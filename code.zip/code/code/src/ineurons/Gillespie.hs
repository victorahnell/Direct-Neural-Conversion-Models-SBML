{-# LANGUAGE DataKinds             #-}
{-# LANGUAGE PartialTypeSignatures #-}
{-# LANGUAGE TemplateHaskell       #-}

module Gillespie
     ( module Gillespie
     ) where

import           Control.Monad.Random
import           Data.Fixed.Vector

import           Phenotype.ReactionNetwork.Stochastic
import           Phenotype.TH.ReactionNetwork

import           Data
import           Model

network :: Cocktail -> GPMap _ (ReactionNetwork Factor)
network Cocktail10   = $(describe . buildPheno $ reactionNetwork <$> neuroreactions Cocktail10)
network RESTi        = $(describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi)
network WildType     = $(describe . buildPheno $ reactionNetwork <$> neuroreactions WildType)
network PTBdepletion = $(describe . buildPheno $ reactionNetwork <$> neuroreactions PTBdepletion)

rungillespie :: MonadRandom m => Cocktail -> Double -> MolarVec Factor -> _ -> MolarVec Factor -> Double -> m [(Double, MolarVec Factor)]
rungillespie cock res noisev g x0 tfinal = gillespieTimes' noisef (gpmap (network cock) g) ts (t0, x0)
    where t0  = 0
          ts = [0, res .. tfinal]
          noisef (Reaction _ stoich) = noisev ! case filter ((/=0).(stoich!)) [minBound .. maxBound] of
              [x] -> x
              _   -> error "One or more reactions in the network affect the concentration level of more than one factor, or none."
