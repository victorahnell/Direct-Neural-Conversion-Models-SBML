{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE TemplateHaskell           #-}

module Functions
     ( module Functions
     ) where

import           Genome.FixedList
import           Language.Haskell.TH
import           Phenotype.TH
import           Phenotype.TH.ReactionNetwork


real = parameter double 'double

one = constantDouble 1

belowone' = (\x -> x/(1+x)) . double
belowone = parameter belowone' 'belowone'

belowten' = (*4) . belowone'
belowten = parameter belowten' 'belowten'

decay = decay' real
transcription = transcription' real
inhibitedBy = inhibitedBy' real belowten
activatedBy = activatedBy' real belowten
background = background' real
complex2 = complex2' belowone
activatedByConstant = activatedBy' one one
inhibitedByConstant = inhibitedBy' one one

partiallyInhibitedBy :: Molar'D c -> Molar'D c -> Molar'D c -> Interaction c -> Molar'D c -> Interaction c
partiallyInhibitedBy p h k a b =
    activatedByConstant (inhibitedByConstant a ((1-p) * (b/k)**h)) (p * (b/k)**h)

-- partiallyInhibitedBy :: Description ExpQ Double -> Description ExpQ Double -> Description ExpQ Double -> Interaction c -> Molar'D c -> Interaction c
-- partiallyInhibitedBy p h k a b =
--     activatedBy' (paramDesc ((k/(p**(1/h))) `typed` [t|Double|])) (paramDesc (h `typed` [t|Double|])) (inhibitedBy' (paramDesc ((k/(1-p)**(1/h)) `typed` [t|Double|])) (paramDesc (h `typed` [t|Double|])) a b) b

withResti x = inhibitedBy' real one x 1
