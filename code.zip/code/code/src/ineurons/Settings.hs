{-# LANGUAGE DataKinds                 #-}
{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE TemplateHaskell           #-}

module Settings
     ( module Settings
     ) where

import           Control.Monad.Random

import           Genome.FixedList
import           Operators.Initiation
import           Organism.GPF
import           Phenotype.TH
import           Phenotype.TH.ReactionNetwork
import           Population.Simple

import           Data
import           Model

neurosystem' Cocktail10   = $(describe . buildPheno $ flip typed [t| ReactionGradient Factor |] <$> gradient <$> neuroreactions Cocktail10)
neurosystem' RESTi        = $(describe . buildPheno $ flip typed [t| ReactionGradient Factor |] <$> gradient <$> neuroreactions RESTi)
neurosystem' WildType     = $(describe . buildPheno $ flip typed [t| ReactionGradient Factor |] <$> gradient <$> neuroreactions WildType)
neurosystem' PTBdepletion = $(describe . buildPheno $ flip typed [t| ReactionGradient Factor |] <$> gradient <$> neuroreactions PTBdepletion)
neurosystem = neurosystem' Cocktail10

g2p g c = gpmap (neurosystem' c) g
p2f = fitnessFun
makeOrganism = makeOrganismStrict g2p p2f

mutation g = flip mutateEach g $
                  mutationProbability (p)    (timesLogNormal (log 1.01))
    `mutationAnd` mutationProbability (p/3)  (timesLogNormal (log 1.05))
    `mutationAnd` mutationProbability (p/10) (timesLogNormal (log 1.50))
    where p = 2 / fromIntegral (ixLength g)

sex = do Just (a,b) <- randomCouple
         ga <- genotype <$> organism a
         gb <- genotype <$> organism b
         geno <- crossover_uniform ga gb >>= mutation
         return $! makeOrganism geno

initEA ini = simple $ generate_ popSize new
    where popSize = 100
          new = case ini of
                  Nothing -> makeOrganism <$> ixReplicateM getRandom
                  Just g  -> makeOrganism <$> return g

stepEA = simple $ evolutionStrategy sex selection parall lambda
    where lambda = 5
          parall = 4
          selection = loser (compareOn fitness)

generations ini rg = map (observe obs) $ run (initEA ini) stepEA rg
    where obs = do alpha <- winner (compareOn fitness) >>= organism
                   return (fitness alpha, genotype alpha)
