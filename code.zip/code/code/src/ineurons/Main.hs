import           Control.Monad
import           Data.Fixed.Vector
import           Data.List
import           Data.Maybe
import           System.Environment
import           System.Exit
import           System.IO
import           System.Random

import           Control.Monad.Random

import           Phenotype.ReactionNetwork
import           Phenotype.TH
import           Utility

import           Data
import           Gillespie
import           Plot
import           Settings

getArgMaybe :: String -> [String] -> Maybe String
getArgMaybe y (x:xs)
    | y `isPrefixOf` x = Just $ drop (length y + 1) x
    | otherwise        = getArgMaybe y xs
getArgMaybe y [] = Nothing

getArg :: String -> [String] -> String -> IO String
getArg y xs er = case getArgMaybe y xs of
    Just r  -> return r
    Nothing -> die er

readNoise :: String -> MolarVec Factor
readNoise str = case reads str :: [(Double,String)] of
    [(x,"")] -> ixReplicate x
    _ -> case reads str :: [(MolarVec Factor,String)] of
             [(x,"")] -> x
             _        -> error "Main.gillespie: Cannot parse noise level."

command "run" cla =
    do seed <- read <$> getArg "seed" cla seedErr
       let ini  = read <$> getArgMaybe "init" cla
       let rand = mkStdGen seed
           ga = take 1000 . takeOneEvery 2500 $ generations ini rand
       hSetBuffering stdout LineBuffering
       putStrLn $ "##   Random seed: " ++ show seed ++ "\n##"
       putStrLn $ "##   Initial genome: " ++ show ini ++ "\n##"
       mapM_ (putStrLn . ("##   "++) . show) $ parameters neurosystem
       putStrLn ""
       mapM_ print ga
    where seedErr = "Main.run: Requires random seed (seed=_)"

command "plot" cla =
    do plot <- getArg "plot" cla "Main.plot: Requires plot file (plot=_)"
       geno <- getArg "geno" cla "Main.plot: Requires genotype (geno=_)"
       void . Plot.plotAll plot . read $ geno

command "params" cla =
    do geno <- getArg "geno" cla "Main.params: Requires genotype (geno=_)"
       printAsTable . forParams (show :: Double -> String) neurosystem . read $ geno

command "fitness" cla =
    do geno <- getArg "geno" cla "Main.fitness: Requires genotype (geno=_)"
       print $ (p2f . g2p) (read geno)

command "gillespie" cla =
    do geno  <- read      <$> getArg "geno"  cla genoErr
       noise <- readNoise <$> getArg "noise" cla noiseErr
       seed  <- read      <$> getArg "seed"  cla seedErr
       let cocktail   = fromMaybe Cocktail10      $ read <$> getArgMaybe "cocktail" cla
       let resolution = fromMaybe 0.1             $ read <$> getArgMaybe "resolution" cla
       let x0         = fromMaybe (xdef cocktail) $ read <$> getArgMaybe "x0" cla
       let tfinal     = fromMaybe (5*24)          $ read <$> getArgMaybe "t" cla
       hSetBuffering stdout LineBuffering
       mapM_ (\(t,v) -> putStrLn $ show t ++ " " ++ show v)
           $ flip evalRand (mkStdGen seed)
           $ rungillespie cocktail resolution noise geno x0 tfinal
    where xdef Cocktail10 = datavector Resti3Days
          xdef _          = datavector Fibroblast
          genoErr  = "Main.gillespie: Requires genotype (geno=_)"
          noiseErr = "Main.gillespie: Requires noise level (noise=_)"
          seedErr  = "Main.gillespie: Requires random seed (seed=_)"

command x _ = putStrLn $ "Command '" ++ x ++ "' not recognized."

main =
    do args <- getArgs
       unless (length args >= 1) $ error "Main: Requires one argument (command)."
       command (head args) (tail args)


printAsTable lst =
          let maxleft = (+1) . maximum . map (length . show . fst) $ lst
              pad x n l = take n (l ++ repeat x)
              left = map (pad ' ' (maxleft `max` 25) . show . fst) lst
              right = map (show . snd) lst
          in mapM_ putStrLn $ zipWith (++) left right
