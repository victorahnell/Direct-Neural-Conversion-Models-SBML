
module Plot
     ( module Plot
     ) where

import           Data.Maybe

import           Graphics.Rendering.Chart.Easy

import           Phenotype.ReactionNetwork
import           Phenotype.ReactionNetwork.Plot
import           Phenotype.TH.Builder

import           Data
import           Settings

compoundC c = (show c, concentration c)

-- scp1restC g = ("SCP1|REST", complex2With (const kd) (concentration O_SCP1) (concentration O_SCP1))
--     where kd = fromMaybe err $ lookupParam neurosystem g "Dissociation constant [M_SCP1|M_REST]" :: Double
--           err = error "ineurons.Plot: Cannot find dissociation constant of [SCP|REST] complex."

plotAll file g = plotGrid (a4landscape 100) file (gridify 3 plots)
    where fs = map compoundC [minBound..maxBound] -- ++ [scp1restC g]
          dat = [ (timeAt m, datavector m) | m <- [Resti3Days .. Day5] ]
          model = runModelAll . g2p $ g
          plots = map addLines $ plotCs dat model fs

addLines plt =
    plt { _layout_plots = _layout_plots plt ++ [
              nolegend $ vlinePlot "RESTi" def (timeAt Fibroblast)
            , nolegend $ vlinePlot "Viral" def (timeAt Resti3Days) ] }
    where nolegend plot = plot { _plot_legend = [] }
