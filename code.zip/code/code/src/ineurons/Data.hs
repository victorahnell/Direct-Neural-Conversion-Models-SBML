
module Data
     ( module Data
     ) where

import qualified Data.Vector.Unboxed                     as V

import           Data.Fixed.Vector
import           Phenotype.ReactionNetwork
import           Phenotype.ReactionNetwork.Deterministic

import           Utility


data Factor  = PTB | NPTB | MiRs | RESTc | EndoNeuroTFs
    deriving (Show,Eq,Enum,Bounded,Ord,Read)
instance Compound Factor

data Measurement = FibroMin3 | FibroMin2 | FibroMin1 | Fibroblast | Resti3Days | Hour8 | Day1 | Day2 | Day3 | Day5 | Week1 | Week2 | Week3
    deriving (Show,Eq,Enum,Bounded,Ord)

data Cocktail = Cocktail10 | RESTi | WildType | PTBdepletion
    deriving (Show,Read,Eq,Bounded,Enum)

timeAt :: Measurement -> Time
timeAt Fibroblast = -72
timeAt Resti3Days = 0;    timeAt Hour8      = 8;   timeAt Day1       = 24
timeAt Day2       = 48;   timeAt Day3       = 72;  timeAt Day5       = 120
timeAt Week1      = 128;  timeAt Week2      = 336; timeAt Week3      = 504

datapoint :: Factor -> Measurement -> [Double]

datapoint EndoNeuroTFs Fibroblast = [0,0,0]
datapoint EndoNeuroTFs Resti3Days = [0,0,0]
datapoint EndoNeuroTFs Hour8      = [0,0,0]
datapoint EndoNeuroTFs Day1       = [0,0,0]
datapoint EndoNeuroTFs Day2       = [0,0,0]
datapoint EndoNeuroTFs Day3       = [0,0,0]
datapoint EndoNeuroTFs Day5       = [5.10066,4.31727,2.96372]
datapoint EndoNeuroTFs Week1      = [7.12724,13.3305]
datapoint EndoNeuroTFs Week2      = [26.7946,133.632]
datapoint EndoNeuroTFs Week3      = [482.693,212.513,264.046]
-- Data for RESTc uses observed expression levels of REST
datapoint RESTc    Fibroblast     = [1,1,0.833627]
datapoint RESTc    Resti3Days     = [0.583367,0.716457,0.645663]
datapoint RESTc    Hour8          = [0.362778,0.599363,0.460984]
datapoint RESTc    Day1           = [1.20932,0.931162]
datapoint RESTc    Day2           = [0.726965,0.509843,0.763301]
datapoint RESTc    Day3           = [0.607953,0.452178]
datapoint RESTc    Day5           = [0.484112,0.563749,0.571023]
datapoint RESTc    Week1          = [0.714685,0.600129]
datapoint RESTc    Week2          = [0.866703,0.531927]
datapoint RESTc    Week3          = [0.890329,0.616981,0.994556]
datapoint PTB     Fibroblast      = [1,1,1.1038]
datapoint PTB     Resti3Days      = [0.954274,0.811663,0.831538]
datapoint PTB     Hour8           = [0.514827,0.511038,0.548205]
datapoint PTB     Day1            = [1.37477,1.24152]
datapoint PTB     Day2            = [1.03523,0.828243,1.20191]
datapoint PTB     Day3            = [0.918296,0.920164]
datapoint PTB     Day5            = [0.786442,1.09667,0.886764]
datapoint PTB     Week1           = [1.24003,0.825502]
datapoint PTB     Week2           = [1.34128,0.978946]
datapoint PTB     Week3           = [1.98951,0.848683,1.20341]
datapoint NPTB    Fibroblast      = [1,1,1.69053]
datapoint NPTB    Resti3Days      = [1.27675,4.08108,1.10869]
datapoint NPTB    Hour8           = [2.38198,1.36273,3.68787]
datapoint NPTB    Day1            = [3.95642,5.30408]
datapoint NPTB    Day2            = [3.68064,3.11261,2.50589]
datapoint NPTB    Day3            = [5.74391,1.91848]
datapoint NPTB    Day5            = [3.33668,4.03656,5.43252]
datapoint NPTB    Week1           = [3.39963,5.40144]
datapoint NPTB    Week2           = [3.36035,5.89422]
datapoint NPTB    Week3           = [3.63614,3.75366,7.60593]
-- Data for miRs uses observed expression levels of miR-124
datapoint MiRs Fibroblast         = [1,1,17.4481]
datapoint MiRs Resti3Days         = [1.08673,1.6644,0.760489]
datapoint MiRs Hour8              = [6.27667,3.69353,1.91853]
datapoint MiRs Day1               = [3.42238,2.17347]
datapoint MiRs Day2               = [4.37717,6.19026,3.03143]
datapoint MiRs Day3               = [9.28563,5.31474]
datapoint MiRs Day5               = [10.4469,5.65685,7.80825]
datapoint MiRs Week1              = [24.3357,15.5625]
datapoint MiRs Week2              = [53.0765,49.694]
datapoint MiRs Week3              = [103.609,113.772,94.0268]
-- datapoint O_Brn2  Fibroblast    = [0,0,0.]
-- datapoint O_Brn2  Resti3Days    = [0,0,0.]
-- datapoint O_Brn2  Hour8         = [0,0.]
-- datapoint O_Brn2  Day1          = [0,0,0.]
-- datapoint O_Brn2  Day2          = [0,0.]
-- datapoint O_Brn2  Day3          = [0,0,0.]
-- datapoint O_Brn2  Day5          = [0,0.]
-- datapoint O_Brn2  Week1         = [0,0.]
-- datapoint O_Brn2  Week2         = [0,0,0.]
-- datapoint O_Brn2  Week3         = [163.706,0,0.]
-- datapoint O_ViralAscl1 Fibroblast    = [0,0,0.]
-- datapoint O_ViralAscl1 Resti3Days    = [0,0,0.]
-- datapoint O_ViralAscl1 Hour8         = [57150.3,20395.5,91778.2]
-- datapoint O_ViralAscl1 Day1          = [523612.,2.70116*10^6]
-- datapoint O_ViralAscl1 Day2          = [521779.,1.40001*10^6,372222.]
-- datapoint O_ViralAscl1 Day3          = [840056.,163919.]
-- datapoint O_ViralAscl1 Day5          = [350896.,93983.4,318826.]
-- datapoint O_ViralAscl1 Week1         = [53912.9,222225.]
-- datapoint O_ViralAscl1 Week2         = [21676.9,67244.]
-- datapoint O_ViralAscl1 Week3         = [23412.,48692.4,74484.3]
-- datapoint O_miR_9   Fibroblast      = [1,1,5.48313]
-- datapoint O_miR_9   Resti3Days      = [0.449066,1.20999,0.530344]
-- datapoint O_miR_9   Hour8           = [3.82378,0.803851,2.58471]
-- datapoint O_miR_9   Day1            = [1.73508,1.5966]
-- datapoint O_miR_9   Day2            = [2,6.38639,2.06337]
-- datapoint O_miR_9   Day3            = [10.3747,2.75108]
-- datapoint O_miR_9   Day5            = [13.5011,2.07772,6.38639]
-- datapoint O_miR_9   Week1           = [10.4831,5.50217]
-- datapoint O_miR_9   Week2           = [11.0809,17.3276]
-- datapoint O_miR_9   Week3           = [29.1414,41909.8,27746.2]
-- datapoint SCP1    Fibroblast     = [1,1,1.43145]
-- datapoint SCP1    Resti3Days     = [1.82447,2.44351,1.7579]
-- datapoint SCP1    Hour8          = [0.660742,0.880565,1.25509]
-- datapoint SCP1    Day1           = [2.59223,2.5617]
-- datapoint SCP1    Day2           = [2.02786,1.46726,1.53722]
-- datapoint SCP1    Day3           = [1.5878,0.993067]
-- datapoint SCP1    Day5           = [1.34575,2.20095,1.59839]
-- datapoint SCP1    Week1          = [1.59702,1.76338]
-- datapoint SCP1    Week2          = [2.06138,2.34453]
-- datapoint SCP1    Week3          = [2.40729,1.25119,2.26911]

datavector :: Measurement -> MolarVec Factor
datavector = datavectorWith median
datavectorWith :: ([Double] -> Double) -> Measurement -> MolarVec Factor
datavectorWith f measurement =
    indexed . V.fromList $ [ f (datapoint i measurement) | i <- [minBound..maxBound] ]

stepSizeSim, stepSizeOut :: Double
stepSizeSim = 0.05
stepSizeOut = 2

runModel :: MolarVec Factor -> ReactionGradient Factor -> Time -> Time -> [(Time, MolarVec Factor)]
runModel x0 f t0 tf = constantStepSize stepSizeSim (rk4 f) (t0, x0) [t0, t0+stepSizeOut .. tf]

runModelViral, runModelFibro, runModelResti, runModelAll :: (Cocktail -> ReactionGradient Factor) -> [(Time, MolarVec Factor)]
runModelViral f = runModel (datavector Resti3Days) (f Cocktail10) (timeAt Resti3Days) (timeAt Day5)
runModelFibro f = runModel (datavector Fibroblast) (f WildType) (timeAt Fibroblast - 3*24) (timeAt Fibroblast)
runModelResti f = runModel (datavector Fibroblast) (f RESTi) (timeAt Fibroblast) (timeAt Resti3Days)
runModelAll   f = runModelFibro f ++ runModelResti f ++ runModelViral f

fitnessFun :: (Cocktail -> ReactionGradient Factor) -> Maybe Double
fitnessFun f =
    do lackoffit  <- negate . ixSum <$> fitting [Hour8 .. Day5] viralpoints
       restifit   <- negate . ixSum <$> fitting [Resti3Days] restipoints
       roughness  <- negate . ixSum <$> smoothness 2 viralpoints
       steadiness <- negate . ixSum <$> smoothness 1 fibropoints
       return $ lackoffit + restifit + roughness*smoothnessweight + steadiness*steadinessweight
    where viralpoints = runModelViral f
          restipoints = runModelResti f
          fibropoints = runModelFibro f
          smoothnessweight = 1/4
          steadinessweight = 1/4

fitting :: [Measurement] -> [(Time, MolarVec Factor)] -> Maybe (MolarVec Factor)
fitting measurements points =
    fmap sum . sequence $ zipWith cost measurements modelpoints
    where modelpoints = findPoints points $ map timeAt measurements
          approx x y = abs (x - y) < 0.01
          findPoints ((t',v):vecs) (t:ts) =
              if abs (t-t') < 0.01 then v : findPoints vecs ts else findPoints vecs (t:ts)
          findPoints _ [] = []
          findPoints [] l = error "ineurons.Data.fitnessFun: executeModel output list does not contain all data points."

cost :: Measurement -> MolarVec Factor -> Maybe (MolarVec Factor)
cost measurement values = onlyIf (ixAll isFiniteDouble) $
    ixZipWith err (o / maxes) (d / maxes)
    where d = datavector measurement
          o = values
          err a b = (a-b)^2

maxes :: MolarVec Factor
maxes = indexed . V.fromList $ [ maximum [ median (datapoint c m) | m <- [Resti3Days .. Day5] ] | c <- [minBound .. maxBound] ]

smoothness :: Int -> [(Time, MolarVec Factor)] -> Maybe (MolarVec Factor)
smoothness 1 = onlyIf (ixAll correct) . (/maxes) . (/ ixReplicate stepSizeOut) . sum . differences . map snd
    where differences (x:y:zs) = abs (x-y) : differences zs
          differences _        = []
          correct x = isFiniteDouble x && x > 0
smoothness 2 = onlyIf (ixAll correct) . (/maxes) . (/ ixReplicate (stepSizeOut^2)) . sum . differences . map snd
    where differences (x:y:z:zs) = abs (z+x-y-y) : differences zs
          differences _          = []
          correct x = isFiniteDouble x && x > 0
