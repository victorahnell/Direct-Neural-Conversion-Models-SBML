

module Organism.Blob
     ( module Organism.Blob
     ) where

-- | An organism type with no attributes.
data Blob = Blob
