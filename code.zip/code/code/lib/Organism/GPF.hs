{-# LANGUAGE BangPatterns #-}

module Organism.GPF
     ( module Organism.GPF
     ) where

data Organism g p f = Organism { genotype :: g, phenotype :: p, fitness :: f }
    deriving Show

-- | Create an organism using the genome and given GPmap and fitness function.
--   This function is strict, meaning the gpmap and fitness function will be
--   evaluated the moment the organism is first created.
makeOrganismStrict :: (g -> p) -> (p -> f) -> g -> Organism g p f
makeOrganismStrict gpmap pfmap !g =
    let !p = gpmap g; !f = pfmap p in Organism g p f

-- | Lazy version of makeOrganismStrict.
makeOrganismLazy :: (g -> p) -> (p -> f) -> g -> Organism g p f
makeOrganismLazy gpmap pfmap g =
    let p = gpmap g; f = pfmap p in Organism g p f
