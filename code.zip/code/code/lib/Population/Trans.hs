{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE FlexibleInstances         #-}
{-# LANGUAGE MultiParamTypeClasses     #-}
{-# LANGUAGE NoMonomorphismRestriction #-}

module Population.Trans
     ( module Population.Trans
     , module Population.Definition
     ) where

import           Population.Definition

class PopulationTrans t where
    unlift :: Population p o => t p o -> p o

    liftAction :: (Population p o, Population (t p) o) => Action s p o a -> Action s (t p) o (a, p o)
    liftAction = action . localAction unlift

    liftDrone :: Population p o => Drone s p o a -> Drone s (t p) o a
    liftDrone = localDrone unlift

    lift :: (Population p o, PopulationM m s (t p) o) => Observer s p o a -> m s (t p) o a
    lift = grabs . localObserve unlift
