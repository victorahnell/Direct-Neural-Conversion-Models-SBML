{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE RankNTypes            #-}
{-# LANGUAGE FlexibleInstances #-}

{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module Population.Definition
     ( module Population.Definition
     , module Control.Monad.Random
     , module Control.Monad.Reader
     , module Control.Monad.State
     ) where

import           Control.Monad
import           Control.Monad.Parallel (MonadFork (..), MonadParallel (..))
import           Control.Monad.Random (MonadRandom (..), RandomGen (..), Random (..))
import           Control.Monad.Reader (MonadReader (..), asks)
import           Control.Monad.State (MonadState (..), modify, gets)
import           Control.Parallel (par)
import           Data.Coerce (coerce)
import           Data.Hashable (Hashable)
import           Data.List ((\\))
import           Data.Maybe (fromMaybe)

newtype Pointer s = Pointer Int
    deriving (Eq,Ord,Hashable)

newtype SomePointer = SomePointer Int
    deriving (Eq,Ord,Hashable)

-- point :: PopulationM m s p o => Pointer s -> (SomePointer -> x) -> m s p o x
-- point p f = return . f . coerce $ p

point :: PopulationM m s p o => (SomePointer -> m s p o x) -> Pointer s -> m s p o x
point f = f . coerce

specialize :: PopulationM m s p o => SomePointer -> m s p o (Pointer s)
specialize = return . coerce

increment :: SomePointer -> SomePointer
increment (SomePointer i) = SomePointer (i+1)

counter :: SomePointer -> Int
counter = coerce

bootstrapPointer :: SomePointer
bootstrapPointer = SomePointer (-1)

class (Population p o, Monad (m s p o)) => PopulationM m s p o where
    action :: m s p o a -> Action s p o a
    grabs :: Observer s p o a -> m s p o a
    grab :: m s p o (p o)
    grab = grabs (Observer id)

class Population p o where
    empty :: p o

    generation      :: PopulationM m s p o =>                m s p o Int
    organismCounter :: PopulationM m s p o =>                m s p o Int
    organismMaybe   :: PopulationM m s p o =>  Pointer s  -> m s p o (Maybe o)
    population      :: PopulationM m s p o =>                m s p o [Pointer s]

    populationSize  :: PopulationM m s p o =>                m s p o Int
    organism        :: PopulationM m s p o =>  Pointer s  -> m s p o o
    organisms       :: PopulationM m s p o =>                m s p o [o]
    allExcept       :: PopulationM m s p o => [Pointer s] -> m s p o [Pointer s]

    killQuiet       ::  Pointer s  -> Action s p o Bool
    nextGeneration  ::                Action s p o ()

    killQuiet_      ::  Pointer s  -> Action s p o ()
    kill            ::  Pointer s  -> Action s p o ()
    select          :: [Pointer s] -> Action s p o ()

    populationSize = length <$> population
    organism p = fromMaybe err <$> organismMaybe p
        where err = error "Population.Definition.Population.organism: Given pointer does not exist in the population."
    organisms = mapM organism =<< population
    allExcept ps = (\\ ps) <$> population

    killQuiet_ = void . killQuiet
    kill p = do r <- killQuiet p; if r then return () else err
        where err = error "Population.Definition.Population.kill: Tried to kill organism that does not exist."
    select ps = allExcept ps >>= mapM_ kill

class Population p o => Addable p o x where
    add :: x -> Action s p o (Maybe (Pointer s))

instance Addable p o x => Addable p o (Maybe x) where
    add Nothing  = return Nothing
    add (Just x) = add x

-- * Action

newtype Action s p o a = Action (forall rg. RandomGen rg => rg -> p o -> (rg, p o, a))

runAction :: RandomGen rg => (forall s. Action s p o a) -> rg -> p o -> (rg, p o, a)
runAction (Action act) rg pop = act rg pop

instance Functor (Action s p o) where
    fmap f (Action act) = Action $ \ rg pop ->
        let (rg',pop',x) = act rg pop
        in (rg',pop',f x)

instance Applicative (Action s p o) where
    (<*>) = ap
    pure = return

instance Monad (Action s p o) where
    return x = Action $ \ rg pop -> (rg,pop,x)
    Action act >>= f = Action $ \ rg pop ->
        let (rg',pop',x) = act rg pop
            Action act' = f x
        in act' rg' pop'

instance MonadRandom (Action s p o) where
    getRandom        = Action $ \ rg pop -> let (x,rg') = random rg in (rg',pop,x)
    getRandomR lohi  = Action $ \ rg pop -> let (x,rg') = randomR lohi rg in (rg',pop,x)
    getRandoms       = Action $ \ rg pop -> let (rg',rg'') = split rg; xs = randoms rg' in (rg'',pop,xs)
    getRandomRs lohi = Action $ \ rg pop -> let (rg',rg'') = split rg; xs = randomRs lohi rg' in (rg'',pop,xs)

instance MonadState (p o) (Action s p o) where
    get = Action $ \ rg pop -> (rg,pop,pop)
    put pop = Action $ \ rg _ -> (rg,pop,())

instance Population p o => PopulationM Action s p o where
    action = id
    grabs = gets . coerce
    grab = get

-- * Drone

newtype Drone s p o a = Drone (forall rg. RandomGen rg => rg -> p o -> (rg, a))

localAction :: (p' o' -> p o) -> Action s p o a -> Drone s p' o' (a, p o)
localAction f (Action act) = Drone $ \ rg pop ->
    let (rg',pop',x) = act rg (f pop)
    in (rg',(x,pop'))

runDrone :: RandomGen rg => (forall s. Drone s p o a) -> rg -> p o -> (rg, a)
runDrone (Drone dr) rg pop = dr rg pop

execDrone :: RandomGen rg => (forall s. Drone s p o a) -> rg -> p o -> a
execDrone dr rg pop = snd $ runDrone dr rg pop

localDrone :: (p' o' -> p o) -> Drone s p o a -> Drone s p' o' a
localDrone f (Drone dr) = Drone $ \ rg pop -> dr rg (f pop)

localDroneM :: Action s p o () -> Drone s p o a -> Drone s p o a
localDroneM (Action act) (Drone dr) = Drone $ \ rg pop ->
    let (rg',pop',()) = act rg pop
    in dr rg' pop'

instance Functor (Drone s p o) where
    fmap f (Drone dr) = Drone $ \ rg pop ->
        let (rg',x) = dr rg pop
        in (rg',f x)

instance Applicative (Drone s p o) where
    (<*>) = ap
    pure = return

instance Monad (Drone s p o) where
    return x = Drone $ \ rg _ -> (rg,x)
    Drone dr >>= f = Drone $ \ rg pop ->
        let (rg',x) = dr rg pop
            Drone dr' = f x
        in dr' rg' pop

instance MonadRandom (Drone s p o) where
    getRandom        = Drone $ \ rg _ -> let (x,rg') = random rg in (rg',x)
    getRandomR lohi  = Drone $ \ rg _ -> let (x,rg') = randomR lohi rg in (rg',x)
    getRandoms       = Drone $ \ rg _ -> let (rg',rg'') = split rg; xs = randoms rg' in (rg'',xs)
    getRandomRs lohi = Drone $ \ rg _ -> let (rg',rg'') = split rg; xs = randomRs lohi rg' in (rg'',xs)

instance MonadReader (p o) (Drone s p o) where
    ask = Drone $ \ rg pop -> (rg,pop)
    local = localDrone

instance Population p o => PopulationM Drone s p o where
    action (Drone dr) = Action $ \ rg pop ->
        let (rg',x) = dr rg pop
        in (rg',pop,x)
    grabs = asks . coerce
    grab = ask

instance MonadParallel (Drone p s o) where
    bindM2 f ma mb =
        do apar <- forkExec ma
           b <- mb
           a <- apar
           f a b

instance MonadFork (Drone p s o) where
    forkExec (Drone dr) = Drone $ \ rg pop ->
        let (rgr,rg') = split rg
            (_,x) = dr rgr pop
        in x `par` (rg',return x)

-- | Observer

newtype Observer s p o a = Observer (p o -> a)
    deriving ( Functor, Applicative, Monad
             , MonadParallel, MonadFork
             , MonadReader (p o)
             )

observer :: Observer s p o a -> Observer s p o a
observer = id

observe :: (forall s. Observer s p o a) -> p o -> a
observe (Observer obs) pop = obs pop

localObserve :: (p' o' -> p o) -> Observer s p o a -> Observer s p' o' a
localObserve f (Observer obs) = Observer $ \ pop -> obs (f pop)

instance Population p o => PopulationM Observer s p o where
    action (Observer obs) = Action $ \ rg pop -> (rg,pop,obs pop)
    grabs = id
    grab = ask


-- * GA

run :: (Population p o, RandomGen rg) => (forall s. Action s p o ()) -> (forall s. Action s p o ()) -> rg -> [p o]
run ini step rgi =
    go $ runAction ini rgi empty
    where go (rg, pop, ()) = pop : go (runAction step rg pop)
