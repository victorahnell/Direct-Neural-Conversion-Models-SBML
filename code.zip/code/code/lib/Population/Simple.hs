{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE MultiParamTypeClasses      #-}
{-# LANGUAGE RankNTypes                 #-}
{-# LANGUAGE TypeFamilies               #-}

module Population.Simple
     ( module Population.Simple
     , module Population.Definition
     ) where

import           Data.Coerce           (coerce)
import           Data.HashMap.Strict   (HashMap)
import qualified Data.HashMap.Strict   as M (delete, empty, insert, keys,
                                             lookup, member)

import           Population.Definition
-- import           Population.Definition.Pointer

-- | ** Simple population type.
-- A population with no capabilities other than keeping track of a set of organisms and pointers.

data SimplePop o
   = SimplePop
   { pop_generation :: ! Int
   , pop_counter    :: ! SomePointer
   , pop_pop        :: ! (HashMap SomePointer o)
   }

instance Population SimplePop o where
    empty = SimplePop 0 bootstrapPointer M.empty

    generation = pop_generation <$> grab
    organismCounter = counter . pop_counter <$> grab
    population = coerce . M.keys . pop_pop <$> grab
    organismMaybe = point $ \ p -> M.lookup p . pop_pop <$> grab

    killQuiet = point $ \ p ->
        do pop <- get
           if p `M.member` pop_pop pop
           then do put $ pop { pop_pop = p `M.delete` pop_pop pop }
                   return True
           else    return False

    nextGeneration = modify $ \ pop -> pop {
        pop_generation = pop_generation pop + 1
        }

instance x ~ o => Addable SimplePop o x where
    add x = do pop <- get
               let p = increment $ pop_counter pop
               put $ pop { pop_pop = M.insert p x $ pop_pop pop
                         , pop_counter = p }
               Just <$> specialize p

-- | Useful to collapse polymorphism in applications.
simple :: m s SimplePop o a -> m s SimplePop o a
simple = id
