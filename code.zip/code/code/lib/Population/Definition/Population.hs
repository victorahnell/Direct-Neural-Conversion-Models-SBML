{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module Population.Definition.Population
     ( module Population.Definition.Population
     ) where

import           Data.Foldable                 (foldr')
import           Data.List
import           Data.Maybe

import           Population.Definition.Pointer

-- ** Population
-- | An instance of the Population class provides basic GA functionality.
--   Populations have (at least) two arguments: the type of organism that inhabits the population, and the pointer dummy type (similar to ST's type argument).
--   Class functions are implemented as "pure" functions, but usually they are applied monadically (see PopulationM, implemented by Action and Drone).
class Population p where
    -- | Empty population
    empty :: p s o
    -- | How many generations have passed?
    pureGeneration :: p s o -> Integer
    -- | How many organisms have been generated? This includes all dead organisms.
    pureOrganismCounter :: p s o -> Integer
    -- | Remove an organism from the population, and return success (True) or failure (False).
    pureQuietKill :: Pointer s -> p s o -> (p s o, Bool)
    -- | Get an organism from a Pointer, if it exists.
    pureOrganismMaybe :: Pointer s -> p s o -> Maybe o
    -- | Get the list of all pointers currently in the population.
    purePopulation :: p s o -> [Pointer s]
    -- | Increment the generation counter by 1
    pureIncrementGeneration :: p s o -> p s o

    -- | Size of the population
    purePopulationSize :: p s o -> Int
    purePopulationSize = length . purePopulation

    -- | Unsafe version of pureOrganismMaybe
    pureOrganism :: Pointer s -> p s o -> o
    pureOrganism p = fromMaybe err . pureOrganismMaybe p
        where err = error "Population.Definition.Population.organism: Given pointer does not exist in the population."

    -- | Get list of all organisms currently in the population.
    pureOrganisms :: p s o -> [o]
    pureOrganisms pop = flip pureOrganism pop <$> purePopulation pop

    -- | Take all organisms currently in the population, except the supplied list.
    pureAllExcept :: [Pointer s] -> p s o -> [Pointer s]
    pureAllExcept ps pop = purePopulation pop \\ ps

    -- | Remove an organism from the population, and throw an error if the organism didn't exist.
    pureKill :: Pointer s -> p s o -> p s o
    pureKill p pop = case pureQuietKill p pop of
        (pop', True) -> pop'
        (_   ,False) -> error "Population.pureKill: Tried to kill organism that does not exist."

    -- | Remove an organism from the population, don't give any feedback on success or failure.
    pureQuietKill_ :: Pointer s -> p s o -> p s o
    pureQuietKill_ p pop = fst $ pureQuietKill p pop

    pureSelect :: [Pointer s] -> p s o -> p s o
    pureSelect ps pop = foldr' pureKill pop (pureAllExcept ps pop)

class Population p => Addable p o x where
    pureAdd :: x -> p s o -> (p s o, Maybe (Pointer s))

instance Addable p o x => Addable p o (Maybe x) where
    pureAdd Nothing  pop = (pop, Nothing)
    pureAdd (Just x) pop = pureAdd x pop
