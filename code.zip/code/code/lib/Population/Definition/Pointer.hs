{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module Population.Definition.Pointer
     ( module Population.Definition.Pointer
     ) where

import           Data.Hashable (Hashable)

newtype Pointer s = Pointer Integer
    deriving (Ord,Eq,Hashable)
