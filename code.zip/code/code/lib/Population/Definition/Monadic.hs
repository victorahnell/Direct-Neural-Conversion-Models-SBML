{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE RankNTypes            #-}

module Population.Definition.Monadic
     ( module Population.Definition.Monadic
     ) where

import Data.List
import System.Random
import Data.Tuple (swap)
import           Control.Monad.Random
import           Control.Monad.State
import           Control.Monad.Reader
import qualified Control.Monad.Parallel as P
import           Control.Parallel

import Population.Definition.Population
import Population.Definition.Pointer


-- ** Monadic Population modifiers.
-- The workhorse is the Action monad, which gives serves as a State monad
-- to modify a Population, as well as a Random monad.
-- The Drone type is a weakened version of Action, giving access to the
-- Population as a Reader instead of State. Drone is useful because it can be
-- used to perform parallel computations, and then converted to an Action.

-- | PopulationM captures the overlap between Drone and Action.
--   It provides access to random values and a population environment.
class (MonadRandom (m p s o), Population p) => PopulationM m p s o where
    -- | Lift PopulationM to an Action.
    action   :: m p s o a -> Action p s o a
    -- | Read a value from the population, equivalent to MonadReader's asks.
    grab     :: (p s o -> a) -> m p s o a

instance Population p => PopulationM Action p s o where
    action = id
    grab f = Action $ \ rg pop -> (rg,pop,f pop)

instance Population p => PopulationM Drone p s o where
    action dr = Action $ \ rg pop -> let (rg',x) = runDrone dr rg pop in (rg',pop,x)
    grab f = Drone $ \ rg pop -> (rg,f pop)

-- * Monadic class functions.

generation      :: PopulationM m p s o => m p s o Integer
generation      = grab     pureGeneration
organismCounter :: PopulationM m p s o => m p s o Integer
organismCounter = grab     pureOrganismCounter
population      :: PopulationM m p s o => m p s o [Pointer s]
population      = grab     purePopulation
organisms       :: PopulationM m p s o => m p s o [o]
organisms       = grab     pureOrganisms
populationSize  :: PopulationM m p s o => m p s o Int
populationSize  = grab     purePopulationSize
organismMaybe   :: PopulationM m p s o => Pointer s -> m p s o (Maybe o)
organismMaybe   = grab   . pureOrganismMaybe
organism        :: PopulationM m p s o => Pointer s -> m p s o o
organism        = grab   . pureOrganism
allExcept       :: PopulationM m p s o => [Pointer s] -> m p s o [Pointer s]
allExcept       = grab   . pureAllExcept
kill            :: Population p => Pointer s -> Action p s o ()
kill            = modify . pureKill
quietKill_      :: Population p => Pointer s -> Action p s o ()
quietKill_      = modify . pureQuietKill_
quietKill       :: Population p => Pointer s -> Action p s o Bool
quietKill       = state  . (.) swap . pureQuietKill
add             :: (Population p, Addable p o x) => x -> Action p s o (Maybe (Pointer s))
add             = state  . (.) swap . pureAdd

-- * Action

data Action p s o a = Action { runAction :: forall rg. RandomGen rg => rg -> p s o -> (rg, p s o, a) }

instance Functor (Action p s o) where
    fmap f a = Action $ \ rg pop ->
        let (rg',pop',x) = runAction a rg pop
        in (rg',pop',f x)

instance Applicative (Action p s o) where
    pure  = return
    (<*>) = ap

instance Monad (Action p s o) where
    return x = Action $ \ rg pop -> (rg, pop, x)
    m >>=  f = Action $ \ rg pop ->
        let (rg', pop', x) = runAction m rg pop
        in runAction (f x) rg' pop'

instance MonadRandom (Action p s o) where
    getRandom        = Action $ \ rg pop -> let (x,rg') = random rg in (rg',pop,x)
    getRandomR lohi  = Action $ \ rg pop -> let (x,rg') = randomR lohi rg in (rg',pop,x)
    getRandoms       = Action $ \ rg pop -> let (rg',rg'') = split rg; xs = randoms rg' in (rg'',pop,xs)
    getRandomRs lohi = Action $ \ rg pop -> let (rg',rg'') = split rg; xs = randomRs lohi rg' in (rg'',pop,xs)

instance MonadState (p s o) (Action p s o) where
    get = Action $ \ rg pop -> (rg,pop,pop)
    put pop = Action $ \ rg _ -> (rg,pop,())

-- * Drone

data Drone p s o a = Drone { runDrone :: forall rg. RandomGen rg => rg -> p s o -> (rg, a) }

-- | Execute a Drone in a modified environment, possibly modifying the type of the population.
localDrone :: (p' s o' -> p s o) -> Drone p s o a -> Drone p' s o' a
localDrone f drone = Drone $ \ rg pop ->
    runDrone drone rg (f pop)

-- | Like localDrone, but using an Action to define the local transformation.
--  This means the type of the population cannot change, but it does allow randomness.
localDroneM :: Action p s o () -> Drone p s o a -> Drone p s o a
localDroneM m drone = Drone $ \ rg pop ->
    let (rg',pop',()) = runAction m rg pop
    in runDrone drone rg' pop'

-- | Turn a monadic Drone into a pure function inspecting a population.
--   Throws an error if the MonadRandom instance is used.
observe :: Drone p s o a -> p s o -> a
observe drone pop = snd $ runDrone drone (err :: StdGen) pop
    where err = error "Population.Definition.Monadic.observe: Cannot use Random generator in observer."

instance Functor (Drone p s o) where
    fmap f m = Drone $ \ rg pop -> f <$> runDrone m rg pop

instance Applicative (Drone p s o) where
    pure = return
    (<*>) = ap

instance Monad (Drone p s o) where
    return x = Drone $ \ rg _   -> (rg,x)
    m >>=  f = Drone $ \ rg pop ->
        let (rg',x) = runDrone m rg pop
        in runDrone (f x) rg' pop

instance MonadRandom (Drone p s o) where
    getRandom        = Drone $ \ rg _ -> let (x,rg') = random rg in (rg',x)
    getRandomR lohi  = Drone $ \ rg _ -> let (x,rg') = randomR lohi rg in (rg',x)
    getRandoms       = Drone $ \ rg _ -> let (rg',rg'') = split rg; xs = randoms rg' in (rg'',xs)
    getRandomRs lohi = Drone $ \ rg _ -> let (rg',rg'') = split rg; xs = randomRs lohi rg' in (rg'',xs)

instance MonadReader (p s o) (Drone p s o) where
    ask = Drone $ \ rg pop -> (rg, pop)
    local f m = Drone $ \ rg pop -> runDrone m rg (f pop)

instance P.MonadParallel (Drone p s o) where
    bindM2 f ma mb =
        do apar <- P.forkExec ma
           b <- mb
           a <- apar
           f a b

instance P.MonadFork (Drone p s o) where
    forkExec m = Drone $ \ rg pop ->
        let (rgr,rg') = split rg
            (_,x) = runDrone m rgr pop
        in x `par` (rg',return x)

-- * Run

run :: (Population p, RandomGen rg) => Action p s o a -> (a -> Action p s o a) -> rg -> [(p s o, a)]
run ini step rg =
    let (rg', pop, x) = runAction ini rg empty
    in unfoldr go (rg', pureIncrementGeneration pop, x)
    where go (r, pop, x) =
              let (r', pop', x') = runAction (step x) r pop
              in Just ((pop, x), (r', pureIncrementGeneration pop', x'))
