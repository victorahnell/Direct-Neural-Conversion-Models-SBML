{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module Population.Spatial.Operators
     ( module Population.Spatial.Operators
     ) where

import           Control.Monad               (filterM, mapM, void)
import qualified Control.Monad.Parallel      as P (mapM, replicateM)
import           Data.Maybe                  (catMaybes)

import           Population.Definition
import           Population.Spatial.Topology
import           Population.Trans.Spatial

-- | Execute a Drone in a limited environment, including only the direct neighborhood of the given coordinate (including that coordinate itself).
around :: (Population p o, Topology t) => Coordinate t -> Drone s p o a -> Drone s (SpatialT t p) o a
around l dr =
    do ps <- catMaybes <$> mapM inhabitant (l : neighborhood l)
       localDroneM (select ps) $ liftDrone dr

-- | Like around, but using a random coordinate.
somewhere :: (Population p o, FiniteTopology t) => Drone s p o a -> Drone s (SpatialT t p) o a
somewhere drone = getRandom >>= flip around drone

place, replace :: (Addable p o (Coordinate t, x), PopulationSpatial t p o)
               => Coordinate t -> x -> Action s p o (Maybe (Pointer s))
place = curry add
replace c x =
    do pm <- inhabitant c; case pm of
           Nothing -> place c x
           Just p  -> do kill p; place c x

-- | Fill a finite topology with organisms produced by a given monadic generator.
fill :: (Addable p o (Coordinate t, x), FiniteTopology t, PopulationSpatial t p o) => Drone s p o x -> Action s p o [Pointer s]
fill mx =
    do ls <- filterM isEmpty everywhere
       if null ls
       then return []
       else do xs <- action $ P.mapM (\ l -> (,) l <$> mx) ls
               ps <- catMaybes <$> mapM add xs
               (ps ++) <$> fill mx

fill_ :: (Addable p o (Coordinate t, x), FiniteTopology t, PopulationSpatial t p o) => Drone s p o x -> Action s p o ()
fill_ mx = void $ fill mx

-- | A variant of Simple.EvolutionStrategy, where the reproduction and selection Drones are executed in local environments.
localStrategy :: (Population p o, Addable p o x, FiniteTopology t)
              => Drone s p o x
              -> (Drone s p o (Pointer s))
              -> Int
              -> Action s (SpatialT t p) o ()
localStrategy new sel n =
    do views <- action $ P.replicateM n $
           do l <- getRandom
              x <- around l new
              y <- around l sel >>= location
              return (x, y)
       sequence_ [ replace loser offspring | (offspring, loser) <- views ]
