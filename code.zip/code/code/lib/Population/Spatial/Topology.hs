{-# LANGUAGE DataKinds                  #-}
{-# LANGUAGE FlexibleContexts           #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE KindSignatures             #-}
{-# LANGUAGE ScopedTypeVariables        #-}
{-# LANGUAGE StandaloneDeriving         #-}
{-# LANGUAGE TypeFamilies               #-}
{-# LANGUAGE TypeOperators              #-}

module Population.Spatial.Topology
     ( Topology (..), FiniteTopology (..)
     , InfiniteLine, HalfOpenLine, Line, Circle
     , Times, Times', Plus
     , Torus, Box, Cube
     ) where

import           Control.Monad                (void)
import           Control.Monad.Random         (Random (..))
import           Control.Monad.State          (runState, state)
import           Data.Coerce                  (coerce)
import           Data.Hashable                (Hashable)
import           Data.Maybe                   (fromMaybe)
import           Data.Proxy                   (Proxy (..))
import           GHC.TypeLits
import           Text.ParserCombinators.ReadP


-- newtype MagicTopology x = MagicNat (forall (t :: *). Topology t => [Coordinate t] -> x)
--
-- reifyTopology :: forall x. ValueTopology -> (forall (t :: *). Topology t => [Coordinate t] -> x) -> x
-- reifyTopology t k = reify

-- ** Topology class
class (Eq (Coordinate t), Hashable (Coordinate t)) => Topology t where
    data Coordinate t
    topology :: Proxy t
    topology = Proxy
    neighborhood :: Coordinate t -> [Coordinate t]
    sizeMaybe :: proxy t -> Maybe Int
    everywhere :: [Coordinate t]

class (Random (Coordinate t), Topology t) => FiniteTopology t where
    size :: proxy t -> Int
    size = fromMaybe err . sizeMaybe
        where err = error "Population.Spatial.Topology: Instance of FiniteTopology not actually finite."

-- * Infinite line
data InfiniteLine :: *

instance Topology InfiniteLine where
    newtype Coordinate InfiniteLine = InfiniteLineC Integer

    neighborhood (InfiniteLineC c) = coerce [c-1,c+1]

    sizeMaybe _ = Nothing

    everywhere = coerce (0 : interleave [1, 2 ..] [-1, -2 ..] :: [Integer])
        where interleave (a:as) (b:bs) = a : b : interleave as bs
              interleave _ _           = []

deriving instance Hashable (Coordinate InfiniteLine)
deriving instance Eq (Coordinate InfiniteLine)
deriving instance Ord (Coordinate InfiniteLine)

instance Show (Coordinate InfiniteLine) where
    show (InfiniteLineC c) = "-" ++ show c ++ "-"

instance Read (Coordinate InfiniteLine) where
    readsPrec s = readP_to_S  $
        do void $ char '-'
           i <- readInteger
           void $ char '-'
           return (InfiniteLineC i)
        <++
        do i <- readInteger
           return (InfiniteLineC i)
        where readInteger = readS_to_P (readsPrec s)

-- * Half-infinite lines
data HalfOpenLine :: *

instance Topology HalfOpenLine where
    newtype Coordinate HalfOpenLine = HalfOpenLineC Integer

    neighborhood (HalfOpenLineC 0) = [HalfOpenLineC 1]
    neighborhood (HalfOpenLineC c) = coerce [c-1,c+1]

    sizeMaybe _ = Nothing

    everywhere = coerce ([0, 1 .. ] :: [Integer])

deriving instance Hashable (Coordinate HalfOpenLine)
deriving instance Eq (Coordinate HalfOpenLine)
deriving instance Ord (Coordinate HalfOpenLine)

instance Show (Coordinate HalfOpenLine) where
    show (HalfOpenLineC c) = "|" ++ show c ++ "-"

instance Read (Coordinate HalfOpenLine) where
    readsPrec s = readP_to_S  $
        do void $ char '|'
           i <- readInteger
           void $ char '-'
           return (HalfOpenLineC i)
        <++
        do i <- readInteger
           return (HalfOpenLineC i)
        where readInteger = readS_to_P (readsPrec s)

-- * Line
data Line :: Nat -> *

instance (KnownNat n, 0 <= n) => Topology (Line n) where
    newtype Coordinate (Line n) = LineC Integer

    neighborhood (LineC c) =
        (if c > 0   then [LineC (c-1)] else [])
     ++ (if c < n-1 then [LineC (c+1)] else [])
        where n = fromInteger $ natVal (Proxy::Proxy n)

    sizeMaybe     _ = Just . fromInteger $ natVal (Proxy::Proxy n)

    everywhere = coerce [0, 1 .. n-1 :: Integer]
        where n = fromInteger $ natVal (Proxy::Proxy n)

instance (KnownNat n, 0 <= n) => FiniteTopology (Line n)

deriving instance Hashable (Coordinate (Line n))
deriving instance Eq (Coordinate (Line n))
deriving instance Ord (Coordinate (Line n))

instance Show (Coordinate (Line n)) where
    show (LineC c) = "|" ++ show c ++ "|"

instance Read (Coordinate (Line n)) where
    readsPrec s = readP_to_S $
        do void $ char '|'
           i <- readInteger
           void $ char '|'
           return (LineC i)
        <++
        do i <- readInteger
           return (LineC i)
        where readInteger = readS_to_P (readsPrec s)

instance KnownNat n => Random (Coordinate (Line n)) where
    random g = let (i,g') = randomR (0, n-1) g in (LineC i, g')
        where n = fromInteger $ natVal (Proxy::Proxy n)
    randomR = error "Population.Spatial.Topology.Line.randomR: randomR not defined for this type."

-- * Circle
data Circle :: Nat -> *

instance (KnownNat n, 0 <= n) => Topology (Circle n) where
    newtype Coordinate (Circle n) = CircleC Integer

    neighborhood (CircleC c)
        | n == 1    = []
        | n == 2    = coerce [1-n]
        | c == 0    = coerce [n-1,1]
        | c == n-1  = coerce [n-2,0]
        | otherwise = coerce [c-1,c+1]
        where n = natVal (Proxy::Proxy n)

    sizeMaybe     _ = Just . fromInteger $ natVal (Proxy::Proxy n)

    everywhere = coerce [0, 1 .. n-1 :: Integer]
        where n = fromInteger $ natVal (Proxy::Proxy n)

instance (KnownNat n, 0 <= n) => FiniteTopology (Circle n)

deriving instance Hashable (Coordinate (Circle n))
deriving instance Eq (Coordinate (Circle n))
deriving instance Ord (Coordinate (Circle n))

instance Show (Coordinate (Circle n)) where
    show (CircleC c) = "(" ++ show c ++ ")"

instance Read (Coordinate (Circle n)) where
    readsPrec s = readP_to_S  $
        do void $ char '('
           i <- readInteger
           void $ char ')'
           return (CircleC i)
        <++
        do i <- readInteger
           return (CircleC i)
        where readInteger = readS_to_P (readsPrec s)

instance KnownNat n => Random (Coordinate (Circle n)) where
    random g = let (i,g') = randomR (0, n-1) g in (CircleC i, g')
        where n = fromInteger $ natVal (Proxy::Proxy n)
    randomR = error "Population.Spatial.Topology.Circle.randomR: randomR not defined for this type."

-- * Direct product topologies, Moore neighborhoods.
--   I.e. Neighbors of (x,y) are of the form (x,neighbor y) or (neighbor x,y)
--   or (neighbor x,neighbor y)
data Times :: * -> * -> *

instance (Topology t1, Topology t2) => Topology (t1 `Times` t2) where
    newtype Coordinate (t1 `Times` t2) =
        TimesC (Coordinate t1, Coordinate t2)

    neighborhood (TimesC (c1,c2)) = coerce $
        [ (x1,c2) | x1 <- neighborhood c1 ]
     ++ [ (c1,x2) | x2 <- neighborhood c2 ]
     ++ [ (x1,x2) | x1 <- neighborhood c1 , x2 <- neighborhood c2 ]

    sizeMaybe _ = (*) <$> sizeMaybe (Proxy::Proxy t1) <*> sizeMaybe (Proxy::Proxy t2)

    everywhere = [ TimesC (c1, c2) | c1 <- everywhere, c2 <- everywhere ]

instance (FiniteTopology t1, FiniteTopology t2) => FiniteTopology (t1 `Times` t2)

deriving instance (Topology t1, Topology t2) => Hashable (Coordinate (t1 `Times` t2))
deriving instance (Topology t1, Topology t2) => Eq (Coordinate (t1 `Times` t2))

instance (Show (Coordinate t1), Show (Coordinate t2))
    => Show (Coordinate (t1 `Times` t2)) where
    show (TimesC (c1,c2)) = show c1 ++ " x " ++ show c2

instance (Read (Coordinate t1), Read (Coordinate t2))
    => Read (Coordinate (t1 `Times` t2)) where
    readsPrec s = readP_to_S $
        do c1 <- readS_to_P (readsPrec s)
           void $ string " x " <++ string "x"
           c2 <- readS_to_P (readsPrec s)
           return $ TimesC (c1,c2)

instance (Random (Coordinate t1), Random (Coordinate t2)) => Random (Coordinate (t1 `Times` t2)) where
    random g = let (c1,g') = random g; (c2,g'') = random g' in (TimesC (c1,c2), g'')
    randomR = error "Population.Spatial.Topology.Times.randomR: randomR not defined for this type."

type Torus n m = Circle n `Times` Circle m
type Box   n m = Line n   `Times` Line m
type Cube n m o = Line n `Times` Line m `Times` Line o

-- * Direct product topologies, using von Neumann neighborhoods
--   I.e. Neighbors of (x,y) are of the form (x,neighbor y) or (neighbor x,y)
data Times' :: * -> * -> *

instance (Topology t1, Topology t2) => Topology (t1 `Times'` t2) where
    newtype Coordinate (t1 `Times'` t2) =
        Times'C (Coordinate t1, Coordinate t2)

    neighborhood (Times'C (c1,c2)) = coerce $
        [ (x1,c2) | x1 <- neighborhood c1 ]
     ++ [ (c1,x2) | x2 <- neighborhood c2 ]

    sizeMaybe _ = (*) <$> sizeMaybe (Proxy::Proxy t1) <*> sizeMaybe (Proxy::Proxy t2)

    everywhere = [ Times'C (c1, c2) | c1 <- everywhere, c2 <- everywhere ]

instance (FiniteTopology t1, FiniteTopology t2) => FiniteTopology (t1 `Times'` t2)

deriving instance (Topology t1, Topology t2) => Hashable (Coordinate (t1 `Times'` t2))
deriving instance (Topology t1, Topology t2) => Eq (Coordinate (t1 `Times'` t2))

instance (Show (Coordinate t1), Show (Coordinate t2))
    => Show (Coordinate (t1 `Times'` t2)) where
    show (Times'C (c1,c2)) = show c1 ++ " x " ++ show c2

instance (Read (Coordinate t1), Read (Coordinate t2))
    => Read (Coordinate (t1 `Times'` t2)) where
    readsPrec s = readP_to_S $
        do c1 <- readS_to_P (readsPrec s)
           void $ string " x " <++ string "x"
           c2 <- readS_to_P (readsPrec s)
           return $ Times'C (c1,c2)

instance (Random (Coordinate t1), Random (Coordinate t2)) => Random (Coordinate (t1 `Times'` t2)) where
    random g = let (c1,g') = random g; (c2,g'') = random g' in (Times'C (c1,c2), g'')
    randomR = error "Population.Spatial.Topology.Times'.randomR: randomR not defined for this type."

-- * Direct sum topologies.
data Plus :: * -> * -> *

instance (Topology t1, Topology t2) => Topology (t1 `Plus` t2) where
        newtype Coordinate (t1 `Plus` t2) =
            PlusC (Either (Coordinate t1) (Coordinate t2))

        neighborhood (PlusC (Left c1)) =
            [ PlusC (Left x1)  | x1 <- neighborhood c1 ]
        neighborhood (PlusC (Right c2)) =
            [ PlusC (Right x2) | x2 <- neighborhood c2 ]

        sizeMaybe _ = (+) <$> sizeMaybe (Proxy::Proxy t1) <*> sizeMaybe (Proxy::Proxy t2)

        everywhere = map (PlusC . Left) everywhere ++ map (PlusC . Right) everywhere

instance (FiniteTopology t1, FiniteTopology t2) => FiniteTopology (t1 `Plus` t2)

deriving instance (Topology t1, Topology t2) => Hashable (Coordinate (t1 `Plus` t2))
deriving instance (Topology t1, Topology t2) => Eq (Coordinate (t1 `Plus` t2))

instance (Show (Coordinate t1), Show (Coordinate t2))
    => Show (Coordinate (t1 `Plus` t2)) where
    show (PlusC (Left  c1)) = show c1
    show (PlusC (Right c2)) = show c2

-- | NOTE: Many coordinates cannot be read this way, because the left and right options may be ambiguous.
--   Particularly if t1 and t2 are the same topology.
instance (Read (Coordinate t1), Read (Coordinate t2))
    => Read (Coordinate (t1 `Plus` t2)) where
    readsPrec s = readP_to_S . choice $ [
        PlusC . Left  <$> readS_to_P (readsPrec s)
      , PlusC . Right <$> readS_to_P (readsPrec s)
     ]

instance (Topology t1, Random (Coordinate t1), Topology t2, Random (Coordinate t2)) => Random (Coordinate (t1 `Plus` t2)) where
    random g = flip runState g $ case (sizeMaybe (Proxy::Proxy t1), sizeMaybe (Proxy::Proxy t2)) of
        (Just s1, Just s2) -> choose $ fromIntegral s1 / fromIntegral (s1+s2)
        (Just _, Nothing)  -> right
        (Nothing, Just _)  -> left
        (Nothing, Nothing) -> choose 0.5
        where left = PlusC . Left <$> state random
              right = PlusC . Right <$> state random
              choose (p::Double) = do k <- state random; if k < p then left else right
    randomR = error "Population.Spatial.Topology.Plus.randomR: randomR not defined for this type."
