

module Population.Spatial.Definition
     ( module Population.Spatial.Definition
     , module Population.Trans.Spatial
     ) where

import           Population.Simple
import           Population.Trans.Spatial


type SpatialPop t = SpatialT t SimplePop

-- | Useful to collapse polymorphism in applications.
spatial :: proxy t -> m (SpatialPop t) s o a -> m (SpatialPop t) s o a
spatial = const id
