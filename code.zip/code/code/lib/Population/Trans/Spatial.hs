{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE FlexibleInstances         #-}
{-# LANGUAGE FunctionalDependencies    #-}
{-# LANGUAGE MultiParamTypeClasses     #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE ScopedTypeVariables       #-}

module Population.Trans.Spatial
     ( module Population.Trans.Spatial
     , module Population.Trans
     ) where

import           Control.Monad               (mapM, when, (<=<))
import           Data.HashMap.Strict         (HashMap)
import qualified Data.HashMap.Strict         as M (delete, empty, insert,
                                                   lookup)
import           Data.Maybe                  (catMaybes, fromMaybe, isJust)

import           Population.Definition
import           Population.Spatial.Topology (Coordinate, Topology (..))
import           Population.Trans

-- * Spatial population class.
class (Topology t, Population p o) => PopulationSpatial t p o | p -> t where
    locationMaybe   :: PopulationM m s p o => Pointer s    -> m s p o (Maybe (Coordinate t))
    location        :: PopulationM m s p o => Pointer s    -> m s p o (Coordinate t)
    location p = fromMaybe err <$> locationMaybe p
        where err = error "Population.Trans.Spatial.PopulationSpatial.location: Pointer does not exist."
    inhabitant      :: PopulationM m s p o => Coordinate t -> m s p o (Maybe (Pointer s))
    isFull, isEmpty :: PopulationM m s p o => Coordinate t -> m s p o Bool
    isFull c = not <$> isEmpty c
    isEmpty c = not <$> isFull c

neighbors :: (PopulationM m s p o, PopulationSpatial t p o) => Pointer s -> m s p o [Pointer s]
neighbors  = fmap catMaybes . mapM inhabitant <=< fmap neighborhood . location
neighbors' :: (PopulationSpatial t p o, PopulationM m s p o) => Pointer s -> m s p o [Pointer s]
neighbors' p = (p:) <$> neighbors p

-- * Spatial transformer type
data SpatialT t p o
   = SpatialT
   { pop_lower :: ! (p o)
   , pop_t2p   :: ! (HashMap (Coordinate t) SomePointer)
   , pop_p2t   :: ! (HashMap SomePointer (Coordinate t))
   }

instance PopulationTrans (SpatialT t) where
    unlift = pop_lower

instance (Topology t, Population p o) => Population (SpatialT t p) o where
    empty = SpatialT { pop_lower = empty, pop_t2p = M.empty, pop_p2t = M.empty }
    generation = lift generation
    organismCounter = lift organismCounter
    organismMaybe = lift . organismMaybe
    population = lift population

    nextGeneration =
        do ((),lower') <- liftAction nextGeneration
           modify $ \ pop -> pop { pop_lower = lower' }

    killQuiet p =
        do (r,lower') <- liftAction (killQuiet p)
           when r $ do loc <- location p
                       pop <- grab
                       flip point p $ \ p' -> put $ SpatialT
                           { pop_t2p = loc `M.delete` pop_t2p pop
                           , pop_p2t = p' `M.delete` pop_p2t pop
                           , pop_lower = lower'
                           }
           return r

instance (Topology t, Population p o) => PopulationSpatial t (SpatialT t p) o where
    locationMaybe = point $ \ p -> M.lookup p . pop_p2t <$> grab
    inhabitant l = M.lookup l . pop_t2p <$> grab >>= mapM specialize
    isFull l = isJust <$> inhabitant l

instance (Topology t, Addable p o x) => Addable (SpatialT t p) o (Coordinate t, x) where
    add (loc, x) =
        do full <- isFull loc; if full
           then return Nothing
           else do (pm, lower') <- liftAction (add x); case pm of
                       Nothing -> return Nothing
                       Just p  -> do flip point p $ \ p' -> modify $ \ pop -> pop
                                         { pop_t2p = M.insert loc p' $ pop_t2p pop
                                         , pop_p2t = M.insert p' loc $ pop_p2t pop
                                         , pop_lower = lower' }
                                     return $ Just p
