{-# LANGUAGE ConstraintKinds           #-}
{-# LANGUAGE DefaultSignatures         #-}
{-# LANGUAGE FlexibleContexts          #-}
{-# LANGUAGE FlexibleInstances         #-}
{-# LANGUAGE FunctionalDependencies    #-}
{-# LANGUAGE MultiParamTypeClasses     #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE ScopedTypeVariables       #-}

module Population.Trans.AttachTag
     ( module Population.Trans.AttachTag
     , module Population.Trans
     ) where

import           Data.Proxy

import           Population.Trans

class Population p o => PopulationAttachTag tag a p o | tag p -> a where
    readTag   :: PopulationM m s p o => proxy tag -> m s p o (Maybe a)
    writeTag  :: proxy tag -> a -> Action s p o ()
    removeTag :: proxy tag -> Action s p o ()

    default readTag :: (PopulationAttachTag tag a p o, PopulationTrans t, PopulationM m s (t p) o) => proxy tag -> m s (t p) o (Maybe a)
    readTag proxy = lift (readTag proxy)

data AttachT tag a p o
   = AttachT
   { pop_writeTagment :: Maybe a
   , pop_lower        :: p o
   }

instance PopulationTrans (AttachT tag a) where
    unlift = pop_lower

instance Population p o => Population (AttachT tag a p) o where
    empty = AttachT Nothing empty
    generation = lift generation
    organismCounter = lift organismCounter
    organismMaybe = lift . organismMaybe
    population = lift population

    nextGeneration =
        do ((),lower') <- liftAction nextGeneration
           modify $ \ pop -> pop { pop_lower = lower' }

    killQuiet p =
        do (r,lower') <- liftAction (killQuiet p)
           modify $ \ pop -> pop { pop_lower = lower' }
           return r

instance Population p o => PopulationAttachTag tag a (AttachT tag a p) o where
    readTag _ = pop_writeTagment <$> grab
    writeTag _ a = modify $ \ pop -> pop { pop_writeTagment = Just a }
    removeTag _ = modify $ \ pop -> pop { pop_writeTagment = Nothing }

instance Addable p o x => Addable (AttachT tag a p) o x where
    add x = do (r,lower') <- liftAction (add x)
               modify $ \ pop -> pop { pop_lower = lower' }
               return r

data SimpleTag
type PopulationAttach = PopulationAttachTag SimpleTag
readAttached :: (PopulationM m s p o, PopulationAttach a p o) => m s p o (Maybe a)
readAttached = readTag (Proxy::Proxy SimpleTag)
writeAttached :: PopulationAttach a p o => a -> Action s p o ()
writeAttached = writeTag (Proxy::Proxy SimpleTag)
removeAttached :: PopulationAttach a p o => Action s p o ()
removeAttached = removeTag (Proxy::Proxy SimpleTag)
