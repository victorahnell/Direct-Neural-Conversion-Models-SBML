{-# LANGUAGE DataKinds             #-}
{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE GADTs                 #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE PolyKinds             #-}
{-# LANGUAGE RankNTypes            #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TypeFamilies          #-}

module Genome.Binary.Definition
     ( BinaryGenome
     , NatList (..)
     , Head, Concat
     , BinGenes (headbits, headbytes, totalbits, totalbytes, bytestring, index)
     , genomehead, genometail, genomeheadtail
     , genomecons, genomeconcat, genomesplit
     ) where

import           Control.Monad.State
import           Data.Bits
import qualified Data.ByteString              as B
import           Data.Function                (on)
import           Data.Maybe
import           Data.Proxy                   (Proxy (..))
import           Data.Word
import           Genome.Split
import           GHC.TypeLits
import           System.Random
import           Text.ParserCombinators.ReadP
import           Utility.Binary
import Data.Coerce

-- The binary genomes in this module represent a concatenation of genes,
-- each represented by a finite sequence of bits.
-- The genome is implemented as a ByteString. The lengths of the
-- constituent genes is represented at the type level by a phantom argument,
-- and has no runtime representation.
-- The phantom argument is a NatList. Some type families are needed to
-- annotate certain functions.

-- Implementation restrictions: The ByteString of a binary genome must
-- contain for each gene the required number of bytes. If there are bits left
-- over (i.e. the length of the gene is not divisible by 8), the remaining
-- bits in the bytestring must be zero. When the genome has several genes,
-- their byte representations are concatenated.
-- BinGenes (Cons 3 (Single 5)) is represented by a bytestring
-- xxxxx000-xxx00000, not xxxxxxxx.

newtype BinaryGenome (l :: NatList) = MkBinaryGenome B.ByteString

data NatList where
    Single :: Nat -> NatList
    Cons   :: Nat -> NatList -> NatList
infixr 8 `Cons`

type family Head (l :: NatList) :: Nat where
    Head (Single n)    = n
    Head (Cons n list) = n

type family Concat (a :: NatList) (b :: NatList) :: NatList where
    Concat (Single n) list = Cons n list
    Concat (Cons n l) list = Cons n (Concat l list)

-- Because the implementation depends on Nat, using a binary genome requires
-- KnownNat instances in order to be useful. The BinGenes class is
-- used to encapsulate this Constraint for both Single and Cons genomes.

-- In addition, some classes need different implementations for Cons and
-- Single genomes. However, providing separate instances will not allow the
-- Haskell type system to infer that in fact all binary genomes (with sound
-- KnownNat instances) are members of that typeclass. By moving the functions
-- that need different implementations for Single and Cons to the
-- BinGenes class, the typeclass that needs these functions can be
-- implemented as (BinGenes b => myclass (BinaryGenome b)), covering all
-- binary genomes (with KnownNats).

class BinGenes b where
    headbits :: Proxy b -> Int
    headbytes :: Proxy b -> Int
    headbytes n = (headbits n - 1) `quot` 8 + 1
    totalbits :: Proxy b -> Int
    totalbytes :: Proxy b -> Int
    bytestring :: BinaryGenome b -> B.ByteString
    bytestring = coerce

    -- From a given bit index 0-totalbits, get the index of the (byte,bit) on the ByteString.
    index :: Int -> Proxy b -> (Int,Int)

    -- Specialized helper functions with different implementations for Cons and Single.
    specialized_show :: BinaryGenome b -> String
    specialized_read :: ReadP (BinaryGenome b)
    specialized_random :: RandomGen rg => Proxy b -> State rg [Word8]

instance KnownNat n => BinGenes (Single n) where
    headbits = totalbits
    totalbits _ = (fromInteger . natVal) (Proxy::Proxy n)
    totalbytes = headbytes

    index i _ =
        if i <  0   then error "BinGenes.index: Index smaller than zero." else
        if i >= len then error "BinGenes.index: Index larger than genome size." else
            i `quotRem` 8
            where len = totalbits (Proxy::Proxy (Single n))

    specialized_show b =
        '-' : showbits ++ "-"
        where showbits = concatMap (show . fromEnum . testBit b) [0..headbits (Proxy::Proxy (Single n)) - 1]

    specialized_read =
        do optionalPref (char '-')
           thebits <- count bits $ choice [char '0', char '1']
           optionalPref (char '-')
           return . fromBits . map char2bool $ thebits
        where optionalPref x = x <++ return undefined
              bits = totalbits (Proxy::Proxy (Single n))
              char2bool '0' = False
              char2bool '1' = True
              char2bool _ = error "Genome.Binary.read: Expected character 0 or 1."

    specialized_random _ =
        case bits `quotRem` 8 of
            (q,0) -> replicateM q (state random)
            (q,r) -> do a <- replicateM q (state random)
                        b <- state (randomR (0,2^r))
                        return $ a ++ [b]
        where bits = totalbits (Proxy::Proxy (Single n))

instance (KnownNat n, BinGenes l) => BinGenes (Cons n l) where
    headbits   _ = totalbits (Proxy::Proxy (Single n))
    totalbits  a = headbits  a + totalbits  (Proxy::Proxy l)
    totalbytes a = headbytes a + totalbytes (Proxy::Proxy l)

    index i _ =
        if i <  0   then error "BinGenes.index: Index smaller than zero." else
            if   i >= bits
            then let (q,r) = index (i-bits) (Proxy::Proxy l) in (bytes + q,r)
            else i `quotRem` 8
            where bits  = headbits  (Proxy::Proxy (Cons n l))
                  bytes = headbytes (Proxy::Proxy (Cons n l))

    specialized_show b =
        '-' : showbits ++ show (genometail b)
        where showbits = concatMap (show . fromEnum . testBit b) [0..headbits (Proxy::Proxy (Cons n l)) - 1]

    specialized_read =
        do thehead <- specialized_read
           therest <- specialized_read
           return $ genomecons thehead therest

    specialized_random _ =
        do a <- specialized_random (Proxy::Proxy (Single n))
           b <- specialized_random (Proxy::Proxy l)
           return $ a ++ b

instance BinGenes b => Eq (BinaryGenome b) where
    (==) = (==) `on` bytestring

instance BinGenes b => Show (BinaryGenome b) where
    show = specialized_show

instance BinGenes b => Bits (BinaryGenome b) where
    (.&.) a b = coerce . B.pack $ B.zipWith (.&.) (coerce a) (coerce b)
    (.|.) a b = coerce . B.pack $ B.zipWith (.|.) (coerce a) (coerce b)
    (xor) a b = coerce . B.pack $ B.zipWith (xor) (coerce a) (coerce b)

    complement = coerce . B.map complement . coerce

    bitSize = fromJust . bitSizeMaybe
    bitSizeMaybe _ = (Just . totalbits) (Proxy::Proxy b)

    popCount = B.foldl' (\ n w -> n + popCount w) 0 . coerce

    testBit b i =
        coerce b `B.index` q `testBit` r
        where (q,r) = index i (Proxy::Proxy b)
              len   = totalbits (Proxy::Proxy b)

    zeroBits =
        coerce $ B.replicate bytes 0
        where bytes = totalbytes (Proxy::Proxy b)

    bit i =
        coerce $ (B.replicate q 0 `B.snoc` bit r)
                 `B.append` B.replicate (bytes-q-1) 0
        where (q,r) = index i (Proxy::Proxy b)
              bytes = totalbytes (Proxy::Proxy b)

    shift = error "BinGenes.shift: Not yet implemented."
    rotate = error "BinGenes.rotate: Not yet implemented."

    isSigned = error "BinGenes.isSigned: Not meaningful."

instance BinGenes b => FiniteBits (BinaryGenome b) where
    finiteBitSize _ = totalbits (Proxy::Proxy b)

instance BinGenes b => Random (BinaryGenome b) where
    random g = flip runState g $ coerce . B.pack <$> specialized_random (Proxy::Proxy b)
    randomR = error "BinGenes.randomR: Not meaningful."

instance BinGenes b => Read (BinaryGenome b) where
    readsPrec _ = readP_to_S specialized_read

-- * These functions allow the genome to be reshaped by removing and adding genes.

genomehead :: forall l. BinGenes l => BinaryGenome l -> BinaryGenome (Single (Head l))
genomehead = coerce . B.take n . coerce
    where n = headbytes (Proxy::Proxy l)

genometail :: forall n l. (BinGenes (Cons n l)) => BinaryGenome (Cons n l) -> BinaryGenome l
genometail = coerce . B.drop n . coerce
    where n = headbytes (Proxy::Proxy (Cons n l))

genomeheadtail :: forall n l. BinGenes (Cons n l) => BinaryGenome (Cons n l) -> (BinaryGenome (Single n), BinaryGenome l)
genomeheadtail = coerce . B.splitAt n . coerce
    where n = headbytes (Proxy::Proxy (Cons n l))

genomecons :: forall n l. (BinGenes (Single n), BinGenes l) => BinaryGenome (Single n) -> BinaryGenome l -> BinaryGenome (Cons n l)
genomecons = genomeconcat

genomeconcat :: forall l l'. (BinGenes l, BinGenes l') => BinaryGenome l -> BinaryGenome l' -> BinaryGenome (Concat l l')
genomeconcat b b' = coerce $ coerce b `B.append` coerce b'

genomesplit :: forall l l'. BinGenes l => BinaryGenome (Concat l l') -> (BinaryGenome l, BinaryGenome l')
genomesplit = coerce . B.splitAt n . coerce
    where n = totalbytes (Proxy::Proxy l)

instance BinGenes l => Split (BinaryGenome l) (BinaryGenome l') where
    type Unsplit (BinaryGenome l) (BinaryGenome l') = BinaryGenome (Concat l l')
    split = genomesplit

instance BinGenes l => Split () (BinaryGenome l) where
    type Unsplit () (BinaryGenome l) = BinaryGenome l
    split g = ((),g)

instance BinGenes l => Split (BinaryGenome l) () where
    type Unsplit (BinaryGenome l) () = BinaryGenome l
    split g = (g,())
