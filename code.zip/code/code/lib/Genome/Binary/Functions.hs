{-# LANGUAGE BangPatterns        #-}
{-# LANGUAGE DataKinds           #-}
{-# LANGUAGE FlexibleInstances   #-}
{-# LANGUAGE GADTs               #-}
{-# LANGUAGE KindSignatures      #-}
{-# LANGUAGE MagicHash           #-}
{-# LANGUAGE RankNTypes          #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE TypeFamilies        #-}
{-# LANGUAGE TypeOperators       #-}
{-# LANGUAGE UnboxedTuples       #-}

module Genome.Binary.Functions
     ( module Genome.Binary.Functions
     ) where

import           Control.Monad
import           Control.Monad.Random     hiding (split)
import           Data.Binary
import           Data.Binary.Get
import           Data.Binary.IEEE754
import           Data.Bits
import qualified Data.ByteString          as B
import qualified Data.ByteString.Lazy     as L
import           Data.Int                 (Int16, Int32, Int64, Int8)
import           Data.List                (foldl')
import           Data.Proxy
import           GHC.TypeLits
import           Unsafe.Coerce

import           Genome.Binary.Definition
import           Genome.Split
import           Utility.Distribution     (poissonM)
import           Utility.Random           (randomround)

-- * Mutation settings
flip1 :: (MonadRandom m, FiniteBits g) => g -> m g
flip1 g = complementBit g <$> getRandomR (0, finiteBitSize g - 1)

flipn :: (MonadRandom m, FiniteBits g) => Int -> g -> m g
flipn n g = foldl (>>=) (return g) $ replicate n flip1

flipR :: (MonadRandom m, FiniteBits g) => m Int -> g -> m g
flipR r g = r >>= flip flipn g

flipn' :: (MonadRandom m, FiniteBits g) => Double -> g -> m g
flipn' n = flipR (randomround n)

flipR' :: (FiniteBits g, MonadRandom m) => m Double -> g -> m g
flipR' r g = flipR (r >>= randomround) g

flipPoisson :: (MonadRandom m, FiniteBits g) => Double -> g -> m g
flipPoisson lambda = flipR (poissonM lambda)

-- * GP maps
{-# INLINABLE base       #-}
{-# INLINABLE int64_base #-}
{-# INLINABLE int32_base #-}
{-# INLINABLE int16_base #-}
{-# INLINABLE int8_base  #-}
{-# INLINABLE word64_base #-}
{-# INLINABLE word32_base #-}
{-# INLINABLE word16_base #-}
{-# INLINABLE word8_base  #-}
-- | Decode a POSITIVE integer using base code.
base :: forall n. KnownNat n => BinaryGenome (Single n) -> Integer
base a = case natVal (Proxy::Proxy n) of
    8   -> toInteger . runGet getWord8    . L.fromStrict . bytestring $ a
    16  -> toInteger . runGet getWord16le . L.fromStrict . bytestring $ a
    32  -> toInteger . runGet getWord32le . L.fromStrict . bytestring $ a
    64  -> toInteger . runGet getWord64le . L.fromStrict . bytestring $ a
    len -> let ints = runGet (replicateM (fromInteger ((len-1) `quot` 64 + 1)) getInt64le) $ (`L.append` L.repeat 0) . L.fromStrict . bytestring $ a
           in foldl' (\ x i -> shiftL x 64 `xor` toInteger i) 0 (reverse ints)
    --
    -- len | len <= 16 -> toInteger . runGet getInt16le . (`L.append` L.repeat 0) . L.fromStrict . bits $ a
    --     | len <= 32 -> toInteger . runGet getInt32le . (`L.append` L.repeat 0) . L.fromStrict . bits $ a
    --     | len <= 64 -> toInteger . runGet getInt64le . (`L.append` L.repeat 0) . L.fromStrict . bits $ a
    --     | otherwise -> let ints = runGet (replicateM (fromInteger ((len-1) `quot` 64 + 1)) getInt64le) $ (`L.append` L.repeat 0) . L.fromStrict . bits $ a
    --                    in foldl' (\ x i -> shiftL x 64 `xor` toInteger i) 0 (reverse ints)

int64_base :: BinaryGenome (Single 64) -> Int64
int64_base = runGet getInt64le . L.fromStrict . bytestring

int32_base :: BinaryGenome (Single 32) -> Int32
int32_base = runGet getInt32le . L.fromStrict . bytestring

int16_base :: BinaryGenome (Single 16) -> Int16
int16_base = runGet getInt16le . L.fromStrict . bytestring

int8_base  :: BinaryGenome (Single 8)  -> Int8
int8_base  = runGet getInt8 . L.fromStrict . bytestring

word64_base :: BinaryGenome (Single 64) -> Word64
word64_base = runGet getWord64le . L.fromStrict . bytestring

word32_base :: BinaryGenome (Single 32) -> Word32
word32_base = runGet getWord32le . L.fromStrict . bytestring

word16_base :: BinaryGenome (Single 16) -> Word16
word16_base = runGet getWord16le . L.fromStrict . bytestring

word8_base  :: BinaryGenome (Single 8)  -> Word8
word8_base  = runGet getWord8 . L.fromStrict . bytestring



{-# INLINABLE gray       #-}
{-# INLINABLE word64_gray #-}
{-# INLINABLE word32_gray #-}
{-# INLINABLE word16_gray #-}
{-# INLINABLE word8_gray  #-}
-- | Decode a POSITIVE integer using Gray code.
gray :: forall n. KnownNat n => BinaryGenome (Single n) -> Integer
gray a = foldl' go (base a) [0 .. shifts]
    where go !x !i = x `xor` shiftR x (2^i)
          len      = natVal (Proxy::Proxy n)
          shifts   = floor . logBase 2 . fromIntegral $ len-1

word64_gray :: BinaryGenome (Single 64) -> Word64
word64_gray = fromIntegral . gray

word32_gray :: BinaryGenome (Single 32) -> Word32
word32_gray = fromIntegral . gray

word16_gray :: BinaryGenome (Single 16) -> Word16
word16_gray = fromIntegral . gray

word8_gray :: BinaryGenome (Single 8)   -> Word8
word8_gray = fromIntegral . gray

int64_gray :: BinaryGenome (Single 64) -> Int64
int64_gray = (\ x -> if x<0 then (minBound::Int64)-x else x) . fromIntegral . word64_gray

int32_gray :: BinaryGenome (Single 32) -> Int32
int32_gray = (\ x -> if x<0 then (minBound::Int32)-x else x) . fromIntegral . word32_gray

int16_gray :: BinaryGenome (Single 16) -> Int16
int16_gray = (\ x -> if x<0 then (minBound::Int16)-x else x) . fromIntegral . word16_gray

int8_gray :: BinaryGenome (Single 8) -> Int8
int8_gray = (\ x -> if x<0 then (minBound::Int8)-x else x) . fromIntegral . word8_gray



{-# INLINABLE bool #-}
bool :: BinaryGenome (Single 1) -> Bool
bool = flip testBit 0 . B.head . bytestring



{-# INLINABLE double_ieee #-}
double_ieee :: BinaryGenome (Single 64) -> Double
double_ieee = runGet getFloat64le . L.fromStrict . bytestring


-- | Decodes a POSITIVE double from a BinaryGenome, reading the significand and exponent using Gray code.
{-# INLINABLE double_base #-}
double_base :: BinaryGenome (Cons 32 (Single 8)) -> Double
double_base g =
    let ( g1 , g2 ) = split g
    in encodeFloat (base g1) (fromIntegral (int8_base g2))

-- | Decodes a POSITIVE double from a BinaryGenome, reading the significand and exponent using Gray code.
{-# INLINABLE double_gray #-}
double_gray :: BinaryGenome (Cons 32 (Single 8)) -> Double
double_gray g =
    let ( g1 , g2 ) = split g
    in encodeFloat (gray g1) (fromIntegral (int8_gray g2))

{-# INLINABLE signed #-}
signed :: Num a => (BinaryGenome list -> a) -> BinaryGenome (Cons 1 list) -> a
signed f g =
    let ( g1 , g2 ) = split g
        y = f g2
    in if bool g1 then -y else y

{-# INLINABLE crossover_uniformbytes #-}
crossover_uniformbytes :: (BinGenes b, MonadRandom m) => BinaryGenome b -> BinaryGenome b -> m (BinaryGenome b)
crossover_uniformbytes x y =
    do let a   = bytestring x
           b   = bytestring y
           len = min (B.length a) (B.length b)
       r <- getRandomR (0,len)
       return $ unsafeCoerce $ B.take r a `B.append` B.drop r b


hammingDistance :: Bits a => a -> a -> Int
hammingDistance a b = popCount $ a `xor` b
