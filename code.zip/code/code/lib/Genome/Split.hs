{-# LANGUAGE FlexibleInstances      #-}
{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE MultiParamTypeClasses  #-}
{-# LANGUAGE TemplateHaskell        #-}
{-# LANGUAGE TypeFamilies           #-}

module Genome.Split
     ( Split (..)
     ) where

class Split a b where
    type Unsplit a b
    split :: Unsplit a b -> (a, b)

instance Split () () where
    type Unsplit () () = ()
    split () = ((),())
