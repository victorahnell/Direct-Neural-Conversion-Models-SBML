
module Genome.Single.Double
     ( module Genome.Single.Double
     ) where

import Control.Monad.Random

mutationProbability :: MonadRandom m => Double -> (a -> m a) -> a -> m a
mutationProbability p f = mutationOr p f return

mutationAnd :: MonadRandom m => (a -> m a) -> (a -> m a) -> a -> m a
mutationAnd = (>=>)

mutationOr :: MonadRandom m => Double -> (a -> m a) -> (a -> m a) -> a -> m a
mutationOr p f g x=
    do r <- getRandomR (0,1)
       if r < p
       then f x
       else g x

randomJoin :: MonadRandom m => (a -> b -> a) -> m b -> a -> m a
randomJoin f m x = f x <$> m

gaussian :: (Floating a, Random a, MonadRandom m) => a -> a -> m a
gaussian sigma mu =
    do s <- sum <$> take 12 <$> getRandoms
       return $ sigma * (s - 6) + mu

plusNormal :: (Random a, Floating a, MonadRandom m) => a -> a -> m a
plusNormal sigma = randomJoin (+) (gaussian sigma 0)

timesLogNormal :: (Random a, Floating a, MonadRandom m) => a -> a -> m a
timesLogNormal sigma = randomJoin (*) (exp <$> gaussian sigma 0)
