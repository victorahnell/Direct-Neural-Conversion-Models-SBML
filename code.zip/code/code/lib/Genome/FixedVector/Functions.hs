{-# LANGUAGE DataKinds           #-}
{-# LANGUAGE FlexibleInstances   #-}
{-# LANGUAGE RankNTypes          #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Genome.FixedVector.Functions
     ( module Genome.FixedVector.Functions
     ) where

import           Control.Monad.Random
import           Data.Int
import qualified Data.Vector.Unboxed           as V
import           Data.Word
import           GHC.TypeLits

import           Genome.FixedVector.Definition
import qualified Genome.List.Functions         as ListGenome (crossover_uniform)
import           Utility

-- * Mutation

-- | Mutate 1 random index in the fixed genome.
mutate1 :: (KnownNat len, V.Unbox a, MonadRandom m) => (a -> m a) -> FixedVector len a -> m (FixedVector len a)
mutate1 mutate vec =
    do i <- getRandomR (0, ixLength vec - 1)
       e <- mutate $ vec ! i
       return . unsafeIndexed $ toVector vec V.// [(i,e)]

-- | Mutate n random indexes (drawn with replacement) from the genome.
mutaten :: (KnownNat len, V.Unbox a, MonadRandom m) => Int -> (a -> m a) -> FixedVector len a -> m (FixedVector len a)
mutaten n mutate | n < 0 = error "Genome.FixedVector.Functions.mutaten: Cannot mutate negative number of list elements."
mutaten 0 mutate = return
mutaten 1 mutate = mutate1 mutate
mutaten n mutate = mutate1 mutate >=> mutaten (n-1) mutate

-- | Mutate n random indices (drawn with replacement), where n is a random number.
mutateDist :: (KnownNat len, V.Unbox a, MonadRandom m) => m Int -> (a -> m a) -> FixedVector len a -> m (FixedVector len a)
mutateDist rand mutate vec = do n <- rand; mutaten n mutate vec

-- | Mutate each of the genome elements according to the given mutation function.
mutateEach :: (KnownNat len, V.Unbox a, MonadRandom m) => (a -> m a) -> FixedVector len a -> m (FixedVector len a)
mutateEach = ixMapM

-- * Crossover

-- | Uniform crossover.
--   Exchange genes randomly between two parent genomes.
crossover_uniform :: (MonadRandom m, V.Unbox a, KnownNat len) => FixedVector len a -> FixedVector len a -> m (FixedVector len a)
crossover_uniform = fmap to `owl` ListGenome.crossover_uniform `on` from
    where to = unsafeIndexed . V.fromList
          from = V.toList . toVector

-- | Combo crossover.
--   Child genes are computed from parent genes as k*p1 + (1-k)*p2.
--   Typical ways to compute k include getRandom (0,1), or normal 0.5 0.5
crossover_combo :: forall m a len. (MonadRandom m, V.Unbox a, KnownNat len, Num a) => m a -> FixedVector len a -> FixedVector len a -> m (FixedVector len a)
crossover_combo randk p1 p2 =
    do k <- ixReplicateM randk :: m (FixedVector len a)
       return $ ixZipWith3 combo k p1 p2
    where combo p a b = p*a + (1-p)*b

-- * Extraction
--   Type-specific versions of getVal.

bool :: FixedVector 1 Bool -> Bool
bool = getVal

double :: FixedVector 1 Double -> Double
double = getVal

word64 :: FixedVector 1 Word64 -> Word64
word64 = getVal
word32 :: FixedVector 1 Word32 -> Word32
word32 = getVal
word16 :: FixedVector 1 Word16 -> Word16
word16 = getVal
word8 :: FixedVector 1 Word8 -> Word8
word8 = getVal

int :: FixedVector 1 Int -> Int
int = getVal
int64 :: FixedVector 1 Int64 -> Int64
int64 = getVal
int32 :: FixedVector 1 Int32 -> Int32
int32 = getVal
int16 :: FixedVector 1 Int16 -> Int16
int16 = getVal
int8 :: FixedVector 1 Int8 -> Int8
int8 = getVal
