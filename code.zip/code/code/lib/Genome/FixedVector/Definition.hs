{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE PolyKinds             #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TypeFamilies          #-}
{-# LANGUAGE TypeOperators         #-}
{-# LANGUAGE TypeSynonymInstances  #-}


module Genome.FixedVector.Definition
     ( module Genome.FixedVector.Definition
     , module Data.Fixed.Vector
     ) where

import           Data.Proxy
import qualified Data.Vector.Unboxed as V
import           GHC.TypeLits

import           Data.Fixed.Vector
import           Genome.Split

instance (KnownNat len, KnownNat len', KnownNat (len + len'), V.Unbox a) => Split (FixedVector len a) (FixedVector len' a) where
    type Unsplit (FixedVector len a) (FixedVector len' a) = (FixedVector (len + len') a)
    split fvec = (indexed xs1, indexed xs2)
        where len = fromInteger $ natVal (Proxy::Proxy len)
              (xs1, xs2) = V.splitAt len . toVector $ fvec

instance Split (FixedVector len a) () where
    type Unsplit (FixedVector len a) () = FixedVector len a
    split xs = (xs,())

instance Split () (FixedVector len a) where
    type Unsplit () (FixedVector len a) = FixedVector len a
    split xs = ((),xs)
