
module Genome.Tuple
     ( module Genome.Tuple.Definition
     , module Genome.Split
     ) where

import           Genome.Tuple.Definition
import Genome.Split
