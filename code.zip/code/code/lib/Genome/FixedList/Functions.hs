{-# LANGUAGE DataKinds         #-}
{-# LANGUAGE FlexibleInstances #-}

module Genome.FixedList.Functions
     ( module Genome.FixedList.Functions
     ) where

import           Control.Monad.Random
import           Data.Int
import           Data.Word
import           GHC.TypeLits

import           Genome.FixedList.Definition
import qualified Genome.List.Functions       as ListGenome (crossover_uniform)
import           Utility

-- * Mutation

-- | Mutate 1 random index in the fixed genome.
mutate1 :: (KnownNat len, MonadRandom m) => (a -> m a) -> FixedList len a -> m (FixedList len a)
mutate1 mutate vec =
    do i <- getRandomR (0, length vec - 1)
       let (begin,this:end) = splitAt i $ toList vec
       this' <- mutate this
       return . unsafeIndexed $ begin ++ this : end

-- | Mutate n random indexes (drawn with replacement) from the genome.
mutaten :: (KnownNat len, MonadRandom m) => Int -> (a -> m a) -> FixedList len a -> m (FixedList len a)
mutaten n mutate | n < 0 = error "Genome.FixedList.Functions.mutaten: Cannot mutate negative number of list elements."
mutaten 0 mutate = return
mutaten 1 mutate = mutate1 mutate
mutaten n mutate = mutate1 mutate >=> mutaten (n-1) mutate

-- | Mutate n random indices (drawn with replacement), where n is a random number.
mutateDist :: (KnownNat len, MonadRandom m) => m Int -> (a -> m a) -> FixedList len a -> m (FixedList len a)
mutateDist rand mutate vec = do n <- rand; mutaten n mutate vec

-- | Mutate each of the genome elements according to the given mutation function.
mutateEach :: (KnownNat len, MonadRandom m) => (a -> m a) -> FixedList len a -> m (FixedList len a)
mutateEach = ixMapM

-- * Crossover

-- | Uniform crossover.
--   Exchange genes randomly between two parent genomes.
crossover_uniform :: (KnownNat len, MonadRandom m) => FixedList len a -> FixedList len a -> m (FixedList len a)
crossover_uniform = fmap to `owl` ListGenome.crossover_uniform `on` from
    where to = unsafeIndexed
          from = toList

-- * Extraction
--   Type-specific versions of getVal.

bool :: FixedList 1 Bool -> Bool
bool = getVal

double :: FixedList 1 Double -> Double
double = getVal

word64 :: FixedList 1 Word64 -> Word64
word64 = getVal
word32 :: FixedList 1 Word32 -> Word32
word32 = getVal
word16 :: FixedList 1 Word16 -> Word16
word16 = getVal
word8 :: FixedList 1 Word8 -> Word8
word8 = getVal

integer :: FixedList 1 Integer -> Integer
integer = getVal
int :: FixedList 1 Int -> Int
int = getVal
int64 :: FixedList 1 Int64 -> Int64
int64 = getVal
int32 :: FixedList 1 Int32 -> Int32
int32 = getVal
int16 :: FixedList 1 Int16 -> Int16
int16 = getVal
int8 :: FixedList 1 Int8 -> Int8
int8 = getVal
