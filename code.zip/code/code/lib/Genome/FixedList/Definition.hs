{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE PolyKinds             #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TypeFamilies          #-}
{-# LANGUAGE TypeOperators         #-}
{-# LANGUAGE TypeSynonymInstances  #-}

module Genome.FixedList.Definition
     ( module Genome.FixedList.Definition
     , module Data.Fixed.List
     ) where

import           Data.Fixed.List
import           Data.Proxy
import           Genome.Split
import           GHC.TypeLits

instance (KnownNat len, KnownNat len', KnownNat (len + len')) => Split (FixedList len a) (FixedList len' a) where
    type Unsplit (FixedList len a) (FixedList len' a) = FixedList (len + len') a
    split flst = (indexed xs1, indexed xs2)
        where len = fromInteger $ natVal (Proxy::Proxy len)
              (xs1, xs2) = splitAt len . toList $ flst

instance Split (FixedList len a) () where
    type Unsplit (FixedList len a) () = FixedList len a
    split xs = (xs,())

instance Split () (FixedList len a) where
    type Unsplit () (FixedList len a) = FixedList len a
    split xs = ((),xs)

-- import           Control.Monad
-- import           Data.Foldable
-- import           Data.Proxy
-- import           GHC.TypeLits
-- import           Text.ParserCombinators.ReadP
--
-- import           Genome.Split
--
-- newtype FixedList (len :: Nat) (a :: *) = FixedList [a]
--     deriving (Functor, Traversable, Show, Eq)
--
-- instance KnownNat len => Foldable (FixedList len) where
--     foldMap f (FixedList lst) = foldMap f lst
--     foldr f x (FixedList lst) = foldr f x lst
--     toList (FixedList lst) = lst
--     length (FixedList lst) = fromInteger (natVal (Proxy::Proxy len))
--
-- instance (KnownNat len, Read a) => Read (FixedList len a) where
--     readsPrec s = readP_to_S $
--         do optional $ string "FixedList "
--            fixedList <$> readS_to_P (readsPrec s :: ReadS [a])
--
-- -- | Create a new FixedList of some length.
-- --   If the given list does not have the right length, an error is produced.
-- --   See fixedList' for a version that truncates the list if needed.
-- fixedList :: forall len a t. (Foldable t, KnownNat len) => t a -> FixedList len a
-- fixedList lst =
--     if length lst == len
--     then FixedList . toList $ lst
--     else error "Genome.FixedList.Definition.fixedList: Argument does not have the right length."
--     where len = fromInteger (natVal (Proxy::Proxy len))
--
-- fixedList' :: forall len a t. (Foldable t, KnownNat len) => t a -> FixedList len a
-- fixedList' lst =
--     if length lst' == len
--     then FixedList lst'
--     else error "Genome.FixedList.Definition.fixedList': Argument is too short to create a fixed list of the given length."
--     where len = fromInteger (natVal (Proxy::Proxy len))
--           lst' = take len . toList $ lst
--
-- fixedListM :: forall len a m. (KnownNat len, Monad m) => m a -> m (FixedList len a)
-- fixedListM m =
--     FixedList <$> replicateM len m
--     where len = fromInteger (natVal (Proxy::Proxy len))
--
-- getVal :: FixedList 1 a -> a
-- getVal (FixedList [x]) = x
-- getVal (FixedList _) = error "Genome.FixedList.Functions.getVal: FixedList lied about being length 1."
--
-- instance KnownNat len => Split (FixedList len a) (FixedList len' a) where
--     type Unsplit (FixedList len a) (FixedList len' a) = (FixedList (len + len') a)
--     split (FixedList xs) = let len = fromInteger (natVal (Proxy::Proxy len))
--                                (xs1, xs2) = splitAt len xs
--                            in (FixedList xs1, FixedList xs2)
--
-- instance Split (FixedList len a) () where
--     type Unsplit (FixedList len a) () = FixedList len a
--     split xs = (xs,())
--
-- instance Split () (FixedList len a) where
--     type Unsplit () (FixedList len a) = FixedList len a
--     split xs = ((),xs)
--
--
-- -- | Essentially Identity Monad.
-- instance Applicative (FixedList 1) where
--     pure = return
--     (<*>) = ap
--
-- instance Monad (FixedList 1) where
--     return x = FixedList [x]
--     (FixedList [x]) >>= f = f x
--     (FixedList _) >>= _ = error "Genome.FixedList.Definition.Monad.>>=: FixedList 1 lied about its length."
