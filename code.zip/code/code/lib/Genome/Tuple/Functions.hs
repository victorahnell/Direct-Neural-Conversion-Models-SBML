
module Genome.Tuple.Functions
     ( module Genome.Tuple.Functions
     ) where

import           Data.Int
import           Data.Word

import           Genome.Tuple.Definition
import           Utility


bool :: Gene Bool -> Bool
bool = readGene

double :: Gene Double -> Double
double = readGene

double01 = (\ k -> k / (1 + k)) . double

word64 :: Gene Word64 -> Word64
word64 = readGene
word32 :: Gene Word32 -> Word32
word32 = readGene
word16 :: Gene Word16 -> Word16
word16 = readGene
word8 :: Gene Word8 -> Word8
word8 = readGene

integer :: Gene Integer -> Integer
integer = readGene
int :: Gene Int -> Int
int = readGene
int64 :: Gene Int64 -> Int64
int64 = readGene
int32 :: Gene Int32 -> Int32
int32 = readGene
int16 :: Gene Int16 -> Int16
int16 = readGene
int8 :: Gene Int8 -> Int8
int8 = readGene

intInRange (lo,hi) = (+ lo) . (`mod` (hi-lo)) . int
