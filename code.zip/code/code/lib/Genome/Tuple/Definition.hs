{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE TemplateHaskell       #-}
{-# LANGUAGE TypeFamilies          #-}

module Genome.Tuple.Definition
     ( Gene (..), readGene
     ) where

import           Genome.Tuple.TH

$(tupleSplitUpTo 30)
