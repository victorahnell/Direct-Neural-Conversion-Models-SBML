{-# LANGUAGE MultiParamTypeClasses      #-}
{-# LANGUAGE TemplateHaskell            #-}
{-# LANGUAGE TypeFamilies               #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module Genome.Tuple.TH
     ( module Genome.Tuple.TH
     ) where

import           Control.Monad
import           Language.Haskell.TH
import           Language.Haskell.TH.Syntax

import           Genome.Split

newtype Gene a = Gene a deriving (Show, Read, Eq, Num, Bounded, Ord, Enum)
readGene (Gene a) = a

tupleSplit :: Int -> Int -> Q [Dec]
tupleSplit n m =
    do nnames <- replicateM n (newName "a")
       mnames <- replicateM m (newName "b")
       let ntuple = return $ foldl (\ r x -> r `AppT` (ConT ''Gene `AppT` VarT x)) (TupleT n) nnames
       let mtuple = return $ foldl (\ r x -> r `AppT` (ConT ''Gene `AppT` VarT x)) (TupleT m) mnames
       let rtuple = return $ foldl (\ r x -> r `AppT` (ConT ''Gene `AppT` VarT x)) (TupleT (n+m)) (nnames ++ mnames)
       let nexp = return $ TupE (map VarE nnames)
       let mexp = return $ TupE (map VarE mnames)
       let rpat = return $ TupP (map VarP (nnames ++ mnames))
       [d| instance Split $ntuple $mtuple where
               type Unsplit $ntuple $mtuple = $rtuple
               split $rpat = ($nexp,$mexp) |]

tupleSplitUpTo t = concat <$> sequence [ tupleSplit n m | n <- [0..t], m <- [0..t-n], not (n + m == 0)]
