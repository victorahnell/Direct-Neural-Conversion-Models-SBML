{-# LANGUAGE BangPatterns          #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE TypeFamilies          #-}

module Genome.List.Definition
     ( module Genome.List.Definition
     ) where

import           Genome.Split

newtype ListGene a = ListGene a

readGene (ListGene a) = a

instance Split (ListGene a) [a] where
    type Unsplit (ListGene a) [a] = [a]
    split (!x:xs) = (ListGene x, xs)
    split [] = error "Genome.Definitions.split: Cannot read gene from empty list genome."

instance Split (ListGene a) (ListGene a) where
    type Unsplit (ListGene a) (ListGene a) = [a]
    split ((!x):(!y):r) = (ListGene x, ListGene y)
    split (x:r) = (ListGene x, error "Genome.List.Definitions.split: Cannot read gene from empty list genome.")
    split [] = error "Genome.List.Definitions.split: Cannot read gene from empty list genome."

instance Split () (ListGene a) where
    type Unsplit () (ListGene a) = ListGene a
    split x = ((),x)

instance Split (ListGene a) () where
    type Unsplit (ListGene a) () = ListGene a
    split x = (x,())

instance Split () [a] where
    type Unsplit () [a] = [a]
    split xs = ((),xs)

instance Split [a] () where
    type Unsplit [a] () = [a]
    split xs = (xs,())
