{-# LANGUAGE ScopedTypeVariables #-}

module Genome.List.Functions
     ( module Genome.List.Functions
     ) where

import           Control.Monad.Random
import           Data.Int
import           Data.Word

import           Genome.List.Definition

crossover_uniform :: MonadRandom m => [a] -> [a] -> m [a]
crossover_uniform (x:xs) (y:ys) =
    do bool :: Bool <- getRandom
       if bool
       then (x :) <$> crossover_uniform xs ys
       else (y :) <$> crossover_uniform xs ys
crossover_uniform [] [] = return []
crossover_uniform _ _ = error "Genome.List.Functions.list_xover_uniform: Cannot crossover lists of different length."

bool :: ListGene Bool -> Bool
bool = readGene

double :: ListGene Double -> Double
double = readGene

word64 :: ListGene Word64 -> Word64
word64 = readGene
word32 :: ListGene Word32 -> Word32
word32 = readGene
word16 :: ListGene Word16 -> Word16
word16 = readGene
word8 :: ListGene Word8 -> Word8
word8 = readGene

integer :: ListGene Integer -> Integer
integer = readGene
int :: ListGene Int -> Int
int = readGene
int64 :: ListGene Int64 -> Int64
int64 = readGene
int32 :: ListGene Int32 -> Int32
int32 = readGene
int16 :: ListGene Int16 -> Int16
int16 = readGene
int8 :: ListGene Int8 -> Int8
int8 = readGene
