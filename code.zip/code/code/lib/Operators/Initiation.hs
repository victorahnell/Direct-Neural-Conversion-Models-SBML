{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE FlexibleContexts #-}

module Operators.Initiation
     ( module Operators.Initiation
     ) where

import           Control.Monad
import           Data.Maybe
import qualified Control.Monad.Parallel as P

import           Population.Definition
import           Utility.Monadic
import           Utility.Random
import           Utility.Distribution
import           Data.Function (on)

import Debug.Trace

import Data.Fixed.Vector

-- | Add n organisms to the population, given by the given monadic generated.
--   Failed adds are ignored, and re-attempted.
generate :: (Population p o, Addable p o a)
              => Int
              -> Drone s p o a
              -> Action s p o [Pointer s]
generate 0 _   = return []
generate n gen =
    do xs <- action $ P.replicateM n gen
       ps <- catMaybes <$> mapM add xs
       (ps ++) <$> generate (n - length ps) gen
generate_ :: Addable p o a => Int -> Drone s p o a -> Action s p o ()
generate_ n gen = void $ generate n gen

randomOrganism :: Population p o => Drone s p o (Maybe (Pointer s))
randomOrganism     = population >>= randomElement
randomOrganismsD :: Population p o => Int -> Drone s p o [Pointer s]
randomOrganismsD n = population >>= randomSublist n
randomOrganismsR :: Population p o => Int -> Drone s p o [Pointer s]
randomOrganismsR n = catMaybes <$> replicateM n randomOrganism

randomCouple :: Population p o => Drone s p o (Maybe (Pointer s, Pointer s))
randomCouple       = population >>= randomCoupleFrom
randomCouplesD :: Population p o => Int -> Drone s p o [(Pointer s, Pointer s)]
randomCouplesD n   = population >>= fmap pairs . randomSublist (2*n)
    where pairs (x:y:zs) = (x,y) : pairs zs
          pairs _        = []
randomCouplesR :: Population p o => Int -> Drone s p o [(Pointer s, Pointer s)]
randomCouplesR n   = catMaybes <$> replicateM n randomCouple
randomCoupleFrom :: Population p o => [Pointer s] -> Drone s p o (Maybe (Pointer s, Pointer s))
randomCoupleFrom ps = pair <$> randomSublist 2 ps
    where pair [a,b] = Just (a,b)
          pair _     = Nothing

-- | Take the best / worst individual according to the given comparison function.
winner, loser :: PopulationM m s p o => (Pointer s -> Pointer s -> Observer s p o Ordering) -> m s p o (Pointer s)
winner cmp = grabs $ fmap head . maximumByM cmp =<< population
loser  cmp = grabs $ fmap head . minimumByM cmp =<< population

winners, losers :: PopulationM m s p o => (Pointer s -> Pointer s -> Observer s p o Ordering) -> Int -> m s p o [Pointer s]
winners cmp n = grabs $ fmap (take n . reverse) . sortByM cmp =<< population
losers  cmp n = grabs $ fmap (take n) . sortByM cmp =<< population

-- | Convert a straightforward fitness function to a more general comparison type that can be used in the other operators.
compareOn :: (PopulationM m s p o, Ord fitness) => (o -> fitness) -> (Pointer s -> Pointer s -> m s p o Ordering)
compareOn fitness = liftM2 compare `on` fmap fitness . organism

-- | A basic evolution strategy.
--   This algorithm creates n new organisms, then performs n selection
--   operations which kill one individual.
--   Selection only compares m random indiduals, which allows easily
--   adjusting the selection pressure.
evolutionStrategy :: (Population p o, Addable p o x)
                  => Drone s p o x                      -- ^ Generate new organism
                  -> Drone s p o (Pointer s)            -- ^ Selection mechanism
                  -> Int                                -- ^ Parallel n
                  -> Int                                -- ^ Lambda. The number of organisms to consider during reproduction and selection (more means higher selection pressure).
                  -> Action s p o ()
evolutionStrategy new sel n lambda
    | n <= 0 || lambda <= 0 = err
    | otherwise =
    do offspring <- action $ P.replicateM n (restrict lambda new)
       forM_ offspring $ \ newguy ->
           add newguy >>= \ result ->
           case result of
               Nothing -> return ()
               Just _  -> action (restrict lambda sel) >>= kill
    where err = error "evolutionStrategy: Can only perform with lambda and n > 0."

-- | Restrict a Drone to a population subset.
--   It will pretend that organisms except the ones provided are dead.
restrictTo :: Population p o => [Pointer s] -> Drone s p o a -> Drone s p o a
restrictTo ps = localDroneM (select ps)

-- | Restrict a drone to a random population subset of the given size.
restrict :: Population p o => Int -> Drone s p o a -> Drone s p o a
restrict lambda drone = randomOrganismsD lambda >>= flip restrictTo drone

-- | Tournament selection algorithm.
--   Returns the worst individual with a probability of p, the second worst with probability p*(p-1) etc.
tournament :: Population p o
           => Double                                             -- ^ p
           -> (Pointer s -> Pointer s -> Observer s p o Ordering)   -- ^ Organism comparison
           -> Drone s p o (Pointer s)
tournament 1 cmp = grabs $ loser cmp
tournament p cmp | p <= 0 || p > 1 = error "Tournament p must be in (0,1]"
                 | otherwise =
    do sorted <- grabs $ sortByM cmp =<< population
       go $ cycle sorted
    where go (x:xs) = do k <- getRandom; if k < p then return x else go xs
          go []     = error "Impossible"

-- | Implementation of Covariance-Matrix Adaptation Evolution Strategy.
--   Takes a selection of best organisms and compares these to the total
--   population to establish a multivariate normal distribution from which to
--   draw new individuals.
--   Organisms must be convertible to and from real vectors.
cmaes :: (Population p o, Index ix, Addable p o x)
      => (Pointer s -> Observer s p o (IxVector ix Double))   -- ^ How to read a vector from the population
      -> (IxVector ix Double -> x)                            -- ^ How to add a vector to the population
      -> Drone s p o [Pointer s]                              -- ^ Selection mechanism (e.g. take 25% best)
      -> Action s p o ()
cmaes vec unvec sel =
    do wins <- action sel
       loss <- allExcept wins
       winvecs <- action $ mapM (fmap wrap . fmap ixCol . vec) wins
       losvecs <- action $ mapM (fmap wrap . fmap ixCol . vec) loss

       let mu  = average $ winvecs ++ losvecs
           mu' = average $ winvecs
           sigma = average . map (cov mu) $ winvecs
           chol = wrTranspose . wrChol $ sigma

       select wins
       generate_ (length loss) (unvec <$> multinormal mu' chol)

    where cov mu x = let x' = x-mu in x' `wrProd` wrTranspose x'
          average lst = sum lst / fromIntegral (length lst)
          multinormal mu cholsigma =
              do z <- wrap . ixCol <$> ixReplicateM (gaussianM 1 0)
                 return $ ixUnCol . unwrap $ mu + wrProd cholsigma z
