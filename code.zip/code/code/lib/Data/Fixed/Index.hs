{-# LANGUAGE DataKinds           #-}
{-# LANGUAGE PolyKinds           #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeFamilies        #-}

module Data.Fixed.Index
     ( module Data.Fixed.Index
     ) where

import           Data.List    (findIndex)
import           Data.Maybe   (fromMaybe)
import           Data.Proxy
import           GHC.TypeLits

-- | Class of possible indexes for fixed-size data structures.
--   The indexes must be consecutive, start at 0 and end at maxIx-1.
class Index a where
    type Ix a
    maxIx :: proxy a -> Ix a
    sizeIx :: proxy a -> Int
    sizeIx p = unsafeIndex p (maxIx p) + 1
    index :: proxy a -> Ix a -> Maybe Int
    unsafeIndex :: proxy a -> Ix a -> Int
    unsafeIndex p i = fromMaybe err $ index p i
        where err = error "Data.Fixed.Vector.unsafeIndex: Not a proper index."

-- | A natural index type accepting integer indices up to a given size.
data IntIx :: Nat -> *
instance KnownNat n => Index (IntIx n) where
    type Ix (IntIx n) = Int
    maxIx _ = (subtract 1) . fromInteger $ natVal (Proxy::Proxy n)
    unsafeIndex _ = id
    index p i | i < 0       = Nothing
              | i > maxIx p = Nothing
              | otherwise   = Just i

-- | Index type using Enums.
--   Because Enum and Bounded make no guarantees that minBound == 0, or that
--   the fromEnum numbers are consecutive, implementation needs to search for the right index and is therefore inefficient.
data EnumIx :: * -> *
instance (Eq c, Enum c, Bounded c) => Index (EnumIx c) where
    type Ix (EnumIx c) = c
    maxIx _ = maxBound
    index _ c = findIndex (c ==) [minBound .. maxBound]

instance (Index a, Index b) => Index (a,b) where
    type Ix (a,b) = (Ix a, Ix b)
    maxIx _ = (maxIx (Proxy::Proxy a), maxIx (Proxy::Proxy b))
    index _ (a,b) =
        do ai <- index (Proxy::Proxy a) a
           bi <- index (Proxy::Proxy b) b
           return $ bi + ai * sizeIx (Proxy::Proxy b)
