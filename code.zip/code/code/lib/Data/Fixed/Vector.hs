{-# LANGUAGE DataKinds                  #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE NoMonomorphismRestriction  #-}
{-# LANGUAGE Rank2Types                 #-}
{-# LANGUAGE ScopedTypeVariables        #-}
{-# LANGUAGE TypeFamilies               #-}

module Data.Fixed.Vector
     ( module Data.Fixed.Index
     , IxVector, FixedVector, FixedMatrix
     , ix, (!), (!?), getVal
     , toVector, indexedMaybe, indexed, unsafeIndexed, ixFromListMaybe, ixFromList
     , ixReplicate, ixReplicateM
     , ixInsert, ixUpdate, (//)
     , ixZipWith, ixZipWith3, ixMap, ixMapM
     , ixLength, ixSum, ixAll, ixAny
     , ixNormL, ixNorm, ixMax, ixMin
     , spike
     , unsafeWrap, unfixMatrix, unfixWrapper, wrap, unwrap
     , wrTranspose, ixTranspose, wrProd, ixProd, wrInvert, ixInvert, wrChol, ixChol
     , ixRow, ixCol, ixUnRow, ixUnCol, ixRows, ixCols, ixCells, ixDot, ixOuter
     , Unbox
     ) where

import           Control.Arrow
import           Control.Monad                (when)
import           Data.List                    (intercalate, nub)
import           Data.Maybe
import           Data.Proxy
import           Data.Vector.Unboxed          (Unbox, Vector)
import qualified Data.Vector.Unboxed          as V
import           GHC.TypeLits                 (KnownNat)
import qualified Numeric.LinearAlgebra        as LA
import           Text.ParserCombinators.ReadP

import           Data.Fixed.Index
import           Utility

import           Data.Coerce

-- ** Indexed vectors with fixed length.
newtype IxVector ix a = IxVector (Vector a)

type FixedVector len a = IxVector (IntIx len) a
-- | NOTE: FixedMatrix uses the same interface as IxVector.
--   In particular, its Num instance specifies that 1 is the matrix where
--   each cell has value 1.
type FixedMatrix x y a = IxVector (IntIx x, IntIx y) a

getVal :: Unbox a => FixedVector 1 a -> a
getVal = coerce V.head

-- * Indexing

ix :: forall a x. (Unbox x, Index a) => IxVector a x -> Ix a -> Maybe x
v `ix` x = (toVector v V.!) <$> index (Proxy::Proxy a) x

(!) :: (Index ix, Unbox a) => IxVector ix a -> Ix ix -> a
(!) = fromMaybe err `owl` (!?)
    where err = error "Data.Fixed.Vector.!: Not a valid index"

(!?) :: (Index ix, Unbox a) => IxVector ix a -> Ix ix -> Maybe a
(!?) = ix

-- * Creation and destruction

toVector :: IxVector ix a -> Vector a
toVector (IxVector v) = v

indexedMaybe :: forall ix a. (Index ix, Unbox a) => Vector a -> Maybe (IxVector ix a)
indexedMaybe v
    | len == V.length v = Just (IxVector v)
    | otherwise         = Nothing
    where len = sizeIx (Proxy::Proxy ix)

indexed :: forall ix a. (Index ix, Unbox a) => Vector a -> IxVector ix a
indexed = fromMaybe err . indexedMaybe
    where err = error "Data.Fixed.Vector.indexed: Index type does not match argument length."

ixFromListMaybe :: (Unbox a, Index ix) => [a] -> Maybe (IxVector ix a)
ixFromListMaybe = indexedMaybe . V.fromList

ixFromList :: (Unbox a, Index ix) => [a] -> IxVector ix a
ixFromList = indexed . V.fromList

unsafeIndexed :: forall ix a. (Index ix, Unbox a) => Vector a -> IxVector ix a
unsafeIndexed = IxVector

ixReplicate :: forall ix a. (Index ix, Unbox a) => a -> IxVector ix a
ixReplicate = coerce $ V.replicate len
    where len = sizeIx (Proxy::Proxy ix)

ixReplicateM :: forall ix a m. (Index ix, Unbox a, Monad m) => m a -> m (IxVector ix a)
ixReplicateM mx = unsafeIndexed <$> V.replicateM len mx
    where len = sizeIx (Proxy::Proxy ix)

spike :: (Index ix, Unbox a, Num a) => Ix ix -> IxVector ix a
spike i = ixInsert i 1 (ixReplicate 0)

-- * Updates

ixInsert :: forall ix a. (Index ix, Unbox a) => Ix ix -> a -> IxVector ix a -> IxVector ix a
ixInsert i x v = v // [(i,x)]

ixUpdate :: forall ix a. (Index ix, Unbox a) => Ix ix -> (a -> a) -> IxVector ix a -> IxVector ix a
ixUpdate i f v = v // [(i,x)] where x = f (v ! i)

(//) :: forall ix a. (Index ix, Unbox a) => IxVector ix a -> [(Ix ix, a)] -> IxVector ix a
v // lst = unsafeIndexed $ (toVector v) V.// map (first (unsafeIndex (Proxy::Proxy ix))) lst

-- * Functions

ixZipWith :: (Unbox a, Unbox b, Unbox c, Index ix) => (a -> b -> c) -> IxVector ix a -> IxVector ix b -> IxVector ix c
ixZipWith = coerce V.zipWith
ixZipWith3 :: (Unbox a, Unbox b, Unbox c, Unbox d, Index ix) => (a -> b -> c -> d) -> IxVector ix a -> IxVector ix b -> IxVector ix c -> IxVector ix d
ixZipWith3 = coerce V.zipWith3

ixMap :: (Unbox a, Unbox b, Index ix) => (a -> b) -> IxVector ix a -> IxVector ix b
ixMap = coerce V.map

ixMapM :: (Unbox a, Unbox b, Index ix, Monad m) => (a -> m b) -> IxVector ix a -> m (IxVector ix b)
ixMapM f = fmap coerce . V.mapM f . coerce

ixLength :: forall ix a. (Index ix, Unbox a) => IxVector ix a -> Int
ixLength _ = sizeIx (Proxy::Proxy ix)

ixSum :: (Index ix, Unbox a, Num a) => IxVector ix a -> a
ixSum = coerce V.sum

ixMax :: (Index ix, Unbox a, Ord a) => IxVector ix a -> a
ixMax = coerce V.maximum
ixMin :: (Index ix, Unbox a, Ord a) => IxVector ix a -> a
ixMin = coerce V.minimum

ixAll, ixAny :: (Index ix, Unbox a) => (a -> Bool) -> IxVector ix a -> Bool
ixAll = coerce V.all
ixAny = coerce V.any

ixNorm :: Index ix => IxVector ix Double -> Double
ixNorm = ixNormL 2
ixNormL :: Index ix => Double -> IxVector ix Double -> Double
ixNormL l = (**(1/l)) . ixSum . ixMap ((**l) . abs)

-- * Linear algebra

ixCells :: (Index ix, Unbox a) => IxVector ix a -> [a]
ixCells = V.toList . toVector

ixRow :: (Index m, Unbox a) => IxVector m a -> IxVector (IntIx 1, m) a
ixRow = coerce
ixUnRow :: (Index m, Unbox a) => IxVector m a -> IxVector (IntIx 1, m) a
ixUnRow = coerce

ixCol :: (Index n, Unbox a) => IxVector n a -> IxVector (n, IntIx 1) a
ixCol = coerce
ixUnCol :: (Index n, Unbox a) => IxVector (n, IntIx 1) a -> IxVector n a
ixUnCol = coerce

ixRows :: forall ixx ixy a. (Index ixx, Index ixy, Unbox a) => IxVector (ixx,ixy) a -> [IxVector ixx a]
ixRows v = [ coerce V.slice i m v | i <- [0, m .. m*(n-1)] ]
    where n = sizeIx (Proxy::Proxy ixx)
          m = sizeIx (Proxy::Proxy ixy)

ixCols :: (Index ixx, Index ixy, Unbox a) => IxVector (ixy, ixx) a -> [IxVector ixx a]
ixCols = ixRows . ixTranspose

ixDot :: (Index ix, Num a, Unbox a) => IxVector ix a -> IxVector ix a -> a
ixDot = ixSum `owl` ixZipWith (*)

ixOuter :: (Index n, Index m) => IxVector n Double -> IxVector m Double -> IxVector (n,m) Double
ixOuter a b = ixCol a `ixProd` ixRow b

newtype MatrixWrapper n m = WrapM (LA.Matrix Double)
    deriving (Num, Fractional, Floating, Show)

unsafeWrap :: LA.Matrix Double -> MatrixWrapper n m
unsafeWrap = WrapM
unfixWrapper :: MatrixWrapper n m -> LA.Matrix Double
unfixWrapper (WrapM x) = x
unfixMatrix :: (Index n, Index m) => IxVector (n,m) Double -> LA.Matrix Double
unfixMatrix = LA.fromLists . map (coerce V.toList) . ixRows

wrap :: (Index n, Index m) => IxVector (n,m) Double -> MatrixWrapper n m
wrap = WrapM . unfixMatrix
unwrap :: (Index n, Index m) => MatrixWrapper n m -> IxVector (n,m) Double
unwrap = unsafeIndexed . V.fromList . concat . LA.toLists . unfixWrapper

wrTranspose :: MatrixWrapper n m -> MatrixWrapper m n
wrTranspose = coerce . LA.tr . unfixWrapper
ixTranspose :: forall ixx ixy a. (Index ixx, Index ixy, Unbox a) => IxVector (ixx,ixy) a -> IxVector (ixy,ixx) a
ixTranspose v = coerce V.backpermute v $ V.fromList . concat $ [ [i, i+n .. nm] | i <- [0 .. n-1] ]
    where n = sizeIx (Proxy::Proxy ixx)
          m = sizeIx (Proxy::Proxy ixy)
          nm = n*m-1

wrProd :: MatrixWrapper n k -> MatrixWrapper k m -> MatrixWrapper n m
wrProd x y = coerce $ unfixWrapper x LA.<> unfixWrapper y
ixProd :: (Index n, Index m, Index k) => IxVector (n,k) Double -> IxVector (k,m) Double -> IxVector (n,m) Double
ixProd x y = unwrap $ wrProd (wrap x) (wrap y)

wrInvert :: MatrixWrapper n n -> MatrixWrapper n n
wrInvert = coerce . LA.inv . unfixWrapper
ixInvert :: Index n => IxVector (n,n) Double -> IxVector (n,n) Double
ixInvert = unwrap . wrInvert . wrap

wrChol :: MatrixWrapper n n -> MatrixWrapper n n
wrChol = coerce . LA.chol . LA.sym . unfixWrapper
ixChol :: Index n => IxVector (n,n) Double -> IxVector (n,n) Double
ixChol = unwrap . wrChol . wrap

-- * Instances

instance (Unbox a, Eq a, Index ix) => Eq (IxVector ix a) where
    (==) = (==) `on` toVector

instance (Show a, Unbox a) => Show (IxVector (IntIx n) a) where
    show = show . toVector
instance (Show a, Unbox a, Show c, Eq c, Bounded c, Enum c) => Show (IxVector (EnumIx c) a) where
    show v = cat $ [ show i ++ ": " ++ show (v ! i) | i <- [minBound..maxBound] ]
        where cat vs = "<| " ++ intercalate ", " vs ++ " |>"
instance (Show a, Unbox a, KnownNat n, KnownNat m) => Show (IxVector (IntIx n, IntIx m) a) where
    show = show . partition . V.toList . toVector
        where partition [] = []
              partition xs = let (fs,sn) = splitAt n xs in fs : partition sn
              n = sizeIx (Proxy::Proxy (IntIx m))

instance (Read a, Unbox a, KnownNat n) => Read (IxVector (IntIx n) a) where
    readsPrec s = readP_to_S $
        do optional $ string "FixedVector "
           indexed <$> readS_to_P (readsPrec s :: ReadS (Vector a))
instance (Read a, Unbox a, Read c, Bounded c, Enum c, Eq c) => Read (IxVector (EnumIx c) a) where
    readsPrec s = readP_to_S $
        do _ <- string "<|"
           skipSpaces
           eles <- sepBy parseEle eleSep
           skipSpaces
           _ <- string "|>"
           when (not (uniq (map fst eles))) duplicatesError
           return $ ixFromList [ fromMaybe def (lookup x eles) | x <- [minBound..maxBound] ]
        where parseEle =
                  do c <- readS_to_P (readsPrec s :: ReadS c)
                     _ <- string ":"
                     skipSpaces
                     x <- readS_to_P (readsPrec s :: ReadS a)
                     return (c,x)
              eleSep = string "," >> skipSpaces
              def = error "Data.Fixed.Vector.read: not all enum indices were specified"
              duplicatesError = error "Data.Fixed.Vector.read: at least one enum index appeared multiple times"
              uniq lst = length (nub lst) == length lst


instance (Index ix, Unbox a, Num a) => Num (IxVector ix a) where
    (+)    = ixZipWith (+)
    (*)    = ixZipWith (*)
    abs    = ixMap abs
    signum = ixMap signum
    negate = ixMap negate
    fromInteger = ixReplicate . fromInteger

{-# SPECIALIZE (/) :: Index ix => IxVector ix Double -> IxVector ix Double -> IxVector ix Double #-}
instance (Index ix, Unbox a, Fractional a) => Fractional (IxVector ix a) where
    (/) = ixZipWith (/)
    fromRational = ixReplicate . fromRational

{-# SPECIALIZE (**) :: Index ix => IxVector ix Double -> IxVector ix Double -> IxVector ix Double #-}
instance (Index ix, Unbox a, Floating a) => Floating (IxVector ix a) where
    pi    = ixReplicate pi
    exp   = ixMap exp
    log   = ixMap log
    sin   = ixMap sin
    cos   = ixMap cos
    asin  = ixMap asin
    acos  = ixMap acos
    atan  = ixMap atan
    sinh  = ixMap sinh
    cosh  = ixMap cosh
    asinh = ixMap asinh
    acosh = ixMap acosh
    atanh = ixMap atanh
