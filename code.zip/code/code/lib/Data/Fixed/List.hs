{-# LANGUAGE DataKinds           #-}
{-# LANGUAGE Rank2Types          #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeFamilies        #-}

module Data.Fixed.List
     ( module Data.Fixed.Index
     , IxList, FixedList
     , ix, (!), (!?), getVal
     , toList, indexedMaybe, indexed, unsafeIndexed
     , ixReplicate, ixReplicateM
     , ixInsert, ixUpdate, (//)
     , ixZipWith, ixZipWith3, ixMap, ixMapM
     , ixLength, ixSum, ixAll, ixAny
     , ixNormL, ixNorm
     , spike
     ) where

import           Control.Arrow                (first)
import           Control.Monad
import           Data.Coerce
import           Data.Foldable
import           Data.List
import           Data.Maybe
import           Data.Proxy
import           Text.ParserCombinators.ReadP

import           Data.Fixed.Index
import           Utility

-- ** Indexed vectors with fixed length.
newtype IxList ix a = IxList [a]

type FixedList len a = IxList (IntIx len) a

getVal :: FixedList 1 a -> a
getVal = head . toList

-- * Indexing

ix :: forall a x. Index a => IxList a x -> Ix a -> Maybe x
v `ix` x = (toList v !!) <$> index (Proxy::Proxy a) x

(!) :: Index ix => IxList ix a -> Ix ix -> a
(!) = fromJust `owl` (!?)

(!?) :: Index ix => IxList ix a -> Ix ix -> Maybe a
(!?) = ix

-- * Creation and destruction

-- toList :: IxList ix a -> [a]
-- See: Foldable instance

indexedMaybe :: forall ix a. Index ix => [a] -> Maybe (IxList ix a)
indexedMaybe v
    | len == length v = Just (IxList v)
    | otherwise       = Nothing
    where len = sizeIx (Proxy::Proxy ix)

indexed :: forall ix a. Index ix => [a] -> IxList ix a
indexed = fromMaybe err . indexedMaybe
    where err = error "Data.Fixed.List.indexed: Index type does not match argument length."

unsafeIndexed :: forall ix a. Index ix => [a] -> IxList ix a
unsafeIndexed = IxList

ixReplicate :: forall ix a. Index ix => a -> IxList ix a
ixReplicate x = unsafeIndexed $ replicate len x
    where len = sizeIx (Proxy::Proxy ix)

ixReplicateM :: forall ix a m. (Index ix, Monad m) => m a -> m (IxList ix a)
ixReplicateM mx = unsafeIndexed <$> replicateM len mx
    where len = sizeIx (Proxy::Proxy ix)

spike :: (Index ix, Num a) => Ix ix -> IxList ix a
spike i = ixInsert i 1 (ixReplicate 0)

-- * Updates

ixInsert :: forall ix a. Index ix => Ix ix -> a -> IxList ix a -> IxList ix a
ixInsert i x v = v // [(i,x)]

ixUpdate :: forall ix a. Index ix => Ix ix -> (a -> a) -> IxList ix a -> IxList ix a
ixUpdate i f v = v // [(i,x)] where x = f (v ! i)

(//) :: forall ix a. Index ix => IxList ix a -> [(Ix ix, a)] -> IxList ix a
v // upds = unsafeIndexed $ go 0 (toList v) upds' []
    where upds' = (sortBy (compare `on` fst)) . map (first (unsafeIndex (Proxy::Proxy ix))) $ upds
          go _ lst [] = (lst ++)
          go i lst ((u,x'):uxs) = case splitAt (u-i) lst of
              (bs,_:xs) -> (bs ++) . go u (x':xs) uxs
              (_,[])    -> error "Data.Fixed.List.//: Cannot update index higher than list length."

-- * Functions

ixZipWith :: Index ix => (a -> b -> c) -> IxList ix a -> IxList ix b -> IxList ix c
ixZipWith f va vb = unsafeIndexed $ zipWith f (toList va) (toList vb)
ixZipWith3 :: Index ix => (a -> b -> c -> d) -> IxList ix a -> IxList ix b -> IxList ix c -> IxList ix d
ixZipWith3 f va vb vc = unsafeIndexed $ zipWith3 f (toList va) (toList vb) (toList vc)

ixMap :: Index ix => (a -> b) -> IxList ix a -> IxList ix b
ixMap f = unsafeIndexed . map f . toList

ixMapM :: (Index ix, Monad m) => (a -> m b) -> IxList ix a -> m (IxList ix b)
ixMapM f = fmap unsafeIndexed . mapM f . toList

ixLength :: forall ix a. Index ix => IxList ix a -> Int
ixLength _ = sizeIx (Proxy::Proxy ix)

ixSum :: forall ix a. (Index ix, Num a) => IxList ix a -> a
ixSum = sum . toList

ixAll, ixAny :: Foldable t => (a -> Bool) -> t a -> Bool
ixAll f = all f . toList
ixAny f = any f . toList

ixNorm :: Index ix => IxList ix Double -> Double
ixNorm = ixNormL 2
ixNormL :: Index ix => Double -> IxList ix Double -> Double
ixNormL l = (**(1/l)) . ixSum . ixMap ((**l) . abs)

-- * Instances

instance (Eq a, Index ix) => Eq (IxList ix a) where
    (==) = (==) `on` toList

instance (Show a, Index ix) => Show (IxList ix a) where
    show = coerce (show :: [a] -> String)

instance (Index ix, Read a) => Read (IxList ix a) where
    readsPrec s = readP_to_S $
        do optional $ string "FixedList "
           indexed <$> readS_to_P (readsPrec s :: ReadS [a])

instance (Index ix, Num a) => Num (IxList ix a) where
    (+)    = ixZipWith (+)
    (*)    = ixZipWith (*)
    abs    = ixMap abs
    signum = ixMap signum
    negate = ixMap negate
    fromInteger = ixReplicate . fromInteger

instance (Index ix, Fractional a) => Fractional (IxList ix a) where
    (/) = ixZipWith (/)
    fromRational = ixReplicate . fromRational

instance (Index ix, Floating a) => Floating (IxList ix a) where
    pi    = ixReplicate pi
    exp   = ixMap exp
    log   = ixMap log
    sin   = ixMap sin
    cos   = ixMap cos
    asin  = ixMap asin
    acos  = ixMap acos
    atan  = ixMap atan
    sinh  = ixMap sinh
    cosh  = ixMap cosh
    asinh = ixMap asinh
    acosh = ixMap acosh
    atanh = ixMap atanh

instance Index ix => Foldable (IxList ix) where
    foldMap f = foldMap f . toList
    foldr f x = foldr f x . toList
    toList (IxList lst) = lst
    length = ixLength

instance Index ix => Functor (IxList ix) where
    fmap f = coerce ((fmap :: (a->b)->[a]->[b]) f)

instance Index ix => Applicative (IxList ix) where
    pure = ixReplicate
    (<*>) = ixZipWith ($)

instance Index ix => Monad (IxList ix) where
    return = pure
    m >>= f = IxList $ zipWith ((!!) . toList . f) (toList m) [0..]
