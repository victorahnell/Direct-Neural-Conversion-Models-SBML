{-# LANGUAGE FlexibleContexts #-}

module Utility
     ( module Utility
     , on
     ) where

import           Control.Monad.Random
import           Data.Function
import           Data.List

subsets :: (Num t, Eq t) => t -> [a] -> [[a]]
subsets 0 _      = [[]]
subsets 1 xs     = map (:[]) xs
subsets n (x:xs) = map (x:) (subsets (n-1) xs) ++ subsets n xs
subsets _ _      = []

isFiniteDouble :: Double -> Bool
isFiniteDouble = not . liftM2 (||) isInfinite isNaN

compareFinite :: Double -> Double -> Ordering
compareFinite x y | isFiniteDouble x && isFiniteDouble y = compare x y
                  | isFiniteDouble x = GT
                  | isFiniteDouble y = LT
                  | otherwise = EQ

average :: Fractional a => [a] -> a
average [] = error "Utility.average: Cannot take average of empty list."
average xs = sum xs / fromIntegral (length xs)

takeOneEvery :: Int -> [a] -> [a]
takeOneEvery n xs = case drop (n-1) xs
                    of []     -> []
                       (y:ys) -> y : takeOneEvery n ys

doTimes :: Int -> (a -> a) -> a -> a
doTimes n _ _ | n < 0 = error "Utility.doTimes: Cannot do negative amount of times."
doTimes n f x = iterate f x !! n

median :: (Ord a, Fractional a) => [a] -> a
median lst | len `rem` 2 == 1 = srtlst !! half
           | otherwise = ((srtlst !! half) + (srtlst !! (half - 1))) / 2
    where len = length lst
          half = len `div` 2
          srtlst = sort lst

equalPartitions :: Int -> [a] -> [[a]]
equalPartitions _ [] = []
equalPartitions n xs = let (f,s) = splitAt n xs
                       in f : equalPartitions n s

ifthen :: a -> a -> Bool -> a
ifthen x y b = if b then x else y

onlyIf :: (a -> Bool) -> a -> Maybe a
onlyIf f a | f a = Just a
           | otherwise = Nothing

nan :: Double
nan = 0 / 0

owl :: (b -> c) -> (a1 -> a -> b) -> a1 -> a -> c
owl = (.).(.)
infixr 6 `owl`

reverseOrd :: Ordering -> Ordering
reverseOrd GT = LT
reverseOrd EQ = EQ
reverseOrd LT = GT
