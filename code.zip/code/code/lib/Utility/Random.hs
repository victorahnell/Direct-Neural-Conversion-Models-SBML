

module Utility.Random
     ( module Utility.Random
     ) where

import           Control.Monad.Random (MonadRandom (..), Random (..))
import           Data.Foldable        (toList)
import           Data.Sequence        (Seq)
import qualified Data.Sequence        as Seq (deleteAt, empty, fromList, index,
                                              length, null, (<|))
import           Data.Set             (Set)
import qualified Data.Set             as Set (delete, elemAt, empty, insert,
                                              null, size)

-- * Misc

-- | Round a number in a random manner, either up or down proportional to the fractional part.
randomround :: (MonadRandom m, RealFrac a, Random a, Integral b)
            => a -> m b
randomround x = do (n,q) <- return $ properFraction x
                   r     <- getRandom
                   return $ if r < q then n+1 else n

-- -- | Create new integral number from a poisson distribution
-- randomPoisson :: (Floating a, Ord a, Random a, Integral b, MonadRandom m) => a -> m b
-- randomPoisson lambda = go (exp (-lambda)) 0 1
--   where go l k p | p < l     = return $ k-1
--                  | otherwise = do u <- getRandom
--                                   go l (k+1) (p*u)

-- * Lists

-- | Get random element from a list
randomElement :: MonadRandom m => [a] -> m (Maybe a)
randomElement lst = fst <$> randomElement' lst

-- | Get random element from a list, and also its complement
randomElement' :: MonadRandom m => [a] -> m (Maybe a, [a])
randomElement' [] = return (Nothing, [])
randomElement' lst =
    do i <- getRandomR (0, length lst - 1)
       e <- return $ lst !! i
       (fstlst, sndlst) <- return $ splitAt i lst
       return (Just e, fstlst ++ tail sndlst)

-- | Get random (not necessarily consecutive) sublist
randomSublist :: MonadRandom m => Int -> [a] -> m [a]
randomSublist n = fmap toList . randomSubseq n . Seq.fromList

-- | Change order of this list
shuffle :: MonadRandom m => [a] -> m [a]
shuffle lst = randomSublist (length lst) lst

-- * Sequences

-- | Get a random element from a sequence
randomSeqElement :: MonadRandom m => Seq a -> m (Maybe a)
randomSeqElement lst = fst <$> randomSeqElement' lst

-- | Get a random element from a sequence, and also the remaining sequence without that element
randomSeqElement' :: MonadRandom m => Seq a -> m (Maybe a, Seq a)
randomSeqElement' lst | Seq.null lst = return (Nothing, Seq.empty)
                      | otherwise =
    do i <- getRandomR (0, Seq.length lst - 1)
       e <- return $ Seq.index lst i
       return (Just e, Seq.deleteAt i lst)

-- | Get a random (not necessarily consecutive) subset from a sequence
randomSubseq :: MonadRandom m => Int -> Seq a -> m (Seq a)
randomSubseq n lst = fst <$> randomSubseq' n lst

-- | Get a random (not necessarily consecutive) subset from a sequence, and the remaining subset
randomSubseq' :: MonadRandom m => Int -> Seq a -> m (Seq a, Seq a)
randomSubseq' n _   | n < 0 = error "Utility.randomSublist': Cannot take negative amount of elements from a list."
randomSubseq' 0 lst = return (Seq.empty,lst)
randomSubseq' n lst | Seq.null lst = return (Seq.empty, Seq.empty)
                    | otherwise  =
    do (Just e, rest) <- randomSeqElement' lst
       (sub,rest') <- randomSubseq' (n-1) rest
       return (e Seq.<| sub, rest')

-- * Sets

-- | Get random element from a set
randomSetElement :: (Ord a, MonadRandom m) => Set a -> m (Maybe a)
randomSetElement set = fst <$> randomSetElement' set

-- | Get random element from a set, and also the remaining set without that element
randomSetElement' :: (MonadRandom m, Ord a) => Set a -> m (Maybe a, Set a)
randomSetElement' set | Set.null set = return (Nothing, Set.empty)
                      | otherwise =
    do i <- getRandomR (0, Set.size set - 1)
       e <- return $ Set.elemAt i set
       return (Just e, Set.delete e set)

-- | Get a random subset of a set
randomSubset :: (Ord a, MonadRandom m) => Int -> Set a -> m (Set a)
randomSubset n set = fst <$> randomSubset' n set

-- | Get a random subset of a set, and also its complement
randomSubset' :: (MonadRandom m, Ord a) => Int -> Set a -> m (Set a, Set a)
randomSubset' n _   | n < 0 = error "Utility.randomSubset': Cannot take negative amount of elements from a set."
randomSubset' 0 set              = return (Set.empty, set)
randomSubset' n set | Set.null set = return (Set.empty, Set.empty)
                    | otherwise  =
    do (Just e, rest) <- randomSetElement' set
       (sub,rest') <- randomSubset' (n-1) rest
       return (Set.insert e sub, rest')
