

module Utility.Monadic
     ( module Utility.Monadic
     ) where

import           Control.Monad

maximumByM, minimumByM :: Monad m => (a -> a -> m Ordering) -> [a] -> m [a]
maximumByM f= go []
    where go xs []         = return xs
          go [] (y:ys)     = go [y] ys
          go (x:xs) (y:ys) = f x y >>= \ cmp -> case cmp of
              EQ -> go (y:x:xs) ys
              GT -> go (x:xs) ys
              LT -> go [y] ys
minimumByM f = maximumByM (\ x y -> other <$> f x y)
    where other EQ = EQ; other GT = LT; other LT = GT

unfoldrM :: Monad m => (b -> m (Maybe (a, b))) -> b -> m [a]
unfoldrM f x = f x >>= \ fx ->
    case fx of
        Just (a, b) -> (a :) <$> unfoldrM f b
        Nothing     -> return []

foldMapM :: (Monad f, Monoid m, Foldable t) => (a -> f m) -> t a -> f m
foldMapM f = foldr (liftM2 mappend . f) (return mempty)

repeatM :: (Monad m) => m a -> m [a]
repeatM m = do x <- m; rest <- repeatM m; return $ x : rest

concatMapM :: (Monad m, Traversable t) => (a -> m [b]) -> t a -> m [b]
concatMapM = ((.).(.)) (fmap concat) mapM

whileM_ :: (Monad m) => m Bool -> m a -> m ()
whileM_ b f =
    do condition <- b
       if condition
       then f >> whileM_ b f
       else return ()

sortByM :: (Monad m) => (a -> a -> m Ordering) -> [a] -> m [a]
sortByM cmp = mergeAll <=< sequences
  where
    sequences (a:b:xs) = do
      ord <- cmp a b
      case ord of
        GT -> descending b [a] xs
        _  -> ascending b (a:) xs
    sequences xs = return [xs]

    descending a as cs@(b:bs) = do
      ord <- cmp a b
      case ord of
        GT -> descending b (a:as) bs
        _  -> liftM ((a:as) :) $ sequences cs
    descending a as bs = liftM ((a:as) :) $ sequences bs

    ascending a as cs@(b:bs) = do
      ord <- cmp a b
      case ord of
        GT -> liftM (as [a] :) $ sequences cs
        _  -> ascending b (\ys -> as (a:ys)) bs
    ascending a as bs = liftM (as [a] :) $ sequences bs

    mergeAll [x] = return x
    mergeAll xs  = mergeAll =<< (mergePairs xs)

    mergePairs (a:b:xs) = liftM2 (:) (merge a b) $ mergePairs xs
    mergePairs xs       = return xs

    merge as@(a:as') bs@(b:bs') = do
      ord <- cmp a b
      case ord of
        GT -> liftM (b :) $ merge as  bs'
        _  -> liftM (a :) $ merge as' bs
    merge [] bs = return bs
    merge as [] = return as
