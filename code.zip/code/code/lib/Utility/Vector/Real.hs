

module Utility.Vector.Real
     ( module Utility.Vector.Real
     ) where

import qualified Data.Vector.Unboxed    as V

import           Utility
import qualified Utility.Vector.Generic as G

dot :: V.Vector Double -> V.Vector Double -> Double
dot = V.sum `owl` V.zipWith (*)

plus, minus, times :: V.Vector Double -> V.Vector Double -> V.Vector Double
plus = G.plus
minus = G.minus
times = G.times

norm = G.norm dot
normalize = G.normalize dot
proj = G.proj dot
unproj = G.unproj dot

orthonormalize = G.orthonormalize dot
