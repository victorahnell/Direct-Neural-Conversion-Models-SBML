

module Utility.Vector.Generic
     ( module Utility.Vector.Generic
     ) where

import           Data.Foldable
import qualified Data.Vector.Unboxed as V

plus, minus, times :: (Num c, V.Unbox c) => V.Vector c -> V.Vector c -> V.Vector c
plus x y  = V.zipWith (+) x y
minus x y = V.zipWith (-) x y
times x y = V.zipWith (*) x y

norm :: (Floating c, V.Unbox c) => (V.Vector c -> V.Vector c -> c) -> V.Vector c -> c
norm dot vec = sqrt $ dot vec vec
normalize :: (Floating c, V.Unbox c) => (V.Vector c -> V.Vector c -> c) -> V.Vector c -> V.Vector c
normalize dot vec = V.map (/n) vec where n = norm dot vec
proj, unproj :: (Floating c, V.Unbox c) => (V.Vector c -> V.Vector c -> c) -> V.Vector c -> V.Vector c -> V.Vector c
proj dot x y = V.map (*r) x where r = dot x y / norm dot x
unproj dot x y = x `minus` proj dot y x

orthonormalize :: (Floating c, V.Unbox c) => (V.Vector c -> V.Vector c -> c) -> [V.Vector c] -> [V.Vector c]
orthonormalize dot vecs = go [] vecs
    where go lst []     = lst
          go lst (v:vs) =
              let v' = normalize dot $ foldl' (unproj dot) v lst
              in go (lst++[v']) vs
