
module Utility.Binary
     ( module Utility.Binary
     ) where

import           Data.Bits
import           Data.List

putBit :: Bits a => Bool -> a -> Int -> a
putBit True  = setBit
putBit False = clearBit

toBits :: Bits a => a -> [Bool]
toBits a = case bitSizeMaybe a of
               Nothing -> map (testBit a) [0 .. ]
               Just x  -> map (testBit a) [0 .. x - 1]

fromBits :: Bits a => [Bool] -> a
fromBits bs = foldl' (\x (b,i) -> putBit b x i) zeroBits (zip bs [0..])
