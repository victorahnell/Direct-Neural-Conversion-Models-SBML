{-# LANGUAGE BangPatterns               #-}
{-# LANGUAGE FlexibleContexts           #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE MagicHash                  #-}
{-# LANGUAGE MultiParamTypeClasses      #-}
{-# LANGUAGE UnboxedTuples              #-}

module Utility.RungeKutta
     ( module Utility.RungeKutta
     ) where

import qualified Data.Vector.Unboxed as V

import           Utility

newtype StepSize = StepSize Double
newtype TimedVectorField = TimedVectorField (Time -> VectorField)
newtype VectorField = VectorField (V.Vector Double -> V.Vector Double)
newtype Time = Time Double deriving (Eq,Show)

applyField (VectorField f) = f


rungeKuttaStep' :: StepSize
               -> TimedVectorField
               -> (Time, V.Vector Double)
               -> (Time, V.Vector Double)
rungeKuttaStep' (StepSize h) (TimedVectorField f) (Time !t,!y) =
    let h' = h / 2.0
        t' = t + h'
        t'' = t + h
        plus = V.zipWith (+)
        times x = V.map (*x)
        k1 = (h'/3.0) `times` applyField (f (Time t))   y
        k2 = (h /3.0) `times` applyField (f (Time t'))  (y `plus` (h' `times` k1))
        k3 = (h /3.0) `times` applyField (f (Time t'))  (y `plus` (h' `times` k2))
        k4 = (h'/3.0) `times` applyField (f (Time t'')) (y `plus` (h  `times` k3))
    in (Time t'', y `plus` k1 `plus` k2 `plus` k3 `plus` k4)

rungeKuttaStep step field (time,x0) =
    snd $ rungeKuttaStep' step (TimedVectorField (const field)) (time,x0)

rungeKutta' :: StepSize
            -> TimedVectorField
            -> (Time, V.Vector Double)
            -> Time
            -> (Time, V.Vector Double)
rungeKutta' (StepSize h) (TimedVectorField f) (Time t0, y) (Time t)
    | t < t0 = error "Utility.RungeKutta.rungeKutta': Cannot do RungeKutta in reverse direction."
    | t == t0 = (Time t,y)
    | otherwise =
          doTimes nsteps step (Time t0, y)
          where step = rungeKuttaStep' (StepSize h) (TimedVectorField f)
                nsteps = round $ (t - t0) / h

rungeKutta h f y t =
    snd $ rungeKutta' h ((TimedVectorField . const) f) (Time 0, y) t

rungeKuttaList' :: StepSize -> TimedVectorField -> (Time, V.Vector Double) -> [Time] -> [(Time, V.Vector Double)]
rungeKuttaList' h f (t0,x0) (t:ts) =
    let (t',xt) = rungeKutta' h f (t0,x0) t
    in (t',xt) : rungeKuttaList' h f (t',xt) ts
rungeKuttaList' _ _ _ [] = []

rungeKuttaList h f y ts =
    map snd $ rungeKuttaList' h ((TimedVectorField . const) f) (Time 0, y) ts
