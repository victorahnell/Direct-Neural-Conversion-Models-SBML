
module Utility.Comonad
     ( module Utility.Comonad
     , module Control.Comonad
     ) where

import           Control.Comonad

putW :: Functor w => w a -> b -> w b
putW w x = const x <$> w

sequenceW :: (Comonad w, Functor t) => w (t a) -> t (w a)
sequenceW xs = fmap (putW xs) (extract xs)

mapW :: (Comonad w, Functor t) => (w a -> b) -> w (t a) -> t b
mapW f w = fmap f (sequenceW w)

maximumByW :: (Comonad w) => (w (a,a) -> Ordering) -> w [a] -> [a]
maximumByW f w = go (extract w) []
    where go [] ms = ms
          go (x:xs) [] = go xs [x]
          go (x:xs) (m:ms) = case f (putW w (x,m)) of
                                 GT -> go xs [x]
                                 EQ -> go xs (x:m:ms)
                                 LT -> go xs (m:ms)

maximumByW' :: (Comonad w, Ord b) => (w a -> b) -> w [a] -> [a]
maximumByW' f w = go (extract w) [] Nothing
    where go [] ms _ = ms
          go (x:xs) [] Nothing = go xs [x] ((Just . f . putW w) x)
          go (x:xs) (m:ms) (Just ord) = let ord' = (f . putW w) x
                                        in case ord' `compare` ord of
                                               GT -> go xs [x] (Just ord')
                                               EQ -> go xs (x:m:ms) (Just ord)
                                               LT -> go xs (m:ms) (Just ord)
          go _ _ _ = error "Utility.Comonad.maximumByW': Something went wrong."

tuple2W :: (Comonad w) => w (a, b) -> (w a, w b)
tuple2W w = let x = fmap fst w
                y = fmap snd w
            in (x,y)

mapTuple2W :: (Comonad w) => (w a -> b) -> w (a,a) -> (b,b)
mapTuple2W f w = let x = f (fst <$> w)
                     y = f (snd <$> w)
                 in (x,y)

onW :: Comonad w => (b -> b -> c) -> (w a -> b) -> w (a, a) -> c
onW f g = uncurry f . mapTuple2W g
