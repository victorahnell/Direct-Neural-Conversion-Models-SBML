{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module Utility.Pareto
     ( module Utility.Pareto
     , module Control.Newtype
     ) where

import           Control.Monad
import           Control.Newtype

class Pareto a where
    paretoCompare :: a -> a -> Maybe Ordering

    dominates :: a -> a -> Bool
    dominates x y = paretoCompare x y == Just GT

    dominar :: a -> a -> Maybe a
    dominar x y = case paretoCompare x y of
        Just GT   -> Just x
        Just LT   -> Just y
        otherwise -> Nothing

frontOn :: Pareto b => (a -> b) -> [a] -> [a]
frontOn f = go []
    where go fr (x:xs) =
              if or [ f y `dominates` f x | y <- fr ]
              then go fr xs
              else go (x : [ y | y <- fr, not (f x `dominates` f y) ])  xs
          go fr [] = fr

front :: Pareto a => [a] -> [a]
front = frontOn id


newtype Paretoize a = Paretoize a
instance Ord a => Pareto (Paretoize a) where
    paretoCompare (Paretoize a) (Paretoize b) = Just (compare a b)
instance Newtype (Paretoize a) a where
    pack = Paretoize
    unpack (Paretoize x) = x

direction = direction' EQ
    where direction' EQ (d:ds)  = direction' d ds
          direction' d' (d:ds)  | d == EQ = direction' d' ds
                                | d == d' = direction' d' ds
                                | otherwise = Nothing
          direction' d  []      = Just d


instance Pareto a => Pareto [a] where
    paretoCompare x y =
        join $ direction <$> zipWithM paretoCompare x y

instance (Pareto a, Pareto b) => Pareto (a,b) where
    paretoCompare (x,y) (x',y') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y' ]

instance (Pareto a, Pareto b, Pareto c) => Pareto (a,b,c) where
    paretoCompare (x,y,z) (x',y',z') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d) => Pareto (a,b,c,d) where
    paretoCompare (x,y,z,w) (x',y',z',w') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d, Pareto e) => Pareto (a,b,c,d,e) where
    paretoCompare (x,y,z,w,v) (x',y',z',w',v') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w'
            , paretoCompare v v' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d, Pareto e, Pareto f) => Pareto (a,b,c,d,e,f) where
    paretoCompare (x,y,z,w,v,u) (x',y',z',w',v',u') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w'
            , paretoCompare v v'
            , paretoCompare u u' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d, Pareto e, Pareto f, Pareto g) => Pareto (a,b,c,d,e,f,g) where
    paretoCompare (x,y,z,w,v,u,t) (x',y',z',w',v',u',t') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w'
            , paretoCompare v v'
            , paretoCompare u u'
            , paretoCompare t t' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d, Pareto e, Pareto f, Pareto g, Pareto h) => Pareto (a,b,c,d,e,f,g,h) where
    paretoCompare (x,y,z,w,v,u,t,s) (x',y',z',w',v',u',t',s') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w'
            , paretoCompare v v'
            , paretoCompare u u'
            , paretoCompare t t'
            , paretoCompare s s' ]

instance (Pareto a, Pareto b, Pareto c, Pareto d, Pareto e, Pareto f, Pareto g, Pareto h, Pareto i) => Pareto (a,b,c,d,e,f,g,h,i) where
    paretoCompare (x,y,z,w,v,u,t,s,r) (x',y',z',w',v',u',t',s',r') =
        join $ direction <$> sequence
            [ paretoCompare x x'
            , paretoCompare y y'
            , paretoCompare z z'
            , paretoCompare w w'
            , paretoCompare v v'
            , paretoCompare u u'
            , paretoCompare t t'
            , paretoCompare s s'
            , paretoCompare r r' ]
