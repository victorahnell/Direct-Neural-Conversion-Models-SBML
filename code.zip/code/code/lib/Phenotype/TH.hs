

module Phenotype.TH
     ( Description, GPMap, gpmap, parameters, forParams, parameter
     , describe, buildPheno, typed
     ) where

import           Phenotype.TH.Builder
import           Phenotype.TH.Description
