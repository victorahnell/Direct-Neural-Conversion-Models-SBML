

module Phenotype.ReactionNetwork.Plot
     ( module Phenotype.ReactionNetwork.Plot
     ) where

import           Data.Colour
import           Data.Colour.SRGB
import           Graphics.Rendering.Chart
import           Graphics.Rendering.Chart.Backend.Cairo
import           Graphics.Rendering.Chart.Easy
import           Graphics.Rendering.Chart.Grid

import           Phenotype.ReactionNetwork.Deterministic (Time)

color1 = sRGB 0.368417 0.506779 0.709798
color2 = sRGB 0.880722 0.611041 0.142051
color3 = sRGB 0.560181 0.691569 0.194885

plotData :: [(x, y)] -> EC (Layout x y) ()
plotData vals =
    do plot . liftEC $
           do plot_lines_values                .= [vals]
              plot_lines_style . line_color    .= opaque color2
       plot . liftEC $
           do plot_points_values               .= vals
              plot_points_style . point_color  .= opaque black
              plot_points_style . point_radius .= 2

plotModel :: [(x, y)] -> EC (Layout x y) ()
plotModel vals = plot . liftEC $
    do plot_lines_values                       .= [vals]
       plot_lines_style . line_color           .= opaque color1
       plot_lines_style . line_width           .= 1.5

plotErrData :: [(x, (y,y,y))] -> EC (Layout x y) ()
plotErrData vals =
    let dat (x,(_,y,_)) = (x,y)
        dats = map dat vals
        err (x,(bot,y,top)) = ErrPoint (ErrValue x x x) (ErrValue bot y top)
        errs = map err vals
    in do plot . liftEC $
              do plot_errbars_values                  .= errs
                 plot_errbars_line_style . line_color .= black `withOpacity` 0.3
          plotData dats

plotC :: [(Time, vec)] -> [(Time, vec)] -> (String, vec -> y) -> EC (Layout Double y) ()
plotC dat model (title,f) =
    do layout_title .= title
       plotData  [ (time, f d) | (time, d) <- dat ]
       plotModel [ (time, f m) | (time, m) <- model ]

plotCs :: PlotValue y => [(Time, vec)] -> [(Time, vec)] -> [(String, vec -> y)] -> [Layout Double y]
plotCs dat model = map (execEC . plotC dat model)

gridify :: (Ord x, Ord y) => Int -> [Layout x y] -> Grid (Renderable (LayoutPick x y y))
gridify rowlen =
    aboveN . map besideN . divideRows . map layoutToGrid
    where divideRows []   = []
          divideRows plts = take rowlen plts : divideRows (drop rowlen plts)

plotGrid :: FileOptions -> FilePath -> Grid (Renderable a) -> IO ()
plotGrid options file = (>>return()) . renderableToFile options file . gridToRenderable

a4landscape dpi = FileOptions (round (dpi*a4height), round (dpi*a4width)) PDF
    where a4height = 11.69
          a4width  = 8.27
