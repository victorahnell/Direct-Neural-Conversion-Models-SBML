{-# LANGUAGE FlexibleInstances    #-}
{-# LANGUAGE ScopedTypeVariables  #-}
{-# LANGUAGE TypeFamilies         #-}
{-# LANGUAGE UndecidableInstances #-}

module Phenotype.ReactionNetwork.Definition
     ( module Phenotype.ReactionNetwork.Definition
     ) where

import           Control.Applicative (liftA2)
import           Data.Fixed.Vector

-- * Compound.
--   Each application will require its own datatype to capture the relevant
--   compounds.
class (Show c, Enum c, Ord c, Bounded c) => Compound c

type ConcentrationVec c i = IxVector (EnumIx c) i
type MolarVec c = ConcentrationVec c Double
type MolesVec c = ConcentrationVec c Int

discretize :: Compound c => MolarVec c -> MolesVec c
discretize = ixMap round
undiscretize :: Compound c => MolesVec c -> MolarVec c
undiscretize = ixMap fromIntegral

type ConcentrationTerm c i = ConcentrationVec c i -> i
type Molar c = ConcentrationTerm c Double
type Moles c = ConcentrationTerm c Int

concentration :: (Compound c, Unbox i) => c -> ConcentrationTerm c i
concentration = flip (!)

-- | Concentration of a complex of two compounds, given a dissociation
--   constant, the total concentrations of the two compounds and assuming
--   that complex formation is in equilibrium.
--   The Floating type can be of type.DeterministicC.
complex2With :: Floating a => a -> a -> a -> a
complex2With kd a b =
    let sym = (a + b + kd) / 2
    in sym - sqrt (sym*sym - a*b)

-- | A Reaction. It is defined by a reaction rate, i.e. a function of the
--   concentration vector, i.e. a concentration Term, and a discrete
--   concentration vector describing the stoichiometric coefficients.
data Reaction c = Reaction (Molar c) (MolesVec c)

-- | A network of reactions, simply a list.
type ReactionNetwork c = [Reaction c]

-- | Vector field, a map from contentration to a concentration gradient
type ReactionGradient c = MolarVec c -> MolarVec c

instance (Compound c, Num i) => Num (ConcentrationTerm c i) where
    (+) = liftA2 (+)
    (*) = liftA2 (*)
    abs = (.) abs
    signum = (.) signum
    negate = (.) negate
    fromInteger = const . fromInteger

instance (Compound c, Fractional i) => Fractional (ConcentrationTerm c i) where
    (/) = liftA2 (/)
    fromRational = const . fromRational

instance (Compound c, Floating i) => Floating (ConcentrationTerm c i) where
    pi = const pi
    exp = (.) exp
    log = (.) log
    sin = (.) sin
    cos = (.) cos
    asin = (.) asin
    acos = (.) acos
    atan = (.) atan
    sinh = (.) sinh
    cosh = (.) cosh
    asinh = (.) asinh
    acosh = (.) acosh
    atanh = (.) atanh
