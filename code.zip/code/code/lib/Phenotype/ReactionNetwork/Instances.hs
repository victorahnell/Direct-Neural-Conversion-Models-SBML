{-# LANGUAGE FlexibleInstances   #-}
{-# LANGUAGE ScopedTypeVariables #-}

module Phenotype.ReactionNetwork.Instances
     ( module Phenotype.ReactionNetwork.Instances
     ) where

import           Control.Applicative
import qualified Data.Vector.Unboxed                  as V

import           Phenotype.ReactionNetwork.Definition

instance (Compound c, V.Unbox i, Num i) => Num (CVec c i) where
    (CVec x) + (CVec y) = CVec (V.zipWith (+) x y)
    (CVec x) * (CVec y) = CVec (V.zipWith (*) x y)
    abs (CVec x) = CVec (V.map abs x)
    signum (CVec x) = CVec (V.map signum x)
    negate (CVec x) = CVec (V.map negate x)
    -- | Should probably only be used to initiate 0 concentration vector.
    fromInteger = fromConstant . fromInteger

instance (Compound c, V.Unbox i, Fractional i) => Fractional (CVec c i) where
    (CVec x) / (CVec y) = CVec (V.zipWith (/) x y)
    fromRational = fromConstant . fromRational

instance (Compound c, V.Unbox i, Num i) => Num (CVec c i -> i) where
    (+) = liftA2 (+)
    (*) = liftA2 (*)
    abs = fmap abs
    signum = fmap signum
    negate = fmap negate
    fromInteger = const . fromInteger

instance (Compound c, V.Unbox i, Fractional i) => Fractional (CVec c i -> i) where
    (/) = liftA2 (/)
    fromRational = const . fromRational

instance (Compound c, V.Unbox i, Floating i) => Floating (CVec c i -> i) where
    (**) = liftA2 (**)
    pi = const pi
    exp = fmap exp
    log = fmap log
    sin = fmap sin
    cos = fmap cos
    asin = fmap asin
    acos = fmap acos
    atan = fmap atan
    sinh = fmap sinh
    cosh = fmap acosh
    asinh = fmap asinh
    acosh = fmap acosh
    atanh = fmap atanh
