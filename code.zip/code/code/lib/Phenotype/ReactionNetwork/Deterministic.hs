{-# LANGUAGE BangPatterns #-}

module Phenotype.ReactionNetwork.Deterministic
     ( module Phenotype.ReactionNetwork.Deterministic
     ) where

import           Data.Fixed.Vector

import           System.IO.Unsafe

type StepSize = Double
type TimedVectorField ix = Time -> VectorField ix
type VectorField ix = IxVector ix Double -> IxVector ix Double
type Time = Double


data ODESolver ix = ODESolver
    { step  :: (StepSize -> (Time, IxVector ix Double) -> (Time, IxVector ix Double))
    , order :: ! Int }

solve :: Index ix => VectorField ix -> (Time, IxVector ix Double) -> [Time] -> [(Time, IxVector ix Double)]
solve f ini ts = adaptiveStepSize (0.01, 0.05 / (maximum ts - minimum ts)) (rk4 f) ini ts
    -- constantStepSize ((maximum ts - minimum ts) / 100) (rk4 f) ini ts

constantStepSize :: Index ix => StepSize -> ODESolver ix -> (Time, IxVector ix Double) -> [Time] -> [(Time, IxVector ix Double)]
constantStepSize _ _   _          []     = []
constantStepSize h sol ini@(t0,_) (t:ts) = if t0 + h >= t
    then let !r = step sol (t-t0) ini in r : constantStepSize h sol r ts
    else let !r = step sol h      ini in     constantStepSize h sol r (t:ts)

adaptiveStepSize :: Index ix => (Double, Double) -> ODESolver ix -> (Time, IxVector ix Double) -> [Time] -> [(Time, IxVector ix Double)]
adaptiveStepSize (tolabs, tolrel) sol ini times = go 1 ini times
    where p = order sol
          p' = 1 / (fromIntegral p + 1)
          go _ _ [] = []
          go !h (!t0,!x0) (!t1:ts) =
              let (_, !x_0) = step sol h (t0,x0)
                  (!t,!x_1) = step sol (h/2) . step sol (h/2) $ (t0,x0)

                  !err = abs (x_1 - x_0)
                  !norm = (/h) . ixMax $ ixZipWith (\ v u -> abs v / (tolabs + tolrel * abs u)) err x_1




                --   !err = abs (x_1 - x_0)
                --   !d = ixMax err
                --   !q = ixMax $ err / ixZipWith min (abs x_0) (abs x_1)
                --   !delta = tolabs / d `min` tolrel / q


                --   !err = ixMax $ ixZipWith (\ v u -> abs v / (tolabs + tolrel * u)) x_0 x_1
                --   !e = ixMap (/ (2^p - 1)) (x_1 - x_0)
                --   !delta = (ixMax . abs) e
                  !h' = 0.9 * h * clip ((1/norm) ** p')

                --   !tol' = tol * h
                --   !delta = (ixMax . abs) (x_1 - x_0) -- Difference is an estimate of the local truncation error, on the order of methodorder+1
                --   !q = (tol' / delta) ** (1/(fromIntegral (order sol)) + 1)
                  clip x = min 2 (max 0.1 x)
                --   !h' = 0.9 * h * clip q

                  prnt s a = unsafePerformIO $ print s >> return a

              in if norm > 1
                 then go h' (t0,x0) (t1:ts)
                 else if t > t1
                      then let !r = step sol (t1-t0) (t0,x0) in r : go h' r ts
                      else go h' (t,x_1 + err / (2^p - 1)) (t1:ts)


rk4 :: Index ix => VectorField ix -> ODESolver ix
rk4 f = ODESolver
    { order = 4
    , step = rkstep }
    where x .* v = ixMap (*x) v
          rkstep h (t,x) =
              let !h' = h / 2
                  !k1 = (h'/3.0) .* f  x
                  !k2 = (h /3.0) .* f (x + (h' .* k1))
                  !k3 = (h /3.0) .* f (x + (h' .* k2))
                  !k4 = (h'/3.0) .* f (x + (h' .* k3))
                  !x' = x + k1 + k2 + k3 + k4
               in (t + h, x')

forwardEuler :: Index ix => VectorField ix -> ODESolver ix
forwardEuler f = ODESolver
    { order = 1
    , step = eulerStep }
    where eulerStep h (t0,x0) = (t0 + h, x0 + ixMap (*h) (f x0))
