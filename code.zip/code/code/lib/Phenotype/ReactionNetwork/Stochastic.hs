

module Phenotype.ReactionNetwork.Stochastic
     ( module Phenotype.ReactionNetwork
     , module Phenotype.ReactionNetwork.Stochastic
     ) where

import           Data.Fixed.Vector

import           Control.Monad.Random
import           Data.List

import           Phenotype.ReactionNetwork

-- | One step in a Gillespie SSA.
--   Computes the next reaction and the time at which it occurs, and returns an updated state.
--   The first argument can be used to arbitrarily change the scale of the reactions. A higher value means more noise.
gillespieStep' :: (MonadRandom m, Compound c) => (Reaction c -> Double) -> ReactionNetwork c -> (Double, MolarVec c) -> m (Double, MolarVec c)
gillespieStep' noisef network (t0, x0) =
    do let rates = [ rate x0 / noisef r | r@(Reaction rate _) <- network ]
       let a0 = sum rates
       r1 <- getRandom
       r2 <- getRandom

       let tau = - log r1 / a0
       let Just mu = findIndex (>= r2*a0) (scanl1 (+) rates)
       let ru@(Reaction _ delta') = network !! mu
       let delta = ixReplicate (noisef ru) * undiscretize delta'

       let t1 = t0 + tau
       let x1 = ixMap clip (x0 + delta) where clip x | x >= 0 = x | otherwise = 0

       return (t1, x1)

gillespieSteps' :: (MonadRandom m, Compound c) => (Reaction c -> Double) -> ReactionNetwork c -> Int -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieSteps' noisef network i xt0
    | i <= 0    = return [xt0]
    | otherwise = fmap (xt0:) $ gillespieStep' noisef network xt0 >>= gillespieSteps' noisef network (i-1)

gillespieUntil' :: (MonadRandom m, Compound c) => (Reaction c -> Double) -> ReactionNetwork c -> ((Double, MolarVec c) -> Bool) -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieUntil' noisef network f xt0
    | f xt0     = return [xt0]
    | otherwise = fmap (xt0:) $ gillespieStep' noisef network xt0 >>= gillespieUntil' noisef network f

gillespieTimes' :: (MonadRandom m, Compound c) => (Reaction c -> Double) -> ReactionNetwork c -> [Double] -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieTimes' _     _       []       xt0 = return [xt0]
gillespieTimes' noisef network (t:ts) xt0@(t0,_)
    | t0 >= t   = fmap (xt0:) $ gillespieTimes' noisef network ts xt0
    | otherwise = gillespieStep' noisef network xt0 >>= gillespieTimes' noisef network (t:ts)

gillespieStep :: (Compound c, MonadRandom m) => Double -> ReactionNetwork c -> (Double, MolarVec c) -> m (Double, MolarVec c)
gillespieSteps :: (Compound c, MonadRandom m) => Double -> ReactionNetwork c -> Int -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieUntil :: (Compound c, MonadRandom m) => Double -> ReactionNetwork c -> ((Double, MolarVec c) -> Bool) -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieTimes :: (Compound c, MonadRandom m) => Double -> ReactionNetwork c -> [Double] -> (Double, MolarVec c) -> m [(Double, MolarVec c)]
gillespieStep  noise = gillespieStep'  (const noise)
gillespieSteps noise = gillespieSteps' (const noise)
gillespieUntil noise = gillespieUntil' (const noise)
gillespieTimes noise = gillespieTimes' (const noise)
