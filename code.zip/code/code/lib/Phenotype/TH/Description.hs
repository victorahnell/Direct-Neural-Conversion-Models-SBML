
module Phenotype.TH.Description
     ( module Phenotype.TH.Description.Description
     ) where

import           Phenotype.TH.Description.Description
import           Phenotype.TH.Description.Instances   ()
