{-# LANGUAGE FlexibleContexts           #-}
{-# LANGUAGE FlexibleInstances          #-}
{-# LANGUAGE GADTs                      #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE MultiParamTypeClasses      #-}
{-# LANGUAGE RankNTypes                 #-}
{-# LANGUAGE TemplateHaskell            #-}
{-# LANGUAGE TypeOperators              #-}

module Phenotype.TH.Builder.Builder
     ( module Phenotype.TH.Builder.Builder
     ) where

import           Control.Monad.Writer
import           Data.Typeable
import           Language.Haskell.TH
import qualified Language.Haskell.TH.Syntax as TH
import Data.Dynamic

import           Genome.Split
import           Phenotype.TH.Description


-- | A GenomeBuilder is a Monad used to build a function with many parameters.
--   Its use is based on three ideas:
--     - buildParam: a function that creates a new Parameter.
--     - Monad: the Monad instance allows extracting and combining the
--         of parameters built by buildParam, into a function result.
--     - buildPheno: finally used to convert a GenomeBuilder to a
--         GPMap, i.e. a function with attached parameter documentation.
--         The argument type of the GPMap is built up from the parameter
--         types using Genome.Split.
newtype GenomeBuilder a = GenomeBuilder (WriterT [Description ParameterD Parameter] Q a)
    deriving (Functor, Applicative, Monad)

liftBuilder :: Q a -> GenomeBuilder a
liftBuilder = GenomeBuilder . lift

data GPMap g p = GPMap { gpmap      :: g -> p
                       , parameters :: [Parameter]
                       , lookupParam :: forall x. Typeable x => g -> String -> Maybe x
                       }

data Parameter where Parameter :: forall g p.
                           { param_info  :: String
                           , param_gname :: Name
                           , param_pname :: Name
                           , param_gtype :: TypeRep
                           , param_ptype :: TypeRep
                           , param_func  :: g -> p } -> Parameter

instance Show Parameter where
    show p =
        param_info p

forParams :: Typeable a => (a -> b) -> GPMap g p -> g -> [(Parameter, Maybe b)]
forParams f gp g =
    map go (parameters gp)
    where go (p@Parameter{param_info=info}) =
              (p, f <$> lookupParam gp g info)

data ParameterD where
    ParameterD :: forall p. { paramD_info :: String, paramD_gname :: Name, paramD_pname :: Name, paramD_func :: Parametric p} -> ParameterD

instance ParameterD `Describes` Parameter where
    describe' _(ParameterD info gname pname (Parametric func)) =
        do (ArrowT `AppT` gtype) `AppT` ptype <- typescribe func
           [e| Parameter { param_info = $(TH.lift info)
                         , param_gname = (mkName $(TH.lift (show gname)))
                         , param_pname = (mkName $(TH.lift (show pname)))
                         , param_gtype = (typeRep ([]::[$(return gtype)]))
                         , param_ptype = (typeRep ([]::[$(return ptype)]))
                         , param_func  = $(describeNoCSE func) } |]

describeFunc :: ParameterD -> ExpQ
describeFunc (ParameterD _ _ _ (Parametric fun)) = describeNoCSE fun

-- | Read a GenomeBuilder as a Description of a GPMap.
--   NOTE: While the g in the return type is universally quantified, it should actually be existentially quantified.
--   That is, this function will match any g in its return value. In reality, there is only one matching g,
--   it is simply unknown what that g is at compile time (the genome type is built up by TH code).
--   This type signature and the below Describes instance are therefore not entirely correct.
buildPheno :: a `Describes` p => GenomeBuilder (Description a p) -> Description (GenomeBuilder (Description a p)) (GPMap g p)
buildPheno builder = Description Nothing builder

instance a `Describes` p => GenomeBuilder (Description a p) `Describes` GPMap g p where
    describe' _ builder =
        do (p, params) <- let GenomeBuilder b = builder in runWriterT b
           genomename <- newName "genome"
           descname <- newName "desc"
           let genomepat = varP genomename
           let vardecs   = declareVars params genomename
           let body      = liftM2 LetE vardecs (describeNoCSE p)
           let lookupbody = liftM2 LetE vardecs $ return (LamE [VarP descname] $ CaseE (VarE descname) (matchParamLookup params))
           let parexp    = describeNoCSE (list'D params)
           [e| GPMap { gpmap = \ $genomepat -> $body
                     , parameters = $parexp
                     , lookupParam = \ $genomepat -> $lookupbody } |]
        where declareVars [] g' = [d| () = $(varE g') |]
              declareVars (p:ps) g' =
                  do g'' <- newName "gpart"
                     let g = paramD_gname . transcribe $ p
                     let x = paramD_pname . transcribe $ p
                     let f = describeFunc . transcribe $ p
                     new   <- [d| ($(varP g), $(varP g'')) = split $(varE g');
                                   $(varP x)               = $f $(varE g);     |]
                     other <- declareVars ps g''
                     return $ new ++ other
              matchParamLookup [] = [Match WildP (NormalB (ConE 'Nothing)) []]
              matchParamLookup (p:ps) =
                  let info = paramD_info . transcribe $ p
                      name = paramD_pname . transcribe $ p
                  in Match (LitP (StringL info)) (NormalB (VarE 'fromDynamic `AppE` (VarE 'toDyn `AppE` VarE name))) []
                     : matchParamLookup ps




instance a `DescribesType` p => GenomeBuilder (Description a p) `DescribesType` GPMap g p where
    typescribe' _ builder =
        do (p, params) <- let GenomeBuilder b = builder in runWriterT b
           let genotype  = foldr (\ x r -> [t| Unsplit $r $x |] ) [t|()|] (map gtype params)
           let phenotype = typescribe p
           [t| GPMap $genotype $phenotype |]
        where gtype (Description { transcribe = (ParameterD _ _ _ (Parametric func)) }) =
                  do (ArrowT `AppT` gt) `AppT` pt <- typescribe func
                     return gt



-- | Wrapper type for simplifying type signatures of functions that add genes to a GenomeBuilder.
data Parametric p where
    Parametric :: forall a g p. (a `DescribesType` (g -> p), Typeable p) => Description a (g -> p) -> Parametric p

parameter :: Typeable p => (g -> p) -> Name -> Parametric p
parameter f name = Parametric $ name'D f name

paramDesc :: (Typeable p, a `DescribesType` p) => Description a p -> Parametric p
paramDesc d = Parametric $ unsafeDescription [e|\ () -> $(describe d) |] `typed` [t|() -> $(typescribe d)|]

constantDouble :: Double -> Parametric Double
constantDouble x = Parametric $ unsafeDescription [e|\ () -> $(TH.lift x) |] `typed` [t|() -> Double|]

constantInt :: Int -> Parametric Int
constantInt x = Parametric $ unsafeDescription [e|\() -> $(TH.lift x) |] `typed` [t|() -> Int|]

constantInteger :: Integer -> Parametric Integer
constantInteger x = Parametric $ unsafeDescription [e|\() -> $(TH.lift x) |] `typed` [t|() -> Integer|]


-- | Generate a GenomeBuilder with one parameter.
--   Normal usage is in do notation to add a new gene to the genome being built (see examples).
buildParam :: String -> Parametric p -> GenomeBuilder (Description ExpQ p)
buildParam info param =
    do gname <- liftBuilder $ newName "g"
       pname <- liftBuilder $ newName "p"
       GenomeBuilder . tell $ [Description Nothing (ParameterD info gname pname param)]
       return . unsafeDescription $ varE pname
