{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TemplateHaskell       #-}
{-# LANGUAGE TypeOperators         #-}

module Phenotype.TH.ReactionNetwork
     ( module Phenotype.ReactionNetwork
     , module Phenotype.TH.ReactionNetwork
     , module Phenotype.TH.Builder
     , module Phenotype.TH
     , StepSize, Time, VectorField
     ) where

import           Data.Fixed.Vector
import           Data.List                               (intercalate)
import qualified Data.Map.Lazy                           as M
import qualified Data.Vector.Unboxed                     as V
import           Language.Haskell.TH
import qualified Language.Haskell.TH.Syntax              as TH

import           Phenotype.ReactionNetwork
import           Phenotype.ReactionNetwork.Deterministic
import           Phenotype.TH
import           Phenotype.TH.Builder
import           Phenotype.TH.Description

-- * Concentration terms.

type Molar'D c = Function'D (MolarVec c) Double
type Moles'D c = Function'D (MolesVec c) Double

-- | A concentration term description representing the concentration of a
--   single compound.
--   Use together with conF and basic arithmetic functions to build more
--   complex functions of the concentration vector as needed.
c :: Compound c => c -> Molar'D c
c x = (unsafeFunction'D $ \ v -> fixName ("c_" ++ show x) [e| toVector $(varE v) V.! $(TH.lift (fromEnum x)) |])
      { document = Just ("[" ++ show x ++ "]") }

-- | The concentration of a complex of two compounds.
--   Builds a parameter to decide the dissociation constant.
complex2' :: Compound c => Parametric Double -> c -> c -> GenomeBuilder (Molar'D c)
complex2' param a b =
    do k <- buildParam info param
       let Description { transcribe = f } = complex2With (conF k) (c a) (c b)
       return $ Description (Just doc) (\ x -> fixName name (f x))
    where info = "Dissociation constant [" ++ show a ++ "|" ++ show b ++ "]"
          name = "complex " ++ show a ++ "|" ++ show b
          doc = "[" ++ show a ++ "|" ++ show b ++ "]"

-- * Concentration vectors

type ConcentrationVec'D c i = Description (M.Map c i) (ConcentrationVec c i)
type MolarVec'D c = ConcentrationVec'D c Double
type MolesVec'D c = ConcentrationVec'D c Int

instance (Compound c, Num i, TH.Lift i) => M.Map c i `Describes` ConcentrationVec c i where
    describe' proxy m = describe' proxy $ M.map lift'D m
instance (a `Describes` i, Compound c, Num i) => M.Map c (Description a i) `Describes` ConcentrationVec c i where
    describe' _ m =
        [e| indexed . V.fromList $ $concentrations |]
        where concentrations = listE $ [ describeNoCSE $ M.findWithDefault 0 x $ M.map flatten m | x <- [minBound..maxBound] ]

ixVector'D :: Compound c => M.Map c i -> ConcentrationVec'D c i
ixVector'D = Description Nothing

buildVector :: forall c i. Compound c => String -> Parametric i -> GenomeBuilder (Description ExpQ (ConcentrationVec c i))
buildVector info param =
    do xs <- sequence [ buildParam (info ++ " value for " ++ show x) param | x <- [minBound .. maxBound::c] ]
       return $ unsafeDescription [e| indexed . V.fromList $ $((listE . map transcribe) xs) |]

-- * Reactions

type Reaction'D c = Description (Molar'D c, MolesVec'D c) (Reaction c)

instance (rate `Describes` Molar c, stoich `Describes` MolesVec c)
    => (Description rate (Molar c), Description stoich (MolesVec c)) `Describes` Reaction c where
    describe' _ (term, stoich) = [e| Reaction $(describe term) $(describe stoich) |]

reaction'D :: Compound c => Molar'D c -> MolesVec'D c -> Reaction'D c
reaction'D rate stoich = Description Nothing (rate, stoich)

creation :: Compound c => c -> Molar'D c -> Reaction'D c
creation x rate = reaction'D rate . ixVector'D $ M.singleton x 1

destruction :: Compound c => c -> Molar'D c -> Reaction'D c
destruction x rate = reaction'D rate . ixVector'D $ M.singleton x (-1)

-- | Mass action reaction, using the supplied value as the rate constant.
--   Add the same compound multiple times to the substrate or product list
--   to represent different stoichiometric coefficients.
massActionWith :: (a `Describes` Double, Compound c) => Description a Double -> [c] -> [c] -> Reaction'D c
massActionWith k substrates products =
    reaction'D (rate k) stoich
    where rate k = conF k * product (map c substrates)
          stoich = ixVector'D . M.fromListWith (+)
                 $ map (\x->(x,1)) substrates ++ map (\x->(x,-1)) products

-- | Mass action reaction, building a parameter to represent the rate
--   constant.
massAction' :: Compound c => Parametric Double -> [c] -> [c] -> GenomeBuilder (Reaction'D c)
massAction' param substrates products =
    do k <- buildParam info param
       return $ massActionWith k substrates products
    where info = "Mass action rate of (" ++ intercalate ", " (map show substrates)
                               ++ " -> " ++ intercalate ", " (map show products) ++ ")"

-- | A decay reaction, proportional to the concentration of the decaying
--   compound and the supplied reaction rate.
decayWith :: (a `Describes` Double, Compound c) => Description a Double -> c -> Reaction'D c
decayWith k x =
    destruction x (rate k) { document = Just doc }
    where rate k = conF k * c x
          doc = "Decay of " ++ show x

-- | Proportional decay reaction, building a parameter representing the
--   rate constant.
decay' :: Compound c => Parametric Double -> c -> GenomeBuilder (Reaction'D c)
decay' param x =
    do k <- buildParam info param
       return $ decayWith k x
    where info = "Decay rate of " ++ show x

-- | Constant generation reaction, using the supplied value as reaction rate.
generationWith :: (a `Describes` Double, Compound c) => Description a Double -> c -> Reaction'D c
generationWith k x =
    creation x (rate k) { document = Just doc }
    where rate k = conF k
          doc = "Generation of " ++ show x

-- | Constant generation reaction, building a parameter to represent the rate
--   constant.
generation' :: Compound c => Parametric Double -> c -> GenomeBuilder (Reaction'D c)
generation' param x =
    do k <- buildParam info param
       return $ generationWith k x
    where info = "Generation rate of " ++ show x

-- | A transcription reaction following Shea-Akers kinetics, i.e. generation
--   of the given compound with Hill kinetics using n activators and m inhibitors.
--   The resulting reaction increases the concentration of the transcribed
--   compound by one, and has a rate of the form:
--       Vmax * (bg + act1 + act2 + ...) / (1 + bg + act1 + act2 + ... + inh1 + inh2 + ...)
--   Where act and inh are of the form (concentration / coefficient) ^ hill
--   The background term represents activation from a constant external source.
--   NOTE: If the transcription has no activators, the numerator is fixed to vmax,
--   and the background setting is overridden to 0.
transcription' :: Compound c => Parametric Double -> c -> Interaction c -> GenomeBuilder (Reaction'D c)
transcription' param x inters =
    do vmax <- buildParam ("Vmax transcription of " ++ show x) param
       act  <- activators inters
       inh  <- inhibitors inters
       rate <- if length act == 0
               then return $ conF vmax / (1 + sum inh)
               else do bg <- core inters
                       return $ conF vmax * ((bg + sum act) / (1 + bg + sum act + sum inh))
       return $ creation x rate { document = Just doc }
    where doc = "Transcription of " ++ show x
          inhibitors (Background _)         = return []
          inhibitors (NoBackground)         = return []
          inhibitors x@(Inhibition _ _ i c) = (:) <$> build x <*> inhibitors i
          inhibitors (Activation _ _ i _)   = inhibitors i
          activators (Background _)         = return []
          activators (NoBackground)         = return []
          activators (Inhibition _ _ i c)   = activators i
          activators x@(Activation _ _ i _) = (:) <$> build x <*> activators i
          core x@(Background _)     = build x
          core x@(NoBackground)     = build x
          core (Inhibition _ _ i _) = core i
          core (Activation _ _ i _) = core i
          build (Inhibition kf hf _ a) =
              do k <- buildParam ("Inhibition coef " ++ document' a ++ " --| " ++ show x) kf
                 h <- buildParam ("Inhibition hill " ++ document' a ++ " --| " ++ show x) hf
                 return $ (a / conF k) ** conF h
          build (Activation kf hf _ a) =
              do k <- buildParam ("Activation coef " ++ document' a ++ " --> " ++ show x) kf
                 h <- buildParam ("Activation hill " ++ document' a ++ " --> " ++ show x) hf
                 return $ (a / conF k) ** conF h
          build (Background f) =
              do k <- buildParam ("Background transcription " ++ show x) f
                 return $ conF k
          build NoBackground = return 0

-- | Represents activation and inhibition interactions, and whether or not
--   there is a background transcription rate in a Shea-Akers interaction.
--   Each inhibition and activation also carries values defining how to read
--   a coefficient and Hill parameter.
data Interaction c = Background (Parametric Double)
                   | NoBackground
                   | Inhibition (Parametric Double) (Parametric Double) (Interaction c) (Molar'D c)
                   | Activation (Parametric Double) (Parametric Double) (Interaction c) (Molar'D c)

nobackground = NoBackground
background' = Background
inhibitedBy' = Inhibition
activatedBy' = Activation


-- * Reaction Networks

type ReactionNetwork'D c = [Reaction'D c]

reactionNetwork :: Compound c => [Reaction'D c] -> Description (ReactionNetwork'D c) (ReactionNetwork c)
reactionNetwork = list'D

-- * Vector Field

type ReactionGradient'D c = Function'D (MolarVec c) (MolarVec c)

gradient :: Compound c => [Reaction'D c] -> ReactionGradient'D c
gradient lst =
    unsafeFunction'D $ \ v -> [e| indexed . V.fromList $ $(gradients v) |]
    where gradients v = listE [ transcribe (gradient x) v | x <- [minBound..maxBound] ]
          gradient x = sum [ term * conF (lift'D (fromIntegral n))
                       | Description { transcribe = (term, stoich) } <- lst
                       , let n = M.findWithDefault 0 x (transcribe stoich), n /= 0]
