{-# LANGUAGE FlexibleInstances   #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell     #-}


module Phenotype.TH.Description.Instances
     ( -- Only exporting instances
     ) where

import           Control.Monad
import           Data.Ratio
import           Language.Haskell.TH

import           Phenotype.TH.Description.Description

isIntegerL :: Exp -> Maybe Integer
isIntegerL (LitE (IntegerL x)) = Just x
isIntegerL (AppE (VarE name) (LitE (IntegerL x))) | name == 'fromInteger = Just x
isIntegerL (LitE (RationalL x)) | denominator x == 1 = Just (numerator x)
isIntegerL (AppE (VarE name) (LitE (RationalL x))) | name == 'fromRational && denominator x == 1 = Just (numerator x)
isIntegerL _ = Nothing
isRationalL :: Exp -> Maybe Rational
isRationalL (LitE (RationalL x)) = Just x
isRationalL (AppE (VarE name) (LitE (RationalL x))) | name == 'fromRational = Just x
isRationalL _ = Nothing


instance Num a => Num (Flat'D a) where
    x + y = Description {
        transcribe =
            do x' <- transcribe x
               y' <- transcribe y
               case isIntegerL x' of
                   Just 0 -> return y'
                   _ -> case isIntegerL y' of
                       Just 0 -> return x'
                       _      -> [e| $(return x') + $(return y') |]
      , document = liftM2 plusdoc (document x) (document y)
  } where plusdoc xdoc ydoc = xdoc ++ " + " ++ ydoc

    x - y = Description {
        transcribe =
            do x' <- transcribe x
               y' <- transcribe y
               case isIntegerL x' of
                   Just 0 -> transcribe (negate y)
                   _ -> case isIntegerL y' of
                       Just 0 -> return x'
                       _      -> [e| $(return x') - $(return y') |]
      , document = liftM2 minusdoc (document x) (document y)
  } where minusdoc xdoc ydoc = xdoc ++ " - " ++ ydoc

    x * y = Description {
        transcribe =
            do x' <- transcribe x
               y' <- transcribe y
               case isIntegerL x' of
                   Just 0 -> return x'
                   Just 1 -> return y'
                   Just (-1) -> transcribe (negate y)
                   _ -> case isIntegerL y' of
                       Just 0    -> return y'
                       Just 1    -> return x'
                       Just (-1) -> transcribe (negate x)
                       _         -> [e| $(return x') * $(return y') |]
      , document = liftM2 timesdoc (document x) (document y)
  } where timesdoc xdoc ydoc = xdoc ++ " " ++ ydoc

    negate x = Description (("-" ++) <$> (document x)) [e|- $(transcribe x) |]
    signum x = Description ((\d->"sgn ("++d++")") <$> (document x)) [e| signum $(transcribe x) |]
    abs x    = Description ((\d->"|"++d++"|") <$> (document x)) [e| abs    $(transcribe x) |]
    fromInteger x = Description (Just (show x)) (return (LitE (IntegerL x)))

instance Fractional a => Fractional (Flat'D a) where
    x / y = Description {
        transcribe =
            do x' <- transcribe x
               y' <- transcribe y
               case isIntegerL x' of
                   Just 0 -> return x'
                   _ -> case isIntegerL y' of
                       Just 1 -> return x'
                       Just 0 -> do reportWarning "Warning when dividing number descriptions: dividing by 0 literal."
                                    [e| $(return x') / $(return y') |]
                       _ -> [e| $(return x') / $(return y') |]
      , document = liftM2 divdoc (document x) (document y)
    } where divdoc xdoc ydoc = "(" ++ xdoc ++ ") / (" ++ ydoc ++ ")"
    fromRational x = Description (Just (show x)) (return (LitE (RationalL x)))

instance Floating a => Floating (Flat'D a) where
    x ** y = Description {
        transcribe =
            do x' <- transcribe x
               y' <- transcribe y
               case isIntegerL y' of
                   Just 1 -> return x'
                   Just 0 -> [e|1|]
                   _ -> case isIntegerL x' of
                       Just 1 -> return x'
                       Just 0 -> return x'
                       _      -> [e| $(return x') ** $(return y') |]
      , document = liftM2 expdoc (document x) (document y)
    } where expdoc xdoc ydoc = "(" ++ xdoc ++ ") ^ (" ++ ydoc ++ ")"
    pi = Description (Just "pi") [e| pi |]
    sqrt x   = Description ((\d->"sqrt ("++d++")") <$> document x) [e| sqrt $(transcribe x) |]
    exp x   = Description ((\d->"exp ("++d++")") <$> document x) [e| exp $(transcribe x) |]
    log x   = Description ((\d->"log ("++d++")") <$> document x) [e| log $(transcribe x) |]
    sin x   = Description ((\d->"sin ("++d++")") <$> document x) [e| sin $(transcribe x) |]
    cos x   = Description ((\d->"cos ("++d++")") <$> document x) [e| cos $(transcribe x) |]
    asin x  = Description ((\d->"asin ("++d++")") <$> document x) [e| asin $(transcribe x) |]
    acos x  = Description ((\d->"acos ("++d++")") <$> document x) [e| acos $(transcribe x) |]
    atan x  = Description ((\d->"atan ("++d++")") <$> document x) [e| atan $(transcribe x) |]
    sinh x  = Description ((\d->"sinh ("++d++")") <$> document x) [e| sinh $(transcribe x) |]
    cosh x  = Description ((\d->"cosh ("++d++")") <$> document x) [e| cosh $(transcribe x) |]
    asinh x = Description ((\d->"asinh ("++d++")") <$> document x) [e| asinh $(transcribe x) |]
    acosh x = Description ((\d->"acosh ("++d++")") <$> document x) [e| acosh $(transcribe x) |]
    atanh x = Description ((\d->"atanh ("++d++")") <$> document x) [e| atanh $(transcribe x) |]

function0 :: Description ExpQ b -> String -> Function'D a b
function0 op doc = Description {
    transcribe = \ _ -> transcribe $ op
  , document   = Just doc
}

function1 :: (Description ExpQ b -> Description ExpQ b) -> (String -> String) -> Function'D a b -> Function'D a b
function1 op doc (Description fdoc f) = Description {
    transcribe = \ x -> transcribe $ op $ unsafeDescription (f x)
  , document   = doc <$> fdoc
}

function2 :: (Description ExpQ b -> Description ExpQ b -> Description ExpQ b) -> (String -> String -> String) -> Function'D a b -> Function'D a b -> Function'D a b
function2 op doc (Description fdoc f) (Description gdoc g) = Description {
    transcribe = \ x -> transcribe $ unsafeDescription (f x) `op` unsafeDescription (g x)
  , document   = doc <$> fdoc <*> gdoc
}

instance Num b => Num (Function'D a b) where
    (+) = function2 (+) (\ df dg -> df ++ " + " ++ dg)
    (-) = function2 (-) (\ df dg -> df ++ " - " ++ dg)
    (*) = function2 (*) (\ df dg -> df ++ " * " ++ dg)
    negate = function1 negate (\d->"-"++d)
    signum = function1 signum (\d->"sgn("++d++")")
    abs    = function1 abs    (\d->"|"++d++"|")
    fromInteger x = Description {
        transcribe = \ _ -> transcribe (fromInteger x :: Flat'D b)
      , document = Just (show x) }

instance Fractional b => Fractional (Function'D a b) where
    (/) = function2 (/) (\ df dg -> "(" ++ df ++ ") / (" ++ dg ++ ")")
    fromRational x = Description {
        transcribe = \ _ -> transcribe (fromRational x :: Flat'D b)
      , document = Just (show x) }

instance Floating b => Floating (Function'D a b) where
    (**)  = function2 (**) (\ df dg -> "(" ++ df ++ ") ^ (" ++ dg ++ ")")
    pi    = function0 pi "pi"
    sqrt  = function1 sqrt (\d->"sqrt("++d++")")
    exp   = function1 exp  (\d->"exp("++d++")")
    log   = function1 log (\d->"log("++d++")")
    sin   = function1 sin (\d->"sin("++d++")")
    cos   = function1 cos (\d->"cos("++d++")")
    asin  = function1 asin (\d->"asin("++d++")")
    acos  = function1 acos (\d->"acos("++d++")")
    atan  = function1 atan (\d->"atan("++d++")")
    sinh  = function1 sinh (\d->"sinh("++d++")")
    cosh  = function1 cosh (\d->"cosh("++d++")")
    asinh = function1 asinh (\d->"asinh("++d++")")
    acosh = function1 acosh (\d->"acosh("++d++")")
    atanh = function1 atanh (\d->"atanh("++d++")")
