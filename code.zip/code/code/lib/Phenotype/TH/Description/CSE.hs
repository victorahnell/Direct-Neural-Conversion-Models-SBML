
module Phenotype.TH.Description.CSE
     ( cse
     ) where

import           Control.Monad
import           Data.List
import           Language.Haskell.TH

-- | Common subexpression elimination.
--   This function finds expressions of the form (let var = exp in ) in the
--   supplied abstract expression tree.
--   The let expressionns are floated to the top and combined when they
--   represent the same expression.
--   It does not find actual common subexpressions, only let variables.
--   This allows the programmer to control the level of cse, and makes the
--   code more readable by moving let expressions to the top as much as
--   possible (that is, not going out of scope).
--   NOTE: Current implementation does not work with (let f x = ...). It will
--   also conservatively avoid floating let expressions outside of some
--   language constructs which are not crawled in current implementation.
cse :: Exp -> Exp
cse ex = case cse' ex of
    LetE [] x -> x
    LetE d x  -> LetE d x
    _         -> error "cse' should always return LetE expressions."

cse' (VarE name) = LetE [] (VarE name)
cse' (ConE con) = LetE [] (ConE con)
cse' (LitE lit) = LetE [] (LitE lit)
cse' (AppE ex1 ex2) =
  let (dec, [ex1', ex2']) = simplify [] [ex1, ex2]
  in LetE dec (AppE ex1' ex2')
cse' (InfixE (Just ex1) ex2 (Just ex3)) =
  let (dec, [ex1', ex2', ex3']) = simplify [] [ex1, ex2, ex3]
  in LetE dec (InfixE (Just ex1') ex2' (Just ex3'))
cse' (InfixE Nothing ex2 (Just ex3)) =
  let (dec, [ex2', ex3']) = simplify [] [ex2, ex3]
  in LetE dec (InfixE Nothing ex2' (Just ex3'))
cse' (InfixE (Just ex1) ex2 Nothing) =
  let (dec, [ex1', ex2']) = simplify [] [ex1, ex2]
  in LetE dec (InfixE (Just ex1') ex2' Nothing)
cse' (InfixE Nothing ex2 Nothing) =
  let (dec, [ex2']) = simplify [] [ex2]
  in LetE dec (InfixE Nothing ex2' Nothing)
cse' (UInfixE ex1 ex2 ex3) =
  let (dec, [ex1', ex2', ex3']) = simplify [] [ex1, ex2, ex3]
  in LetE dec (UInfixE ex1' ex2' ex3')
cse' (LamE pat ex) =
    LetE [] (LamE pat (cse ex))
cse' (LamCaseE m) =
  LetE [] (LamCaseE m)
cse' (ParensE ex) =
  let (dec, [ex']) = simplify [] [ex]
  in LetE dec (ParensE ex')
cse' (TupE exs) =
  let (dec, exs') = simplify [] exs
  in LetE dec (TupE exs')
cse' (UnboxedTupE exs) =
  let (dec, exs') = simplify [] exs
  in LetE dec (UnboxedTupE exs')
cse' (CondE ex1 ex2 ex3) =
  let (dec, [ex1',ex2',ex3']) = simplify [] [ex1,ex2,ex3]
  in LetE dec (CondE ex1' ex2' ex3')
cse' (MultiIfE ms) =
  LetE [] (MultiIfE ms)
cse' (LetE dec ex) =
  let (dec', [ex']) = simplify dec [ex]
  in LetE dec' ex'
cse' (CaseE exs ms) =
    LetE [] (CaseE exs ms)
cse' (DoE ss) =
    LetE [] (DoE ss)
cse' (CompE ss) =
    LetE [] (CompE ss)
cse' (ArithSeqE r) =
    LetE [] (ArithSeqE r)
cse' (ListE exs) =
    let (dec, exs') = simplify [] exs
    in LetE dec (ListE exs')
cse' (SigE ex ty) =
    let (dec, [ex']) = simplify [] [ex]
    in LetE dec (SigE ex' ty)
cse' (RecConE con nexs) =
    LetE [] (RecConE con (map (\ (n,ex) -> (n,cse ex)) nexs))
    -- let (dec, exs') = simplify [] (map snd nexs)
    -- in LetE dec (RecConE con (zip (map fst nexs) exs'))
cse' (RecUpdE conex nexs) =
    LetE [] (RecUpdE conex (map (\ (n,ex) -> (n,cse ex)) nexs))
cse' (StaticE ex) =
    let (dec, [ex']) = simplify [] [ex]
    in LetE dec (StaticE ex')
cse' (UnboundVarE name) =
    LetE [] (UnboundVarE name)

simplifyDecs (ValD pat (NormalB ex) [] : dec) =
    let LetE dec' ex' = cse' ex
    in (ValD pat (NormalB ex') []) : simplifyDecs (dec ++ dec')
simplifyDecs (d:dec) = d : simplifyDecs dec
simplifyDecs [] = []

simplify d exs =
  let decexs = map cse' exs
      decs = [ dec | LetE dec _ <- decexs ]
      exs' = [ ex' | LetE _ ex' <- decexs ]
  in go [] (simplifyDecs (d ++ concat decs)) exs'
go prev (d@(ValD (VarP v) (NormalB ex) []):ds) exs =
  case find (equalExpr d) prev of
      Just (ValD (VarP vprev) (NormalB exprev) [])
          | vprev == v -> go prev ds exs
          | otherwise ->
              case (mapM (substituteD v vprev) prev, mapM (substituteD v vprev) ds, mapM (substitute v vprev) exs) of
                  (Just subprev, Just subds, Just subexs) -> go subprev subds subexs
                  otherwise -> go (d:prev) ds exs
      Nothing -> go (d:prev) ds exs
      Just _ -> error "Error: This cannot happen."
go prev (d:ds) exs = go (d:prev) ds exs
go prev [] exs = (prev, exs)

equalExpr (ValD (VarP v1) (NormalB ex1) []) (ValD (VarP v2) (NormalB ex2) []) =
  case (substitute v1 v2 ex1, substitute v2 v1 ex2) of
      (Just a, Just b) -> a == b
      (_, _)           -> False
equalExpr _ _ = False

substituteD v1 v2 (ValD pat (NormalB ex) []) = liftM2 (ValD pat) (liftM NormalB (substitute v1 v2 ex)) (Just [])
substituteD v1 v2 _ = Nothing


substitute v1 v2 (VarE name) | name == v1 = Just (VarE v2)
                             | otherwise = Just (VarE name)
substitute _ _ (ConE con) = Just (ConE con)
substitute _ _ (LitE lit) = Just (LitE lit)
substitute v1 v2 (AppE ex1 ex2) = liftM2 AppE (substitute v1 v2 ex1) (substitute v1 v2 ex2)
substitute v1 v2 (InfixE mex1 ex2 mex3) = liftM3 InfixE (substitute v1 v2 <$> mex1) (substitute v1 v2 ex2) (substitute v1 v2 <$> mex3)
substitute v1 v2 (UInfixE ex1 ex2 ex3) = liftM3 UInfixE (substitute v1 v2 ex1) (substitute v1 v2 ex2) (substitute v1 v2 ex3)
substitute v1 v2 (ParensE ex) = liftM ParensE (substitute v1 v2 ex)
substitute v1 v2 (LamE pats ex) | any (patContains v2) pats = Nothing -- lambda bindings shadow v2, so replacement would be invalid.
                                | any (patContains v1) pats = Just (LamE pats ex) -- lambda bindings shadow v1, so they do not have to be replaced
                                | otherwise = liftM (LamE pats) (substitute v1 v2 ex)
substitute v1 v2 (LamCaseE m) = Nothing -- A hassle and fringe case.
substitute v1 v2 (TupE exs) = liftM TupE (mapM (substitute v1 v2) exs)
substitute v1 v2 (UnboxedTupE exs) = liftM UnboxedTupE (mapM (substitute v1 v2) exs)
substitute v1 v2 (CondE ex1 ex2 ex3) = liftM3 CondE (substitute v1 v2 ex1) (substitute v1 v2 ex2) (substitute v1 v2 ex3)
substitute v1 v2 (MultiIfE m) = Nothing -- A hassle and fringe case.
substitute v1 v2 (LetE decs ex) = Nothing
substitute v1 v2 (CaseE ex m) = Nothing
substitute v1 v2 (DoE ss) = liftM DoE $ mapM (substituteStmt v1 v2) ss
substitute v1 v2 (CompE ss) = liftM CompE $ mapM (substituteStmt v1 v2) ss
substitute v1 v2 (ArithSeqE r) = liftM ArithSeqE $ substituteRange v1 v2 r
substitute v1 v2 (ListE lst) = liftM ListE $ mapM (substitute v1 v2) lst
substitute v1 v2 (SigE ex ty) = liftM (flip SigE ty) (substitute v1 v2 ex)
substitute v1 v2 (RecConE con fexs) = liftM (RecConE con) $ mapM (\(n,ex) -> if n == v1 || n == v2 then Nothing else liftM (\ x -> (n,x)) (substitute v1 v2 ex)) fexs
substitute v1 v2 (RecUpdE _ _) = Nothing
substitute v1 v2 (StaticE _) = Nothing
substitute v1 v2 (UnboundVarE _) = Nothing

substituteStmt v1 v2 (BindS pat ex) | patContains v2 pat = Nothing
                                  | patContains v1 pat = Nothing
                                  | otherwise = liftM (BindS pat) $ substitute v1 v2 ex
substituteStmt v1 v2 (LetS decs) = Nothing
substituteStmt v1 v2 (NoBindS ex) = liftM NoBindS $ substitute v1 v2 ex
substituteStmt v1 v2 (ParS _) = Nothing

substituteRange v1 v2 (FromR ex) = liftM FromR $ substitute v1 v2 ex
substituteRange v1 v2 (FromThenR ex1 ex2) = liftM2 FromThenR (substitute v1 v2 ex1) (substitute v1 v2 ex2)
substituteRange v1 v2 (FromToR ex1 ex2) = liftM2 FromToR (substitute v1 v2 ex1) (substitute v1 v2 ex2)
substituteRange v1 v2 (FromThenToR ex1 ex2 ex3) = liftM3 FromThenToR (substitute v1 v2 ex1) (substitute v1 v2 ex2) (substitute v1 v2 ex3)


patContains v (VarP name) | name == v = True
                          | otherwise = False
patContains v (LitP _) = False
patContains v (TupP pats) = any (patContains v) pats
patContains v (UnboxedTupP pats) = any (patContains v) pats
patContains v (ConP con pats) = any (patContains v) pats
patContains v (ParensP pat) = patContains v pat
patContains v (InfixP pat1 con pat2) = any (patContains v) [pat1, pat2]
patContains v (UInfixP pat1 con pat2) = any (patContains v) [pat1, pat2]
patContains v (TildeP pat) = patContains v pat
patContains v (BangP pat) = patContains v pat
patContains v (AsP n pat) = any (patContains v) [VarP n, pat]
patContains v WildP = False
patContains v (RecP con fpats) = any (patContains v . snd) fpats
patContains v (ListP pats) = any (patContains v) pats
patContains v (SigP pat ty) = patContains v pat
patContains v (ViewP ex pat) = patContains v pat
