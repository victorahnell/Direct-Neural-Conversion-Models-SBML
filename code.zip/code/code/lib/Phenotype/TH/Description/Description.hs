{-# LANGUAGE FlexibleContexts      #-}
{-# LANGUAGE FlexibleInstances     #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE ScopedTypeVariables   #-}
{-# LANGUAGE TemplateHaskell       #-}
{-# LANGUAGE TypeOperators         #-}

module Phenotype.TH.Description.Description
     ( module Phenotype.TH.Description.Description
     ) where

import           Control.Monad
import           Data.Char
import           Data.Proxy
import           Data.List                     (intercalate)
import           Language.Haskell.TH
import qualified Language.Haskell.TH.Syntax    as TH

import           Phenotype.TH.Description.CSE

-- | The Description type is the core of the Template Haskell API used for GenomeBuilders.
--   It holds one argument of type a, and a dummy argument b.
--   The idea is that the value of type a can be used to create a TH ExpQ
--   representing a value of type b. This functionality is encapsulated in
--   the Describes class.
--   A Description also holds an optional String that describes the value in
--   words or human-readable expressions.
--
--   Description is useful because it allows:
--      (1) type-safer reasoning in TH, as Description can be seen as a type
--          wrapper around an ExpQ, just like Q (TExp b).
--      (2) custom compile-time optimizations, as the type a can hold
--          information that can be manipulated so that it results in more
--          efficient TH code.
--      (3) possibly carry information about the type of b that can be used
--          in TH expressions. This is encapsulated in the DescribesType
--          class.
--      (4) possibly carry extra information for describing the built value
--          in human-readable terms.
--   The trivial instance that allows only (1) is Description ExpQ b.
--   Any Description a b can be converted to that.
--
--   NOTE: Regarding point (1), in many cases it is impossible to guarantee
--   that the TH ExpQ described by a Description is actually of the type b,
--   and not a more general type. For example, a Description a Int
--   may describe TH code of the form [e| fromInteger 1 |]. When this code
--   is actually compiled, it may also result in an Integer or other Num, and
--   indeed will default to an Integer in certain situations due to the
--   monomorphism restriction.
--   All a Description a b can guarantee about the type that the described
--   ExpQ compiles to, is that it is compatible with manipulations as a b.
--   The actual type that is compiled may be more general.
--
--   NOTE: To illustrate (2), consider a Description type that can be used
--   to represent tuples, Description (ExpQ, ExpQ) (x,y). This can be
--   easily converted to a Description or ExpQ representing only the first
--   element in the tuple, with
--       \ (Description (qx,qy) -> Description qx :: Description ExpQ x
--   , at compile time, or to pass it directly to TH,
--       \ (Description (qx, qy) -> qx
--   On the contrary, when using an ExpQ or Q (TExp (x,y)), the only way to
--   retrieve only the first part is to build
--       \ qtup -> [e| fst $qtup |]
--   which also builds the snd, unnecessary part of the tuple.
--   While Haskell's lazy semantics would avoid actually computing snd in
--   this case, this approach avoids building a lot of unnecessary code,
--   especially in more complicated circumstances. In addition, using more
--   specific representations of types allows certain operations that would
--   not be possible when using an Exp or TExp.
data Description a b =
    Description { document :: Maybe String, transcribe :: a }

document' (Description {document = Just doc}) = doc
document' (Description {document = Nothing})  = "[~]"

-- | Class used to convert Description a b to an ExpQ of b.
class a `Describes` b where
    describe' :: proxy b -> a -> ExpQ

-- | Convert a Description to an ExpQ.
--   This will do CSE, an experimental feature. When encountering issues,
--   use describeNoCSE instead.
describe :: (a `Describes` b) => Description a b -> ExpQ
describe = fmap cse . describeNoCSE

describeT :: (a `Describes` b) => Description a b -> Q (TExp b)
describeT = TH.unsafeTExpCoerce . describe

describeNoCSE :: (a `Describes` b) => Description a b -> ExpQ
describeNoCSE d = describe' d (transcribe d)

fixName :: String -> ExpQ -> ExpQ
fixName n ex = do name <- newName (safen n); [e| let $(varP name) = $ex in $(varE name) |]
    where safen [] = "val"
          safen (c:cs) | isUpper c = safen $ toLower c : cs
                       | not (isLower c) || c == '_' = safen $ '_' : c : cs
                       | not (all (`elem` allowedChars) (c:cs)) =
                           safen $ map (\ x -> if x `elem` allowedChars then x else '_') (c:cs)
                       | otherwise = c:cs
          allowedChars = ['a'..'z'] ++ ['A'..'Z'] ++ ['0'..'9'] ++ "'_"

-- | Convert a Description to a TypeQ.
class (a `Describes` b) => a `DescribesType` b where
    typescribe' :: proxy b -> a -> TypeQ

typescribe :: (a `DescribesType` b) => Description a b -> TypeQ
typescribe d = typescribe' d (transcribe d)

data Typed a = Typed a TypeQ

typed :: Description a b -> TypeQ -> Description (Typed a) b
typed d ty = Description { transcribe = Typed (transcribe d) ty, document = document d}

instance a `Describes` b => Typed a `Describes` b where
    describe' _ (Typed a ty) = [e| $(describe' (Proxy::Proxy b) a) :: $ty |]

instance a `Describes` b => Typed a `DescribesType` b where
    typescribe' _ (Typed a ty) = ty

-- * Describe instances.

instance ExpQ `Describes` a where
    describe' _ = id

unsafeDescription :: ExpQ -> Description ExpQ x
unsafeDescription = Description Nothing

instance Q (TExp a) `Describes` a where
    describe' _ = TH.unTypeQ

description :: Q (TExp a) -> Description (Q (TExp a)) a
description = Description Nothing

type Flat'D = Description ExpQ
flatten :: (a `Describes` b) => Description a b -> Description ExpQ b
flatten d = Description { transcribe = describeNoCSE d, document = document d }

-- | Values that can be lifted to TH expressions, can describe themselves.
type Lift'D a = Description a a
instance TH.Lift a => a `Describes` a where
    describe' _ = TH.lift
lift'D :: TH.Lift a => a -> Description a a
lift'D = Description Nothing

-- | A Name can represent any type.
--   In order to give a Description Name the correct return type b,
--   create Name descriptions using:
--       nameD x 'x
--   where x is a global variable.
type Name'D b = Description Name b
instance Name `Describes` b where
    describe' _ = varE
instance Name `DescribesType` b where
    typescribe' _ name =
        do rei <- reify name
           case rei of
               VarI _ ty _ -> return ty
               otherwise   -> error msg
        where msg = "Error: Description Name was not given a value name.\
                          \ Proper use to avoid this error: nameD x 'x"
name'D :: a -> Name -> Description Name a
name'D _ n = Description (Just (show n)) n

-- | A Description can be used as a Decription.
instance (a `Describes` b) => Description a b `Describes` b where
    describe' _ x = describeNoCSE x

-- | A list of values that are descriptions, can represent a list.
instance (a `Describes` b) => [a] `Describes` [b] where
    describe' _ = listE . map (describeNoCSE . d)
        where d = Description Nothing :: a -> Description a b
list'D :: (a `Describes` b) => [Description a b] -> Description [Description a b] [b]
list'D lst = Description (bracket <$> mapM document lst) lst
    where bracket doc = "[" ++ intercalate "," doc ++ "]"

-- | A tuple of descriptions is a description of a tuple
instance (a `Describes` b, a' `Describes` b') => (Description a b , Description a' b') `Describes` (b,b') where
    describe' _ (x,x') = tupE [describeNoCSE x, describeNoCSE x']
tuple'D :: (a `Describes` b, a' `Describes` b') => (Description a b ,Description a' b') -> Description (Description a b , Description a' b') (b,b')
tuple'D (x,x') = Description (tupledoc <$> document x <*> document x') (x,x')
    where tupledoc dx dx' = "(" ++ dx ++  ", " ++ dx' ++ ")"

-- | A tuple of descriptions is a description of a tuple
instance (a `Describes` b, a' `Describes` b', a'' `Describes` b'') => (Description a b , Description a' b', Description a'' b'') `Describes` (b,b',b'') where
    describe' _ (x,x',x'') = tupE [describeNoCSE x, describeNoCSE x', describeNoCSE x'']
tuple3'D :: (a `Describes` b, a' `Describes` b', a'' `Describes` b'') => (Description a b, Description a' b', Description a'' b'') -> Description (Description a b , Description a' b', Description a'' b'') (b,b',b'')
tuple3'D (x,x',x'') = Description (tupledoc <$> document x <*> document x' <*> document x'') (x,x',x'')
    where tupledoc dx dx' dx'' = "(" ++ dx ++  ", " ++ dx' ++ ", " ++ dx'' ++ ")"

-- | Standard function instance
-- | See Instances for Num etc. instances.
type Function'D a b = Description (Name -> ExpQ) (a -> b)
instance x `Describes` b => (Name -> x) `Describes` (a -> b) where
    describe' _ f = do x <- newName "x"; [e| \ $(varP x) -> $(describe' (Proxy::Proxy b) (f x)) |]
unsafeFunction'D :: (Name -> ExpQ) -> Function'D a b
unsafeFunction'D = Description Nothing
-- | Bind name as a lambda variable in expression, returning a function.
functionOf'D :: x `Describes` b => Name -> Description x b -> Description ExpQ (a -> b)
functionOf'D name ex = Description Nothing [e| \ $(varP name) -> $(describeNoCSE ex) |]

fun'D :: x `Describes` b => (Name -> x) -> Description (Name -> x) (a -> b)
fun'D = Description Nothing

-- | Apply a function Description to an argument Description.
--   This flattens the Description type to an ExpQ.
apply'D :: (d `Describes` (a -> b), d' `Describes` a) => Description d (a -> b) -> Description d' a -> Description ExpQ b
apply'D df dx = Description doc [e| $(describeNoCSE df) $(describeNoCSE dx) |]
    where docapp fdoc xdoc = fdoc ++ " (" ++ xdoc ++ ")"
          doc = liftM2 docapp (document df) (document dx)

-- | A description of a constant function.
conF :: a `Describes` b => Description a b -> Function'D x b
conF x = (unsafeFunction'D $ \ _ -> describeNoCSE x)
         { document = document x }
