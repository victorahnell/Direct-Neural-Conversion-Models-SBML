
module Phenotype.TH.Builder
     ( GenomeBuilder
     , liftBuilder
     , GPMap (..), forParams
     , Parameter (..)
     , ParameterD (..)
     , buildPheno, buildParam
     , Parametric, parameter, paramDesc, constantDouble, constantInt, constantInteger
     ) where

import           Phenotype.TH.Builder.Builder
