src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2148
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a214M
                      p_a2147 = double g_a2146
                      (g_a2146, gpart_a214M) = Genome.Split.split gpart_a214L
                      p_a2145 = double g_a2144
                      (g_a2144, gpart_a214L) = Genome.Split.split gpart_a214K
                      p_a2143 = double g_a2142
                      (g_a2142, gpart_a214K) = Genome.Split.split gpart_a214J
                      p_a2141 = double g_a2140
                      (g_a2140, gpart_a214J) = Genome.Split.split gpart_a214I
                      p_a213Z = double g_a213Y
                      (g_a213Y, gpart_a214I) = Genome.Split.split gpart_a214H
                      p_a213X = Functions.belowten' g_a213W
                      (g_a213W, gpart_a214H) = Genome.Split.split gpart_a214G
                      p_a213V = double g_a213U
                      (g_a213U, gpart_a214G) = Genome.Split.split gpart_a214F
                      p_a213T = double g_a213S
                      (g_a213S, gpart_a214F) = Genome.Split.split gpart_a214E
                      p_a213R = double g_a213Q
                      (g_a213Q, gpart_a214E) = Genome.Split.split gpart_a214D
                      p_a213P = Functions.belowten' g_a213O
                      (g_a213O, gpart_a214D) = Genome.Split.split gpart_a214C
                      p_a213N = double g_a213M
                      (g_a213M, gpart_a214C) = Genome.Split.split gpart_a214B
                      p_a213L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213K
                      (g_a213K, gpart_a214B) = Genome.Split.split gpart_a214A
                      p_a213J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213I
                      (g_a213I, gpart_a214A) = Genome.Split.split gpart_a214z
                      p_a213H = Functions.belowten' g_a213G
                      (g_a213G, gpart_a214z) = Genome.Split.split gpart_a214y
                      p_a213F = double g_a213E
                      (g_a213E, gpart_a214y) = Genome.Split.split gpart_a214x
                      p_a213D = double g_a213C
                      (g_a213C, gpart_a214x) = Genome.Split.split gpart_a214w
                      p_a213B = double g_a213A
                      (g_a213A, gpart_a214w) = Genome.Split.split gpart_a214v
                      p_a213z = Functions.belowten' g_a213y
                      (g_a213y, gpart_a214v) = Genome.Split.split gpart_a214u
                      p_a213x = double g_a213w
                      (g_a213w, gpart_a214u) = Genome.Split.split gpart_a214t
                      p_a213v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213u
                      (g_a213u, gpart_a214t) = Genome.Split.split gpart_a214s
                      p_a213t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213s
                      (g_a213s, gpart_a214s) = Genome.Split.split gpart_a214r
                      p_a213r = double g_a213q
                      (g_a213q, gpart_a214r) = Genome.Split.split gpart_a214q
                      p_a213p = double g_a213o
                      (g_a213o, gpart_a214q) = Genome.Split.split gpart_a214p
                      p_a213n = Functions.belowten' g_a213m
                      (g_a213m, gpart_a214p) = Genome.Split.split gpart_a214o
                      p_a213l = double g_a213k
                      (g_a213k, gpart_a214o) = Genome.Split.split gpart_a214n
                      p_a213j = Functions.belowten' g_a213i
                      (g_a213i, gpart_a214n) = Genome.Split.split gpart_a214m
                      p_a213h = double g_a213g
                      (g_a213g, gpart_a214m) = Genome.Split.split gpart_a214l
                      p_a213f = Functions.belowten' g_a213e
                      (g_a213e, gpart_a214l) = Genome.Split.split gpart_a214k
                      p_a213d = double g_a213c
                      (g_a213c, gpart_a214k) = Genome.Split.split gpart_a214j
                      p_a213b = double g_a213a
                      (g_a213a, gpart_a214j) = Genome.Split.split gpart_a214i
                      p_a2139 = Functions.belowten' g_a2138
                      (g_a2138, gpart_a214i) = Genome.Split.split gpart_a214h
                      p_a2137 = double g_a2136
                      (g_a2136, gpart_a214h) = Genome.Split.split gpart_a214g
                      p_a2135
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2134
                      (g_a2134, gpart_a214g) = Genome.Split.split gpart_a214f
                      p_a2133
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2132
                      (g_a2132, gpart_a214f) = Genome.Split.split gpart_a214e
                      p_a2131 = double g_a2130
                      (g_a2130, gpart_a214e) = Genome.Split.split gpart_a214d
                      p_a212Z = double g_a212Y
                      (g_a212Y, gpart_a214d) = Genome.Split.split gpart_a214c
                      p_a212X = double g_a212W
                      (g_a212W, gpart_a214c) = Genome.Split.split gpart_a214b
                      p_a212V = double g_a212U
                      (g_a212U, gpart_a214b) = Genome.Split.split gpart_a214a
                      p_a212T = double g_a212S
                      (g_a212S, gpart_a214a) = Genome.Split.split genome_a2148
                    in  \ x_a214N
                          -> let
                               c_PTB_a214Q
                                 = ((Data.Fixed.Vector.toVector x_a214N) Data.Vector.Unboxed.! 0)
                               c_MiRs_a214O
                                 = ((Data.Fixed.Vector.toVector x_a214N) Data.Vector.Unboxed.! 2)
                               c_NPTB_a214W
                                 = ((Data.Fixed.Vector.toVector x_a214N) Data.Vector.Unboxed.! 1)
                               c_RESTc_a214R
                                 = ((Data.Fixed.Vector.toVector x_a214N) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2157
                                 = ((Data.Fixed.Vector.toVector x_a214N) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2131 / (1 + ((c_MiRs_a214O / p_a2137) ** p_a2139)))
                                    + (negate (p_a213Z * c_PTB_a214Q))),
                                   ((p_a213b
                                     * ((p_a213p + ((c_RESTc_a214R / p_a213d) ** p_a213f))
                                        / (((1 + p_a213p) + ((c_RESTc_a214R / p_a213d) ** p_a213f))
                                           + (((c_MiRs_a214O / p_a213h) ** p_a213j)
                                              + ((c_PTB_a214Q / p_a213l) ** p_a213n)))))
                                    + (negate (p_a2141 * c_NPTB_a214W))),
                                   ((p_a213r
                                     * ((p_a213B + ((p_a212X / p_a213t) ** p_a213v))
                                        / (((1 + p_a213B) + ((p_a212X / p_a213t) ** p_a213v))
                                           + ((c_RESTc_a214R / p_a213x) ** p_a213z))))
                                    + (negate (p_a2143 * c_MiRs_a214O))),
                                   ((p_a213D
                                     * ((p_a213R + ((c_PTB_a214Q / p_a213F) ** p_a213H))
                                        / (((1 + p_a213R) + ((c_PTB_a214Q / p_a213F) ** p_a213H))
                                           + (((p_a212T / p_a213J) ** p_a213L)
                                              + ((c_MiRs_a214O / p_a213N) ** p_a213P)))))
                                    + (negate (p_a2145 * c_RESTc_a214R))),
                                   ((p_a213T / (1 + ((c_RESTc_a214R / p_a213V) ** p_a213X)))
                                    + (negate (p_a2147 * c_EndoNeuroTFs_a2157)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490481",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490483",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490507",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490509",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490523",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490525",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2148
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a215K
                            p_a2147 = double g_a2146
                            (g_a2146, gpart_a215K) = Genome.Split.split gpart_a215J
                            p_a2145 = double g_a2144
                            (g_a2144, gpart_a215J) = Genome.Split.split gpart_a215I
                            p_a2143 = double g_a2142
                            (g_a2142, gpart_a215I) = Genome.Split.split gpart_a215H
                            p_a2141 = double g_a2140
                            (g_a2140, gpart_a215H) = Genome.Split.split gpart_a215G
                            p_a213Z = double g_a213Y
                            (g_a213Y, gpart_a215G) = Genome.Split.split gpart_a215F
                            p_a213X = Functions.belowten' g_a213W
                            (g_a213W, gpart_a215F) = Genome.Split.split gpart_a215E
                            p_a213V = double g_a213U
                            (g_a213U, gpart_a215E) = Genome.Split.split gpart_a215D
                            p_a213T = double g_a213S
                            (g_a213S, gpart_a215D) = Genome.Split.split gpart_a215C
                            p_a213R = double g_a213Q
                            (g_a213Q, gpart_a215C) = Genome.Split.split gpart_a215B
                            p_a213P = Functions.belowten' g_a213O
                            (g_a213O, gpart_a215B) = Genome.Split.split gpart_a215A
                            p_a213N = double g_a213M
                            (g_a213M, gpart_a215A) = Genome.Split.split gpart_a215z
                            p_a213L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213K
                            (g_a213K, gpart_a215z) = Genome.Split.split gpart_a215y
                            p_a213J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213I
                            (g_a213I, gpart_a215y) = Genome.Split.split gpart_a215x
                            p_a213H = Functions.belowten' g_a213G
                            (g_a213G, gpart_a215x) = Genome.Split.split gpart_a215w
                            p_a213F = double g_a213E
                            (g_a213E, gpart_a215w) = Genome.Split.split gpart_a215v
                            p_a213D = double g_a213C
                            (g_a213C, gpart_a215v) = Genome.Split.split gpart_a215u
                            p_a213B = double g_a213A
                            (g_a213A, gpart_a215u) = Genome.Split.split gpart_a215t
                            p_a213z = Functions.belowten' g_a213y
                            (g_a213y, gpart_a215t) = Genome.Split.split gpart_a215s
                            p_a213x = double g_a213w
                            (g_a213w, gpart_a215s) = Genome.Split.split gpart_a215r
                            p_a213v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213u
                            (g_a213u, gpart_a215r) = Genome.Split.split gpart_a215q
                            p_a213t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213s
                            (g_a213s, gpart_a215q) = Genome.Split.split gpart_a215p
                            p_a213r = double g_a213q
                            (g_a213q, gpart_a215p) = Genome.Split.split gpart_a215o
                            p_a213p = double g_a213o
                            (g_a213o, gpart_a215o) = Genome.Split.split gpart_a215n
                            p_a213n = Functions.belowten' g_a213m
                            (g_a213m, gpart_a215n) = Genome.Split.split gpart_a215m
                            p_a213l = double g_a213k
                            (g_a213k, gpart_a215m) = Genome.Split.split gpart_a215l
                            p_a213j = Functions.belowten' g_a213i
                            (g_a213i, gpart_a215l) = Genome.Split.split gpart_a215k
                            p_a213h = double g_a213g
                            (g_a213g, gpart_a215k) = Genome.Split.split gpart_a215j
                            p_a213f = Functions.belowten' g_a213e
                            (g_a213e, gpart_a215j) = Genome.Split.split gpart_a215i
                            p_a213d = double g_a213c
                            (g_a213c, gpart_a215i) = Genome.Split.split gpart_a215h
                            p_a213b = double g_a213a
                            (g_a213a, gpart_a215h) = Genome.Split.split gpart_a215g
                            p_a2139 = Functions.belowten' g_a2138
                            (g_a2138, gpart_a215g) = Genome.Split.split gpart_a215f
                            p_a2137 = double g_a2136
                            (g_a2136, gpart_a215f) = Genome.Split.split gpart_a215e
                            p_a2135
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2134
                            (g_a2134, gpart_a215e) = Genome.Split.split gpart_a215d
                            p_a2133
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2132
                            (g_a2132, gpart_a215d) = Genome.Split.split gpart_a215c
                            p_a2131 = double g_a2130
                            (g_a2130, gpart_a215c) = Genome.Split.split gpart_a215b
                            p_a212Z = double g_a212Y
                            (g_a212Y, gpart_a215b) = Genome.Split.split gpart_a215a
                            p_a212X = double g_a212W
                            (g_a212W, gpart_a215a) = Genome.Split.split gpart_a2159
                            p_a212V = double g_a212U
                            (g_a212U, gpart_a2159) = Genome.Split.split gpart_a2158
                            p_a212T = double g_a212S
                            (g_a212S, gpart_a2158) = Genome.Split.split genome_a2148
                          in
                            \ desc_a2149
                              -> case desc_a2149 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a212T)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a212V)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a212X)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a212Z)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2131)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2133)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2135)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2137)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2139)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213b)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213d)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213f)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213h)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213j)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213l)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213n)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213p)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213r)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213t)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213v)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213x)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213z)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213B)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213D)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213F)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213H)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213J)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213L)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213N)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213P)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213R)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213T)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213V)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213X)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213Z)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2141)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2143)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2145)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2147)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a218a
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a218O
                      p_a2189 = double g_a2188
                      (g_a2188, gpart_a218O) = Genome.Split.split gpart_a218N
                      p_a2187 = double g_a2186
                      (g_a2186, gpart_a218N) = Genome.Split.split gpart_a218M
                      p_a2185 = double g_a2184
                      (g_a2184, gpart_a218M) = Genome.Split.split gpart_a218L
                      p_a2183 = double g_a2182
                      (g_a2182, gpart_a218L) = Genome.Split.split gpart_a218K
                      p_a2181 = double g_a2180
                      (g_a2180, gpart_a218K) = Genome.Split.split gpart_a218J
                      p_a217Z = Functions.belowten' g_a217Y
                      (g_a217Y, gpart_a218J) = Genome.Split.split gpart_a218I
                      p_a217X = double g_a217W
                      (g_a217W, gpart_a218I) = Genome.Split.split gpart_a218H
                      p_a217V = double g_a217U
                      (g_a217U, gpart_a218H) = Genome.Split.split gpart_a218G
                      p_a217T = double g_a217S
                      (g_a217S, gpart_a218G) = Genome.Split.split gpart_a218F
                      p_a217R = Functions.belowten' g_a217Q
                      (g_a217Q, gpart_a218F) = Genome.Split.split gpart_a218E
                      p_a217P = double g_a217O
                      (g_a217O, gpart_a218E) = Genome.Split.split gpart_a218D
                      p_a217N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217M
                      (g_a217M, gpart_a218D) = Genome.Split.split gpart_a218C
                      p_a217L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217K
                      (g_a217K, gpart_a218C) = Genome.Split.split gpart_a218B
                      p_a217J = Functions.belowten' g_a217I
                      (g_a217I, gpart_a218B) = Genome.Split.split gpart_a218A
                      p_a217H = double g_a217G
                      (g_a217G, gpart_a218A) = Genome.Split.split gpart_a218z
                      p_a217F = double g_a217E
                      (g_a217E, gpart_a218z) = Genome.Split.split gpart_a218y
                      p_a217D = double g_a217C
                      (g_a217C, gpart_a218y) = Genome.Split.split gpart_a218x
                      p_a217B = Functions.belowten' g_a217A
                      (g_a217A, gpart_a218x) = Genome.Split.split gpart_a218w
                      p_a217z = double g_a217y
                      (g_a217y, gpart_a218w) = Genome.Split.split gpart_a218v
                      p_a217x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217w
                      (g_a217w, gpart_a218v) = Genome.Split.split gpart_a218u
                      p_a217v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217u
                      (g_a217u, gpart_a218u) = Genome.Split.split gpart_a218t
                      p_a217t = double g_a217s
                      (g_a217s, gpart_a218t) = Genome.Split.split gpart_a218s
                      p_a217r = double g_a217q
                      (g_a217q, gpart_a218s) = Genome.Split.split gpart_a218r
                      p_a217p = Functions.belowten' g_a217o
                      (g_a217o, gpart_a218r) = Genome.Split.split gpart_a218q
                      p_a217n = double g_a217m
                      (g_a217m, gpart_a218q) = Genome.Split.split gpart_a218p
                      p_a217l = Functions.belowten' g_a217k
                      (g_a217k, gpart_a218p) = Genome.Split.split gpart_a218o
                      p_a217j = double g_a217i
                      (g_a217i, gpart_a218o) = Genome.Split.split gpart_a218n
                      p_a217h = Functions.belowten' g_a217g
                      (g_a217g, gpart_a218n) = Genome.Split.split gpart_a218m
                      p_a217f = double g_a217e
                      (g_a217e, gpart_a218m) = Genome.Split.split gpart_a218l
                      p_a217d = double g_a217c
                      (g_a217c, gpart_a218l) = Genome.Split.split gpart_a218k
                      p_a217b = Functions.belowten' g_a217a
                      (g_a217a, gpart_a218k) = Genome.Split.split gpart_a218j
                      p_a2179 = double g_a2178
                      (g_a2178, gpart_a218j) = Genome.Split.split gpart_a218i
                      p_a2177
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2176
                      (g_a2176, gpart_a218i) = Genome.Split.split gpart_a218h
                      p_a2175
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2174
                      (g_a2174, gpart_a218h) = Genome.Split.split gpart_a218g
                      p_a2173 = double g_a2172
                      (g_a2172, gpart_a218g) = Genome.Split.split gpart_a218f
                      p_a2171 = double g_a2170
                      (g_a2170, gpart_a218f) = Genome.Split.split gpart_a218e
                      p_a216Z = double g_a216Y
                      (g_a216Y, gpart_a218e) = Genome.Split.split gpart_a218d
                      p_a216X = double g_a216W
                      (g_a216W, gpart_a218d) = Genome.Split.split gpart_a218c
                      p_a216V = double g_a216U
                      (g_a216U, gpart_a218c) = Genome.Split.split genome_a218a
                    in  \ x_a218P
                          -> let
                               c_PTB_a218S
                                 = ((Data.Fixed.Vector.toVector x_a218P) Data.Vector.Unboxed.! 0)
                               c_MiRs_a218Q
                                 = ((Data.Fixed.Vector.toVector x_a218P) Data.Vector.Unboxed.! 2)
                               c_NPTB_a218Y
                                 = ((Data.Fixed.Vector.toVector x_a218P) Data.Vector.Unboxed.! 1)
                               c_RESTc_a218T
                                 = ((Data.Fixed.Vector.toVector x_a218P) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2199
                                 = ((Data.Fixed.Vector.toVector x_a218P) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2173 / (1 + ((c_MiRs_a218Q / p_a2179) ** p_a217b)))
                                    + (negate (p_a2181 * c_PTB_a218S))),
                                   ((p_a217d
                                     * ((p_a217r + ((c_RESTc_a218T / p_a217f) ** p_a217h))
                                        / (((1 + p_a217r) + ((c_RESTc_a218T / p_a217f) ** p_a217h))
                                           + (((c_MiRs_a218Q / p_a217j) ** p_a217l)
                                              + ((c_PTB_a218S / p_a217n) ** p_a217p)))))
                                    + (negate (p_a2183 * c_NPTB_a218Y))),
                                   ((p_a217t
                                     * (p_a217D
                                        / ((1 + p_a217D) + ((c_RESTc_a218T / p_a217z) ** p_a217B))))
                                    + (negate (p_a2185 * c_MiRs_a218Q))),
                                   ((p_a217F
                                     * ((p_a217T + ((c_PTB_a218S / p_a217H) ** p_a217J))
                                        / (((1 + p_a217T) + ((c_PTB_a218S / p_a217H) ** p_a217J))
                                           + (((p_a216V / p_a217L) ** p_a217N)
                                              + ((c_MiRs_a218Q / p_a217P) ** p_a217R)))))
                                    + (negate (p_a2187 * c_RESTc_a218T))),
                                   ((p_a217V / (1 + ((c_RESTc_a218T / p_a217X) ** p_a217Z)))
                                    + (negate (p_a2189 * c_EndoNeuroTFs_a2199)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490731",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490733",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490757",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490759",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490773",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490775",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490785",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a218a
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a219M
                            p_a2189 = double g_a2188
                            (g_a2188, gpart_a219M) = Genome.Split.split gpart_a219L
                            p_a2187 = double g_a2186
                            (g_a2186, gpart_a219L) = Genome.Split.split gpart_a219K
                            p_a2185 = double g_a2184
                            (g_a2184, gpart_a219K) = Genome.Split.split gpart_a219J
                            p_a2183 = double g_a2182
                            (g_a2182, gpart_a219J) = Genome.Split.split gpart_a219I
                            p_a2181 = double g_a2180
                            (g_a2180, gpart_a219I) = Genome.Split.split gpart_a219H
                            p_a217Z = Functions.belowten' g_a217Y
                            (g_a217Y, gpart_a219H) = Genome.Split.split gpart_a219G
                            p_a217X = double g_a217W
                            (g_a217W, gpart_a219G) = Genome.Split.split gpart_a219F
                            p_a217V = double g_a217U
                            (g_a217U, gpart_a219F) = Genome.Split.split gpart_a219E
                            p_a217T = double g_a217S
                            (g_a217S, gpart_a219E) = Genome.Split.split gpart_a219D
                            p_a217R = Functions.belowten' g_a217Q
                            (g_a217Q, gpart_a219D) = Genome.Split.split gpart_a219C
                            p_a217P = double g_a217O
                            (g_a217O, gpart_a219C) = Genome.Split.split gpart_a219B
                            p_a217N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217M
                            (g_a217M, gpart_a219B) = Genome.Split.split gpart_a219A
                            p_a217L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217K
                            (g_a217K, gpart_a219A) = Genome.Split.split gpart_a219z
                            p_a217J = Functions.belowten' g_a217I
                            (g_a217I, gpart_a219z) = Genome.Split.split gpart_a219y
                            p_a217H = double g_a217G
                            (g_a217G, gpart_a219y) = Genome.Split.split gpart_a219x
                            p_a217F = double g_a217E
                            (g_a217E, gpart_a219x) = Genome.Split.split gpart_a219w
                            p_a217D = double g_a217C
                            (g_a217C, gpart_a219w) = Genome.Split.split gpart_a219v
                            p_a217B = Functions.belowten' g_a217A
                            (g_a217A, gpart_a219v) = Genome.Split.split gpart_a219u
                            p_a217z = double g_a217y
                            (g_a217y, gpart_a219u) = Genome.Split.split gpart_a219t
                            p_a217x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217w
                            (g_a217w, gpart_a219t) = Genome.Split.split gpart_a219s
                            p_a217v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217u
                            (g_a217u, gpart_a219s) = Genome.Split.split gpart_a219r
                            p_a217t = double g_a217s
                            (g_a217s, gpart_a219r) = Genome.Split.split gpart_a219q
                            p_a217r = double g_a217q
                            (g_a217q, gpart_a219q) = Genome.Split.split gpart_a219p
                            p_a217p = Functions.belowten' g_a217o
                            (g_a217o, gpart_a219p) = Genome.Split.split gpart_a219o
                            p_a217n = double g_a217m
                            (g_a217m, gpart_a219o) = Genome.Split.split gpart_a219n
                            p_a217l = Functions.belowten' g_a217k
                            (g_a217k, gpart_a219n) = Genome.Split.split gpart_a219m
                            p_a217j = double g_a217i
                            (g_a217i, gpart_a219m) = Genome.Split.split gpart_a219l
                            p_a217h = Functions.belowten' g_a217g
                            (g_a217g, gpart_a219l) = Genome.Split.split gpart_a219k
                            p_a217f = double g_a217e
                            (g_a217e, gpart_a219k) = Genome.Split.split gpart_a219j
                            p_a217d = double g_a217c
                            (g_a217c, gpart_a219j) = Genome.Split.split gpart_a219i
                            p_a217b = Functions.belowten' g_a217a
                            (g_a217a, gpart_a219i) = Genome.Split.split gpart_a219h
                            p_a2179 = double g_a2178
                            (g_a2178, gpart_a219h) = Genome.Split.split gpart_a219g
                            p_a2177
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2176
                            (g_a2176, gpart_a219g) = Genome.Split.split gpart_a219f
                            p_a2175
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2174
                            (g_a2174, gpart_a219f) = Genome.Split.split gpart_a219e
                            p_a2173 = double g_a2172
                            (g_a2172, gpart_a219e) = Genome.Split.split gpart_a219d
                            p_a2171 = double g_a2170
                            (g_a2170, gpart_a219d) = Genome.Split.split gpart_a219c
                            p_a216Z = double g_a216Y
                            (g_a216Y, gpart_a219c) = Genome.Split.split gpart_a219b
                            p_a216X = double g_a216W
                            (g_a216W, gpart_a219b) = Genome.Split.split gpart_a219a
                            p_a216V = double g_a216U
                            (g_a216U, gpart_a219a) = Genome.Split.split genome_a218a
                          in
                            \ desc_a218b
                              -> case desc_a218b of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a216V)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a216X)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a216Z)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2171)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2173)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2175)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2177)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2179)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217b)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217d)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217f)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217h)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217j)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217l)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217n)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217p)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217r)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217t)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217v)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217x)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217z)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217B)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217D)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217F)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217H)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217J)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217L)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217N)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217P)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217R)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217T)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217V)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217X)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217Z)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2181)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2183)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2185)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2187)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2189)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a21cc
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21cQ
                      p_a21cb = double g_a21ca
                      (g_a21ca, gpart_a21cQ) = Genome.Split.split gpart_a21cP
                      p_a21c9 = double g_a21c8
                      (g_a21c8, gpart_a21cP) = Genome.Split.split gpart_a21cO
                      p_a21c7 = double g_a21c6
                      (g_a21c6, gpart_a21cO) = Genome.Split.split gpart_a21cN
                      p_a21c5 = double g_a21c4
                      (g_a21c4, gpart_a21cN) = Genome.Split.split gpart_a21cM
                      p_a21c3 = double g_a21c2
                      (g_a21c2, gpart_a21cM) = Genome.Split.split gpart_a21cL
                      p_a21c1 = Functions.belowten' g_a21c0
                      (g_a21c0, gpart_a21cL) = Genome.Split.split gpart_a21cK
                      p_a21bZ = double g_a21bY
                      (g_a21bY, gpart_a21cK) = Genome.Split.split gpart_a21cJ
                      p_a21bX = double g_a21bW
                      (g_a21bW, gpart_a21cJ) = Genome.Split.split gpart_a21cI
                      p_a21bV = double g_a21bU
                      (g_a21bU, gpart_a21cI) = Genome.Split.split gpart_a21cH
                      p_a21bT = Functions.belowten' g_a21bS
                      (g_a21bS, gpart_a21cH) = Genome.Split.split gpart_a21cG
                      p_a21bR = double g_a21bQ
                      (g_a21bQ, gpart_a21cG) = Genome.Split.split gpart_a21cF
                      p_a21bP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bO
                      (g_a21bO, gpart_a21cF) = Genome.Split.split gpart_a21cE
                      p_a21bN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bM
                      (g_a21bM, gpart_a21cE) = Genome.Split.split gpart_a21cD
                      p_a21bL = Functions.belowten' g_a21bK
                      (g_a21bK, gpart_a21cD) = Genome.Split.split gpart_a21cC
                      p_a21bJ = double g_a21bI
                      (g_a21bI, gpart_a21cC) = Genome.Split.split gpart_a21cB
                      p_a21bH = double g_a21bG
                      (g_a21bG, gpart_a21cB) = Genome.Split.split gpart_a21cA
                      p_a21bF = double g_a21bE
                      (g_a21bE, gpart_a21cA) = Genome.Split.split gpart_a21cz
                      p_a21bD = Functions.belowten' g_a21bC
                      (g_a21bC, gpart_a21cz) = Genome.Split.split gpart_a21cy
                      p_a21bB = double g_a21bA
                      (g_a21bA, gpart_a21cy) = Genome.Split.split gpart_a21cx
                      p_a21bz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21by
                      (g_a21by, gpart_a21cx) = Genome.Split.split gpart_a21cw
                      p_a21bx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bw
                      (g_a21bw, gpart_a21cw) = Genome.Split.split gpart_a21cv
                      p_a21bv = double g_a21bu
                      (g_a21bu, gpart_a21cv) = Genome.Split.split gpart_a21cu
                      p_a21bt = double g_a21bs
                      (g_a21bs, gpart_a21cu) = Genome.Split.split gpart_a21ct
                      p_a21br = Functions.belowten' g_a21bq
                      (g_a21bq, gpart_a21ct) = Genome.Split.split gpart_a21cs
                      p_a21bp = double g_a21bo
                      (g_a21bo, gpart_a21cs) = Genome.Split.split gpart_a21cr
                      p_a21bn = Functions.belowten' g_a21bm
                      (g_a21bm, gpart_a21cr) = Genome.Split.split gpart_a21cq
                      p_a21bl = double g_a21bk
                      (g_a21bk, gpart_a21cq) = Genome.Split.split gpart_a21cp
                      p_a21bj = Functions.belowten' g_a21bi
                      (g_a21bi, gpart_a21cp) = Genome.Split.split gpart_a21co
                      p_a21bh = double g_a21bg
                      (g_a21bg, gpart_a21co) = Genome.Split.split gpart_a21cn
                      p_a21bf = double g_a21be
                      (g_a21be, gpart_a21cn) = Genome.Split.split gpart_a21cm
                      p_a21bd = Functions.belowten' g_a21bc
                      (g_a21bc, gpart_a21cm) = Genome.Split.split gpart_a21cl
                      p_a21bb = double g_a21ba
                      (g_a21ba, gpart_a21cl) = Genome.Split.split gpart_a21ck
                      p_a21b9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21b8
                      (g_a21b8, gpart_a21ck) = Genome.Split.split gpart_a21cj
                      p_a21b7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21b6
                      (g_a21b6, gpart_a21cj) = Genome.Split.split gpart_a21ci
                      p_a21b5 = double g_a21b4
                      (g_a21b4, gpart_a21ci) = Genome.Split.split gpart_a21ch
                      p_a21b3 = double g_a21b2
                      (g_a21b2, gpart_a21ch) = Genome.Split.split gpart_a21cg
                      p_a21b1 = double g_a21b0
                      (g_a21b0, gpart_a21cg) = Genome.Split.split gpart_a21cf
                      p_a21aZ = double g_a21aY
                      (g_a21aY, gpart_a21cf) = Genome.Split.split gpart_a21ce
                      p_a21aX = double g_a21aW
                      (g_a21aW, gpart_a21ce) = Genome.Split.split genome_a21cc
                    in  \ x_a21cR
                          -> let
                               c_PTB_a21cU
                                 = ((Data.Fixed.Vector.toVector x_a21cR) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21cS
                                 = ((Data.Fixed.Vector.toVector x_a21cR) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21d0
                                 = ((Data.Fixed.Vector.toVector x_a21cR) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21cV
                                 = ((Data.Fixed.Vector.toVector x_a21cR) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21db
                                 = ((Data.Fixed.Vector.toVector x_a21cR) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21b5 / (1 + ((c_MiRs_a21cS / p_a21bb) ** p_a21bd)))
                                    + (negate (p_a21c3 * c_PTB_a21cU))),
                                   ((p_a21bf
                                     * ((p_a21bt + ((c_RESTc_a21cV / p_a21bh) ** p_a21bj))
                                        / (((1 + p_a21bt) + ((c_RESTc_a21cV / p_a21bh) ** p_a21bj))
                                           + (((c_MiRs_a21cS / p_a21bl) ** p_a21bn)
                                              + ((c_PTB_a21cU / p_a21bp) ** p_a21br)))))
                                    + (negate (p_a21c5 * c_NPTB_a21d0))),
                                   ((p_a21bv
                                     * (p_a21bF
                                        / ((1 + p_a21bF) + ((c_RESTc_a21cV / p_a21bB) ** p_a21bD))))
                                    + (negate (p_a21c7 * c_MiRs_a21cS))),
                                   ((p_a21bH
                                     * ((p_a21bV + ((c_PTB_a21cU / p_a21bJ) ** p_a21bL))
                                        / (((1 + p_a21bV) + ((c_PTB_a21cU / p_a21bJ) ** p_a21bL))
                                           + ((c_MiRs_a21cS / p_a21bR) ** p_a21bT))))
                                    + (negate (p_a21c9 * c_RESTc_a21cV))),
                                   ((p_a21bX / (1 + ((c_RESTc_a21cV / p_a21bZ) ** p_a21c1)))
                                    + (negate (p_a21cb * c_EndoNeuroTFs_a21db)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490981",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490983",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490999",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491001",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491007",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491009",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491023",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491025",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491045",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21cc
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21dO
                            p_a21cb = double g_a21ca
                            (g_a21ca, gpart_a21dO) = Genome.Split.split gpart_a21dN
                            p_a21c9 = double g_a21c8
                            (g_a21c8, gpart_a21dN) = Genome.Split.split gpart_a21dM
                            p_a21c7 = double g_a21c6
                            (g_a21c6, gpart_a21dM) = Genome.Split.split gpart_a21dL
                            p_a21c5 = double g_a21c4
                            (g_a21c4, gpart_a21dL) = Genome.Split.split gpart_a21dK
                            p_a21c3 = double g_a21c2
                            (g_a21c2, gpart_a21dK) = Genome.Split.split gpart_a21dJ
                            p_a21c1 = Functions.belowten' g_a21c0
                            (g_a21c0, gpart_a21dJ) = Genome.Split.split gpart_a21dI
                            p_a21bZ = double g_a21bY
                            (g_a21bY, gpart_a21dI) = Genome.Split.split gpart_a21dH
                            p_a21bX = double g_a21bW
                            (g_a21bW, gpart_a21dH) = Genome.Split.split gpart_a21dG
                            p_a21bV = double g_a21bU
                            (g_a21bU, gpart_a21dG) = Genome.Split.split gpart_a21dF
                            p_a21bT = Functions.belowten' g_a21bS
                            (g_a21bS, gpart_a21dF) = Genome.Split.split gpart_a21dE
                            p_a21bR = double g_a21bQ
                            (g_a21bQ, gpart_a21dE) = Genome.Split.split gpart_a21dD
                            p_a21bP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bO
                            (g_a21bO, gpart_a21dD) = Genome.Split.split gpart_a21dC
                            p_a21bN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bM
                            (g_a21bM, gpart_a21dC) = Genome.Split.split gpart_a21dB
                            p_a21bL = Functions.belowten' g_a21bK
                            (g_a21bK, gpart_a21dB) = Genome.Split.split gpart_a21dA
                            p_a21bJ = double g_a21bI
                            (g_a21bI, gpart_a21dA) = Genome.Split.split gpart_a21dz
                            p_a21bH = double g_a21bG
                            (g_a21bG, gpart_a21dz) = Genome.Split.split gpart_a21dy
                            p_a21bF = double g_a21bE
                            (g_a21bE, gpart_a21dy) = Genome.Split.split gpart_a21dx
                            p_a21bD = Functions.belowten' g_a21bC
                            (g_a21bC, gpart_a21dx) = Genome.Split.split gpart_a21dw
                            p_a21bB = double g_a21bA
                            (g_a21bA, gpart_a21dw) = Genome.Split.split gpart_a21dv
                            p_a21bz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21by
                            (g_a21by, gpart_a21dv) = Genome.Split.split gpart_a21du
                            p_a21bx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bw
                            (g_a21bw, gpart_a21du) = Genome.Split.split gpart_a21dt
                            p_a21bv = double g_a21bu
                            (g_a21bu, gpart_a21dt) = Genome.Split.split gpart_a21ds
                            p_a21bt = double g_a21bs
                            (g_a21bs, gpart_a21ds) = Genome.Split.split gpart_a21dr
                            p_a21br = Functions.belowten' g_a21bq
                            (g_a21bq, gpart_a21dr) = Genome.Split.split gpart_a21dq
                            p_a21bp = double g_a21bo
                            (g_a21bo, gpart_a21dq) = Genome.Split.split gpart_a21dp
                            p_a21bn = Functions.belowten' g_a21bm
                            (g_a21bm, gpart_a21dp) = Genome.Split.split gpart_a21do
                            p_a21bl = double g_a21bk
                            (g_a21bk, gpart_a21do) = Genome.Split.split gpart_a21dn
                            p_a21bj = Functions.belowten' g_a21bi
                            (g_a21bi, gpart_a21dn) = Genome.Split.split gpart_a21dm
                            p_a21bh = double g_a21bg
                            (g_a21bg, gpart_a21dm) = Genome.Split.split gpart_a21dl
                            p_a21bf = double g_a21be
                            (g_a21be, gpart_a21dl) = Genome.Split.split gpart_a21dk
                            p_a21bd = Functions.belowten' g_a21bc
                            (g_a21bc, gpart_a21dk) = Genome.Split.split gpart_a21dj
                            p_a21bb = double g_a21ba
                            (g_a21ba, gpart_a21dj) = Genome.Split.split gpart_a21di
                            p_a21b9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21b8
                            (g_a21b8, gpart_a21di) = Genome.Split.split gpart_a21dh
                            p_a21b7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21b6
                            (g_a21b6, gpart_a21dh) = Genome.Split.split gpart_a21dg
                            p_a21b5 = double g_a21b4
                            (g_a21b4, gpart_a21dg) = Genome.Split.split gpart_a21df
                            p_a21b3 = double g_a21b2
                            (g_a21b2, gpart_a21df) = Genome.Split.split gpart_a21de
                            p_a21b1 = double g_a21b0
                            (g_a21b0, gpart_a21de) = Genome.Split.split gpart_a21dd
                            p_a21aZ = double g_a21aY
                            (g_a21aY, gpart_a21dd) = Genome.Split.split gpart_a21dc
                            p_a21aX = double g_a21aW
                            (g_a21aW, gpart_a21dc) = Genome.Split.split genome_a21cc
                          in
                            \ desc_a21cd
                              -> case desc_a21cd of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21aX)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21aZ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21b1)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21b3)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21b5)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21b7)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21b9)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bb)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bd)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bf)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bh)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21br)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bt)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bv)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bx)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bz)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bB)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bD)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bF)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bH)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bJ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bL)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bN)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bP)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bR)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bT)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bV)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bX)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bZ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c1)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c3)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c5)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c7)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c9)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cb)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a21ge
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21gS
                      p_a21gd = double g_a21gc
                      (g_a21gc, gpart_a21gS) = Genome.Split.split gpart_a21gR
                      p_a21gb = double g_a21ga
                      (g_a21ga, gpart_a21gR) = Genome.Split.split gpart_a21gQ
                      p_a21g9 = double g_a21g8
                      (g_a21g8, gpart_a21gQ) = Genome.Split.split gpart_a21gP
                      p_a21g7 = double g_a21g6
                      (g_a21g6, gpart_a21gP) = Genome.Split.split gpart_a21gO
                      p_a21g5 = double g_a21g4
                      (g_a21g4, gpart_a21gO) = Genome.Split.split gpart_a21gN
                      p_a21g3 = Functions.belowten' g_a21g2
                      (g_a21g2, gpart_a21gN) = Genome.Split.split gpart_a21gM
                      p_a21g1 = double g_a21g0
                      (g_a21g0, gpart_a21gM) = Genome.Split.split gpart_a21gL
                      p_a21fZ = double g_a21fY
                      (g_a21fY, gpart_a21gL) = Genome.Split.split gpart_a21gK
                      p_a21fX = double g_a21fW
                      (g_a21fW, gpart_a21gK) = Genome.Split.split gpart_a21gJ
                      p_a21fV = Functions.belowten' g_a21fU
                      (g_a21fU, gpart_a21gJ) = Genome.Split.split gpart_a21gI
                      p_a21fT = double g_a21fS
                      (g_a21fS, gpart_a21gI) = Genome.Split.split gpart_a21gH
                      p_a21fR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fQ
                      (g_a21fQ, gpart_a21gH) = Genome.Split.split gpart_a21gG
                      p_a21fP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fO
                      (g_a21fO, gpart_a21gG) = Genome.Split.split gpart_a21gF
                      p_a21fN = Functions.belowten' g_a21fM
                      (g_a21fM, gpart_a21gF) = Genome.Split.split gpart_a21gE
                      p_a21fL = double g_a21fK
                      (g_a21fK, gpart_a21gE) = Genome.Split.split gpart_a21gD
                      p_a21fJ = double g_a21fI
                      (g_a21fI, gpart_a21gD) = Genome.Split.split gpart_a21gC
                      p_a21fH = double g_a21fG
                      (g_a21fG, gpart_a21gC) = Genome.Split.split gpart_a21gB
                      p_a21fF = Functions.belowten' g_a21fE
                      (g_a21fE, gpart_a21gB) = Genome.Split.split gpart_a21gA
                      p_a21fD = double g_a21fC
                      (g_a21fC, gpart_a21gA) = Genome.Split.split gpart_a21gz
                      p_a21fB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fA
                      (g_a21fA, gpart_a21gz) = Genome.Split.split gpart_a21gy
                      p_a21fz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fy
                      (g_a21fy, gpart_a21gy) = Genome.Split.split gpart_a21gx
                      p_a21fx = double g_a21fw
                      (g_a21fw, gpart_a21gx) = Genome.Split.split gpart_a21gw
                      p_a21fv = double g_a21fu
                      (g_a21fu, gpart_a21gw) = Genome.Split.split gpart_a21gv
                      p_a21ft = Functions.belowten' g_a21fs
                      (g_a21fs, gpart_a21gv) = Genome.Split.split gpart_a21gu
                      p_a21fr = double g_a21fq
                      (g_a21fq, gpart_a21gu) = Genome.Split.split gpart_a21gt
                      p_a21fp = Functions.belowten' g_a21fo
                      (g_a21fo, gpart_a21gt) = Genome.Split.split gpart_a21gs
                      p_a21fn = double g_a21fm
                      (g_a21fm, gpart_a21gs) = Genome.Split.split gpart_a21gr
                      p_a21fl = Functions.belowten' g_a21fk
                      (g_a21fk, gpart_a21gr) = Genome.Split.split gpart_a21gq
                      p_a21fj = double g_a21fi
                      (g_a21fi, gpart_a21gq) = Genome.Split.split gpart_a21gp
                      p_a21fh = double g_a21fg
                      (g_a21fg, gpart_a21gp) = Genome.Split.split gpart_a21go
                      p_a21ff = Functions.belowten' g_a21fe
                      (g_a21fe, gpart_a21go) = Genome.Split.split gpart_a21gn
                      p_a21fd = double g_a21fc
                      (g_a21fc, gpart_a21gn) = Genome.Split.split gpart_a21gm
                      p_a21fb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fa
                      (g_a21fa, gpart_a21gm) = Genome.Split.split gpart_a21gl
                      p_a21f9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21f8
                      (g_a21f8, gpart_a21gl) = Genome.Split.split gpart_a21gk
                      p_a21f7 = double g_a21f6
                      (g_a21f6, gpart_a21gk) = Genome.Split.split gpart_a21gj
                      p_a21f5 = double g_a21f4
                      (g_a21f4, gpart_a21gj) = Genome.Split.split gpart_a21gi
                      p_a21f3 = double g_a21f2
                      (g_a21f2, gpart_a21gi) = Genome.Split.split gpart_a21gh
                      p_a21f1 = double g_a21f0
                      (g_a21f0, gpart_a21gh) = Genome.Split.split gpart_a21gg
                      p_a21eZ = double g_a21eY
                      (g_a21eY, gpart_a21gg) = Genome.Split.split genome_a21ge
                    in  \ x_a21gT
                          -> let
                               c_PTB_a21gW
                                 = ((Data.Fixed.Vector.toVector x_a21gT) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21gU
                                 = ((Data.Fixed.Vector.toVector x_a21gT) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21h2
                                 = ((Data.Fixed.Vector.toVector x_a21gT) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21gX
                                 = ((Data.Fixed.Vector.toVector x_a21gT) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21hd
                                 = ((Data.Fixed.Vector.toVector x_a21gT) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21f7
                                     / (1
                                        + (((p_a21eZ / p_a21f9) ** p_a21fb)
                                           + ((c_MiRs_a21gU / p_a21fd) ** p_a21ff))))
                                    + (negate (p_a21g5 * c_PTB_a21gW))),
                                   ((p_a21fh
                                     * ((p_a21fv + ((c_RESTc_a21gX / p_a21fj) ** p_a21fl))
                                        / (((1 + p_a21fv) + ((c_RESTc_a21gX / p_a21fj) ** p_a21fl))
                                           + (((c_MiRs_a21gU / p_a21fn) ** p_a21fp)
                                              + ((c_PTB_a21gW / p_a21fr) ** p_a21ft)))))
                                    + (negate (p_a21g7 * c_NPTB_a21h2))),
                                   ((p_a21fx
                                     * (p_a21fH
                                        / ((1 + p_a21fH) + ((c_RESTc_a21gX / p_a21fD) ** p_a21fF))))
                                    + (negate (p_a21g9 * c_MiRs_a21gU))),
                                   ((p_a21fJ
                                     * ((p_a21fX + ((c_PTB_a21gW / p_a21fL) ** p_a21fN))
                                        / (((1 + p_a21fX) + ((c_PTB_a21gW / p_a21fL) ** p_a21fN))
                                           + ((c_MiRs_a21gU / p_a21fT) ** p_a21fV))))
                                    + (negate (p_a21gb * c_RESTc_a21gX))),
                                   ((p_a21fZ / (1 + ((c_RESTc_a21gX / p_a21g1) ** p_a21g3)))
                                    + (negate (p_a21gd * c_EndoNeuroTFs_a21hd)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491231",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491233",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491257",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491259",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491273",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491275",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21ge
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21hQ
                            p_a21gd = double g_a21gc
                            (g_a21gc, gpart_a21hQ) = Genome.Split.split gpart_a21hP
                            p_a21gb = double g_a21ga
                            (g_a21ga, gpart_a21hP) = Genome.Split.split gpart_a21hO
                            p_a21g9 = double g_a21g8
                            (g_a21g8, gpart_a21hO) = Genome.Split.split gpart_a21hN
                            p_a21g7 = double g_a21g6
                            (g_a21g6, gpart_a21hN) = Genome.Split.split gpart_a21hM
                            p_a21g5 = double g_a21g4
                            (g_a21g4, gpart_a21hM) = Genome.Split.split gpart_a21hL
                            p_a21g3 = Functions.belowten' g_a21g2
                            (g_a21g2, gpart_a21hL) = Genome.Split.split gpart_a21hK
                            p_a21g1 = double g_a21g0
                            (g_a21g0, gpart_a21hK) = Genome.Split.split gpart_a21hJ
                            p_a21fZ = double g_a21fY
                            (g_a21fY, gpart_a21hJ) = Genome.Split.split gpart_a21hI
                            p_a21fX = double g_a21fW
                            (g_a21fW, gpart_a21hI) = Genome.Split.split gpart_a21hH
                            p_a21fV = Functions.belowten' g_a21fU
                            (g_a21fU, gpart_a21hH) = Genome.Split.split gpart_a21hG
                            p_a21fT = double g_a21fS
                            (g_a21fS, gpart_a21hG) = Genome.Split.split gpart_a21hF
                            p_a21fR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fQ
                            (g_a21fQ, gpart_a21hF) = Genome.Split.split gpart_a21hE
                            p_a21fP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fO
                            (g_a21fO, gpart_a21hE) = Genome.Split.split gpart_a21hD
                            p_a21fN = Functions.belowten' g_a21fM
                            (g_a21fM, gpart_a21hD) = Genome.Split.split gpart_a21hC
                            p_a21fL = double g_a21fK
                            (g_a21fK, gpart_a21hC) = Genome.Split.split gpart_a21hB
                            p_a21fJ = double g_a21fI
                            (g_a21fI, gpart_a21hB) = Genome.Split.split gpart_a21hA
                            p_a21fH = double g_a21fG
                            (g_a21fG, gpart_a21hA) = Genome.Split.split gpart_a21hz
                            p_a21fF = Functions.belowten' g_a21fE
                            (g_a21fE, gpart_a21hz) = Genome.Split.split gpart_a21hy
                            p_a21fD = double g_a21fC
                            (g_a21fC, gpart_a21hy) = Genome.Split.split gpart_a21hx
                            p_a21fB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fA
                            (g_a21fA, gpart_a21hx) = Genome.Split.split gpart_a21hw
                            p_a21fz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fy
                            (g_a21fy, gpart_a21hw) = Genome.Split.split gpart_a21hv
                            p_a21fx = double g_a21fw
                            (g_a21fw, gpart_a21hv) = Genome.Split.split gpart_a21hu
                            p_a21fv = double g_a21fu
                            (g_a21fu, gpart_a21hu) = Genome.Split.split gpart_a21ht
                            p_a21ft = Functions.belowten' g_a21fs
                            (g_a21fs, gpart_a21ht) = Genome.Split.split gpart_a21hs
                            p_a21fr = double g_a21fq
                            (g_a21fq, gpart_a21hs) = Genome.Split.split gpart_a21hr
                            p_a21fp = Functions.belowten' g_a21fo
                            (g_a21fo, gpart_a21hr) = Genome.Split.split gpart_a21hq
                            p_a21fn = double g_a21fm
                            (g_a21fm, gpart_a21hq) = Genome.Split.split gpart_a21hp
                            p_a21fl = Functions.belowten' g_a21fk
                            (g_a21fk, gpart_a21hp) = Genome.Split.split gpart_a21ho
                            p_a21fj = double g_a21fi
                            (g_a21fi, gpart_a21ho) = Genome.Split.split gpart_a21hn
                            p_a21fh = double g_a21fg
                            (g_a21fg, gpart_a21hn) = Genome.Split.split gpart_a21hm
                            p_a21ff = Functions.belowten' g_a21fe
                            (g_a21fe, gpart_a21hm) = Genome.Split.split gpart_a21hl
                            p_a21fd = double g_a21fc
                            (g_a21fc, gpart_a21hl) = Genome.Split.split gpart_a21hk
                            p_a21fb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fa
                            (g_a21fa, gpart_a21hk) = Genome.Split.split gpart_a21hj
                            p_a21f9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21f8
                            (g_a21f8, gpart_a21hj) = Genome.Split.split gpart_a21hi
                            p_a21f7 = double g_a21f6
                            (g_a21f6, gpart_a21hi) = Genome.Split.split gpart_a21hh
                            p_a21f5 = double g_a21f4
                            (g_a21f4, gpart_a21hh) = Genome.Split.split gpart_a21hg
                            p_a21f3 = double g_a21f2
                            (g_a21f2, gpart_a21hg) = Genome.Split.split gpart_a21hf
                            p_a21f1 = double g_a21f0
                            (g_a21f0, gpart_a21hf) = Genome.Split.split gpart_a21he
                            p_a21eZ = double g_a21eY
                            (g_a21eY, gpart_a21he) = Genome.Split.split genome_a21ge
                          in
                            \ desc_a21gf
                              -> case desc_a21gf of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21eZ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21f1)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21f3)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21f5)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21f7)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21f9)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fb)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fd)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ff)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fh)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fj)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fl)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fn)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fp)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fr)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ft)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fv)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fx)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fz)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fB)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fD)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fF)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fH)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fJ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fL)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fN)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fP)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fR)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fT)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fV)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fX)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g1)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g3)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g5)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g7)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g9)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gb)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gd)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVT
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWx
                      p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                      (g_asVR, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                      (g_asVP, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                      (g_asVN, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                      (g_asVL, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                      (g_asVJ, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asVI = Functions.belowten' g_asVH
                      (g_asVH, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asVG = code-0.1.0.0:Genome.FixedList.Functions.double g_asVF
                      (g_asVF, gpart_asWr) = Genome.Split.split gpart_asWq
                      p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                      (g_asVD, gpart_asWq) = Genome.Split.split gpart_asWp
                      p_asVC = code-0.1.0.0:Genome.FixedList.Functions.double g_asVB
                      (g_asVB, gpart_asWp) = Genome.Split.split gpart_asWo
                      p_asVA = Functions.belowten' g_asVz
                      (g_asVz, gpart_asWo) = Genome.Split.split gpart_asWn
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWn) = Genome.Split.split gpart_asWm
                      p_asVw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVv
                      (g_asVv, gpart_asWm) = Genome.Split.split gpart_asWl
                      p_asVu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVt
                      (g_asVt, gpart_asWl) = Genome.Split.split gpart_asWk
                      p_asVs = Functions.belowten' g_asVr
                      (g_asVr, gpart_asWk) = Genome.Split.split gpart_asWj
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWj) = Genome.Split.split gpart_asWi
                      p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                      (g_asVn, gpart_asWi) = Genome.Split.split gpart_asWh
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWh) = Genome.Split.split gpart_asWg
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asWg) = Genome.Split.split gpart_asWf
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asWf) = Genome.Split.split gpart_asWe
                      p_asVg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                      (g_asVf, gpart_asWe) = Genome.Split.split gpart_asWd
                      p_asVe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                      (g_asVd, gpart_asWd) = Genome.Split.split gpart_asWc
                      p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                      (g_asVb, gpart_asWc) = Genome.Split.split gpart_asWb
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asWb) = Genome.Split.split gpart_asWa
                      p_asV8 = Functions.belowten' g_asV7
                      (g_asV7, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asV4 = Functions.belowten' g_asV3
                      (g_asV3, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asV0 = Functions.belowten' g_asUZ
                      (g_asUZ, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asUU = Functions.belowten' g_asUT
                      (g_asUT, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asUQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                      (g_asUP, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asUO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                      (g_asUN, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                      (g_asUL, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                      (g_asUJ, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                      (g_asUH, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                      (g_asUF, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                      (g_asUD, gpart_asVV) = Genome.Split.split genome_asVT
                    in
                      [Reaction
                         (\ x_asWy
                            -> let c_MiRs_asWz = ((toVector x_asWy) Data.Vector.Unboxed.! 2)
                               in (p_asUM / (1 + ((c_MiRs_asWz / p_asUS) ** p_asUU))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWA
                            -> let
                                 c_PTB_asWE = ((toVector x_asWA) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asWD = ((toVector x_asWA) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWB = ((toVector x_asWA) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUW
                                  * ((p_asVa + ((c_RESTc_asWB / p_asUY) ** p_asV0))
                                     / (((1 + p_asVa) + ((c_RESTc_asWB / p_asUY) ** p_asV0))
                                        + (((c_MiRs_asWD / p_asV2) ** p_asV4)
                                           + ((c_PTB_asWE / p_asV6) ** p_asV8))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWF
                            -> let c_RESTc_asWG = ((toVector x_asWF) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVc
                                  * ((p_asVm + ((p_asUI / p_asVe) ** p_asVg))
                                     / (((1 + p_asVm) + ((p_asUI / p_asVe) ** p_asVg))
                                        + ((c_RESTc_asWG / p_asVi) ** p_asVk)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWH
                            -> let
                                 c_MiRs_asWK = ((toVector x_asWH) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWI = ((toVector x_asWH) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVo
                                  * ((p_asVC + ((c_PTB_asWI / p_asVq) ** p_asVs))
                                     / (((1 + p_asVC) + ((c_PTB_asWI / p_asVq) ** p_asVs))
                                        + (((p_asUE / p_asVu) ** p_asVw)
                                           + ((c_MiRs_asWK / p_asVy) ** p_asVA))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWL
                            -> let c_RESTc_asWM = ((toVector x_asWL) Data.Vector.Unboxed.! 3)
                               in (p_asVE / (1 + ((c_RESTc_asWM / p_asVG) ** p_asVI))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWN
                            -> let c_PTB_asWO = ((toVector x_asWN) Data.Vector.Unboxed.! 0)
                               in (p_asVK * c_PTB_asWO))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWP
                            -> let c_NPTB_asWQ = ((toVector x_asWP) Data.Vector.Unboxed.! 1)
                               in (p_asVM * c_NPTB_asWQ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWR
                            -> let c_MiRs_asWS = ((toVector x_asWR) Data.Vector.Unboxed.! 2)
                               in (p_asVO * c_MiRs_asWS))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWT
                            -> let c_RESTc_asWU = ((toVector x_asWT) Data.Vector.Unboxed.! 3)
                               in (p_asVQ * c_RESTc_asWU))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWV
                            -> let
                                 c_EndoNeuroTFs_asWW = ((toVector x_asWV) Data.Vector.Unboxed.! 4)
                               in (p_asVS * c_EndoNeuroTFs_asWW))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVT
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXE
                            p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                            (g_asVR, gpart_asXE) = Genome.Split.split gpart_asXD
                            p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                            (g_asVP, gpart_asXD) = Genome.Split.split gpart_asXC
                            p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                            (g_asVN, gpart_asXC) = Genome.Split.split gpart_asXB
                            p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                            (g_asVL, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                            (g_asVJ, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asVI = Functions.belowten' g_asVH
                            (g_asVH, gpart_asXz) = Genome.Split.split gpart_asXy
                            p_asVG = code-0.1.0.0:Genome.FixedList.Functions.double g_asVF
                            (g_asVF, gpart_asXy) = Genome.Split.split gpart_asXx
                            p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                            (g_asVD, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVC = code-0.1.0.0:Genome.FixedList.Functions.double g_asVB
                            (g_asVB, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVA = Functions.belowten' g_asVz
                            (g_asVz, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVv
                            (g_asVv, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVt
                            (g_asVt, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVs = Functions.belowten' g_asVr
                            (g_asVr, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                            (g_asVn, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asVg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                            (g_asVf, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asVe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                            (g_asVd, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                            (g_asVb, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asV8 = Functions.belowten' g_asV7
                            (g_asV7, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asV4 = Functions.belowten' g_asV3
                            (g_asV3, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asV0 = Functions.belowten' g_asUZ
                            (g_asUZ, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asUU = Functions.belowten' g_asUT
                            (g_asUT, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asUQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                            (g_asUP, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asUO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                            (g_asUN, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                            (g_asUL, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                            (g_asUJ, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                            (g_asUH, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                            (g_asUF, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                            (g_asUD, gpart_asX2) = Genome.Split.split genome_asVT
                          in
                            \ desc_asVU
                              -> case desc_asVU of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0f
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0f) = Genome.Split.split gpart_at0e
                      p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                      (g_asZx, gpart_at0e) = Genome.Split.split gpart_at0d
                      p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                      (g_asZv, gpart_at0d) = Genome.Split.split gpart_at0c
                      p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                      (g_asZt, gpart_at0c) = Genome.Split.split gpart_at0b
                      p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                      (g_asZr, gpart_at0b) = Genome.Split.split gpart_at0a
                      p_asZq = Functions.belowten' g_asZp
                      (g_asZp, gpart_at0a) = Genome.Split.split gpart_at09
                      p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                      (g_asZn, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                      (g_asZl, gpart_at08) = Genome.Split.split gpart_at07
                      p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                      (g_asZj, gpart_at07) = Genome.Split.split gpart_at06
                      p_asZi = Functions.belowten' g_asZh
                      (g_asZh, gpart_at06) = Genome.Split.split gpart_at05
                      p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                      (g_asZf, gpart_at05) = Genome.Split.split gpart_at04
                      p_asZe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZd
                      (g_asZd, gpart_at04) = Genome.Split.split gpart_at03
                      p_asZc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZb
                      (g_asZb, gpart_at03) = Genome.Split.split gpart_at02
                      p_asZa = Functions.belowten' g_asZ9
                      (g_asZ9, gpart_at02) = Genome.Split.split gpart_at01
                      p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                      (g_asZ7, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                      (g_asZ3, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZ2 = Functions.belowten' g_asZ1
                      (g_asZ1, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                      (g_asYZ, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asYY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYX
                      (g_asYX, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asYW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYV
                      (g_asYV, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                      (g_asYT, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                      (g_asYR, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYQ = Functions.belowten' g_asYP
                      (g_asYP, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYM = Functions.belowten' g_asYL
                      (g_asYL, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYI = Functions.belowten' g_asYH
                      (g_asYH, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                      (g_asYD, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYC = Functions.belowten' g_asYB
                      (g_asYB, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                      (g_asYz, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYx
                      (g_asYx, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYv
                      (g_asYv, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                      (g_asYr, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                      (g_asYn, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZD) = Genome.Split.split genome_asZB
                    in
                      [Reaction
                         (\ x_at0g
                            -> let c_MiRs_at0h = ((toVector x_at0g) Data.Vector.Unboxed.! 2)
                               in (p_asYu / (1 + ((c_MiRs_at0h / p_asYA) ** p_asYC))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0i
                            -> let
                                 c_PTB_at0m = ((toVector x_at0i) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at0l = ((toVector x_at0i) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at0j = ((toVector x_at0i) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYE
                                  * ((p_asYS + ((c_RESTc_at0j / p_asYG) ** p_asYI))
                                     / (((1 + p_asYS) + ((c_RESTc_at0j / p_asYG) ** p_asYI))
                                        + (((c_MiRs_at0l / p_asYK) ** p_asYM)
                                           + ((c_PTB_at0m / p_asYO) ** p_asYQ))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0n
                            -> let c_RESTc_at0o = ((toVector x_at0n) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYU
                                  * (p_asZ4
                                     / ((1 + p_asZ4) + ((c_RESTc_at0o / p_asZ0) ** p_asZ2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0p
                            -> let
                                 c_MiRs_at0s = ((toVector x_at0p) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0q = ((toVector x_at0p) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZ6
                                  * ((p_asZk + ((c_PTB_at0q / p_asZ8) ** p_asZa))
                                     / (((1 + p_asZk) + ((c_PTB_at0q / p_asZ8) ** p_asZa))
                                        + (((p_asYm / p_asZc) ** p_asZe)
                                           + ((c_MiRs_at0s / p_asZg) ** p_asZi))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0t
                            -> let c_RESTc_at0u = ((toVector x_at0t) Data.Vector.Unboxed.! 3)
                               in (p_asZm / (1 + ((c_RESTc_at0u / p_asZo) ** p_asZq))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0v
                            -> let c_PTB_at0w = ((toVector x_at0v) Data.Vector.Unboxed.! 0)
                               in (p_asZs * c_PTB_at0w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0x
                            -> let c_NPTB_at0y = ((toVector x_at0x) Data.Vector.Unboxed.! 1)
                               in (p_asZu * c_NPTB_at0y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0z
                            -> let c_MiRs_at0A = ((toVector x_at0z) Data.Vector.Unboxed.! 2)
                               in (p_asZw * c_MiRs_at0A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0B
                            -> let c_RESTc_at0C = ((toVector x_at0B) Data.Vector.Unboxed.! 3)
                               in (p_asZy * c_RESTc_at0C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0D
                            -> let
                                 c_EndoNeuroTFs_at0E = ((toVector x_at0D) Data.Vector.Unboxed.! 4)
                               in (p_asZA * c_EndoNeuroTFs_at0E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1h
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at1h) = Genome.Split.split gpart_at1g
                            p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                            (g_asZx, gpart_at1g) = Genome.Split.split gpart_at1f
                            p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                            (g_asZv, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                            (g_asZt, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                            (g_asZr, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asZq = Functions.belowten' g_asZp
                            (g_asZp, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                            (g_asZn, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                            (g_asZl, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                            (g_asZj, gpart_at19) = Genome.Split.split gpart_at18
                            p_asZi = Functions.belowten' g_asZh
                            (g_asZh, gpart_at18) = Genome.Split.split gpart_at17
                            p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                            (g_asZf, gpart_at17) = Genome.Split.split gpart_at16
                            p_asZe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZd
                            (g_asZd, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZb
                            (g_asZb, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZa = Functions.belowten' g_asZ9
                            (g_asZ9, gpart_at14) = Genome.Split.split gpart_at13
                            p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                            (g_asZ7, gpart_at13) = Genome.Split.split gpart_at12
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at12) = Genome.Split.split gpart_at11
                            p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                            (g_asZ3, gpart_at11) = Genome.Split.split gpart_at10
                            p_asZ2 = Functions.belowten' g_asZ1
                            (g_asZ1, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                            (g_asYZ, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYX
                            (g_asYX, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYV
                            (g_asYV, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                            (g_asYT, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                            (g_asYR, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYQ = Functions.belowten' g_asYP
                            (g_asYP, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYM = Functions.belowten' g_asYL
                            (g_asYL, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYI = Functions.belowten' g_asYH
                            (g_asYH, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                            (g_asYD, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYC = Functions.belowten' g_asYB
                            (g_asYB, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYA = code-0.1.0.0:Genome.FixedList.Functions.double g_asYz
                            (g_asYz, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYx
                            (g_asYx, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYv
                            (g_asYv, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                            (g_asYr, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                            (g_asYn, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at0F) = Genome.Split.split genome_asZB
                          in
                            \ desc_asZC
                              -> case desc_asZC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZm)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZo)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3e
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3S
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                      (g_at3a, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                      (g_at38, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                      (g_at36, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                      (g_at34, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at33 = Functions.belowten' g_at32
                      (g_at32, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                      (g_at2Y, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2V = Functions.belowten' g_at2U
                      (g_at2U, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2Q
                      (g_at2Q, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2O
                      (g_at2O, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2N = Functions.belowten' g_at2M
                      (g_at2M, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                      (g_at2K, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2F = Functions.belowten' g_at2E
                      (g_at2E, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                      (g_at2C, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2A
                      (g_at2A, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                      (g_at2y, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                      (g_at2w, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                      (g_at2u, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2t = Functions.belowten' g_at2s
                      (g_at2s, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                      (g_at2q, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2p = Functions.belowten' g_at2o
                      (g_at2o, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                      (g_at2m, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2l = Functions.belowten' g_at2k
                      (g_at2k, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                      (g_at2i, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                      (g_at2g, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2f = Functions.belowten' g_at2e
                      (g_at2e, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                      (g_at2c, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2a
                      (g_at2a, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at29
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at28
                      (g_at28, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                      (g_at26, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                      (g_at24, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at21 = code-0.1.0.0:Genome.FixedList.Functions.double g_at20
                      (g_at20, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at3g) = Genome.Split.split genome_at3e
                    in
                      [Reaction
                         (\ x_at3T
                            -> let c_MiRs_at3U = ((toVector x_at3T) Data.Vector.Unboxed.! 2)
                               in (p_at27 / (1 + ((c_MiRs_at3U / p_at2d) ** p_at2f))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3V
                            -> let
                                 c_PTB_at3Z = ((toVector x_at3V) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at3Y = ((toVector x_at3V) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3W = ((toVector x_at3V) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2h
                                  * ((p_at2v + ((c_RESTc_at3W / p_at2j) ** p_at2l))
                                     / (((1 + p_at2v) + ((c_RESTc_at3W / p_at2j) ** p_at2l))
                                        + (((c_MiRs_at3Y / p_at2n) ** p_at2p)
                                           + ((c_PTB_at3Z / p_at2r) ** p_at2t))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at40
                            -> let c_RESTc_at41 = ((toVector x_at40) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2x
                                  * (p_at2H
                                     / ((1 + p_at2H) + ((c_RESTc_at41 / p_at2D) ** p_at2F)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at42
                            -> let
                                 c_MiRs_at45 = ((toVector x_at42) Data.Vector.Unboxed.! 2)
                                 c_PTB_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2J
                                  * ((p_at2X + ((c_PTB_at43 / p_at2L) ** p_at2N))
                                     / (((1 + p_at2X) + ((c_PTB_at43 / p_at2L) ** p_at2N))
                                        + ((c_MiRs_at45 / p_at2T) ** p_at2V)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at46
                            -> let c_RESTc_at47 = ((toVector x_at46) Data.Vector.Unboxed.! 3)
                               in (p_at2Z / (1 + ((c_RESTc_at47 / p_at31) ** p_at33))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at48
                            -> let c_PTB_at49 = ((toVector x_at48) Data.Vector.Unboxed.! 0)
                               in (p_at35 * c_PTB_at49))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4a
                            -> let c_NPTB_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 1)
                               in (p_at37 * c_NPTB_at4b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4c
                            -> let c_MiRs_at4d = ((toVector x_at4c) Data.Vector.Unboxed.! 2)
                               in (p_at39 * c_MiRs_at4d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4e
                            -> let c_RESTc_at4f = ((toVector x_at4e) Data.Vector.Unboxed.! 3)
                               in (p_at3b * c_RESTc_at4f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4g
                            -> let
                                 c_EndoNeuroTFs_at4h = ((toVector x_at4g) Data.Vector.Unboxed.! 4)
                               in (p_at3d * c_EndoNeuroTFs_at4h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3e
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4U
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                            (g_at3a, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                            (g_at38, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                            (g_at36, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                            (g_at34, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at33 = Functions.belowten' g_at32
                            (g_at32, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                            (g_at2Y, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2V = Functions.belowten' g_at2U
                            (g_at2U, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2Q
                            (g_at2Q, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2O
                            (g_at2O, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2N = Functions.belowten' g_at2M
                            (g_at2M, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                            (g_at2K, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2F = Functions.belowten' g_at2E
                            (g_at2E, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                            (g_at2C, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2A
                            (g_at2A, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                            (g_at2y, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                            (g_at2w, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                            (g_at2u, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2t = Functions.belowten' g_at2s
                            (g_at2s, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                            (g_at2q, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2p = Functions.belowten' g_at2o
                            (g_at2o, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                            (g_at2m, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2l = Functions.belowten' g_at2k
                            (g_at2k, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                            (g_at2i, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                            (g_at2g, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2f = Functions.belowten' g_at2e
                            (g_at2e, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                            (g_at2c, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2a
                            (g_at2a, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at29
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at28
                            (g_at28, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                            (g_at26, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                            (g_at24, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at21 = code-0.1.0.0:Genome.FixedList.Functions.double g_at20
                            (g_at20, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at4i) = Genome.Split.split genome_at3e
                          in
                            \ desc_at3f
                              -> case desc_at3f of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at33)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at35)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6R
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7v
                      p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                      (g_at6P, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                      (g_at6N, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                      (g_at6J, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6G = Functions.belowten' g_at6F
                      (g_at6F, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                      (g_at6B, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                      (g_at6z, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6y = Functions.belowten' g_at6x
                      (g_at6x, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                      (g_at6v, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6t
                      (g_at6t, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6r
                      (g_at6r, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6q = Functions.belowten' g_at6p
                      (g_at6p, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                      (g_at6n, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                      (g_at6l, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                      (g_at6j, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at6i = Functions.belowten' g_at6h
                      (g_at6h, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                      (g_at6f, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at6e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6d
                      (g_at6d, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at6c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6b
                      (g_at6b, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at6a = code-0.1.0.0:Genome.FixedList.Functions.double g_at69
                      (g_at69, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                      (g_at67, gpart_at79) = Genome.Split.split gpart_at78
                      p_at66 = Functions.belowten' g_at65
                      (g_at65, gpart_at78) = Genome.Split.split gpart_at77
                      p_at64 = code-0.1.0.0:Genome.FixedList.Functions.double g_at63
                      (g_at63, gpart_at77) = Genome.Split.split gpart_at76
                      p_at62 = Functions.belowten' g_at61
                      (g_at61, gpart_at76) = Genome.Split.split gpart_at75
                      p_at60 = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Z
                      (g_at5Z, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5Y = Functions.belowten' g_at5X
                      (g_at5X, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5W = code-0.1.0.0:Genome.FixedList.Functions.double g_at5V
                      (g_at5V, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                      (g_at5T, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5S = Functions.belowten' g_at5R
                      (g_at5R, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                      (g_at5P, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5N
                      (g_at5N, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                      (g_at5L, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                      (g_at5J, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                      (g_at5F, gpart_at6V) = Genome.Split.split gpart_at6U
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6U) = Genome.Split.split gpart_at6T
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6T) = Genome.Split.split genome_at6R
                    in
                      [Reaction
                         (\ x_at7w
                            -> let c_MiRs_at7x = ((toVector x_at7w) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5K
                                  / (1
                                     + (((p_at5C / p_at5M) ** p_at5O)
                                        + ((c_MiRs_at7x / p_at5Q) ** p_at5S)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7y
                            -> let
                                 c_PTB_at7C = ((toVector x_at7y) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at7B = ((toVector x_at7y) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7z = ((toVector x_at7y) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5U
                                  * ((p_at68 + ((c_RESTc_at7z / p_at5W) ** p_at5Y))
                                     / (((1 + p_at68) + ((c_RESTc_at7z / p_at5W) ** p_at5Y))
                                        + (((c_MiRs_at7B / p_at60) ** p_at62)
                                           + ((c_PTB_at7C / p_at64) ** p_at66))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7D
                            -> let c_RESTc_at7E = ((toVector x_at7D) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6a
                                  * (p_at6k
                                     / ((1 + p_at6k) + ((c_RESTc_at7E / p_at6g) ** p_at6i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7F
                            -> let
                                 c_MiRs_at7I = ((toVector x_at7F) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7G = ((toVector x_at7F) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6m
                                  * ((p_at6A + ((c_PTB_at7G / p_at6o) ** p_at6q))
                                     / (((1 + p_at6A) + ((c_PTB_at7G / p_at6o) ** p_at6q))
                                        + ((c_MiRs_at7I / p_at6w) ** p_at6y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7J
                            -> let c_RESTc_at7K = ((toVector x_at7J) Data.Vector.Unboxed.! 3)
                               in (p_at6C / (1 + ((c_RESTc_at7K / p_at6E) ** p_at6G))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7L
                            -> let c_PTB_at7M = ((toVector x_at7L) Data.Vector.Unboxed.! 0)
                               in (p_at6I * c_PTB_at7M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7N
                            -> let c_NPTB_at7O = ((toVector x_at7N) Data.Vector.Unboxed.! 1)
                               in (p_at6K * c_NPTB_at7O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7P
                            -> let c_MiRs_at7Q = ((toVector x_at7P) Data.Vector.Unboxed.! 2)
                               in (p_at6M * c_MiRs_at7Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7R
                            -> let c_RESTc_at7S = ((toVector x_at7R) Data.Vector.Unboxed.! 3)
                               in (p_at6O * c_RESTc_at7S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7T
                            -> let
                                 c_EndoNeuroTFs_at7U = ((toVector x_at7T) Data.Vector.Unboxed.! 4)
                               in (p_at6Q * c_EndoNeuroTFs_at7U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6R
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8x
                            p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                            (g_at6P, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                            (g_at6N, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                            (g_at6J, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6G = Functions.belowten' g_at6F
                            (g_at6F, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                            (g_at6B, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                            (g_at6z, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6y = Functions.belowten' g_at6x
                            (g_at6x, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                            (g_at6v, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at6u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6t
                            (g_at6t, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at6s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6r
                            (g_at6r, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at6q = Functions.belowten' g_at6p
                            (g_at6p, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                            (g_at6n, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                            (g_at6l, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                            (g_at6j, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at6i = Functions.belowten' g_at6h
                            (g_at6h, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                            (g_at6f, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at6e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6d
                            (g_at6d, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at6c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6b
                            (g_at6b, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at6a = code-0.1.0.0:Genome.FixedList.Functions.double g_at69
                            (g_at69, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                            (g_at67, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at66 = Functions.belowten' g_at65
                            (g_at65, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at64 = code-0.1.0.0:Genome.FixedList.Functions.double g_at63
                            (g_at63, gpart_at89) = Genome.Split.split gpart_at88
                            p_at62 = Functions.belowten' g_at61
                            (g_at61, gpart_at88) = Genome.Split.split gpart_at87
                            p_at60 = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Z
                            (g_at5Z, gpart_at87) = Genome.Split.split gpart_at86
                            p_at5Y = Functions.belowten' g_at5X
                            (g_at5X, gpart_at86) = Genome.Split.split gpart_at85
                            p_at5W = code-0.1.0.0:Genome.FixedList.Functions.double g_at5V
                            (g_at5V, gpart_at85) = Genome.Split.split gpart_at84
                            p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                            (g_at5T, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5S = Functions.belowten' g_at5R
                            (g_at5R, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                            (g_at5P, gpart_at82) = Genome.Split.split gpart_at81
                            p_at5O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5N
                            (g_at5N, gpart_at81) = Genome.Split.split gpart_at80
                            p_at5M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                            (g_at5L, gpart_at80) = Genome.Split.split gpart_at7Z
                            p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                            (g_at5J, gpart_at7Z) = Genome.Split.split gpart_at7Y
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at7Y) = Genome.Split.split gpart_at7X
                            p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                            (g_at5F, gpart_at7X) = Genome.Split.split gpart_at7W
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at7W) = Genome.Split.split gpart_at7V
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at7V) = Genome.Split.split genome_at6R
                          in
                            \ desc_at6S
                              -> case desc_at6S of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   _ -> Nothing }}
