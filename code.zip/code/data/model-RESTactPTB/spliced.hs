src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a20XV
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a20Yz
                      p_a20XU = double g_a20XT
                      (g_a20XT, gpart_a20Yz) = Genome.Split.split gpart_a20Yy
                      p_a20XS = double g_a20XR
                      (g_a20XR, gpart_a20Yy) = Genome.Split.split gpart_a20Yx
                      p_a20XQ = double g_a20XP
                      (g_a20XP, gpart_a20Yx) = Genome.Split.split gpart_a20Yw
                      p_a20XO = double g_a20XN
                      (g_a20XN, gpart_a20Yw) = Genome.Split.split gpart_a20Yv
                      p_a20XM = double g_a20XL
                      (g_a20XL, gpart_a20Yv) = Genome.Split.split gpart_a20Yu
                      p_a20XK = Functions.belowten' g_a20XJ
                      (g_a20XJ, gpart_a20Yu) = Genome.Split.split gpart_a20Yt
                      p_a20XI = double g_a20XH
                      (g_a20XH, gpart_a20Yt) = Genome.Split.split gpart_a20Ys
                      p_a20XG = double g_a20XF
                      (g_a20XF, gpart_a20Ys) = Genome.Split.split gpart_a20Yr
                      p_a20XE = double g_a20XD
                      (g_a20XD, gpart_a20Yr) = Genome.Split.split gpart_a20Yq
                      p_a20XC = Functions.belowten' g_a20XB
                      (g_a20XB, gpart_a20Yq) = Genome.Split.split gpart_a20Yp
                      p_a20XA = double g_a20Xz
                      (g_a20Xz, gpart_a20Yp) = Genome.Split.split gpart_a20Yo
                      p_a20Xy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xx
                      (g_a20Xx, gpart_a20Yo) = Genome.Split.split gpart_a20Yn
                      p_a20Xw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xv
                      (g_a20Xv, gpart_a20Yn) = Genome.Split.split gpart_a20Ym
                      p_a20Xu = Functions.belowten' g_a20Xt
                      (g_a20Xt, gpart_a20Ym) = Genome.Split.split gpart_a20Yl
                      p_a20Xs = double g_a20Xr
                      (g_a20Xr, gpart_a20Yl) = Genome.Split.split gpart_a20Yk
                      p_a20Xq = double g_a20Xp
                      (g_a20Xp, gpart_a20Yk) = Genome.Split.split gpart_a20Yj
                      p_a20Xo = double g_a20Xn
                      (g_a20Xn, gpart_a20Yj) = Genome.Split.split gpart_a20Yi
                      p_a20Xm = Functions.belowten' g_a20Xl
                      (g_a20Xl, gpart_a20Yi) = Genome.Split.split gpart_a20Yh
                      p_a20Xk = double g_a20Xj
                      (g_a20Xj, gpart_a20Yh) = Genome.Split.split gpart_a20Yg
                      p_a20Xi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xh
                      (g_a20Xh, gpart_a20Yg) = Genome.Split.split gpart_a20Yf
                      p_a20Xg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xf
                      (g_a20Xf, gpart_a20Yf) = Genome.Split.split gpart_a20Ye
                      p_a20Xe = double g_a20Xd
                      (g_a20Xd, gpart_a20Ye) = Genome.Split.split gpart_a20Yd
                      p_a20Xc = Functions.belowten' g_a20Xb
                      (g_a20Xb, gpart_a20Yd) = Genome.Split.split gpart_a20Yc
                      p_a20Xa = double g_a20X9
                      (g_a20X9, gpart_a20Yc) = Genome.Split.split gpart_a20Yb
                      p_a20X8 = Functions.belowten' g_a20X7
                      (g_a20X7, gpart_a20Yb) = Genome.Split.split gpart_a20Ya
                      p_a20X6 = double g_a20X5
                      (g_a20X5, gpart_a20Ya) = Genome.Split.split gpart_a20Y9
                      p_a20X4 = double g_a20X3
                      (g_a20X3, gpart_a20Y9) = Genome.Split.split gpart_a20Y8
                      p_a20X2 = double g_a20X1
                      (g_a20X1, gpart_a20Y8) = Genome.Split.split gpart_a20Y7
                      p_a20X0 = Functions.belowten' g_a20WZ
                      (g_a20WZ, gpart_a20Y7) = Genome.Split.split gpart_a20Y6
                      p_a20WY = double g_a20WX
                      (g_a20WX, gpart_a20Y6) = Genome.Split.split gpart_a20Y5
                      p_a20WW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20WV
                      (g_a20WV, gpart_a20Y5) = Genome.Split.split gpart_a20Y4
                      p_a20WU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20WT
                      (g_a20WT, gpart_a20Y4) = Genome.Split.split gpart_a20Y3
                      p_a20WS = Functions.belowten' g_a20WR
                      (g_a20WR, gpart_a20Y3) = Genome.Split.split gpart_a20Y2
                      p_a20WQ = double g_a20WP
                      (g_a20WP, gpart_a20Y2) = Genome.Split.split gpart_a20Y1
                      p_a20WO = double g_a20WN
                      (g_a20WN, gpart_a20Y1) = Genome.Split.split gpart_a20Y0
                      p_a20WM = double g_a20WL
                      (g_a20WL, gpart_a20Y0) = Genome.Split.split gpart_a20XZ
                      p_a20WK = double g_a20WJ
                      (g_a20WJ, gpart_a20XZ) = Genome.Split.split gpart_a20XY
                      p_a20WI = double g_a20WH
                      (g_a20WH, gpart_a20XY) = Genome.Split.split gpart_a20XX
                      p_a20WG = double g_a20WF
                      (g_a20WF, gpart_a20XX) = Genome.Split.split genome_a20XV
                    in  \ x_a20YA
                          -> let
                               c_PTB_a20YF
                                 = ((Data.Fixed.Vector.toVector x_a20YA) Data.Vector.Unboxed.! 0)
                               c_MiRs_a20YD
                                 = ((Data.Fixed.Vector.toVector x_a20YA) Data.Vector.Unboxed.! 2)
                               c_RESTc_a20YB
                                 = ((Data.Fixed.Vector.toVector x_a20YA) Data.Vector.Unboxed.! 3)
                               c_NPTB_a20YJ
                                 = ((Data.Fixed.Vector.toVector x_a20YA) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a20YU
                                 = ((Data.Fixed.Vector.toVector x_a20YA) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a20WO
                                     * ((p_a20X2 + ((c_RESTc_a20YB / p_a20WQ) ** p_a20WS))
                                        / (((1 + p_a20X2) + ((c_RESTc_a20YB / p_a20WQ) ** p_a20WS))
                                           + ((c_MiRs_a20YD / p_a20WY) ** p_a20X0))))
                                    + (negate (p_a20XM * c_PTB_a20YF))),
                                   ((p_a20X4
                                     / (1
                                        + (((c_MiRs_a20YD / p_a20X6) ** p_a20X8)
                                           + ((c_PTB_a20YF / p_a20Xa) ** p_a20Xc))))
                                    + (negate (p_a20XO * c_NPTB_a20YJ))),
                                   ((p_a20Xe
                                     * ((p_a20Xo + ((p_a20WK / p_a20Xg) ** p_a20Xi))
                                        / (((1 + p_a20Xo) + ((p_a20WK / p_a20Xg) ** p_a20Xi))
                                           + ((c_RESTc_a20YB / p_a20Xk) ** p_a20Xm))))
                                    + (negate (p_a20XQ * c_MiRs_a20YD))),
                                   ((p_a20Xq
                                     * ((p_a20XE + ((c_PTB_a20YF / p_a20Xs) ** p_a20Xu))
                                        / (((1 + p_a20XE) + ((c_PTB_a20YF / p_a20Xs) ** p_a20Xu))
                                           + (((p_a20WG / p_a20Xw) ** p_a20Xy)
                                              + ((c_MiRs_a20YD / p_a20XA) ** p_a20XC)))))
                                    + (negate (p_a20XS * c_RESTc_a20YB))),
                                   ((p_a20XG / (1 + ((c_RESTc_a20YB / p_a20XI) ** p_a20XK)))
                                    + (negate (p_a20XU * c_EndoNeuroTFs_a20YU)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490086",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490088",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490090",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490100",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490102",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490108",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490122",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490124",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490138",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490140",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a20XV
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a20Zx
                            p_a20XU = double g_a20XT
                            (g_a20XT, gpart_a20Zx) = Genome.Split.split gpart_a20Zw
                            p_a20XS = double g_a20XR
                            (g_a20XR, gpart_a20Zw) = Genome.Split.split gpart_a20Zv
                            p_a20XQ = double g_a20XP
                            (g_a20XP, gpart_a20Zv) = Genome.Split.split gpart_a20Zu
                            p_a20XO = double g_a20XN
                            (g_a20XN, gpart_a20Zu) = Genome.Split.split gpart_a20Zt
                            p_a20XM = double g_a20XL
                            (g_a20XL, gpart_a20Zt) = Genome.Split.split gpart_a20Zs
                            p_a20XK = Functions.belowten' g_a20XJ
                            (g_a20XJ, gpart_a20Zs) = Genome.Split.split gpart_a20Zr
                            p_a20XI = double g_a20XH
                            (g_a20XH, gpart_a20Zr) = Genome.Split.split gpart_a20Zq
                            p_a20XG = double g_a20XF
                            (g_a20XF, gpart_a20Zq) = Genome.Split.split gpart_a20Zp
                            p_a20XE = double g_a20XD
                            (g_a20XD, gpart_a20Zp) = Genome.Split.split gpart_a20Zo
                            p_a20XC = Functions.belowten' g_a20XB
                            (g_a20XB, gpart_a20Zo) = Genome.Split.split gpart_a20Zn
                            p_a20XA = double g_a20Xz
                            (g_a20Xz, gpart_a20Zn) = Genome.Split.split gpart_a20Zm
                            p_a20Xy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xx
                            (g_a20Xx, gpart_a20Zm) = Genome.Split.split gpart_a20Zl
                            p_a20Xw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xv
                            (g_a20Xv, gpart_a20Zl) = Genome.Split.split gpart_a20Zk
                            p_a20Xu = Functions.belowten' g_a20Xt
                            (g_a20Xt, gpart_a20Zk) = Genome.Split.split gpart_a20Zj
                            p_a20Xs = double g_a20Xr
                            (g_a20Xr, gpart_a20Zj) = Genome.Split.split gpart_a20Zi
                            p_a20Xq = double g_a20Xp
                            (g_a20Xp, gpart_a20Zi) = Genome.Split.split gpart_a20Zh
                            p_a20Xo = double g_a20Xn
                            (g_a20Xn, gpart_a20Zh) = Genome.Split.split gpart_a20Zg
                            p_a20Xm = Functions.belowten' g_a20Xl
                            (g_a20Xl, gpart_a20Zg) = Genome.Split.split gpart_a20Zf
                            p_a20Xk = double g_a20Xj
                            (g_a20Xj, gpart_a20Zf) = Genome.Split.split gpart_a20Ze
                            p_a20Xi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xh
                            (g_a20Xh, gpart_a20Ze) = Genome.Split.split gpart_a20Zd
                            p_a20Xg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20Xf
                            (g_a20Xf, gpart_a20Zd) = Genome.Split.split gpart_a20Zc
                            p_a20Xe = double g_a20Xd
                            (g_a20Xd, gpart_a20Zc) = Genome.Split.split gpart_a20Zb
                            p_a20Xc = Functions.belowten' g_a20Xb
                            (g_a20Xb, gpart_a20Zb) = Genome.Split.split gpart_a20Za
                            p_a20Xa = double g_a20X9
                            (g_a20X9, gpart_a20Za) = Genome.Split.split gpart_a20Z9
                            p_a20X8 = Functions.belowten' g_a20X7
                            (g_a20X7, gpart_a20Z9) = Genome.Split.split gpart_a20Z8
                            p_a20X6 = double g_a20X5
                            (g_a20X5, gpart_a20Z8) = Genome.Split.split gpart_a20Z7
                            p_a20X4 = double g_a20X3
                            (g_a20X3, gpart_a20Z7) = Genome.Split.split gpart_a20Z6
                            p_a20X2 = double g_a20X1
                            (g_a20X1, gpart_a20Z6) = Genome.Split.split gpart_a20Z5
                            p_a20X0 = Functions.belowten' g_a20WZ
                            (g_a20WZ, gpart_a20Z5) = Genome.Split.split gpart_a20Z4
                            p_a20WY = double g_a20WX
                            (g_a20WX, gpart_a20Z4) = Genome.Split.split gpart_a20Z3
                            p_a20WW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20WV
                            (g_a20WV, gpart_a20Z3) = Genome.Split.split gpart_a20Z2
                            p_a20WU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20WT
                            (g_a20WT, gpart_a20Z2) = Genome.Split.split gpart_a20Z1
                            p_a20WS = Functions.belowten' g_a20WR
                            (g_a20WR, gpart_a20Z1) = Genome.Split.split gpart_a20Z0
                            p_a20WQ = double g_a20WP
                            (g_a20WP, gpart_a20Z0) = Genome.Split.split gpart_a20YZ
                            p_a20WO = double g_a20WN
                            (g_a20WN, gpart_a20YZ) = Genome.Split.split gpart_a20YY
                            p_a20WM = double g_a20WL
                            (g_a20WL, gpart_a20YY) = Genome.Split.split gpart_a20YX
                            p_a20WK = double g_a20WJ
                            (g_a20WJ, gpart_a20YX) = Genome.Split.split gpart_a20YW
                            p_a20WI = double g_a20WH
                            (g_a20WH, gpart_a20YW) = Genome.Split.split gpart_a20YV
                            p_a20WG = double g_a20WF
                            (g_a20WF, gpart_a20YV) = Genome.Split.split genome_a20XV
                          in
                            \ desc_a20XW
                              -> case desc_a20XW of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WG)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WI)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WK)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WM)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WO)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WQ)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WS)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WU)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WW)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20WY)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20X0)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20X2)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20X4)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20X6)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20X8)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xa)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xc)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xe)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xg)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xi)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xk)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xm)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xo)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xq)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xs)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xu)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xw)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Xy)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XA)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XC)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XE)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XG)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XI)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XK)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XM)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XO)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XQ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XS)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20XU)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a211X
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a212B
                      p_a211W = double g_a211V
                      (g_a211V, gpart_a212B) = Genome.Split.split gpart_a212A
                      p_a211U = double g_a211T
                      (g_a211T, gpart_a212A) = Genome.Split.split gpart_a212z
                      p_a211S = double g_a211R
                      (g_a211R, gpart_a212z) = Genome.Split.split gpart_a212y
                      p_a211Q = double g_a211P
                      (g_a211P, gpart_a212y) = Genome.Split.split gpart_a212x
                      p_a211O = double g_a211N
                      (g_a211N, gpart_a212x) = Genome.Split.split gpart_a212w
                      p_a211M = Functions.belowten' g_a211L
                      (g_a211L, gpart_a212w) = Genome.Split.split gpart_a212v
                      p_a211K = double g_a211J
                      (g_a211J, gpart_a212v) = Genome.Split.split gpart_a212u
                      p_a211I = double g_a211H
                      (g_a211H, gpart_a212u) = Genome.Split.split gpart_a212t
                      p_a211G = double g_a211F
                      (g_a211F, gpart_a212t) = Genome.Split.split gpart_a212s
                      p_a211E = Functions.belowten' g_a211D
                      (g_a211D, gpart_a212s) = Genome.Split.split gpart_a212r
                      p_a211C = double g_a211B
                      (g_a211B, gpart_a212r) = Genome.Split.split gpart_a212q
                      p_a211A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211z
                      (g_a211z, gpart_a212q) = Genome.Split.split gpart_a212p
                      p_a211y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211x
                      (g_a211x, gpart_a212p) = Genome.Split.split gpart_a212o
                      p_a211w = Functions.belowten' g_a211v
                      (g_a211v, gpart_a212o) = Genome.Split.split gpart_a212n
                      p_a211u = double g_a211t
                      (g_a211t, gpart_a212n) = Genome.Split.split gpart_a212m
                      p_a211s = double g_a211r
                      (g_a211r, gpart_a212m) = Genome.Split.split gpart_a212l
                      p_a211q = double g_a211p
                      (g_a211p, gpart_a212l) = Genome.Split.split gpart_a212k
                      p_a211o = Functions.belowten' g_a211n
                      (g_a211n, gpart_a212k) = Genome.Split.split gpart_a212j
                      p_a211m = double g_a211l
                      (g_a211l, gpart_a212j) = Genome.Split.split gpart_a212i
                      p_a211k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211j
                      (g_a211j, gpart_a212i) = Genome.Split.split gpart_a212h
                      p_a211i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211h
                      (g_a211h, gpart_a212h) = Genome.Split.split gpart_a212g
                      p_a211g = double g_a211f
                      (g_a211f, gpart_a212g) = Genome.Split.split gpart_a212f
                      p_a211e = Functions.belowten' g_a211d
                      (g_a211d, gpart_a212f) = Genome.Split.split gpart_a212e
                      p_a211c = double g_a211b
                      (g_a211b, gpart_a212e) = Genome.Split.split gpart_a212d
                      p_a211a = Functions.belowten' g_a2119
                      (g_a2119, gpart_a212d) = Genome.Split.split gpart_a212c
                      p_a2118 = double g_a2117
                      (g_a2117, gpart_a212c) = Genome.Split.split gpart_a212b
                      p_a2116 = double g_a2115
                      (g_a2115, gpart_a212b) = Genome.Split.split gpart_a212a
                      p_a2114 = double g_a2113
                      (g_a2113, gpart_a212a) = Genome.Split.split gpart_a2129
                      p_a2112 = Functions.belowten' g_a2111
                      (g_a2111, gpart_a2129) = Genome.Split.split gpart_a2128
                      p_a2110 = double g_a210Z
                      (g_a210Z, gpart_a2128) = Genome.Split.split gpart_a2127
                      p_a210Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210X
                      (g_a210X, gpart_a2127) = Genome.Split.split gpart_a2126
                      p_a210W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210V
                      (g_a210V, gpart_a2126) = Genome.Split.split gpart_a2125
                      p_a210U = Functions.belowten' g_a210T
                      (g_a210T, gpart_a2125) = Genome.Split.split gpart_a2124
                      p_a210S = double g_a210R
                      (g_a210R, gpart_a2124) = Genome.Split.split gpart_a2123
                      p_a210Q = double g_a210P
                      (g_a210P, gpart_a2123) = Genome.Split.split gpart_a2122
                      p_a210O = double g_a210N
                      (g_a210N, gpart_a2122) = Genome.Split.split gpart_a2121
                      p_a210M = double g_a210L
                      (g_a210L, gpart_a2121) = Genome.Split.split gpart_a2120
                      p_a210K = double g_a210J
                      (g_a210J, gpart_a2120) = Genome.Split.split gpart_a211Z
                      p_a210I = double g_a210H
                      (g_a210H, gpart_a211Z) = Genome.Split.split genome_a211X
                    in  \ x_a212C
                          -> let
                               c_PTB_a212H
                                 = ((Data.Fixed.Vector.toVector x_a212C) Data.Vector.Unboxed.! 0)
                               c_MiRs_a212F
                                 = ((Data.Fixed.Vector.toVector x_a212C) Data.Vector.Unboxed.! 2)
                               c_RESTc_a212D
                                 = ((Data.Fixed.Vector.toVector x_a212C) Data.Vector.Unboxed.! 3)
                               c_NPTB_a212L
                                 = ((Data.Fixed.Vector.toVector x_a212C) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a212W
                                 = ((Data.Fixed.Vector.toVector x_a212C) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a210Q
                                     * ((p_a2114 + ((c_RESTc_a212D / p_a210S) ** p_a210U))
                                        / (((1 + p_a2114) + ((c_RESTc_a212D / p_a210S) ** p_a210U))
                                           + ((c_MiRs_a212F / p_a2110) ** p_a2112))))
                                    + (negate (p_a211O * c_PTB_a212H))),
                                   ((p_a2116
                                     / (1
                                        + (((c_MiRs_a212F / p_a2118) ** p_a211a)
                                           + ((c_PTB_a212H / p_a211c) ** p_a211e))))
                                    + (negate (p_a211Q * c_NPTB_a212L))),
                                   ((p_a211g
                                     * (p_a211q
                                        / ((1 + p_a211q) + ((c_RESTc_a212D / p_a211m) ** p_a211o))))
                                    + (negate (p_a211S * c_MiRs_a212F))),
                                   ((p_a211s
                                     * ((p_a211G + ((c_PTB_a212H / p_a211u) ** p_a211w))
                                        / (((1 + p_a211G) + ((c_PTB_a212H / p_a211u) ** p_a211w))
                                           + (((p_a210I / p_a211y) ** p_a211A)
                                              + ((c_MiRs_a212F / p_a211C) ** p_a211E)))))
                                    + (negate (p_a211U * c_RESTc_a212D))),
                                   ((p_a211I / (1 + ((c_RESTc_a212D / p_a211K) ** p_a211M)))
                                    + (negate (p_a211W * c_EndoNeuroTFs_a212W)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490350",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490352",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490372",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490374",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490388",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490390",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a211X
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a213z
                            p_a211W = double g_a211V
                            (g_a211V, gpart_a213z) = Genome.Split.split gpart_a213y
                            p_a211U = double g_a211T
                            (g_a211T, gpart_a213y) = Genome.Split.split gpart_a213x
                            p_a211S = double g_a211R
                            (g_a211R, gpart_a213x) = Genome.Split.split gpart_a213w
                            p_a211Q = double g_a211P
                            (g_a211P, gpart_a213w) = Genome.Split.split gpart_a213v
                            p_a211O = double g_a211N
                            (g_a211N, gpart_a213v) = Genome.Split.split gpart_a213u
                            p_a211M = Functions.belowten' g_a211L
                            (g_a211L, gpart_a213u) = Genome.Split.split gpart_a213t
                            p_a211K = double g_a211J
                            (g_a211J, gpart_a213t) = Genome.Split.split gpart_a213s
                            p_a211I = double g_a211H
                            (g_a211H, gpart_a213s) = Genome.Split.split gpart_a213r
                            p_a211G = double g_a211F
                            (g_a211F, gpart_a213r) = Genome.Split.split gpart_a213q
                            p_a211E = Functions.belowten' g_a211D
                            (g_a211D, gpart_a213q) = Genome.Split.split gpart_a213p
                            p_a211C = double g_a211B
                            (g_a211B, gpart_a213p) = Genome.Split.split gpart_a213o
                            p_a211A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211z
                            (g_a211z, gpart_a213o) = Genome.Split.split gpart_a213n
                            p_a211y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211x
                            (g_a211x, gpart_a213n) = Genome.Split.split gpart_a213m
                            p_a211w = Functions.belowten' g_a211v
                            (g_a211v, gpart_a213m) = Genome.Split.split gpart_a213l
                            p_a211u = double g_a211t
                            (g_a211t, gpart_a213l) = Genome.Split.split gpart_a213k
                            p_a211s = double g_a211r
                            (g_a211r, gpart_a213k) = Genome.Split.split gpart_a213j
                            p_a211q = double g_a211p
                            (g_a211p, gpart_a213j) = Genome.Split.split gpart_a213i
                            p_a211o = Functions.belowten' g_a211n
                            (g_a211n, gpart_a213i) = Genome.Split.split gpart_a213h
                            p_a211m = double g_a211l
                            (g_a211l, gpart_a213h) = Genome.Split.split gpart_a213g
                            p_a211k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211j
                            (g_a211j, gpart_a213g) = Genome.Split.split gpart_a213f
                            p_a211i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a211h
                            (g_a211h, gpart_a213f) = Genome.Split.split gpart_a213e
                            p_a211g = double g_a211f
                            (g_a211f, gpart_a213e) = Genome.Split.split gpart_a213d
                            p_a211e = Functions.belowten' g_a211d
                            (g_a211d, gpart_a213d) = Genome.Split.split gpart_a213c
                            p_a211c = double g_a211b
                            (g_a211b, gpart_a213c) = Genome.Split.split gpart_a213b
                            p_a211a = Functions.belowten' g_a2119
                            (g_a2119, gpart_a213b) = Genome.Split.split gpart_a213a
                            p_a2118 = double g_a2117
                            (g_a2117, gpart_a213a) = Genome.Split.split gpart_a2139
                            p_a2116 = double g_a2115
                            (g_a2115, gpart_a2139) = Genome.Split.split gpart_a2138
                            p_a2114 = double g_a2113
                            (g_a2113, gpart_a2138) = Genome.Split.split gpart_a2137
                            p_a2112 = Functions.belowten' g_a2111
                            (g_a2111, gpart_a2137) = Genome.Split.split gpart_a2136
                            p_a2110 = double g_a210Z
                            (g_a210Z, gpart_a2136) = Genome.Split.split gpart_a2135
                            p_a210Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210X
                            (g_a210X, gpart_a2135) = Genome.Split.split gpart_a2134
                            p_a210W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210V
                            (g_a210V, gpart_a2134) = Genome.Split.split gpart_a2133
                            p_a210U = Functions.belowten' g_a210T
                            (g_a210T, gpart_a2133) = Genome.Split.split gpart_a2132
                            p_a210S = double g_a210R
                            (g_a210R, gpart_a2132) = Genome.Split.split gpart_a2131
                            p_a210Q = double g_a210P
                            (g_a210P, gpart_a2131) = Genome.Split.split gpart_a2130
                            p_a210O = double g_a210N
                            (g_a210N, gpart_a2130) = Genome.Split.split gpart_a212Z
                            p_a210M = double g_a210L
                            (g_a210L, gpart_a212Z) = Genome.Split.split gpart_a212Y
                            p_a210K = double g_a210J
                            (g_a210J, gpart_a212Y) = Genome.Split.split gpart_a212X
                            p_a210I = double g_a210H
                            (g_a210H, gpart_a212X) = Genome.Split.split genome_a211X
                          in
                            \ desc_a211Y
                              -> case desc_a211Y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210I)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210K)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210M)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210O)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210Q)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210S)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210U)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210W)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210Y)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2110)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2112)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2114)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2116)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2118)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211a)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211c)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211e)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211g)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211i)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211k)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211m)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211o)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211s)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211u)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211w)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211y)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211A)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211C)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211E)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211G)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211I)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211K)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211M)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211O)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211Q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211S)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211U)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a211W)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a215Z
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a216D
                      p_a215Y = double g_a215X
                      (g_a215X, gpart_a216D) = Genome.Split.split gpart_a216C
                      p_a215W = double g_a215V
                      (g_a215V, gpart_a216C) = Genome.Split.split gpart_a216B
                      p_a215U = double g_a215T
                      (g_a215T, gpart_a216B) = Genome.Split.split gpart_a216A
                      p_a215S = double g_a215R
                      (g_a215R, gpart_a216A) = Genome.Split.split gpart_a216z
                      p_a215Q = double g_a215P
                      (g_a215P, gpart_a216z) = Genome.Split.split gpart_a216y
                      p_a215O = Functions.belowten' g_a215N
                      (g_a215N, gpart_a216y) = Genome.Split.split gpart_a216x
                      p_a215M = double g_a215L
                      (g_a215L, gpart_a216x) = Genome.Split.split gpart_a216w
                      p_a215K = double g_a215J
                      (g_a215J, gpart_a216w) = Genome.Split.split gpart_a216v
                      p_a215I = double g_a215H
                      (g_a215H, gpart_a216v) = Genome.Split.split gpart_a216u
                      p_a215G = Functions.belowten' g_a215F
                      (g_a215F, gpart_a216u) = Genome.Split.split gpart_a216t
                      p_a215E = double g_a215D
                      (g_a215D, gpart_a216t) = Genome.Split.split gpart_a216s
                      p_a215C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215B
                      (g_a215B, gpart_a216s) = Genome.Split.split gpart_a216r
                      p_a215A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215z
                      (g_a215z, gpart_a216r) = Genome.Split.split gpart_a216q
                      p_a215y = Functions.belowten' g_a215x
                      (g_a215x, gpart_a216q) = Genome.Split.split gpart_a216p
                      p_a215w = double g_a215v
                      (g_a215v, gpart_a216p) = Genome.Split.split gpart_a216o
                      p_a215u = double g_a215t
                      (g_a215t, gpart_a216o) = Genome.Split.split gpart_a216n
                      p_a215s = double g_a215r
                      (g_a215r, gpart_a216n) = Genome.Split.split gpart_a216m
                      p_a215q = Functions.belowten' g_a215p
                      (g_a215p, gpart_a216m) = Genome.Split.split gpart_a216l
                      p_a215o = double g_a215n
                      (g_a215n, gpart_a216l) = Genome.Split.split gpart_a216k
                      p_a215m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215l
                      (g_a215l, gpart_a216k) = Genome.Split.split gpart_a216j
                      p_a215k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215j
                      (g_a215j, gpart_a216j) = Genome.Split.split gpart_a216i
                      p_a215i = double g_a215h
                      (g_a215h, gpart_a216i) = Genome.Split.split gpart_a216h
                      p_a215g = Functions.belowten' g_a215f
                      (g_a215f, gpart_a216h) = Genome.Split.split gpart_a216g
                      p_a215e = double g_a215d
                      (g_a215d, gpart_a216g) = Genome.Split.split gpart_a216f
                      p_a215c = Functions.belowten' g_a215b
                      (g_a215b, gpart_a216f) = Genome.Split.split gpart_a216e
                      p_a215a = double g_a2159
                      (g_a2159, gpart_a216e) = Genome.Split.split gpart_a216d
                      p_a2158 = double g_a2157
                      (g_a2157, gpart_a216d) = Genome.Split.split gpart_a216c
                      p_a2156 = double g_a2155
                      (g_a2155, gpart_a216c) = Genome.Split.split gpart_a216b
                      p_a2154 = Functions.belowten' g_a2153
                      (g_a2153, gpart_a216b) = Genome.Split.split gpart_a216a
                      p_a2152 = double g_a2151
                      (g_a2151, gpart_a216a) = Genome.Split.split gpart_a2169
                      p_a2150
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214Z
                      (g_a214Z, gpart_a2169) = Genome.Split.split gpart_a2168
                      p_a214Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214X
                      (g_a214X, gpart_a2168) = Genome.Split.split gpart_a2167
                      p_a214W = Functions.belowten' g_a214V
                      (g_a214V, gpart_a2167) = Genome.Split.split gpart_a2166
                      p_a214U = double g_a214T
                      (g_a214T, gpart_a2166) = Genome.Split.split gpart_a2165
                      p_a214S = double g_a214R
                      (g_a214R, gpart_a2165) = Genome.Split.split gpart_a2164
                      p_a214Q = double g_a214P
                      (g_a214P, gpart_a2164) = Genome.Split.split gpart_a2163
                      p_a214O = double g_a214N
                      (g_a214N, gpart_a2163) = Genome.Split.split gpart_a2162
                      p_a214M = double g_a214L
                      (g_a214L, gpart_a2162) = Genome.Split.split gpart_a2161
                      p_a214K = double g_a214J
                      (g_a214J, gpart_a2161) = Genome.Split.split genome_a215Z
                    in  \ x_a216E
                          -> let
                               c_PTB_a216J
                                 = ((Data.Fixed.Vector.toVector x_a216E) Data.Vector.Unboxed.! 0)
                               c_MiRs_a216H
                                 = ((Data.Fixed.Vector.toVector x_a216E) Data.Vector.Unboxed.! 2)
                               c_RESTc_a216F
                                 = ((Data.Fixed.Vector.toVector x_a216E) Data.Vector.Unboxed.! 3)
                               c_NPTB_a216N
                                 = ((Data.Fixed.Vector.toVector x_a216E) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a216Y
                                 = ((Data.Fixed.Vector.toVector x_a216E) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a214S
                                     * ((p_a2156 + ((c_RESTc_a216F / p_a214U) ** p_a214W))
                                        / (((1 + p_a2156) + ((c_RESTc_a216F / p_a214U) ** p_a214W))
                                           + ((c_MiRs_a216H / p_a2152) ** p_a2154))))
                                    + (negate (p_a215Q * c_PTB_a216J))),
                                   ((p_a2158
                                     / (1
                                        + (((c_MiRs_a216H / p_a215a) ** p_a215c)
                                           + ((c_PTB_a216J / p_a215e) ** p_a215g))))
                                    + (negate (p_a215S * c_NPTB_a216N))),
                                   ((p_a215i
                                     * (p_a215s
                                        / ((1 + p_a215s) + ((c_RESTc_a216F / p_a215o) ** p_a215q))))
                                    + (negate (p_a215U * c_MiRs_a216H))),
                                   ((p_a215u
                                     * ((p_a215I + ((c_PTB_a216J / p_a215w) ** p_a215y))
                                        / (((1 + p_a215I) + ((c_PTB_a216J / p_a215w) ** p_a215y))
                                           + ((c_MiRs_a216H / p_a215E) ** p_a215G))))
                                    + (negate (p_a215W * c_RESTc_a216F))),
                                   ((p_a215K / (1 + ((c_RESTc_a216F / p_a215M) ** p_a215O)))
                                    + (negate (p_a215Y * c_EndoNeuroTFs_a216Y)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490598",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490600",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490602",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490622",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490624",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490638",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490640",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a215Z
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a217B
                            p_a215Y = double g_a215X
                            (g_a215X, gpart_a217B) = Genome.Split.split gpart_a217A
                            p_a215W = double g_a215V
                            (g_a215V, gpart_a217A) = Genome.Split.split gpart_a217z
                            p_a215U = double g_a215T
                            (g_a215T, gpart_a217z) = Genome.Split.split gpart_a217y
                            p_a215S = double g_a215R
                            (g_a215R, gpart_a217y) = Genome.Split.split gpart_a217x
                            p_a215Q = double g_a215P
                            (g_a215P, gpart_a217x) = Genome.Split.split gpart_a217w
                            p_a215O = Functions.belowten' g_a215N
                            (g_a215N, gpart_a217w) = Genome.Split.split gpart_a217v
                            p_a215M = double g_a215L
                            (g_a215L, gpart_a217v) = Genome.Split.split gpart_a217u
                            p_a215K = double g_a215J
                            (g_a215J, gpart_a217u) = Genome.Split.split gpart_a217t
                            p_a215I = double g_a215H
                            (g_a215H, gpart_a217t) = Genome.Split.split gpart_a217s
                            p_a215G = Functions.belowten' g_a215F
                            (g_a215F, gpart_a217s) = Genome.Split.split gpart_a217r
                            p_a215E = double g_a215D
                            (g_a215D, gpart_a217r) = Genome.Split.split gpart_a217q
                            p_a215C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215B
                            (g_a215B, gpart_a217q) = Genome.Split.split gpart_a217p
                            p_a215A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215z
                            (g_a215z, gpart_a217p) = Genome.Split.split gpart_a217o
                            p_a215y = Functions.belowten' g_a215x
                            (g_a215x, gpart_a217o) = Genome.Split.split gpart_a217n
                            p_a215w = double g_a215v
                            (g_a215v, gpart_a217n) = Genome.Split.split gpart_a217m
                            p_a215u = double g_a215t
                            (g_a215t, gpart_a217m) = Genome.Split.split gpart_a217l
                            p_a215s = double g_a215r
                            (g_a215r, gpart_a217l) = Genome.Split.split gpart_a217k
                            p_a215q = Functions.belowten' g_a215p
                            (g_a215p, gpart_a217k) = Genome.Split.split gpart_a217j
                            p_a215o = double g_a215n
                            (g_a215n, gpart_a217j) = Genome.Split.split gpart_a217i
                            p_a215m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215l
                            (g_a215l, gpart_a217i) = Genome.Split.split gpart_a217h
                            p_a215k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a215j
                            (g_a215j, gpart_a217h) = Genome.Split.split gpart_a217g
                            p_a215i = double g_a215h
                            (g_a215h, gpart_a217g) = Genome.Split.split gpart_a217f
                            p_a215g = Functions.belowten' g_a215f
                            (g_a215f, gpart_a217f) = Genome.Split.split gpart_a217e
                            p_a215e = double g_a215d
                            (g_a215d, gpart_a217e) = Genome.Split.split gpart_a217d
                            p_a215c = Functions.belowten' g_a215b
                            (g_a215b, gpart_a217d) = Genome.Split.split gpart_a217c
                            p_a215a = double g_a2159
                            (g_a2159, gpart_a217c) = Genome.Split.split gpart_a217b
                            p_a2158 = double g_a2157
                            (g_a2157, gpart_a217b) = Genome.Split.split gpart_a217a
                            p_a2156 = double g_a2155
                            (g_a2155, gpart_a217a) = Genome.Split.split gpart_a2179
                            p_a2154 = Functions.belowten' g_a2153
                            (g_a2153, gpart_a2179) = Genome.Split.split gpart_a2178
                            p_a2152 = double g_a2151
                            (g_a2151, gpart_a2178) = Genome.Split.split gpart_a2177
                            p_a2150
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214Z
                            (g_a214Z, gpart_a2177) = Genome.Split.split gpart_a2176
                            p_a214Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214X
                            (g_a214X, gpart_a2176) = Genome.Split.split gpart_a2175
                            p_a214W = Functions.belowten' g_a214V
                            (g_a214V, gpart_a2175) = Genome.Split.split gpart_a2174
                            p_a214U = double g_a214T
                            (g_a214T, gpart_a2174) = Genome.Split.split gpart_a2173
                            p_a214S = double g_a214R
                            (g_a214R, gpart_a2173) = Genome.Split.split gpart_a2172
                            p_a214Q = double g_a214P
                            (g_a214P, gpart_a2172) = Genome.Split.split gpart_a2171
                            p_a214O = double g_a214N
                            (g_a214N, gpart_a2171) = Genome.Split.split gpart_a2170
                            p_a214M = double g_a214L
                            (g_a214L, gpart_a2170) = Genome.Split.split gpart_a216Z
                            p_a214K = double g_a214J
                            (g_a214J, gpart_a216Z) = Genome.Split.split genome_a215Z
                          in
                            \ desc_a2160
                              -> case desc_a2160 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214K)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214M)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214O)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214Q)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214S)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214U)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214W)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214Y)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2150)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2152)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2154)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2156)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2158)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215a)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215c)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215e)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215g)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215i)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215k)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215m)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215o)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215q)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215s)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215u)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215w)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215y)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215A)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215C)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215E)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215G)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215I)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215K)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215M)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215O)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215Q)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215S)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215U)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215W)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a215Y)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a21a1
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21aF
                      p_a21a0 = double g_a219Z
                      (g_a219Z, gpart_a21aF) = Genome.Split.split gpart_a21aE
                      p_a219Y = double g_a219X
                      (g_a219X, gpart_a21aE) = Genome.Split.split gpart_a21aD
                      p_a219W = double g_a219V
                      (g_a219V, gpart_a21aD) = Genome.Split.split gpart_a21aC
                      p_a219U = double g_a219T
                      (g_a219T, gpart_a21aC) = Genome.Split.split gpart_a21aB
                      p_a219S = double g_a219R
                      (g_a219R, gpart_a21aB) = Genome.Split.split gpart_a21aA
                      p_a219Q = Functions.belowten' g_a219P
                      (g_a219P, gpart_a21aA) = Genome.Split.split gpart_a21az
                      p_a219O = double g_a219N
                      (g_a219N, gpart_a21az) = Genome.Split.split gpart_a21ay
                      p_a219M = double g_a219L
                      (g_a219L, gpart_a21ay) = Genome.Split.split gpart_a21ax
                      p_a219K = double g_a219J
                      (g_a219J, gpart_a21ax) = Genome.Split.split gpart_a21aw
                      p_a219I = Functions.belowten' g_a219H
                      (g_a219H, gpart_a21aw) = Genome.Split.split gpart_a21av
                      p_a219G = double g_a219F
                      (g_a219F, gpart_a21av) = Genome.Split.split gpart_a21au
                      p_a219E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219D
                      (g_a219D, gpart_a21au) = Genome.Split.split gpart_a21at
                      p_a219C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219B
                      (g_a219B, gpart_a21at) = Genome.Split.split gpart_a21as
                      p_a219A = Functions.belowten' g_a219z
                      (g_a219z, gpart_a21as) = Genome.Split.split gpart_a21ar
                      p_a219y = double g_a219x
                      (g_a219x, gpart_a21ar) = Genome.Split.split gpart_a21aq
                      p_a219w = double g_a219v
                      (g_a219v, gpart_a21aq) = Genome.Split.split gpart_a21ap
                      p_a219u = double g_a219t
                      (g_a219t, gpart_a21ap) = Genome.Split.split gpart_a21ao
                      p_a219s = Functions.belowten' g_a219r
                      (g_a219r, gpart_a21ao) = Genome.Split.split gpart_a21an
                      p_a219q = double g_a219p
                      (g_a219p, gpart_a21an) = Genome.Split.split gpart_a21am
                      p_a219o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219n
                      (g_a219n, gpart_a21am) = Genome.Split.split gpart_a21al
                      p_a219m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219l
                      (g_a219l, gpart_a21al) = Genome.Split.split gpart_a21ak
                      p_a219k = double g_a219j
                      (g_a219j, gpart_a21ak) = Genome.Split.split gpart_a21aj
                      p_a219i = Functions.belowten' g_a219h
                      (g_a219h, gpart_a21aj) = Genome.Split.split gpart_a21ai
                      p_a219g = double g_a219f
                      (g_a219f, gpart_a21ai) = Genome.Split.split gpart_a21ah
                      p_a219e = Functions.belowten' g_a219d
                      (g_a219d, gpart_a21ah) = Genome.Split.split gpart_a21ag
                      p_a219c = double g_a219b
                      (g_a219b, gpart_a21ag) = Genome.Split.split gpart_a21af
                      p_a219a = double g_a2199
                      (g_a2199, gpart_a21af) = Genome.Split.split gpart_a21ae
                      p_a2198 = double g_a2197
                      (g_a2197, gpart_a21ae) = Genome.Split.split gpart_a21ad
                      p_a2196 = Functions.belowten' g_a2195
                      (g_a2195, gpart_a21ad) = Genome.Split.split gpart_a21ac
                      p_a2194 = double g_a2193
                      (g_a2193, gpart_a21ac) = Genome.Split.split gpart_a21ab
                      p_a2192
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2191
                      (g_a2191, gpart_a21ab) = Genome.Split.split gpart_a21aa
                      p_a2190
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218Z
                      (g_a218Z, gpart_a21aa) = Genome.Split.split gpart_a21a9
                      p_a218Y = Functions.belowten' g_a218X
                      (g_a218X, gpart_a21a9) = Genome.Split.split gpart_a21a8
                      p_a218W = double g_a218V
                      (g_a218V, gpart_a21a8) = Genome.Split.split gpart_a21a7
                      p_a218U = double g_a218T
                      (g_a218T, gpart_a21a7) = Genome.Split.split gpart_a21a6
                      p_a218S = double g_a218R
                      (g_a218R, gpart_a21a6) = Genome.Split.split gpart_a21a5
                      p_a218Q = double g_a218P
                      (g_a218P, gpart_a21a5) = Genome.Split.split gpart_a21a4
                      p_a218O = double g_a218N
                      (g_a218N, gpart_a21a4) = Genome.Split.split gpart_a21a3
                      p_a218M = double g_a218L
                      (g_a218L, gpart_a21a3) = Genome.Split.split genome_a21a1
                    in  \ x_a21aG
                          -> let
                               c_PTB_a21aL
                                 = ((Data.Fixed.Vector.toVector x_a21aG) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21aJ
                                 = ((Data.Fixed.Vector.toVector x_a21aG) Data.Vector.Unboxed.! 2)
                               c_RESTc_a21aH
                                 = ((Data.Fixed.Vector.toVector x_a21aG) Data.Vector.Unboxed.! 3)
                               c_NPTB_a21aP
                                 = ((Data.Fixed.Vector.toVector x_a21aG) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a21b0
                                 = ((Data.Fixed.Vector.toVector x_a21aG) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a218U
                                     * ((p_a2198 + ((c_RESTc_a21aH / p_a218W) ** p_a218Y))
                                        / (((1 + p_a2198) + ((c_RESTc_a21aH / p_a218W) ** p_a218Y))
                                           + (((p_a218M / p_a2190) ** p_a2192)
                                              + ((c_MiRs_a21aJ / p_a2194) ** p_a2196)))))
                                    + (negate (p_a219S * c_PTB_a21aL))),
                                   ((p_a219a
                                     / (1
                                        + (((c_MiRs_a21aJ / p_a219c) ** p_a219e)
                                           + ((c_PTB_a21aL / p_a219g) ** p_a219i))))
                                    + (negate (p_a219U * c_NPTB_a21aP))),
                                   ((p_a219k
                                     * (p_a219u
                                        / ((1 + p_a219u) + ((c_RESTc_a21aH / p_a219q) ** p_a219s))))
                                    + (negate (p_a219W * c_MiRs_a21aJ))),
                                   ((p_a219w
                                     * ((p_a219K + ((c_PTB_a21aL / p_a219y) ** p_a219A))
                                        / (((1 + p_a219K) + ((c_PTB_a21aL / p_a219y) ** p_a219A))
                                           + ((c_MiRs_a21aJ / p_a219G) ** p_a219I))))
                                    + (negate (p_a219Y * c_RESTc_a21aH))),
                                   ((p_a219M / (1 + ((c_RESTc_a21aH / p_a219O) ** p_a219Q)))
                                    + (negate (p_a21a0 * c_EndoNeuroTFs_a21b0)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490842",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490850",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490852",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490872",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490874",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490888",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490890",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21a1
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21bD
                            p_a21a0 = double g_a219Z
                            (g_a219Z, gpart_a21bD) = Genome.Split.split gpart_a21bC
                            p_a219Y = double g_a219X
                            (g_a219X, gpart_a21bC) = Genome.Split.split gpart_a21bB
                            p_a219W = double g_a219V
                            (g_a219V, gpart_a21bB) = Genome.Split.split gpart_a21bA
                            p_a219U = double g_a219T
                            (g_a219T, gpart_a21bA) = Genome.Split.split gpart_a21bz
                            p_a219S = double g_a219R
                            (g_a219R, gpart_a21bz) = Genome.Split.split gpart_a21by
                            p_a219Q = Functions.belowten' g_a219P
                            (g_a219P, gpart_a21by) = Genome.Split.split gpart_a21bx
                            p_a219O = double g_a219N
                            (g_a219N, gpart_a21bx) = Genome.Split.split gpart_a21bw
                            p_a219M = double g_a219L
                            (g_a219L, gpart_a21bw) = Genome.Split.split gpart_a21bv
                            p_a219K = double g_a219J
                            (g_a219J, gpart_a21bv) = Genome.Split.split gpart_a21bu
                            p_a219I = Functions.belowten' g_a219H
                            (g_a219H, gpart_a21bu) = Genome.Split.split gpart_a21bt
                            p_a219G = double g_a219F
                            (g_a219F, gpart_a21bt) = Genome.Split.split gpart_a21bs
                            p_a219E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219D
                            (g_a219D, gpart_a21bs) = Genome.Split.split gpart_a21br
                            p_a219C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219B
                            (g_a219B, gpart_a21br) = Genome.Split.split gpart_a21bq
                            p_a219A = Functions.belowten' g_a219z
                            (g_a219z, gpart_a21bq) = Genome.Split.split gpart_a21bp
                            p_a219y = double g_a219x
                            (g_a219x, gpart_a21bp) = Genome.Split.split gpart_a21bo
                            p_a219w = double g_a219v
                            (g_a219v, gpart_a21bo) = Genome.Split.split gpart_a21bn
                            p_a219u = double g_a219t
                            (g_a219t, gpart_a21bn) = Genome.Split.split gpart_a21bm
                            p_a219s = Functions.belowten' g_a219r
                            (g_a219r, gpart_a21bm) = Genome.Split.split gpart_a21bl
                            p_a219q = double g_a219p
                            (g_a219p, gpart_a21bl) = Genome.Split.split gpart_a21bk
                            p_a219o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219n
                            (g_a219n, gpart_a21bk) = Genome.Split.split gpart_a21bj
                            p_a219m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a219l
                            (g_a219l, gpart_a21bj) = Genome.Split.split gpart_a21bi
                            p_a219k = double g_a219j
                            (g_a219j, gpart_a21bi) = Genome.Split.split gpart_a21bh
                            p_a219i = Functions.belowten' g_a219h
                            (g_a219h, gpart_a21bh) = Genome.Split.split gpart_a21bg
                            p_a219g = double g_a219f
                            (g_a219f, gpart_a21bg) = Genome.Split.split gpart_a21bf
                            p_a219e = Functions.belowten' g_a219d
                            (g_a219d, gpart_a21bf) = Genome.Split.split gpart_a21be
                            p_a219c = double g_a219b
                            (g_a219b, gpart_a21be) = Genome.Split.split gpart_a21bd
                            p_a219a = double g_a2199
                            (g_a2199, gpart_a21bd) = Genome.Split.split gpart_a21bc
                            p_a2198 = double g_a2197
                            (g_a2197, gpart_a21bc) = Genome.Split.split gpart_a21bb
                            p_a2196 = Functions.belowten' g_a2195
                            (g_a2195, gpart_a21bb) = Genome.Split.split gpart_a21ba
                            p_a2194 = double g_a2193
                            (g_a2193, gpart_a21ba) = Genome.Split.split gpart_a21b9
                            p_a2192
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2191
                            (g_a2191, gpart_a21b9) = Genome.Split.split gpart_a21b8
                            p_a2190
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218Z
                            (g_a218Z, gpart_a21b8) = Genome.Split.split gpart_a21b7
                            p_a218Y = Functions.belowten' g_a218X
                            (g_a218X, gpart_a21b7) = Genome.Split.split gpart_a21b6
                            p_a218W = double g_a218V
                            (g_a218V, gpart_a21b6) = Genome.Split.split gpart_a21b5
                            p_a218U = double g_a218T
                            (g_a218T, gpart_a21b5) = Genome.Split.split gpart_a21b4
                            p_a218S = double g_a218R
                            (g_a218R, gpart_a21b4) = Genome.Split.split gpart_a21b3
                            p_a218Q = double g_a218P
                            (g_a218P, gpart_a21b3) = Genome.Split.split gpart_a21b2
                            p_a218O = double g_a218N
                            (g_a218N, gpart_a21b2) = Genome.Split.split gpart_a21b1
                            p_a218M = double g_a218L
                            (g_a218L, gpart_a21b1) = Genome.Split.split genome_a21a1
                          in
                            \ desc_a21a2
                              -> case desc_a21a2 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218M)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218O)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218Q)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218S)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218U)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218W)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218Y)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2190)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2192)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2194)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2196)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2198)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219a)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219c)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219e)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219g)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219i)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219k)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219m)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219o)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219q)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219s)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219u)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219w)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219y)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219A)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219C)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219E)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219G)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219I)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219K)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219M)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219O)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219Q)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219S)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219U)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219W)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a219Y)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21a0)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asSx
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asTb
                      p_asSw = code-0.1.0.0:Genome.FixedList.Functions.double g_asSv
                      (g_asSv, gpart_asTb) = Genome.Split.split gpart_asTa
                      p_asSu = code-0.1.0.0:Genome.FixedList.Functions.double g_asSt
                      (g_asSt, gpart_asTa) = Genome.Split.split gpart_asT9
                      p_asSs = code-0.1.0.0:Genome.FixedList.Functions.double g_asSr
                      (g_asSr, gpart_asT9) = Genome.Split.split gpart_asT8
                      p_asSq = code-0.1.0.0:Genome.FixedList.Functions.double g_asSp
                      (g_asSp, gpart_asT8) = Genome.Split.split gpart_asT7
                      p_asSo = code-0.1.0.0:Genome.FixedList.Functions.double g_asSn
                      (g_asSn, gpart_asT7) = Genome.Split.split gpart_asT6
                      p_asSm = Functions.belowten' g_asSl
                      (g_asSl, gpart_asT6) = Genome.Split.split gpart_asT5
                      p_asSk = code-0.1.0.0:Genome.FixedList.Functions.double g_asSj
                      (g_asSj, gpart_asT5) = Genome.Split.split gpart_asT4
                      p_asSi = code-0.1.0.0:Genome.FixedList.Functions.double g_asSh
                      (g_asSh, gpart_asT4) = Genome.Split.split gpart_asT3
                      p_asSg = code-0.1.0.0:Genome.FixedList.Functions.double g_asSf
                      (g_asSf, gpart_asT3) = Genome.Split.split gpart_asT2
                      p_asSe = Functions.belowten' g_asSd
                      (g_asSd, gpart_asT2) = Genome.Split.split gpart_asT1
                      p_asSc = code-0.1.0.0:Genome.FixedList.Functions.double g_asSb
                      (g_asSb, gpart_asT1) = Genome.Split.split gpart_asT0
                      p_asSa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS9
                      (g_asS9, gpart_asT0) = Genome.Split.split gpart_asSZ
                      p_asS8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS7
                      (g_asS7, gpart_asSZ) = Genome.Split.split gpart_asSY
                      p_asS6 = Functions.belowten' g_asS5
                      (g_asS5, gpart_asSY) = Genome.Split.split gpart_asSX
                      p_asS4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS3
                      (g_asS3, gpart_asSX) = Genome.Split.split gpart_asSW
                      p_asS2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS1
                      (g_asS1, gpart_asSW) = Genome.Split.split gpart_asSV
                      p_asS0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asRZ
                      (g_asRZ, gpart_asSV) = Genome.Split.split gpart_asSU
                      p_asRY = Functions.belowten' g_asRX
                      (g_asRX, gpart_asSU) = Genome.Split.split gpart_asST
                      p_asRW = code-0.1.0.0:Genome.FixedList.Functions.double g_asRV
                      (g_asRV, gpart_asST) = Genome.Split.split gpart_asSS
                      p_asRU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRT
                      (g_asRT, gpart_asSS) = Genome.Split.split gpart_asSR
                      p_asRS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRR
                      (g_asRR, gpart_asSR) = Genome.Split.split gpart_asSQ
                      p_asRQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asRP
                      (g_asRP, gpart_asSQ) = Genome.Split.split gpart_asSP
                      p_asRO = Functions.belowten' g_asRN
                      (g_asRN, gpart_asSP) = Genome.Split.split gpart_asSO
                      p_asRM = code-0.1.0.0:Genome.FixedList.Functions.double g_asRL
                      (g_asRL, gpart_asSO) = Genome.Split.split gpart_asSN
                      p_asRK = Functions.belowten' g_asRJ
                      (g_asRJ, gpart_asSN) = Genome.Split.split gpart_asSM
                      p_asRI = code-0.1.0.0:Genome.FixedList.Functions.double g_asRH
                      (g_asRH, gpart_asSM) = Genome.Split.split gpart_asSL
                      p_asRG = code-0.1.0.0:Genome.FixedList.Functions.double g_asRF
                      (g_asRF, gpart_asSL) = Genome.Split.split gpart_asSK
                      p_asRE = code-0.1.0.0:Genome.FixedList.Functions.double g_asRD
                      (g_asRD, gpart_asSK) = Genome.Split.split gpart_asSJ
                      p_asRC = Functions.belowten' g_asRB
                      (g_asRB, gpart_asSJ) = Genome.Split.split gpart_asSI
                      p_asRA = code-0.1.0.0:Genome.FixedList.Functions.double g_asRz
                      (g_asRz, gpart_asSI) = Genome.Split.split gpart_asSH
                      p_asRy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRx
                      (g_asRx, gpart_asSH) = Genome.Split.split gpart_asSG
                      p_asRw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRv
                      (g_asRv, gpart_asSG) = Genome.Split.split gpart_asSF
                      p_asRu = Functions.belowten' g_asRt
                      (g_asRt, gpart_asSF) = Genome.Split.split gpart_asSE
                      p_asRs = code-0.1.0.0:Genome.FixedList.Functions.double g_asRr
                      (g_asRr, gpart_asSE) = Genome.Split.split gpart_asSD
                      p_asRq = code-0.1.0.0:Genome.FixedList.Functions.double g_asRp
                      (g_asRp, gpart_asSD) = Genome.Split.split gpart_asSC
                      p_asRo = code-0.1.0.0:Genome.FixedList.Functions.double g_asRn
                      (g_asRn, gpart_asSC) = Genome.Split.split gpart_asSB
                      p_asRm = code-0.1.0.0:Genome.FixedList.Functions.double g_asRl
                      (g_asRl, gpart_asSB) = Genome.Split.split gpart_asSA
                      p_asRk = code-0.1.0.0:Genome.FixedList.Functions.double g_asRj
                      (g_asRj, gpart_asSA) = Genome.Split.split gpart_asSz
                      p_asRi = code-0.1.0.0:Genome.FixedList.Functions.double g_asRh
                      (g_asRh, gpart_asSz) = Genome.Split.split genome_asSx
                    in
                      [Reaction
                         (\ x_asTc
                            -> let
                                 c_MiRs_asTf = ((toVector x_asTc) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asTd = ((toVector x_asTc) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asRq
                                  * ((p_asRE + ((c_RESTc_asTd / p_asRs) ** p_asRu))
                                     / (((1 + p_asRE) + ((c_RESTc_asTd / p_asRs) ** p_asRu))
                                        + ((c_MiRs_asTf / p_asRA) ** p_asRC)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTg
                            -> let
                                 c_MiRs_asTh = ((toVector x_asTg) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTi = ((toVector x_asTg) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asRG
                                  / (1
                                     + (((c_MiRs_asTh / p_asRI) ** p_asRK)
                                        + ((c_PTB_asTi / p_asRM) ** p_asRO)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asTj
                            -> let c_RESTc_asTk = ((toVector x_asTj) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asRQ
                                  * ((p_asS0 + ((p_asRm / p_asRS) ** p_asRU))
                                     / (((1 + p_asS0) + ((p_asRm / p_asRS) ** p_asRU))
                                        + ((c_RESTc_asTk / p_asRW) ** p_asRY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asTl
                            -> let
                                 c_MiRs_asTo = ((toVector x_asTl) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTm = ((toVector x_asTl) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asS2
                                  * ((p_asSg + ((c_PTB_asTm / p_asS4) ** p_asS6))
                                     / (((1 + p_asSg) + ((c_PTB_asTm / p_asS4) ** p_asS6))
                                        + (((p_asRi / p_asS8) ** p_asSa)
                                           + ((c_MiRs_asTo / p_asSc) ** p_asSe))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asTp
                            -> let c_RESTc_asTq = ((toVector x_asTp) Data.Vector.Unboxed.! 3)
                               in (p_asSi / (1 + ((c_RESTc_asTq / p_asSk) ** p_asSm))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asTr
                            -> let c_PTB_asTs = ((toVector x_asTr) Data.Vector.Unboxed.! 0)
                               in (p_asSo * c_PTB_asTs))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTt
                            -> let c_NPTB_asTu = ((toVector x_asTt) Data.Vector.Unboxed.! 1)
                               in (p_asSq * c_NPTB_asTu))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asTv
                            -> let c_MiRs_asTw = ((toVector x_asTv) Data.Vector.Unboxed.! 2)
                               in (p_asSs * c_MiRs_asTw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asTx
                            -> let c_RESTc_asTy = ((toVector x_asTx) Data.Vector.Unboxed.! 3)
                               in (p_asSu * c_RESTc_asTy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asTz
                            -> let
                                 c_EndoNeuroTFs_asTA = ((toVector x_asTz) Data.Vector.Unboxed.! 4)
                               in (p_asSw * c_EndoNeuroTFs_asTA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120742",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120744",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120764",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120766",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120780",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120782",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120792",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asSx
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUi
                            p_asSw = code-0.1.0.0:Genome.FixedList.Functions.double g_asSv
                            (g_asSv, gpart_asUi) = Genome.Split.split gpart_asUh
                            p_asSu = code-0.1.0.0:Genome.FixedList.Functions.double g_asSt
                            (g_asSt, gpart_asUh) = Genome.Split.split gpart_asUg
                            p_asSs = code-0.1.0.0:Genome.FixedList.Functions.double g_asSr
                            (g_asSr, gpart_asUg) = Genome.Split.split gpart_asUf
                            p_asSq = code-0.1.0.0:Genome.FixedList.Functions.double g_asSp
                            (g_asSp, gpart_asUf) = Genome.Split.split gpart_asUe
                            p_asSo = code-0.1.0.0:Genome.FixedList.Functions.double g_asSn
                            (g_asSn, gpart_asUe) = Genome.Split.split gpart_asUd
                            p_asSm = Functions.belowten' g_asSl
                            (g_asSl, gpart_asUd) = Genome.Split.split gpart_asUc
                            p_asSk = code-0.1.0.0:Genome.FixedList.Functions.double g_asSj
                            (g_asSj, gpart_asUc) = Genome.Split.split gpart_asUb
                            p_asSi = code-0.1.0.0:Genome.FixedList.Functions.double g_asSh
                            (g_asSh, gpart_asUb) = Genome.Split.split gpart_asUa
                            p_asSg = code-0.1.0.0:Genome.FixedList.Functions.double g_asSf
                            (g_asSf, gpart_asUa) = Genome.Split.split gpart_asU9
                            p_asSe = Functions.belowten' g_asSd
                            (g_asSd, gpart_asU9) = Genome.Split.split gpart_asU8
                            p_asSc = code-0.1.0.0:Genome.FixedList.Functions.double g_asSb
                            (g_asSb, gpart_asU8) = Genome.Split.split gpart_asU7
                            p_asSa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS9
                            (g_asS9, gpart_asU7) = Genome.Split.split gpart_asU6
                            p_asS8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS7
                            (g_asS7, gpart_asU6) = Genome.Split.split gpart_asU5
                            p_asS6 = Functions.belowten' g_asS5
                            (g_asS5, gpart_asU5) = Genome.Split.split gpart_asU4
                            p_asS4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS3
                            (g_asS3, gpart_asU4) = Genome.Split.split gpart_asU3
                            p_asS2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS1
                            (g_asS1, gpart_asU3) = Genome.Split.split gpart_asU2
                            p_asS0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asRZ
                            (g_asRZ, gpart_asU2) = Genome.Split.split gpart_asU1
                            p_asRY = Functions.belowten' g_asRX
                            (g_asRX, gpart_asU1) = Genome.Split.split gpart_asU0
                            p_asRW = code-0.1.0.0:Genome.FixedList.Functions.double g_asRV
                            (g_asRV, gpart_asU0) = Genome.Split.split gpart_asTZ
                            p_asRU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRT
                            (g_asRT, gpart_asTZ) = Genome.Split.split gpart_asTY
                            p_asRS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRR
                            (g_asRR, gpart_asTY) = Genome.Split.split gpart_asTX
                            p_asRQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asRP
                            (g_asRP, gpart_asTX) = Genome.Split.split gpart_asTW
                            p_asRO = Functions.belowten' g_asRN
                            (g_asRN, gpart_asTW) = Genome.Split.split gpart_asTV
                            p_asRM = code-0.1.0.0:Genome.FixedList.Functions.double g_asRL
                            (g_asRL, gpart_asTV) = Genome.Split.split gpart_asTU
                            p_asRK = Functions.belowten' g_asRJ
                            (g_asRJ, gpart_asTU) = Genome.Split.split gpart_asTT
                            p_asRI = code-0.1.0.0:Genome.FixedList.Functions.double g_asRH
                            (g_asRH, gpart_asTT) = Genome.Split.split gpart_asTS
                            p_asRG = code-0.1.0.0:Genome.FixedList.Functions.double g_asRF
                            (g_asRF, gpart_asTS) = Genome.Split.split gpart_asTR
                            p_asRE = code-0.1.0.0:Genome.FixedList.Functions.double g_asRD
                            (g_asRD, gpart_asTR) = Genome.Split.split gpart_asTQ
                            p_asRC = Functions.belowten' g_asRB
                            (g_asRB, gpart_asTQ) = Genome.Split.split gpart_asTP
                            p_asRA = code-0.1.0.0:Genome.FixedList.Functions.double g_asRz
                            (g_asRz, gpart_asTP) = Genome.Split.split gpart_asTO
                            p_asRy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRx
                            (g_asRx, gpart_asTO) = Genome.Split.split gpart_asTN
                            p_asRw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRv
                            (g_asRv, gpart_asTN) = Genome.Split.split gpart_asTM
                            p_asRu = Functions.belowten' g_asRt
                            (g_asRt, gpart_asTM) = Genome.Split.split gpart_asTL
                            p_asRs = code-0.1.0.0:Genome.FixedList.Functions.double g_asRr
                            (g_asRr, gpart_asTL) = Genome.Split.split gpart_asTK
                            p_asRq = code-0.1.0.0:Genome.FixedList.Functions.double g_asRp
                            (g_asRp, gpart_asTK) = Genome.Split.split gpart_asTJ
                            p_asRo = code-0.1.0.0:Genome.FixedList.Functions.double g_asRn
                            (g_asRn, gpart_asTJ) = Genome.Split.split gpart_asTI
                            p_asRm = code-0.1.0.0:Genome.FixedList.Functions.double g_asRl
                            (g_asRl, gpart_asTI) = Genome.Split.split gpart_asTH
                            p_asRk = code-0.1.0.0:Genome.FixedList.Functions.double g_asRj
                            (g_asRj, gpart_asTH) = Genome.Split.split gpart_asTG
                            p_asRi = code-0.1.0.0:Genome.FixedList.Functions.double g_asRh
                            (g_asRh, gpart_asTG) = Genome.Split.split genome_asSx
                          in
                            \ desc_asSy
                              -> case desc_asSy of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRi)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRk)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRm)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRo)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRq)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRs)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRu)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRw)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRy)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRA)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRC)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRE)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRG)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRI)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRK)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRM)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRO)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRQ)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRS)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRU)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRW)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRY)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS0)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS2)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS4)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS6)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS8)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSa)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSc)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSe)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSg)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSi)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSk)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSm)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSo)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSq)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSs)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSu)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSw)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asWf
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWT
                      p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                      (g_asWd, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                      (g_asWb, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                      (g_asW9, gpart_asWR) = Genome.Split.split gpart_asWQ
                      p_asW8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW7
                      (g_asW7, gpart_asWQ) = Genome.Split.split gpart_asWP
                      p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                      (g_asW5, gpart_asWP) = Genome.Split.split gpart_asWO
                      p_asW4 = Functions.belowten' g_asW3
                      (g_asW3, gpart_asWO) = Genome.Split.split gpart_asWN
                      p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                      (g_asW1, gpart_asWN) = Genome.Split.split gpart_asWM
                      p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                      (g_asVZ, gpart_asWM) = Genome.Split.split gpart_asWL
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asWL) = Genome.Split.split gpart_asWK
                      p_asVW = Functions.belowten' g_asVV
                      (g_asVV, gpart_asWK) = Genome.Split.split gpart_asWJ
                      p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                      (g_asVT, gpart_asWJ) = Genome.Split.split gpart_asWI
                      p_asVS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVR
                      (g_asVR, gpart_asWI) = Genome.Split.split gpart_asWH
                      p_asVQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVP
                      (g_asVP, gpart_asWH) = Genome.Split.split gpart_asWG
                      p_asVO = Functions.belowten' g_asVN
                      (g_asVN, gpart_asWG) = Genome.Split.split gpart_asWF
                      p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                      (g_asVL, gpart_asWF) = Genome.Split.split gpart_asWE
                      p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                      (g_asVJ, gpart_asWE) = Genome.Split.split gpart_asWD
                      p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                      (g_asVH, gpart_asWD) = Genome.Split.split gpart_asWC
                      p_asVG = Functions.belowten' g_asVF
                      (g_asVF, gpart_asWC) = Genome.Split.split gpart_asWB
                      p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                      (g_asVD, gpart_asWB) = Genome.Split.split gpart_asWA
                      p_asVC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVB
                      (g_asVB, gpart_asWA) = Genome.Split.split gpart_asWz
                      p_asVA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVz
                      (g_asVz, gpart_asWz) = Genome.Split.split gpart_asWy
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWy) = Genome.Split.split gpart_asWx
                      p_asVw = Functions.belowten' g_asVv
                      (g_asVv, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asVs = Functions.belowten' g_asVr
                      (g_asVr, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                      (g_asVn, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asWr) = Genome.Split.split gpart_asWq
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asWq) = Genome.Split.split gpart_asWp
                      p_asVg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                      (g_asVf, gpart_asWp) = Genome.Split.split gpart_asWo
                      p_asVe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                      (g_asVd, gpart_asWo) = Genome.Split.split gpart_asWn
                      p_asVc = Functions.belowten' g_asVb
                      (g_asVb, gpart_asWn) = Genome.Split.split gpart_asWm
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asWm) = Genome.Split.split gpart_asWl
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asWl) = Genome.Split.split gpart_asWk
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asWk) = Genome.Split.split gpart_asWj
                      p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                      (g_asV3, gpart_asWj) = Genome.Split.split gpart_asWi
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asWi) = Genome.Split.split gpart_asWh
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asWh) = Genome.Split.split genome_asWf
                    in
                      [Reaction
                         (\ x_asWU
                            -> let
                                 c_MiRs_asWX = ((toVector x_asWU) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWV = ((toVector x_asWU) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asV8
                                  * ((p_asVm + ((c_RESTc_asWV / p_asVa) ** p_asVc))
                                     / (((1 + p_asVm) + ((c_RESTc_asWV / p_asVa) ** p_asVc))
                                        + ((c_MiRs_asWX / p_asVi) ** p_asVk)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWY
                            -> let
                                 c_MiRs_asWZ = ((toVector x_asWY) Data.Vector.Unboxed.! 2)
                                 c_PTB_asX0 = ((toVector x_asWY) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVo
                                  / (1
                                     + (((c_MiRs_asWZ / p_asVq) ** p_asVs)
                                        + ((c_PTB_asX0 / p_asVu) ** p_asVw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asX1
                            -> let c_RESTc_asX2 = ((toVector x_asX1) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVy
                                  * (p_asVI
                                     / ((1 + p_asVI) + ((c_RESTc_asX2 / p_asVE) ** p_asVG)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asX3
                            -> let
                                 c_MiRs_asX6 = ((toVector x_asX3) Data.Vector.Unboxed.! 2)
                                 c_PTB_asX4 = ((toVector x_asX3) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVK
                                  * ((p_asVY + ((c_PTB_asX4 / p_asVM) ** p_asVO))
                                     / (((1 + p_asVY) + ((c_PTB_asX4 / p_asVM) ** p_asVO))
                                        + (((p_asV0 / p_asVQ) ** p_asVS)
                                           + ((c_MiRs_asX6 / p_asVU) ** p_asVW))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asX7
                            -> let c_RESTc_asX8 = ((toVector x_asX7) Data.Vector.Unboxed.! 3)
                               in (p_asW0 / (1 + ((c_RESTc_asX8 / p_asW2) ** p_asW4))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asX9
                            -> let c_PTB_asXa = ((toVector x_asX9) Data.Vector.Unboxed.! 0)
                               in (p_asW6 * c_PTB_asXa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXb
                            -> let c_NPTB_asXc = ((toVector x_asXb) Data.Vector.Unboxed.! 1)
                               in (p_asW8 * c_NPTB_asXc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXd
                            -> let c_MiRs_asXe = ((toVector x_asXd) Data.Vector.Unboxed.! 2)
                               in (p_asWa * c_MiRs_asXe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXf
                            -> let c_RESTc_asXg = ((toVector x_asXf) Data.Vector.Unboxed.! 3)
                               in (p_asWc * c_RESTc_asXg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXh
                            -> let
                                 c_EndoNeuroTFs_asXi = ((toVector x_asXh) Data.Vector.Unboxed.! 4)
                               in (p_asWe * c_EndoNeuroTFs_asXi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWf
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXV
                            p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                            (g_asWd, gpart_asXV) = Genome.Split.split gpart_asXU
                            p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                            (g_asWb, gpart_asXU) = Genome.Split.split gpart_asXT
                            p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                            (g_asW9, gpart_asXT) = Genome.Split.split gpart_asXS
                            p_asW8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW7
                            (g_asW7, gpart_asXS) = Genome.Split.split gpart_asXR
                            p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                            (g_asW5, gpart_asXR) = Genome.Split.split gpart_asXQ
                            p_asW4 = Functions.belowten' g_asW3
                            (g_asW3, gpart_asXQ) = Genome.Split.split gpart_asXP
                            p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                            (g_asW1, gpart_asXP) = Genome.Split.split gpart_asXO
                            p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                            (g_asVZ, gpart_asXO) = Genome.Split.split gpart_asXN
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asXN) = Genome.Split.split gpart_asXM
                            p_asVW = Functions.belowten' g_asVV
                            (g_asVV, gpart_asXM) = Genome.Split.split gpart_asXL
                            p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                            (g_asVT, gpart_asXL) = Genome.Split.split gpart_asXK
                            p_asVS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVR
                            (g_asVR, gpart_asXK) = Genome.Split.split gpart_asXJ
                            p_asVQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVP
                            (g_asVP, gpart_asXJ) = Genome.Split.split gpart_asXI
                            p_asVO = Functions.belowten' g_asVN
                            (g_asVN, gpart_asXI) = Genome.Split.split gpart_asXH
                            p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                            (g_asVL, gpart_asXH) = Genome.Split.split gpart_asXG
                            p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                            (g_asVJ, gpart_asXG) = Genome.Split.split gpart_asXF
                            p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                            (g_asVH, gpart_asXF) = Genome.Split.split gpart_asXE
                            p_asVG = Functions.belowten' g_asVF
                            (g_asVF, gpart_asXE) = Genome.Split.split gpart_asXD
                            p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                            (g_asVD, gpart_asXD) = Genome.Split.split gpart_asXC
                            p_asVC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVB
                            (g_asVB, gpart_asXC) = Genome.Split.split gpart_asXB
                            p_asVA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVz
                            (g_asVz, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asVw = Functions.belowten' g_asVv
                            (g_asVv, gpart_asXz) = Genome.Split.split gpart_asXy
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asXy) = Genome.Split.split gpart_asXx
                            p_asVs = Functions.belowten' g_asVr
                            (g_asVr, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                            (g_asVn, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                            (g_asVf, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                            (g_asVd, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVc = Functions.belowten' g_asVb
                            (g_asVb, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                            (g_asV3, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asXj) = Genome.Split.split genome_asWf
                          in
                            \ desc_asWg
                              -> case desc_asWg of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW4)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW6)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW8)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWa)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWc)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWe)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_asZS
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0w
                      p_asZR = code-0.1.0.0:Genome.FixedList.Functions.double g_asZQ
                      (g_asZQ, gpart_at0w) = Genome.Split.split gpart_at0v
                      p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                      (g_asZO, gpart_at0v) = Genome.Split.split gpart_at0u
                      p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                      (g_asZM, gpart_at0u) = Genome.Split.split gpart_at0t
                      p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                      (g_asZK, gpart_at0t) = Genome.Split.split gpart_at0s
                      p_asZJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZI
                      (g_asZI, gpart_at0s) = Genome.Split.split gpart_at0r
                      p_asZH = Functions.belowten' g_asZG
                      (g_asZG, gpart_at0r) = Genome.Split.split gpart_at0q
                      p_asZF = code-0.1.0.0:Genome.FixedList.Functions.double g_asZE
                      (g_asZE, gpart_at0q) = Genome.Split.split gpart_at0p
                      p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                      (g_asZC, gpart_at0p) = Genome.Split.split gpart_at0o
                      p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                      (g_asZA, gpart_at0o) = Genome.Split.split gpart_at0n
                      p_asZz = Functions.belowten' g_asZy
                      (g_asZy, gpart_at0n) = Genome.Split.split gpart_at0m
                      p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                      (g_asZw, gpart_at0m) = Genome.Split.split gpart_at0l
                      p_asZv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZu
                      (g_asZu, gpart_at0l) = Genome.Split.split gpart_at0k
                      p_asZt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZs
                      (g_asZs, gpart_at0k) = Genome.Split.split gpart_at0j
                      p_asZr = Functions.belowten' g_asZq
                      (g_asZq, gpart_at0j) = Genome.Split.split gpart_at0i
                      p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                      (g_asZo, gpart_at0i) = Genome.Split.split gpart_at0h
                      p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                      (g_asZm, gpart_at0h) = Genome.Split.split gpart_at0g
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at0g) = Genome.Split.split gpart_at0f
                      p_asZj = Functions.belowten' g_asZi
                      (g_asZi, gpart_at0f) = Genome.Split.split gpart_at0e
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at0e) = Genome.Split.split gpart_at0d
                      p_asZf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZe
                      (g_asZe, gpart_at0d) = Genome.Split.split gpart_at0c
                      p_asZd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZc
                      (g_asZc, gpart_at0c) = Genome.Split.split gpart_at0b
                      p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                      (g_asZa, gpart_at0b) = Genome.Split.split gpart_at0a
                      p_asZ9 = Functions.belowten' g_asZ8
                      (g_asZ8, gpart_at0a) = Genome.Split.split gpart_at09
                      p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                      (g_asZ6, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZ5 = Functions.belowten' g_asZ4
                      (g_asZ4, gpart_at08) = Genome.Split.split gpart_at07
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_at07) = Genome.Split.split gpart_at06
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_at06) = Genome.Split.split gpart_at05
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_at05) = Genome.Split.split gpart_at04
                      p_asYX = Functions.belowten' g_asYW
                      (g_asYW, gpart_at04) = Genome.Split.split gpart_at03
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_at03) = Genome.Split.split gpart_at02
                      p_asYT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                      (g_asYS, gpart_at02) = Genome.Split.split gpart_at01
                      p_asYR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYQ
                      (g_asYQ, gpart_at01) = Genome.Split.split gpart_at00
                      p_asYP = Functions.belowten' g_asYO
                      (g_asYO, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                      (g_asYE, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                      (g_asYC, gpart_asZU) = Genome.Split.split genome_asZS
                    in
                      [Reaction
                         (\ x_at0x
                            -> let
                                 c_MiRs_at0A = ((toVector x_at0x) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at0y = ((toVector x_at0x) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYL
                                  * ((p_asYZ + ((c_RESTc_at0y / p_asYN) ** p_asYP))
                                     / (((1 + p_asYZ) + ((c_RESTc_at0y / p_asYN) ** p_asYP))
                                        + ((c_MiRs_at0A / p_asYV) ** p_asYX)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0B
                            -> let
                                 c_MiRs_at0C = ((toVector x_at0B) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0D = ((toVector x_at0B) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZ1
                                  / (1
                                     + (((c_MiRs_at0C / p_asZ3) ** p_asZ5)
                                        + ((c_PTB_at0D / p_asZ7) ** p_asZ9)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0E
                            -> let c_RESTc_at0F = ((toVector x_at0E) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZb
                                  * (p_asZl
                                     / ((1 + p_asZl) + ((c_RESTc_at0F / p_asZh) ** p_asZj)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0G
                            -> let
                                 c_MiRs_at0J = ((toVector x_at0G) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0H = ((toVector x_at0G) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZn
                                  * ((p_asZB + ((c_PTB_at0H / p_asZp) ** p_asZr))
                                     / (((1 + p_asZB) + ((c_PTB_at0H / p_asZp) ** p_asZr))
                                        + ((c_MiRs_at0J / p_asZx) ** p_asZz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0K
                            -> let c_RESTc_at0L = ((toVector x_at0K) Data.Vector.Unboxed.! 3)
                               in (p_asZD / (1 + ((c_RESTc_at0L / p_asZF) ** p_asZH))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0M
                            -> let c_PTB_at0N = ((toVector x_at0M) Data.Vector.Unboxed.! 0)
                               in (p_asZJ * c_PTB_at0N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0O
                            -> let c_NPTB_at0P = ((toVector x_at0O) Data.Vector.Unboxed.! 1)
                               in (p_asZL * c_NPTB_at0P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0Q
                            -> let c_MiRs_at0R = ((toVector x_at0Q) Data.Vector.Unboxed.! 2)
                               in (p_asZN * c_MiRs_at0R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0S
                            -> let c_RESTc_at0T = ((toVector x_at0S) Data.Vector.Unboxed.! 3)
                               in (p_asZP * c_RESTc_at0T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0U
                            -> let
                                 c_EndoNeuroTFs_at0V = ((toVector x_at0U) Data.Vector.Unboxed.! 4)
                               in (p_asZR * c_EndoNeuroTFs_at0V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121235",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121237",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZS
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1y
                            p_asZR = code-0.1.0.0:Genome.FixedList.Functions.double g_asZQ
                            (g_asZQ, gpart_at1y) = Genome.Split.split gpart_at1x
                            p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                            (g_asZO, gpart_at1x) = Genome.Split.split gpart_at1w
                            p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                            (g_asZM, gpart_at1w) = Genome.Split.split gpart_at1v
                            p_asZL = code-0.1.0.0:Genome.FixedList.Functions.double g_asZK
                            (g_asZK, gpart_at1v) = Genome.Split.split gpart_at1u
                            p_asZJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZI
                            (g_asZI, gpart_at1u) = Genome.Split.split gpart_at1t
                            p_asZH = Functions.belowten' g_asZG
                            (g_asZG, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZF = code-0.1.0.0:Genome.FixedList.Functions.double g_asZE
                            (g_asZE, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                            (g_asZC, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                            (g_asZA, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZz = Functions.belowten' g_asZy
                            (g_asZy, gpart_at1p) = Genome.Split.split gpart_at1o
                            p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                            (g_asZw, gpart_at1o) = Genome.Split.split gpart_at1n
                            p_asZv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZu
                            (g_asZu, gpart_at1n) = Genome.Split.split gpart_at1m
                            p_asZt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZs
                            (g_asZs, gpart_at1m) = Genome.Split.split gpart_at1l
                            p_asZr = Functions.belowten' g_asZq
                            (g_asZq, gpart_at1l) = Genome.Split.split gpart_at1k
                            p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                            (g_asZo, gpart_at1k) = Genome.Split.split gpart_at1j
                            p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                            (g_asZm, gpart_at1j) = Genome.Split.split gpart_at1i
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at1i) = Genome.Split.split gpart_at1h
                            p_asZj = Functions.belowten' g_asZi
                            (g_asZi, gpart_at1h) = Genome.Split.split gpart_at1g
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at1g) = Genome.Split.split gpart_at1f
                            p_asZf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZe
                            (g_asZe, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asZd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZc
                            (g_asZc, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                            (g_asZa, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asZ9 = Functions.belowten' g_asZ8
                            (g_asZ8, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                            (g_asZ6, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asZ5 = Functions.belowten' g_asZ4
                            (g_asZ4, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at19) = Genome.Split.split gpart_at18
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at18) = Genome.Split.split gpart_at17
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at17) = Genome.Split.split gpart_at16
                            p_asYX = Functions.belowten' g_asYW
                            (g_asYW, gpart_at16) = Genome.Split.split gpart_at15
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at15) = Genome.Split.split gpart_at14
                            p_asYT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                            (g_asYS, gpart_at14) = Genome.Split.split gpart_at13
                            p_asYR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYQ
                            (g_asYQ, gpart_at13) = Genome.Split.split gpart_at12
                            p_asYP = Functions.belowten' g_asYO
                            (g_asYO, gpart_at12) = Genome.Split.split gpart_at11
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                            (g_asYE, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                            (g_asYC, gpart_at0W) = Genome.Split.split genome_asZS
                          in
                            \ desc_asZT
                              -> case desc_asZT of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZp)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZt)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZv)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZx)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZz)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZB)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZD)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZF)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZH)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZJ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZL)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZN)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZP)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZR)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at3v
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at49
                      p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                      (g_at3t, gpart_at49) = Genome.Split.split gpart_at48
                      p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                      (g_at3r, gpart_at48) = Genome.Split.split gpart_at47
                      p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                      (g_at3p, gpart_at47) = Genome.Split.split gpart_at46
                      p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                      (g_at3n, gpart_at46) = Genome.Split.split gpart_at45
                      p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                      (g_at3l, gpart_at45) = Genome.Split.split gpart_at44
                      p_at3k = Functions.belowten' g_at3j
                      (g_at3j, gpart_at44) = Genome.Split.split gpart_at43
                      p_at3i = code-0.1.0.0:Genome.FixedList.Functions.double g_at3h
                      (g_at3h, gpart_at43) = Genome.Split.split gpart_at42
                      p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                      (g_at3f, gpart_at42) = Genome.Split.split gpart_at41
                      p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                      (g_at3d, gpart_at41) = Genome.Split.split gpart_at40
                      p_at3c = Functions.belowten' g_at3b
                      (g_at3b, gpart_at40) = Genome.Split.split gpart_at3Z
                      p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                      (g_at39, gpart_at3Z) = Genome.Split.split gpart_at3Y
                      p_at38
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at37
                      (g_at37, gpart_at3Y) = Genome.Split.split gpart_at3X
                      p_at36
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at35
                      (g_at35, gpart_at3X) = Genome.Split.split gpart_at3W
                      p_at34 = Functions.belowten' g_at33
                      (g_at33, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                      (g_at31, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                      (g_at2X, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at2W = Functions.belowten' g_at2V
                      (g_at2V, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                      (g_at2T, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at2S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2R
                      (g_at2R, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at2Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2P
                      (g_at2P, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at2M = Functions.belowten' g_at2L
                      (g_at2L, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2I = Functions.belowten' g_at2H
                      (g_at2H, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2A = Functions.belowten' g_at2z
                      (g_at2z, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                      (g_at2v, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                      (g_at2t, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2s = Functions.belowten' g_at2r
                      (g_at2r, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                      (g_at2p, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                      (g_at2l, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3x) = Genome.Split.split genome_at3v
                    in
                      [Reaction
                         (\ x_at4a
                            -> let
                                 c_MiRs_at4d = ((toVector x_at4a) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2o
                                  * ((p_at2C + ((c_RESTc_at4b / p_at2q) ** p_at2s))
                                     / (((1 + p_at2C) + ((c_RESTc_at4b / p_at2q) ** p_at2s))
                                        + (((p_at2g / p_at2u) ** p_at2w)
                                           + ((c_MiRs_at4d / p_at2y) ** p_at2A))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4e
                            -> let
                                 c_MiRs_at4f = ((toVector x_at4e) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4g = ((toVector x_at4e) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2E
                                  / (1
                                     + (((c_MiRs_at4f / p_at2G) ** p_at2I)
                                        + ((c_PTB_at4g / p_at2K) ** p_at2M)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4h
                            -> let c_RESTc_at4i = ((toVector x_at4h) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2O
                                  * (p_at2Y
                                     / ((1 + p_at2Y) + ((c_RESTc_at4i / p_at2U) ** p_at2W)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4j
                            -> let
                                 c_MiRs_at4m = ((toVector x_at4j) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4k = ((toVector x_at4j) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at30
                                  * ((p_at3e + ((c_PTB_at4k / p_at32) ** p_at34))
                                     / (((1 + p_at3e) + ((c_PTB_at4k / p_at32) ** p_at34))
                                        + ((c_MiRs_at4m / p_at3a) ** p_at3c)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4n
                            -> let c_RESTc_at4o = ((toVector x_at4n) Data.Vector.Unboxed.! 3)
                               in (p_at3g / (1 + ((c_RESTc_at4o / p_at3i) ** p_at3k))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4p
                            -> let c_PTB_at4q = ((toVector x_at4p) Data.Vector.Unboxed.! 0)
                               in (p_at3m * c_PTB_at4q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4r
                            -> let c_NPTB_at4s = ((toVector x_at4r) Data.Vector.Unboxed.! 1)
                               in (p_at3o * c_NPTB_at4s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4t
                            -> let c_MiRs_at4u = ((toVector x_at4t) Data.Vector.Unboxed.! 2)
                               in (p_at3q * c_MiRs_at4u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4v
                            -> let c_RESTc_at4w = ((toVector x_at4v) Data.Vector.Unboxed.! 3)
                               in (p_at3s * c_RESTc_at4w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4x
                            -> let
                                 c_EndoNeuroTFs_at4y = ((toVector x_at4x) Data.Vector.Unboxed.! 4)
                               in (p_at3u * c_EndoNeuroTFs_at4y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3v
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5b
                            p_at3u = code-0.1.0.0:Genome.FixedList.Functions.double g_at3t
                            (g_at3t, gpart_at5b) = Genome.Split.split gpart_at5a
                            p_at3s = code-0.1.0.0:Genome.FixedList.Functions.double g_at3r
                            (g_at3r, gpart_at5a) = Genome.Split.split gpart_at59
                            p_at3q = code-0.1.0.0:Genome.FixedList.Functions.double g_at3p
                            (g_at3p, gpart_at59) = Genome.Split.split gpart_at58
                            p_at3o = code-0.1.0.0:Genome.FixedList.Functions.double g_at3n
                            (g_at3n, gpart_at58) = Genome.Split.split gpart_at57
                            p_at3m = code-0.1.0.0:Genome.FixedList.Functions.double g_at3l
                            (g_at3l, gpart_at57) = Genome.Split.split gpart_at56
                            p_at3k = Functions.belowten' g_at3j
                            (g_at3j, gpart_at56) = Genome.Split.split gpart_at55
                            p_at3i = code-0.1.0.0:Genome.FixedList.Functions.double g_at3h
                            (g_at3h, gpart_at55) = Genome.Split.split gpart_at54
                            p_at3g = code-0.1.0.0:Genome.FixedList.Functions.double g_at3f
                            (g_at3f, gpart_at54) = Genome.Split.split gpart_at53
                            p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                            (g_at3d, gpart_at53) = Genome.Split.split gpart_at52
                            p_at3c = Functions.belowten' g_at3b
                            (g_at3b, gpart_at52) = Genome.Split.split gpart_at51
                            p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                            (g_at39, gpart_at51) = Genome.Split.split gpart_at50
                            p_at38
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at37
                            (g_at37, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at36
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at35
                            (g_at35, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at34 = Functions.belowten' g_at33
                            (g_at33, gpart_at4Y) = Genome.Split.split gpart_at4X
                            p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                            (g_at31, gpart_at4X) = Genome.Split.split gpart_at4W
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at4W) = Genome.Split.split gpart_at4V
                            p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                            (g_at2X, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at2W = Functions.belowten' g_at2V
                            (g_at2V, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                            (g_at2T, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at2S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2R
                            (g_at2R, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at2Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2P
                            (g_at2P, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2M = Functions.belowten' g_at2L
                            (g_at2L, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2I = Functions.belowten' g_at2H
                            (g_at2H, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2A = Functions.belowten' g_at2z
                            (g_at2z, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                            (g_at2v, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                            (g_at2t, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2s = Functions.belowten' g_at2r
                            (g_at2r, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                            (g_at2p, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                            (g_at2l, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at4z) = Genome.Split.split genome_at3v
                          in
                            \ desc_at3w
                              -> case desc_at3w of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3g)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3i)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3k)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3m)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3o)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3s)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3u)
                                   _ -> Nothing }}
