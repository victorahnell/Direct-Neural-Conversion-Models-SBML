src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24U0
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UG
                      p_a24TZ = double g_a24TY
                      (g_a24TY, gpart_a24UG) = Genome.Split.split gpart_a24UF
                      p_a24TX = double g_a24TW
                      (g_a24TW, gpart_a24UF) = Genome.Split.split gpart_a24UE
                      p_a24TV = double g_a24TU
                      (g_a24TU, gpart_a24UE) = Genome.Split.split gpart_a24UD
                      p_a24TT = double g_a24TS
                      (g_a24TS, gpart_a24UD) = Genome.Split.split gpart_a24UC
                      p_a24TR = double g_a24TQ
                      (g_a24TQ, gpart_a24UC) = Genome.Split.split gpart_a24UB
                      p_a24TP = double g_a24TO
                      (g_a24TO, gpart_a24UB) = Genome.Split.split gpart_a24UA
                      p_a24TN = Functions.belowten' g_a24TM
                      (g_a24TM, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                      p_a24TL = double g_a24TK
                      (g_a24TK, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                      p_a24TJ = Functions.belowten' g_a24TI
                      (g_a24TI, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                      p_a24TH = double g_a24TG
                      (g_a24TG, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                      p_a24TF = double g_a24TE
                      (g_a24TE, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                      p_a24TD = double g_a24TC
                      (g_a24TC, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                      p_a24TB = Functions.belowten' g_a24TA
                      (g_a24TA, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                      p_a24Tz = double g_a24Ty
                      (g_a24Ty, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                      p_a24Tx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tw
                      (g_a24Tw, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                      p_a24Tv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tu
                      (g_a24Tu, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                      p_a24Tt = Functions.belowten' g_a24Ts
                      (g_a24Ts, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                      p_a24Tr = double g_a24Tq
                      (g_a24Tq, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                      p_a24Tp = Functions.belowten' g_a24To
                      (g_a24To, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                      p_a24Tn = double g_a24Tm
                      (g_a24Tm, gpart_a24Un) = Genome.Split.split gpart_a24Um
                      p_a24Tl = double g_a24Tk
                      (g_a24Tk, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                      p_a24Tj = double g_a24Ti
                      (g_a24Ti, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                      p_a24Th = Functions.belowten' g_a24Tg
                      (g_a24Tg, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                      p_a24Tf = double g_a24Te
                      (g_a24Te, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                      p_a24Td
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tc
                      (g_a24Tc, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                      p_a24Tb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ta
                      (g_a24Ta, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                      p_a24T9 = double g_a24T8
                      (g_a24T8, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                      p_a24T7 = Functions.belowten' g_a24T6
                      (g_a24T6, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                      p_a24T5 = double g_a24T4
                      (g_a24T4, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                      p_a24T3 = Functions.belowten' g_a24T2
                      (g_a24T2, gpart_a24Ud) = Genome.Split.split gpart_a24Uc
                      p_a24T1 = double g_a24T0
                      (g_a24T0, gpart_a24Uc) = Genome.Split.split gpart_a24Ub
                      p_a24SZ = double g_a24SY
                      (g_a24SY, gpart_a24Ub) = Genome.Split.split gpart_a24Ua
                      p_a24SX = Functions.belowten' g_a24SW
                      (g_a24SW, gpart_a24Ua) = Genome.Split.split gpart_a24U9
                      p_a24SV = double g_a24SU
                      (g_a24SU, gpart_a24U9) = Genome.Split.split gpart_a24U8
                      p_a24ST
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SS
                      (g_a24SS, gpart_a24U8) = Genome.Split.split gpart_a24U7
                      p_a24SR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SQ
                      (g_a24SQ, gpart_a24U7) = Genome.Split.split gpart_a24U6
                      p_a24SP = double g_a24SO
                      (g_a24SO, gpart_a24U6) = Genome.Split.split gpart_a24U5
                      p_a24SN = double g_a24SM
                      (g_a24SM, gpart_a24U5) = Genome.Split.split gpart_a24U4
                      p_a24SL = double g_a24SK
                      (g_a24SK, gpart_a24U4) = Genome.Split.split gpart_a24U3
                      p_a24SJ = double g_a24SI
                      (g_a24SI, gpart_a24U3) = Genome.Split.split gpart_a24U2
                      p_a24SH = double g_a24SG
                      (g_a24SG, gpart_a24U2) = Genome.Split.split genome_a24U0
                    in  \ x_a24UH
                          -> let
                               c_PTB_a24UK
                                 = ((Data.Fixed.Vector.toVector x_a24UH) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24UI
                                 = ((Data.Fixed.Vector.toVector x_a24UH) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24UO
                                 = ((Data.Fixed.Vector.toVector x_a24UH) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24UP
                                 = ((Data.Fixed.Vector.toVector x_a24UH) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24V3
                                 = ((Data.Fixed.Vector.toVector x_a24UH) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24SP / (1 + ((c_MiRs_a24UI / p_a24SV) ** p_a24SX)))
                                    + (negate (p_a24TR * c_PTB_a24UK))),
                                   ((p_a24SZ
                                     / (1
                                        + (((c_MiRs_a24UI / p_a24T1) ** p_a24T3)
                                           + ((c_PTB_a24UK / p_a24T5) ** p_a24T7))))
                                    + (negate (p_a24TT * c_NPTB_a24UO))),
                                   ((p_a24T9
                                     * ((p_a24Tj + ((p_a24SL / p_a24Tb) ** p_a24Td))
                                        / (((1 + p_a24Tj) + ((p_a24SL / p_a24Tb) ** p_a24Td))
                                           + ((c_RESTc_a24UP / p_a24Tf) ** p_a24Th))))
                                    + (negate (p_a24TV * c_MiRs_a24UI))),
                                   ((p_a24Tl
                                     * ((p_a24TD
                                         + (((c_NPTB_a24UO / p_a24Tn) ** p_a24Tp)
                                            + ((c_PTB_a24UK / p_a24Tr) ** p_a24Tt)))
                                        / (((1 + p_a24TD)
                                            + (((c_NPTB_a24UO / p_a24Tn) ** p_a24Tp)
                                               + ((c_PTB_a24UK / p_a24Tr) ** p_a24Tt)))
                                           + (((p_a24SH / p_a24Tv) ** p_a24Tx)
                                              + ((c_MiRs_a24UI / p_a24Tz) ** p_a24TB)))))
                                    + (negate (p_a24TX * c_RESTc_a24UP))),
                                   ((p_a24TF
                                     * ((p_a24TP + ((c_MiRs_a24UI / p_a24TH) ** p_a24TJ))
                                        / (((1 + p_a24TP) + ((c_MiRs_a24UI / p_a24TH) ** p_a24TJ))
                                           + ((c_RESTc_a24UP / p_a24TL) ** p_a24TN))))
                                    + (negate (p_a24TZ * c_EndoNeuroTFs_a24V3)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505225",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505227",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505245",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505247",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505265",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505267",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24U0
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24VI
                            p_a24TZ = double g_a24TY
                            (g_a24TY, gpart_a24VI) = Genome.Split.split gpart_a24VH
                            p_a24TX = double g_a24TW
                            (g_a24TW, gpart_a24VH) = Genome.Split.split gpart_a24VG
                            p_a24TV = double g_a24TU
                            (g_a24TU, gpart_a24VG) = Genome.Split.split gpart_a24VF
                            p_a24TT = double g_a24TS
                            (g_a24TS, gpart_a24VF) = Genome.Split.split gpart_a24VE
                            p_a24TR = double g_a24TQ
                            (g_a24TQ, gpart_a24VE) = Genome.Split.split gpart_a24VD
                            p_a24TP = double g_a24TO
                            (g_a24TO, gpart_a24VD) = Genome.Split.split gpart_a24VC
                            p_a24TN = Functions.belowten' g_a24TM
                            (g_a24TM, gpart_a24VC) = Genome.Split.split gpart_a24VB
                            p_a24TL = double g_a24TK
                            (g_a24TK, gpart_a24VB) = Genome.Split.split gpart_a24VA
                            p_a24TJ = Functions.belowten' g_a24TI
                            (g_a24TI, gpart_a24VA) = Genome.Split.split gpart_a24Vz
                            p_a24TH = double g_a24TG
                            (g_a24TG, gpart_a24Vz) = Genome.Split.split gpart_a24Vy
                            p_a24TF = double g_a24TE
                            (g_a24TE, gpart_a24Vy) = Genome.Split.split gpart_a24Vx
                            p_a24TD = double g_a24TC
                            (g_a24TC, gpart_a24Vx) = Genome.Split.split gpart_a24Vw
                            p_a24TB = Functions.belowten' g_a24TA
                            (g_a24TA, gpart_a24Vw) = Genome.Split.split gpart_a24Vv
                            p_a24Tz = double g_a24Ty
                            (g_a24Ty, gpart_a24Vv) = Genome.Split.split gpart_a24Vu
                            p_a24Tx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tw
                            (g_a24Tw, gpart_a24Vu) = Genome.Split.split gpart_a24Vt
                            p_a24Tv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tu
                            (g_a24Tu, gpart_a24Vt) = Genome.Split.split gpart_a24Vs
                            p_a24Tt = Functions.belowten' g_a24Ts
                            (g_a24Ts, gpart_a24Vs) = Genome.Split.split gpart_a24Vr
                            p_a24Tr = double g_a24Tq
                            (g_a24Tq, gpart_a24Vr) = Genome.Split.split gpart_a24Vq
                            p_a24Tp = Functions.belowten' g_a24To
                            (g_a24To, gpart_a24Vq) = Genome.Split.split gpart_a24Vp
                            p_a24Tn = double g_a24Tm
                            (g_a24Tm, gpart_a24Vp) = Genome.Split.split gpart_a24Vo
                            p_a24Tl = double g_a24Tk
                            (g_a24Tk, gpart_a24Vo) = Genome.Split.split gpart_a24Vn
                            p_a24Tj = double g_a24Ti
                            (g_a24Ti, gpart_a24Vn) = Genome.Split.split gpart_a24Vm
                            p_a24Th = Functions.belowten' g_a24Tg
                            (g_a24Tg, gpart_a24Vm) = Genome.Split.split gpart_a24Vl
                            p_a24Tf = double g_a24Te
                            (g_a24Te, gpart_a24Vl) = Genome.Split.split gpart_a24Vk
                            p_a24Td
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tc
                            (g_a24Tc, gpart_a24Vk) = Genome.Split.split gpart_a24Vj
                            p_a24Tb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ta
                            (g_a24Ta, gpart_a24Vj) = Genome.Split.split gpart_a24Vi
                            p_a24T9 = double g_a24T8
                            (g_a24T8, gpart_a24Vi) = Genome.Split.split gpart_a24Vh
                            p_a24T7 = Functions.belowten' g_a24T6
                            (g_a24T6, gpart_a24Vh) = Genome.Split.split gpart_a24Vg
                            p_a24T5 = double g_a24T4
                            (g_a24T4, gpart_a24Vg) = Genome.Split.split gpart_a24Vf
                            p_a24T3 = Functions.belowten' g_a24T2
                            (g_a24T2, gpart_a24Vf) = Genome.Split.split gpart_a24Ve
                            p_a24T1 = double g_a24T0
                            (g_a24T0, gpart_a24Ve) = Genome.Split.split gpart_a24Vd
                            p_a24SZ = double g_a24SY
                            (g_a24SY, gpart_a24Vd) = Genome.Split.split gpart_a24Vc
                            p_a24SX = Functions.belowten' g_a24SW
                            (g_a24SW, gpart_a24Vc) = Genome.Split.split gpart_a24Vb
                            p_a24SV = double g_a24SU
                            (g_a24SU, gpart_a24Vb) = Genome.Split.split gpart_a24Va
                            p_a24ST
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SS
                            (g_a24SS, gpart_a24Va) = Genome.Split.split gpart_a24V9
                            p_a24SR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SQ
                            (g_a24SQ, gpart_a24V9) = Genome.Split.split gpart_a24V8
                            p_a24SP = double g_a24SO
                            (g_a24SO, gpart_a24V8) = Genome.Split.split gpart_a24V7
                            p_a24SN = double g_a24SM
                            (g_a24SM, gpart_a24V7) = Genome.Split.split gpart_a24V6
                            p_a24SL = double g_a24SK
                            (g_a24SK, gpart_a24V6) = Genome.Split.split gpart_a24V5
                            p_a24SJ = double g_a24SI
                            (g_a24SI, gpart_a24V5) = Genome.Split.split gpart_a24V4
                            p_a24SH = double g_a24SG
                            (g_a24SG, gpart_a24V4) = Genome.Split.split genome_a24U0
                          in
                            \ desc_a24U1
                              -> case desc_a24U1 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SH)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SJ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SL)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SN)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SP)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SR)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ST)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SX)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SZ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T1)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T3)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T5)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T7)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T9)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tb)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Td)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tf)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Th)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tj)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tl)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tn)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tp)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tr)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tt)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tv)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tx)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tz)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TB)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TD)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TF)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TH)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TN)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TP)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TR)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TT)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TV)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TX)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TZ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24Yc
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24YS
                      p_a24Yb = double g_a24Ya
                      (g_a24Ya, gpart_a24YS) = Genome.Split.split gpart_a24YR
                      p_a24Y9 = double g_a24Y8
                      (g_a24Y8, gpart_a24YR) = Genome.Split.split gpart_a24YQ
                      p_a24Y7 = double g_a24Y6
                      (g_a24Y6, gpart_a24YQ) = Genome.Split.split gpart_a24YP
                      p_a24Y5 = double g_a24Y4
                      (g_a24Y4, gpart_a24YP) = Genome.Split.split gpart_a24YO
                      p_a24Y3 = double g_a24Y2
                      (g_a24Y2, gpart_a24YO) = Genome.Split.split gpart_a24YN
                      p_a24Y1 = double g_a24Y0
                      (g_a24Y0, gpart_a24YN) = Genome.Split.split gpart_a24YM
                      p_a24XZ = Functions.belowten' g_a24XY
                      (g_a24XY, gpart_a24YM) = Genome.Split.split gpart_a24YL
                      p_a24XX = double g_a24XW
                      (g_a24XW, gpart_a24YL) = Genome.Split.split gpart_a24YK
                      p_a24XV = Functions.belowten' g_a24XU
                      (g_a24XU, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                      p_a24XT = double g_a24XS
                      (g_a24XS, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                      p_a24XR = double g_a24XQ
                      (g_a24XQ, gpart_a24YI) = Genome.Split.split gpart_a24YH
                      p_a24XP = double g_a24XO
                      (g_a24XO, gpart_a24YH) = Genome.Split.split gpart_a24YG
                      p_a24XN = Functions.belowten' g_a24XM
                      (g_a24XM, gpart_a24YG) = Genome.Split.split gpart_a24YF
                      p_a24XL = double g_a24XK
                      (g_a24XK, gpart_a24YF) = Genome.Split.split gpart_a24YE
                      p_a24XJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XI
                      (g_a24XI, gpart_a24YE) = Genome.Split.split gpart_a24YD
                      p_a24XH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XG
                      (g_a24XG, gpart_a24YD) = Genome.Split.split gpart_a24YC
                      p_a24XF = Functions.belowten' g_a24XE
                      (g_a24XE, gpart_a24YC) = Genome.Split.split gpart_a24YB
                      p_a24XD = double g_a24XC
                      (g_a24XC, gpart_a24YB) = Genome.Split.split gpart_a24YA
                      p_a24XB = Functions.belowten' g_a24XA
                      (g_a24XA, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                      p_a24Xz = double g_a24Xy
                      (g_a24Xy, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                      p_a24Xx = double g_a24Xw
                      (g_a24Xw, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                      p_a24Xv = double g_a24Xu
                      (g_a24Xu, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                      p_a24Xt = Functions.belowten' g_a24Xs
                      (g_a24Xs, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                      p_a24Xr = double g_a24Xq
                      (g_a24Xq, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                      p_a24Xp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xo
                      (g_a24Xo, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                      p_a24Xn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xm
                      (g_a24Xm, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                      p_a24Xl = double g_a24Xk
                      (g_a24Xk, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                      p_a24Xj = Functions.belowten' g_a24Xi
                      (g_a24Xi, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                      p_a24Xh = double g_a24Xg
                      (g_a24Xg, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                      p_a24Xf = Functions.belowten' g_a24Xe
                      (g_a24Xe, gpart_a24Yp) = Genome.Split.split gpart_a24Yo
                      p_a24Xd = double g_a24Xc
                      (g_a24Xc, gpart_a24Yo) = Genome.Split.split gpart_a24Yn
                      p_a24Xb = double g_a24Xa
                      (g_a24Xa, gpart_a24Yn) = Genome.Split.split gpart_a24Ym
                      p_a24X9 = Functions.belowten' g_a24X8
                      (g_a24X8, gpart_a24Ym) = Genome.Split.split gpart_a24Yl
                      p_a24X7 = double g_a24X6
                      (g_a24X6, gpart_a24Yl) = Genome.Split.split gpart_a24Yk
                      p_a24X5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24X4
                      (g_a24X4, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                      p_a24X3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24X2
                      (g_a24X2, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                      p_a24X1 = double g_a24X0
                      (g_a24X0, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                      p_a24WZ = double g_a24WY
                      (g_a24WY, gpart_a24Yh) = Genome.Split.split gpart_a24Yg
                      p_a24WX = double g_a24WW
                      (g_a24WW, gpart_a24Yg) = Genome.Split.split gpart_a24Yf
                      p_a24WV = double g_a24WU
                      (g_a24WU, gpart_a24Yf) = Genome.Split.split gpart_a24Ye
                      p_a24WT = double g_a24WS
                      (g_a24WS, gpart_a24Ye) = Genome.Split.split genome_a24Yc
                    in  \ x_a24YT
                          -> let
                               c_PTB_a24YW
                                 = ((Data.Fixed.Vector.toVector x_a24YT) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24YU
                                 = ((Data.Fixed.Vector.toVector x_a24YT) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Z0
                                 = ((Data.Fixed.Vector.toVector x_a24YT) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Z1
                                 = ((Data.Fixed.Vector.toVector x_a24YT) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Zf
                                 = ((Data.Fixed.Vector.toVector x_a24YT) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24X1 / (1 + ((c_MiRs_a24YU / p_a24X7) ** p_a24X9)))
                                    + (negate (p_a24Y3 * c_PTB_a24YW))),
                                   ((p_a24Xb
                                     / (1
                                        + (((c_MiRs_a24YU / p_a24Xd) ** p_a24Xf)
                                           + ((c_PTB_a24YW / p_a24Xh) ** p_a24Xj))))
                                    + (negate (p_a24Y5 * c_NPTB_a24Z0))),
                                   ((p_a24Xl
                                     * (p_a24Xv
                                        / ((1 + p_a24Xv) + ((c_RESTc_a24Z1 / p_a24Xr) ** p_a24Xt))))
                                    + (negate (p_a24Y7 * c_MiRs_a24YU))),
                                   ((p_a24Xx
                                     * ((p_a24XP
                                         + (((c_NPTB_a24Z0 / p_a24Xz) ** p_a24XB)
                                            + ((c_PTB_a24YW / p_a24XD) ** p_a24XF)))
                                        / (((1 + p_a24XP)
                                            + (((c_NPTB_a24Z0 / p_a24Xz) ** p_a24XB)
                                               + ((c_PTB_a24YW / p_a24XD) ** p_a24XF)))
                                           + (((p_a24WT / p_a24XH) ** p_a24XJ)
                                              + ((c_MiRs_a24YU / p_a24XL) ** p_a24XN)))))
                                    + (negate (p_a24Y9 * c_RESTc_a24Z1))),
                                   ((p_a24XR
                                     * ((p_a24Y1 + ((c_MiRs_a24YU / p_a24XT) ** p_a24XV))
                                        / (((1 + p_a24Y1) + ((c_MiRs_a24YU / p_a24XT) ** p_a24XV))
                                           + ((c_RESTc_a24Z1 / p_a24XX) ** p_a24XZ))))
                                    + (negate (p_a24Yb * c_EndoNeuroTFs_a24Zf)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505481",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505483",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505485",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505487",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505505",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505507",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505525",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505527",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Yc
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24ZU
                            p_a24Yb = double g_a24Ya
                            (g_a24Ya, gpart_a24ZU) = Genome.Split.split gpart_a24ZT
                            p_a24Y9 = double g_a24Y8
                            (g_a24Y8, gpart_a24ZT) = Genome.Split.split gpart_a24ZS
                            p_a24Y7 = double g_a24Y6
                            (g_a24Y6, gpart_a24ZS) = Genome.Split.split gpart_a24ZR
                            p_a24Y5 = double g_a24Y4
                            (g_a24Y4, gpart_a24ZR) = Genome.Split.split gpart_a24ZQ
                            p_a24Y3 = double g_a24Y2
                            (g_a24Y2, gpart_a24ZQ) = Genome.Split.split gpart_a24ZP
                            p_a24Y1 = double g_a24Y0
                            (g_a24Y0, gpart_a24ZP) = Genome.Split.split gpart_a24ZO
                            p_a24XZ = Functions.belowten' g_a24XY
                            (g_a24XY, gpart_a24ZO) = Genome.Split.split gpart_a24ZN
                            p_a24XX = double g_a24XW
                            (g_a24XW, gpart_a24ZN) = Genome.Split.split gpart_a24ZM
                            p_a24XV = Functions.belowten' g_a24XU
                            (g_a24XU, gpart_a24ZM) = Genome.Split.split gpart_a24ZL
                            p_a24XT = double g_a24XS
                            (g_a24XS, gpart_a24ZL) = Genome.Split.split gpart_a24ZK
                            p_a24XR = double g_a24XQ
                            (g_a24XQ, gpart_a24ZK) = Genome.Split.split gpart_a24ZJ
                            p_a24XP = double g_a24XO
                            (g_a24XO, gpart_a24ZJ) = Genome.Split.split gpart_a24ZI
                            p_a24XN = Functions.belowten' g_a24XM
                            (g_a24XM, gpart_a24ZI) = Genome.Split.split gpart_a24ZH
                            p_a24XL = double g_a24XK
                            (g_a24XK, gpart_a24ZH) = Genome.Split.split gpart_a24ZG
                            p_a24XJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XI
                            (g_a24XI, gpart_a24ZG) = Genome.Split.split gpart_a24ZF
                            p_a24XH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XG
                            (g_a24XG, gpart_a24ZF) = Genome.Split.split gpart_a24ZE
                            p_a24XF = Functions.belowten' g_a24XE
                            (g_a24XE, gpart_a24ZE) = Genome.Split.split gpart_a24ZD
                            p_a24XD = double g_a24XC
                            (g_a24XC, gpart_a24ZD) = Genome.Split.split gpart_a24ZC
                            p_a24XB = Functions.belowten' g_a24XA
                            (g_a24XA, gpart_a24ZC) = Genome.Split.split gpart_a24ZB
                            p_a24Xz = double g_a24Xy
                            (g_a24Xy, gpart_a24ZB) = Genome.Split.split gpart_a24ZA
                            p_a24Xx = double g_a24Xw
                            (g_a24Xw, gpart_a24ZA) = Genome.Split.split gpart_a24Zz
                            p_a24Xv = double g_a24Xu
                            (g_a24Xu, gpart_a24Zz) = Genome.Split.split gpart_a24Zy
                            p_a24Xt = Functions.belowten' g_a24Xs
                            (g_a24Xs, gpart_a24Zy) = Genome.Split.split gpart_a24Zx
                            p_a24Xr = double g_a24Xq
                            (g_a24Xq, gpart_a24Zx) = Genome.Split.split gpart_a24Zw
                            p_a24Xp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xo
                            (g_a24Xo, gpart_a24Zw) = Genome.Split.split gpart_a24Zv
                            p_a24Xn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xm
                            (g_a24Xm, gpart_a24Zv) = Genome.Split.split gpart_a24Zu
                            p_a24Xl = double g_a24Xk
                            (g_a24Xk, gpart_a24Zu) = Genome.Split.split gpart_a24Zt
                            p_a24Xj = Functions.belowten' g_a24Xi
                            (g_a24Xi, gpart_a24Zt) = Genome.Split.split gpart_a24Zs
                            p_a24Xh = double g_a24Xg
                            (g_a24Xg, gpart_a24Zs) = Genome.Split.split gpart_a24Zr
                            p_a24Xf = Functions.belowten' g_a24Xe
                            (g_a24Xe, gpart_a24Zr) = Genome.Split.split gpart_a24Zq
                            p_a24Xd = double g_a24Xc
                            (g_a24Xc, gpart_a24Zq) = Genome.Split.split gpart_a24Zp
                            p_a24Xb = double g_a24Xa
                            (g_a24Xa, gpart_a24Zp) = Genome.Split.split gpart_a24Zo
                            p_a24X9 = Functions.belowten' g_a24X8
                            (g_a24X8, gpart_a24Zo) = Genome.Split.split gpart_a24Zn
                            p_a24X7 = double g_a24X6
                            (g_a24X6, gpart_a24Zn) = Genome.Split.split gpart_a24Zm
                            p_a24X5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24X4
                            (g_a24X4, gpart_a24Zm) = Genome.Split.split gpart_a24Zl
                            p_a24X3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24X2
                            (g_a24X2, gpart_a24Zl) = Genome.Split.split gpart_a24Zk
                            p_a24X1 = double g_a24X0
                            (g_a24X0, gpart_a24Zk) = Genome.Split.split gpart_a24Zj
                            p_a24WZ = double g_a24WY
                            (g_a24WY, gpart_a24Zj) = Genome.Split.split gpart_a24Zi
                            p_a24WX = double g_a24WW
                            (g_a24WW, gpart_a24Zi) = Genome.Split.split gpart_a24Zh
                            p_a24WV = double g_a24WU
                            (g_a24WU, gpart_a24Zh) = Genome.Split.split gpart_a24Zg
                            p_a24WT = double g_a24WS
                            (g_a24WS, gpart_a24Zg) = Genome.Split.split genome_a24Yc
                          in
                            \ desc_a24Yd
                              -> case desc_a24Yd of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WT)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WV)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WX)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WZ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X1)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X3)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X5)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X7)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X9)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xb)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xd)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xf)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xh)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xj)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xl)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xn)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xp)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xr)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xt)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xv)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xx)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xz)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XB)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XD)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XF)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XH)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XJ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XL)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XN)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XP)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XR)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XT)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XV)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XX)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XZ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y1)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y3)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y5)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y7)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y9)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yb)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a252o
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2534
                      p_a252n = double g_a252m
                      (g_a252m, gpart_a2534) = Genome.Split.split gpart_a2533
                      p_a252l = double g_a252k
                      (g_a252k, gpart_a2533) = Genome.Split.split gpart_a2532
                      p_a252j = double g_a252i
                      (g_a252i, gpart_a2532) = Genome.Split.split gpart_a2531
                      p_a252h = double g_a252g
                      (g_a252g, gpart_a2531) = Genome.Split.split gpart_a2530
                      p_a252f = double g_a252e
                      (g_a252e, gpart_a2530) = Genome.Split.split gpart_a252Z
                      p_a252d = double g_a252c
                      (g_a252c, gpart_a252Z) = Genome.Split.split gpart_a252Y
                      p_a252b = Functions.belowten' g_a252a
                      (g_a252a, gpart_a252Y) = Genome.Split.split gpart_a252X
                      p_a2529 = double g_a2528
                      (g_a2528, gpart_a252X) = Genome.Split.split gpart_a252W
                      p_a2527 = Functions.belowten' g_a2526
                      (g_a2526, gpart_a252W) = Genome.Split.split gpart_a252V
                      p_a2525 = double g_a2524
                      (g_a2524, gpart_a252V) = Genome.Split.split gpart_a252U
                      p_a2523 = double g_a2522
                      (g_a2522, gpart_a252U) = Genome.Split.split gpart_a252T
                      p_a2521 = double g_a2520
                      (g_a2520, gpart_a252T) = Genome.Split.split gpart_a252S
                      p_a251Z = Functions.belowten' g_a251Y
                      (g_a251Y, gpart_a252S) = Genome.Split.split gpart_a252R
                      p_a251X = double g_a251W
                      (g_a251W, gpart_a252R) = Genome.Split.split gpart_a252Q
                      p_a251V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251U
                      (g_a251U, gpart_a252Q) = Genome.Split.split gpart_a252P
                      p_a251T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251S
                      (g_a251S, gpart_a252P) = Genome.Split.split gpart_a252O
                      p_a251R = Functions.belowten' g_a251Q
                      (g_a251Q, gpart_a252O) = Genome.Split.split gpart_a252N
                      p_a251P = double g_a251O
                      (g_a251O, gpart_a252N) = Genome.Split.split gpart_a252M
                      p_a251N = Functions.belowten' g_a251M
                      (g_a251M, gpart_a252M) = Genome.Split.split gpart_a252L
                      p_a251L = double g_a251K
                      (g_a251K, gpart_a252L) = Genome.Split.split gpart_a252K
                      p_a251J = double g_a251I
                      (g_a251I, gpart_a252K) = Genome.Split.split gpart_a252J
                      p_a251H = double g_a251G
                      (g_a251G, gpart_a252J) = Genome.Split.split gpart_a252I
                      p_a251F = Functions.belowten' g_a251E
                      (g_a251E, gpart_a252I) = Genome.Split.split gpart_a252H
                      p_a251D = double g_a251C
                      (g_a251C, gpart_a252H) = Genome.Split.split gpart_a252G
                      p_a251B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251A
                      (g_a251A, gpart_a252G) = Genome.Split.split gpart_a252F
                      p_a251z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251y
                      (g_a251y, gpart_a252F) = Genome.Split.split gpart_a252E
                      p_a251x = double g_a251w
                      (g_a251w, gpart_a252E) = Genome.Split.split gpart_a252D
                      p_a251v = Functions.belowten' g_a251u
                      (g_a251u, gpart_a252D) = Genome.Split.split gpart_a252C
                      p_a251t = double g_a251s
                      (g_a251s, gpart_a252C) = Genome.Split.split gpart_a252B
                      p_a251r = Functions.belowten' g_a251q
                      (g_a251q, gpart_a252B) = Genome.Split.split gpart_a252A
                      p_a251p = double g_a251o
                      (g_a251o, gpart_a252A) = Genome.Split.split gpart_a252z
                      p_a251n = double g_a251m
                      (g_a251m, gpart_a252z) = Genome.Split.split gpart_a252y
                      p_a251l = Functions.belowten' g_a251k
                      (g_a251k, gpart_a252y) = Genome.Split.split gpart_a252x
                      p_a251j = double g_a251i
                      (g_a251i, gpart_a252x) = Genome.Split.split gpart_a252w
                      p_a251h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251g
                      (g_a251g, gpart_a252w) = Genome.Split.split gpart_a252v
                      p_a251f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251e
                      (g_a251e, gpart_a252v) = Genome.Split.split gpart_a252u
                      p_a251d = double g_a251c
                      (g_a251c, gpart_a252u) = Genome.Split.split gpart_a252t
                      p_a251b = double g_a251a
                      (g_a251a, gpart_a252t) = Genome.Split.split gpart_a252s
                      p_a2519 = double g_a2518
                      (g_a2518, gpart_a252s) = Genome.Split.split gpart_a252r
                      p_a2517 = double g_a2516
                      (g_a2516, gpart_a252r) = Genome.Split.split gpart_a252q
                      p_a2515 = double g_a2514
                      (g_a2514, gpart_a252q) = Genome.Split.split genome_a252o
                    in  \ x_a2535
                          -> let
                               c_PTB_a2538
                                 = ((Data.Fixed.Vector.toVector x_a2535) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2536
                                 = ((Data.Fixed.Vector.toVector x_a2535) Data.Vector.Unboxed.! 2)
                               c_NPTB_a253c
                                 = ((Data.Fixed.Vector.toVector x_a2535) Data.Vector.Unboxed.! 1)
                               c_RESTc_a253d
                                 = ((Data.Fixed.Vector.toVector x_a2535) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a253r
                                 = ((Data.Fixed.Vector.toVector x_a2535) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a251d / (1 + ((c_MiRs_a2536 / p_a251j) ** p_a251l)))
                                    + (negate (p_a252f * c_PTB_a2538))),
                                   ((p_a251n
                                     / (1
                                        + (((c_MiRs_a2536 / p_a251p) ** p_a251r)
                                           + ((c_PTB_a2538 / p_a251t) ** p_a251v))))
                                    + (negate (p_a252h * c_NPTB_a253c))),
                                   ((p_a251x
                                     * (p_a251H
                                        / ((1 + p_a251H) + ((c_RESTc_a253d / p_a251D) ** p_a251F))))
                                    + (negate (p_a252j * c_MiRs_a2536))),
                                   ((p_a251J
                                     * ((p_a2521
                                         + (((c_NPTB_a253c / p_a251L) ** p_a251N)
                                            + ((c_PTB_a2538 / p_a251P) ** p_a251R)))
                                        / (((1 + p_a2521)
                                            + (((c_NPTB_a253c / p_a251L) ** p_a251N)
                                               + ((c_PTB_a2538 / p_a251P) ** p_a251R)))
                                           + ((c_MiRs_a2536 / p_a251X) ** p_a251Z))))
                                    + (negate (p_a252l * c_RESTc_a253d))),
                                   ((p_a2523
                                     * ((p_a252d + ((c_MiRs_a2536 / p_a2525) ** p_a2527))
                                        / (((1 + p_a252d) + ((c_MiRs_a2536 / p_a2525) ** p_a2527))
                                           + ((c_RESTc_a253d / p_a2529) ** p_a252b))))
                                    + (negate (p_a252n * c_EndoNeuroTFs_a253r)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505745",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505747",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505765",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505767",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505785",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505787",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a252o
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2546
                            p_a252n = double g_a252m
                            (g_a252m, gpart_a2546) = Genome.Split.split gpart_a2545
                            p_a252l = double g_a252k
                            (g_a252k, gpart_a2545) = Genome.Split.split gpart_a2544
                            p_a252j = double g_a252i
                            (g_a252i, gpart_a2544) = Genome.Split.split gpart_a2543
                            p_a252h = double g_a252g
                            (g_a252g, gpart_a2543) = Genome.Split.split gpart_a2542
                            p_a252f = double g_a252e
                            (g_a252e, gpart_a2542) = Genome.Split.split gpart_a2541
                            p_a252d = double g_a252c
                            (g_a252c, gpart_a2541) = Genome.Split.split gpart_a2540
                            p_a252b = Functions.belowten' g_a252a
                            (g_a252a, gpart_a2540) = Genome.Split.split gpart_a253Z
                            p_a2529 = double g_a2528
                            (g_a2528, gpart_a253Z) = Genome.Split.split gpart_a253Y
                            p_a2527 = Functions.belowten' g_a2526
                            (g_a2526, gpart_a253Y) = Genome.Split.split gpart_a253X
                            p_a2525 = double g_a2524
                            (g_a2524, gpart_a253X) = Genome.Split.split gpart_a253W
                            p_a2523 = double g_a2522
                            (g_a2522, gpart_a253W) = Genome.Split.split gpart_a253V
                            p_a2521 = double g_a2520
                            (g_a2520, gpart_a253V) = Genome.Split.split gpart_a253U
                            p_a251Z = Functions.belowten' g_a251Y
                            (g_a251Y, gpart_a253U) = Genome.Split.split gpart_a253T
                            p_a251X = double g_a251W
                            (g_a251W, gpart_a253T) = Genome.Split.split gpart_a253S
                            p_a251V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251U
                            (g_a251U, gpart_a253S) = Genome.Split.split gpart_a253R
                            p_a251T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251S
                            (g_a251S, gpart_a253R) = Genome.Split.split gpart_a253Q
                            p_a251R = Functions.belowten' g_a251Q
                            (g_a251Q, gpart_a253Q) = Genome.Split.split gpart_a253P
                            p_a251P = double g_a251O
                            (g_a251O, gpart_a253P) = Genome.Split.split gpart_a253O
                            p_a251N = Functions.belowten' g_a251M
                            (g_a251M, gpart_a253O) = Genome.Split.split gpart_a253N
                            p_a251L = double g_a251K
                            (g_a251K, gpart_a253N) = Genome.Split.split gpart_a253M
                            p_a251J = double g_a251I
                            (g_a251I, gpart_a253M) = Genome.Split.split gpart_a253L
                            p_a251H = double g_a251G
                            (g_a251G, gpart_a253L) = Genome.Split.split gpart_a253K
                            p_a251F = Functions.belowten' g_a251E
                            (g_a251E, gpart_a253K) = Genome.Split.split gpart_a253J
                            p_a251D = double g_a251C
                            (g_a251C, gpart_a253J) = Genome.Split.split gpart_a253I
                            p_a251B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251A
                            (g_a251A, gpart_a253I) = Genome.Split.split gpart_a253H
                            p_a251z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251y
                            (g_a251y, gpart_a253H) = Genome.Split.split gpart_a253G
                            p_a251x = double g_a251w
                            (g_a251w, gpart_a253G) = Genome.Split.split gpart_a253F
                            p_a251v = Functions.belowten' g_a251u
                            (g_a251u, gpart_a253F) = Genome.Split.split gpart_a253E
                            p_a251t = double g_a251s
                            (g_a251s, gpart_a253E) = Genome.Split.split gpart_a253D
                            p_a251r = Functions.belowten' g_a251q
                            (g_a251q, gpart_a253D) = Genome.Split.split gpart_a253C
                            p_a251p = double g_a251o
                            (g_a251o, gpart_a253C) = Genome.Split.split gpart_a253B
                            p_a251n = double g_a251m
                            (g_a251m, gpart_a253B) = Genome.Split.split gpart_a253A
                            p_a251l = Functions.belowten' g_a251k
                            (g_a251k, gpart_a253A) = Genome.Split.split gpart_a253z
                            p_a251j = double g_a251i
                            (g_a251i, gpart_a253z) = Genome.Split.split gpart_a253y
                            p_a251h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251g
                            (g_a251g, gpart_a253y) = Genome.Split.split gpart_a253x
                            p_a251f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251e
                            (g_a251e, gpart_a253x) = Genome.Split.split gpart_a253w
                            p_a251d = double g_a251c
                            (g_a251c, gpart_a253w) = Genome.Split.split gpart_a253v
                            p_a251b = double g_a251a
                            (g_a251a, gpart_a253v) = Genome.Split.split gpart_a253u
                            p_a2519 = double g_a2518
                            (g_a2518, gpart_a253u) = Genome.Split.split gpart_a253t
                            p_a2517 = double g_a2516
                            (g_a2516, gpart_a253t) = Genome.Split.split gpart_a253s
                            p_a2515 = double g_a2514
                            (g_a2514, gpart_a253s) = Genome.Split.split genome_a252o
                          in
                            \ desc_a252p
                              -> case desc_a252p of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2515)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2517)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2519)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251b)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251d)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251f)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251h)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251j)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251l)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251n)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251p)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251r)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251t)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251v)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251x)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251z)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251B)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251D)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251F)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251H)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251J)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251L)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251N)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251P)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251R)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251T)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251V)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251X)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251Z)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2521)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2523)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2525)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2527)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2529)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252b)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252d)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252f)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252h)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252j)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252l)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252n)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a256A
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a257g
                      p_a256z = double g_a256y
                      (g_a256y, gpart_a257g) = Genome.Split.split gpart_a257f
                      p_a256x = double g_a256w
                      (g_a256w, gpart_a257f) = Genome.Split.split gpart_a257e
                      p_a256v = double g_a256u
                      (g_a256u, gpart_a257e) = Genome.Split.split gpart_a257d
                      p_a256t = double g_a256s
                      (g_a256s, gpart_a257d) = Genome.Split.split gpart_a257c
                      p_a256r = double g_a256q
                      (g_a256q, gpart_a257c) = Genome.Split.split gpart_a257b
                      p_a256p = double g_a256o
                      (g_a256o, gpart_a257b) = Genome.Split.split gpart_a257a
                      p_a256n = Functions.belowten' g_a256m
                      (g_a256m, gpart_a257a) = Genome.Split.split gpart_a2579
                      p_a256l = double g_a256k
                      (g_a256k, gpart_a2579) = Genome.Split.split gpart_a2578
                      p_a256j = Functions.belowten' g_a256i
                      (g_a256i, gpart_a2578) = Genome.Split.split gpart_a2577
                      p_a256h = double g_a256g
                      (g_a256g, gpart_a2577) = Genome.Split.split gpart_a2576
                      p_a256f = double g_a256e
                      (g_a256e, gpart_a2576) = Genome.Split.split gpart_a2575
                      p_a256d = double g_a256c
                      (g_a256c, gpart_a2575) = Genome.Split.split gpart_a2574
                      p_a256b = Functions.belowten' g_a256a
                      (g_a256a, gpart_a2574) = Genome.Split.split gpart_a2573
                      p_a2569 = double g_a2568
                      (g_a2568, gpart_a2573) = Genome.Split.split gpart_a2572
                      p_a2567
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2566
                      (g_a2566, gpart_a2572) = Genome.Split.split gpart_a2571
                      p_a2565
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2564
                      (g_a2564, gpart_a2571) = Genome.Split.split gpart_a2570
                      p_a2563 = Functions.belowten' g_a2562
                      (g_a2562, gpart_a2570) = Genome.Split.split gpart_a256Z
                      p_a2561 = double g_a2560
                      (g_a2560, gpart_a256Z) = Genome.Split.split gpart_a256Y
                      p_a255Z = Functions.belowten' g_a255Y
                      (g_a255Y, gpart_a256Y) = Genome.Split.split gpart_a256X
                      p_a255X = double g_a255W
                      (g_a255W, gpart_a256X) = Genome.Split.split gpart_a256W
                      p_a255V = double g_a255U
                      (g_a255U, gpart_a256W) = Genome.Split.split gpart_a256V
                      p_a255T = double g_a255S
                      (g_a255S, gpart_a256V) = Genome.Split.split gpart_a256U
                      p_a255R = Functions.belowten' g_a255Q
                      (g_a255Q, gpart_a256U) = Genome.Split.split gpart_a256T
                      p_a255P = double g_a255O
                      (g_a255O, gpart_a256T) = Genome.Split.split gpart_a256S
                      p_a255N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255M
                      (g_a255M, gpart_a256S) = Genome.Split.split gpart_a256R
                      p_a255L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255K
                      (g_a255K, gpart_a256R) = Genome.Split.split gpart_a256Q
                      p_a255J = double g_a255I
                      (g_a255I, gpart_a256Q) = Genome.Split.split gpart_a256P
                      p_a255H = Functions.belowten' g_a255G
                      (g_a255G, gpart_a256P) = Genome.Split.split gpart_a256O
                      p_a255F = double g_a255E
                      (g_a255E, gpart_a256O) = Genome.Split.split gpart_a256N
                      p_a255D = Functions.belowten' g_a255C
                      (g_a255C, gpart_a256N) = Genome.Split.split gpart_a256M
                      p_a255B = double g_a255A
                      (g_a255A, gpart_a256M) = Genome.Split.split gpart_a256L
                      p_a255z = double g_a255y
                      (g_a255y, gpart_a256L) = Genome.Split.split gpart_a256K
                      p_a255x = Functions.belowten' g_a255w
                      (g_a255w, gpart_a256K) = Genome.Split.split gpart_a256J
                      p_a255v = double g_a255u
                      (g_a255u, gpart_a256J) = Genome.Split.split gpart_a256I
                      p_a255t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255s
                      (g_a255s, gpart_a256I) = Genome.Split.split gpart_a256H
                      p_a255r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255q
                      (g_a255q, gpart_a256H) = Genome.Split.split gpart_a256G
                      p_a255p = double g_a255o
                      (g_a255o, gpart_a256G) = Genome.Split.split gpart_a256F
                      p_a255n = double g_a255m
                      (g_a255m, gpart_a256F) = Genome.Split.split gpart_a256E
                      p_a255l = double g_a255k
                      (g_a255k, gpart_a256E) = Genome.Split.split gpart_a256D
                      p_a255j = double g_a255i
                      (g_a255i, gpart_a256D) = Genome.Split.split gpart_a256C
                      p_a255h = double g_a255g
                      (g_a255g, gpart_a256C) = Genome.Split.split genome_a256A
                    in  \ x_a257h
                          -> let
                               c_PTB_a257k
                                 = ((Data.Fixed.Vector.toVector x_a257h) Data.Vector.Unboxed.! 0)
                               c_MiRs_a257i
                                 = ((Data.Fixed.Vector.toVector x_a257h) Data.Vector.Unboxed.! 2)
                               c_NPTB_a257o
                                 = ((Data.Fixed.Vector.toVector x_a257h) Data.Vector.Unboxed.! 1)
                               c_RESTc_a257p
                                 = ((Data.Fixed.Vector.toVector x_a257h) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a257D
                                 = ((Data.Fixed.Vector.toVector x_a257h) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a255p
                                     / (1
                                        + (((p_a255h / p_a255r) ** p_a255t)
                                           + ((c_MiRs_a257i / p_a255v) ** p_a255x))))
                                    + (negate (p_a256r * c_PTB_a257k))),
                                   ((p_a255z
                                     / (1
                                        + (((c_MiRs_a257i / p_a255B) ** p_a255D)
                                           + ((c_PTB_a257k / p_a255F) ** p_a255H))))
                                    + (negate (p_a256t * c_NPTB_a257o))),
                                   ((p_a255J
                                     * (p_a255T
                                        / ((1 + p_a255T) + ((c_RESTc_a257p / p_a255P) ** p_a255R))))
                                    + (negate (p_a256v * c_MiRs_a257i))),
                                   ((p_a255V
                                     * ((p_a256d
                                         + (((c_NPTB_a257o / p_a255X) ** p_a255Z)
                                            + ((c_PTB_a257k / p_a2561) ** p_a2563)))
                                        / (((1 + p_a256d)
                                            + (((c_NPTB_a257o / p_a255X) ** p_a255Z)
                                               + ((c_PTB_a257k / p_a2561) ** p_a2563)))
                                           + ((c_MiRs_a257i / p_a2569) ** p_a256b))))
                                    + (negate (p_a256x * c_RESTc_a257p))),
                                   ((p_a256f
                                     * ((p_a256p + ((c_MiRs_a257i / p_a256h) ** p_a256j))
                                        / (((1 + p_a256p) + ((c_MiRs_a257i / p_a256h) ** p_a256j))
                                           + ((c_RESTc_a257p / p_a256l) ** p_a256n))))
                                    + (negate (p_a256z * c_EndoNeuroTFs_a257D)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505999",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506001",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506005",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506007",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506025",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506027",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506045",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506047",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a256A
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a258i
                            p_a256z = double g_a256y
                            (g_a256y, gpart_a258i) = Genome.Split.split gpart_a258h
                            p_a256x = double g_a256w
                            (g_a256w, gpart_a258h) = Genome.Split.split gpart_a258g
                            p_a256v = double g_a256u
                            (g_a256u, gpart_a258g) = Genome.Split.split gpart_a258f
                            p_a256t = double g_a256s
                            (g_a256s, gpart_a258f) = Genome.Split.split gpart_a258e
                            p_a256r = double g_a256q
                            (g_a256q, gpart_a258e) = Genome.Split.split gpart_a258d
                            p_a256p = double g_a256o
                            (g_a256o, gpart_a258d) = Genome.Split.split gpart_a258c
                            p_a256n = Functions.belowten' g_a256m
                            (g_a256m, gpart_a258c) = Genome.Split.split gpart_a258b
                            p_a256l = double g_a256k
                            (g_a256k, gpart_a258b) = Genome.Split.split gpart_a258a
                            p_a256j = Functions.belowten' g_a256i
                            (g_a256i, gpart_a258a) = Genome.Split.split gpart_a2589
                            p_a256h = double g_a256g
                            (g_a256g, gpart_a2589) = Genome.Split.split gpart_a2588
                            p_a256f = double g_a256e
                            (g_a256e, gpart_a2588) = Genome.Split.split gpart_a2587
                            p_a256d = double g_a256c
                            (g_a256c, gpart_a2587) = Genome.Split.split gpart_a2586
                            p_a256b = Functions.belowten' g_a256a
                            (g_a256a, gpart_a2586) = Genome.Split.split gpart_a2585
                            p_a2569 = double g_a2568
                            (g_a2568, gpart_a2585) = Genome.Split.split gpart_a2584
                            p_a2567
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2566
                            (g_a2566, gpart_a2584) = Genome.Split.split gpart_a2583
                            p_a2565
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2564
                            (g_a2564, gpart_a2583) = Genome.Split.split gpart_a2582
                            p_a2563 = Functions.belowten' g_a2562
                            (g_a2562, gpart_a2582) = Genome.Split.split gpart_a2581
                            p_a2561 = double g_a2560
                            (g_a2560, gpart_a2581) = Genome.Split.split gpart_a2580
                            p_a255Z = Functions.belowten' g_a255Y
                            (g_a255Y, gpart_a2580) = Genome.Split.split gpart_a257Z
                            p_a255X = double g_a255W
                            (g_a255W, gpart_a257Z) = Genome.Split.split gpart_a257Y
                            p_a255V = double g_a255U
                            (g_a255U, gpart_a257Y) = Genome.Split.split gpart_a257X
                            p_a255T = double g_a255S
                            (g_a255S, gpart_a257X) = Genome.Split.split gpart_a257W
                            p_a255R = Functions.belowten' g_a255Q
                            (g_a255Q, gpart_a257W) = Genome.Split.split gpart_a257V
                            p_a255P = double g_a255O
                            (g_a255O, gpart_a257V) = Genome.Split.split gpart_a257U
                            p_a255N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255M
                            (g_a255M, gpart_a257U) = Genome.Split.split gpart_a257T
                            p_a255L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255K
                            (g_a255K, gpart_a257T) = Genome.Split.split gpart_a257S
                            p_a255J = double g_a255I
                            (g_a255I, gpart_a257S) = Genome.Split.split gpart_a257R
                            p_a255H = Functions.belowten' g_a255G
                            (g_a255G, gpart_a257R) = Genome.Split.split gpart_a257Q
                            p_a255F = double g_a255E
                            (g_a255E, gpart_a257Q) = Genome.Split.split gpart_a257P
                            p_a255D = Functions.belowten' g_a255C
                            (g_a255C, gpart_a257P) = Genome.Split.split gpart_a257O
                            p_a255B = double g_a255A
                            (g_a255A, gpart_a257O) = Genome.Split.split gpart_a257N
                            p_a255z = double g_a255y
                            (g_a255y, gpart_a257N) = Genome.Split.split gpart_a257M
                            p_a255x = Functions.belowten' g_a255w
                            (g_a255w, gpart_a257M) = Genome.Split.split gpart_a257L
                            p_a255v = double g_a255u
                            (g_a255u, gpart_a257L) = Genome.Split.split gpart_a257K
                            p_a255t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255s
                            (g_a255s, gpart_a257K) = Genome.Split.split gpart_a257J
                            p_a255r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a255q
                            (g_a255q, gpart_a257J) = Genome.Split.split gpart_a257I
                            p_a255p = double g_a255o
                            (g_a255o, gpart_a257I) = Genome.Split.split gpart_a257H
                            p_a255n = double g_a255m
                            (g_a255m, gpart_a257H) = Genome.Split.split gpart_a257G
                            p_a255l = double g_a255k
                            (g_a255k, gpart_a257G) = Genome.Split.split gpart_a257F
                            p_a255j = double g_a255i
                            (g_a255i, gpart_a257F) = Genome.Split.split gpart_a257E
                            p_a255h = double g_a255g
                            (g_a255g, gpart_a257E) = Genome.Split.split genome_a256A
                          in
                            \ desc_a256B
                              -> case desc_a256B of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255h)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255j)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255l)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255n)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255p)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255r)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255t)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255v)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255x)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255z)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255B)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255D)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255F)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255H)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255J)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255L)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255N)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255P)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255R)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255T)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255V)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255X)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255Z)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2561)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2563)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2565)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2567)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2569)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256b)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256d)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256f)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256h)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256j)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256l)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256n)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256p)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256r)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256t)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256v)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256x)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a256z)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWh
                      p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                      (g_asVz, gpart_asWh) = Genome.Split.split gpart_asWg
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWg) = Genome.Split.split gpart_asWf
                      p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                      (g_asVv, gpart_asWf) = Genome.Split.split gpart_asWe
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWe) = Genome.Split.split gpart_asWd
                      p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                      (g_asVr, gpart_asWd) = Genome.Split.split gpart_asWc
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWc) = Genome.Split.split gpart_asWb
                      p_asVo = Functions.belowten' g_asVn
                      (g_asVn, gpart_asWb) = Genome.Split.split gpart_asWa
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                      (g_asVf, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                      (g_asVd, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asVc = Functions.belowten' g_asVb
                      (g_asVb, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asV8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV7
                      (g_asV7, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asV6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                      (g_asV5, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asV4 = Functions.belowten' g_asV3
                      (g_asV3, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asV0 = Functions.belowten' g_asUZ
                      (g_asUZ, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                      (g_asUT, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUS = Functions.belowten' g_asUR
                      (g_asUR, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUP
                      (g_asUP, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                      (g_asUN, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUL
                      (g_asUL, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                      (g_asUJ, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUI = Functions.belowten' g_asUH
                      (g_asUH, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                      (g_asUF, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUE = Functions.belowten' g_asUD
                      (g_asUD, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                      (g_asUB, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                      (g_asUz, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUy = Functions.belowten' g_asUx
                      (g_asUx, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUt
                      (g_asUt, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUr
                      (g_asUr, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                      (g_asUp, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                      (g_asUn, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                      (g_asUl, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                      (g_asUh, gpart_asVD) = Genome.Split.split genome_asVB
                    in
                      [Reaction
                         (\ x_asWi
                            -> let c_MiRs_asWj = ((toVector x_asWi) Data.Vector.Unboxed.! 2)
                               in (p_asUq / (1 + ((c_MiRs_asWj / p_asUw) ** p_asUy))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWk
                            -> let
                                 c_MiRs_asWl = ((toVector x_asWk) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWm = ((toVector x_asWk) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUA
                                  / (1
                                     + (((c_MiRs_asWl / p_asUC) ** p_asUE)
                                        + ((c_PTB_asWm / p_asUG) ** p_asUI)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWn
                            -> let c_RESTc_asWo = ((toVector x_asWn) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUK
                                  * ((p_asUU + ((p_asUm / p_asUM) ** p_asUO))
                                     / (((1 + p_asUU) + ((p_asUm / p_asUM) ** p_asUO))
                                        + ((c_RESTc_asWo / p_asUQ) ** p_asUS)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWp
                            -> let
                                 c_MiRs_asWu = ((toVector x_asWp) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWr = ((toVector x_asWp) Data.Vector.Unboxed.! 0)
                                 c_NPTB_asWq = ((toVector x_asWp) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUW
                                  * ((p_asVe
                                      + (((c_NPTB_asWq / p_asUY) ** p_asV0)
                                         + ((c_PTB_asWr / p_asV2) ** p_asV4)))
                                     / (((1 + p_asVe)
                                         + (((c_NPTB_asWq / p_asUY) ** p_asV0)
                                            + ((c_PTB_asWr / p_asV2) ** p_asV4)))
                                        + (((p_asUi / p_asV6) ** p_asV8)
                                           + ((c_MiRs_asWu / p_asVa) ** p_asVc))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWv
                            -> let
                                 c_RESTc_asWy = ((toVector x_asWv) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWw = ((toVector x_asWv) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asVg
                                  * ((p_asVq + ((c_MiRs_asWw / p_asVi) ** p_asVk))
                                     / (((1 + p_asVq) + ((c_MiRs_asWw / p_asVi) ** p_asVk))
                                        + ((c_RESTc_asWy / p_asVm) ** p_asVo)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWz
                            -> let c_PTB_asWA = ((toVector x_asWz) Data.Vector.Unboxed.! 0)
                               in (p_asVs * c_PTB_asWA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWB
                            -> let c_NPTB_asWC = ((toVector x_asWB) Data.Vector.Unboxed.! 1)
                               in (p_asVu * c_NPTB_asWC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWD
                            -> let c_MiRs_asWE = ((toVector x_asWD) Data.Vector.Unboxed.! 2)
                               in (p_asVw * c_MiRs_asWE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWF
                            -> let c_RESTc_asWG = ((toVector x_asWF) Data.Vector.Unboxed.! 3)
                               in (p_asVy * c_RESTc_asWG))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWH
                            -> let
                                 c_EndoNeuroTFs_asWI = ((toVector x_asWH) Data.Vector.Unboxed.! 4)
                               in (p_asVA * c_EndoNeuroTFs_asWI))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXs
                            p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                            (g_asVz, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                            (g_asVv, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                            (g_asVr, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asVo = Functions.belowten' g_asVn
                            (g_asVn, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                            (g_asVf, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                            (g_asVd, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asVc = Functions.belowten' g_asVb
                            (g_asVb, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asV8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV7
                            (g_asV7, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asV6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                            (g_asV5, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asV4 = Functions.belowten' g_asV3
                            (g_asV3, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asV0 = Functions.belowten' g_asUZ
                            (g_asUZ, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                            (g_asUT, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUS = Functions.belowten' g_asUR
                            (g_asUR, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUP
                            (g_asUP, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                            (g_asUN, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUL
                            (g_asUL, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                            (g_asUJ, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUI = Functions.belowten' g_asUH
                            (g_asUH, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                            (g_asUF, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUE = Functions.belowten' g_asUD
                            (g_asUD, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                            (g_asUB, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                            (g_asUz, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUy = Functions.belowten' g_asUx
                            (g_asUx, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUt
                            (g_asUt, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUr
                            (g_asUr, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                            (g_asUp, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                            (g_asUn, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                            (g_asUl, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                            (g_asUh, gpart_asWO) = Genome.Split.split genome_asVB
                          in
                            \ desc_asVC
                              -> case desc_asVC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZt
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at09
                      p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                      (g_asZr, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                      (g_asZp, gpart_at08) = Genome.Split.split gpart_at07
                      p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                      (g_asZn, gpart_at07) = Genome.Split.split gpart_at06
                      p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                      (g_asZl, gpart_at06) = Genome.Split.split gpart_at05
                      p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                      (g_asZj, gpart_at05) = Genome.Split.split gpart_at04
                      p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                      (g_asZh, gpart_at04) = Genome.Split.split gpart_at03
                      p_asZg = Functions.belowten' g_asZf
                      (g_asZf, gpart_at03) = Genome.Split.split gpart_at02
                      p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                      (g_asZd, gpart_at02) = Genome.Split.split gpart_at01
                      p_asZc = Functions.belowten' g_asZb
                      (g_asZb, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                      (g_asZ7, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZ4 = Functions.belowten' g_asZ3
                      (g_asZ3, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                      (g_asZ1, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asZ0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYZ
                      (g_asYZ, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYX
                      (g_asYX, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYW = Functions.belowten' g_asYV
                      (g_asYV, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                      (g_asYT, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYS = Functions.belowten' g_asYR
                      (g_asYR, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                      (g_asYP, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                      (g_asYL, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYK = Functions.belowten' g_asYJ
                      (g_asYJ, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYF
                      (g_asYF, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYD
                      (g_asYD, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYA = Functions.belowten' g_asYz
                      (g_asYz, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYw = Functions.belowten' g_asYv
                      (g_asYv, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                      (g_asYr, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYq = Functions.belowten' g_asYp
                      (g_asYp, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                      (g_asYn, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYl
                      (g_asYl, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                      (g_asYj, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                      (g_asYh, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                      (g_asYf, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                      (g_asYd, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asZv) = Genome.Split.split genome_asZt
                    in
                      [Reaction
                         (\ x_at0a
                            -> let c_MiRs_at0b = ((toVector x_at0a) Data.Vector.Unboxed.! 2)
                               in (p_asYi / (1 + ((c_MiRs_at0b / p_asYo) ** p_asYq))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0c
                            -> let
                                 c_MiRs_at0d = ((toVector x_at0c) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0e = ((toVector x_at0c) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYs
                                  / (1
                                     + (((c_MiRs_at0d / p_asYu) ** p_asYw)
                                        + ((c_PTB_at0e / p_asYy) ** p_asYA)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0f
                            -> let c_RESTc_at0g = ((toVector x_at0f) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYC
                                  * (p_asYM
                                     / ((1 + p_asYM) + ((c_RESTc_at0g / p_asYI) ** p_asYK)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0h
                            -> let
                                 c_MiRs_at0m = ((toVector x_at0h) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0j = ((toVector x_at0h) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at0i = ((toVector x_at0h) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYO
                                  * ((p_asZ6
                                      + (((c_NPTB_at0i / p_asYQ) ** p_asYS)
                                         + ((c_PTB_at0j / p_asYU) ** p_asYW)))
                                     / (((1 + p_asZ6)
                                         + (((c_NPTB_at0i / p_asYQ) ** p_asYS)
                                            + ((c_PTB_at0j / p_asYU) ** p_asYW)))
                                        + (((p_asYa / p_asYY) ** p_asZ0)
                                           + ((c_MiRs_at0m / p_asZ2) ** p_asZ4))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0n
                            -> let
                                 c_RESTc_at0q = ((toVector x_at0n) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0o = ((toVector x_at0n) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZ8
                                  * ((p_asZi + ((c_MiRs_at0o / p_asZa) ** p_asZc))
                                     / (((1 + p_asZi) + ((c_MiRs_at0o / p_asZa) ** p_asZc))
                                        + ((c_RESTc_at0q / p_asZe) ** p_asZg)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0r
                            -> let c_PTB_at0s = ((toVector x_at0r) Data.Vector.Unboxed.! 0)
                               in (p_asZk * c_PTB_at0s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0t
                            -> let c_NPTB_at0u = ((toVector x_at0t) Data.Vector.Unboxed.! 1)
                               in (p_asZm * c_NPTB_at0u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0v
                            -> let c_MiRs_at0w = ((toVector x_at0v) Data.Vector.Unboxed.! 2)
                               in (p_asZo * c_MiRs_at0w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0x
                            -> let c_RESTc_at0y = ((toVector x_at0x) Data.Vector.Unboxed.! 3)
                               in (p_asZq * c_RESTc_at0y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0z
                            -> let
                                 c_EndoNeuroTFs_at0A = ((toVector x_at0z) Data.Vector.Unboxed.! 4)
                               in (p_asZs * c_EndoNeuroTFs_at0A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZt
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1f
                            p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                            (g_asZr, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asZq = code-0.1.0.0:Genome.FixedList.Functions.double g_asZp
                            (g_asZp, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                            (g_asZn, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                            (g_asZl, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                            (g_asZj, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                            (g_asZh, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asZg = Functions.belowten' g_asZf
                            (g_asZf, gpart_at19) = Genome.Split.split gpart_at18
                            p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                            (g_asZd, gpart_at18) = Genome.Split.split gpart_at17
                            p_asZc = Functions.belowten' g_asZb
                            (g_asZb, gpart_at17) = Genome.Split.split gpart_at16
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                            (g_asZ7, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at14) = Genome.Split.split gpart_at13
                            p_asZ4 = Functions.belowten' g_asZ3
                            (g_asZ3, gpart_at13) = Genome.Split.split gpart_at12
                            p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                            (g_asZ1, gpart_at12) = Genome.Split.split gpart_at11
                            p_asZ0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYZ
                            (g_asYZ, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYX
                            (g_asYX, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYW = Functions.belowten' g_asYV
                            (g_asYV, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                            (g_asYT, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYS = Functions.belowten' g_asYR
                            (g_asYR, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                            (g_asYP, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                            (g_asYL, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYK = Functions.belowten' g_asYJ
                            (g_asYJ, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYF
                            (g_asYF, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYD
                            (g_asYD, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYA = Functions.belowten' g_asYz
                            (g_asYz, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYw = Functions.belowten' g_asYv
                            (g_asYv, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYs = code-0.1.0.0:Genome.FixedList.Functions.double g_asYr
                            (g_asYr, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYq = Functions.belowten' g_asYp
                            (g_asYp, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYo = code-0.1.0.0:Genome.FixedList.Functions.double g_asYn
                            (g_asYn, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYl
                            (g_asYl, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                            (g_asYj, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYi = code-0.1.0.0:Genome.FixedList.Functions.double g_asYh
                            (g_asYh, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                            (g_asYf, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                            (g_asYd, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_at0B) = Genome.Split.split genome_asZt
                          in
                            \ desc_asZu
                              -> case desc_asZu of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZm)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZo)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3g
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3W
                      p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                      (g_at3e, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                      (g_at3a, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                      (g_at38, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                      (g_at36, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                      (g_at34, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at33 = Functions.belowten' g_at32
                      (g_at32, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at2Z = Functions.belowten' g_at2Y
                      (g_at2Y, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                      (g_at2U, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2R = Functions.belowten' g_at2Q
                      (g_at2Q, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2P = code-0.1.0.0:Genome.FixedList.Functions.double g_at2O
                      (g_at2O, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2M
                      (g_at2M, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2K
                      (g_at2K, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2J = Functions.belowten' g_at2I
                      (g_at2I, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2F = Functions.belowten' g_at2E
                      (g_at2E, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                      (g_at2C, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                      (g_at2A, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                      (g_at2y, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2x = Functions.belowten' g_at2w
                      (g_at2w, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                      (g_at2u, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2s
                      (g_at2s, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2q
                      (g_at2q, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2n = Functions.belowten' g_at2m
                      (g_at2m, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                      (g_at2k, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2j = Functions.belowten' g_at2i
                      (g_at2i, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                      (g_at2g, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                      (g_at2e, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2d = Functions.belowten' g_at2c
                      (g_at2c, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at29
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at28
                      (g_at28, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at27
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at26
                      (g_at26, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                      (g_at24, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at21 = code-0.1.0.0:Genome.FixedList.Functions.double g_at20
                      (g_at20, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                      (g_at1W, gpart_at3i) = Genome.Split.split genome_at3g
                    in
                      [Reaction
                         (\ x_at3X
                            -> let c_MiRs_at3Y = ((toVector x_at3X) Data.Vector.Unboxed.! 2)
                               in (p_at25 / (1 + ((c_MiRs_at3Y / p_at2b) ** p_at2d))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3Z
                            -> let
                                 c_MiRs_at40 = ((toVector x_at3Z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at41 = ((toVector x_at3Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2f
                                  / (1
                                     + (((c_MiRs_at40 / p_at2h) ** p_at2j)
                                        + ((c_PTB_at41 / p_at2l) ** p_at2n)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at42
                            -> let c_RESTc_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2p
                                  * (p_at2z
                                     / ((1 + p_at2z) + ((c_RESTc_at43 / p_at2v) ** p_at2x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at44
                            -> let
                                 c_MiRs_at49 = ((toVector x_at44) Data.Vector.Unboxed.! 2)
                                 c_PTB_at46 = ((toVector x_at44) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2B
                                  * ((p_at2T
                                      + (((c_NPTB_at45 / p_at2D) ** p_at2F)
                                         + ((c_PTB_at46 / p_at2H) ** p_at2J)))
                                     / (((1 + p_at2T)
                                         + (((c_NPTB_at45 / p_at2D) ** p_at2F)
                                            + ((c_PTB_at46 / p_at2H) ** p_at2J)))
                                        + ((c_MiRs_at49 / p_at2P) ** p_at2R)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4a
                            -> let
                                 c_RESTc_at4d = ((toVector x_at4a) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2V
                                  * ((p_at35 + ((c_MiRs_at4b / p_at2X) ** p_at2Z))
                                     / (((1 + p_at35) + ((c_MiRs_at4b / p_at2X) ** p_at2Z))
                                        + ((c_RESTc_at4d / p_at31) ** p_at33)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4e
                            -> let c_PTB_at4f = ((toVector x_at4e) Data.Vector.Unboxed.! 0)
                               in (p_at37 * c_PTB_at4f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4g
                            -> let c_NPTB_at4h = ((toVector x_at4g) Data.Vector.Unboxed.! 1)
                               in (p_at39 * c_NPTB_at4h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4i
                            -> let c_MiRs_at4j = ((toVector x_at4i) Data.Vector.Unboxed.! 2)
                               in (p_at3b * c_MiRs_at4j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4k
                            -> let c_RESTc_at4l = ((toVector x_at4k) Data.Vector.Unboxed.! 3)
                               in (p_at3d * c_RESTc_at4l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4m
                            -> let
                                 c_EndoNeuroTFs_at4n = ((toVector x_at4m) Data.Vector.Unboxed.! 4)
                               in (p_at3f * c_EndoNeuroTFs_at4n))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3g
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at52
                            p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                            (g_at3e, gpart_at52) = Genome.Split.split gpart_at51
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at51) = Genome.Split.split gpart_at50
                            p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                            (g_at3a, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                            (g_at38, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                            (g_at36, gpart_at4Y) = Genome.Split.split gpart_at4X
                            p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                            (g_at34, gpart_at4X) = Genome.Split.split gpart_at4W
                            p_at33 = Functions.belowten' g_at32
                            (g_at32, gpart_at4W) = Genome.Split.split gpart_at4V
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at2Z = Functions.belowten' g_at2Y
                            (g_at2Y, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                            (g_at2U, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2R = Functions.belowten' g_at2Q
                            (g_at2Q, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2P = code-0.1.0.0:Genome.FixedList.Functions.double g_at2O
                            (g_at2O, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2M
                            (g_at2M, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2K
                            (g_at2K, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2J = Functions.belowten' g_at2I
                            (g_at2I, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2F = Functions.belowten' g_at2E
                            (g_at2E, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                            (g_at2C, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                            (g_at2A, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                            (g_at2y, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2x = Functions.belowten' g_at2w
                            (g_at2w, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                            (g_at2u, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2s
                            (g_at2s, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2q
                            (g_at2q, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2n = Functions.belowten' g_at2m
                            (g_at2m, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                            (g_at2k, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2j = Functions.belowten' g_at2i
                            (g_at2i, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                            (g_at2g, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                            (g_at2e, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2d = Functions.belowten' g_at2c
                            (g_at2c, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at29
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at28
                            (g_at28, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at27
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at26
                            (g_at26, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                            (g_at24, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at21 = code-0.1.0.0:Genome.FixedList.Functions.double g_at20
                            (g_at20, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                            (g_at1W, gpart_at4o) = Genome.Split.split genome_at3g
                          in
                            \ desc_at3h
                              -> case desc_at3h of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at33)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at35)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at73
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7J
                      p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                      (g_at71, gpart_at7J) = Genome.Split.split gpart_at7I
                      p_at70 = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Z
                      (g_at6Z, gpart_at7I) = Genome.Split.split gpart_at7H
                      p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                      (g_at6X, gpart_at7H) = Genome.Split.split gpart_at7G
                      p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                      (g_at6V, gpart_at7G) = Genome.Split.split gpart_at7F
                      p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                      (g_at6T, gpart_at7F) = Genome.Split.split gpart_at7E
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at7E) = Genome.Split.split gpart_at7D
                      p_at6Q = Functions.belowten' g_at6P
                      (g_at6P, gpart_at7D) = Genome.Split.split gpart_at7C
                      p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                      (g_at6N, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6M = Functions.belowten' g_at6L
                      (g_at6L, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                      (g_at6J, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6G = code-0.1.0.0:Genome.FixedList.Functions.double g_at6F
                      (g_at6F, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6E = Functions.belowten' g_at6D
                      (g_at6D, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                      (g_at6B, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6z
                      (g_at6z, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6x
                      (g_at6x, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6w = Functions.belowten' g_at6v
                      (g_at6v, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6u = code-0.1.0.0:Genome.FixedList.Functions.double g_at6t
                      (g_at6t, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6s = Functions.belowten' g_at6r
                      (g_at6r, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6p
                      (g_at6p, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                      (g_at6n, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                      (g_at6l, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6k = Functions.belowten' g_at6j
                      (g_at6j, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                      (g_at6h, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6f
                      (g_at6f, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6d
                      (g_at6d, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                      (g_at6b, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6a = Functions.belowten' g_at69
                      (g_at69, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                      (g_at67, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at66 = Functions.belowten' g_at65
                      (g_at65, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at64 = code-0.1.0.0:Genome.FixedList.Functions.double g_at63
                      (g_at63, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                      (g_at61, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at60 = Functions.belowten' g_at5Z
                      (g_at5Z, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                      (g_at5X, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at5W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5V
                      (g_at5V, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at5U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5T
                      (g_at5T, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                      (g_at5R, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                      (g_at5P, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                      (g_at5N, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                      (g_at5L, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                      (g_at5J, gpart_at75) = Genome.Split.split genome_at73
                    in
                      [Reaction
                         (\ x_at7K
                            -> let c_MiRs_at7L = ((toVector x_at7K) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5S
                                  / (1
                                     + (((p_at5K / p_at5U) ** p_at5W)
                                        + ((c_MiRs_at7L / p_at5Y) ** p_at60)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7M
                            -> let
                                 c_MiRs_at7N = ((toVector x_at7M) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7O = ((toVector x_at7M) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at62
                                  / (1
                                     + (((c_MiRs_at7N / p_at64) ** p_at66)
                                        + ((c_PTB_at7O / p_at68) ** p_at6a)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7P
                            -> let c_RESTc_at7Q = ((toVector x_at7P) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6c
                                  * (p_at6m
                                     / ((1 + p_at6m) + ((c_RESTc_at7Q / p_at6i) ** p_at6k)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7R
                            -> let
                                 c_MiRs_at7W = ((toVector x_at7R) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7T = ((toVector x_at7R) Data.Vector.Unboxed.! 0)
                                 c_NPTB_at7S = ((toVector x_at7R) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at6o
                                  * ((p_at6G
                                      + (((c_NPTB_at7S / p_at6q) ** p_at6s)
                                         + ((c_PTB_at7T / p_at6u) ** p_at6w)))
                                     / (((1 + p_at6G)
                                         + (((c_NPTB_at7S / p_at6q) ** p_at6s)
                                            + ((c_PTB_at7T / p_at6u) ** p_at6w)))
                                        + ((c_MiRs_at7W / p_at6C) ** p_at6E)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7X
                            -> let
                                 c_RESTc_at80 = ((toVector x_at7X) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7Y = ((toVector x_at7X) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6I
                                  * ((p_at6S + ((c_MiRs_at7Y / p_at6K) ** p_at6M))
                                     / (((1 + p_at6S) + ((c_MiRs_at7Y / p_at6K) ** p_at6M))
                                        + ((c_RESTc_at80 / p_at6O) ** p_at6Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at81
                            -> let c_PTB_at82 = ((toVector x_at81) Data.Vector.Unboxed.! 0)
                               in (p_at6U * c_PTB_at82))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at83
                            -> let c_NPTB_at84 = ((toVector x_at83) Data.Vector.Unboxed.! 1)
                               in (p_at6W * c_NPTB_at84))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at85
                            -> let c_MiRs_at86 = ((toVector x_at85) Data.Vector.Unboxed.! 2)
                               in (p_at6Y * c_MiRs_at86))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at87
                            -> let c_RESTc_at88 = ((toVector x_at87) Data.Vector.Unboxed.! 3)
                               in (p_at70 * c_RESTc_at88))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at89
                            -> let
                                 c_EndoNeuroTFs_at8a = ((toVector x_at89) Data.Vector.Unboxed.! 4)
                               in (p_at72 * c_EndoNeuroTFs_at8a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at73
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8P
                            p_at72 = code-0.1.0.0:Genome.FixedList.Functions.double g_at71
                            (g_at71, gpart_at8P) = Genome.Split.split gpart_at8O
                            p_at70 = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Z
                            (g_at6Z, gpart_at8O) = Genome.Split.split gpart_at8N
                            p_at6Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6X
                            (g_at6X, gpart_at8N) = Genome.Split.split gpart_at8M
                            p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                            (g_at6V, gpart_at8M) = Genome.Split.split gpart_at8L
                            p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                            (g_at6T, gpart_at8L) = Genome.Split.split gpart_at8K
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at8K) = Genome.Split.split gpart_at8J
                            p_at6Q = Functions.belowten' g_at6P
                            (g_at6P, gpart_at8J) = Genome.Split.split gpart_at8I
                            p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                            (g_at6N, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6M = Functions.belowten' g_at6L
                            (g_at6L, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                            (g_at6J, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6G = code-0.1.0.0:Genome.FixedList.Functions.double g_at6F
                            (g_at6F, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6E = Functions.belowten' g_at6D
                            (g_at6D, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                            (g_at6B, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6z
                            (g_at6z, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6x
                            (g_at6x, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6w = Functions.belowten' g_at6v
                            (g_at6v, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6u = code-0.1.0.0:Genome.FixedList.Functions.double g_at6t
                            (g_at6t, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6s = Functions.belowten' g_at6r
                            (g_at6r, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6p
                            (g_at6p, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                            (g_at6n, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                            (g_at6l, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6k = Functions.belowten' g_at6j
                            (g_at6j, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                            (g_at6h, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6f
                            (g_at6f, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6d
                            (g_at6d, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                            (g_at6b, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6a = Functions.belowten' g_at69
                            (g_at69, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at68 = code-0.1.0.0:Genome.FixedList.Functions.double g_at67
                            (g_at67, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at66 = Functions.belowten' g_at65
                            (g_at65, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at64 = code-0.1.0.0:Genome.FixedList.Functions.double g_at63
                            (g_at63, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                            (g_at61, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at60 = Functions.belowten' g_at5Z
                            (g_at5Z, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                            (g_at5X, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at5W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5V
                            (g_at5V, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at5U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5T
                            (g_at5T, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                            (g_at5R, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                            (g_at5P, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                            (g_at5N, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                            (g_at5L, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                            (g_at5J, gpart_at8b) = Genome.Split.split genome_at73
                          in
                            \ desc_at74
                              -> case desc_at74 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Activation coef [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Activation hill [NPTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6U)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6W)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Y)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at70)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at72)
                                   _ -> Nothing }}
