src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24AM
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Bs
                      p_a24AL = double g_a24AK
                      (g_a24AK, gpart_a24Bs) = Genome.Split.split gpart_a24Br
                      p_a24AJ = double g_a24AI
                      (g_a24AI, gpart_a24Br) = Genome.Split.split gpart_a24Bq
                      p_a24AH = double g_a24AG
                      (g_a24AG, gpart_a24Bq) = Genome.Split.split gpart_a24Bp
                      p_a24AF = double g_a24AE
                      (g_a24AE, gpart_a24Bp) = Genome.Split.split gpart_a24Bo
                      p_a24AD = double g_a24AC
                      (g_a24AC, gpart_a24Bo) = Genome.Split.split gpart_a24Bn
                      p_a24AB = Functions.belowten' g_a24AA
                      (g_a24AA, gpart_a24Bn) = Genome.Split.split gpart_a24Bm
                      p_a24Az = double g_a24Ay
                      (g_a24Ay, gpart_a24Bm) = Genome.Split.split gpart_a24Bl
                      p_a24Ax = double g_a24Aw
                      (g_a24Aw, gpart_a24Bl) = Genome.Split.split gpart_a24Bk
                      p_a24Av = double g_a24Au
                      (g_a24Au, gpart_a24Bk) = Genome.Split.split gpart_a24Bj
                      p_a24At = Functions.belowten' g_a24As
                      (g_a24As, gpart_a24Bj) = Genome.Split.split gpart_a24Bi
                      p_a24Ar = double g_a24Aq
                      (g_a24Aq, gpart_a24Bi) = Genome.Split.split gpart_a24Bh
                      p_a24Ap
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ao
                      (g_a24Ao, gpart_a24Bh) = Genome.Split.split gpart_a24Bg
                      p_a24An
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Am
                      (g_a24Am, gpart_a24Bg) = Genome.Split.split gpart_a24Bf
                      p_a24Al = Functions.belowten' g_a24Ak
                      (g_a24Ak, gpart_a24Bf) = Genome.Split.split gpart_a24Be
                      p_a24Aj = double g_a24Ai
                      (g_a24Ai, gpart_a24Be) = Genome.Split.split gpart_a24Bd
                      p_a24Ah = double g_a24Ag
                      (g_a24Ag, gpart_a24Bd) = Genome.Split.split gpart_a24Bc
                      p_a24Af = double g_a24Ae
                      (g_a24Ae, gpart_a24Bc) = Genome.Split.split gpart_a24Bb
                      p_a24Ad = Functions.belowten' g_a24Ac
                      (g_a24Ac, gpart_a24Bb) = Genome.Split.split gpart_a24Ba
                      p_a24Ab = double g_a24Aa
                      (g_a24Aa, gpart_a24Ba) = Genome.Split.split gpart_a24B9
                      p_a24A9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24A8
                      (g_a24A8, gpart_a24B9) = Genome.Split.split gpart_a24B8
                      p_a24A7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24A6
                      (g_a24A6, gpart_a24B8) = Genome.Split.split gpart_a24B7
                      p_a24A5 = double g_a24A4
                      (g_a24A4, gpart_a24B7) = Genome.Split.split gpart_a24B6
                      p_a24A3 = Functions.belowten' g_a24A2
                      (g_a24A2, gpart_a24B6) = Genome.Split.split gpart_a24B5
                      p_a24A1 = double g_a24A0
                      (g_a24A0, gpart_a24B5) = Genome.Split.split gpart_a24B4
                      p_a24zZ = Functions.belowten' g_a24zY
                      (g_a24zY, gpart_a24B4) = Genome.Split.split gpart_a24B3
                      p_a24zX = double g_a24zW
                      (g_a24zW, gpart_a24B3) = Genome.Split.split gpart_a24B2
                      p_a24zV = Functions.belowten' g_a24zU
                      (g_a24zU, gpart_a24B2) = Genome.Split.split gpart_a24B1
                      p_a24zT = double g_a24zS
                      (g_a24zS, gpart_a24B1) = Genome.Split.split gpart_a24B0
                      p_a24zR = double g_a24zQ
                      (g_a24zQ, gpart_a24B0) = Genome.Split.split gpart_a24AZ
                      p_a24zP = double g_a24zO
                      (g_a24zO, gpart_a24AZ) = Genome.Split.split gpart_a24AY
                      p_a24zN = Functions.belowten' g_a24zM
                      (g_a24zM, gpart_a24AY) = Genome.Split.split gpart_a24AX
                      p_a24zL = double g_a24zK
                      (g_a24zK, gpart_a24AX) = Genome.Split.split gpart_a24AW
                      p_a24zJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24zI
                      (g_a24zI, gpart_a24AW) = Genome.Split.split gpart_a24AV
                      p_a24zH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24zG
                      (g_a24zG, gpart_a24AV) = Genome.Split.split gpart_a24AU
                      p_a24zF = Functions.belowten' g_a24zE
                      (g_a24zE, gpart_a24AU) = Genome.Split.split gpart_a24AT
                      p_a24zD = double g_a24zC
                      (g_a24zC, gpart_a24AT) = Genome.Split.split gpart_a24AS
                      p_a24zB = double g_a24zA
                      (g_a24zA, gpart_a24AS) = Genome.Split.split gpart_a24AR
                      p_a24zz = double g_a24zy
                      (g_a24zy, gpart_a24AR) = Genome.Split.split gpart_a24AQ
                      p_a24zx = double g_a24zw
                      (g_a24zw, gpart_a24AQ) = Genome.Split.split gpart_a24AP
                      p_a24zv = double g_a24zu
                      (g_a24zu, gpart_a24AP) = Genome.Split.split gpart_a24AO
                      p_a24zt = double g_a24zs
                      (g_a24zs, gpart_a24AO) = Genome.Split.split genome_a24AM
                    in  \ x_a24Bt
                          -> let
                               c_PTB_a24By
                                 = ((Data.Fixed.Vector.toVector x_a24Bt) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Bw
                                 = ((Data.Fixed.Vector.toVector x_a24Bt) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Bu
                                 = ((Data.Fixed.Vector.toVector x_a24Bt) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Bz
                                 = ((Data.Fixed.Vector.toVector x_a24Bt) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24BO
                                 = ((Data.Fixed.Vector.toVector x_a24Bt) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24zB
                                     * ((p_a24zP + ((c_NPTB_a24Bu / p_a24zD) ** p_a24zF))
                                        / (((1 + p_a24zP) + ((c_NPTB_a24Bu / p_a24zD) ** p_a24zF))
                                           + ((c_MiRs_a24Bw / p_a24zL) ** p_a24zN))))
                                    + (negate (p_a24AD * c_PTB_a24By))),
                                   ((p_a24zR
                                     / (1
                                        + ((((c_RESTc_a24Bz / p_a24zT) ** p_a24zV)
                                            + ((c_MiRs_a24Bw / p_a24zX) ** p_a24zZ))
                                           + ((c_PTB_a24By / p_a24A1) ** p_a24A3))))
                                    + (negate (p_a24AF * c_NPTB_a24Bu))),
                                   ((p_a24A5
                                     * ((p_a24Af + ((p_a24zx / p_a24A7) ** p_a24A9))
                                        / (((1 + p_a24Af) + ((p_a24zx / p_a24A7) ** p_a24A9))
                                           + ((c_RESTc_a24Bz / p_a24Ab) ** p_a24Ad))))
                                    + (negate (p_a24AH * c_MiRs_a24Bw))),
                                   ((p_a24Ah
                                     * ((p_a24Av + ((c_PTB_a24By / p_a24Aj) ** p_a24Al))
                                        / (((1 + p_a24Av) + ((c_PTB_a24By / p_a24Aj) ** p_a24Al))
                                           + (((p_a24zt / p_a24An) ** p_a24Ap)
                                              + ((c_MiRs_a24Bw / p_a24Ar) ** p_a24At)))))
                                    + (negate (p_a24AJ * c_RESTc_a24Bz))),
                                   ((p_a24Ax / (1 + ((c_RESTc_a24Bz / p_a24Az) ** p_a24AB)))
                                    + (negate (p_a24AL * c_EndoNeuroTFs_a24BO)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504037",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504039",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504043",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504045",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504063",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504065",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504079",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504081",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504093",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24AM
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Ct
                            p_a24AL = double g_a24AK
                            (g_a24AK, gpart_a24Ct) = Genome.Split.split gpart_a24Cs
                            p_a24AJ = double g_a24AI
                            (g_a24AI, gpart_a24Cs) = Genome.Split.split gpart_a24Cr
                            p_a24AH = double g_a24AG
                            (g_a24AG, gpart_a24Cr) = Genome.Split.split gpart_a24Cq
                            p_a24AF = double g_a24AE
                            (g_a24AE, gpart_a24Cq) = Genome.Split.split gpart_a24Cp
                            p_a24AD = double g_a24AC
                            (g_a24AC, gpart_a24Cp) = Genome.Split.split gpart_a24Co
                            p_a24AB = Functions.belowten' g_a24AA
                            (g_a24AA, gpart_a24Co) = Genome.Split.split gpart_a24Cn
                            p_a24Az = double g_a24Ay
                            (g_a24Ay, gpart_a24Cn) = Genome.Split.split gpart_a24Cm
                            p_a24Ax = double g_a24Aw
                            (g_a24Aw, gpart_a24Cm) = Genome.Split.split gpart_a24Cl
                            p_a24Av = double g_a24Au
                            (g_a24Au, gpart_a24Cl) = Genome.Split.split gpart_a24Ck
                            p_a24At = Functions.belowten' g_a24As
                            (g_a24As, gpart_a24Ck) = Genome.Split.split gpart_a24Cj
                            p_a24Ar = double g_a24Aq
                            (g_a24Aq, gpart_a24Cj) = Genome.Split.split gpart_a24Ci
                            p_a24Ap
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ao
                            (g_a24Ao, gpart_a24Ci) = Genome.Split.split gpart_a24Ch
                            p_a24An
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Am
                            (g_a24Am, gpart_a24Ch) = Genome.Split.split gpart_a24Cg
                            p_a24Al = Functions.belowten' g_a24Ak
                            (g_a24Ak, gpart_a24Cg) = Genome.Split.split gpart_a24Cf
                            p_a24Aj = double g_a24Ai
                            (g_a24Ai, gpart_a24Cf) = Genome.Split.split gpart_a24Ce
                            p_a24Ah = double g_a24Ag
                            (g_a24Ag, gpart_a24Ce) = Genome.Split.split gpart_a24Cd
                            p_a24Af = double g_a24Ae
                            (g_a24Ae, gpart_a24Cd) = Genome.Split.split gpart_a24Cc
                            p_a24Ad = Functions.belowten' g_a24Ac
                            (g_a24Ac, gpart_a24Cc) = Genome.Split.split gpart_a24Cb
                            p_a24Ab = double g_a24Aa
                            (g_a24Aa, gpart_a24Cb) = Genome.Split.split gpart_a24Ca
                            p_a24A9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24A8
                            (g_a24A8, gpart_a24Ca) = Genome.Split.split gpart_a24C9
                            p_a24A7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24A6
                            (g_a24A6, gpart_a24C9) = Genome.Split.split gpart_a24C8
                            p_a24A5 = double g_a24A4
                            (g_a24A4, gpart_a24C8) = Genome.Split.split gpart_a24C7
                            p_a24A3 = Functions.belowten' g_a24A2
                            (g_a24A2, gpart_a24C7) = Genome.Split.split gpart_a24C6
                            p_a24A1 = double g_a24A0
                            (g_a24A0, gpart_a24C6) = Genome.Split.split gpart_a24C5
                            p_a24zZ = Functions.belowten' g_a24zY
                            (g_a24zY, gpart_a24C5) = Genome.Split.split gpart_a24C4
                            p_a24zX = double g_a24zW
                            (g_a24zW, gpart_a24C4) = Genome.Split.split gpart_a24C3
                            p_a24zV = Functions.belowten' g_a24zU
                            (g_a24zU, gpart_a24C3) = Genome.Split.split gpart_a24C2
                            p_a24zT = double g_a24zS
                            (g_a24zS, gpart_a24C2) = Genome.Split.split gpart_a24C1
                            p_a24zR = double g_a24zQ
                            (g_a24zQ, gpart_a24C1) = Genome.Split.split gpart_a24C0
                            p_a24zP = double g_a24zO
                            (g_a24zO, gpart_a24C0) = Genome.Split.split gpart_a24BZ
                            p_a24zN = Functions.belowten' g_a24zM
                            (g_a24zM, gpart_a24BZ) = Genome.Split.split gpart_a24BY
                            p_a24zL = double g_a24zK
                            (g_a24zK, gpart_a24BY) = Genome.Split.split gpart_a24BX
                            p_a24zJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24zI
                            (g_a24zI, gpart_a24BX) = Genome.Split.split gpart_a24BW
                            p_a24zH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24zG
                            (g_a24zG, gpart_a24BW) = Genome.Split.split gpart_a24BV
                            p_a24zF = Functions.belowten' g_a24zE
                            (g_a24zE, gpart_a24BV) = Genome.Split.split gpart_a24BU
                            p_a24zD = double g_a24zC
                            (g_a24zC, gpart_a24BU) = Genome.Split.split gpart_a24BT
                            p_a24zB = double g_a24zA
                            (g_a24zA, gpart_a24BT) = Genome.Split.split gpart_a24BS
                            p_a24zz = double g_a24zy
                            (g_a24zy, gpart_a24BS) = Genome.Split.split gpart_a24BR
                            p_a24zx = double g_a24zw
                            (g_a24zw, gpart_a24BR) = Genome.Split.split gpart_a24BQ
                            p_a24zv = double g_a24zu
                            (g_a24zu, gpart_a24BQ) = Genome.Split.split gpart_a24BP
                            p_a24zt = double g_a24zs
                            (g_a24zs, gpart_a24BP) = Genome.Split.split genome_a24AM
                          in
                            \ desc_a24AN
                              -> case desc_a24AN of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zt)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zv)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zx)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zz)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zB)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zD)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zF)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zH)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zJ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zL)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zN)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zP)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zR)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zT)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zV)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zX)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24zZ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24A1)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24A3)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24A5)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24A7)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24A9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ab)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ad)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Af)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ah)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Aj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Al)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24An)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ap)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ar)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24At)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Av)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ax)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Az)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AB)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AD)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AF)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AH)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AJ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24AL)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24EX
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24FD
                      p_a24EW = double g_a24EV
                      (g_a24EV, gpart_a24FD) = Genome.Split.split gpart_a24FC
                      p_a24EU = double g_a24ET
                      (g_a24ET, gpart_a24FC) = Genome.Split.split gpart_a24FB
                      p_a24ES = double g_a24ER
                      (g_a24ER, gpart_a24FB) = Genome.Split.split gpart_a24FA
                      p_a24EQ = double g_a24EP
                      (g_a24EP, gpart_a24FA) = Genome.Split.split gpart_a24Fz
                      p_a24EO = double g_a24EN
                      (g_a24EN, gpart_a24Fz) = Genome.Split.split gpart_a24Fy
                      p_a24EM = Functions.belowten' g_a24EL
                      (g_a24EL, gpart_a24Fy) = Genome.Split.split gpart_a24Fx
                      p_a24EK = double g_a24EJ
                      (g_a24EJ, gpart_a24Fx) = Genome.Split.split gpart_a24Fw
                      p_a24EI = double g_a24EH
                      (g_a24EH, gpart_a24Fw) = Genome.Split.split gpart_a24Fv
                      p_a24EG = double g_a24EF
                      (g_a24EF, gpart_a24Fv) = Genome.Split.split gpart_a24Fu
                      p_a24EE = Functions.belowten' g_a24ED
                      (g_a24ED, gpart_a24Fu) = Genome.Split.split gpart_a24Ft
                      p_a24EC = double g_a24EB
                      (g_a24EB, gpart_a24Ft) = Genome.Split.split gpart_a24Fs
                      p_a24EA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ez
                      (g_a24Ez, gpart_a24Fs) = Genome.Split.split gpart_a24Fr
                      p_a24Ey
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ex
                      (g_a24Ex, gpart_a24Fr) = Genome.Split.split gpart_a24Fq
                      p_a24Ew = Functions.belowten' g_a24Ev
                      (g_a24Ev, gpart_a24Fq) = Genome.Split.split gpart_a24Fp
                      p_a24Eu = double g_a24Et
                      (g_a24Et, gpart_a24Fp) = Genome.Split.split gpart_a24Fo
                      p_a24Es = double g_a24Er
                      (g_a24Er, gpart_a24Fo) = Genome.Split.split gpart_a24Fn
                      p_a24Eq = double g_a24Ep
                      (g_a24Ep, gpart_a24Fn) = Genome.Split.split gpart_a24Fm
                      p_a24Eo = Functions.belowten' g_a24En
                      (g_a24En, gpart_a24Fm) = Genome.Split.split gpart_a24Fl
                      p_a24Em = double g_a24El
                      (g_a24El, gpart_a24Fl) = Genome.Split.split gpart_a24Fk
                      p_a24Ek
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ej
                      (g_a24Ej, gpart_a24Fk) = Genome.Split.split gpart_a24Fj
                      p_a24Ei
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Eh
                      (g_a24Eh, gpart_a24Fj) = Genome.Split.split gpart_a24Fi
                      p_a24Eg = double g_a24Ef
                      (g_a24Ef, gpart_a24Fi) = Genome.Split.split gpart_a24Fh
                      p_a24Ee = Functions.belowten' g_a24Ed
                      (g_a24Ed, gpart_a24Fh) = Genome.Split.split gpart_a24Fg
                      p_a24Ec = double g_a24Eb
                      (g_a24Eb, gpart_a24Fg) = Genome.Split.split gpart_a24Ff
                      p_a24Ea = Functions.belowten' g_a24E9
                      (g_a24E9, gpart_a24Ff) = Genome.Split.split gpart_a24Fe
                      p_a24E8 = double g_a24E7
                      (g_a24E7, gpart_a24Fe) = Genome.Split.split gpart_a24Fd
                      p_a24E6 = Functions.belowten' g_a24E5
                      (g_a24E5, gpart_a24Fd) = Genome.Split.split gpart_a24Fc
                      p_a24E4 = double g_a24E3
                      (g_a24E3, gpart_a24Fc) = Genome.Split.split gpart_a24Fb
                      p_a24E2 = double g_a24E1
                      (g_a24E1, gpart_a24Fb) = Genome.Split.split gpart_a24Fa
                      p_a24E0 = double g_a24DZ
                      (g_a24DZ, gpart_a24Fa) = Genome.Split.split gpart_a24F9
                      p_a24DY = Functions.belowten' g_a24DX
                      (g_a24DX, gpart_a24F9) = Genome.Split.split gpart_a24F8
                      p_a24DW = double g_a24DV
                      (g_a24DV, gpart_a24F8) = Genome.Split.split gpart_a24F7
                      p_a24DU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24DT
                      (g_a24DT, gpart_a24F7) = Genome.Split.split gpart_a24F6
                      p_a24DS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24DR
                      (g_a24DR, gpart_a24F6) = Genome.Split.split gpart_a24F5
                      p_a24DQ = Functions.belowten' g_a24DP
                      (g_a24DP, gpart_a24F5) = Genome.Split.split gpart_a24F4
                      p_a24DO = double g_a24DN
                      (g_a24DN, gpart_a24F4) = Genome.Split.split gpart_a24F3
                      p_a24DM = double g_a24DL
                      (g_a24DL, gpart_a24F3) = Genome.Split.split gpart_a24F2
                      p_a24DK = double g_a24DJ
                      (g_a24DJ, gpart_a24F2) = Genome.Split.split gpart_a24F1
                      p_a24DI = double g_a24DH
                      (g_a24DH, gpart_a24F1) = Genome.Split.split gpart_a24F0
                      p_a24DG = double g_a24DF
                      (g_a24DF, gpart_a24F0) = Genome.Split.split gpart_a24EZ
                      p_a24DE = double g_a24DD
                      (g_a24DD, gpart_a24EZ) = Genome.Split.split genome_a24EX
                    in  \ x_a24FE
                          -> let
                               c_PTB_a24FJ
                                 = ((Data.Fixed.Vector.toVector x_a24FE) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24FH
                                 = ((Data.Fixed.Vector.toVector x_a24FE) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24FF
                                 = ((Data.Fixed.Vector.toVector x_a24FE) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24FK
                                 = ((Data.Fixed.Vector.toVector x_a24FE) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24FZ
                                 = ((Data.Fixed.Vector.toVector x_a24FE) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24DM
                                     * ((p_a24E0 + ((c_NPTB_a24FF / p_a24DO) ** p_a24DQ))
                                        / (((1 + p_a24E0) + ((c_NPTB_a24FF / p_a24DO) ** p_a24DQ))
                                           + ((c_MiRs_a24FH / p_a24DW) ** p_a24DY))))
                                    + (negate (p_a24EO * c_PTB_a24FJ))),
                                   ((p_a24E2
                                     / (1
                                        + ((((c_RESTc_a24FK / p_a24E4) ** p_a24E6)
                                            + ((c_MiRs_a24FH / p_a24E8) ** p_a24Ea))
                                           + ((c_PTB_a24FJ / p_a24Ec) ** p_a24Ee))))
                                    + (negate (p_a24EQ * c_NPTB_a24FF))),
                                   ((p_a24Eg
                                     * (p_a24Eq
                                        / ((1 + p_a24Eq) + ((c_RESTc_a24FK / p_a24Em) ** p_a24Eo))))
                                    + (negate (p_a24ES * c_MiRs_a24FH))),
                                   ((p_a24Es
                                     * ((p_a24EG + ((c_PTB_a24FJ / p_a24Eu) ** p_a24Ew))
                                        / (((1 + p_a24EG) + ((c_PTB_a24FJ / p_a24Eu) ** p_a24Ew))
                                           + (((p_a24DE / p_a24Ey) ** p_a24EA)
                                              + ((c_MiRs_a24FH / p_a24EC) ** p_a24EE)))))
                                    + (negate (p_a24EU * c_RESTc_a24FK))),
                                   ((p_a24EI / (1 + ((c_RESTc_a24FK / p_a24EK) ** p_a24EM)))
                                    + (negate (p_a24EW * c_EndoNeuroTFs_a24FZ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504296",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504298",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504322",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504324",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504338",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504340",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24EX
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24GE
                            p_a24EW = double g_a24EV
                            (g_a24EV, gpart_a24GE) = Genome.Split.split gpart_a24GD
                            p_a24EU = double g_a24ET
                            (g_a24ET, gpart_a24GD) = Genome.Split.split gpart_a24GC
                            p_a24ES = double g_a24ER
                            (g_a24ER, gpart_a24GC) = Genome.Split.split gpart_a24GB
                            p_a24EQ = double g_a24EP
                            (g_a24EP, gpart_a24GB) = Genome.Split.split gpart_a24GA
                            p_a24EO = double g_a24EN
                            (g_a24EN, gpart_a24GA) = Genome.Split.split gpart_a24Gz
                            p_a24EM = Functions.belowten' g_a24EL
                            (g_a24EL, gpart_a24Gz) = Genome.Split.split gpart_a24Gy
                            p_a24EK = double g_a24EJ
                            (g_a24EJ, gpart_a24Gy) = Genome.Split.split gpart_a24Gx
                            p_a24EI = double g_a24EH
                            (g_a24EH, gpart_a24Gx) = Genome.Split.split gpart_a24Gw
                            p_a24EG = double g_a24EF
                            (g_a24EF, gpart_a24Gw) = Genome.Split.split gpart_a24Gv
                            p_a24EE = Functions.belowten' g_a24ED
                            (g_a24ED, gpart_a24Gv) = Genome.Split.split gpart_a24Gu
                            p_a24EC = double g_a24EB
                            (g_a24EB, gpart_a24Gu) = Genome.Split.split gpart_a24Gt
                            p_a24EA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ez
                            (g_a24Ez, gpart_a24Gt) = Genome.Split.split gpart_a24Gs
                            p_a24Ey
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ex
                            (g_a24Ex, gpart_a24Gs) = Genome.Split.split gpart_a24Gr
                            p_a24Ew = Functions.belowten' g_a24Ev
                            (g_a24Ev, gpart_a24Gr) = Genome.Split.split gpart_a24Gq
                            p_a24Eu = double g_a24Et
                            (g_a24Et, gpart_a24Gq) = Genome.Split.split gpart_a24Gp
                            p_a24Es = double g_a24Er
                            (g_a24Er, gpart_a24Gp) = Genome.Split.split gpart_a24Go
                            p_a24Eq = double g_a24Ep
                            (g_a24Ep, gpart_a24Go) = Genome.Split.split gpart_a24Gn
                            p_a24Eo = Functions.belowten' g_a24En
                            (g_a24En, gpart_a24Gn) = Genome.Split.split gpart_a24Gm
                            p_a24Em = double g_a24El
                            (g_a24El, gpart_a24Gm) = Genome.Split.split gpart_a24Gl
                            p_a24Ek
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ej
                            (g_a24Ej, gpart_a24Gl) = Genome.Split.split gpart_a24Gk
                            p_a24Ei
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Eh
                            (g_a24Eh, gpart_a24Gk) = Genome.Split.split gpart_a24Gj
                            p_a24Eg = double g_a24Ef
                            (g_a24Ef, gpart_a24Gj) = Genome.Split.split gpart_a24Gi
                            p_a24Ee = Functions.belowten' g_a24Ed
                            (g_a24Ed, gpart_a24Gi) = Genome.Split.split gpart_a24Gh
                            p_a24Ec = double g_a24Eb
                            (g_a24Eb, gpart_a24Gh) = Genome.Split.split gpart_a24Gg
                            p_a24Ea = Functions.belowten' g_a24E9
                            (g_a24E9, gpart_a24Gg) = Genome.Split.split gpart_a24Gf
                            p_a24E8 = double g_a24E7
                            (g_a24E7, gpart_a24Gf) = Genome.Split.split gpart_a24Ge
                            p_a24E6 = Functions.belowten' g_a24E5
                            (g_a24E5, gpart_a24Ge) = Genome.Split.split gpart_a24Gd
                            p_a24E4 = double g_a24E3
                            (g_a24E3, gpart_a24Gd) = Genome.Split.split gpart_a24Gc
                            p_a24E2 = double g_a24E1
                            (g_a24E1, gpart_a24Gc) = Genome.Split.split gpart_a24Gb
                            p_a24E0 = double g_a24DZ
                            (g_a24DZ, gpart_a24Gb) = Genome.Split.split gpart_a24Ga
                            p_a24DY = Functions.belowten' g_a24DX
                            (g_a24DX, gpart_a24Ga) = Genome.Split.split gpart_a24G9
                            p_a24DW = double g_a24DV
                            (g_a24DV, gpart_a24G9) = Genome.Split.split gpart_a24G8
                            p_a24DU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24DT
                            (g_a24DT, gpart_a24G8) = Genome.Split.split gpart_a24G7
                            p_a24DS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24DR
                            (g_a24DR, gpart_a24G7) = Genome.Split.split gpart_a24G6
                            p_a24DQ = Functions.belowten' g_a24DP
                            (g_a24DP, gpart_a24G6) = Genome.Split.split gpart_a24G5
                            p_a24DO = double g_a24DN
                            (g_a24DN, gpart_a24G5) = Genome.Split.split gpart_a24G4
                            p_a24DM = double g_a24DL
                            (g_a24DL, gpart_a24G4) = Genome.Split.split gpart_a24G3
                            p_a24DK = double g_a24DJ
                            (g_a24DJ, gpart_a24G3) = Genome.Split.split gpart_a24G2
                            p_a24DI = double g_a24DH
                            (g_a24DH, gpart_a24G2) = Genome.Split.split gpart_a24G1
                            p_a24DG = double g_a24DF
                            (g_a24DF, gpart_a24G1) = Genome.Split.split gpart_a24G0
                            p_a24DE = double g_a24DD
                            (g_a24DD, gpart_a24G0) = Genome.Split.split genome_a24EX
                          in
                            \ desc_a24EY
                              -> case desc_a24EY of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DE)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DG)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DI)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DK)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DM)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DO)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DQ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DS)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DU)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DW)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24DY)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24E0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24E2)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24E4)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24E6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24E8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ea)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ec)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ee)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Eg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ei)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ek)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Em)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Eo)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Eq)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Es)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Eu)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ew)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ey)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EA)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EC)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EE)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EG)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EI)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EK)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EM)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EO)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EQ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ES)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EU)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24EW)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24J8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24JO
                      p_a24J7 = double g_a24J6
                      (g_a24J6, gpart_a24JO) = Genome.Split.split gpart_a24JN
                      p_a24J5 = double g_a24J4
                      (g_a24J4, gpart_a24JN) = Genome.Split.split gpart_a24JM
                      p_a24J3 = double g_a24J2
                      (g_a24J2, gpart_a24JM) = Genome.Split.split gpart_a24JL
                      p_a24J1 = double g_a24J0
                      (g_a24J0, gpart_a24JL) = Genome.Split.split gpart_a24JK
                      p_a24IZ = double g_a24IY
                      (g_a24IY, gpart_a24JK) = Genome.Split.split gpart_a24JJ
                      p_a24IX = Functions.belowten' g_a24IW
                      (g_a24IW, gpart_a24JJ) = Genome.Split.split gpart_a24JI
                      p_a24IV = double g_a24IU
                      (g_a24IU, gpart_a24JI) = Genome.Split.split gpart_a24JH
                      p_a24IT = double g_a24IS
                      (g_a24IS, gpart_a24JH) = Genome.Split.split gpart_a24JG
                      p_a24IR = double g_a24IQ
                      (g_a24IQ, gpart_a24JG) = Genome.Split.split gpart_a24JF
                      p_a24IP = Functions.belowten' g_a24IO
                      (g_a24IO, gpart_a24JF) = Genome.Split.split gpart_a24JE
                      p_a24IN = double g_a24IM
                      (g_a24IM, gpart_a24JE) = Genome.Split.split gpart_a24JD
                      p_a24IL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24IK
                      (g_a24IK, gpart_a24JD) = Genome.Split.split gpart_a24JC
                      p_a24IJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24II
                      (g_a24II, gpart_a24JC) = Genome.Split.split gpart_a24JB
                      p_a24IH = Functions.belowten' g_a24IG
                      (g_a24IG, gpart_a24JB) = Genome.Split.split gpart_a24JA
                      p_a24IF = double g_a24IE
                      (g_a24IE, gpart_a24JA) = Genome.Split.split gpart_a24Jz
                      p_a24ID = double g_a24IC
                      (g_a24IC, gpart_a24Jz) = Genome.Split.split gpart_a24Jy
                      p_a24IB = double g_a24IA
                      (g_a24IA, gpart_a24Jy) = Genome.Split.split gpart_a24Jx
                      p_a24Iz = Functions.belowten' g_a24Iy
                      (g_a24Iy, gpart_a24Jx) = Genome.Split.split gpart_a24Jw
                      p_a24Ix = double g_a24Iw
                      (g_a24Iw, gpart_a24Jw) = Genome.Split.split gpart_a24Jv
                      p_a24Iv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iu
                      (g_a24Iu, gpart_a24Jv) = Genome.Split.split gpart_a24Ju
                      p_a24It
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Is
                      (g_a24Is, gpart_a24Ju) = Genome.Split.split gpart_a24Jt
                      p_a24Ir = double g_a24Iq
                      (g_a24Iq, gpart_a24Jt) = Genome.Split.split gpart_a24Js
                      p_a24Ip = Functions.belowten' g_a24Io
                      (g_a24Io, gpart_a24Js) = Genome.Split.split gpart_a24Jr
                      p_a24In = double g_a24Im
                      (g_a24Im, gpart_a24Jr) = Genome.Split.split gpart_a24Jq
                      p_a24Il = Functions.belowten' g_a24Ik
                      (g_a24Ik, gpart_a24Jq) = Genome.Split.split gpart_a24Jp
                      p_a24Ij = double g_a24Ii
                      (g_a24Ii, gpart_a24Jp) = Genome.Split.split gpart_a24Jo
                      p_a24Ih = Functions.belowten' g_a24Ig
                      (g_a24Ig, gpart_a24Jo) = Genome.Split.split gpart_a24Jn
                      p_a24If = double g_a24Ie
                      (g_a24Ie, gpart_a24Jn) = Genome.Split.split gpart_a24Jm
                      p_a24Id = double g_a24Ic
                      (g_a24Ic, gpart_a24Jm) = Genome.Split.split gpart_a24Jl
                      p_a24Ib = double g_a24Ia
                      (g_a24Ia, gpart_a24Jl) = Genome.Split.split gpart_a24Jk
                      p_a24I9 = Functions.belowten' g_a24I8
                      (g_a24I8, gpart_a24Jk) = Genome.Split.split gpart_a24Jj
                      p_a24I7 = double g_a24I6
                      (g_a24I6, gpart_a24Jj) = Genome.Split.split gpart_a24Ji
                      p_a24I5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24I4
                      (g_a24I4, gpart_a24Ji) = Genome.Split.split gpart_a24Jh
                      p_a24I3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24I2
                      (g_a24I2, gpart_a24Jh) = Genome.Split.split gpart_a24Jg
                      p_a24I1 = Functions.belowten' g_a24I0
                      (g_a24I0, gpart_a24Jg) = Genome.Split.split gpart_a24Jf
                      p_a24HZ = double g_a24HY
                      (g_a24HY, gpart_a24Jf) = Genome.Split.split gpart_a24Je
                      p_a24HX = double g_a24HW
                      (g_a24HW, gpart_a24Je) = Genome.Split.split gpart_a24Jd
                      p_a24HV = double g_a24HU
                      (g_a24HU, gpart_a24Jd) = Genome.Split.split gpart_a24Jc
                      p_a24HT = double g_a24HS
                      (g_a24HS, gpart_a24Jc) = Genome.Split.split gpart_a24Jb
                      p_a24HR = double g_a24HQ
                      (g_a24HQ, gpart_a24Jb) = Genome.Split.split gpart_a24Ja
                      p_a24HP = double g_a24HO
                      (g_a24HO, gpart_a24Ja) = Genome.Split.split genome_a24J8
                    in  \ x_a24JP
                          -> let
                               c_PTB_a24JU
                                 = ((Data.Fixed.Vector.toVector x_a24JP) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24JS
                                 = ((Data.Fixed.Vector.toVector x_a24JP) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24JQ
                                 = ((Data.Fixed.Vector.toVector x_a24JP) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24JV
                                 = ((Data.Fixed.Vector.toVector x_a24JP) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Ka
                                 = ((Data.Fixed.Vector.toVector x_a24JP) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24HX
                                     * ((p_a24Ib + ((c_NPTB_a24JQ / p_a24HZ) ** p_a24I1))
                                        / (((1 + p_a24Ib) + ((c_NPTB_a24JQ / p_a24HZ) ** p_a24I1))
                                           + ((c_MiRs_a24JS / p_a24I7) ** p_a24I9))))
                                    + (negate (p_a24IZ * c_PTB_a24JU))),
                                   ((p_a24Id
                                     / (1
                                        + ((((c_RESTc_a24JV / p_a24If) ** p_a24Ih)
                                            + ((c_MiRs_a24JS / p_a24Ij) ** p_a24Il))
                                           + ((c_PTB_a24JU / p_a24In) ** p_a24Ip))))
                                    + (negate (p_a24J1 * c_NPTB_a24JQ))),
                                   ((p_a24Ir
                                     * (p_a24IB
                                        / ((1 + p_a24IB) + ((c_RESTc_a24JV / p_a24Ix) ** p_a24Iz))))
                                    + (negate (p_a24J3 * c_MiRs_a24JS))),
                                   ((p_a24ID
                                     * ((p_a24IR + ((c_PTB_a24JU / p_a24IF) ** p_a24IH))
                                        / (((1 + p_a24IR) + ((c_PTB_a24JU / p_a24IF) ** p_a24IH))
                                           + ((c_MiRs_a24JS / p_a24IN) ** p_a24IP))))
                                    + (negate (p_a24J5 * c_RESTc_a24JV))),
                                   ((p_a24IT / (1 + ((c_RESTc_a24JV / p_a24IV) ** p_a24IX)))
                                    + (negate (p_a24J7 * c_EndoNeuroTFs_a24Ka)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504555",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504557",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504581",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504583",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504597",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504599",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24J8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24KP
                            p_a24J7 = double g_a24J6
                            (g_a24J6, gpart_a24KP) = Genome.Split.split gpart_a24KO
                            p_a24J5 = double g_a24J4
                            (g_a24J4, gpart_a24KO) = Genome.Split.split gpart_a24KN
                            p_a24J3 = double g_a24J2
                            (g_a24J2, gpart_a24KN) = Genome.Split.split gpart_a24KM
                            p_a24J1 = double g_a24J0
                            (g_a24J0, gpart_a24KM) = Genome.Split.split gpart_a24KL
                            p_a24IZ = double g_a24IY
                            (g_a24IY, gpart_a24KL) = Genome.Split.split gpart_a24KK
                            p_a24IX = Functions.belowten' g_a24IW
                            (g_a24IW, gpart_a24KK) = Genome.Split.split gpart_a24KJ
                            p_a24IV = double g_a24IU
                            (g_a24IU, gpart_a24KJ) = Genome.Split.split gpart_a24KI
                            p_a24IT = double g_a24IS
                            (g_a24IS, gpart_a24KI) = Genome.Split.split gpart_a24KH
                            p_a24IR = double g_a24IQ
                            (g_a24IQ, gpart_a24KH) = Genome.Split.split gpart_a24KG
                            p_a24IP = Functions.belowten' g_a24IO
                            (g_a24IO, gpart_a24KG) = Genome.Split.split gpart_a24KF
                            p_a24IN = double g_a24IM
                            (g_a24IM, gpart_a24KF) = Genome.Split.split gpart_a24KE
                            p_a24IL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24IK
                            (g_a24IK, gpart_a24KE) = Genome.Split.split gpart_a24KD
                            p_a24IJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24II
                            (g_a24II, gpart_a24KD) = Genome.Split.split gpart_a24KC
                            p_a24IH = Functions.belowten' g_a24IG
                            (g_a24IG, gpart_a24KC) = Genome.Split.split gpart_a24KB
                            p_a24IF = double g_a24IE
                            (g_a24IE, gpart_a24KB) = Genome.Split.split gpart_a24KA
                            p_a24ID = double g_a24IC
                            (g_a24IC, gpart_a24KA) = Genome.Split.split gpart_a24Kz
                            p_a24IB = double g_a24IA
                            (g_a24IA, gpart_a24Kz) = Genome.Split.split gpart_a24Ky
                            p_a24Iz = Functions.belowten' g_a24Iy
                            (g_a24Iy, gpart_a24Ky) = Genome.Split.split gpart_a24Kx
                            p_a24Ix = double g_a24Iw
                            (g_a24Iw, gpart_a24Kx) = Genome.Split.split gpart_a24Kw
                            p_a24Iv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Iu
                            (g_a24Iu, gpart_a24Kw) = Genome.Split.split gpart_a24Kv
                            p_a24It
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Is
                            (g_a24Is, gpart_a24Kv) = Genome.Split.split gpart_a24Ku
                            p_a24Ir = double g_a24Iq
                            (g_a24Iq, gpart_a24Ku) = Genome.Split.split gpart_a24Kt
                            p_a24Ip = Functions.belowten' g_a24Io
                            (g_a24Io, gpart_a24Kt) = Genome.Split.split gpart_a24Ks
                            p_a24In = double g_a24Im
                            (g_a24Im, gpart_a24Ks) = Genome.Split.split gpart_a24Kr
                            p_a24Il = Functions.belowten' g_a24Ik
                            (g_a24Ik, gpart_a24Kr) = Genome.Split.split gpart_a24Kq
                            p_a24Ij = double g_a24Ii
                            (g_a24Ii, gpart_a24Kq) = Genome.Split.split gpart_a24Kp
                            p_a24Ih = Functions.belowten' g_a24Ig
                            (g_a24Ig, gpart_a24Kp) = Genome.Split.split gpart_a24Ko
                            p_a24If = double g_a24Ie
                            (g_a24Ie, gpart_a24Ko) = Genome.Split.split gpart_a24Kn
                            p_a24Id = double g_a24Ic
                            (g_a24Ic, gpart_a24Kn) = Genome.Split.split gpart_a24Km
                            p_a24Ib = double g_a24Ia
                            (g_a24Ia, gpart_a24Km) = Genome.Split.split gpart_a24Kl
                            p_a24I9 = Functions.belowten' g_a24I8
                            (g_a24I8, gpart_a24Kl) = Genome.Split.split gpart_a24Kk
                            p_a24I7 = double g_a24I6
                            (g_a24I6, gpart_a24Kk) = Genome.Split.split gpart_a24Kj
                            p_a24I5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24I4
                            (g_a24I4, gpart_a24Kj) = Genome.Split.split gpart_a24Ki
                            p_a24I3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24I2
                            (g_a24I2, gpart_a24Ki) = Genome.Split.split gpart_a24Kh
                            p_a24I1 = Functions.belowten' g_a24I0
                            (g_a24I0, gpart_a24Kh) = Genome.Split.split gpart_a24Kg
                            p_a24HZ = double g_a24HY
                            (g_a24HY, gpart_a24Kg) = Genome.Split.split gpart_a24Kf
                            p_a24HX = double g_a24HW
                            (g_a24HW, gpart_a24Kf) = Genome.Split.split gpart_a24Ke
                            p_a24HV = double g_a24HU
                            (g_a24HU, gpart_a24Ke) = Genome.Split.split gpart_a24Kd
                            p_a24HT = double g_a24HS
                            (g_a24HS, gpart_a24Kd) = Genome.Split.split gpart_a24Kc
                            p_a24HR = double g_a24HQ
                            (g_a24HQ, gpart_a24Kc) = Genome.Split.split gpart_a24Kb
                            p_a24HP = double g_a24HO
                            (g_a24HO, gpart_a24Kb) = Genome.Split.split genome_a24J8
                          in
                            \ desc_a24J9
                              -> case desc_a24J9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HP)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HR)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HT)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HV)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HX)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24HZ)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I1)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I3)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I5)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I7)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24I9)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ib)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Id)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24If)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ih)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ij)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Il)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24In)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ip)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ir)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24It)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Iv)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ix)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Iz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ID)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IH)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IJ)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IN)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IT)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IV)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24IZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24J1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24J3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24J5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24J7)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24Nj
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24NZ
                      p_a24Ni = double g_a24Nh
                      (g_a24Nh, gpart_a24NZ) = Genome.Split.split gpart_a24NY
                      p_a24Ng = double g_a24Nf
                      (g_a24Nf, gpart_a24NY) = Genome.Split.split gpart_a24NX
                      p_a24Ne = double g_a24Nd
                      (g_a24Nd, gpart_a24NX) = Genome.Split.split gpart_a24NW
                      p_a24Nc = double g_a24Nb
                      (g_a24Nb, gpart_a24NW) = Genome.Split.split gpart_a24NV
                      p_a24Na = double g_a24N9
                      (g_a24N9, gpart_a24NV) = Genome.Split.split gpart_a24NU
                      p_a24N8 = Functions.belowten' g_a24N7
                      (g_a24N7, gpart_a24NU) = Genome.Split.split gpart_a24NT
                      p_a24N6 = double g_a24N5
                      (g_a24N5, gpart_a24NT) = Genome.Split.split gpart_a24NS
                      p_a24N4 = double g_a24N3
                      (g_a24N3, gpart_a24NS) = Genome.Split.split gpart_a24NR
                      p_a24N2 = double g_a24N1
                      (g_a24N1, gpart_a24NR) = Genome.Split.split gpart_a24NQ
                      p_a24N0 = Functions.belowten' g_a24MZ
                      (g_a24MZ, gpart_a24NQ) = Genome.Split.split gpart_a24NP
                      p_a24MY = double g_a24MX
                      (g_a24MX, gpart_a24NP) = Genome.Split.split gpart_a24NO
                      p_a24MW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MV
                      (g_a24MV, gpart_a24NO) = Genome.Split.split gpart_a24NN
                      p_a24MU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MT
                      (g_a24MT, gpart_a24NN) = Genome.Split.split gpart_a24NM
                      p_a24MS = Functions.belowten' g_a24MR
                      (g_a24MR, gpart_a24NM) = Genome.Split.split gpart_a24NL
                      p_a24MQ = double g_a24MP
                      (g_a24MP, gpart_a24NL) = Genome.Split.split gpart_a24NK
                      p_a24MO = double g_a24MN
                      (g_a24MN, gpart_a24NK) = Genome.Split.split gpart_a24NJ
                      p_a24MM = double g_a24ML
                      (g_a24ML, gpart_a24NJ) = Genome.Split.split gpart_a24NI
                      p_a24MK = Functions.belowten' g_a24MJ
                      (g_a24MJ, gpart_a24NI) = Genome.Split.split gpart_a24NH
                      p_a24MI = double g_a24MH
                      (g_a24MH, gpart_a24NH) = Genome.Split.split gpart_a24NG
                      p_a24MG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MF
                      (g_a24MF, gpart_a24NG) = Genome.Split.split gpart_a24NF
                      p_a24ME
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MD
                      (g_a24MD, gpart_a24NF) = Genome.Split.split gpart_a24NE
                      p_a24MC = double g_a24MB
                      (g_a24MB, gpart_a24NE) = Genome.Split.split gpart_a24ND
                      p_a24MA = Functions.belowten' g_a24Mz
                      (g_a24Mz, gpart_a24ND) = Genome.Split.split gpart_a24NC
                      p_a24My = double g_a24Mx
                      (g_a24Mx, gpart_a24NC) = Genome.Split.split gpart_a24NB
                      p_a24Mw = Functions.belowten' g_a24Mv
                      (g_a24Mv, gpart_a24NB) = Genome.Split.split gpart_a24NA
                      p_a24Mu = double g_a24Mt
                      (g_a24Mt, gpart_a24NA) = Genome.Split.split gpart_a24Nz
                      p_a24Ms = Functions.belowten' g_a24Mr
                      (g_a24Mr, gpart_a24Nz) = Genome.Split.split gpart_a24Ny
                      p_a24Mq = double g_a24Mp
                      (g_a24Mp, gpart_a24Ny) = Genome.Split.split gpart_a24Nx
                      p_a24Mo = double g_a24Mn
                      (g_a24Mn, gpart_a24Nx) = Genome.Split.split gpart_a24Nw
                      p_a24Mm = double g_a24Ml
                      (g_a24Ml, gpart_a24Nw) = Genome.Split.split gpart_a24Nv
                      p_a24Mk = Functions.belowten' g_a24Mj
                      (g_a24Mj, gpart_a24Nv) = Genome.Split.split gpart_a24Nu
                      p_a24Mi = double g_a24Mh
                      (g_a24Mh, gpart_a24Nu) = Genome.Split.split gpart_a24Nt
                      p_a24Mg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mf
                      (g_a24Mf, gpart_a24Nt) = Genome.Split.split gpart_a24Ns
                      p_a24Me
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Md
                      (g_a24Md, gpart_a24Ns) = Genome.Split.split gpart_a24Nr
                      p_a24Mc = Functions.belowten' g_a24Mb
                      (g_a24Mb, gpart_a24Nr) = Genome.Split.split gpart_a24Nq
                      p_a24Ma = double g_a24M9
                      (g_a24M9, gpart_a24Nq) = Genome.Split.split gpart_a24Np
                      p_a24M8 = double g_a24M7
                      (g_a24M7, gpart_a24Np) = Genome.Split.split gpart_a24No
                      p_a24M6 = double g_a24M5
                      (g_a24M5, gpart_a24No) = Genome.Split.split gpart_a24Nn
                      p_a24M4 = double g_a24M3
                      (g_a24M3, gpart_a24Nn) = Genome.Split.split gpart_a24Nm
                      p_a24M2 = double g_a24M1
                      (g_a24M1, gpart_a24Nm) = Genome.Split.split gpart_a24Nl
                      p_a24M0 = double g_a24LZ
                      (g_a24LZ, gpart_a24Nl) = Genome.Split.split genome_a24Nj
                    in  \ x_a24O0
                          -> let
                               c_PTB_a24O5
                                 = ((Data.Fixed.Vector.toVector x_a24O0) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24O3
                                 = ((Data.Fixed.Vector.toVector x_a24O0) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24O1
                                 = ((Data.Fixed.Vector.toVector x_a24O0) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24O6
                                 = ((Data.Fixed.Vector.toVector x_a24O0) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Ol
                                 = ((Data.Fixed.Vector.toVector x_a24O0) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24M8
                                     * ((p_a24Mm + ((c_NPTB_a24O1 / p_a24Ma) ** p_a24Mc))
                                        / (((1 + p_a24Mm) + ((c_NPTB_a24O1 / p_a24Ma) ** p_a24Mc))
                                           + (((p_a24M0 / p_a24Me) ** p_a24Mg)
                                              + ((c_MiRs_a24O3 / p_a24Mi) ** p_a24Mk)))))
                                    + (negate (p_a24Na * c_PTB_a24O5))),
                                   ((p_a24Mo
                                     / (1
                                        + ((((c_RESTc_a24O6 / p_a24Mq) ** p_a24Ms)
                                            + ((c_MiRs_a24O3 / p_a24Mu) ** p_a24Mw))
                                           + ((c_PTB_a24O5 / p_a24My) ** p_a24MA))))
                                    + (negate (p_a24Nc * c_NPTB_a24O1))),
                                   ((p_a24MC
                                     * (p_a24MM
                                        / ((1 + p_a24MM) + ((c_RESTc_a24O6 / p_a24MI) ** p_a24MK))))
                                    + (negate (p_a24Ne * c_MiRs_a24O3))),
                                   ((p_a24MO
                                     * ((p_a24N2 + ((c_PTB_a24O5 / p_a24MQ) ** p_a24MS))
                                        / (((1 + p_a24N2) + ((c_PTB_a24O5 / p_a24MQ) ** p_a24MS))
                                           + ((c_MiRs_a24O3 / p_a24MY) ** p_a24N0))))
                                    + (negate (p_a24Ng * c_RESTc_a24O6))),
                                   ((p_a24N4 / (1 + ((c_RESTc_a24O6 / p_a24N6) ** p_a24N8)))
                                    + (negate (p_a24Ni * c_EndoNeuroTFs_a24Ol)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504807",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504808",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504810",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504812",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504814",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504816",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504817",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504818",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504819",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504820",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504821",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504822",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504823",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504824",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504825",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504826",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504827",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504828",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504829",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504830",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504834",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504840",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504842",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504856",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504858",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Nj
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24P0
                            p_a24Ni = double g_a24Nh
                            (g_a24Nh, gpart_a24P0) = Genome.Split.split gpart_a24OZ
                            p_a24Ng = double g_a24Nf
                            (g_a24Nf, gpart_a24OZ) = Genome.Split.split gpart_a24OY
                            p_a24Ne = double g_a24Nd
                            (g_a24Nd, gpart_a24OY) = Genome.Split.split gpart_a24OX
                            p_a24Nc = double g_a24Nb
                            (g_a24Nb, gpart_a24OX) = Genome.Split.split gpart_a24OW
                            p_a24Na = double g_a24N9
                            (g_a24N9, gpart_a24OW) = Genome.Split.split gpart_a24OV
                            p_a24N8 = Functions.belowten' g_a24N7
                            (g_a24N7, gpart_a24OV) = Genome.Split.split gpart_a24OU
                            p_a24N6 = double g_a24N5
                            (g_a24N5, gpart_a24OU) = Genome.Split.split gpart_a24OT
                            p_a24N4 = double g_a24N3
                            (g_a24N3, gpart_a24OT) = Genome.Split.split gpart_a24OS
                            p_a24N2 = double g_a24N1
                            (g_a24N1, gpart_a24OS) = Genome.Split.split gpart_a24OR
                            p_a24N0 = Functions.belowten' g_a24MZ
                            (g_a24MZ, gpart_a24OR) = Genome.Split.split gpart_a24OQ
                            p_a24MY = double g_a24MX
                            (g_a24MX, gpart_a24OQ) = Genome.Split.split gpart_a24OP
                            p_a24MW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MV
                            (g_a24MV, gpart_a24OP) = Genome.Split.split gpart_a24OO
                            p_a24MU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MT
                            (g_a24MT, gpart_a24OO) = Genome.Split.split gpart_a24ON
                            p_a24MS = Functions.belowten' g_a24MR
                            (g_a24MR, gpart_a24ON) = Genome.Split.split gpart_a24OM
                            p_a24MQ = double g_a24MP
                            (g_a24MP, gpart_a24OM) = Genome.Split.split gpart_a24OL
                            p_a24MO = double g_a24MN
                            (g_a24MN, gpart_a24OL) = Genome.Split.split gpart_a24OK
                            p_a24MM = double g_a24ML
                            (g_a24ML, gpart_a24OK) = Genome.Split.split gpart_a24OJ
                            p_a24MK = Functions.belowten' g_a24MJ
                            (g_a24MJ, gpart_a24OJ) = Genome.Split.split gpart_a24OI
                            p_a24MI = double g_a24MH
                            (g_a24MH, gpart_a24OI) = Genome.Split.split gpart_a24OH
                            p_a24MG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MF
                            (g_a24MF, gpart_a24OH) = Genome.Split.split gpart_a24OG
                            p_a24ME
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24MD
                            (g_a24MD, gpart_a24OG) = Genome.Split.split gpart_a24OF
                            p_a24MC = double g_a24MB
                            (g_a24MB, gpart_a24OF) = Genome.Split.split gpart_a24OE
                            p_a24MA = Functions.belowten' g_a24Mz
                            (g_a24Mz, gpart_a24OE) = Genome.Split.split gpart_a24OD
                            p_a24My = double g_a24Mx
                            (g_a24Mx, gpart_a24OD) = Genome.Split.split gpart_a24OC
                            p_a24Mw = Functions.belowten' g_a24Mv
                            (g_a24Mv, gpart_a24OC) = Genome.Split.split gpart_a24OB
                            p_a24Mu = double g_a24Mt
                            (g_a24Mt, gpart_a24OB) = Genome.Split.split gpart_a24OA
                            p_a24Ms = Functions.belowten' g_a24Mr
                            (g_a24Mr, gpart_a24OA) = Genome.Split.split gpart_a24Oz
                            p_a24Mq = double g_a24Mp
                            (g_a24Mp, gpart_a24Oz) = Genome.Split.split gpart_a24Oy
                            p_a24Mo = double g_a24Mn
                            (g_a24Mn, gpart_a24Oy) = Genome.Split.split gpart_a24Ox
                            p_a24Mm = double g_a24Ml
                            (g_a24Ml, gpart_a24Ox) = Genome.Split.split gpart_a24Ow
                            p_a24Mk = Functions.belowten' g_a24Mj
                            (g_a24Mj, gpart_a24Ow) = Genome.Split.split gpart_a24Ov
                            p_a24Mi = double g_a24Mh
                            (g_a24Mh, gpart_a24Ov) = Genome.Split.split gpart_a24Ou
                            p_a24Mg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Mf
                            (g_a24Mf, gpart_a24Ou) = Genome.Split.split gpart_a24Ot
                            p_a24Me
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Md
                            (g_a24Md, gpart_a24Ot) = Genome.Split.split gpart_a24Os
                            p_a24Mc = Functions.belowten' g_a24Mb
                            (g_a24Mb, gpart_a24Os) = Genome.Split.split gpart_a24Or
                            p_a24Ma = double g_a24M9
                            (g_a24M9, gpart_a24Or) = Genome.Split.split gpart_a24Oq
                            p_a24M8 = double g_a24M7
                            (g_a24M7, gpart_a24Oq) = Genome.Split.split gpart_a24Op
                            p_a24M6 = double g_a24M5
                            (g_a24M5, gpart_a24Op) = Genome.Split.split gpart_a24Oo
                            p_a24M4 = double g_a24M3
                            (g_a24M3, gpart_a24Oo) = Genome.Split.split gpart_a24On
                            p_a24M2 = double g_a24M1
                            (g_a24M1, gpart_a24On) = Genome.Split.split gpart_a24Om
                            p_a24M0 = double g_a24LZ
                            (g_a24LZ, gpart_a24Om) = Genome.Split.split genome_a24Nj
                          in
                            \ desc_a24Nk
                              -> case desc_a24Nk of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M0)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M2)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M4)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M6)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24M8)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ma)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mc)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Me)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mg)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mi)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mk)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mm)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mo)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mq)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ms)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mu)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Mw)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24My)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ME)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MS)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MU)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24MY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N4)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N6)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24N8)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Na)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nc)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ne)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ng)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ni)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asTQ
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUw
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                      (g_asTK, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                      (g_asTI, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                      (g_asTG, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTF = Functions.belowten' g_asTE
                      (g_asTE, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                      (g_asTC, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                      (g_asTA, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                      (g_asTy, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asTx = Functions.belowten' g_asTw
                      (g_asTw, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                      (g_asTu, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asTt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTs
                      (g_asTs, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asTr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTq
                      (g_asTq, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asTp = Functions.belowten' g_asTo
                      (g_asTo, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                      (g_asTm, gpart_asUi) = Genome.Split.split gpart_asUh
                      p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                      (g_asTk, gpart_asUh) = Genome.Split.split gpart_asUg
                      p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                      (g_asTi, gpart_asUg) = Genome.Split.split gpart_asUf
                      p_asTh = Functions.belowten' g_asTg
                      (g_asTg, gpart_asUf) = Genome.Split.split gpart_asUe
                      p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                      (g_asTe, gpart_asUe) = Genome.Split.split gpart_asUd
                      p_asTd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTc
                      (g_asTc, gpart_asUd) = Genome.Split.split gpart_asUc
                      p_asTb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTa
                      (g_asTa, gpart_asUc) = Genome.Split.split gpart_asUb
                      p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                      (g_asT8, gpart_asUb) = Genome.Split.split gpart_asUa
                      p_asT7 = Functions.belowten' g_asT6
                      (g_asT6, gpart_asUa) = Genome.Split.split gpart_asU9
                      p_asT5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT4
                      (g_asT4, gpart_asU9) = Genome.Split.split gpart_asU8
                      p_asT3 = Functions.belowten' g_asT2
                      (g_asT2, gpart_asU8) = Genome.Split.split gpart_asU7
                      p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                      (g_asT0, gpart_asU7) = Genome.Split.split gpart_asU6
                      p_asSZ = Functions.belowten' g_asSY
                      (g_asSY, gpart_asU6) = Genome.Split.split gpart_asU5
                      p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                      (g_asSW, gpart_asU5) = Genome.Split.split gpart_asU4
                      p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                      (g_asSU, gpart_asU4) = Genome.Split.split gpart_asU3
                      p_asST = code-0.1.0.0:Genome.FixedList.Functions.double g_asSS
                      (g_asSS, gpart_asU3) = Genome.Split.split gpart_asU2
                      p_asSR = Functions.belowten' g_asSQ
                      (g_asSQ, gpart_asU2) = Genome.Split.split gpart_asU1
                      p_asSP = code-0.1.0.0:Genome.FixedList.Functions.double g_asSO
                      (g_asSO, gpart_asU1) = Genome.Split.split gpart_asU0
                      p_asSN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSM
                      (g_asSM, gpart_asU0) = Genome.Split.split gpart_asTZ
                      p_asSL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSK
                      (g_asSK, gpart_asTZ) = Genome.Split.split gpart_asTY
                      p_asSJ = Functions.belowten' g_asSI
                      (g_asSI, gpart_asTY) = Genome.Split.split gpart_asTX
                      p_asSH = code-0.1.0.0:Genome.FixedList.Functions.double g_asSG
                      (g_asSG, gpart_asTX) = Genome.Split.split gpart_asTW
                      p_asSF = code-0.1.0.0:Genome.FixedList.Functions.double g_asSE
                      (g_asSE, gpart_asTW) = Genome.Split.split gpart_asTV
                      p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                      (g_asSC, gpart_asTV) = Genome.Split.split gpart_asTU
                      p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                      (g_asSA, gpart_asTU) = Genome.Split.split gpart_asTT
                      p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                      (g_asSy, gpart_asTT) = Genome.Split.split gpart_asTS
                      p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                      (g_asSw, gpart_asTS) = Genome.Split.split genome_asTQ
                    in
                      [Reaction
                         (\ x_asUx
                            -> let
                                 c_MiRs_asUA = ((toVector x_asUx) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asUy = ((toVector x_asUx) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asSF
                                  * ((p_asST + ((c_NPTB_asUy / p_asSH) ** p_asSJ))
                                     / (((1 + p_asST) + ((c_NPTB_asUy / p_asSH) ** p_asSJ))
                                        + ((c_MiRs_asUA / p_asSP) ** p_asSR)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUB
                            -> let
                                 c_MiRs_asUD = ((toVector x_asUB) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asUC = ((toVector x_asUB) Data.Vector.Unboxed.! 3)
                                 c_PTB_asUE = ((toVector x_asUB) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asSV
                                  / (1
                                     + ((((c_RESTc_asUC / p_asSX) ** p_asSZ)
                                         + ((c_MiRs_asUD / p_asT1) ** p_asT3))
                                        + ((c_PTB_asUE / p_asT5) ** p_asT7)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUF
                            -> let c_RESTc_asUG = ((toVector x_asUF) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asT9
                                  * ((p_asTj + ((p_asSB / p_asTb) ** p_asTd))
                                     / (((1 + p_asTj) + ((p_asSB / p_asTb) ** p_asTd))
                                        + ((c_RESTc_asUG / p_asTf) ** p_asTh)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUH
                            -> let
                                 c_MiRs_asUK = ((toVector x_asUH) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUI = ((toVector x_asUH) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTl
                                  * ((p_asTz + ((c_PTB_asUI / p_asTn) ** p_asTp))
                                     / (((1 + p_asTz) + ((c_PTB_asUI / p_asTn) ** p_asTp))
                                        + (((p_asSx / p_asTr) ** p_asTt)
                                           + ((c_MiRs_asUK / p_asTv) ** p_asTx))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asUL
                            -> let c_RESTc_asUM = ((toVector x_asUL) Data.Vector.Unboxed.! 3)
                               in (p_asTB / (1 + ((c_RESTc_asUM / p_asTD) ** p_asTF))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asUN
                            -> let c_PTB_asUO = ((toVector x_asUN) Data.Vector.Unboxed.! 0)
                               in (p_asTH * c_PTB_asUO))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUP
                            -> let c_NPTB_asUQ = ((toVector x_asUP) Data.Vector.Unboxed.! 1)
                               in (p_asTJ * c_NPTB_asUQ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asUR
                            -> let c_MiRs_asUS = ((toVector x_asUR) Data.Vector.Unboxed.! 2)
                               in (p_asTL * c_MiRs_asUS))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asUT
                            -> let c_RESTc_asUU = ((toVector x_asUT) Data.Vector.Unboxed.! 3)
                               in (p_asTN * c_RESTc_asUU))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asUV
                            -> let
                                 c_EndoNeuroTFs_asUW = ((toVector x_asUV) Data.Vector.Unboxed.! 4)
                               in (p_asTP * c_EndoNeuroTFs_asUW))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120819",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120821",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120845",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120847",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120863",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asTQ
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVG
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                            (g_asTK, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                            (g_asTI, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                            (g_asTG, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asTF = Functions.belowten' g_asTE
                            (g_asTE, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                            (g_asTC, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                            (g_asTA, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                            (g_asTy, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asTx = Functions.belowten' g_asTw
                            (g_asTw, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                            (g_asTu, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asTt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTs
                            (g_asTs, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asTr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTq
                            (g_asTq, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asTp = Functions.belowten' g_asTo
                            (g_asTo, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                            (g_asTm, gpart_asVs) = Genome.Split.split gpart_asVr
                            p_asTl = code-0.1.0.0:Genome.FixedList.Functions.double g_asTk
                            (g_asTk, gpart_asVr) = Genome.Split.split gpart_asVq
                            p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                            (g_asTi, gpart_asVq) = Genome.Split.split gpart_asVp
                            p_asTh = Functions.belowten' g_asTg
                            (g_asTg, gpart_asVp) = Genome.Split.split gpart_asVo
                            p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                            (g_asTe, gpart_asVo) = Genome.Split.split gpart_asVn
                            p_asTd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTc
                            (g_asTc, gpart_asVn) = Genome.Split.split gpart_asVm
                            p_asTb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTa
                            (g_asTa, gpart_asVm) = Genome.Split.split gpart_asVl
                            p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                            (g_asT8, gpart_asVl) = Genome.Split.split gpart_asVk
                            p_asT7 = Functions.belowten' g_asT6
                            (g_asT6, gpart_asVk) = Genome.Split.split gpart_asVj
                            p_asT5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT4
                            (g_asT4, gpart_asVj) = Genome.Split.split gpart_asVi
                            p_asT3 = Functions.belowten' g_asT2
                            (g_asT2, gpart_asVi) = Genome.Split.split gpart_asVh
                            p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                            (g_asT0, gpart_asVh) = Genome.Split.split gpart_asVg
                            p_asSZ = Functions.belowten' g_asSY
                            (g_asSY, gpart_asVg) = Genome.Split.split gpart_asVf
                            p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                            (g_asSW, gpart_asVf) = Genome.Split.split gpart_asVe
                            p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                            (g_asSU, gpart_asVe) = Genome.Split.split gpart_asVd
                            p_asST = code-0.1.0.0:Genome.FixedList.Functions.double g_asSS
                            (g_asSS, gpart_asVd) = Genome.Split.split gpart_asVc
                            p_asSR = Functions.belowten' g_asSQ
                            (g_asSQ, gpart_asVc) = Genome.Split.split gpart_asVb
                            p_asSP = code-0.1.0.0:Genome.FixedList.Functions.double g_asSO
                            (g_asSO, gpart_asVb) = Genome.Split.split gpart_asVa
                            p_asSN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSM
                            (g_asSM, gpart_asVa) = Genome.Split.split gpart_asV9
                            p_asSL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSK
                            (g_asSK, gpart_asV9) = Genome.Split.split gpart_asV8
                            p_asSJ = Functions.belowten' g_asSI
                            (g_asSI, gpart_asV8) = Genome.Split.split gpart_asV7
                            p_asSH = code-0.1.0.0:Genome.FixedList.Functions.double g_asSG
                            (g_asSG, gpart_asV7) = Genome.Split.split gpart_asV6
                            p_asSF = code-0.1.0.0:Genome.FixedList.Functions.double g_asSE
                            (g_asSE, gpart_asV6) = Genome.Split.split gpart_asV5
                            p_asSD = code-0.1.0.0:Genome.FixedList.Functions.double g_asSC
                            (g_asSC, gpart_asV5) = Genome.Split.split gpart_asV4
                            p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                            (g_asSA, gpart_asV4) = Genome.Split.split gpart_asV3
                            p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                            (g_asSy, gpart_asV3) = Genome.Split.split gpart_asV2
                            p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                            (g_asSw, gpart_asV2) = Genome.Split.split genome_asTQ
                          in
                            \ desc_asTR
                              -> case desc_asTR of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSx)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSz)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSB)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSD)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSF)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSH)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSJ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSL)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSN)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSP)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSR)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asST)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSV)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSX)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSZ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT1)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT3)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT5)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT7)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT9)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTb)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTd)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTf)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTh)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTj)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTl)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTt)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asXH
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYn
                      p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                      (g_asXF, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                      (g_asXD, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                      (g_asXz, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                      (g_asXx, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asXw = Functions.belowten' g_asXv
                      (g_asXv, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                      (g_asXt, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                      (g_asXr, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asXq = code-0.1.0.0:Genome.FixedList.Functions.double g_asXp
                      (g_asXp, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asXo = Functions.belowten' g_asXn
                      (g_asXn, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                      (g_asXl, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asXk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXj
                      (g_asXj, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asXi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXh
                      (g_asXh, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asXg = Functions.belowten' g_asXf
                      (g_asXf, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                      (g_asXd, gpart_asY9) = Genome.Split.split gpart_asY8
                      p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                      (g_asXb, gpart_asY8) = Genome.Split.split gpart_asY7
                      p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                      (g_asX9, gpart_asY7) = Genome.Split.split gpart_asY6
                      p_asX8 = Functions.belowten' g_asX7
                      (g_asX7, gpart_asY6) = Genome.Split.split gpart_asY5
                      p_asX6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX5
                      (g_asX5, gpart_asY5) = Genome.Split.split gpart_asY4
                      p_asX4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                      (g_asX3, gpart_asY4) = Genome.Split.split gpart_asY3
                      p_asX2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX1
                      (g_asX1, gpart_asY3) = Genome.Split.split gpart_asY2
                      p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                      (g_asWZ, gpart_asY2) = Genome.Split.split gpart_asY1
                      p_asWY = Functions.belowten' g_asWX
                      (g_asWX, gpart_asY1) = Genome.Split.split gpart_asY0
                      p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                      (g_asWV, gpart_asY0) = Genome.Split.split gpart_asXZ
                      p_asWU = Functions.belowten' g_asWT
                      (g_asWT, gpart_asXZ) = Genome.Split.split gpart_asXY
                      p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                      (g_asWR, gpart_asXY) = Genome.Split.split gpart_asXX
                      p_asWQ = Functions.belowten' g_asWP
                      (g_asWP, gpart_asXX) = Genome.Split.split gpart_asXW
                      p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                      (g_asWN, gpart_asXW) = Genome.Split.split gpart_asXV
                      p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                      (g_asWL, gpart_asXV) = Genome.Split.split gpart_asXU
                      p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                      (g_asWJ, gpart_asXU) = Genome.Split.split gpart_asXT
                      p_asWI = Functions.belowten' g_asWH
                      (g_asWH, gpart_asXT) = Genome.Split.split gpart_asXS
                      p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                      (g_asWF, gpart_asXS) = Genome.Split.split gpart_asXR
                      p_asWE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWD
                      (g_asWD, gpart_asXR) = Genome.Split.split gpart_asXQ
                      p_asWC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWB
                      (g_asWB, gpart_asXQ) = Genome.Split.split gpart_asXP
                      p_asWA = Functions.belowten' g_asWz
                      (g_asWz, gpart_asXP) = Genome.Split.split gpart_asXO
                      p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                      (g_asWx, gpart_asXO) = Genome.Split.split gpart_asXN
                      p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                      (g_asWv, gpart_asXN) = Genome.Split.split gpart_asXM
                      p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                      (g_asWt, gpart_asXM) = Genome.Split.split gpart_asXL
                      p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                      (g_asWr, gpart_asXL) = Genome.Split.split gpart_asXK
                      p_asWq = code-0.1.0.0:Genome.FixedList.Functions.double g_asWp
                      (g_asWp, gpart_asXK) = Genome.Split.split gpart_asXJ
                      p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                      (g_asWn, gpart_asXJ) = Genome.Split.split genome_asXH
                    in
                      [Reaction
                         (\ x_asYo
                            -> let
                                 c_MiRs_asYr = ((toVector x_asYo) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asYp = ((toVector x_asYo) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asWw
                                  * ((p_asWK + ((c_NPTB_asYp / p_asWy) ** p_asWA))
                                     / (((1 + p_asWK) + ((c_NPTB_asYp / p_asWy) ** p_asWA))
                                        + ((c_MiRs_asYr / p_asWG) ** p_asWI)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYs
                            -> let
                                 c_MiRs_asYu = ((toVector x_asYs) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asYt = ((toVector x_asYs) Data.Vector.Unboxed.! 3)
                                 c_PTB_asYv = ((toVector x_asYs) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWM
                                  / (1
                                     + ((((c_RESTc_asYt / p_asWO) ** p_asWQ)
                                         + ((c_MiRs_asYu / p_asWS) ** p_asWU))
                                        + ((c_PTB_asYv / p_asWW) ** p_asWY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYw
                            -> let c_RESTc_asYx = ((toVector x_asYw) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asX0
                                  * (p_asXa
                                     / ((1 + p_asXa) + ((c_RESTc_asYx / p_asX6) ** p_asX8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYy
                            -> let
                                 c_MiRs_asYB = ((toVector x_asYy) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYz = ((toVector x_asYy) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXc
                                  * ((p_asXq + ((c_PTB_asYz / p_asXe) ** p_asXg))
                                     / (((1 + p_asXq) + ((c_PTB_asYz / p_asXe) ** p_asXg))
                                        + (((p_asWo / p_asXi) ** p_asXk)
                                           + ((c_MiRs_asYB / p_asXm) ** p_asXo))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asYC
                            -> let c_RESTc_asYD = ((toVector x_asYC) Data.Vector.Unboxed.! 3)
                               in (p_asXs / (1 + ((c_RESTc_asYD / p_asXu) ** p_asXw))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asYE
                            -> let c_PTB_asYF = ((toVector x_asYE) Data.Vector.Unboxed.! 0)
                               in (p_asXy * c_PTB_asYF))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYG
                            -> let c_NPTB_asYH = ((toVector x_asYG) Data.Vector.Unboxed.! 1)
                               in (p_asXA * c_NPTB_asYH))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asYI
                            -> let c_MiRs_asYJ = ((toVector x_asYI) Data.Vector.Unboxed.! 2)
                               in (p_asXC * c_MiRs_asYJ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asYK
                            -> let c_RESTc_asYL = ((toVector x_asYK) Data.Vector.Unboxed.! 3)
                               in (p_asXE * c_RESTc_asYL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asYM
                            -> let
                                 c_EndoNeuroTFs_asYN = ((toVector x_asYM) Data.Vector.Unboxed.! 4)
                               in (p_asXG * c_EndoNeuroTFs_asYN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121058",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121060",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121084",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121086",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121088",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121090",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121100",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121102",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121108",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asXH
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZs
                            p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                            (g_asXF, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                            (g_asXD, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                            (g_asXz, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                            (g_asXx, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asXw = Functions.belowten' g_asXv
                            (g_asXv, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asXu = code-0.1.0.0:Genome.FixedList.Functions.double g_asXt
                            (g_asXt, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                            (g_asXr, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asXq = code-0.1.0.0:Genome.FixedList.Functions.double g_asXp
                            (g_asXp, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asXo = Functions.belowten' g_asXn
                            (g_asXn, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                            (g_asXl, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asXk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXj
                            (g_asXj, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asXi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXh
                            (g_asXh, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asXg = Functions.belowten' g_asXf
                            (g_asXf, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                            (g_asXd, gpart_asZe) = Genome.Split.split gpart_asZd
                            p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                            (g_asXb, gpart_asZd) = Genome.Split.split gpart_asZc
                            p_asXa = code-0.1.0.0:Genome.FixedList.Functions.double g_asX9
                            (g_asX9, gpart_asZc) = Genome.Split.split gpart_asZb
                            p_asX8 = Functions.belowten' g_asX7
                            (g_asX7, gpart_asZb) = Genome.Split.split gpart_asZa
                            p_asX6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX5
                            (g_asX5, gpart_asZa) = Genome.Split.split gpart_asZ9
                            p_asX4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                            (g_asX3, gpart_asZ9) = Genome.Split.split gpart_asZ8
                            p_asX2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX1
                            (g_asX1, gpart_asZ8) = Genome.Split.split gpart_asZ7
                            p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                            (g_asWZ, gpart_asZ7) = Genome.Split.split gpart_asZ6
                            p_asWY = Functions.belowten' g_asWX
                            (g_asWX, gpart_asZ6) = Genome.Split.split gpart_asZ5
                            p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                            (g_asWV, gpart_asZ5) = Genome.Split.split gpart_asZ4
                            p_asWU = Functions.belowten' g_asWT
                            (g_asWT, gpart_asZ4) = Genome.Split.split gpart_asZ3
                            p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                            (g_asWR, gpart_asZ3) = Genome.Split.split gpart_asZ2
                            p_asWQ = Functions.belowten' g_asWP
                            (g_asWP, gpart_asZ2) = Genome.Split.split gpart_asZ1
                            p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                            (g_asWN, gpart_asZ1) = Genome.Split.split gpart_asZ0
                            p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                            (g_asWL, gpart_asZ0) = Genome.Split.split gpart_asYZ
                            p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                            (g_asWJ, gpart_asYZ) = Genome.Split.split gpart_asYY
                            p_asWI = Functions.belowten' g_asWH
                            (g_asWH, gpart_asYY) = Genome.Split.split gpart_asYX
                            p_asWG = code-0.1.0.0:Genome.FixedList.Functions.double g_asWF
                            (g_asWF, gpart_asYX) = Genome.Split.split gpart_asYW
                            p_asWE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWD
                            (g_asWD, gpart_asYW) = Genome.Split.split gpart_asYV
                            p_asWC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWB
                            (g_asWB, gpart_asYV) = Genome.Split.split gpart_asYU
                            p_asWA = Functions.belowten' g_asWz
                            (g_asWz, gpart_asYU) = Genome.Split.split gpart_asYT
                            p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                            (g_asWx, gpart_asYT) = Genome.Split.split gpart_asYS
                            p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                            (g_asWv, gpart_asYS) = Genome.Split.split gpart_asYR
                            p_asWu = code-0.1.0.0:Genome.FixedList.Functions.double g_asWt
                            (g_asWt, gpart_asYR) = Genome.Split.split gpart_asYQ
                            p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                            (g_asWr, gpart_asYQ) = Genome.Split.split gpart_asYP
                            p_asWq = code-0.1.0.0:Genome.FixedList.Functions.double g_asWp
                            (g_asWp, gpart_asYP) = Genome.Split.split gpart_asYO
                            p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                            (g_asWn, gpart_asYO) = Genome.Split.split genome_asXH
                          in
                            \ desc_asXI
                              -> case desc_asXI of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWo)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWq)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWs)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWu)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWw)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWy)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWA)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWC)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWE)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWG)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWI)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWK)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWM)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWQ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWS)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWU)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWW)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWY)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX0)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX2)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX4)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX6)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX8)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXa)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXc)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXe)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXg)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXi)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXk)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXm)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXo)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXq)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXs)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXu)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXw)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1t
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at29
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at29) = Genome.Split.split gpart_at28
                      p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                      (g_at1p, gpart_at28) = Genome.Split.split gpart_at27
                      p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                      (g_at1n, gpart_at27) = Genome.Split.split gpart_at26
                      p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                      (g_at1l, gpart_at26) = Genome.Split.split gpart_at25
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at25) = Genome.Split.split gpart_at24
                      p_at1i = Functions.belowten' g_at1h
                      (g_at1h, gpart_at24) = Genome.Split.split gpart_at23
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at23) = Genome.Split.split gpart_at22
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at22) = Genome.Split.split gpart_at21
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at21) = Genome.Split.split gpart_at20
                      p_at1a = Functions.belowten' g_at19
                      (g_at19, gpart_at20) = Genome.Split.split gpart_at1Z
                      p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                      (g_at17, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at16
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at15
                      (g_at15, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at14
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at13
                      (g_at13, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at12 = Functions.belowten' g_at11
                      (g_at11, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                      (g_at0Z, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                      (g_at0X, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                      (g_at0V, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at0U = Functions.belowten' g_at0T
                      (g_at0T, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                      (g_at0R, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at0Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0P
                      (g_at0P, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at0O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0N
                      (g_at0N, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                      (g_at0L, gpart_at1O) = Genome.Split.split gpart_at1N
                      p_at0K = Functions.belowten' g_at0J
                      (g_at0J, gpart_at1N) = Genome.Split.split gpart_at1M
                      p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                      (g_at0H, gpart_at1M) = Genome.Split.split gpart_at1L
                      p_at0G = Functions.belowten' g_at0F
                      (g_at0F, gpart_at1L) = Genome.Split.split gpart_at1K
                      p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                      (g_at0D, gpart_at1K) = Genome.Split.split gpart_at1J
                      p_at0C = Functions.belowten' g_at0B
                      (g_at0B, gpart_at1J) = Genome.Split.split gpart_at1I
                      p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                      (g_at0z, gpart_at1I) = Genome.Split.split gpart_at1H
                      p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                      (g_at0x, gpart_at1H) = Genome.Split.split gpart_at1G
                      p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                      (g_at0v, gpart_at1G) = Genome.Split.split gpart_at1F
                      p_at0u = Functions.belowten' g_at0t
                      (g_at0t, gpart_at1F) = Genome.Split.split gpart_at1E
                      p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                      (g_at0r, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0p
                      (g_at0p, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0n
                      (g_at0n, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0m = Functions.belowten' g_at0l
                      (g_at0l, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                      (g_at0j, gpart_at1A) = Genome.Split.split gpart_at1z
                      p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                      (g_at0h, gpart_at1z) = Genome.Split.split gpart_at1y
                      p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                      (g_at0f, gpart_at1y) = Genome.Split.split gpart_at1x
                      p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                      (g_at0d, gpart_at1x) = Genome.Split.split gpart_at1w
                      p_at0c = code-0.1.0.0:Genome.FixedList.Functions.double g_at0b
                      (g_at0b, gpart_at1w) = Genome.Split.split gpart_at1v
                      p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                      (g_at09, gpart_at1v) = Genome.Split.split genome_at1t
                    in
                      [Reaction
                         (\ x_at2a
                            -> let
                                 c_MiRs_at2d = ((toVector x_at2a) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at2b = ((toVector x_at2a) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at0i
                                  * ((p_at0w + ((c_NPTB_at2b / p_at0k) ** p_at0m))
                                     / (((1 + p_at0w) + ((c_NPTB_at2b / p_at0k) ** p_at0m))
                                        + ((c_MiRs_at2d / p_at0s) ** p_at0u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2e
                            -> let
                                 c_MiRs_at2g = ((toVector x_at2e) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at2f = ((toVector x_at2e) Data.Vector.Unboxed.! 3)
                                 c_PTB_at2h = ((toVector x_at2e) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0y
                                  / (1
                                     + ((((c_RESTc_at2f / p_at0A) ** p_at0C)
                                         + ((c_MiRs_at2g / p_at0E) ** p_at0G))
                                        + ((c_PTB_at2h / p_at0I) ** p_at0K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2i
                            -> let c_RESTc_at2j = ((toVector x_at2i) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at0M
                                  * (p_at0W
                                     / ((1 + p_at0W) + ((c_RESTc_at2j / p_at0S) ** p_at0U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2k
                            -> let
                                 c_MiRs_at2n = ((toVector x_at2k) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2l = ((toVector x_at2k) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0Y
                                  * ((p_at1c + ((c_PTB_at2l / p_at10) ** p_at12))
                                     / (((1 + p_at1c) + ((c_PTB_at2l / p_at10) ** p_at12))
                                        + ((c_MiRs_at2n / p_at18) ** p_at1a)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2o
                            -> let c_RESTc_at2p = ((toVector x_at2o) Data.Vector.Unboxed.! 3)
                               in (p_at1e / (1 + ((c_RESTc_at2p / p_at1g) ** p_at1i))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2q
                            -> let c_PTB_at2r = ((toVector x_at2q) Data.Vector.Unboxed.! 0)
                               in (p_at1k * c_PTB_at2r))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2s
                            -> let c_NPTB_at2t = ((toVector x_at2s) Data.Vector.Unboxed.! 1)
                               in (p_at1m * c_NPTB_at2t))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2u
                            -> let c_MiRs_at2v = ((toVector x_at2u) Data.Vector.Unboxed.! 2)
                               in (p_at1o * c_MiRs_at2v))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2w
                            -> let c_RESTc_at2x = ((toVector x_at2w) Data.Vector.Unboxed.! 3)
                               in (p_at1q * c_RESTc_at2x))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2y
                            -> let
                                 c_EndoNeuroTFs_at2z = ((toVector x_at2y) Data.Vector.Unboxed.! 4)
                               in (p_at1s * c_EndoNeuroTFs_at2z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121318",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1t
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3e
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                            (g_at1p, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                            (g_at1n, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                            (g_at1l, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at1i = Functions.belowten' g_at1h
                            (g_at1h, gpart_at39) = Genome.Split.split gpart_at38
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at38) = Genome.Split.split gpart_at37
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at37) = Genome.Split.split gpart_at36
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at36) = Genome.Split.split gpart_at35
                            p_at1a = Functions.belowten' g_at19
                            (g_at19, gpart_at35) = Genome.Split.split gpart_at34
                            p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                            (g_at17, gpart_at34) = Genome.Split.split gpart_at33
                            p_at16
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at15
                            (g_at15, gpart_at33) = Genome.Split.split gpart_at32
                            p_at14
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at13
                            (g_at13, gpart_at32) = Genome.Split.split gpart_at31
                            p_at12 = Functions.belowten' g_at11
                            (g_at11, gpart_at31) = Genome.Split.split gpart_at30
                            p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                            (g_at0Z, gpart_at30) = Genome.Split.split gpart_at2Z
                            p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                            (g_at0X, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                            (g_at0V, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at0U = Functions.belowten' g_at0T
                            (g_at0T, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                            (g_at0R, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at0Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0P
                            (g_at0P, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at0O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0N
                            (g_at0N, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                            (g_at0L, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at0K = Functions.belowten' g_at0J
                            (g_at0J, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                            (g_at0H, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at0G = Functions.belowten' g_at0F
                            (g_at0F, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at0E = code-0.1.0.0:Genome.FixedList.Functions.double g_at0D
                            (g_at0D, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0C = Functions.belowten' g_at0B
                            (g_at0B, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0A = code-0.1.0.0:Genome.FixedList.Functions.double g_at0z
                            (g_at0z, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0x
                            (g_at0x, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0w = code-0.1.0.0:Genome.FixedList.Functions.double g_at0v
                            (g_at0v, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0u = Functions.belowten' g_at0t
                            (g_at0t, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                            (g_at0r, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0p
                            (g_at0p, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0n
                            (g_at0n, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0m = Functions.belowten' g_at0l
                            (g_at0l, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                            (g_at0j, gpart_at2F) = Genome.Split.split gpart_at2E
                            p_at0i = code-0.1.0.0:Genome.FixedList.Functions.double g_at0h
                            (g_at0h, gpart_at2E) = Genome.Split.split gpart_at2D
                            p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                            (g_at0f, gpart_at2D) = Genome.Split.split gpart_at2C
                            p_at0e = code-0.1.0.0:Genome.FixedList.Functions.double g_at0d
                            (g_at0d, gpart_at2C) = Genome.Split.split gpart_at2B
                            p_at0c = code-0.1.0.0:Genome.FixedList.Functions.double g_at0b
                            (g_at0b, gpart_at2B) = Genome.Split.split gpart_at2A
                            p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                            (g_at09, gpart_at2A) = Genome.Split.split genome_at1t
                          in
                            \ desc_at1u
                              -> case desc_at1u of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0w)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0y)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0A)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0C)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0E)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0G)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0M)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0O)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0W)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Y)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at10)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5f
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5V
                      p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                      (g_at5d, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                      (g_at5b, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                      (g_at59, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at58 = code-0.1.0.0:Genome.FixedList.Functions.double g_at57
                      (g_at57, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                      (g_at55, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at54 = Functions.belowten' g_at53
                      (g_at53, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                      (g_at51, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at50 = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Z
                      (g_at4Z, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                      (g_at4X, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4W = Functions.belowten' g_at4V
                      (g_at4V, gpart_at5M) = Genome.Split.split gpart_at5L
                      p_at4U = code-0.1.0.0:Genome.FixedList.Functions.double g_at4T
                      (g_at4T, gpart_at5L) = Genome.Split.split gpart_at5K
                      p_at4S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4R
                      (g_at4R, gpart_at5K) = Genome.Split.split gpart_at5J
                      p_at4Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4P
                      (g_at4P, gpart_at5J) = Genome.Split.split gpart_at5I
                      p_at4O = Functions.belowten' g_at4N
                      (g_at4N, gpart_at5I) = Genome.Split.split gpart_at5H
                      p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                      (g_at4L, gpart_at5H) = Genome.Split.split gpart_at5G
                      p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                      (g_at4J, gpart_at5G) = Genome.Split.split gpart_at5F
                      p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                      (g_at4H, gpart_at5F) = Genome.Split.split gpart_at5E
                      p_at4G = Functions.belowten' g_at4F
                      (g_at4F, gpart_at5E) = Genome.Split.split gpart_at5D
                      p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                      (g_at4D, gpart_at5D) = Genome.Split.split gpart_at5C
                      p_at4C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4B
                      (g_at4B, gpart_at5C) = Genome.Split.split gpart_at5B
                      p_at4A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                      (g_at4z, gpart_at5B) = Genome.Split.split gpart_at5A
                      p_at4y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4x
                      (g_at4x, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4w = Functions.belowten' g_at4v
                      (g_at4v, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                      (g_at4t, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4s = Functions.belowten' g_at4r
                      (g_at4r, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                      (g_at4p, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4o = Functions.belowten' g_at4n
                      (g_at4n, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                      (g_at4l, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4k = code-0.1.0.0:Genome.FixedList.Functions.double g_at4j
                      (g_at4j, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                      (g_at4h, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4g = Functions.belowten' g_at4f
                      (g_at4f, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4e = code-0.1.0.0:Genome.FixedList.Functions.double g_at4d
                      (g_at4d, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4b
                      (g_at4b, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at49
                      (g_at49, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at48 = Functions.belowten' g_at47
                      (g_at47, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                      (g_at45, gpart_at5m) = Genome.Split.split gpart_at5l
                      p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                      (g_at43, gpart_at5l) = Genome.Split.split gpart_at5k
                      p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                      (g_at41, gpart_at5k) = Genome.Split.split gpart_at5j
                      p_at40 = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Z
                      (g_at3Z, gpart_at5j) = Genome.Split.split gpart_at5i
                      p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                      (g_at3X, gpart_at5i) = Genome.Split.split gpart_at5h
                      p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                      (g_at3V, gpart_at5h) = Genome.Split.split genome_at5f
                    in
                      [Reaction
                         (\ x_at5W
                            -> let
                                 c_MiRs_at5Z = ((toVector x_at5W) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at5X = ((toVector x_at5W) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at44
                                  * ((p_at4i + ((c_NPTB_at5X / p_at46) ** p_at48))
                                     / (((1 + p_at4i) + ((c_NPTB_at5X / p_at46) ** p_at48))
                                        + (((p_at3W / p_at4a) ** p_at4c)
                                           + ((c_MiRs_at5Z / p_at4e) ** p_at4g))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at60
                            -> let
                                 c_MiRs_at62 = ((toVector x_at60) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at61 = ((toVector x_at60) Data.Vector.Unboxed.! 3)
                                 c_PTB_at63 = ((toVector x_at60) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4k
                                  / (1
                                     + ((((c_RESTc_at61 / p_at4m) ** p_at4o)
                                         + ((c_MiRs_at62 / p_at4q) ** p_at4s))
                                        + ((c_PTB_at63 / p_at4u) ** p_at4w)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at64
                            -> let c_RESTc_at65 = ((toVector x_at64) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at4y
                                  * (p_at4I
                                     / ((1 + p_at4I) + ((c_RESTc_at65 / p_at4E) ** p_at4G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at66
                            -> let
                                 c_MiRs_at69 = ((toVector x_at66) Data.Vector.Unboxed.! 2)
                                 c_PTB_at67 = ((toVector x_at66) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4K
                                  * ((p_at4Y + ((c_PTB_at67 / p_at4M) ** p_at4O))
                                     / (((1 + p_at4Y) + ((c_PTB_at67 / p_at4M) ** p_at4O))
                                        + ((c_MiRs_at69 / p_at4U) ** p_at4W)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6a
                            -> let c_RESTc_at6b = ((toVector x_at6a) Data.Vector.Unboxed.! 3)
                               in (p_at50 / (1 + ((c_RESTc_at6b / p_at52) ** p_at54))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6c
                            -> let c_PTB_at6d = ((toVector x_at6c) Data.Vector.Unboxed.! 0)
                               in (p_at56 * c_PTB_at6d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6e
                            -> let c_NPTB_at6f = ((toVector x_at6e) Data.Vector.Unboxed.! 1)
                               in (p_at58 * c_NPTB_at6f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6g
                            -> let c_MiRs_at6h = ((toVector x_at6g) Data.Vector.Unboxed.! 2)
                               in (p_at5a * c_MiRs_at6h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6i
                            -> let c_RESTc_at6j = ((toVector x_at6i) Data.Vector.Unboxed.! 3)
                               in (p_at5c * c_RESTc_at6j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6k
                            -> let
                                 c_EndoNeuroTFs_at6l = ((toVector x_at6k) Data.Vector.Unboxed.! 4)
                               in (p_at5e * c_EndoNeuroTFs_at6l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121526",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121528",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121552",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121554",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121568",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121570",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5f
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at70
                            p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                            (g_at5d, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                            (g_at5b, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                            (g_at59, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at58 = code-0.1.0.0:Genome.FixedList.Functions.double g_at57
                            (g_at57, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                            (g_at55, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at54 = Functions.belowten' g_at53
                            (g_at53, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                            (g_at51, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at50 = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Z
                            (g_at4Z, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                            (g_at4X, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at4W = Functions.belowten' g_at4V
                            (g_at4V, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at4U = code-0.1.0.0:Genome.FixedList.Functions.double g_at4T
                            (g_at4T, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4R
                            (g_at4R, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4P
                            (g_at4P, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4O = Functions.belowten' g_at4N
                            (g_at4N, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                            (g_at4L, gpart_at6M) = Genome.Split.split gpart_at6L
                            p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                            (g_at4J, gpart_at6L) = Genome.Split.split gpart_at6K
                            p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                            (g_at4H, gpart_at6K) = Genome.Split.split gpart_at6J
                            p_at4G = Functions.belowten' g_at4F
                            (g_at4F, gpart_at6J) = Genome.Split.split gpart_at6I
                            p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                            (g_at4D, gpart_at6I) = Genome.Split.split gpart_at6H
                            p_at4C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4B
                            (g_at4B, gpart_at6H) = Genome.Split.split gpart_at6G
                            p_at4A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4z
                            (g_at4z, gpart_at6G) = Genome.Split.split gpart_at6F
                            p_at4y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4x
                            (g_at4x, gpart_at6F) = Genome.Split.split gpart_at6E
                            p_at4w = Functions.belowten' g_at4v
                            (g_at4v, gpart_at6E) = Genome.Split.split gpart_at6D
                            p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                            (g_at4t, gpart_at6D) = Genome.Split.split gpart_at6C
                            p_at4s = Functions.belowten' g_at4r
                            (g_at4r, gpart_at6C) = Genome.Split.split gpart_at6B
                            p_at4q = code-0.1.0.0:Genome.FixedList.Functions.double g_at4p
                            (g_at4p, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4o = Functions.belowten' g_at4n
                            (g_at4n, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4m = code-0.1.0.0:Genome.FixedList.Functions.double g_at4l
                            (g_at4l, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4k = code-0.1.0.0:Genome.FixedList.Functions.double g_at4j
                            (g_at4j, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4i = code-0.1.0.0:Genome.FixedList.Functions.double g_at4h
                            (g_at4h, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4g = Functions.belowten' g_at4f
                            (g_at4f, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4e = code-0.1.0.0:Genome.FixedList.Functions.double g_at4d
                            (g_at4d, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4b
                            (g_at4b, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at49
                            (g_at49, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at48 = Functions.belowten' g_at47
                            (g_at47, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at46 = code-0.1.0.0:Genome.FixedList.Functions.double g_at45
                            (g_at45, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at44 = code-0.1.0.0:Genome.FixedList.Functions.double g_at43
                            (g_at43, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at42 = code-0.1.0.0:Genome.FixedList.Functions.double g_at41
                            (g_at41, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at40 = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Z
                            (g_at3Z, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at3Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at3X
                            (g_at3X, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at3W = code-0.1.0.0:Genome.FixedList.Functions.double g_at3V
                            (g_at3V, gpart_at6m) = Genome.Split.split genome_at5f
                          in
                            \ desc_at5g
                              -> case desc_at5g of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3W)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Y)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at40)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at42)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at44)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at46)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at48)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4a)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4c)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4e)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4g)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4i)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4k)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4m)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4o)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4q)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4s)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4u)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4w)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4y)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4A)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4C)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4E)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4G)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4I)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4K)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4M)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4O)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Q)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4S)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4U)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4W)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Y)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at50)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at52)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at54)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at56)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at58)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5a)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5c)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5e)
                                   _ -> Nothing }}
