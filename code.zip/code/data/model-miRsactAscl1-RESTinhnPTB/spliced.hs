src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24KH
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Ln
                      p_a24KG = double g_a24KF
                      (g_a24KF, gpart_a24Ln) = Genome.Split.split gpart_a24Lm
                      p_a24KE = double g_a24KD
                      (g_a24KD, gpart_a24Lm) = Genome.Split.split gpart_a24Ll
                      p_a24KC = double g_a24KB
                      (g_a24KB, gpart_a24Ll) = Genome.Split.split gpart_a24Lk
                      p_a24KA = double g_a24Kz
                      (g_a24Kz, gpart_a24Lk) = Genome.Split.split gpart_a24Lj
                      p_a24Ky = double g_a24Kx
                      (g_a24Kx, gpart_a24Lj) = Genome.Split.split gpart_a24Li
                      p_a24Kw = double g_a24Kv
                      (g_a24Kv, gpart_a24Li) = Genome.Split.split gpart_a24Lh
                      p_a24Ku = Functions.belowten' g_a24Kt
                      (g_a24Kt, gpart_a24Lh) = Genome.Split.split gpart_a24Lg
                      p_a24Ks = double g_a24Kr
                      (g_a24Kr, gpart_a24Lg) = Genome.Split.split gpart_a24Lf
                      p_a24Kq = Functions.belowten' g_a24Kp
                      (g_a24Kp, gpart_a24Lf) = Genome.Split.split gpart_a24Le
                      p_a24Ko = double g_a24Kn
                      (g_a24Kn, gpart_a24Le) = Genome.Split.split gpart_a24Ld
                      p_a24Km = double g_a24Kl
                      (g_a24Kl, gpart_a24Ld) = Genome.Split.split gpart_a24Lc
                      p_a24Kk = double g_a24Kj
                      (g_a24Kj, gpart_a24Lc) = Genome.Split.split gpart_a24Lb
                      p_a24Ki = Functions.belowten' g_a24Kh
                      (g_a24Kh, gpart_a24Lb) = Genome.Split.split gpart_a24La
                      p_a24Kg = double g_a24Kf
                      (g_a24Kf, gpart_a24La) = Genome.Split.split gpart_a24L9
                      p_a24Ke
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kd
                      (g_a24Kd, gpart_a24L9) = Genome.Split.split gpart_a24L8
                      p_a24Kc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kb
                      (g_a24Kb, gpart_a24L8) = Genome.Split.split gpart_a24L7
                      p_a24Ka = Functions.belowten' g_a24K9
                      (g_a24K9, gpart_a24L7) = Genome.Split.split gpart_a24L6
                      p_a24K8 = double g_a24K7
                      (g_a24K7, gpart_a24L6) = Genome.Split.split gpart_a24L5
                      p_a24K6 = double g_a24K5
                      (g_a24K5, gpart_a24L5) = Genome.Split.split gpart_a24L4
                      p_a24K4 = double g_a24K3
                      (g_a24K3, gpart_a24L4) = Genome.Split.split gpart_a24L3
                      p_a24K2 = Functions.belowten' g_a24K1
                      (g_a24K1, gpart_a24L3) = Genome.Split.split gpart_a24L2
                      p_a24K0 = double g_a24JZ
                      (g_a24JZ, gpart_a24L2) = Genome.Split.split gpart_a24L1
                      p_a24JY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JX
                      (g_a24JX, gpart_a24L1) = Genome.Split.split gpart_a24L0
                      p_a24JW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JV
                      (g_a24JV, gpart_a24L0) = Genome.Split.split gpart_a24KZ
                      p_a24JU = double g_a24JT
                      (g_a24JT, gpart_a24KZ) = Genome.Split.split gpart_a24KY
                      p_a24JS = Functions.belowten' g_a24JR
                      (g_a24JR, gpart_a24KY) = Genome.Split.split gpart_a24KX
                      p_a24JQ = double g_a24JP
                      (g_a24JP, gpart_a24KX) = Genome.Split.split gpart_a24KW
                      p_a24JO = Functions.belowten' g_a24JN
                      (g_a24JN, gpart_a24KW) = Genome.Split.split gpart_a24KV
                      p_a24JM = double g_a24JL
                      (g_a24JL, gpart_a24KV) = Genome.Split.split gpart_a24KU
                      p_a24JK = Functions.belowten' g_a24JJ
                      (g_a24JJ, gpart_a24KU) = Genome.Split.split gpart_a24KT
                      p_a24JI = double g_a24JH
                      (g_a24JH, gpart_a24KT) = Genome.Split.split gpart_a24KS
                      p_a24JG = double g_a24JF
                      (g_a24JF, gpart_a24KS) = Genome.Split.split gpart_a24KR
                      p_a24JE = Functions.belowten' g_a24JD
                      (g_a24JD, gpart_a24KR) = Genome.Split.split gpart_a24KQ
                      p_a24JC = double g_a24JB
                      (g_a24JB, gpart_a24KQ) = Genome.Split.split gpart_a24KP
                      p_a24JA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jz
                      (g_a24Jz, gpart_a24KP) = Genome.Split.split gpart_a24KO
                      p_a24Jy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jx
                      (g_a24Jx, gpart_a24KO) = Genome.Split.split gpart_a24KN
                      p_a24Jw = double g_a24Jv
                      (g_a24Jv, gpart_a24KN) = Genome.Split.split gpart_a24KM
                      p_a24Ju = double g_a24Jt
                      (g_a24Jt, gpart_a24KM) = Genome.Split.split gpart_a24KL
                      p_a24Js = double g_a24Jr
                      (g_a24Jr, gpart_a24KL) = Genome.Split.split gpart_a24KK
                      p_a24Jq = double g_a24Jp
                      (g_a24Jp, gpart_a24KK) = Genome.Split.split gpart_a24KJ
                      p_a24Jo = double g_a24Jn
                      (g_a24Jn, gpart_a24KJ) = Genome.Split.split genome_a24KH
                    in  \ x_a24Lo
                          -> let
                               c_PTB_a24Lr
                                 = ((Data.Fixed.Vector.toVector x_a24Lo) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Lp
                                 = ((Data.Fixed.Vector.toVector x_a24Lo) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Lw
                                 = ((Data.Fixed.Vector.toVector x_a24Lo) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Ls
                                 = ((Data.Fixed.Vector.toVector x_a24Lo) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24LJ
                                 = ((Data.Fixed.Vector.toVector x_a24Lo) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Jw / (1 + ((c_MiRs_a24Lp / p_a24JC) ** p_a24JE)))
                                    + (negate (p_a24Ky * c_PTB_a24Lr))),
                                   ((p_a24JG
                                     / (1
                                        + ((((c_RESTc_a24Ls / p_a24JI) ** p_a24JK)
                                            + ((c_MiRs_a24Lp / p_a24JM) ** p_a24JO))
                                           + ((c_PTB_a24Lr / p_a24JQ) ** p_a24JS))))
                                    + (negate (p_a24KA * c_NPTB_a24Lw))),
                                   ((p_a24JU
                                     * ((p_a24K4 + ((p_a24Js / p_a24JW) ** p_a24JY))
                                        / (((1 + p_a24K4) + ((p_a24Js / p_a24JW) ** p_a24JY))
                                           + ((c_RESTc_a24Ls / p_a24K0) ** p_a24K2))))
                                    + (negate (p_a24KC * c_MiRs_a24Lp))),
                                   ((p_a24K6
                                     * ((p_a24Kk + ((c_PTB_a24Lr / p_a24K8) ** p_a24Ka))
                                        / (((1 + p_a24Kk) + ((c_PTB_a24Lr / p_a24K8) ** p_a24Ka))
                                           + (((p_a24Jo / p_a24Kc) ** p_a24Ke)
                                              + ((c_MiRs_a24Lp / p_a24Kg) ** p_a24Ki)))))
                                    + (negate (p_a24KE * c_RESTc_a24Ls))),
                                   ((p_a24Km
                                     * ((p_a24Kw + ((c_MiRs_a24Lp / p_a24Ko) ** p_a24Kq))
                                        / (((1 + p_a24Kw) + ((c_MiRs_a24Lp / p_a24Ko) ** p_a24Kq))
                                           + ((c_RESTc_a24Ls / p_a24Ks) ** p_a24Ku))))
                                    + (negate (p_a24KG * c_EndoNeuroTFs_a24LJ)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504648",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504650",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504672",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504674",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504688",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504690",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24KH
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Mo
                            p_a24KG = double g_a24KF
                            (g_a24KF, gpart_a24Mo) = Genome.Split.split gpart_a24Mn
                            p_a24KE = double g_a24KD
                            (g_a24KD, gpart_a24Mn) = Genome.Split.split gpart_a24Mm
                            p_a24KC = double g_a24KB
                            (g_a24KB, gpart_a24Mm) = Genome.Split.split gpart_a24Ml
                            p_a24KA = double g_a24Kz
                            (g_a24Kz, gpart_a24Ml) = Genome.Split.split gpart_a24Mk
                            p_a24Ky = double g_a24Kx
                            (g_a24Kx, gpart_a24Mk) = Genome.Split.split gpart_a24Mj
                            p_a24Kw = double g_a24Kv
                            (g_a24Kv, gpart_a24Mj) = Genome.Split.split gpart_a24Mi
                            p_a24Ku = Functions.belowten' g_a24Kt
                            (g_a24Kt, gpart_a24Mi) = Genome.Split.split gpart_a24Mh
                            p_a24Ks = double g_a24Kr
                            (g_a24Kr, gpart_a24Mh) = Genome.Split.split gpart_a24Mg
                            p_a24Kq = Functions.belowten' g_a24Kp
                            (g_a24Kp, gpart_a24Mg) = Genome.Split.split gpart_a24Mf
                            p_a24Ko = double g_a24Kn
                            (g_a24Kn, gpart_a24Mf) = Genome.Split.split gpart_a24Me
                            p_a24Km = double g_a24Kl
                            (g_a24Kl, gpart_a24Me) = Genome.Split.split gpart_a24Md
                            p_a24Kk = double g_a24Kj
                            (g_a24Kj, gpart_a24Md) = Genome.Split.split gpart_a24Mc
                            p_a24Ki = Functions.belowten' g_a24Kh
                            (g_a24Kh, gpart_a24Mc) = Genome.Split.split gpart_a24Mb
                            p_a24Kg = double g_a24Kf
                            (g_a24Kf, gpart_a24Mb) = Genome.Split.split gpart_a24Ma
                            p_a24Ke
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kd
                            (g_a24Kd, gpart_a24Ma) = Genome.Split.split gpart_a24M9
                            p_a24Kc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kb
                            (g_a24Kb, gpart_a24M9) = Genome.Split.split gpart_a24M8
                            p_a24Ka = Functions.belowten' g_a24K9
                            (g_a24K9, gpart_a24M8) = Genome.Split.split gpart_a24M7
                            p_a24K8 = double g_a24K7
                            (g_a24K7, gpart_a24M7) = Genome.Split.split gpart_a24M6
                            p_a24K6 = double g_a24K5
                            (g_a24K5, gpart_a24M6) = Genome.Split.split gpart_a24M5
                            p_a24K4 = double g_a24K3
                            (g_a24K3, gpart_a24M5) = Genome.Split.split gpart_a24M4
                            p_a24K2 = Functions.belowten' g_a24K1
                            (g_a24K1, gpart_a24M4) = Genome.Split.split gpart_a24M3
                            p_a24K0 = double g_a24JZ
                            (g_a24JZ, gpart_a24M3) = Genome.Split.split gpart_a24M2
                            p_a24JY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JX
                            (g_a24JX, gpart_a24M2) = Genome.Split.split gpart_a24M1
                            p_a24JW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JV
                            (g_a24JV, gpart_a24M1) = Genome.Split.split gpart_a24M0
                            p_a24JU = double g_a24JT
                            (g_a24JT, gpart_a24M0) = Genome.Split.split gpart_a24LZ
                            p_a24JS = Functions.belowten' g_a24JR
                            (g_a24JR, gpart_a24LZ) = Genome.Split.split gpart_a24LY
                            p_a24JQ = double g_a24JP
                            (g_a24JP, gpart_a24LY) = Genome.Split.split gpart_a24LX
                            p_a24JO = Functions.belowten' g_a24JN
                            (g_a24JN, gpart_a24LX) = Genome.Split.split gpart_a24LW
                            p_a24JM = double g_a24JL
                            (g_a24JL, gpart_a24LW) = Genome.Split.split gpart_a24LV
                            p_a24JK = Functions.belowten' g_a24JJ
                            (g_a24JJ, gpart_a24LV) = Genome.Split.split gpart_a24LU
                            p_a24JI = double g_a24JH
                            (g_a24JH, gpart_a24LU) = Genome.Split.split gpart_a24LT
                            p_a24JG = double g_a24JF
                            (g_a24JF, gpart_a24LT) = Genome.Split.split gpart_a24LS
                            p_a24JE = Functions.belowten' g_a24JD
                            (g_a24JD, gpart_a24LS) = Genome.Split.split gpart_a24LR
                            p_a24JC = double g_a24JB
                            (g_a24JB, gpart_a24LR) = Genome.Split.split gpart_a24LQ
                            p_a24JA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jz
                            (g_a24Jz, gpart_a24LQ) = Genome.Split.split gpart_a24LP
                            p_a24Jy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Jx
                            (g_a24Jx, gpart_a24LP) = Genome.Split.split gpart_a24LO
                            p_a24Jw = double g_a24Jv
                            (g_a24Jv, gpart_a24LO) = Genome.Split.split gpart_a24LN
                            p_a24Ju = double g_a24Jt
                            (g_a24Jt, gpart_a24LN) = Genome.Split.split gpart_a24LM
                            p_a24Js = double g_a24Jr
                            (g_a24Jr, gpart_a24LM) = Genome.Split.split gpart_a24LL
                            p_a24Jq = double g_a24Jp
                            (g_a24Jp, gpart_a24LL) = Genome.Split.split gpart_a24LK
                            p_a24Jo = double g_a24Jn
                            (g_a24Jn, gpart_a24LK) = Genome.Split.split genome_a24KH
                          in
                            \ desc_a24KI
                              -> case desc_a24KI of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jo)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jq)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Js)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ju)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jw)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Jy)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JA)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JC)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JE)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JG)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JI)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JK)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JM)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JO)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JQ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JS)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JU)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JW)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JY)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K0)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K2)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K4)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K6)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K8)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ka)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kc)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ke)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kg)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ki)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kk)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Km)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ko)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kq)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ks)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ku)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kw)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ky)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KA)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KC)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KE)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KG)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24OS
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Py
                      p_a24OR = double g_a24OQ
                      (g_a24OQ, gpart_a24Py) = Genome.Split.split gpart_a24Px
                      p_a24OP = double g_a24OO
                      (g_a24OO, gpart_a24Px) = Genome.Split.split gpart_a24Pw
                      p_a24ON = double g_a24OM
                      (g_a24OM, gpart_a24Pw) = Genome.Split.split gpart_a24Pv
                      p_a24OL = double g_a24OK
                      (g_a24OK, gpart_a24Pv) = Genome.Split.split gpart_a24Pu
                      p_a24OJ = double g_a24OI
                      (g_a24OI, gpart_a24Pu) = Genome.Split.split gpart_a24Pt
                      p_a24OH = double g_a24OG
                      (g_a24OG, gpart_a24Pt) = Genome.Split.split gpart_a24Ps
                      p_a24OF = Functions.belowten' g_a24OE
                      (g_a24OE, gpart_a24Ps) = Genome.Split.split gpart_a24Pr
                      p_a24OD = double g_a24OC
                      (g_a24OC, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24OB = Functions.belowten' g_a24OA
                      (g_a24OA, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24Oz = double g_a24Oy
                      (g_a24Oy, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24Ox = double g_a24Ow
                      (g_a24Ow, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24Ov = double g_a24Ou
                      (g_a24Ou, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24Ot = Functions.belowten' g_a24Os
                      (g_a24Os, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24Or = double g_a24Oq
                      (g_a24Oq, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24Op
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oo
                      (g_a24Oo, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24On
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Om
                      (g_a24Om, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24Ol = Functions.belowten' g_a24Ok
                      (g_a24Ok, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24Oj = double g_a24Oi
                      (g_a24Oi, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24Oh = double g_a24Og
                      (g_a24Og, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24Of = double g_a24Oe
                      (g_a24Oe, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24Od = Functions.belowten' g_a24Oc
                      (g_a24Oc, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24Ob = double g_a24Oa
                      (g_a24Oa, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24O9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O8
                      (g_a24O8, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24O7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O6
                      (g_a24O6, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24O5 = double g_a24O4
                      (g_a24O4, gpart_a24Pa) = Genome.Split.split gpart_a24P9
                      p_a24O3 = Functions.belowten' g_a24O2
                      (g_a24O2, gpart_a24P9) = Genome.Split.split gpart_a24P8
                      p_a24O1 = double g_a24O0
                      (g_a24O0, gpart_a24P8) = Genome.Split.split gpart_a24P7
                      p_a24NZ = Functions.belowten' g_a24NY
                      (g_a24NY, gpart_a24P7) = Genome.Split.split gpart_a24P6
                      p_a24NX = double g_a24NW
                      (g_a24NW, gpart_a24P6) = Genome.Split.split gpart_a24P5
                      p_a24NV = Functions.belowten' g_a24NU
                      (g_a24NU, gpart_a24P5) = Genome.Split.split gpart_a24P4
                      p_a24NT = double g_a24NS
                      (g_a24NS, gpart_a24P4) = Genome.Split.split gpart_a24P3
                      p_a24NR = double g_a24NQ
                      (g_a24NQ, gpart_a24P3) = Genome.Split.split gpart_a24P2
                      p_a24NP = Functions.belowten' g_a24NO
                      (g_a24NO, gpart_a24P2) = Genome.Split.split gpart_a24P1
                      p_a24NN = double g_a24NM
                      (g_a24NM, gpart_a24P1) = Genome.Split.split gpart_a24P0
                      p_a24NL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NK
                      (g_a24NK, gpart_a24P0) = Genome.Split.split gpart_a24OZ
                      p_a24NJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NI
                      (g_a24NI, gpart_a24OZ) = Genome.Split.split gpart_a24OY
                      p_a24NH = double g_a24NG
                      (g_a24NG, gpart_a24OY) = Genome.Split.split gpart_a24OX
                      p_a24NF = double g_a24NE
                      (g_a24NE, gpart_a24OX) = Genome.Split.split gpart_a24OW
                      p_a24ND = double g_a24NC
                      (g_a24NC, gpart_a24OW) = Genome.Split.split gpart_a24OV
                      p_a24NB = double g_a24NA
                      (g_a24NA, gpart_a24OV) = Genome.Split.split gpart_a24OU
                      p_a24Nz = double g_a24Ny
                      (g_a24Ny, gpart_a24OU) = Genome.Split.split genome_a24OS
                    in  \ x_a24Pz
                          -> let
                               c_PTB_a24PC
                                 = ((Data.Fixed.Vector.toVector x_a24Pz) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24PA
                                 = ((Data.Fixed.Vector.toVector x_a24Pz) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24PH
                                 = ((Data.Fixed.Vector.toVector x_a24Pz) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24PD
                                 = ((Data.Fixed.Vector.toVector x_a24Pz) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24PU
                                 = ((Data.Fixed.Vector.toVector x_a24Pz) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NH / (1 + ((c_MiRs_a24PA / p_a24NN) ** p_a24NP)))
                                    + (negate (p_a24OJ * c_PTB_a24PC))),
                                   ((p_a24NR
                                     / (1
                                        + ((((c_RESTc_a24PD / p_a24NT) ** p_a24NV)
                                            + ((c_MiRs_a24PA / p_a24NX) ** p_a24NZ))
                                           + ((c_PTB_a24PC / p_a24O1) ** p_a24O3))))
                                    + (negate (p_a24OL * c_NPTB_a24PH))),
                                   ((p_a24O5
                                     * (p_a24Of
                                        / ((1 + p_a24Of) + ((c_RESTc_a24PD / p_a24Ob) ** p_a24Od))))
                                    + (negate (p_a24ON * c_MiRs_a24PA))),
                                   ((p_a24Oh
                                     * ((p_a24Ov + ((c_PTB_a24PC / p_a24Oj) ** p_a24Ol))
                                        / (((1 + p_a24Ov) + ((c_PTB_a24PC / p_a24Oj) ** p_a24Ol))
                                           + (((p_a24Nz / p_a24On) ** p_a24Op)
                                              + ((c_MiRs_a24PA / p_a24Or) ** p_a24Ot)))))
                                    + (negate (p_a24OP * c_RESTc_a24PD))),
                                   ((p_a24Ox
                                     * ((p_a24OH + ((c_MiRs_a24PA / p_a24Oz) ** p_a24OB))
                                        / (((1 + p_a24OH) + ((c_MiRs_a24PA / p_a24Oz) ** p_a24OB))
                                           + ((c_RESTc_a24PD / p_a24OD) ** p_a24OF))))
                                    + (negate (p_a24OR * c_EndoNeuroTFs_a24PU)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504907",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504909",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504931",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504933",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504947",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504949",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24OS
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Qz
                            p_a24OR = double g_a24OQ
                            (g_a24OQ, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                            p_a24OP = double g_a24OO
                            (g_a24OO, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                            p_a24ON = double g_a24OM
                            (g_a24OM, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                            p_a24OL = double g_a24OK
                            (g_a24OK, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                            p_a24OJ = double g_a24OI
                            (g_a24OI, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                            p_a24OH = double g_a24OG
                            (g_a24OG, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                            p_a24OF = Functions.belowten' g_a24OE
                            (g_a24OE, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                            p_a24OD = double g_a24OC
                            (g_a24OC, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24OB = Functions.belowten' g_a24OA
                            (g_a24OA, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24Oz = double g_a24Oy
                            (g_a24Oy, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24Ox = double g_a24Ow
                            (g_a24Ow, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24Ov = double g_a24Ou
                            (g_a24Ou, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24Ot = Functions.belowten' g_a24Os
                            (g_a24Os, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24Or = double g_a24Oq
                            (g_a24Oq, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24Op
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oo
                            (g_a24Oo, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24On
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Om
                            (g_a24Om, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24Ol = Functions.belowten' g_a24Ok
                            (g_a24Ok, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24Oj = double g_a24Oi
                            (g_a24Oi, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24Oh = double g_a24Og
                            (g_a24Og, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24Of = double g_a24Oe
                            (g_a24Oe, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24Od = Functions.belowten' g_a24Oc
                            (g_a24Oc, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24Ob = double g_a24Oa
                            (g_a24Oa, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24O9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O8
                            (g_a24O8, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24O7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O6
                            (g_a24O6, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                            p_a24O5 = double g_a24O4
                            (g_a24O4, gpart_a24Qb) = Genome.Split.split gpart_a24Qa
                            p_a24O3 = Functions.belowten' g_a24O2
                            (g_a24O2, gpart_a24Qa) = Genome.Split.split gpart_a24Q9
                            p_a24O1 = double g_a24O0
                            (g_a24O0, gpart_a24Q9) = Genome.Split.split gpart_a24Q8
                            p_a24NZ = Functions.belowten' g_a24NY
                            (g_a24NY, gpart_a24Q8) = Genome.Split.split gpart_a24Q7
                            p_a24NX = double g_a24NW
                            (g_a24NW, gpart_a24Q7) = Genome.Split.split gpart_a24Q6
                            p_a24NV = Functions.belowten' g_a24NU
                            (g_a24NU, gpart_a24Q6) = Genome.Split.split gpart_a24Q5
                            p_a24NT = double g_a24NS
                            (g_a24NS, gpart_a24Q5) = Genome.Split.split gpart_a24Q4
                            p_a24NR = double g_a24NQ
                            (g_a24NQ, gpart_a24Q4) = Genome.Split.split gpart_a24Q3
                            p_a24NP = Functions.belowten' g_a24NO
                            (g_a24NO, gpart_a24Q3) = Genome.Split.split gpart_a24Q2
                            p_a24NN = double g_a24NM
                            (g_a24NM, gpart_a24Q2) = Genome.Split.split gpart_a24Q1
                            p_a24NL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NK
                            (g_a24NK, gpart_a24Q1) = Genome.Split.split gpart_a24Q0
                            p_a24NJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NI
                            (g_a24NI, gpart_a24Q0) = Genome.Split.split gpart_a24PZ
                            p_a24NH = double g_a24NG
                            (g_a24NG, gpart_a24PZ) = Genome.Split.split gpart_a24PY
                            p_a24NF = double g_a24NE
                            (g_a24NE, gpart_a24PY) = Genome.Split.split gpart_a24PX
                            p_a24ND = double g_a24NC
                            (g_a24NC, gpart_a24PX) = Genome.Split.split gpart_a24PW
                            p_a24NB = double g_a24NA
                            (g_a24NA, gpart_a24PW) = Genome.Split.split gpart_a24PV
                            p_a24Nz = double g_a24Ny
                            (g_a24Ny, gpart_a24PV) = Genome.Split.split genome_a24OS
                          in
                            \ desc_a24OT
                              -> case desc_a24OT of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nz)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NB)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ND)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NF)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NH)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NJ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NL)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NN)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NP)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NR)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NT)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NV)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NX)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NZ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O1)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O3)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O5)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O7)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ob)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Od)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Of)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oh)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ol)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24On)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Op)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Or)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ot)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ov)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ox)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oz)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OB)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OD)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OF)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OH)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OJ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OL)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ON)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OP)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OR)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24T3
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24TJ
                      p_a24T2 = double g_a24T1
                      (g_a24T1, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                      p_a24T0 = double g_a24SZ
                      (g_a24SZ, gpart_a24TI) = Genome.Split.split gpart_a24TH
                      p_a24SY = double g_a24SX
                      (g_a24SX, gpart_a24TH) = Genome.Split.split gpart_a24TG
                      p_a24SW = double g_a24SV
                      (g_a24SV, gpart_a24TG) = Genome.Split.split gpart_a24TF
                      p_a24SU = double g_a24ST
                      (g_a24ST, gpart_a24TF) = Genome.Split.split gpart_a24TE
                      p_a24SS = double g_a24SR
                      (g_a24SR, gpart_a24TE) = Genome.Split.split gpart_a24TD
                      p_a24SQ = Functions.belowten' g_a24SP
                      (g_a24SP, gpart_a24TD) = Genome.Split.split gpart_a24TC
                      p_a24SO = double g_a24SN
                      (g_a24SN, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24SM = Functions.belowten' g_a24SL
                      (g_a24SL, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24SK = double g_a24SJ
                      (g_a24SJ, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24SI = double g_a24SH
                      (g_a24SH, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24SG = double g_a24SF
                      (g_a24SF, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24SE = Functions.belowten' g_a24SD
                      (g_a24SD, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24SC = double g_a24SB
                      (g_a24SB, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24SA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sz
                      (g_a24Sz, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24Sy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sx
                      (g_a24Sx, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24Sw = Functions.belowten' g_a24Sv
                      (g_a24Sv, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24Su = double g_a24St
                      (g_a24St, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24Ss = double g_a24Sr
                      (g_a24Sr, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24Sq = double g_a24Sp
                      (g_a24Sp, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24So = Functions.belowten' g_a24Sn
                      (g_a24Sn, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24Sm = double g_a24Sl
                      (g_a24Sl, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24Sk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sj
                      (g_a24Sj, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24Si
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sh
                      (g_a24Sh, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24Sg = double g_a24Sf
                      (g_a24Sf, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24Se = Functions.belowten' g_a24Sd
                      (g_a24Sd, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24Sc = double g_a24Sb
                      (g_a24Sb, gpart_a24Tj) = Genome.Split.split gpart_a24Ti
                      p_a24Sa = Functions.belowten' g_a24S9
                      (g_a24S9, gpart_a24Ti) = Genome.Split.split gpart_a24Th
                      p_a24S8 = double g_a24S7
                      (g_a24S7, gpart_a24Th) = Genome.Split.split gpart_a24Tg
                      p_a24S6 = Functions.belowten' g_a24S5
                      (g_a24S5, gpart_a24Tg) = Genome.Split.split gpart_a24Tf
                      p_a24S4 = double g_a24S3
                      (g_a24S3, gpart_a24Tf) = Genome.Split.split gpart_a24Te
                      p_a24S2 = double g_a24S1
                      (g_a24S1, gpart_a24Te) = Genome.Split.split gpart_a24Td
                      p_a24S0 = Functions.belowten' g_a24RZ
                      (g_a24RZ, gpart_a24Td) = Genome.Split.split gpart_a24Tc
                      p_a24RY = double g_a24RX
                      (g_a24RX, gpart_a24Tc) = Genome.Split.split gpart_a24Tb
                      p_a24RW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RV
                      (g_a24RV, gpart_a24Tb) = Genome.Split.split gpart_a24Ta
                      p_a24RU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RT
                      (g_a24RT, gpart_a24Ta) = Genome.Split.split gpart_a24T9
                      p_a24RS = double g_a24RR
                      (g_a24RR, gpart_a24T9) = Genome.Split.split gpart_a24T8
                      p_a24RQ = double g_a24RP
                      (g_a24RP, gpart_a24T8) = Genome.Split.split gpart_a24T7
                      p_a24RO = double g_a24RN
                      (g_a24RN, gpart_a24T7) = Genome.Split.split gpart_a24T6
                      p_a24RM = double g_a24RL
                      (g_a24RL, gpart_a24T6) = Genome.Split.split gpart_a24T5
                      p_a24RK = double g_a24RJ
                      (g_a24RJ, gpart_a24T5) = Genome.Split.split genome_a24T3
                    in  \ x_a24TK
                          -> let
                               c_PTB_a24TN
                                 = ((Data.Fixed.Vector.toVector x_a24TK) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TL
                                 = ((Data.Fixed.Vector.toVector x_a24TK) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24TS
                                 = ((Data.Fixed.Vector.toVector x_a24TK) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24TO
                                 = ((Data.Fixed.Vector.toVector x_a24TK) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24U5
                                 = ((Data.Fixed.Vector.toVector x_a24TK) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24RS / (1 + ((c_MiRs_a24TL / p_a24RY) ** p_a24S0)))
                                    + (negate (p_a24SU * c_PTB_a24TN))),
                                   ((p_a24S2
                                     / (1
                                        + ((((c_RESTc_a24TO / p_a24S4) ** p_a24S6)
                                            + ((c_MiRs_a24TL / p_a24S8) ** p_a24Sa))
                                           + ((c_PTB_a24TN / p_a24Sc) ** p_a24Se))))
                                    + (negate (p_a24SW * c_NPTB_a24TS))),
                                   ((p_a24Sg
                                     * (p_a24Sq
                                        / ((1 + p_a24Sq) + ((c_RESTc_a24TO / p_a24Sm) ** p_a24So))))
                                    + (negate (p_a24SY * c_MiRs_a24TL))),
                                   ((p_a24Ss
                                     * ((p_a24SG + ((c_PTB_a24TN / p_a24Su) ** p_a24Sw))
                                        / (((1 + p_a24SG) + ((c_PTB_a24TN / p_a24Su) ** p_a24Sw))
                                           + ((c_MiRs_a24TL / p_a24SC) ** p_a24SE))))
                                    + (negate (p_a24T0 * c_RESTc_a24TO))),
                                   ((p_a24SI
                                     * ((p_a24SS + ((c_MiRs_a24TL / p_a24SK) ** p_a24SM))
                                        / (((1 + p_a24SS) + ((c_MiRs_a24TL / p_a24SK) ** p_a24SM))
                                           + ((c_RESTc_a24TO / p_a24SO) ** p_a24SQ))))
                                    + (negate (p_a24T2 * c_EndoNeuroTFs_a24U5)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505166",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505168",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505190",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505192",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505206",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505208",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24T3
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UK
                            p_a24T2 = double g_a24T1
                            (g_a24T1, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                            p_a24T0 = double g_a24SZ
                            (g_a24SZ, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                            p_a24SY = double g_a24SX
                            (g_a24SX, gpart_a24UI) = Genome.Split.split gpart_a24UH
                            p_a24SW = double g_a24SV
                            (g_a24SV, gpart_a24UH) = Genome.Split.split gpart_a24UG
                            p_a24SU = double g_a24ST
                            (g_a24ST, gpart_a24UG) = Genome.Split.split gpart_a24UF
                            p_a24SS = double g_a24SR
                            (g_a24SR, gpart_a24UF) = Genome.Split.split gpart_a24UE
                            p_a24SQ = Functions.belowten' g_a24SP
                            (g_a24SP, gpart_a24UE) = Genome.Split.split gpart_a24UD
                            p_a24SO = double g_a24SN
                            (g_a24SN, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24SM = Functions.belowten' g_a24SL
                            (g_a24SL, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24SK = double g_a24SJ
                            (g_a24SJ, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24SI = double g_a24SH
                            (g_a24SH, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24SG = double g_a24SF
                            (g_a24SF, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24SE = Functions.belowten' g_a24SD
                            (g_a24SD, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24SC = double g_a24SB
                            (g_a24SB, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24SA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sz
                            (g_a24Sz, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24Sy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sx
                            (g_a24Sx, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24Sw = Functions.belowten' g_a24Sv
                            (g_a24Sv, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24Su = double g_a24St
                            (g_a24St, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24Ss = double g_a24Sr
                            (g_a24Sr, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24Sq = double g_a24Sp
                            (g_a24Sp, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24So = Functions.belowten' g_a24Sn
                            (g_a24Sn, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24Sm = double g_a24Sl
                            (g_a24Sl, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24Sk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sj
                            (g_a24Sj, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24Si
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sh
                            (g_a24Sh, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24Sg = double g_a24Sf
                            (g_a24Sf, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24Se = Functions.belowten' g_a24Sd
                            (g_a24Sd, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                            p_a24Sc = double g_a24Sb
                            (g_a24Sb, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                            p_a24Sa = Functions.belowten' g_a24S9
                            (g_a24S9, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                            p_a24S8 = double g_a24S7
                            (g_a24S7, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                            p_a24S6 = Functions.belowten' g_a24S5
                            (g_a24S5, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                            p_a24S4 = double g_a24S3
                            (g_a24S3, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                            p_a24S2 = double g_a24S1
                            (g_a24S1, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                            p_a24S0 = Functions.belowten' g_a24RZ
                            (g_a24RZ, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                            p_a24RY = double g_a24RX
                            (g_a24RX, gpart_a24Ud) = Genome.Split.split gpart_a24Uc
                            p_a24RW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RV
                            (g_a24RV, gpart_a24Uc) = Genome.Split.split gpart_a24Ub
                            p_a24RU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RT
                            (g_a24RT, gpart_a24Ub) = Genome.Split.split gpart_a24Ua
                            p_a24RS = double g_a24RR
                            (g_a24RR, gpart_a24Ua) = Genome.Split.split gpart_a24U9
                            p_a24RQ = double g_a24RP
                            (g_a24RP, gpart_a24U9) = Genome.Split.split gpart_a24U8
                            p_a24RO = double g_a24RN
                            (g_a24RN, gpart_a24U8) = Genome.Split.split gpart_a24U7
                            p_a24RM = double g_a24RL
                            (g_a24RL, gpart_a24U7) = Genome.Split.split gpart_a24U6
                            p_a24RK = double g_a24RJ
                            (g_a24RJ, gpart_a24U6) = Genome.Split.split genome_a24T3
                          in
                            \ desc_a24T4
                              -> case desc_a24T4 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RK)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RM)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RO)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RQ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RS)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RU)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RW)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RY)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S2)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S4)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sa)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Se)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Si)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sk)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sm)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24So)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sq)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ss)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Su)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sw)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sy)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SA)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SC)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SE)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SG)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SI)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SK)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SM)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SO)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SQ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SS)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SU)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SW)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SY)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T0)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T2)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24Xe
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24XU
                      p_a24Xd = double g_a24Xc
                      (g_a24Xc, gpart_a24XU) = Genome.Split.split gpart_a24XT
                      p_a24Xb = double g_a24Xa
                      (g_a24Xa, gpart_a24XT) = Genome.Split.split gpart_a24XS
                      p_a24X9 = double g_a24X8
                      (g_a24X8, gpart_a24XS) = Genome.Split.split gpart_a24XR
                      p_a24X7 = double g_a24X6
                      (g_a24X6, gpart_a24XR) = Genome.Split.split gpart_a24XQ
                      p_a24X5 = double g_a24X4
                      (g_a24X4, gpart_a24XQ) = Genome.Split.split gpart_a24XP
                      p_a24X3 = double g_a24X2
                      (g_a24X2, gpart_a24XP) = Genome.Split.split gpart_a24XO
                      p_a24X1 = Functions.belowten' g_a24X0
                      (g_a24X0, gpart_a24XO) = Genome.Split.split gpart_a24XN
                      p_a24WZ = double g_a24WY
                      (g_a24WY, gpart_a24XN) = Genome.Split.split gpart_a24XM
                      p_a24WX = Functions.belowten' g_a24WW
                      (g_a24WW, gpart_a24XM) = Genome.Split.split gpart_a24XL
                      p_a24WV = double g_a24WU
                      (g_a24WU, gpart_a24XL) = Genome.Split.split gpart_a24XK
                      p_a24WT = double g_a24WS
                      (g_a24WS, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                      p_a24WR = double g_a24WQ
                      (g_a24WQ, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24WP = Functions.belowten' g_a24WO
                      (g_a24WO, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24WN = double g_a24WM
                      (g_a24WM, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24WL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WK
                      (g_a24WK, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24WJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WI
                      (g_a24WI, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24WH = Functions.belowten' g_a24WG
                      (g_a24WG, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24WF = double g_a24WE
                      (g_a24WE, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24WD = double g_a24WC
                      (g_a24WC, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24WB = double g_a24WA
                      (g_a24WA, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24Wz = Functions.belowten' g_a24Wy
                      (g_a24Wy, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24Wx = double g_a24Ww
                      (g_a24Ww, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24Wv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wu
                      (g_a24Wu, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24Wt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ws
                      (g_a24Ws, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24Wr = double g_a24Wq
                      (g_a24Wq, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24Wp = Functions.belowten' g_a24Wo
                      (g_a24Wo, gpart_a24Xv) = Genome.Split.split gpart_a24Xu
                      p_a24Wn = double g_a24Wm
                      (g_a24Wm, gpart_a24Xu) = Genome.Split.split gpart_a24Xt
                      p_a24Wl = Functions.belowten' g_a24Wk
                      (g_a24Wk, gpart_a24Xt) = Genome.Split.split gpart_a24Xs
                      p_a24Wj = double g_a24Wi
                      (g_a24Wi, gpart_a24Xs) = Genome.Split.split gpart_a24Xr
                      p_a24Wh = Functions.belowten' g_a24Wg
                      (g_a24Wg, gpart_a24Xr) = Genome.Split.split gpart_a24Xq
                      p_a24Wf = double g_a24We
                      (g_a24We, gpart_a24Xq) = Genome.Split.split gpart_a24Xp
                      p_a24Wd = double g_a24Wc
                      (g_a24Wc, gpart_a24Xp) = Genome.Split.split gpart_a24Xo
                      p_a24Wb = Functions.belowten' g_a24Wa
                      (g_a24Wa, gpart_a24Xo) = Genome.Split.split gpart_a24Xn
                      p_a24W9 = double g_a24W8
                      (g_a24W8, gpart_a24Xn) = Genome.Split.split gpart_a24Xm
                      p_a24W7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W6
                      (g_a24W6, gpart_a24Xm) = Genome.Split.split gpart_a24Xl
                      p_a24W5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W4
                      (g_a24W4, gpart_a24Xl) = Genome.Split.split gpart_a24Xk
                      p_a24W3 = double g_a24W2
                      (g_a24W2, gpart_a24Xk) = Genome.Split.split gpart_a24Xj
                      p_a24W1 = double g_a24W0
                      (g_a24W0, gpart_a24Xj) = Genome.Split.split gpart_a24Xi
                      p_a24VZ = double g_a24VY
                      (g_a24VY, gpart_a24Xi) = Genome.Split.split gpart_a24Xh
                      p_a24VX = double g_a24VW
                      (g_a24VW, gpart_a24Xh) = Genome.Split.split gpart_a24Xg
                      p_a24VV = double g_a24VU
                      (g_a24VU, gpart_a24Xg) = Genome.Split.split genome_a24Xe
                    in  \ x_a24XV
                          -> let
                               c_PTB_a24XY
                                 = ((Data.Fixed.Vector.toVector x_a24XV) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24XW
                                 = ((Data.Fixed.Vector.toVector x_a24XV) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Y3
                                 = ((Data.Fixed.Vector.toVector x_a24XV) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24XZ
                                 = ((Data.Fixed.Vector.toVector x_a24XV) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Yg
                                 = ((Data.Fixed.Vector.toVector x_a24XV) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24W3
                                     / (1
                                        + (((p_a24VV / p_a24W5) ** p_a24W7)
                                           + ((c_MiRs_a24XW / p_a24W9) ** p_a24Wb))))
                                    + (negate (p_a24X5 * c_PTB_a24XY))),
                                   ((p_a24Wd
                                     / (1
                                        + ((((c_RESTc_a24XZ / p_a24Wf) ** p_a24Wh)
                                            + ((c_MiRs_a24XW / p_a24Wj) ** p_a24Wl))
                                           + ((c_PTB_a24XY / p_a24Wn) ** p_a24Wp))))
                                    + (negate (p_a24X7 * c_NPTB_a24Y3))),
                                   ((p_a24Wr
                                     * (p_a24WB
                                        / ((1 + p_a24WB) + ((c_RESTc_a24XZ / p_a24Wx) ** p_a24Wz))))
                                    + (negate (p_a24X9 * c_MiRs_a24XW))),
                                   ((p_a24WD
                                     * ((p_a24WR + ((c_PTB_a24XY / p_a24WF) ** p_a24WH))
                                        / (((1 + p_a24WR) + ((c_PTB_a24XY / p_a24WF) ** p_a24WH))
                                           + ((c_MiRs_a24XW / p_a24WN) ** p_a24WP))))
                                    + (negate (p_a24Xb * c_RESTc_a24XZ))),
                                   ((p_a24WT
                                     * ((p_a24X3 + ((c_MiRs_a24XW / p_a24WV) ** p_a24WX))
                                        / (((1 + p_a24X3) + ((c_MiRs_a24XW / p_a24WV) ** p_a24WX))
                                           + ((c_RESTc_a24XZ / p_a24WZ) ** p_a24X1))))
                                    + (negate (p_a24Xd * c_EndoNeuroTFs_a24Yg)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505425",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505427",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505449",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505451",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505465",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505467",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505481",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505483",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Xe
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24YV
                            p_a24Xd = double g_a24Xc
                            (g_a24Xc, gpart_a24YV) = Genome.Split.split gpart_a24YU
                            p_a24Xb = double g_a24Xa
                            (g_a24Xa, gpart_a24YU) = Genome.Split.split gpart_a24YT
                            p_a24X9 = double g_a24X8
                            (g_a24X8, gpart_a24YT) = Genome.Split.split gpart_a24YS
                            p_a24X7 = double g_a24X6
                            (g_a24X6, gpart_a24YS) = Genome.Split.split gpart_a24YR
                            p_a24X5 = double g_a24X4
                            (g_a24X4, gpart_a24YR) = Genome.Split.split gpart_a24YQ
                            p_a24X3 = double g_a24X2
                            (g_a24X2, gpart_a24YQ) = Genome.Split.split gpart_a24YP
                            p_a24X1 = Functions.belowten' g_a24X0
                            (g_a24X0, gpart_a24YP) = Genome.Split.split gpart_a24YO
                            p_a24WZ = double g_a24WY
                            (g_a24WY, gpart_a24YO) = Genome.Split.split gpart_a24YN
                            p_a24WX = Functions.belowten' g_a24WW
                            (g_a24WW, gpart_a24YN) = Genome.Split.split gpart_a24YM
                            p_a24WV = double g_a24WU
                            (g_a24WU, gpart_a24YM) = Genome.Split.split gpart_a24YL
                            p_a24WT = double g_a24WS
                            (g_a24WS, gpart_a24YL) = Genome.Split.split gpart_a24YK
                            p_a24WR = double g_a24WQ
                            (g_a24WQ, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24WP = Functions.belowten' g_a24WO
                            (g_a24WO, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24WN = double g_a24WM
                            (g_a24WM, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24WL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WK
                            (g_a24WK, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24WJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WI
                            (g_a24WI, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24WH = Functions.belowten' g_a24WG
                            (g_a24WG, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24WF = double g_a24WE
                            (g_a24WE, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24WD = double g_a24WC
                            (g_a24WC, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24WB = double g_a24WA
                            (g_a24WA, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24Wz = Functions.belowten' g_a24Wy
                            (g_a24Wy, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24Wx = double g_a24Ww
                            (g_a24Ww, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24Wv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wu
                            (g_a24Wu, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24Wt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ws
                            (g_a24Ws, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24Wr = double g_a24Wq
                            (g_a24Wq, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                            p_a24Wp = Functions.belowten' g_a24Wo
                            (g_a24Wo, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                            p_a24Wn = double g_a24Wm
                            (g_a24Wm, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                            p_a24Wl = Functions.belowten' g_a24Wk
                            (g_a24Wk, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                            p_a24Wj = double g_a24Wi
                            (g_a24Wi, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                            p_a24Wh = Functions.belowten' g_a24Wg
                            (g_a24Wg, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                            p_a24Wf = double g_a24We
                            (g_a24We, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                            p_a24Wd = double g_a24Wc
                            (g_a24Wc, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                            p_a24Wb = Functions.belowten' g_a24Wa
                            (g_a24Wa, gpart_a24Yp) = Genome.Split.split gpart_a24Yo
                            p_a24W9 = double g_a24W8
                            (g_a24W8, gpart_a24Yo) = Genome.Split.split gpart_a24Yn
                            p_a24W7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W6
                            (g_a24W6, gpart_a24Yn) = Genome.Split.split gpart_a24Ym
                            p_a24W5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W4
                            (g_a24W4, gpart_a24Ym) = Genome.Split.split gpart_a24Yl
                            p_a24W3 = double g_a24W2
                            (g_a24W2, gpart_a24Yl) = Genome.Split.split gpart_a24Yk
                            p_a24W1 = double g_a24W0
                            (g_a24W0, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                            p_a24VZ = double g_a24VY
                            (g_a24VY, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                            p_a24VX = double g_a24VW
                            (g_a24VW, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                            p_a24VV = double g_a24VU
                            (g_a24VU, gpart_a24Yh) = Genome.Split.split genome_a24Xe
                          in
                            \ desc_a24Xf
                              -> case desc_a24Xf of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W3)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W5)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W7)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W9)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wb)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wd)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wf)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wh)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wj)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wl)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wn)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wp)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wr)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wt)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wv)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wx)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WD)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WH)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WJ)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WN)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WT)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WV)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WX)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WZ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X1)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X3)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X5)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X7)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X9)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xb)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xd)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVu
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWa
                      p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                      (g_asVs, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                      (g_asVq, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                      (g_asVo, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                      (g_asVm, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                      (g_asVk, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                      (g_asVi, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asVh = Functions.belowten' g_asVg
                      (g_asVg, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asVf = code-0.1.0.0:Genome.FixedList.Functions.double g_asVe
                      (g_asVe, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asVd = Functions.belowten' g_asVc
                      (g_asVc, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                      (g_asVa, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                      (g_asV8, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asV5 = Functions.belowten' g_asV4
                      (g_asV4, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asV1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV0
                      (g_asV0, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                      (g_asUY, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUX = Functions.belowten' g_asUW
                      (g_asUW, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                      (g_asUU, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUP = Functions.belowten' g_asUO
                      (g_asUO, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                      (g_asUM, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUK
                      (g_asUK, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                      (g_asUI, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                      (g_asUG, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUF = Functions.belowten' g_asUE
                      (g_asUE, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUB = Functions.belowten' g_asUA
                      (g_asUA, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUx = Functions.belowten' g_asUw
                      (g_asUw, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUr = Functions.belowten' g_asUq
                      (g_asUq, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                      (g_asUk, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                      (g_asUi, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVw) = Genome.Split.split genome_asVu
                    in
                      [Reaction
                         (\ x_asWb
                            -> let c_MiRs_asWc = ((toVector x_asWb) Data.Vector.Unboxed.! 2)
                               in (p_asUj / (1 + ((c_MiRs_asWc / p_asUp) ** p_asUr))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWd
                            -> let
                                 c_MiRs_asWf = ((toVector x_asWd) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWe = ((toVector x_asWd) Data.Vector.Unboxed.! 3)
                                 c_PTB_asWg = ((toVector x_asWd) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUt
                                  / (1
                                     + ((((c_RESTc_asWe / p_asUv) ** p_asUx)
                                         + ((c_MiRs_asWf / p_asUz) ** p_asUB))
                                        + ((c_PTB_asWg / p_asUD) ** p_asUF)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWh
                            -> let c_RESTc_asWi = ((toVector x_asWh) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUH
                                  * ((p_asUR + ((p_asUf / p_asUJ) ** p_asUL))
                                     / (((1 + p_asUR) + ((p_asUf / p_asUJ) ** p_asUL))
                                        + ((c_RESTc_asWi / p_asUN) ** p_asUP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWj
                            -> let
                                 c_MiRs_asWm = ((toVector x_asWj) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWk = ((toVector x_asWj) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUT
                                  * ((p_asV7 + ((c_PTB_asWk / p_asUV) ** p_asUX))
                                     / (((1 + p_asV7) + ((c_PTB_asWk / p_asUV) ** p_asUX))
                                        + (((p_asUb / p_asUZ) ** p_asV1)
                                           + ((c_MiRs_asWm / p_asV3) ** p_asV5))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWn
                            -> let
                                 c_RESTc_asWq = ((toVector x_asWn) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWo = ((toVector x_asWn) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asV9
                                  * ((p_asVj + ((c_MiRs_asWo / p_asVb) ** p_asVd))
                                     / (((1 + p_asVj) + ((c_MiRs_asWo / p_asVb) ** p_asVd))
                                        + ((c_RESTc_asWq / p_asVf) ** p_asVh)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWr
                            -> let c_PTB_asWs = ((toVector x_asWr) Data.Vector.Unboxed.! 0)
                               in (p_asVl * c_PTB_asWs))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWt
                            -> let c_NPTB_asWu = ((toVector x_asWt) Data.Vector.Unboxed.! 1)
                               in (p_asVn * c_NPTB_asWu))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWv
                            -> let c_MiRs_asWw = ((toVector x_asWv) Data.Vector.Unboxed.! 2)
                               in (p_asVp * c_MiRs_asWw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWx
                            -> let c_RESTc_asWy = ((toVector x_asWx) Data.Vector.Unboxed.! 3)
                               in (p_asVr * c_RESTc_asWy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWz
                            -> let
                                 c_EndoNeuroTFs_asWA = ((toVector x_asWz) Data.Vector.Unboxed.! 4)
                               in (p_asVt * c_EndoNeuroTFs_asWA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVu
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXk
                            p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                            (g_asVs, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                            (g_asVq, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                            (g_asVo, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                            (g_asVm, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                            (g_asVk, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                            (g_asVi, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asVh = Functions.belowten' g_asVg
                            (g_asVg, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asVf = code-0.1.0.0:Genome.FixedList.Functions.double g_asVe
                            (g_asVe, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asVd = Functions.belowten' g_asVc
                            (g_asVc, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                            (g_asVa, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                            (g_asV8, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asV5 = Functions.belowten' g_asV4
                            (g_asV4, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asV1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV0
                            (g_asV0, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                            (g_asUY, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUX = Functions.belowten' g_asUW
                            (g_asUW, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                            (g_asUU, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUP = Functions.belowten' g_asUO
                            (g_asUO, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                            (g_asUM, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUK
                            (g_asUK, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                            (g_asUI, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                            (g_asUG, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUF = Functions.belowten' g_asUE
                            (g_asUE, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUB = Functions.belowten' g_asUA
                            (g_asUA, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUx = Functions.belowten' g_asUw
                            (g_asUw, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUr = Functions.belowten' g_asUq
                            (g_asUq, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                            (g_asUk, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                            (g_asUi, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWG) = Genome.Split.split genome_asVu
                          in
                            \ desc_asVv
                              -> case desc_asVv of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV9)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVb)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVh)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVj)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVl)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVn)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVp)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVr)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVt)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZl
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at01
                      p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                      (g_asZj, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                      (g_asZh, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                      (g_asZf, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                      (g_asZd, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                      (g_asZb, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asZ8 = Functions.belowten' g_asZ7
                      (g_asZ7, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asZ4 = Functions.belowten' g_asZ3
                      (g_asZ3, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                      (g_asZ1, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                      (g_asYZ, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                      (g_asYX, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYW = Functions.belowten' g_asYV
                      (g_asYV, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                      (g_asYT, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYR
                      (g_asYR, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYP
                      (g_asYP, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYO = Functions.belowten' g_asYN
                      (g_asYN, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                      (g_asYL, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYG = Functions.belowten' g_asYF
                      (g_asYF, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                      (g_asYD, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYB
                      (g_asYB, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYz
                      (g_asYz, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYw = Functions.belowten' g_asYv
                      (g_asYv, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYs = Functions.belowten' g_asYr
                      (g_asYr, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYo = Functions.belowten' g_asYn
                      (g_asYn, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                      (g_asYj, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYi = Functions.belowten' g_asYh
                      (g_asYh, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                      (g_asYf, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYd
                      (g_asYd, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYb
                      (g_asYb, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                      (g_asY7, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                      (g_asY5, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                      (g_asY3, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                      (g_asY1, gpart_asZn) = Genome.Split.split genome_asZl
                    in
                      [Reaction
                         (\ x_at02
                            -> let c_MiRs_at03 = ((toVector x_at02) Data.Vector.Unboxed.! 2)
                               in (p_asYa / (1 + ((c_MiRs_at03 / p_asYg) ** p_asYi))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at04
                            -> let
                                 c_MiRs_at06 = ((toVector x_at04) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at05 = ((toVector x_at04) Data.Vector.Unboxed.! 3)
                                 c_PTB_at07 = ((toVector x_at04) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYk
                                  / (1
                                     + ((((c_RESTc_at05 / p_asYm) ** p_asYo)
                                         + ((c_MiRs_at06 / p_asYq) ** p_asYs))
                                        + ((c_PTB_at07 / p_asYu) ** p_asYw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at08
                            -> let c_RESTc_at09 = ((toVector x_at08) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYy
                                  * (p_asYI
                                     / ((1 + p_asYI) + ((c_RESTc_at09 / p_asYE) ** p_asYG)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0a
                            -> let
                                 c_MiRs_at0d = ((toVector x_at0a) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0b = ((toVector x_at0a) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYK
                                  * ((p_asYY + ((c_PTB_at0b / p_asYM) ** p_asYO))
                                     / (((1 + p_asYY) + ((c_PTB_at0b / p_asYM) ** p_asYO))
                                        + (((p_asY2 / p_asYQ) ** p_asYS)
                                           + ((c_MiRs_at0d / p_asYU) ** p_asYW))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0e
                            -> let
                                 c_RESTc_at0h = ((toVector x_at0e) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0f = ((toVector x_at0e) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZ0
                                  * ((p_asZa + ((c_MiRs_at0f / p_asZ2) ** p_asZ4))
                                     / (((1 + p_asZa) + ((c_MiRs_at0f / p_asZ2) ** p_asZ4))
                                        + ((c_RESTc_at0h / p_asZ6) ** p_asZ8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0i
                            -> let c_PTB_at0j = ((toVector x_at0i) Data.Vector.Unboxed.! 0)
                               in (p_asZc * c_PTB_at0j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0k
                            -> let c_NPTB_at0l = ((toVector x_at0k) Data.Vector.Unboxed.! 1)
                               in (p_asZe * c_NPTB_at0l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0m
                            -> let c_MiRs_at0n = ((toVector x_at0m) Data.Vector.Unboxed.! 2)
                               in (p_asZg * c_MiRs_at0n))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0o
                            -> let c_RESTc_at0p = ((toVector x_at0o) Data.Vector.Unboxed.! 3)
                               in (p_asZi * c_RESTc_at0p))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0q
                            -> let
                                 c_EndoNeuroTFs_at0r = ((toVector x_at0q) Data.Vector.Unboxed.! 4)
                               in (p_asZk * c_EndoNeuroTFs_at0r))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZl
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at16
                            p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                            (g_asZj, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                            (g_asZh, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                            (g_asZf, gpart_at14) = Genome.Split.split gpart_at13
                            p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                            (g_asZd, gpart_at13) = Genome.Split.split gpart_at12
                            p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                            (g_asZb, gpart_at12) = Genome.Split.split gpart_at11
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at11) = Genome.Split.split gpart_at10
                            p_asZ8 = Functions.belowten' g_asZ7
                            (g_asZ7, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asZ4 = Functions.belowten' g_asZ3
                            (g_asZ3, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                            (g_asZ1, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                            (g_asYZ, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                            (g_asYX, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYW = Functions.belowten' g_asYV
                            (g_asYV, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                            (g_asYT, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYR
                            (g_asYR, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYP
                            (g_asYP, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYO = Functions.belowten' g_asYN
                            (g_asYN, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                            (g_asYL, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYG = Functions.belowten' g_asYF
                            (g_asYF, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                            (g_asYD, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYB
                            (g_asYB, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYz
                            (g_asYz, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYw = Functions.belowten' g_asYv
                            (g_asYv, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYs = Functions.belowten' g_asYr
                            (g_asYr, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYo = Functions.belowten' g_asYn
                            (g_asYn, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYk = code-0.1.0.0:Genome.FixedList.Functions.double g_asYj
                            (g_asYj, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYi = Functions.belowten' g_asYh
                            (g_asYh, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                            (g_asYf, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYd
                            (g_asYd, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYb
                            (g_asYb, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                            (g_asY7, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                            (g_asY5, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                            (g_asY3, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                            (g_asY1, gpart_at0s) = Genome.Split.split genome_asZl
                          in
                            \ desc_asZm
                              -> case desc_asZm of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at37
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3N
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                      (g_at33, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                      (g_at31, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                      (g_at2X, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                      (g_at2V, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2U = Functions.belowten' g_at2T
                      (g_at2T, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                      (g_at2R, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2Q = Functions.belowten' g_at2P
                      (g_at2P, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2I = Functions.belowten' g_at2H
                      (g_at2H, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2D
                      (g_at2D, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2B
                      (g_at2B, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2A = Functions.belowten' g_at2z
                      (g_at2z, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2u = code-0.1.0.0:Genome.FixedList.Functions.double g_at2t
                      (g_at2t, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2s = Functions.belowten' g_at2r
                      (g_at2r, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                      (g_at2p, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2n
                      (g_at2n, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                      (g_at2l, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2i = Functions.belowten' g_at2h
                      (g_at2h, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2e = Functions.belowten' g_at2d
                      (g_at2d, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2a = Functions.belowten' g_at29
                      (g_at29, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at24 = Functions.belowten' g_at23
                      (g_at23, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at20
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                      (g_at1Z, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at1Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                      (g_at1X, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at39) = Genome.Split.split genome_at37
                    in
                      [Reaction
                         (\ x_at3O
                            -> let c_MiRs_at3P = ((toVector x_at3O) Data.Vector.Unboxed.! 2)
                               in (p_at1W / (1 + ((c_MiRs_at3P / p_at22) ** p_at24))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3Q
                            -> let
                                 c_MiRs_at3S = ((toVector x_at3Q) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3R = ((toVector x_at3Q) Data.Vector.Unboxed.! 3)
                                 c_PTB_at3T = ((toVector x_at3Q) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at26
                                  / (1
                                     + ((((c_RESTc_at3R / p_at28) ** p_at2a)
                                         + ((c_MiRs_at3S / p_at2c) ** p_at2e))
                                        + ((c_PTB_at3T / p_at2g) ** p_at2i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3U
                            -> let c_RESTc_at3V = ((toVector x_at3U) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2k
                                  * (p_at2u
                                     / ((1 + p_at2u) + ((c_RESTc_at3V / p_at2q) ** p_at2s)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3W
                            -> let
                                 c_MiRs_at3Z = ((toVector x_at3W) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3X = ((toVector x_at3W) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2w
                                  * ((p_at2K + ((c_PTB_at3X / p_at2y) ** p_at2A))
                                     / (((1 + p_at2K) + ((c_PTB_at3X / p_at2y) ** p_at2A))
                                        + ((c_MiRs_at3Z / p_at2G) ** p_at2I)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at40
                            -> let
                                 c_RESTc_at43 = ((toVector x_at40) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at41 = ((toVector x_at40) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2M
                                  * ((p_at2W + ((c_MiRs_at41 / p_at2O) ** p_at2Q))
                                     / (((1 + p_at2W) + ((c_MiRs_at41 / p_at2O) ** p_at2Q))
                                        + ((c_RESTc_at43 / p_at2S) ** p_at2U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at44
                            -> let c_PTB_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 0)
                               in (p_at2Y * c_PTB_at45))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at46
                            -> let c_NPTB_at47 = ((toVector x_at46) Data.Vector.Unboxed.! 1)
                               in (p_at30 * c_NPTB_at47))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at48
                            -> let c_MiRs_at49 = ((toVector x_at48) Data.Vector.Unboxed.! 2)
                               in (p_at32 * c_MiRs_at49))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4a
                            -> let c_RESTc_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 3)
                               in (p_at34 * c_RESTc_at4b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4c
                            -> let
                                 c_EndoNeuroTFs_at4d = ((toVector x_at4c) Data.Vector.Unboxed.! 4)
                               in (p_at36 * c_EndoNeuroTFs_at4d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at37
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4S
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                            (g_at33, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                            (g_at31, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                            (g_at2X, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                            (g_at2V, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2U = Functions.belowten' g_at2T
                            (g_at2T, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                            (g_at2R, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2Q = Functions.belowten' g_at2P
                            (g_at2P, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2I = Functions.belowten' g_at2H
                            (g_at2H, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2D
                            (g_at2D, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2B
                            (g_at2B, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2A = Functions.belowten' g_at2z
                            (g_at2z, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2u = code-0.1.0.0:Genome.FixedList.Functions.double g_at2t
                            (g_at2t, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2s = Functions.belowten' g_at2r
                            (g_at2r, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                            (g_at2p, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2n
                            (g_at2n, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                            (g_at2l, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2i = Functions.belowten' g_at2h
                            (g_at2h, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2e = Functions.belowten' g_at2d
                            (g_at2d, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2a = Functions.belowten' g_at29
                            (g_at29, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at24 = Functions.belowten' g_at23
                            (g_at23, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at20
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                            (g_at1Z, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at1Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                            (g_at1X, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at4e) = Genome.Split.split genome_at37
                          in
                            \ desc_at38
                              -> case desc_at38 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6T
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7z
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                      (g_at6P, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                      (g_at6N, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                      (g_at6J, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6G = Functions.belowten' g_at6F
                      (g_at6F, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6C = Functions.belowten' g_at6B
                      (g_at6B, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                      (g_at6z, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                      (g_at6x, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                      (g_at6v, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6u = Functions.belowten' g_at6t
                      (g_at6t, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                      (g_at6r, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6p
                      (g_at6p, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6n
                      (g_at6n, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6m = Functions.belowten' g_at6l
                      (g_at6l, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                      (g_at6j, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                      (g_at6h, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                      (g_at6f, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6e = Functions.belowten' g_at6d
                      (g_at6d, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                      (g_at6b, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at6a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                      (g_at69, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at68
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                      (g_at67, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                      (g_at65, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at64 = Functions.belowten' g_at63
                      (g_at63, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                      (g_at61, gpart_at79) = Genome.Split.split gpart_at78
                      p_at60 = Functions.belowten' g_at5Z
                      (g_at5Z, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                      (g_at5X, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5W = Functions.belowten' g_at5V
                      (g_at5V, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                      (g_at5T, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                      (g_at5R, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5Q = Functions.belowten' g_at5P
                      (g_at5P, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                      (g_at5N, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                      (g_at5L, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5J
                      (g_at5J, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                      (g_at5F, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                      (g_at5z, gpart_at6V) = Genome.Split.split genome_at6T
                    in
                      [Reaction
                         (\ x_at7A
                            -> let c_MiRs_at7B = ((toVector x_at7A) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5I
                                  / (1
                                     + (((p_at5A / p_at5K) ** p_at5M)
                                        + ((c_MiRs_at7B / p_at5O) ** p_at5Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7C
                            -> let
                                 c_MiRs_at7E = ((toVector x_at7C) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7D = ((toVector x_at7C) Data.Vector.Unboxed.! 3)
                                 c_PTB_at7F = ((toVector x_at7C) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5S
                                  / (1
                                     + ((((c_RESTc_at7D / p_at5U) ** p_at5W)
                                         + ((c_MiRs_at7E / p_at5Y) ** p_at60))
                                        + ((c_PTB_at7F / p_at62) ** p_at64)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7G
                            -> let c_RESTc_at7H = ((toVector x_at7G) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at66
                                  * (p_at6g
                                     / ((1 + p_at6g) + ((c_RESTc_at7H / p_at6c) ** p_at6e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7I
                            -> let
                                 c_MiRs_at7L = ((toVector x_at7I) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7J = ((toVector x_at7I) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6i
                                  * ((p_at6w + ((c_PTB_at7J / p_at6k) ** p_at6m))
                                     / (((1 + p_at6w) + ((c_PTB_at7J / p_at6k) ** p_at6m))
                                        + ((c_MiRs_at7L / p_at6s) ** p_at6u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7M
                            -> let
                                 c_RESTc_at7P = ((toVector x_at7M) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7N = ((toVector x_at7M) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6y
                                  * ((p_at6I + ((c_MiRs_at7N / p_at6A) ** p_at6C))
                                     / (((1 + p_at6I) + ((c_MiRs_at7N / p_at6A) ** p_at6C))
                                        + ((c_RESTc_at7P / p_at6E) ** p_at6G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7Q
                            -> let c_PTB_at7R = ((toVector x_at7Q) Data.Vector.Unboxed.! 0)
                               in (p_at6K * c_PTB_at7R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7S
                            -> let c_NPTB_at7T = ((toVector x_at7S) Data.Vector.Unboxed.! 1)
                               in (p_at6M * c_NPTB_at7T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7U
                            -> let c_MiRs_at7V = ((toVector x_at7U) Data.Vector.Unboxed.! 2)
                               in (p_at6O * c_MiRs_at7V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7W
                            -> let c_RESTc_at7X = ((toVector x_at7W) Data.Vector.Unboxed.! 3)
                               in (p_at6Q * c_RESTc_at7X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7Y
                            -> let
                                 c_EndoNeuroTFs_at7Z = ((toVector x_at7Y) Data.Vector.Unboxed.! 4)
                               in (p_at6S * c_EndoNeuroTFs_at7Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6T
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8E
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                            (g_at6P, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                            (g_at6N, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6K = code-0.1.0.0:Genome.FixedList.Functions.double g_at6J
                            (g_at6J, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6G = Functions.belowten' g_at6F
                            (g_at6F, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6C = Functions.belowten' g_at6B
                            (g_at6B, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                            (g_at6z, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6y = code-0.1.0.0:Genome.FixedList.Functions.double g_at6x
                            (g_at6x, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                            (g_at6v, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6u = Functions.belowten' g_at6t
                            (g_at6t, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6s = code-0.1.0.0:Genome.FixedList.Functions.double g_at6r
                            (g_at6r, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6p
                            (g_at6p, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6n
                            (g_at6n, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6m = Functions.belowten' g_at6l
                            (g_at6l, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                            (g_at6j, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at6i = code-0.1.0.0:Genome.FixedList.Functions.double g_at6h
                            (g_at6h, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                            (g_at6f, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at6e = Functions.belowten' g_at6d
                            (g_at6d, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                            (g_at6b, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at6a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                            (g_at69, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at68
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                            (g_at67, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                            (g_at65, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at64 = Functions.belowten' g_at63
                            (g_at63, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                            (g_at61, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at60 = Functions.belowten' g_at5Z
                            (g_at5Z, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                            (g_at5X, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5W = Functions.belowten' g_at5V
                            (g_at5V, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                            (g_at5T, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                            (g_at5R, gpart_at89) = Genome.Split.split gpart_at88
                            p_at5Q = Functions.belowten' g_at5P
                            (g_at5P, gpart_at88) = Genome.Split.split gpart_at87
                            p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                            (g_at5N, gpart_at87) = Genome.Split.split gpart_at86
                            p_at5M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                            (g_at5L, gpart_at86) = Genome.Split.split gpart_at85
                            p_at5K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5J
                            (g_at5J, gpart_at85) = Genome.Split.split gpart_at84
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                            (g_at5F, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at82) = Genome.Split.split gpart_at81
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at81) = Genome.Split.split gpart_at80
                            p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                            (g_at5z, gpart_at80) = Genome.Split.split genome_at6T
                          in
                            \ desc_at6U
                              -> case desc_at6U of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   _ -> Nothing }}
