src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a26zS
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Az
                      p_a26zR = double g_a26zQ
                      (g_a26zQ, gpart_a26Az) = Genome.Split.split gpart_a26Ay
                      p_a26zP = double g_a26zO
                      (g_a26zO, gpart_a26Ay) = Genome.Split.split gpart_a26Ax
                      p_a26zN = double g_a26zM
                      (g_a26zM, gpart_a26Ax) = Genome.Split.split gpart_a26Aw
                      p_a26zL = double g_a26zK
                      (g_a26zK, gpart_a26Aw) = Genome.Split.split gpart_a26Av
                      p_a26zJ = double g_a26zI
                      (g_a26zI, gpart_a26Av) = Genome.Split.split gpart_a26Au
                      p_a26zH = double g_a26zG
                      (g_a26zG, gpart_a26Au) = Genome.Split.split gpart_a26At
                      p_a26zF = Functions.belowten' g_a26zE
                      (g_a26zE, gpart_a26At) = Genome.Split.split gpart_a26As
                      p_a26zD = double g_a26zC
                      (g_a26zC, gpart_a26As) = Genome.Split.split gpart_a26Ar
                      p_a26zB = Functions.belowten' g_a26zA
                      (g_a26zA, gpart_a26Ar) = Genome.Split.split gpart_a26Aq
                      p_a26zz = double g_a26zy
                      (g_a26zy, gpart_a26Aq) = Genome.Split.split gpart_a26Ap
                      p_a26zx = double g_a26zw
                      (g_a26zw, gpart_a26Ap) = Genome.Split.split gpart_a26Ao
                      p_a26zv = double g_a26zu
                      (g_a26zu, gpart_a26Ao) = Genome.Split.split gpart_a26An
                      p_a26zt = Functions.belowten' g_a26zs
                      (g_a26zs, gpart_a26An) = Genome.Split.split gpart_a26Am
                      p_a26zr = double g_a26zq
                      (g_a26zq, gpart_a26Am) = Genome.Split.split gpart_a26Al
                      p_a26zp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zo
                      (g_a26zo, gpart_a26Al) = Genome.Split.split gpart_a26Ak
                      p_a26zn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zm
                      (g_a26zm, gpart_a26Ak) = Genome.Split.split gpart_a26Aj
                      p_a26zl = Functions.belowten' g_a26zk
                      (g_a26zk, gpart_a26Aj) = Genome.Split.split gpart_a26Ai
                      p_a26zj = double g_a26zi
                      (g_a26zi, gpart_a26Ai) = Genome.Split.split gpart_a26Ah
                      p_a26zh = double g_a26zg
                      (g_a26zg, gpart_a26Ah) = Genome.Split.split gpart_a26Ag
                      p_a26zf = double g_a26ze
                      (g_a26ze, gpart_a26Ag) = Genome.Split.split gpart_a26Af
                      p_a26zd = Functions.belowten' g_a26zc
                      (g_a26zc, gpart_a26Af) = Genome.Split.split gpart_a26Ae
                      p_a26zb = double g_a26za
                      (g_a26za, gpart_a26Ae) = Genome.Split.split gpart_a26Ad
                      p_a26z9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26z8
                      (g_a26z8, gpart_a26Ad) = Genome.Split.split gpart_a26Ac
                      p_a26z7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26z6
                      (g_a26z6, gpart_a26Ac) = Genome.Split.split gpart_a26Ab
                      p_a26z5 = double g_a26z4
                      (g_a26z4, gpart_a26Ab) = Genome.Split.split gpart_a26Aa
                      p_a26z3 = double g_a26z2
                      (g_a26z2, gpart_a26Aa) = Genome.Split.split gpart_a26A9
                      p_a26z1 = Functions.belowten' g_a26z0
                      (g_a26z0, gpart_a26A9) = Genome.Split.split gpart_a26A8
                      p_a26yZ = double g_a26yY
                      (g_a26yY, gpart_a26A8) = Genome.Split.split gpart_a26A7
                      p_a26yX = Functions.belowten' g_a26yW
                      (g_a26yW, gpart_a26A7) = Genome.Split.split gpart_a26A6
                      p_a26yV = double g_a26yU
                      (g_a26yU, gpart_a26A6) = Genome.Split.split gpart_a26A5
                      p_a26yT = Functions.belowten' g_a26yS
                      (g_a26yS, gpart_a26A5) = Genome.Split.split gpart_a26A4
                      p_a26yR = double g_a26yQ
                      (g_a26yQ, gpart_a26A4) = Genome.Split.split gpart_a26A3
                      p_a26yP = double g_a26yO
                      (g_a26yO, gpart_a26A3) = Genome.Split.split gpart_a26A2
                      p_a26yN = Functions.belowten' g_a26yM
                      (g_a26yM, gpart_a26A2) = Genome.Split.split gpart_a26A1
                      p_a26yL = double g_a26yK
                      (g_a26yK, gpart_a26A1) = Genome.Split.split gpart_a26A0
                      p_a26yJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26yI
                      (g_a26yI, gpart_a26A0) = Genome.Split.split gpart_a26zZ
                      p_a26yH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26yG
                      (g_a26yG, gpart_a26zZ) = Genome.Split.split gpart_a26zY
                      p_a26yF = double g_a26yE
                      (g_a26yE, gpart_a26zY) = Genome.Split.split gpart_a26zX
                      p_a26yD = double g_a26yC
                      (g_a26yC, gpart_a26zX) = Genome.Split.split gpart_a26zW
                      p_a26yB = double g_a26yA
                      (g_a26yA, gpart_a26zW) = Genome.Split.split gpart_a26zV
                      p_a26yz = double g_a26yy
                      (g_a26yy, gpart_a26zV) = Genome.Split.split gpart_a26zU
                      p_a26yx = double g_a26yw
                      (g_a26yw, gpart_a26zU) = Genome.Split.split genome_a26zS
                    in  \ x_a26AA
                          -> let
                               c_PTB_a26AD
                                 = ((Data.Fixed.Vector.toVector x_a26AA) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26AB
                                 = ((Data.Fixed.Vector.toVector x_a26AA) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26AJ
                                 = ((Data.Fixed.Vector.toVector x_a26AA) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26AE
                                 = ((Data.Fixed.Vector.toVector x_a26AA) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26AW
                                 = ((Data.Fixed.Vector.toVector x_a26AA) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26yF / (1 + ((c_MiRs_a26AB / p_a26yL) ** p_a26yN)))
                                    + (negate (p_a26zJ * c_PTB_a26AD))),
                                   ((p_a26yP
                                     * ((p_a26z3 + ((c_RESTc_a26AE / p_a26yR) ** p_a26yT))
                                        / (((1 + p_a26z3) + ((c_RESTc_a26AE / p_a26yR) ** p_a26yT))
                                           + (((c_MiRs_a26AB / p_a26yV) ** p_a26yX)
                                              + ((c_PTB_a26AD / p_a26yZ) ** p_a26z1)))))
                                    + (negate (p_a26zL * c_NPTB_a26AJ))),
                                   ((p_a26z5
                                     * ((p_a26zf + ((p_a26yB / p_a26z7) ** p_a26z9))
                                        / (((1 + p_a26zf) + ((p_a26yB / p_a26z7) ** p_a26z9))
                                           + ((c_RESTc_a26AE / p_a26zb) ** p_a26zd))))
                                    + (negate (p_a26zN * c_MiRs_a26AB))),
                                   ((p_a26zh
                                     * ((p_a26zv + ((c_PTB_a26AD / p_a26zj) ** p_a26zl))
                                        / (((1 + p_a26zv) + ((c_PTB_a26AD / p_a26zj) ** p_a26zl))
                                           + (((p_a26yx / p_a26zn) ** p_a26zp)
                                              + ((c_MiRs_a26AB / p_a26zr) ** p_a26zt)))))
                                    + (negate (p_a26zP * c_RESTc_a26AE))),
                                   ((p_a26zx
                                     * ((p_a26zH + ((c_MiRs_a26AB / p_a26zz) ** p_a26zB))
                                        / (((1 + p_a26zH) + ((c_MiRs_a26AB / p_a26zz) ** p_a26zB))
                                           + ((c_RESTc_a26AE / p_a26zD) ** p_a26zF))))
                                    + (negate (p_a26zR * c_EndoNeuroTFs_a26AW)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511663",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511665",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511689",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511691",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511705",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511707",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26zS
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26BC
                            p_a26zR = double g_a26zQ
                            (g_a26zQ, gpart_a26BC) = Genome.Split.split gpart_a26BB
                            p_a26zP = double g_a26zO
                            (g_a26zO, gpart_a26BB) = Genome.Split.split gpart_a26BA
                            p_a26zN = double g_a26zM
                            (g_a26zM, gpart_a26BA) = Genome.Split.split gpart_a26Bz
                            p_a26zL = double g_a26zK
                            (g_a26zK, gpart_a26Bz) = Genome.Split.split gpart_a26By
                            p_a26zJ = double g_a26zI
                            (g_a26zI, gpart_a26By) = Genome.Split.split gpart_a26Bx
                            p_a26zH = double g_a26zG
                            (g_a26zG, gpart_a26Bx) = Genome.Split.split gpart_a26Bw
                            p_a26zF = Functions.belowten' g_a26zE
                            (g_a26zE, gpart_a26Bw) = Genome.Split.split gpart_a26Bv
                            p_a26zD = double g_a26zC
                            (g_a26zC, gpart_a26Bv) = Genome.Split.split gpart_a26Bu
                            p_a26zB = Functions.belowten' g_a26zA
                            (g_a26zA, gpart_a26Bu) = Genome.Split.split gpart_a26Bt
                            p_a26zz = double g_a26zy
                            (g_a26zy, gpart_a26Bt) = Genome.Split.split gpart_a26Bs
                            p_a26zx = double g_a26zw
                            (g_a26zw, gpart_a26Bs) = Genome.Split.split gpart_a26Br
                            p_a26zv = double g_a26zu
                            (g_a26zu, gpart_a26Br) = Genome.Split.split gpart_a26Bq
                            p_a26zt = Functions.belowten' g_a26zs
                            (g_a26zs, gpart_a26Bq) = Genome.Split.split gpart_a26Bp
                            p_a26zr = double g_a26zq
                            (g_a26zq, gpart_a26Bp) = Genome.Split.split gpart_a26Bo
                            p_a26zp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zo
                            (g_a26zo, gpart_a26Bo) = Genome.Split.split gpart_a26Bn
                            p_a26zn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26zm
                            (g_a26zm, gpart_a26Bn) = Genome.Split.split gpart_a26Bm
                            p_a26zl = Functions.belowten' g_a26zk
                            (g_a26zk, gpart_a26Bm) = Genome.Split.split gpart_a26Bl
                            p_a26zj = double g_a26zi
                            (g_a26zi, gpart_a26Bl) = Genome.Split.split gpart_a26Bk
                            p_a26zh = double g_a26zg
                            (g_a26zg, gpart_a26Bk) = Genome.Split.split gpart_a26Bj
                            p_a26zf = double g_a26ze
                            (g_a26ze, gpart_a26Bj) = Genome.Split.split gpart_a26Bi
                            p_a26zd = Functions.belowten' g_a26zc
                            (g_a26zc, gpart_a26Bi) = Genome.Split.split gpart_a26Bh
                            p_a26zb = double g_a26za
                            (g_a26za, gpart_a26Bh) = Genome.Split.split gpart_a26Bg
                            p_a26z9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26z8
                            (g_a26z8, gpart_a26Bg) = Genome.Split.split gpart_a26Bf
                            p_a26z7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26z6
                            (g_a26z6, gpart_a26Bf) = Genome.Split.split gpart_a26Be
                            p_a26z5 = double g_a26z4
                            (g_a26z4, gpart_a26Be) = Genome.Split.split gpart_a26Bd
                            p_a26z3 = double g_a26z2
                            (g_a26z2, gpart_a26Bd) = Genome.Split.split gpart_a26Bc
                            p_a26z1 = Functions.belowten' g_a26z0
                            (g_a26z0, gpart_a26Bc) = Genome.Split.split gpart_a26Bb
                            p_a26yZ = double g_a26yY
                            (g_a26yY, gpart_a26Bb) = Genome.Split.split gpart_a26Ba
                            p_a26yX = Functions.belowten' g_a26yW
                            (g_a26yW, gpart_a26Ba) = Genome.Split.split gpart_a26B9
                            p_a26yV = double g_a26yU
                            (g_a26yU, gpart_a26B9) = Genome.Split.split gpart_a26B8
                            p_a26yT = Functions.belowten' g_a26yS
                            (g_a26yS, gpart_a26B8) = Genome.Split.split gpart_a26B7
                            p_a26yR = double g_a26yQ
                            (g_a26yQ, gpart_a26B7) = Genome.Split.split gpart_a26B6
                            p_a26yP = double g_a26yO
                            (g_a26yO, gpart_a26B6) = Genome.Split.split gpart_a26B5
                            p_a26yN = Functions.belowten' g_a26yM
                            (g_a26yM, gpart_a26B5) = Genome.Split.split gpart_a26B4
                            p_a26yL = double g_a26yK
                            (g_a26yK, gpart_a26B4) = Genome.Split.split gpart_a26B3
                            p_a26yJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26yI
                            (g_a26yI, gpart_a26B3) = Genome.Split.split gpart_a26B2
                            p_a26yH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26yG
                            (g_a26yG, gpart_a26B2) = Genome.Split.split gpart_a26B1
                            p_a26yF = double g_a26yE
                            (g_a26yE, gpart_a26B1) = Genome.Split.split gpart_a26B0
                            p_a26yD = double g_a26yC
                            (g_a26yC, gpart_a26B0) = Genome.Split.split gpart_a26AZ
                            p_a26yB = double g_a26yA
                            (g_a26yA, gpart_a26AZ) = Genome.Split.split gpart_a26AY
                            p_a26yz = double g_a26yy
                            (g_a26yy, gpart_a26AY) = Genome.Split.split gpart_a26AX
                            p_a26yx = double g_a26yw
                            (g_a26yw, gpart_a26AX) = Genome.Split.split genome_a26zS
                          in
                            \ desc_a26zT
                              -> case desc_a26zT of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yx)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yz)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yB)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yD)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yF)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yH)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yJ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yL)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yN)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yP)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yR)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yT)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yV)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yX)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26yZ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26z1)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26z3)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26z5)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26z7)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26z9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zb)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zd)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zf)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zh)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zl)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zn)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zp)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zr)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zt)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zv)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zx)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zz)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zB)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zD)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zF)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zH)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zJ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zL)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zN)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zP)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26zR)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a26E8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26EP
                      p_a26E7 = double g_a26E6
                      (g_a26E6, gpart_a26EP) = Genome.Split.split gpart_a26EO
                      p_a26E5 = double g_a26E4
                      (g_a26E4, gpart_a26EO) = Genome.Split.split gpart_a26EN
                      p_a26E3 = double g_a26E2
                      (g_a26E2, gpart_a26EN) = Genome.Split.split gpart_a26EM
                      p_a26E1 = double g_a26E0
                      (g_a26E0, gpart_a26EM) = Genome.Split.split gpart_a26EL
                      p_a26DZ = double g_a26DY
                      (g_a26DY, gpart_a26EL) = Genome.Split.split gpart_a26EK
                      p_a26DX = double g_a26DW
                      (g_a26DW, gpart_a26EK) = Genome.Split.split gpart_a26EJ
                      p_a26DV = Functions.belowten' g_a26DU
                      (g_a26DU, gpart_a26EJ) = Genome.Split.split gpart_a26EI
                      p_a26DT = double g_a26DS
                      (g_a26DS, gpart_a26EI) = Genome.Split.split gpart_a26EH
                      p_a26DR = Functions.belowten' g_a26DQ
                      (g_a26DQ, gpart_a26EH) = Genome.Split.split gpart_a26EG
                      p_a26DP = double g_a26DO
                      (g_a26DO, gpart_a26EG) = Genome.Split.split gpart_a26EF
                      p_a26DN = double g_a26DM
                      (g_a26DM, gpart_a26EF) = Genome.Split.split gpart_a26EE
                      p_a26DL = double g_a26DK
                      (g_a26DK, gpart_a26EE) = Genome.Split.split gpart_a26ED
                      p_a26DJ = Functions.belowten' g_a26DI
                      (g_a26DI, gpart_a26ED) = Genome.Split.split gpart_a26EC
                      p_a26DH = double g_a26DG
                      (g_a26DG, gpart_a26EC) = Genome.Split.split gpart_a26EB
                      p_a26DF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26DE
                      (g_a26DE, gpart_a26EB) = Genome.Split.split gpart_a26EA
                      p_a26DD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26DC
                      (g_a26DC, gpart_a26EA) = Genome.Split.split gpart_a26Ez
                      p_a26DB = Functions.belowten' g_a26DA
                      (g_a26DA, gpart_a26Ez) = Genome.Split.split gpart_a26Ey
                      p_a26Dz = double g_a26Dy
                      (g_a26Dy, gpart_a26Ey) = Genome.Split.split gpart_a26Ex
                      p_a26Dx = double g_a26Dw
                      (g_a26Dw, gpart_a26Ex) = Genome.Split.split gpart_a26Ew
                      p_a26Dv = double g_a26Du
                      (g_a26Du, gpart_a26Ew) = Genome.Split.split gpart_a26Ev
                      p_a26Dt = Functions.belowten' g_a26Ds
                      (g_a26Ds, gpart_a26Ev) = Genome.Split.split gpart_a26Eu
                      p_a26Dr = double g_a26Dq
                      (g_a26Dq, gpart_a26Eu) = Genome.Split.split gpart_a26Et
                      p_a26Dp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Do
                      (g_a26Do, gpart_a26Et) = Genome.Split.split gpart_a26Es
                      p_a26Dn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Dm
                      (g_a26Dm, gpart_a26Es) = Genome.Split.split gpart_a26Er
                      p_a26Dl = double g_a26Dk
                      (g_a26Dk, gpart_a26Er) = Genome.Split.split gpart_a26Eq
                      p_a26Dj = double g_a26Di
                      (g_a26Di, gpart_a26Eq) = Genome.Split.split gpart_a26Ep
                      p_a26Dh = Functions.belowten' g_a26Dg
                      (g_a26Dg, gpart_a26Ep) = Genome.Split.split gpart_a26Eo
                      p_a26Df = double g_a26De
                      (g_a26De, gpart_a26Eo) = Genome.Split.split gpart_a26En
                      p_a26Dd = Functions.belowten' g_a26Dc
                      (g_a26Dc, gpart_a26En) = Genome.Split.split gpart_a26Em
                      p_a26Db = double g_a26Da
                      (g_a26Da, gpart_a26Em) = Genome.Split.split gpart_a26El
                      p_a26D9 = Functions.belowten' g_a26D8
                      (g_a26D8, gpart_a26El) = Genome.Split.split gpart_a26Ek
                      p_a26D7 = double g_a26D6
                      (g_a26D6, gpart_a26Ek) = Genome.Split.split gpart_a26Ej
                      p_a26D5 = double g_a26D4
                      (g_a26D4, gpart_a26Ej) = Genome.Split.split gpart_a26Ei
                      p_a26D3 = Functions.belowten' g_a26D2
                      (g_a26D2, gpart_a26Ei) = Genome.Split.split gpart_a26Eh
                      p_a26D1 = double g_a26D0
                      (g_a26D0, gpart_a26Eh) = Genome.Split.split gpart_a26Eg
                      p_a26CZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26CY
                      (g_a26CY, gpart_a26Eg) = Genome.Split.split gpart_a26Ef
                      p_a26CX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26CW
                      (g_a26CW, gpart_a26Ef) = Genome.Split.split gpart_a26Ee
                      p_a26CV = double g_a26CU
                      (g_a26CU, gpart_a26Ee) = Genome.Split.split gpart_a26Ed
                      p_a26CT = double g_a26CS
                      (g_a26CS, gpart_a26Ed) = Genome.Split.split gpart_a26Ec
                      p_a26CR = double g_a26CQ
                      (g_a26CQ, gpart_a26Ec) = Genome.Split.split gpart_a26Eb
                      p_a26CP = double g_a26CO
                      (g_a26CO, gpart_a26Eb) = Genome.Split.split gpart_a26Ea
                      p_a26CN = double g_a26CM
                      (g_a26CM, gpart_a26Ea) = Genome.Split.split genome_a26E8
                    in  \ x_a26EQ
                          -> let
                               c_PTB_a26ET
                                 = ((Data.Fixed.Vector.toVector x_a26EQ) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26ER
                                 = ((Data.Fixed.Vector.toVector x_a26EQ) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26EZ
                                 = ((Data.Fixed.Vector.toVector x_a26EQ) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26EU
                                 = ((Data.Fixed.Vector.toVector x_a26EQ) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26Fc
                                 = ((Data.Fixed.Vector.toVector x_a26EQ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26CV / (1 + ((c_MiRs_a26ER / p_a26D1) ** p_a26D3)))
                                    + (negate (p_a26DZ * c_PTB_a26ET))),
                                   ((p_a26D5
                                     * ((p_a26Dj + ((c_RESTc_a26EU / p_a26D7) ** p_a26D9))
                                        / (((1 + p_a26Dj) + ((c_RESTc_a26EU / p_a26D7) ** p_a26D9))
                                           + (((c_MiRs_a26ER / p_a26Db) ** p_a26Dd)
                                              + ((c_PTB_a26ET / p_a26Df) ** p_a26Dh)))))
                                    + (negate (p_a26E1 * c_NPTB_a26EZ))),
                                   ((p_a26Dl
                                     * (p_a26Dv
                                        / ((1 + p_a26Dv) + ((c_RESTc_a26EU / p_a26Dr) ** p_a26Dt))))
                                    + (negate (p_a26E3 * c_MiRs_a26ER))),
                                   ((p_a26Dx
                                     * ((p_a26DL + ((c_PTB_a26ET / p_a26Dz) ** p_a26DB))
                                        / (((1 + p_a26DL) + ((c_PTB_a26ET / p_a26Dz) ** p_a26DB))
                                           + (((p_a26CN / p_a26DD) ** p_a26DF)
                                              + ((c_MiRs_a26ER / p_a26DH) ** p_a26DJ)))))
                                    + (negate (p_a26E5 * c_RESTc_a26EU))),
                                   ((p_a26DN
                                     * ((p_a26DX + ((c_MiRs_a26ER / p_a26DP) ** p_a26DR))
                                        / (((1 + p_a26DX) + ((c_MiRs_a26ER / p_a26DP) ** p_a26DR))
                                           + ((c_RESTc_a26EU / p_a26DT) ** p_a26DV))))
                                    + (negate (p_a26E7 * c_EndoNeuroTFs_a26Fc)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511927",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511929",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511953",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511955",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511969",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511971",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511999",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26E8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26FS
                            p_a26E7 = double g_a26E6
                            (g_a26E6, gpart_a26FS) = Genome.Split.split gpart_a26FR
                            p_a26E5 = double g_a26E4
                            (g_a26E4, gpart_a26FR) = Genome.Split.split gpart_a26FQ
                            p_a26E3 = double g_a26E2
                            (g_a26E2, gpart_a26FQ) = Genome.Split.split gpart_a26FP
                            p_a26E1 = double g_a26E0
                            (g_a26E0, gpart_a26FP) = Genome.Split.split gpart_a26FO
                            p_a26DZ = double g_a26DY
                            (g_a26DY, gpart_a26FO) = Genome.Split.split gpart_a26FN
                            p_a26DX = double g_a26DW
                            (g_a26DW, gpart_a26FN) = Genome.Split.split gpart_a26FM
                            p_a26DV = Functions.belowten' g_a26DU
                            (g_a26DU, gpart_a26FM) = Genome.Split.split gpart_a26FL
                            p_a26DT = double g_a26DS
                            (g_a26DS, gpart_a26FL) = Genome.Split.split gpart_a26FK
                            p_a26DR = Functions.belowten' g_a26DQ
                            (g_a26DQ, gpart_a26FK) = Genome.Split.split gpart_a26FJ
                            p_a26DP = double g_a26DO
                            (g_a26DO, gpart_a26FJ) = Genome.Split.split gpart_a26FI
                            p_a26DN = double g_a26DM
                            (g_a26DM, gpart_a26FI) = Genome.Split.split gpart_a26FH
                            p_a26DL = double g_a26DK
                            (g_a26DK, gpart_a26FH) = Genome.Split.split gpart_a26FG
                            p_a26DJ = Functions.belowten' g_a26DI
                            (g_a26DI, gpart_a26FG) = Genome.Split.split gpart_a26FF
                            p_a26DH = double g_a26DG
                            (g_a26DG, gpart_a26FF) = Genome.Split.split gpart_a26FE
                            p_a26DF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26DE
                            (g_a26DE, gpart_a26FE) = Genome.Split.split gpart_a26FD
                            p_a26DD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26DC
                            (g_a26DC, gpart_a26FD) = Genome.Split.split gpart_a26FC
                            p_a26DB = Functions.belowten' g_a26DA
                            (g_a26DA, gpart_a26FC) = Genome.Split.split gpart_a26FB
                            p_a26Dz = double g_a26Dy
                            (g_a26Dy, gpart_a26FB) = Genome.Split.split gpart_a26FA
                            p_a26Dx = double g_a26Dw
                            (g_a26Dw, gpart_a26FA) = Genome.Split.split gpart_a26Fz
                            p_a26Dv = double g_a26Du
                            (g_a26Du, gpart_a26Fz) = Genome.Split.split gpart_a26Fy
                            p_a26Dt = Functions.belowten' g_a26Ds
                            (g_a26Ds, gpart_a26Fy) = Genome.Split.split gpart_a26Fx
                            p_a26Dr = double g_a26Dq
                            (g_a26Dq, gpart_a26Fx) = Genome.Split.split gpart_a26Fw
                            p_a26Dp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Do
                            (g_a26Do, gpart_a26Fw) = Genome.Split.split gpart_a26Fv
                            p_a26Dn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Dm
                            (g_a26Dm, gpart_a26Fv) = Genome.Split.split gpart_a26Fu
                            p_a26Dl = double g_a26Dk
                            (g_a26Dk, gpart_a26Fu) = Genome.Split.split gpart_a26Ft
                            p_a26Dj = double g_a26Di
                            (g_a26Di, gpart_a26Ft) = Genome.Split.split gpart_a26Fs
                            p_a26Dh = Functions.belowten' g_a26Dg
                            (g_a26Dg, gpart_a26Fs) = Genome.Split.split gpart_a26Fr
                            p_a26Df = double g_a26De
                            (g_a26De, gpart_a26Fr) = Genome.Split.split gpart_a26Fq
                            p_a26Dd = Functions.belowten' g_a26Dc
                            (g_a26Dc, gpart_a26Fq) = Genome.Split.split gpart_a26Fp
                            p_a26Db = double g_a26Da
                            (g_a26Da, gpart_a26Fp) = Genome.Split.split gpart_a26Fo
                            p_a26D9 = Functions.belowten' g_a26D8
                            (g_a26D8, gpart_a26Fo) = Genome.Split.split gpart_a26Fn
                            p_a26D7 = double g_a26D6
                            (g_a26D6, gpart_a26Fn) = Genome.Split.split gpart_a26Fm
                            p_a26D5 = double g_a26D4
                            (g_a26D4, gpart_a26Fm) = Genome.Split.split gpart_a26Fl
                            p_a26D3 = Functions.belowten' g_a26D2
                            (g_a26D2, gpart_a26Fl) = Genome.Split.split gpart_a26Fk
                            p_a26D1 = double g_a26D0
                            (g_a26D0, gpart_a26Fk) = Genome.Split.split gpart_a26Fj
                            p_a26CZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26CY
                            (g_a26CY, gpart_a26Fj) = Genome.Split.split gpart_a26Fi
                            p_a26CX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26CW
                            (g_a26CW, gpart_a26Fi) = Genome.Split.split gpart_a26Fh
                            p_a26CV = double g_a26CU
                            (g_a26CU, gpart_a26Fh) = Genome.Split.split gpart_a26Fg
                            p_a26CT = double g_a26CS
                            (g_a26CS, gpart_a26Fg) = Genome.Split.split gpart_a26Ff
                            p_a26CR = double g_a26CQ
                            (g_a26CQ, gpart_a26Ff) = Genome.Split.split gpart_a26Fe
                            p_a26CP = double g_a26CO
                            (g_a26CO, gpart_a26Fe) = Genome.Split.split gpart_a26Fd
                            p_a26CN = double g_a26CM
                            (g_a26CM, gpart_a26Fd) = Genome.Split.split genome_a26E8
                          in
                            \ desc_a26E9
                              -> case desc_a26E9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CN)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CP)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CR)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CT)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CV)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CX)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26CZ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26D1)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26D3)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26D5)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26D7)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26D9)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Db)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dd)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Df)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dh)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dj)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dl)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dn)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dp)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dr)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dt)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dv)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dx)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Dz)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DB)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DD)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DF)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DH)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DJ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DL)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DN)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DP)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DR)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DT)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DV)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26DZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26E7)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a26Io
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26J5
                      p_a26In = double g_a26Im
                      (g_a26Im, gpart_a26J5) = Genome.Split.split gpart_a26J4
                      p_a26Il = double g_a26Ik
                      (g_a26Ik, gpart_a26J4) = Genome.Split.split gpart_a26J3
                      p_a26Ij = double g_a26Ii
                      (g_a26Ii, gpart_a26J3) = Genome.Split.split gpart_a26J2
                      p_a26Ih = double g_a26Ig
                      (g_a26Ig, gpart_a26J2) = Genome.Split.split gpart_a26J1
                      p_a26If = double g_a26Ie
                      (g_a26Ie, gpart_a26J1) = Genome.Split.split gpart_a26J0
                      p_a26Id = double g_a26Ic
                      (g_a26Ic, gpart_a26J0) = Genome.Split.split gpart_a26IZ
                      p_a26Ib = Functions.belowten' g_a26Ia
                      (g_a26Ia, gpart_a26IZ) = Genome.Split.split gpart_a26IY
                      p_a26I9 = double g_a26I8
                      (g_a26I8, gpart_a26IY) = Genome.Split.split gpart_a26IX
                      p_a26I7 = Functions.belowten' g_a26I6
                      (g_a26I6, gpart_a26IX) = Genome.Split.split gpart_a26IW
                      p_a26I5 = double g_a26I4
                      (g_a26I4, gpart_a26IW) = Genome.Split.split gpart_a26IV
                      p_a26I3 = double g_a26I2
                      (g_a26I2, gpart_a26IV) = Genome.Split.split gpart_a26IU
                      p_a26I1 = double g_a26I0
                      (g_a26I0, gpart_a26IU) = Genome.Split.split gpart_a26IT
                      p_a26HZ = Functions.belowten' g_a26HY
                      (g_a26HY, gpart_a26IT) = Genome.Split.split gpart_a26IS
                      p_a26HX = double g_a26HW
                      (g_a26HW, gpart_a26IS) = Genome.Split.split gpart_a26IR
                      p_a26HV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HU
                      (g_a26HU, gpart_a26IR) = Genome.Split.split gpart_a26IQ
                      p_a26HT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HS
                      (g_a26HS, gpart_a26IQ) = Genome.Split.split gpart_a26IP
                      p_a26HR = Functions.belowten' g_a26HQ
                      (g_a26HQ, gpart_a26IP) = Genome.Split.split gpart_a26IO
                      p_a26HP = double g_a26HO
                      (g_a26HO, gpart_a26IO) = Genome.Split.split gpart_a26IN
                      p_a26HN = double g_a26HM
                      (g_a26HM, gpart_a26IN) = Genome.Split.split gpart_a26IM
                      p_a26HL = double g_a26HK
                      (g_a26HK, gpart_a26IM) = Genome.Split.split gpart_a26IL
                      p_a26HJ = Functions.belowten' g_a26HI
                      (g_a26HI, gpart_a26IL) = Genome.Split.split gpart_a26IK
                      p_a26HH = double g_a26HG
                      (g_a26HG, gpart_a26IK) = Genome.Split.split gpart_a26IJ
                      p_a26HF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HE
                      (g_a26HE, gpart_a26IJ) = Genome.Split.split gpart_a26II
                      p_a26HD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HC
                      (g_a26HC, gpart_a26II) = Genome.Split.split gpart_a26IH
                      p_a26HB = double g_a26HA
                      (g_a26HA, gpart_a26IH) = Genome.Split.split gpart_a26IG
                      p_a26Hz = double g_a26Hy
                      (g_a26Hy, gpart_a26IG) = Genome.Split.split gpart_a26IF
                      p_a26Hx = Functions.belowten' g_a26Hw
                      (g_a26Hw, gpart_a26IF) = Genome.Split.split gpart_a26IE
                      p_a26Hv = double g_a26Hu
                      (g_a26Hu, gpart_a26IE) = Genome.Split.split gpart_a26ID
                      p_a26Ht = Functions.belowten' g_a26Hs
                      (g_a26Hs, gpart_a26ID) = Genome.Split.split gpart_a26IC
                      p_a26Hr = double g_a26Hq
                      (g_a26Hq, gpart_a26IC) = Genome.Split.split gpart_a26IB
                      p_a26Hp = Functions.belowten' g_a26Ho
                      (g_a26Ho, gpart_a26IB) = Genome.Split.split gpart_a26IA
                      p_a26Hn = double g_a26Hm
                      (g_a26Hm, gpart_a26IA) = Genome.Split.split gpart_a26Iz
                      p_a26Hl = double g_a26Hk
                      (g_a26Hk, gpart_a26Iz) = Genome.Split.split gpart_a26Iy
                      p_a26Hj = Functions.belowten' g_a26Hi
                      (g_a26Hi, gpart_a26Iy) = Genome.Split.split gpart_a26Ix
                      p_a26Hh = double g_a26Hg
                      (g_a26Hg, gpart_a26Ix) = Genome.Split.split gpart_a26Iw
                      p_a26Hf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26He
                      (g_a26He, gpart_a26Iw) = Genome.Split.split gpart_a26Iv
                      p_a26Hd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Hc
                      (g_a26Hc, gpart_a26Iv) = Genome.Split.split gpart_a26Iu
                      p_a26Hb = double g_a26Ha
                      (g_a26Ha, gpart_a26Iu) = Genome.Split.split gpart_a26It
                      p_a26H9 = double g_a26H8
                      (g_a26H8, gpart_a26It) = Genome.Split.split gpart_a26Is
                      p_a26H7 = double g_a26H6
                      (g_a26H6, gpart_a26Is) = Genome.Split.split gpart_a26Ir
                      p_a26H5 = double g_a26H4
                      (g_a26H4, gpart_a26Ir) = Genome.Split.split gpart_a26Iq
                      p_a26H3 = double g_a26H2
                      (g_a26H2, gpart_a26Iq) = Genome.Split.split genome_a26Io
                    in  \ x_a26J6
                          -> let
                               c_PTB_a26J9
                                 = ((Data.Fixed.Vector.toVector x_a26J6) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26J7
                                 = ((Data.Fixed.Vector.toVector x_a26J6) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26Jf
                                 = ((Data.Fixed.Vector.toVector x_a26J6) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26Ja
                                 = ((Data.Fixed.Vector.toVector x_a26J6) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26Js
                                 = ((Data.Fixed.Vector.toVector x_a26J6) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Hb / (1 + ((c_MiRs_a26J7 / p_a26Hh) ** p_a26Hj)))
                                    + (negate (p_a26If * c_PTB_a26J9))),
                                   ((p_a26Hl
                                     * ((p_a26Hz + ((c_RESTc_a26Ja / p_a26Hn) ** p_a26Hp))
                                        / (((1 + p_a26Hz) + ((c_RESTc_a26Ja / p_a26Hn) ** p_a26Hp))
                                           + (((c_MiRs_a26J7 / p_a26Hr) ** p_a26Ht)
                                              + ((c_PTB_a26J9 / p_a26Hv) ** p_a26Hx)))))
                                    + (negate (p_a26Ih * c_NPTB_a26Jf))),
                                   ((p_a26HB
                                     * (p_a26HL
                                        / ((1 + p_a26HL) + ((c_RESTc_a26Ja / p_a26HH) ** p_a26HJ))))
                                    + (negate (p_a26Ij * c_MiRs_a26J7))),
                                   ((p_a26HN
                                     * ((p_a26I1 + ((c_PTB_a26J9 / p_a26HP) ** p_a26HR))
                                        / (((1 + p_a26I1) + ((c_PTB_a26J9 / p_a26HP) ** p_a26HR))
                                           + ((c_MiRs_a26J7 / p_a26HX) ** p_a26HZ))))
                                    + (negate (p_a26Il * c_RESTc_a26Ja))),
                                   ((p_a26I3
                                     * ((p_a26Id + ((c_MiRs_a26J7 / p_a26I5) ** p_a26I7))
                                        / (((1 + p_a26Id) + ((c_MiRs_a26J7 / p_a26I5) ** p_a26I7))
                                           + ((c_RESTc_a26Ja / p_a26I9) ** p_a26Ib))))
                                    + (negate (p_a26In * c_EndoNeuroTFs_a26Js)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512191",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512193",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512217",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512219",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512233",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512235",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Io
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26K8
                            p_a26In = double g_a26Im
                            (g_a26Im, gpart_a26K8) = Genome.Split.split gpart_a26K7
                            p_a26Il = double g_a26Ik
                            (g_a26Ik, gpart_a26K7) = Genome.Split.split gpart_a26K6
                            p_a26Ij = double g_a26Ii
                            (g_a26Ii, gpart_a26K6) = Genome.Split.split gpart_a26K5
                            p_a26Ih = double g_a26Ig
                            (g_a26Ig, gpart_a26K5) = Genome.Split.split gpart_a26K4
                            p_a26If = double g_a26Ie
                            (g_a26Ie, gpart_a26K4) = Genome.Split.split gpart_a26K3
                            p_a26Id = double g_a26Ic
                            (g_a26Ic, gpart_a26K3) = Genome.Split.split gpart_a26K2
                            p_a26Ib = Functions.belowten' g_a26Ia
                            (g_a26Ia, gpart_a26K2) = Genome.Split.split gpart_a26K1
                            p_a26I9 = double g_a26I8
                            (g_a26I8, gpart_a26K1) = Genome.Split.split gpart_a26K0
                            p_a26I7 = Functions.belowten' g_a26I6
                            (g_a26I6, gpart_a26K0) = Genome.Split.split gpart_a26JZ
                            p_a26I5 = double g_a26I4
                            (g_a26I4, gpart_a26JZ) = Genome.Split.split gpart_a26JY
                            p_a26I3 = double g_a26I2
                            (g_a26I2, gpart_a26JY) = Genome.Split.split gpart_a26JX
                            p_a26I1 = double g_a26I0
                            (g_a26I0, gpart_a26JX) = Genome.Split.split gpart_a26JW
                            p_a26HZ = Functions.belowten' g_a26HY
                            (g_a26HY, gpart_a26JW) = Genome.Split.split gpart_a26JV
                            p_a26HX = double g_a26HW
                            (g_a26HW, gpart_a26JV) = Genome.Split.split gpart_a26JU
                            p_a26HV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HU
                            (g_a26HU, gpart_a26JU) = Genome.Split.split gpart_a26JT
                            p_a26HT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HS
                            (g_a26HS, gpart_a26JT) = Genome.Split.split gpart_a26JS
                            p_a26HR = Functions.belowten' g_a26HQ
                            (g_a26HQ, gpart_a26JS) = Genome.Split.split gpart_a26JR
                            p_a26HP = double g_a26HO
                            (g_a26HO, gpart_a26JR) = Genome.Split.split gpart_a26JQ
                            p_a26HN = double g_a26HM
                            (g_a26HM, gpart_a26JQ) = Genome.Split.split gpart_a26JP
                            p_a26HL = double g_a26HK
                            (g_a26HK, gpart_a26JP) = Genome.Split.split gpart_a26JO
                            p_a26HJ = Functions.belowten' g_a26HI
                            (g_a26HI, gpart_a26JO) = Genome.Split.split gpart_a26JN
                            p_a26HH = double g_a26HG
                            (g_a26HG, gpart_a26JN) = Genome.Split.split gpart_a26JM
                            p_a26HF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HE
                            (g_a26HE, gpart_a26JM) = Genome.Split.split gpart_a26JL
                            p_a26HD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26HC
                            (g_a26HC, gpart_a26JL) = Genome.Split.split gpart_a26JK
                            p_a26HB = double g_a26HA
                            (g_a26HA, gpart_a26JK) = Genome.Split.split gpart_a26JJ
                            p_a26Hz = double g_a26Hy
                            (g_a26Hy, gpart_a26JJ) = Genome.Split.split gpart_a26JI
                            p_a26Hx = Functions.belowten' g_a26Hw
                            (g_a26Hw, gpart_a26JI) = Genome.Split.split gpart_a26JH
                            p_a26Hv = double g_a26Hu
                            (g_a26Hu, gpart_a26JH) = Genome.Split.split gpart_a26JG
                            p_a26Ht = Functions.belowten' g_a26Hs
                            (g_a26Hs, gpart_a26JG) = Genome.Split.split gpart_a26JF
                            p_a26Hr = double g_a26Hq
                            (g_a26Hq, gpart_a26JF) = Genome.Split.split gpart_a26JE
                            p_a26Hp = Functions.belowten' g_a26Ho
                            (g_a26Ho, gpart_a26JE) = Genome.Split.split gpart_a26JD
                            p_a26Hn = double g_a26Hm
                            (g_a26Hm, gpart_a26JD) = Genome.Split.split gpart_a26JC
                            p_a26Hl = double g_a26Hk
                            (g_a26Hk, gpart_a26JC) = Genome.Split.split gpart_a26JB
                            p_a26Hj = Functions.belowten' g_a26Hi
                            (g_a26Hi, gpart_a26JB) = Genome.Split.split gpart_a26JA
                            p_a26Hh = double g_a26Hg
                            (g_a26Hg, gpart_a26JA) = Genome.Split.split gpart_a26Jz
                            p_a26Hf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26He
                            (g_a26He, gpart_a26Jz) = Genome.Split.split gpart_a26Jy
                            p_a26Hd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Hc
                            (g_a26Hc, gpart_a26Jy) = Genome.Split.split gpart_a26Jx
                            p_a26Hb = double g_a26Ha
                            (g_a26Ha, gpart_a26Jx) = Genome.Split.split gpart_a26Jw
                            p_a26H9 = double g_a26H8
                            (g_a26H8, gpart_a26Jw) = Genome.Split.split gpart_a26Jv
                            p_a26H7 = double g_a26H6
                            (g_a26H6, gpart_a26Jv) = Genome.Split.split gpart_a26Ju
                            p_a26H5 = double g_a26H4
                            (g_a26H4, gpart_a26Ju) = Genome.Split.split gpart_a26Jt
                            p_a26H3 = double g_a26H2
                            (g_a26H2, gpart_a26Jt) = Genome.Split.split genome_a26Io
                          in
                            \ desc_a26Ip
                              -> case desc_a26Ip of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26H3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26H5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26H7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26H9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hb)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hd)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hf)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hh)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hj)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hl)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hn)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hp)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hr)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ht)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hv)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hx)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Hz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HR)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HT)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HV)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HX)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26HZ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I1)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I3)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I5)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26I9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ib)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Id)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26If)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ih)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ij)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Il)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26In)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a26ME
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Nl
                      p_a26MD = double g_a26MC
                      (g_a26MC, gpart_a26Nl) = Genome.Split.split gpart_a26Nk
                      p_a26MB = double g_a26MA
                      (g_a26MA, gpart_a26Nk) = Genome.Split.split gpart_a26Nj
                      p_a26Mz = double g_a26My
                      (g_a26My, gpart_a26Nj) = Genome.Split.split gpart_a26Ni
                      p_a26Mx = double g_a26Mw
                      (g_a26Mw, gpart_a26Ni) = Genome.Split.split gpart_a26Nh
                      p_a26Mv = double g_a26Mu
                      (g_a26Mu, gpart_a26Nh) = Genome.Split.split gpart_a26Ng
                      p_a26Mt = double g_a26Ms
                      (g_a26Ms, gpart_a26Ng) = Genome.Split.split gpart_a26Nf
                      p_a26Mr = Functions.belowten' g_a26Mq
                      (g_a26Mq, gpart_a26Nf) = Genome.Split.split gpart_a26Ne
                      p_a26Mp = double g_a26Mo
                      (g_a26Mo, gpart_a26Ne) = Genome.Split.split gpart_a26Nd
                      p_a26Mn = Functions.belowten' g_a26Mm
                      (g_a26Mm, gpart_a26Nd) = Genome.Split.split gpart_a26Nc
                      p_a26Ml = double g_a26Mk
                      (g_a26Mk, gpart_a26Nc) = Genome.Split.split gpart_a26Nb
                      p_a26Mj = double g_a26Mi
                      (g_a26Mi, gpart_a26Nb) = Genome.Split.split gpart_a26Na
                      p_a26Mh = double g_a26Mg
                      (g_a26Mg, gpart_a26Na) = Genome.Split.split gpart_a26N9
                      p_a26Mf = Functions.belowten' g_a26Me
                      (g_a26Me, gpart_a26N9) = Genome.Split.split gpart_a26N8
                      p_a26Md = double g_a26Mc
                      (g_a26Mc, gpart_a26N8) = Genome.Split.split gpart_a26N7
                      p_a26Mb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ma
                      (g_a26Ma, gpart_a26N7) = Genome.Split.split gpart_a26N6
                      p_a26M9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26M8
                      (g_a26M8, gpart_a26N6) = Genome.Split.split gpart_a26N5
                      p_a26M7 = Functions.belowten' g_a26M6
                      (g_a26M6, gpart_a26N5) = Genome.Split.split gpart_a26N4
                      p_a26M5 = double g_a26M4
                      (g_a26M4, gpart_a26N4) = Genome.Split.split gpart_a26N3
                      p_a26M3 = double g_a26M2
                      (g_a26M2, gpart_a26N3) = Genome.Split.split gpart_a26N2
                      p_a26M1 = double g_a26M0
                      (g_a26M0, gpart_a26N2) = Genome.Split.split gpart_a26N1
                      p_a26LZ = Functions.belowten' g_a26LY
                      (g_a26LY, gpart_a26N1) = Genome.Split.split gpart_a26N0
                      p_a26LX = double g_a26LW
                      (g_a26LW, gpart_a26N0) = Genome.Split.split gpart_a26MZ
                      p_a26LV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26LU
                      (g_a26LU, gpart_a26MZ) = Genome.Split.split gpart_a26MY
                      p_a26LT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26LS
                      (g_a26LS, gpart_a26MY) = Genome.Split.split gpart_a26MX
                      p_a26LR = double g_a26LQ
                      (g_a26LQ, gpart_a26MX) = Genome.Split.split gpart_a26MW
                      p_a26LP = double g_a26LO
                      (g_a26LO, gpart_a26MW) = Genome.Split.split gpart_a26MV
                      p_a26LN = Functions.belowten' g_a26LM
                      (g_a26LM, gpart_a26MV) = Genome.Split.split gpart_a26MU
                      p_a26LL = double g_a26LK
                      (g_a26LK, gpart_a26MU) = Genome.Split.split gpart_a26MT
                      p_a26LJ = Functions.belowten' g_a26LI
                      (g_a26LI, gpart_a26MT) = Genome.Split.split gpart_a26MS
                      p_a26LH = double g_a26LG
                      (g_a26LG, gpart_a26MS) = Genome.Split.split gpart_a26MR
                      p_a26LF = Functions.belowten' g_a26LE
                      (g_a26LE, gpart_a26MR) = Genome.Split.split gpart_a26MQ
                      p_a26LD = double g_a26LC
                      (g_a26LC, gpart_a26MQ) = Genome.Split.split gpart_a26MP
                      p_a26LB = double g_a26LA
                      (g_a26LA, gpart_a26MP) = Genome.Split.split gpart_a26MO
                      p_a26Lz = Functions.belowten' g_a26Ly
                      (g_a26Ly, gpart_a26MO) = Genome.Split.split gpart_a26MN
                      p_a26Lx = double g_a26Lw
                      (g_a26Lw, gpart_a26MN) = Genome.Split.split gpart_a26MM
                      p_a26Lv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Lu
                      (g_a26Lu, gpart_a26MM) = Genome.Split.split gpart_a26ML
                      p_a26Lt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ls
                      (g_a26Ls, gpart_a26ML) = Genome.Split.split gpart_a26MK
                      p_a26Lr = double g_a26Lq
                      (g_a26Lq, gpart_a26MK) = Genome.Split.split gpart_a26MJ
                      p_a26Lp = double g_a26Lo
                      (g_a26Lo, gpart_a26MJ) = Genome.Split.split gpart_a26MI
                      p_a26Ln = double g_a26Lm
                      (g_a26Lm, gpart_a26MI) = Genome.Split.split gpart_a26MH
                      p_a26Ll = double g_a26Lk
                      (g_a26Lk, gpart_a26MH) = Genome.Split.split gpart_a26MG
                      p_a26Lj = double g_a26Li
                      (g_a26Li, gpart_a26MG) = Genome.Split.split genome_a26ME
                    in  \ x_a26Nm
                          -> let
                               c_PTB_a26Np
                                 = ((Data.Fixed.Vector.toVector x_a26Nm) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26Nn
                                 = ((Data.Fixed.Vector.toVector x_a26Nm) Data.Vector.Unboxed.! 2)
                               c_NPTB_a26Nv
                                 = ((Data.Fixed.Vector.toVector x_a26Nm) Data.Vector.Unboxed.! 1)
                               c_RESTc_a26Nq
                                 = ((Data.Fixed.Vector.toVector x_a26Nm) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a26NI
                                 = ((Data.Fixed.Vector.toVector x_a26Nm) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Lr
                                     / (1
                                        + (((p_a26Lj / p_a26Lt) ** p_a26Lv)
                                           + ((c_MiRs_a26Nn / p_a26Lx) ** p_a26Lz))))
                                    + (negate (p_a26Mv * c_PTB_a26Np))),
                                   ((p_a26LB
                                     * ((p_a26LP + ((c_RESTc_a26Nq / p_a26LD) ** p_a26LF))
                                        / (((1 + p_a26LP) + ((c_RESTc_a26Nq / p_a26LD) ** p_a26LF))
                                           + (((c_MiRs_a26Nn / p_a26LH) ** p_a26LJ)
                                              + ((c_PTB_a26Np / p_a26LL) ** p_a26LN)))))
                                    + (negate (p_a26Mx * c_NPTB_a26Nv))),
                                   ((p_a26LR
                                     * (p_a26M1
                                        / ((1 + p_a26M1) + ((c_RESTc_a26Nq / p_a26LX) ** p_a26LZ))))
                                    + (negate (p_a26Mz * c_MiRs_a26Nn))),
                                   ((p_a26M3
                                     * ((p_a26Mh + ((c_PTB_a26Np / p_a26M5) ** p_a26M7))
                                        / (((1 + p_a26Mh) + ((c_PTB_a26Np / p_a26M5) ** p_a26M7))
                                           + ((c_MiRs_a26Nn / p_a26Md) ** p_a26Mf))))
                                    + (negate (p_a26MB * c_RESTc_a26Nq))),
                                   ((p_a26Mj
                                     * ((p_a26Mt + ((c_MiRs_a26Nn / p_a26Ml) ** p_a26Mn))
                                        / (((1 + p_a26Mt) + ((c_MiRs_a26Nn / p_a26Ml) ** p_a26Mn))
                                           + ((c_RESTc_a26Nq / p_a26Mp) ** p_a26Mr))))
                                    + (negate (p_a26MD * c_EndoNeuroTFs_a26NI)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512455",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512457",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512481",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512483",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512497",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512499",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26ME
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Oo
                            p_a26MD = double g_a26MC
                            (g_a26MC, gpart_a26Oo) = Genome.Split.split gpart_a26On
                            p_a26MB = double g_a26MA
                            (g_a26MA, gpart_a26On) = Genome.Split.split gpart_a26Om
                            p_a26Mz = double g_a26My
                            (g_a26My, gpart_a26Om) = Genome.Split.split gpart_a26Ol
                            p_a26Mx = double g_a26Mw
                            (g_a26Mw, gpart_a26Ol) = Genome.Split.split gpart_a26Ok
                            p_a26Mv = double g_a26Mu
                            (g_a26Mu, gpart_a26Ok) = Genome.Split.split gpart_a26Oj
                            p_a26Mt = double g_a26Ms
                            (g_a26Ms, gpart_a26Oj) = Genome.Split.split gpart_a26Oi
                            p_a26Mr = Functions.belowten' g_a26Mq
                            (g_a26Mq, gpart_a26Oi) = Genome.Split.split gpart_a26Oh
                            p_a26Mp = double g_a26Mo
                            (g_a26Mo, gpart_a26Oh) = Genome.Split.split gpart_a26Og
                            p_a26Mn = Functions.belowten' g_a26Mm
                            (g_a26Mm, gpart_a26Og) = Genome.Split.split gpart_a26Of
                            p_a26Ml = double g_a26Mk
                            (g_a26Mk, gpart_a26Of) = Genome.Split.split gpart_a26Oe
                            p_a26Mj = double g_a26Mi
                            (g_a26Mi, gpart_a26Oe) = Genome.Split.split gpart_a26Od
                            p_a26Mh = double g_a26Mg
                            (g_a26Mg, gpart_a26Od) = Genome.Split.split gpart_a26Oc
                            p_a26Mf = Functions.belowten' g_a26Me
                            (g_a26Me, gpart_a26Oc) = Genome.Split.split gpart_a26Ob
                            p_a26Md = double g_a26Mc
                            (g_a26Mc, gpart_a26Ob) = Genome.Split.split gpart_a26Oa
                            p_a26Mb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ma
                            (g_a26Ma, gpart_a26Oa) = Genome.Split.split gpart_a26O9
                            p_a26M9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26M8
                            (g_a26M8, gpart_a26O9) = Genome.Split.split gpart_a26O8
                            p_a26M7 = Functions.belowten' g_a26M6
                            (g_a26M6, gpart_a26O8) = Genome.Split.split gpart_a26O7
                            p_a26M5 = double g_a26M4
                            (g_a26M4, gpart_a26O7) = Genome.Split.split gpart_a26O6
                            p_a26M3 = double g_a26M2
                            (g_a26M2, gpart_a26O6) = Genome.Split.split gpart_a26O5
                            p_a26M1 = double g_a26M0
                            (g_a26M0, gpart_a26O5) = Genome.Split.split gpart_a26O4
                            p_a26LZ = Functions.belowten' g_a26LY
                            (g_a26LY, gpart_a26O4) = Genome.Split.split gpart_a26O3
                            p_a26LX = double g_a26LW
                            (g_a26LW, gpart_a26O3) = Genome.Split.split gpart_a26O2
                            p_a26LV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26LU
                            (g_a26LU, gpart_a26O2) = Genome.Split.split gpart_a26O1
                            p_a26LT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26LS
                            (g_a26LS, gpart_a26O1) = Genome.Split.split gpart_a26O0
                            p_a26LR = double g_a26LQ
                            (g_a26LQ, gpart_a26O0) = Genome.Split.split gpart_a26NZ
                            p_a26LP = double g_a26LO
                            (g_a26LO, gpart_a26NZ) = Genome.Split.split gpart_a26NY
                            p_a26LN = Functions.belowten' g_a26LM
                            (g_a26LM, gpart_a26NY) = Genome.Split.split gpart_a26NX
                            p_a26LL = double g_a26LK
                            (g_a26LK, gpart_a26NX) = Genome.Split.split gpart_a26NW
                            p_a26LJ = Functions.belowten' g_a26LI
                            (g_a26LI, gpart_a26NW) = Genome.Split.split gpart_a26NV
                            p_a26LH = double g_a26LG
                            (g_a26LG, gpart_a26NV) = Genome.Split.split gpart_a26NU
                            p_a26LF = Functions.belowten' g_a26LE
                            (g_a26LE, gpart_a26NU) = Genome.Split.split gpart_a26NT
                            p_a26LD = double g_a26LC
                            (g_a26LC, gpart_a26NT) = Genome.Split.split gpart_a26NS
                            p_a26LB = double g_a26LA
                            (g_a26LA, gpart_a26NS) = Genome.Split.split gpart_a26NR
                            p_a26Lz = Functions.belowten' g_a26Ly
                            (g_a26Ly, gpart_a26NR) = Genome.Split.split gpart_a26NQ
                            p_a26Lx = double g_a26Lw
                            (g_a26Lw, gpart_a26NQ) = Genome.Split.split gpart_a26NP
                            p_a26Lv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Lu
                            (g_a26Lu, gpart_a26NP) = Genome.Split.split gpart_a26NO
                            p_a26Lt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ls
                            (g_a26Ls, gpart_a26NO) = Genome.Split.split gpart_a26NN
                            p_a26Lr = double g_a26Lq
                            (g_a26Lq, gpart_a26NN) = Genome.Split.split gpart_a26NM
                            p_a26Lp = double g_a26Lo
                            (g_a26Lo, gpart_a26NM) = Genome.Split.split gpart_a26NL
                            p_a26Ln = double g_a26Lm
                            (g_a26Lm, gpart_a26NL) = Genome.Split.split gpart_a26NK
                            p_a26Ll = double g_a26Lk
                            (g_a26Lk, gpart_a26NK) = Genome.Split.split gpart_a26NJ
                            p_a26Lj = double g_a26Li
                            (g_a26Li, gpart_a26NJ) = Genome.Split.split genome_a26ME
                          in
                            \ desc_a26MF
                              -> case desc_a26MF of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lj)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ll)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ln)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lp)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lr)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lt)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Lz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LB)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LD)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LF)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LH)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LJ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LL)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LN)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LP)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LR)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LT)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LV)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LX)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26LZ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26M1)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26M3)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26M5)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26M7)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26M9)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mb)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Md)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mf)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mh)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mj)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ml)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mn)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mp)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mr)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mt)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mv)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mx)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Mz)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MB)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26MD)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUX
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asUX) = Genome.Split.split gpart_asUW
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                      (g_asU6, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asU3 = Functions.belowten' g_asU2
                      (g_asU2, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                      (g_asU0, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asTZ = Functions.belowten' g_asTY
                      (g_asTY, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asTR = Functions.belowten' g_asTQ
                      (g_asTQ, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                      (g_asTO, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asTN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTM
                      (g_asTM, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                      (g_asTK, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTJ = Functions.belowten' g_asTI
                      (g_asTI, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                      (g_asTG, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                      (g_asTE, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                      (g_asTC, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTB = Functions.belowten' g_asTA
                      (g_asTA, gpart_asUD) = Genome.Split.split gpart_asUC
                      p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                      (g_asTy, gpart_asUC) = Genome.Split.split gpart_asUB
                      p_asTx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTw
                      (g_asTw, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTu
                      (g_asTu, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                      (g_asTs, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                      (g_asTq, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTp = Functions.belowten' g_asTo
                      (g_asTo, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                      (g_asTm, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTl = Functions.belowten' g_asTk
                      (g_asTk, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                      (g_asTi, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTh = Functions.belowten' g_asTg
                      (g_asTg, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                      (g_asTe, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                      (g_asTc, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTb = Functions.belowten' g_asTa
                      (g_asTa, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                      (g_asT8, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asT7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT6
                      (g_asT6, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asT5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                      (g_asT4, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                      (g_asT2, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                      (g_asT0, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                      (g_asSY, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                      (g_asSW, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                      (g_asSU, gpart_asUi) = Genome.Split.split genome_asUg
                    in
                      [Reaction
                         (\ x_asUY
                            -> let c_MiRs_asUZ = ((toVector x_asUY) Data.Vector.Unboxed.! 2)
                               in (p_asT3 / (1 + ((c_MiRs_asUZ / p_asT9) ** p_asTb))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asV0
                            -> let
                                 c_PTB_asV4 = ((toVector x_asV0) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asV3 = ((toVector x_asV0) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asV1 = ((toVector x_asV0) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asTd
                                  * ((p_asTr + ((c_RESTc_asV1 / p_asTf) ** p_asTh))
                                     / (((1 + p_asTr) + ((c_RESTc_asV1 / p_asTf) ** p_asTh))
                                        + (((c_MiRs_asV3 / p_asTj) ** p_asTl)
                                           + ((c_PTB_asV4 / p_asTn) ** p_asTp))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asV5
                            -> let c_RESTc_asV6 = ((toVector x_asV5) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asTt
                                  * ((p_asTD + ((p_asSZ / p_asTv) ** p_asTx))
                                     / (((1 + p_asTD) + ((p_asSZ / p_asTv) ** p_asTx))
                                        + ((c_RESTc_asV6 / p_asTz) ** p_asTB)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asV7
                            -> let
                                 c_MiRs_asVa = ((toVector x_asV7) Data.Vector.Unboxed.! 2)
                                 c_PTB_asV8 = ((toVector x_asV7) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTF
                                  * ((p_asTT + ((c_PTB_asV8 / p_asTH) ** p_asTJ))
                                     / (((1 + p_asTT) + ((c_PTB_asV8 / p_asTH) ** p_asTJ))
                                        + (((p_asSV / p_asTL) ** p_asTN)
                                           + ((c_MiRs_asVa / p_asTP) ** p_asTR))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVb
                            -> let
                                 c_RESTc_asVe = ((toVector x_asVb) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asVc = ((toVector x_asVb) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asTV
                                  * ((p_asU5 + ((c_MiRs_asVc / p_asTX) ** p_asTZ))
                                     / (((1 + p_asU5) + ((c_MiRs_asVc / p_asTX) ** p_asTZ))
                                        + ((c_RESTc_asVe / p_asU1) ** p_asU3)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVf
                            -> let c_PTB_asVg = ((toVector x_asVf) Data.Vector.Unboxed.! 0)
                               in (p_asU7 * c_PTB_asVg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVh
                            -> let c_NPTB_asVi = ((toVector x_asVh) Data.Vector.Unboxed.! 1)
                               in (p_asU9 * c_NPTB_asVi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVj
                            -> let c_MiRs_asVk = ((toVector x_asVj) Data.Vector.Unboxed.! 2)
                               in (p_asUb * c_MiRs_asVk))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVl
                            -> let c_RESTc_asVm = ((toVector x_asVl) Data.Vector.Unboxed.! 3)
                               in (p_asUd * c_RESTc_asVm))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVn
                            -> let
                                 c_EndoNeuroTFs_asVo = ((toVector x_asVn) Data.Vector.Unboxed.! 4)
                               in (p_asUf * c_EndoNeuroTFs_asVo))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120839",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120841",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asW9
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asW8) = Genome.Split.split gpart_asW7
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asW7) = Genome.Split.split gpart_asW6
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                            (g_asU6, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asU3 = Functions.belowten' g_asU2
                            (g_asU2, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                            (g_asU0, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asTZ = Functions.belowten' g_asTY
                            (g_asTY, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTR = Functions.belowten' g_asTQ
                            (g_asTQ, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTP = code-0.1.0.0:Genome.FixedList.Functions.double g_asTO
                            (g_asTO, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTM
                            (g_asTM, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                            (g_asTK, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTJ = Functions.belowten' g_asTI
                            (g_asTI, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asTH = code-0.1.0.0:Genome.FixedList.Functions.double g_asTG
                            (g_asTG, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                            (g_asTE, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                            (g_asTC, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asTB = Functions.belowten' g_asTA
                            (g_asTA, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                            (g_asTy, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTw
                            (g_asTw, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTu
                            (g_asTu, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                            (g_asTs, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                            (g_asTq, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTp = Functions.belowten' g_asTo
                            (g_asTo, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                            (g_asTm, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTl = Functions.belowten' g_asTk
                            (g_asTk, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTj = code-0.1.0.0:Genome.FixedList.Functions.double g_asTi
                            (g_asTi, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTh = Functions.belowten' g_asTg
                            (g_asTg, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTf = code-0.1.0.0:Genome.FixedList.Functions.double g_asTe
                            (g_asTe, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTd = code-0.1.0.0:Genome.FixedList.Functions.double g_asTc
                            (g_asTc, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTb = Functions.belowten' g_asTa
                            (g_asTa, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asT9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT8
                            (g_asT8, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asT7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT6
                            (g_asT6, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asT5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT4
                            (g_asT4, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asT3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT2
                            (g_asT2, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asT1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT0
                            (g_asT0, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asSZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSY
                            (g_asSY, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asSX = code-0.1.0.0:Genome.FixedList.Functions.double g_asSW
                            (g_asSW, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asSV = code-0.1.0.0:Genome.FixedList.Functions.double g_asSU
                            (g_asSU, gpart_asVu) = Genome.Split.split genome_asUg
                          in
                            \ desc_asUh
                              -> case desc_asUh of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT3)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT5)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT7)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT9)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTb)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTd)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTf)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTh)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTj)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTl)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTt)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYc
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYT
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asXZ = Functions.belowten' g_asXY
                      (g_asXY, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asXV = Functions.belowten' g_asXU
                      (g_asXU, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                      (g_asXQ, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXN = Functions.belowten' g_asXM
                      (g_asXM, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXI
                      (g_asXI, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXG
                      (g_asXG, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXF = Functions.belowten' g_asXE
                      (g_asXE, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYA) = Genome.Split.split gpart_asYz
                      p_asXx = Functions.belowten' g_asXw
                      (g_asXw, gpart_asYz) = Genome.Split.split gpart_asYy
                      p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                      (g_asXu, gpart_asYy) = Genome.Split.split gpart_asYx
                      p_asXt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                      (g_asXs, gpart_asYx) = Genome.Split.split gpart_asYw
                      p_asXr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                      (g_asXq, gpart_asYw) = Genome.Split.split gpart_asYv
                      p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                      (g_asXo, gpart_asYv) = Genome.Split.split gpart_asYu
                      p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                      (g_asXm, gpart_asYu) = Genome.Split.split gpart_asYt
                      p_asXl = Functions.belowten' g_asXk
                      (g_asXk, gpart_asYt) = Genome.Split.split gpart_asYs
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXh = Functions.belowten' g_asXg
                      (g_asXg, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                      (g_asXe, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXd = Functions.belowten' g_asXc
                      (g_asXc, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXb = code-0.1.0.0:Genome.FixedList.Functions.double g_asXa
                      (g_asXa, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                      (g_asX8, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asX7 = Functions.belowten' g_asX6
                      (g_asX6, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                      (g_asX4, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asX3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX2
                      (g_asX2, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asX1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX0
                      (g_asX0, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                      (g_asWY, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asWX = code-0.1.0.0:Genome.FixedList.Functions.double g_asWW
                      (g_asWW, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                      (g_asWU, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                      (g_asWS, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                      (g_asWQ, gpart_asYe) = Genome.Split.split genome_asYc
                    in
                      [Reaction
                         (\ x_asYU
                            -> let c_MiRs_asYV = ((toVector x_asYU) Data.Vector.Unboxed.! 2)
                               in (p_asWZ / (1 + ((c_MiRs_asYV / p_asX5) ** p_asX7))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYW
                            -> let
                                 c_PTB_asZ0 = ((toVector x_asYW) Data.Vector.Unboxed.! 0)
                                 c_MiRs_asYZ = ((toVector x_asYW) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asYX = ((toVector x_asYW) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asX9
                                  * ((p_asXn + ((c_RESTc_asYX / p_asXb) ** p_asXd))
                                     / (((1 + p_asXn) + ((c_RESTc_asYX / p_asXb) ** p_asXd))
                                        + (((c_MiRs_asYZ / p_asXf) ** p_asXh)
                                           + ((c_PTB_asZ0 / p_asXj) ** p_asXl))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZ1
                            -> let c_RESTc_asZ2 = ((toVector x_asZ1) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asXp
                                  * (p_asXz
                                     / ((1 + p_asXz) + ((c_RESTc_asZ2 / p_asXv) ** p_asXx)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZ3
                            -> let
                                 c_MiRs_asZ6 = ((toVector x_asZ3) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZ4 = ((toVector x_asZ3) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXB
                                  * ((p_asXP + ((c_PTB_asZ4 / p_asXD) ** p_asXF))
                                     / (((1 + p_asXP) + ((c_PTB_asZ4 / p_asXD) ** p_asXF))
                                        + (((p_asWR / p_asXH) ** p_asXJ)
                                           + ((c_MiRs_asZ6 / p_asXL) ** p_asXN))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZ7
                            -> let
                                 c_RESTc_asZa = ((toVector x_asZ7) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZ8 = ((toVector x_asZ7) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asXR
                                  * ((p_asY1 + ((c_MiRs_asZ8 / p_asXT) ** p_asXV))
                                     / (((1 + p_asY1) + ((c_MiRs_asZ8 / p_asXT) ** p_asXV))
                                        + ((c_RESTc_asZa / p_asXX) ** p_asXZ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZb
                            -> let c_PTB_asZc = ((toVector x_asZb) Data.Vector.Unboxed.! 0)
                               in (p_asY3 * c_PTB_asZc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZd
                            -> let c_NPTB_asZe = ((toVector x_asZd) Data.Vector.Unboxed.! 1)
                               in (p_asY5 * c_NPTB_asZe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZf
                            -> let c_MiRs_asZg = ((toVector x_asZf) Data.Vector.Unboxed.! 2)
                               in (p_asY7 * c_MiRs_asZg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZh
                            -> let c_RESTc_asZi = ((toVector x_asZh) Data.Vector.Unboxed.! 3)
                               in (p_asY9 * c_RESTc_asZi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZj
                            -> let
                                 c_EndoNeuroTFs_asZk = ((toVector x_asZj) Data.Vector.Unboxed.! 4)
                               in (p_asYb * c_EndoNeuroTFs_asZk))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121093",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYc
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at00
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXZ = Functions.belowten' g_asXY
                            (g_asXY, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXV = Functions.belowten' g_asXU
                            (g_asXU, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                            (g_asXQ, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXN = Functions.belowten' g_asXM
                            (g_asXM, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXI
                            (g_asXI, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXG
                            (g_asXG, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXF = Functions.belowten' g_asXE
                            (g_asXE, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXx = Functions.belowten' g_asXw
                            (g_asXw, gpart_asZG) = Genome.Split.split gpart_asZF
                            p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                            (g_asXu, gpart_asZF) = Genome.Split.split gpart_asZE
                            p_asXt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                            (g_asXs, gpart_asZE) = Genome.Split.split gpart_asZD
                            p_asXr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                            (g_asXq, gpart_asZD) = Genome.Split.split gpart_asZC
                            p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                            (g_asXo, gpart_asZC) = Genome.Split.split gpart_asZB
                            p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                            (g_asXm, gpart_asZB) = Genome.Split.split gpart_asZA
                            p_asXl = Functions.belowten' g_asXk
                            (g_asXk, gpart_asZA) = Genome.Split.split gpart_asZz
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZz) = Genome.Split.split gpart_asZy
                            p_asXh = Functions.belowten' g_asXg
                            (g_asXg, gpart_asZy) = Genome.Split.split gpart_asZx
                            p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                            (g_asXe, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXd = Functions.belowten' g_asXc
                            (g_asXc, gpart_asZw) = Genome.Split.split gpart_asZv
                            p_asXb = code-0.1.0.0:Genome.FixedList.Functions.double g_asXa
                            (g_asXa, gpart_asZv) = Genome.Split.split gpart_asZu
                            p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                            (g_asX8, gpart_asZu) = Genome.Split.split gpart_asZt
                            p_asX7 = Functions.belowten' g_asX6
                            (g_asX6, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                            (g_asX4, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asX3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX2
                            (g_asX2, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asX1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX0
                            (g_asX0, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                            (g_asWY, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asWX = code-0.1.0.0:Genome.FixedList.Functions.double g_asWW
                            (g_asWW, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                            (g_asWU, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                            (g_asWS, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                            (g_asWQ, gpart_asZl) = Genome.Split.split genome_asYc
                          in
                            \ desc_asYd
                              -> case desc_asYd of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWR)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWT)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWV)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWX)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWZ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX9)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXb)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at23
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2K
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1Q = Functions.belowten' g_at1P
                      (g_at1P, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1M = Functions.belowten' g_at1L
                      (g_at1L, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1E = Functions.belowten' g_at1D
                      (g_at1D, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                      (g_at1z, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1x
                      (g_at1x, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1w = Functions.belowten' g_at1v
                      (g_at1v, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                      (g_at1t, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                      (g_at1p, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1o = Functions.belowten' g_at1n
                      (g_at1n, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                      (g_at1l, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1j
                      (g_at1j, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                      (g_at1h, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1c = Functions.belowten' g_at1b
                      (g_at1b, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                      (g_at19, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at18 = Functions.belowten' g_at17
                      (g_at17, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                      (g_at15, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at14 = Functions.belowten' g_at13
                      (g_at13, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                      (g_at11, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                      (g_at0Z, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at0Y = Functions.belowten' g_at0X
                      (g_at0X, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                      (g_at0V, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at0U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0T
                      (g_at0T, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at0S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0R
                      (g_at0R, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                      (g_at0P, gpart_at29) = Genome.Split.split gpart_at28
                      p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                      (g_at0N, gpart_at28) = Genome.Split.split gpart_at27
                      p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                      (g_at0L, gpart_at27) = Genome.Split.split gpart_at26
                      p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                      (g_at0J, gpart_at26) = Genome.Split.split gpart_at25
                      p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                      (g_at0H, gpart_at25) = Genome.Split.split genome_at23
                    in
                      [Reaction
                         (\ x_at2L
                            -> let c_MiRs_at2M = ((toVector x_at2L) Data.Vector.Unboxed.! 2)
                               in (p_at0Q / (1 + ((c_MiRs_at2M / p_at0W) ** p_at0Y))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2N
                            -> let
                                 c_PTB_at2R = ((toVector x_at2N) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at2Q = ((toVector x_at2N) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at2O = ((toVector x_at2N) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at10
                                  * ((p_at1e + ((c_RESTc_at2O / p_at12) ** p_at14))
                                     / (((1 + p_at1e) + ((c_RESTc_at2O / p_at12) ** p_at14))
                                        + (((c_MiRs_at2Q / p_at16) ** p_at18)
                                           + ((c_PTB_at2R / p_at1a) ** p_at1c))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2S
                            -> let c_RESTc_at2T = ((toVector x_at2S) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1g
                                  * (p_at1q
                                     / ((1 + p_at1q) + ((c_RESTc_at2T / p_at1m) ** p_at1o)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2U
                            -> let
                                 c_MiRs_at2X = ((toVector x_at2U) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2V = ((toVector x_at2U) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1s
                                  * ((p_at1G + ((c_PTB_at2V / p_at1u) ** p_at1w))
                                     / (((1 + p_at1G) + ((c_PTB_at2V / p_at1u) ** p_at1w))
                                        + ((c_MiRs_at2X / p_at1C) ** p_at1E)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2Y
                            -> let
                                 c_RESTc_at31 = ((toVector x_at2Y) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at2Z = ((toVector x_at2Y) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at1I
                                  * ((p_at1S + ((c_MiRs_at2Z / p_at1K) ** p_at1M))
                                     / (((1 + p_at1S) + ((c_MiRs_at2Z / p_at1K) ** p_at1M))
                                        + ((c_RESTc_at31 / p_at1O) ** p_at1Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at32
                            -> let c_PTB_at33 = ((toVector x_at32) Data.Vector.Unboxed.! 0)
                               in (p_at1U * c_PTB_at33))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at34
                            -> let c_NPTB_at35 = ((toVector x_at34) Data.Vector.Unboxed.! 1)
                               in (p_at1W * c_NPTB_at35))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at36
                            -> let c_MiRs_at37 = ((toVector x_at36) Data.Vector.Unboxed.! 2)
                               in (p_at1Y * c_MiRs_at37))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at38
                            -> let c_RESTc_at39 = ((toVector x_at38) Data.Vector.Unboxed.! 3)
                               in (p_at20 * c_RESTc_at39))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3a
                            -> let
                                 c_EndoNeuroTFs_at3b = ((toVector x_at3a) Data.Vector.Unboxed.! 4)
                               in (p_at22 * c_EndoNeuroTFs_at3b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121317",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121318",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at23
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3R
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at3Q) = Genome.Split.split gpart_at3P
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at3O) = Genome.Split.split gpart_at3N
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at3N) = Genome.Split.split gpart_at3M
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at1Q = Functions.belowten' g_at1P
                            (g_at1P, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1M = Functions.belowten' g_at1L
                            (g_at1L, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1E = Functions.belowten' g_at1D
                            (g_at1D, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                            (g_at1z, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1x
                            (g_at1x, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1w = Functions.belowten' g_at1v
                            (g_at1v, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                            (g_at1t, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                            (g_at1p, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1o = Functions.belowten' g_at1n
                            (g_at1n, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                            (g_at1l, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1j
                            (g_at1j, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                            (g_at1h, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1c = Functions.belowten' g_at1b
                            (g_at1b, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                            (g_at19, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at18 = Functions.belowten' g_at17
                            (g_at17, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                            (g_at15, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at14 = Functions.belowten' g_at13
                            (g_at13, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                            (g_at11, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                            (g_at0Z, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at0Y = Functions.belowten' g_at0X
                            (g_at0X, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                            (g_at0V, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at0U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0T
                            (g_at0T, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at0S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0R
                            (g_at0R, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                            (g_at0P, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at0O = code-0.1.0.0:Genome.FixedList.Functions.double g_at0N
                            (g_at0N, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at0M = code-0.1.0.0:Genome.FixedList.Functions.double g_at0L
                            (g_at0L, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at0K = code-0.1.0.0:Genome.FixedList.Functions.double g_at0J
                            (g_at0J, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at0I = code-0.1.0.0:Genome.FixedList.Functions.double g_at0H
                            (g_at0H, gpart_at3c) = Genome.Split.split genome_at23
                          in
                            \ desc_at24
                              -> case desc_at24 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0I)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0K)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0M)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0O)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0W)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Y)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at10)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5U
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6B
                      p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                      (g_at5S, gpart_at6B) = Genome.Split.split gpart_at6A
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at6A) = Genome.Split.split gpart_at6z
                      p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                      (g_at5O, gpart_at6z) = Genome.Split.split gpart_at6y
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at6y) = Genome.Split.split gpart_at6x
                      p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                      (g_at5K, gpart_at6x) = Genome.Split.split gpart_at6w
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6w) = Genome.Split.split gpart_at6v
                      p_at5H = Functions.belowten' g_at5G
                      (g_at5G, gpart_at6v) = Genome.Split.split gpart_at6u
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6u) = Genome.Split.split gpart_at6t
                      p_at5D = Functions.belowten' g_at5C
                      (g_at5C, gpart_at6t) = Genome.Split.split gpart_at6s
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6s) = Genome.Split.split gpart_at6r
                      p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                      (g_at5y, gpart_at6r) = Genome.Split.split gpart_at6q
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6q) = Genome.Split.split gpart_at6p
                      p_at5v = Functions.belowten' g_at5u
                      (g_at5u, gpart_at6p) = Genome.Split.split gpart_at6o
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6o) = Genome.Split.split gpart_at6n
                      p_at5r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                      (g_at5q, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5o
                      (g_at5o, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5n = Functions.belowten' g_at5m
                      (g_at5m, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                      (g_at5k, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5f = Functions.belowten' g_at5e
                      (g_at5e, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5a
                      (g_at5a, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at59
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at58
                      (g_at58, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                      (g_at56, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                      (g_at54, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at53 = Functions.belowten' g_at52
                      (g_at52, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                      (g_at50, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at4Z = Functions.belowten' g_at4Y
                      (g_at4Y, gpart_at69) = Genome.Split.split gpart_at68
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at68) = Genome.Split.split gpart_at67
                      p_at4V = Functions.belowten' g_at4U
                      (g_at4U, gpart_at67) = Genome.Split.split gpart_at66
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at66) = Genome.Split.split gpart_at65
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at65) = Genome.Split.split gpart_at64
                      p_at4P = Functions.belowten' g_at4O
                      (g_at4O, gpart_at64) = Genome.Split.split gpart_at63
                      p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                      (g_at4M, gpart_at63) = Genome.Split.split gpart_at62
                      p_at4L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4K
                      (g_at4K, gpart_at62) = Genome.Split.split gpart_at61
                      p_at4J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                      (g_at4I, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                      (g_at4G, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                      (g_at4E, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                      (g_at4A, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5W) = Genome.Split.split genome_at5U
                    in
                      [Reaction
                         (\ x_at6C
                            -> let c_MiRs_at6D = ((toVector x_at6C) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4H
                                  / (1
                                     + (((p_at4z / p_at4J) ** p_at4L)
                                        + ((c_MiRs_at6D / p_at4N) ** p_at4P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6E
                            -> let
                                 c_PTB_at6I = ((toVector x_at6E) Data.Vector.Unboxed.! 0)
                                 c_MiRs_at6H = ((toVector x_at6E) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at6F = ((toVector x_at6E) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at4R
                                  * ((p_at55 + ((c_RESTc_at6F / p_at4T) ** p_at4V))
                                     / (((1 + p_at55) + ((c_RESTc_at6F / p_at4T) ** p_at4V))
                                        + (((c_MiRs_at6H / p_at4X) ** p_at4Z)
                                           + ((c_PTB_at6I / p_at51) ** p_at53))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6J
                            -> let c_RESTc_at6K = ((toVector x_at6J) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at57
                                  * (p_at5h
                                     / ((1 + p_at5h) + ((c_RESTc_at6K / p_at5d) ** p_at5f)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6L
                            -> let
                                 c_MiRs_at6O = ((toVector x_at6L) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6M = ((toVector x_at6L) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5j
                                  * ((p_at5x + ((c_PTB_at6M / p_at5l) ** p_at5n))
                                     / (((1 + p_at5x) + ((c_PTB_at6M / p_at5l) ** p_at5n))
                                        + ((c_MiRs_at6O / p_at5t) ** p_at5v)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6P
                            -> let
                                 c_RESTc_at6S = ((toVector x_at6P) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6Q = ((toVector x_at6P) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5z
                                  * ((p_at5J + ((c_MiRs_at6Q / p_at5B) ** p_at5D))
                                     / (((1 + p_at5J) + ((c_MiRs_at6Q / p_at5B) ** p_at5D))
                                        + ((c_RESTc_at6S / p_at5F) ** p_at5H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6T
                            -> let c_PTB_at6U = ((toVector x_at6T) Data.Vector.Unboxed.! 0)
                               in (p_at5L * c_PTB_at6U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6V
                            -> let c_NPTB_at6W = ((toVector x_at6V) Data.Vector.Unboxed.! 1)
                               in (p_at5N * c_NPTB_at6W))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6X
                            -> let c_MiRs_at6Y = ((toVector x_at6X) Data.Vector.Unboxed.! 2)
                               in (p_at5P * c_MiRs_at6Y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6Z
                            -> let c_RESTc_at70 = ((toVector x_at6Z) Data.Vector.Unboxed.! 3)
                               in (p_at5R * c_RESTc_at70))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at71
                            -> let
                                 c_EndoNeuroTFs_at72 = ((toVector x_at71) Data.Vector.Unboxed.! 4)
                               in (p_at5T * c_EndoNeuroTFs_at72))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5U
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7I
                            p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                            (g_at5S, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at7H) = Genome.Split.split gpart_at7G
                            p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                            (g_at5O, gpart_at7G) = Genome.Split.split gpart_at7F
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at7F) = Genome.Split.split gpart_at7E
                            p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                            (g_at5K, gpart_at7E) = Genome.Split.split gpart_at7D
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at7D) = Genome.Split.split gpart_at7C
                            p_at5H = Functions.belowten' g_at5G
                            (g_at5G, gpart_at7C) = Genome.Split.split gpart_at7B
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7B) = Genome.Split.split gpart_at7A
                            p_at5D = Functions.belowten' g_at5C
                            (g_at5C, gpart_at7A) = Genome.Split.split gpart_at7z
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7z) = Genome.Split.split gpart_at7y
                            p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                            (g_at5y, gpart_at7y) = Genome.Split.split gpart_at7x
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7x) = Genome.Split.split gpart_at7w
                            p_at5v = Functions.belowten' g_at5u
                            (g_at5u, gpart_at7w) = Genome.Split.split gpart_at7v
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7v) = Genome.Split.split gpart_at7u
                            p_at5r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                            (g_at5q, gpart_at7u) = Genome.Split.split gpart_at7t
                            p_at5p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5o
                            (g_at5o, gpart_at7t) = Genome.Split.split gpart_at7s
                            p_at5n = Functions.belowten' g_at5m
                            (g_at5m, gpart_at7s) = Genome.Split.split gpart_at7r
                            p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                            (g_at5k, gpart_at7r) = Genome.Split.split gpart_at7q
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at5f = Functions.belowten' g_at5e
                            (g_at5e, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5a
                            (g_at5a, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at59
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at58
                            (g_at58, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                            (g_at56, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                            (g_at54, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at53 = Functions.belowten' g_at52
                            (g_at52, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                            (g_at50, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at4Z = Functions.belowten' g_at4Y
                            (g_at4Y, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at4V = Functions.belowten' g_at4U
                            (g_at4U, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at4P = Functions.belowten' g_at4O
                            (g_at4O, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                            (g_at4M, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at4L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4K
                            (g_at4K, gpart_at79) = Genome.Split.split gpart_at78
                            p_at4J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                            (g_at4I, gpart_at78) = Genome.Split.split gpart_at77
                            p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                            (g_at4G, gpart_at77) = Genome.Split.split gpart_at76
                            p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                            (g_at4E, gpart_at76) = Genome.Split.split gpart_at75
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at75) = Genome.Split.split gpart_at74
                            p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                            (g_at4A, gpart_at74) = Genome.Split.split gpart_at73
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at73) = Genome.Split.split genome_at5U
                          in
                            \ desc_at5V
                              -> case desc_at5V of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Activation coef [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Activation hill [RESTc] --> NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Background transcription NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   _ -> Nothing }}
