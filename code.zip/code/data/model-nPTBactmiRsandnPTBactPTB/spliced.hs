src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24GM
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Hs
                      p_a24GL = double g_a24GK
                      (g_a24GK, gpart_a24Hs) = Genome.Split.split gpart_a24Hr
                      p_a24GJ = double g_a24GI
                      (g_a24GI, gpart_a24Hr) = Genome.Split.split gpart_a24Hq
                      p_a24GH = double g_a24GG
                      (g_a24GG, gpart_a24Hq) = Genome.Split.split gpart_a24Hp
                      p_a24GF = double g_a24GE
                      (g_a24GE, gpart_a24Hp) = Genome.Split.split gpart_a24Ho
                      p_a24GD = double g_a24GC
                      (g_a24GC, gpart_a24Ho) = Genome.Split.split gpart_a24Hn
                      p_a24GB = Functions.belowten' g_a24GA
                      (g_a24GA, gpart_a24Hn) = Genome.Split.split gpart_a24Hm
                      p_a24Gz = double g_a24Gy
                      (g_a24Gy, gpart_a24Hm) = Genome.Split.split gpart_a24Hl
                      p_a24Gx = double g_a24Gw
                      (g_a24Gw, gpart_a24Hl) = Genome.Split.split gpart_a24Hk
                      p_a24Gv = double g_a24Gu
                      (g_a24Gu, gpart_a24Hk) = Genome.Split.split gpart_a24Hj
                      p_a24Gt = Functions.belowten' g_a24Gs
                      (g_a24Gs, gpart_a24Hj) = Genome.Split.split gpart_a24Hi
                      p_a24Gr = double g_a24Gq
                      (g_a24Gq, gpart_a24Hi) = Genome.Split.split gpart_a24Hh
                      p_a24Gp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Go
                      (g_a24Go, gpart_a24Hh) = Genome.Split.split gpart_a24Hg
                      p_a24Gn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gm
                      (g_a24Gm, gpart_a24Hg) = Genome.Split.split gpart_a24Hf
                      p_a24Gl = Functions.belowten' g_a24Gk
                      (g_a24Gk, gpart_a24Hf) = Genome.Split.split gpart_a24He
                      p_a24Gj = double g_a24Gi
                      (g_a24Gi, gpart_a24He) = Genome.Split.split gpart_a24Hd
                      p_a24Gh = double g_a24Gg
                      (g_a24Gg, gpart_a24Hd) = Genome.Split.split gpart_a24Hc
                      p_a24Gf = double g_a24Ge
                      (g_a24Ge, gpart_a24Hc) = Genome.Split.split gpart_a24Hb
                      p_a24Gd = Functions.belowten' g_a24Gc
                      (g_a24Gc, gpart_a24Hb) = Genome.Split.split gpart_a24Ha
                      p_a24Gb = double g_a24Ga
                      (g_a24Ga, gpart_a24Ha) = Genome.Split.split gpart_a24H9
                      p_a24G9 = Functions.belowten' g_a24G8
                      (g_a24G8, gpart_a24H9) = Genome.Split.split gpart_a24H8
                      p_a24G7 = double g_a24G6
                      (g_a24G6, gpart_a24H8) = Genome.Split.split gpart_a24H7
                      p_a24G5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G4
                      (g_a24G4, gpart_a24H7) = Genome.Split.split gpart_a24H6
                      p_a24G3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G2
                      (g_a24G2, gpart_a24H6) = Genome.Split.split gpart_a24H5
                      p_a24G1 = double g_a24G0
                      (g_a24G0, gpart_a24H5) = Genome.Split.split gpart_a24H4
                      p_a24FZ = Functions.belowten' g_a24FY
                      (g_a24FY, gpart_a24H4) = Genome.Split.split gpart_a24H3
                      p_a24FX = double g_a24FW
                      (g_a24FW, gpart_a24H3) = Genome.Split.split gpart_a24H2
                      p_a24FV = Functions.belowten' g_a24FU
                      (g_a24FU, gpart_a24H2) = Genome.Split.split gpart_a24H1
                      p_a24FT = double g_a24FS
                      (g_a24FS, gpart_a24H1) = Genome.Split.split gpart_a24H0
                      p_a24FR = double g_a24FQ
                      (g_a24FQ, gpart_a24H0) = Genome.Split.split gpart_a24GZ
                      p_a24FP = double g_a24FO
                      (g_a24FO, gpart_a24GZ) = Genome.Split.split gpart_a24GY
                      p_a24FN = Functions.belowten' g_a24FM
                      (g_a24FM, gpart_a24GY) = Genome.Split.split gpart_a24GX
                      p_a24FL = double g_a24FK
                      (g_a24FK, gpart_a24GX) = Genome.Split.split gpart_a24GW
                      p_a24FJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FI
                      (g_a24FI, gpart_a24GW) = Genome.Split.split gpart_a24GV
                      p_a24FH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FG
                      (g_a24FG, gpart_a24GV) = Genome.Split.split gpart_a24GU
                      p_a24FF = Functions.belowten' g_a24FE
                      (g_a24FE, gpart_a24GU) = Genome.Split.split gpart_a24GT
                      p_a24FD = double g_a24FC
                      (g_a24FC, gpart_a24GT) = Genome.Split.split gpart_a24GS
                      p_a24FB = double g_a24FA
                      (g_a24FA, gpart_a24GS) = Genome.Split.split gpart_a24GR
                      p_a24Fz = double g_a24Fy
                      (g_a24Fy, gpart_a24GR) = Genome.Split.split gpart_a24GQ
                      p_a24Fx = double g_a24Fw
                      (g_a24Fw, gpart_a24GQ) = Genome.Split.split gpart_a24GP
                      p_a24Fv = double g_a24Fu
                      (g_a24Fu, gpart_a24GP) = Genome.Split.split gpart_a24GO
                      p_a24Ft = double g_a24Fs
                      (g_a24Fs, gpart_a24GO) = Genome.Split.split genome_a24GM
                    in  \ x_a24Ht
                          -> let
                               c_PTB_a24Hy
                                 = ((Data.Fixed.Vector.toVector x_a24Ht) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Hw
                                 = ((Data.Fixed.Vector.toVector x_a24Ht) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Hu
                                 = ((Data.Fixed.Vector.toVector x_a24Ht) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24HF
                                 = ((Data.Fixed.Vector.toVector x_a24Ht) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24HP
                                 = ((Data.Fixed.Vector.toVector x_a24Ht) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24FB
                                     * ((p_a24FP + ((c_NPTB_a24Hu / p_a24FD) ** p_a24FF))
                                        / (((1 + p_a24FP) + ((c_NPTB_a24Hu / p_a24FD) ** p_a24FF))
                                           + ((c_MiRs_a24Hw / p_a24FL) ** p_a24FN))))
                                    + (negate (p_a24GD * c_PTB_a24Hy))),
                                   ((p_a24FR
                                     / (1
                                        + (((c_MiRs_a24Hw / p_a24FT) ** p_a24FV)
                                           + ((c_PTB_a24Hy / p_a24FX) ** p_a24FZ))))
                                    + (negate (p_a24GF * c_NPTB_a24Hu))),
                                   ((p_a24G1
                                     * ((p_a24Gf
                                         + (((p_a24Fx / p_a24G3) ** p_a24G5)
                                            + ((c_NPTB_a24Hu / p_a24G7) ** p_a24G9)))
                                        / (((1 + p_a24Gf)
                                            + (((p_a24Fx / p_a24G3) ** p_a24G5)
                                               + ((c_NPTB_a24Hu / p_a24G7) ** p_a24G9)))
                                           + ((c_RESTc_a24HF / p_a24Gb) ** p_a24Gd))))
                                    + (negate (p_a24GH * c_MiRs_a24Hw))),
                                   ((p_a24Gh
                                     * ((p_a24Gv + ((c_PTB_a24Hy / p_a24Gj) ** p_a24Gl))
                                        / (((1 + p_a24Gv) + ((c_PTB_a24Hy / p_a24Gj) ** p_a24Gl))
                                           + (((p_a24Ft / p_a24Gn) ** p_a24Gp)
                                              + ((c_MiRs_a24Hw / p_a24Gr) ** p_a24Gt)))))
                                    + (negate (p_a24GJ * c_RESTc_a24HF))),
                                   ((p_a24Gx / (1 + ((c_RESTc_a24HF / p_a24Gz) ** p_a24GB)))
                                    + (negate (p_a24GL * c_EndoNeuroTFs_a24HP)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504409",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504411",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504431",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504433",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504451",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504453",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24GM
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Iu
                            p_a24GL = double g_a24GK
                            (g_a24GK, gpart_a24Iu) = Genome.Split.split gpart_a24It
                            p_a24GJ = double g_a24GI
                            (g_a24GI, gpart_a24It) = Genome.Split.split gpart_a24Is
                            p_a24GH = double g_a24GG
                            (g_a24GG, gpart_a24Is) = Genome.Split.split gpart_a24Ir
                            p_a24GF = double g_a24GE
                            (g_a24GE, gpart_a24Ir) = Genome.Split.split gpart_a24Iq
                            p_a24GD = double g_a24GC
                            (g_a24GC, gpart_a24Iq) = Genome.Split.split gpart_a24Ip
                            p_a24GB = Functions.belowten' g_a24GA
                            (g_a24GA, gpart_a24Ip) = Genome.Split.split gpart_a24Io
                            p_a24Gz = double g_a24Gy
                            (g_a24Gy, gpart_a24Io) = Genome.Split.split gpart_a24In
                            p_a24Gx = double g_a24Gw
                            (g_a24Gw, gpart_a24In) = Genome.Split.split gpart_a24Im
                            p_a24Gv = double g_a24Gu
                            (g_a24Gu, gpart_a24Im) = Genome.Split.split gpart_a24Il
                            p_a24Gt = Functions.belowten' g_a24Gs
                            (g_a24Gs, gpart_a24Il) = Genome.Split.split gpart_a24Ik
                            p_a24Gr = double g_a24Gq
                            (g_a24Gq, gpart_a24Ik) = Genome.Split.split gpart_a24Ij
                            p_a24Gp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Go
                            (g_a24Go, gpart_a24Ij) = Genome.Split.split gpart_a24Ii
                            p_a24Gn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Gm
                            (g_a24Gm, gpart_a24Ii) = Genome.Split.split gpart_a24Ih
                            p_a24Gl = Functions.belowten' g_a24Gk
                            (g_a24Gk, gpart_a24Ih) = Genome.Split.split gpart_a24Ig
                            p_a24Gj = double g_a24Gi
                            (g_a24Gi, gpart_a24Ig) = Genome.Split.split gpart_a24If
                            p_a24Gh = double g_a24Gg
                            (g_a24Gg, gpart_a24If) = Genome.Split.split gpart_a24Ie
                            p_a24Gf = double g_a24Ge
                            (g_a24Ge, gpart_a24Ie) = Genome.Split.split gpart_a24Id
                            p_a24Gd = Functions.belowten' g_a24Gc
                            (g_a24Gc, gpart_a24Id) = Genome.Split.split gpart_a24Ic
                            p_a24Gb = double g_a24Ga
                            (g_a24Ga, gpart_a24Ic) = Genome.Split.split gpart_a24Ib
                            p_a24G9 = Functions.belowten' g_a24G8
                            (g_a24G8, gpart_a24Ib) = Genome.Split.split gpart_a24Ia
                            p_a24G7 = double g_a24G6
                            (g_a24G6, gpart_a24Ia) = Genome.Split.split gpart_a24I9
                            p_a24G5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G4
                            (g_a24G4, gpart_a24I9) = Genome.Split.split gpart_a24I8
                            p_a24G3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24G2
                            (g_a24G2, gpart_a24I8) = Genome.Split.split gpart_a24I7
                            p_a24G1 = double g_a24G0
                            (g_a24G0, gpart_a24I7) = Genome.Split.split gpart_a24I6
                            p_a24FZ = Functions.belowten' g_a24FY
                            (g_a24FY, gpart_a24I6) = Genome.Split.split gpart_a24I5
                            p_a24FX = double g_a24FW
                            (g_a24FW, gpart_a24I5) = Genome.Split.split gpart_a24I4
                            p_a24FV = Functions.belowten' g_a24FU
                            (g_a24FU, gpart_a24I4) = Genome.Split.split gpart_a24I3
                            p_a24FT = double g_a24FS
                            (g_a24FS, gpart_a24I3) = Genome.Split.split gpart_a24I2
                            p_a24FR = double g_a24FQ
                            (g_a24FQ, gpart_a24I2) = Genome.Split.split gpart_a24I1
                            p_a24FP = double g_a24FO
                            (g_a24FO, gpart_a24I1) = Genome.Split.split gpart_a24I0
                            p_a24FN = Functions.belowten' g_a24FM
                            (g_a24FM, gpart_a24I0) = Genome.Split.split gpart_a24HZ
                            p_a24FL = double g_a24FK
                            (g_a24FK, gpart_a24HZ) = Genome.Split.split gpart_a24HY
                            p_a24FJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FI
                            (g_a24FI, gpart_a24HY) = Genome.Split.split gpart_a24HX
                            p_a24FH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24FG
                            (g_a24FG, gpart_a24HX) = Genome.Split.split gpart_a24HW
                            p_a24FF = Functions.belowten' g_a24FE
                            (g_a24FE, gpart_a24HW) = Genome.Split.split gpart_a24HV
                            p_a24FD = double g_a24FC
                            (g_a24FC, gpart_a24HV) = Genome.Split.split gpart_a24HU
                            p_a24FB = double g_a24FA
                            (g_a24FA, gpart_a24HU) = Genome.Split.split gpart_a24HT
                            p_a24Fz = double g_a24Fy
                            (g_a24Fy, gpart_a24HT) = Genome.Split.split gpart_a24HS
                            p_a24Fx = double g_a24Fw
                            (g_a24Fw, gpart_a24HS) = Genome.Split.split gpart_a24HR
                            p_a24Fv = double g_a24Fu
                            (g_a24Fu, gpart_a24HR) = Genome.Split.split gpart_a24HQ
                            p_a24Ft = double g_a24Fs
                            (g_a24Fs, gpart_a24HQ) = Genome.Split.split genome_a24GM
                          in
                            \ desc_a24GN
                              -> case desc_a24GN of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ft)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fv)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fx)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Fz)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FB)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FD)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FF)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FH)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FJ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FL)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FN)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FP)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FR)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FT)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FV)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FX)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24FZ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G1)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G3)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G5)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G7)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24G9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gb)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gd)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gf)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gh)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gl)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gn)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gp)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gr)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gt)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gv)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gx)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Gz)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GB)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GD)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GF)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GH)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GJ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24GL)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24KY
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24LE
                      p_a24KX = double g_a24KW
                      (g_a24KW, gpart_a24LE) = Genome.Split.split gpart_a24LD
                      p_a24KV = double g_a24KU
                      (g_a24KU, gpart_a24LD) = Genome.Split.split gpart_a24LC
                      p_a24KT = double g_a24KS
                      (g_a24KS, gpart_a24LC) = Genome.Split.split gpart_a24LB
                      p_a24KR = double g_a24KQ
                      (g_a24KQ, gpart_a24LB) = Genome.Split.split gpart_a24LA
                      p_a24KP = double g_a24KO
                      (g_a24KO, gpart_a24LA) = Genome.Split.split gpart_a24Lz
                      p_a24KN = Functions.belowten' g_a24KM
                      (g_a24KM, gpart_a24Lz) = Genome.Split.split gpart_a24Ly
                      p_a24KL = double g_a24KK
                      (g_a24KK, gpart_a24Ly) = Genome.Split.split gpart_a24Lx
                      p_a24KJ = double g_a24KI
                      (g_a24KI, gpart_a24Lx) = Genome.Split.split gpart_a24Lw
                      p_a24KH = double g_a24KG
                      (g_a24KG, gpart_a24Lw) = Genome.Split.split gpart_a24Lv
                      p_a24KF = Functions.belowten' g_a24KE
                      (g_a24KE, gpart_a24Lv) = Genome.Split.split gpart_a24Lu
                      p_a24KD = double g_a24KC
                      (g_a24KC, gpart_a24Lu) = Genome.Split.split gpart_a24Lt
                      p_a24KB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24KA
                      (g_a24KA, gpart_a24Lt) = Genome.Split.split gpart_a24Ls
                      p_a24Kz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ky
                      (g_a24Ky, gpart_a24Ls) = Genome.Split.split gpart_a24Lr
                      p_a24Kx = Functions.belowten' g_a24Kw
                      (g_a24Kw, gpart_a24Lr) = Genome.Split.split gpart_a24Lq
                      p_a24Kv = double g_a24Ku
                      (g_a24Ku, gpart_a24Lq) = Genome.Split.split gpart_a24Lp
                      p_a24Kt = double g_a24Ks
                      (g_a24Ks, gpart_a24Lp) = Genome.Split.split gpart_a24Lo
                      p_a24Kr = double g_a24Kq
                      (g_a24Kq, gpart_a24Lo) = Genome.Split.split gpart_a24Ln
                      p_a24Kp = Functions.belowten' g_a24Ko
                      (g_a24Ko, gpart_a24Ln) = Genome.Split.split gpart_a24Lm
                      p_a24Kn = double g_a24Km
                      (g_a24Km, gpart_a24Lm) = Genome.Split.split gpart_a24Ll
                      p_a24Kl = Functions.belowten' g_a24Kk
                      (g_a24Kk, gpart_a24Ll) = Genome.Split.split gpart_a24Lk
                      p_a24Kj = double g_a24Ki
                      (g_a24Ki, gpart_a24Lk) = Genome.Split.split gpart_a24Lj
                      p_a24Kh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kg
                      (g_a24Kg, gpart_a24Lj) = Genome.Split.split gpart_a24Li
                      p_a24Kf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ke
                      (g_a24Ke, gpart_a24Li) = Genome.Split.split gpart_a24Lh
                      p_a24Kd = double g_a24Kc
                      (g_a24Kc, gpart_a24Lh) = Genome.Split.split gpart_a24Lg
                      p_a24Kb = Functions.belowten' g_a24Ka
                      (g_a24Ka, gpart_a24Lg) = Genome.Split.split gpart_a24Lf
                      p_a24K9 = double g_a24K8
                      (g_a24K8, gpart_a24Lf) = Genome.Split.split gpart_a24Le
                      p_a24K7 = Functions.belowten' g_a24K6
                      (g_a24K6, gpart_a24Le) = Genome.Split.split gpart_a24Ld
                      p_a24K5 = double g_a24K4
                      (g_a24K4, gpart_a24Ld) = Genome.Split.split gpart_a24Lc
                      p_a24K3 = double g_a24K2
                      (g_a24K2, gpart_a24Lc) = Genome.Split.split gpart_a24Lb
                      p_a24K1 = double g_a24K0
                      (g_a24K0, gpart_a24Lb) = Genome.Split.split gpart_a24La
                      p_a24JZ = Functions.belowten' g_a24JY
                      (g_a24JY, gpart_a24La) = Genome.Split.split gpart_a24L9
                      p_a24JX = double g_a24JW
                      (g_a24JW, gpart_a24L9) = Genome.Split.split gpart_a24L8
                      p_a24JV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JU
                      (g_a24JU, gpart_a24L8) = Genome.Split.split gpart_a24L7
                      p_a24JT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JS
                      (g_a24JS, gpart_a24L7) = Genome.Split.split gpart_a24L6
                      p_a24JR = Functions.belowten' g_a24JQ
                      (g_a24JQ, gpart_a24L6) = Genome.Split.split gpart_a24L5
                      p_a24JP = double g_a24JO
                      (g_a24JO, gpart_a24L5) = Genome.Split.split gpart_a24L4
                      p_a24JN = double g_a24JM
                      (g_a24JM, gpart_a24L4) = Genome.Split.split gpart_a24L3
                      p_a24JL = double g_a24JK
                      (g_a24JK, gpart_a24L3) = Genome.Split.split gpart_a24L2
                      p_a24JJ = double g_a24JI
                      (g_a24JI, gpart_a24L2) = Genome.Split.split gpart_a24L1
                      p_a24JH = double g_a24JG
                      (g_a24JG, gpart_a24L1) = Genome.Split.split gpart_a24L0
                      p_a24JF = double g_a24JE
                      (g_a24JE, gpart_a24L0) = Genome.Split.split genome_a24KY
                    in  \ x_a24LF
                          -> let
                               c_PTB_a24LK
                                 = ((Data.Fixed.Vector.toVector x_a24LF) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24LI
                                 = ((Data.Fixed.Vector.toVector x_a24LF) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24LG
                                 = ((Data.Fixed.Vector.toVector x_a24LF) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24LR
                                 = ((Data.Fixed.Vector.toVector x_a24LF) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24M1
                                 = ((Data.Fixed.Vector.toVector x_a24LF) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24JN
                                     * ((p_a24K1 + ((c_NPTB_a24LG / p_a24JP) ** p_a24JR))
                                        / (((1 + p_a24K1) + ((c_NPTB_a24LG / p_a24JP) ** p_a24JR))
                                           + ((c_MiRs_a24LI / p_a24JX) ** p_a24JZ))))
                                    + (negate (p_a24KP * c_PTB_a24LK))),
                                   ((p_a24K3
                                     / (1
                                        + (((c_MiRs_a24LI / p_a24K5) ** p_a24K7)
                                           + ((c_PTB_a24LK / p_a24K9) ** p_a24Kb))))
                                    + (negate (p_a24KR * c_NPTB_a24LG))),
                                   ((p_a24Kd
                                     * ((p_a24Kr + ((c_NPTB_a24LG / p_a24Kj) ** p_a24Kl))
                                        / (((1 + p_a24Kr) + ((c_NPTB_a24LG / p_a24Kj) ** p_a24Kl))
                                           + ((c_RESTc_a24LR / p_a24Kn) ** p_a24Kp))))
                                    + (negate (p_a24KT * c_MiRs_a24LI))),
                                   ((p_a24Kt
                                     * ((p_a24KH + ((c_PTB_a24LK / p_a24Kv) ** p_a24Kx))
                                        / (((1 + p_a24KH) + ((c_PTB_a24LK / p_a24Kv) ** p_a24Kx))
                                           + (((p_a24JF / p_a24Kz) ** p_a24KB)
                                              + ((c_MiRs_a24LI / p_a24KD) ** p_a24KF)))))
                                    + (negate (p_a24KV * c_RESTc_a24LR))),
                                   ((p_a24KJ / (1 + ((c_RESTc_a24LR / p_a24KL) ** p_a24KN)))
                                    + (negate (p_a24KX * c_EndoNeuroTFs_a24M1)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504671",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504691",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504693",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504711",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504713",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24KY
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24MG
                            p_a24KX = double g_a24KW
                            (g_a24KW, gpart_a24MG) = Genome.Split.split gpart_a24MF
                            p_a24KV = double g_a24KU
                            (g_a24KU, gpart_a24MF) = Genome.Split.split gpart_a24ME
                            p_a24KT = double g_a24KS
                            (g_a24KS, gpart_a24ME) = Genome.Split.split gpart_a24MD
                            p_a24KR = double g_a24KQ
                            (g_a24KQ, gpart_a24MD) = Genome.Split.split gpart_a24MC
                            p_a24KP = double g_a24KO
                            (g_a24KO, gpart_a24MC) = Genome.Split.split gpart_a24MB
                            p_a24KN = Functions.belowten' g_a24KM
                            (g_a24KM, gpart_a24MB) = Genome.Split.split gpart_a24MA
                            p_a24KL = double g_a24KK
                            (g_a24KK, gpart_a24MA) = Genome.Split.split gpart_a24Mz
                            p_a24KJ = double g_a24KI
                            (g_a24KI, gpart_a24Mz) = Genome.Split.split gpart_a24My
                            p_a24KH = double g_a24KG
                            (g_a24KG, gpart_a24My) = Genome.Split.split gpart_a24Mx
                            p_a24KF = Functions.belowten' g_a24KE
                            (g_a24KE, gpart_a24Mx) = Genome.Split.split gpart_a24Mw
                            p_a24KD = double g_a24KC
                            (g_a24KC, gpart_a24Mw) = Genome.Split.split gpart_a24Mv
                            p_a24KB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24KA
                            (g_a24KA, gpart_a24Mv) = Genome.Split.split gpart_a24Mu
                            p_a24Kz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ky
                            (g_a24Ky, gpart_a24Mu) = Genome.Split.split gpart_a24Mt
                            p_a24Kx = Functions.belowten' g_a24Kw
                            (g_a24Kw, gpart_a24Mt) = Genome.Split.split gpart_a24Ms
                            p_a24Kv = double g_a24Ku
                            (g_a24Ku, gpart_a24Ms) = Genome.Split.split gpart_a24Mr
                            p_a24Kt = double g_a24Ks
                            (g_a24Ks, gpart_a24Mr) = Genome.Split.split gpart_a24Mq
                            p_a24Kr = double g_a24Kq
                            (g_a24Kq, gpart_a24Mq) = Genome.Split.split gpart_a24Mp
                            p_a24Kp = Functions.belowten' g_a24Ko
                            (g_a24Ko, gpart_a24Mp) = Genome.Split.split gpart_a24Mo
                            p_a24Kn = double g_a24Km
                            (g_a24Km, gpart_a24Mo) = Genome.Split.split gpart_a24Mn
                            p_a24Kl = Functions.belowten' g_a24Kk
                            (g_a24Kk, gpart_a24Mn) = Genome.Split.split gpart_a24Mm
                            p_a24Kj = double g_a24Ki
                            (g_a24Ki, gpart_a24Mm) = Genome.Split.split gpart_a24Ml
                            p_a24Kh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Kg
                            (g_a24Kg, gpart_a24Ml) = Genome.Split.split gpart_a24Mk
                            p_a24Kf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ke
                            (g_a24Ke, gpart_a24Mk) = Genome.Split.split gpart_a24Mj
                            p_a24Kd = double g_a24Kc
                            (g_a24Kc, gpart_a24Mj) = Genome.Split.split gpart_a24Mi
                            p_a24Kb = Functions.belowten' g_a24Ka
                            (g_a24Ka, gpart_a24Mi) = Genome.Split.split gpart_a24Mh
                            p_a24K9 = double g_a24K8
                            (g_a24K8, gpart_a24Mh) = Genome.Split.split gpart_a24Mg
                            p_a24K7 = Functions.belowten' g_a24K6
                            (g_a24K6, gpart_a24Mg) = Genome.Split.split gpart_a24Mf
                            p_a24K5 = double g_a24K4
                            (g_a24K4, gpart_a24Mf) = Genome.Split.split gpart_a24Me
                            p_a24K3 = double g_a24K2
                            (g_a24K2, gpart_a24Me) = Genome.Split.split gpart_a24Md
                            p_a24K1 = double g_a24K0
                            (g_a24K0, gpart_a24Md) = Genome.Split.split gpart_a24Mc
                            p_a24JZ = Functions.belowten' g_a24JY
                            (g_a24JY, gpart_a24Mc) = Genome.Split.split gpart_a24Mb
                            p_a24JX = double g_a24JW
                            (g_a24JW, gpart_a24Mb) = Genome.Split.split gpart_a24Ma
                            p_a24JV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JU
                            (g_a24JU, gpart_a24Ma) = Genome.Split.split gpart_a24M9
                            p_a24JT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24JS
                            (g_a24JS, gpart_a24M9) = Genome.Split.split gpart_a24M8
                            p_a24JR = Functions.belowten' g_a24JQ
                            (g_a24JQ, gpart_a24M8) = Genome.Split.split gpart_a24M7
                            p_a24JP = double g_a24JO
                            (g_a24JO, gpart_a24M7) = Genome.Split.split gpart_a24M6
                            p_a24JN = double g_a24JM
                            (g_a24JM, gpart_a24M6) = Genome.Split.split gpart_a24M5
                            p_a24JL = double g_a24JK
                            (g_a24JK, gpart_a24M5) = Genome.Split.split gpart_a24M4
                            p_a24JJ = double g_a24JI
                            (g_a24JI, gpart_a24M4) = Genome.Split.split gpart_a24M3
                            p_a24JH = double g_a24JG
                            (g_a24JG, gpart_a24M3) = Genome.Split.split gpart_a24M2
                            p_a24JF = double g_a24JE
                            (g_a24JE, gpart_a24M2) = Genome.Split.split genome_a24KY
                          in
                            \ desc_a24KZ
                              -> case desc_a24KZ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JF)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JH)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JJ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JL)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JN)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JP)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JR)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JT)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JV)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JX)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24JZ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24K9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kd)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kf)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kh)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kj)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kl)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kn)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kp)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kr)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kt)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kv)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kx)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Kz)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KB)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KD)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KF)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KH)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KN)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KP)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KR)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KT)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KV)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24KX)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24Pa
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24PQ
                      p_a24P9 = double g_a24P8
                      (g_a24P8, gpart_a24PQ) = Genome.Split.split gpart_a24PP
                      p_a24P7 = double g_a24P6
                      (g_a24P6, gpart_a24PP) = Genome.Split.split gpart_a24PO
                      p_a24P5 = double g_a24P4
                      (g_a24P4, gpart_a24PO) = Genome.Split.split gpart_a24PN
                      p_a24P3 = double g_a24P2
                      (g_a24P2, gpart_a24PN) = Genome.Split.split gpart_a24PM
                      p_a24P1 = double g_a24P0
                      (g_a24P0, gpart_a24PM) = Genome.Split.split gpart_a24PL
                      p_a24OZ = Functions.belowten' g_a24OY
                      (g_a24OY, gpart_a24PL) = Genome.Split.split gpart_a24PK
                      p_a24OX = double g_a24OW
                      (g_a24OW, gpart_a24PK) = Genome.Split.split gpart_a24PJ
                      p_a24OV = double g_a24OU
                      (g_a24OU, gpart_a24PJ) = Genome.Split.split gpart_a24PI
                      p_a24OT = double g_a24OS
                      (g_a24OS, gpart_a24PI) = Genome.Split.split gpart_a24PH
                      p_a24OR = Functions.belowten' g_a24OQ
                      (g_a24OQ, gpart_a24PH) = Genome.Split.split gpart_a24PG
                      p_a24OP = double g_a24OO
                      (g_a24OO, gpart_a24PG) = Genome.Split.split gpart_a24PF
                      p_a24ON
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OM
                      (g_a24OM, gpart_a24PF) = Genome.Split.split gpart_a24PE
                      p_a24OL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OK
                      (g_a24OK, gpart_a24PE) = Genome.Split.split gpart_a24PD
                      p_a24OJ = Functions.belowten' g_a24OI
                      (g_a24OI, gpart_a24PD) = Genome.Split.split gpart_a24PC
                      p_a24OH = double g_a24OG
                      (g_a24OG, gpart_a24PC) = Genome.Split.split gpart_a24PB
                      p_a24OF = double g_a24OE
                      (g_a24OE, gpart_a24PB) = Genome.Split.split gpart_a24PA
                      p_a24OD = double g_a24OC
                      (g_a24OC, gpart_a24PA) = Genome.Split.split gpart_a24Pz
                      p_a24OB = Functions.belowten' g_a24OA
                      (g_a24OA, gpart_a24Pz) = Genome.Split.split gpart_a24Py
                      p_a24Oz = double g_a24Oy
                      (g_a24Oy, gpart_a24Py) = Genome.Split.split gpart_a24Px
                      p_a24Ox = Functions.belowten' g_a24Ow
                      (g_a24Ow, gpart_a24Px) = Genome.Split.split gpart_a24Pw
                      p_a24Ov = double g_a24Ou
                      (g_a24Ou, gpart_a24Pw) = Genome.Split.split gpart_a24Pv
                      p_a24Ot
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Os
                      (g_a24Os, gpart_a24Pv) = Genome.Split.split gpart_a24Pu
                      p_a24Or
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oq
                      (g_a24Oq, gpart_a24Pu) = Genome.Split.split gpart_a24Pt
                      p_a24Op = double g_a24Oo
                      (g_a24Oo, gpart_a24Pt) = Genome.Split.split gpart_a24Ps
                      p_a24On = Functions.belowten' g_a24Om
                      (g_a24Om, gpart_a24Ps) = Genome.Split.split gpart_a24Pr
                      p_a24Ol = double g_a24Ok
                      (g_a24Ok, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24Oj = Functions.belowten' g_a24Oi
                      (g_a24Oi, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24Oh = double g_a24Og
                      (g_a24Og, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24Of = double g_a24Oe
                      (g_a24Oe, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24Od = double g_a24Oc
                      (g_a24Oc, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24Ob = Functions.belowten' g_a24Oa
                      (g_a24Oa, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24O9 = double g_a24O8
                      (g_a24O8, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24O7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O6
                      (g_a24O6, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24O5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O4
                      (g_a24O4, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24O3 = Functions.belowten' g_a24O2
                      (g_a24O2, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24O1 = double g_a24O0
                      (g_a24O0, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24NZ = double g_a24NY
                      (g_a24NY, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24NX = double g_a24NW
                      (g_a24NW, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24NV = double g_a24NU
                      (g_a24NU, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24NT = double g_a24NS
                      (g_a24NS, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24NR = double g_a24NQ
                      (g_a24NQ, gpart_a24Pc) = Genome.Split.split genome_a24Pa
                    in  \ x_a24PR
                          -> let
                               c_PTB_a24PW
                                 = ((Data.Fixed.Vector.toVector x_a24PR) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24PU
                                 = ((Data.Fixed.Vector.toVector x_a24PR) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24PS
                                 = ((Data.Fixed.Vector.toVector x_a24PR) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Q3
                                 = ((Data.Fixed.Vector.toVector x_a24PR) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Qd
                                 = ((Data.Fixed.Vector.toVector x_a24PR) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NZ
                                     * ((p_a24Od + ((c_NPTB_a24PS / p_a24O1) ** p_a24O3))
                                        / (((1 + p_a24Od) + ((c_NPTB_a24PS / p_a24O1) ** p_a24O3))
                                           + ((c_MiRs_a24PU / p_a24O9) ** p_a24Ob))))
                                    + (negate (p_a24P1 * c_PTB_a24PW))),
                                   ((p_a24Of
                                     / (1
                                        + (((c_MiRs_a24PU / p_a24Oh) ** p_a24Oj)
                                           + ((c_PTB_a24PW / p_a24Ol) ** p_a24On))))
                                    + (negate (p_a24P3 * c_NPTB_a24PS))),
                                   ((p_a24Op
                                     * ((p_a24OD + ((c_NPTB_a24PS / p_a24Ov) ** p_a24Ox))
                                        / (((1 + p_a24OD) + ((c_NPTB_a24PS / p_a24Ov) ** p_a24Ox))
                                           + ((c_RESTc_a24Q3 / p_a24Oz) ** p_a24OB))))
                                    + (negate (p_a24P5 * c_MiRs_a24PU))),
                                   ((p_a24OF
                                     * ((p_a24OT + ((c_PTB_a24PW / p_a24OH) ** p_a24OJ))
                                        / (((1 + p_a24OT) + ((c_PTB_a24PW / p_a24OH) ** p_a24OJ))
                                           + ((c_MiRs_a24PU / p_a24OP) ** p_a24OR))))
                                    + (negate (p_a24P7 * c_RESTc_a24Q3))),
                                   ((p_a24OV / (1 + ((c_RESTc_a24Q3 / p_a24OX) ** p_a24OZ)))
                                    + (negate (p_a24P9 * c_EndoNeuroTFs_a24Qd)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504929",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504931",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504951",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504953",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504971",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504973",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504993",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Pa
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24QS
                            p_a24P9 = double g_a24P8
                            (g_a24P8, gpart_a24QS) = Genome.Split.split gpart_a24QR
                            p_a24P7 = double g_a24P6
                            (g_a24P6, gpart_a24QR) = Genome.Split.split gpart_a24QQ
                            p_a24P5 = double g_a24P4
                            (g_a24P4, gpart_a24QQ) = Genome.Split.split gpart_a24QP
                            p_a24P3 = double g_a24P2
                            (g_a24P2, gpart_a24QP) = Genome.Split.split gpart_a24QO
                            p_a24P1 = double g_a24P0
                            (g_a24P0, gpart_a24QO) = Genome.Split.split gpart_a24QN
                            p_a24OZ = Functions.belowten' g_a24OY
                            (g_a24OY, gpart_a24QN) = Genome.Split.split gpart_a24QM
                            p_a24OX = double g_a24OW
                            (g_a24OW, gpart_a24QM) = Genome.Split.split gpart_a24QL
                            p_a24OV = double g_a24OU
                            (g_a24OU, gpart_a24QL) = Genome.Split.split gpart_a24QK
                            p_a24OT = double g_a24OS
                            (g_a24OS, gpart_a24QK) = Genome.Split.split gpart_a24QJ
                            p_a24OR = Functions.belowten' g_a24OQ
                            (g_a24OQ, gpart_a24QJ) = Genome.Split.split gpart_a24QI
                            p_a24OP = double g_a24OO
                            (g_a24OO, gpart_a24QI) = Genome.Split.split gpart_a24QH
                            p_a24ON
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OM
                            (g_a24OM, gpart_a24QH) = Genome.Split.split gpart_a24QG
                            p_a24OL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OK
                            (g_a24OK, gpart_a24QG) = Genome.Split.split gpart_a24QF
                            p_a24OJ = Functions.belowten' g_a24OI
                            (g_a24OI, gpart_a24QF) = Genome.Split.split gpart_a24QE
                            p_a24OH = double g_a24OG
                            (g_a24OG, gpart_a24QE) = Genome.Split.split gpart_a24QD
                            p_a24OF = double g_a24OE
                            (g_a24OE, gpart_a24QD) = Genome.Split.split gpart_a24QC
                            p_a24OD = double g_a24OC
                            (g_a24OC, gpart_a24QC) = Genome.Split.split gpart_a24QB
                            p_a24OB = Functions.belowten' g_a24OA
                            (g_a24OA, gpart_a24QB) = Genome.Split.split gpart_a24QA
                            p_a24Oz = double g_a24Oy
                            (g_a24Oy, gpart_a24QA) = Genome.Split.split gpart_a24Qz
                            p_a24Ox = Functions.belowten' g_a24Ow
                            (g_a24Ow, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                            p_a24Ov = double g_a24Ou
                            (g_a24Ou, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                            p_a24Ot
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Os
                            (g_a24Os, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                            p_a24Or
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oq
                            (g_a24Oq, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                            p_a24Op = double g_a24Oo
                            (g_a24Oo, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                            p_a24On = Functions.belowten' g_a24Om
                            (g_a24Om, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                            p_a24Ol = double g_a24Ok
                            (g_a24Ok, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                            p_a24Oj = Functions.belowten' g_a24Oi
                            (g_a24Oi, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24Oh = double g_a24Og
                            (g_a24Og, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24Of = double g_a24Oe
                            (g_a24Oe, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24Od = double g_a24Oc
                            (g_a24Oc, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24Ob = Functions.belowten' g_a24Oa
                            (g_a24Oa, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24O9 = double g_a24O8
                            (g_a24O8, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24O7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O6
                            (g_a24O6, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24O5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24O4
                            (g_a24O4, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24O3 = Functions.belowten' g_a24O2
                            (g_a24O2, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24O1 = double g_a24O0
                            (g_a24O0, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24NZ = double g_a24NY
                            (g_a24NY, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24NX = double g_a24NW
                            (g_a24NW, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24NV = double g_a24NU
                            (g_a24NU, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24NT = double g_a24NS
                            (g_a24NS, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24NR = double g_a24NQ
                            (g_a24NQ, gpart_a24Qe) = Genome.Split.split genome_a24Pa
                          in
                            \ desc_a24Pb
                              -> case desc_a24Pb of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NR)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NT)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NV)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NX)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NZ)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O1)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O3)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O5)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O7)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O9)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ob)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Od)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Of)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oh)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oj)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ol)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24On)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Op)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Or)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ot)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ov)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ox)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oz)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OB)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OD)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OF)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OH)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OJ)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OL)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ON)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OP)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OR)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OT)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OV)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OX)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OZ)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P1)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P3)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P5)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P7)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P9)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a24Tm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24U2
                      p_a24Tl = double g_a24Tk
                      (g_a24Tk, gpart_a24U2) = Genome.Split.split gpart_a24U1
                      p_a24Tj = double g_a24Ti
                      (g_a24Ti, gpart_a24U1) = Genome.Split.split gpart_a24U0
                      p_a24Th = double g_a24Tg
                      (g_a24Tg, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                      p_a24Tf = double g_a24Te
                      (g_a24Te, gpart_a24TZ) = Genome.Split.split gpart_a24TY
                      p_a24Td = double g_a24Tc
                      (g_a24Tc, gpart_a24TY) = Genome.Split.split gpart_a24TX
                      p_a24Tb = Functions.belowten' g_a24Ta
                      (g_a24Ta, gpart_a24TX) = Genome.Split.split gpart_a24TW
                      p_a24T9 = double g_a24T8
                      (g_a24T8, gpart_a24TW) = Genome.Split.split gpart_a24TV
                      p_a24T7 = double g_a24T6
                      (g_a24T6, gpart_a24TV) = Genome.Split.split gpart_a24TU
                      p_a24T5 = double g_a24T4
                      (g_a24T4, gpart_a24TU) = Genome.Split.split gpart_a24TT
                      p_a24T3 = Functions.belowten' g_a24T2
                      (g_a24T2, gpart_a24TT) = Genome.Split.split gpart_a24TS
                      p_a24T1 = double g_a24T0
                      (g_a24T0, gpart_a24TS) = Genome.Split.split gpart_a24TR
                      p_a24SZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SY
                      (g_a24SY, gpart_a24TR) = Genome.Split.split gpart_a24TQ
                      p_a24SX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SW
                      (g_a24SW, gpart_a24TQ) = Genome.Split.split gpart_a24TP
                      p_a24SV = Functions.belowten' g_a24SU
                      (g_a24SU, gpart_a24TP) = Genome.Split.split gpart_a24TO
                      p_a24ST = double g_a24SS
                      (g_a24SS, gpart_a24TO) = Genome.Split.split gpart_a24TN
                      p_a24SR = double g_a24SQ
                      (g_a24SQ, gpart_a24TN) = Genome.Split.split gpart_a24TM
                      p_a24SP = double g_a24SO
                      (g_a24SO, gpart_a24TM) = Genome.Split.split gpart_a24TL
                      p_a24SN = Functions.belowten' g_a24SM
                      (g_a24SM, gpart_a24TL) = Genome.Split.split gpart_a24TK
                      p_a24SL = double g_a24SK
                      (g_a24SK, gpart_a24TK) = Genome.Split.split gpart_a24TJ
                      p_a24SJ = Functions.belowten' g_a24SI
                      (g_a24SI, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                      p_a24SH = double g_a24SG
                      (g_a24SG, gpart_a24TI) = Genome.Split.split gpart_a24TH
                      p_a24SF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SE
                      (g_a24SE, gpart_a24TH) = Genome.Split.split gpart_a24TG
                      p_a24SD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SC
                      (g_a24SC, gpart_a24TG) = Genome.Split.split gpart_a24TF
                      p_a24SB = double g_a24SA
                      (g_a24SA, gpart_a24TF) = Genome.Split.split gpart_a24TE
                      p_a24Sz = Functions.belowten' g_a24Sy
                      (g_a24Sy, gpart_a24TE) = Genome.Split.split gpart_a24TD
                      p_a24Sx = double g_a24Sw
                      (g_a24Sw, gpart_a24TD) = Genome.Split.split gpart_a24TC
                      p_a24Sv = Functions.belowten' g_a24Su
                      (g_a24Su, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24St = double g_a24Ss
                      (g_a24Ss, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24Sr = double g_a24Sq
                      (g_a24Sq, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24Sp = double g_a24So
                      (g_a24So, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24Sn = Functions.belowten' g_a24Sm
                      (g_a24Sm, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24Sl = double g_a24Sk
                      (g_a24Sk, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24Sj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Si
                      (g_a24Si, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24Sh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sg
                      (g_a24Sg, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24Sf = Functions.belowten' g_a24Se
                      (g_a24Se, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24Sd = double g_a24Sc
                      (g_a24Sc, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24Sb = double g_a24Sa
                      (g_a24Sa, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24S9 = double g_a24S8
                      (g_a24S8, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24S7 = double g_a24S6
                      (g_a24S6, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24S5 = double g_a24S4
                      (g_a24S4, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24S3 = double g_a24S2
                      (g_a24S2, gpart_a24To) = Genome.Split.split genome_a24Tm
                    in  \ x_a24U3
                          -> let
                               c_PTB_a24U8
                                 = ((Data.Fixed.Vector.toVector x_a24U3) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24U6
                                 = ((Data.Fixed.Vector.toVector x_a24U3) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24U4
                                 = ((Data.Fixed.Vector.toVector x_a24U3) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Uf
                                 = ((Data.Fixed.Vector.toVector x_a24U3) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Up
                                 = ((Data.Fixed.Vector.toVector x_a24U3) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Sb
                                     * ((p_a24Sp + ((c_NPTB_a24U4 / p_a24Sd) ** p_a24Sf))
                                        / (((1 + p_a24Sp) + ((c_NPTB_a24U4 / p_a24Sd) ** p_a24Sf))
                                           + (((p_a24S3 / p_a24Sh) ** p_a24Sj)
                                              + ((c_MiRs_a24U6 / p_a24Sl) ** p_a24Sn)))))
                                    + (negate (p_a24Td * c_PTB_a24U8))),
                                   ((p_a24Sr
                                     / (1
                                        + (((c_MiRs_a24U6 / p_a24St) ** p_a24Sv)
                                           + ((c_PTB_a24U8 / p_a24Sx) ** p_a24Sz))))
                                    + (negate (p_a24Tf * c_NPTB_a24U4))),
                                   ((p_a24SB
                                     * ((p_a24SP + ((c_NPTB_a24U4 / p_a24SH) ** p_a24SJ))
                                        / (((1 + p_a24SP) + ((c_NPTB_a24U4 / p_a24SH) ** p_a24SJ))
                                           + ((c_RESTc_a24Uf / p_a24SL) ** p_a24SN))))
                                    + (negate (p_a24Th * c_MiRs_a24U6))),
                                   ((p_a24SR
                                     * ((p_a24T5 + ((c_PTB_a24U8 / p_a24ST) ** p_a24SV))
                                        / (((1 + p_a24T5) + ((c_PTB_a24U8 / p_a24ST) ** p_a24SV))
                                           + ((c_MiRs_a24U6 / p_a24T1) ** p_a24T3))))
                                    + (negate (p_a24Tj * c_RESTc_a24Uf))),
                                   ((p_a24T7 / (1 + ((c_RESTc_a24Uf / p_a24T9) ** p_a24Tb)))
                                    + (negate (p_a24Tl * c_EndoNeuroTFs_a24Up)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505189",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505191",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505211",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505213",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505231",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505233",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Tm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24V4
                            p_a24Tl = double g_a24Tk
                            (g_a24Tk, gpart_a24V4) = Genome.Split.split gpart_a24V3
                            p_a24Tj = double g_a24Ti
                            (g_a24Ti, gpart_a24V3) = Genome.Split.split gpart_a24V2
                            p_a24Th = double g_a24Tg
                            (g_a24Tg, gpart_a24V2) = Genome.Split.split gpart_a24V1
                            p_a24Tf = double g_a24Te
                            (g_a24Te, gpart_a24V1) = Genome.Split.split gpart_a24V0
                            p_a24Td = double g_a24Tc
                            (g_a24Tc, gpart_a24V0) = Genome.Split.split gpart_a24UZ
                            p_a24Tb = Functions.belowten' g_a24Ta
                            (g_a24Ta, gpart_a24UZ) = Genome.Split.split gpart_a24UY
                            p_a24T9 = double g_a24T8
                            (g_a24T8, gpart_a24UY) = Genome.Split.split gpart_a24UX
                            p_a24T7 = double g_a24T6
                            (g_a24T6, gpart_a24UX) = Genome.Split.split gpart_a24UW
                            p_a24T5 = double g_a24T4
                            (g_a24T4, gpart_a24UW) = Genome.Split.split gpart_a24UV
                            p_a24T3 = Functions.belowten' g_a24T2
                            (g_a24T2, gpart_a24UV) = Genome.Split.split gpart_a24UU
                            p_a24T1 = double g_a24T0
                            (g_a24T0, gpart_a24UU) = Genome.Split.split gpart_a24UT
                            p_a24SZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SY
                            (g_a24SY, gpart_a24UT) = Genome.Split.split gpart_a24US
                            p_a24SX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SW
                            (g_a24SW, gpart_a24US) = Genome.Split.split gpart_a24UR
                            p_a24SV = Functions.belowten' g_a24SU
                            (g_a24SU, gpart_a24UR) = Genome.Split.split gpart_a24UQ
                            p_a24ST = double g_a24SS
                            (g_a24SS, gpart_a24UQ) = Genome.Split.split gpart_a24UP
                            p_a24SR = double g_a24SQ
                            (g_a24SQ, gpart_a24UP) = Genome.Split.split gpart_a24UO
                            p_a24SP = double g_a24SO
                            (g_a24SO, gpart_a24UO) = Genome.Split.split gpart_a24UN
                            p_a24SN = Functions.belowten' g_a24SM
                            (g_a24SM, gpart_a24UN) = Genome.Split.split gpart_a24UM
                            p_a24SL = double g_a24SK
                            (g_a24SK, gpart_a24UM) = Genome.Split.split gpart_a24UL
                            p_a24SJ = Functions.belowten' g_a24SI
                            (g_a24SI, gpart_a24UL) = Genome.Split.split gpart_a24UK
                            p_a24SH = double g_a24SG
                            (g_a24SG, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                            p_a24SF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SE
                            (g_a24SE, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                            p_a24SD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SC
                            (g_a24SC, gpart_a24UI) = Genome.Split.split gpart_a24UH
                            p_a24SB = double g_a24SA
                            (g_a24SA, gpart_a24UH) = Genome.Split.split gpart_a24UG
                            p_a24Sz = Functions.belowten' g_a24Sy
                            (g_a24Sy, gpart_a24UG) = Genome.Split.split gpart_a24UF
                            p_a24Sx = double g_a24Sw
                            (g_a24Sw, gpart_a24UF) = Genome.Split.split gpart_a24UE
                            p_a24Sv = Functions.belowten' g_a24Su
                            (g_a24Su, gpart_a24UE) = Genome.Split.split gpart_a24UD
                            p_a24St = double g_a24Ss
                            (g_a24Ss, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24Sr = double g_a24Sq
                            (g_a24Sq, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24Sp = double g_a24So
                            (g_a24So, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24Sn = Functions.belowten' g_a24Sm
                            (g_a24Sm, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24Sl = double g_a24Sk
                            (g_a24Sk, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24Sj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Si
                            (g_a24Si, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24Sh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sg
                            (g_a24Sg, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24Sf = Functions.belowten' g_a24Se
                            (g_a24Se, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24Sd = double g_a24Sc
                            (g_a24Sc, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24Sb = double g_a24Sa
                            (g_a24Sa, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24S9 = double g_a24S8
                            (g_a24S8, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24S7 = double g_a24S6
                            (g_a24S6, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24S5 = double g_a24S4
                            (g_a24S4, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24S3 = double g_a24S2
                            (g_a24S2, gpart_a24Uq) = Genome.Split.split genome_a24Tm
                          in
                            \ desc_a24Tn
                              -> case desc_a24Tn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sb)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sd)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sf)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sh)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sj)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sl)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sn)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24St)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SF)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SH)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ST)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SV)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SX)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Td)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Th)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tl)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUG
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVm
                      p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                      (g_asUE, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                      (g_asUA, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asUv = Functions.belowten' g_asUu
                      (g_asUu, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                      (g_asUq, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asUn = Functions.belowten' g_asUm
                      (g_asUm, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                      (g_asUk, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asUj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUi
                      (g_asUi, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asUh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUg
                      (g_asUg, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asUf = Functions.belowten' g_asUe
                      (g_asUe, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asV8) = Genome.Split.split gpart_asV7
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asV7) = Genome.Split.split gpart_asV6
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asV6) = Genome.Split.split gpart_asV5
                      p_asU7 = Functions.belowten' g_asU6
                      (g_asU6, gpart_asV5) = Genome.Split.split gpart_asV4
                      p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                      (g_asU4, gpart_asV4) = Genome.Split.split gpart_asV3
                      p_asU3 = Functions.belowten' g_asU2
                      (g_asU2, gpart_asV3) = Genome.Split.split gpart_asV2
                      p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                      (g_asU0, gpart_asV2) = Genome.Split.split gpart_asV1
                      p_asTZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTY
                      (g_asTY, gpart_asV1) = Genome.Split.split gpart_asV0
                      p_asTX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTW
                      (g_asTW, gpart_asV0) = Genome.Split.split gpart_asUZ
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asUZ) = Genome.Split.split gpart_asUY
                      p_asTT = Functions.belowten' g_asTS
                      (g_asTS, gpart_asUY) = Genome.Split.split gpart_asUX
                      p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                      (g_asTQ, gpart_asUX) = Genome.Split.split gpart_asUW
                      p_asTP = Functions.belowten' g_asTO
                      (g_asTO, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                      (g_asTK, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                      (g_asTI, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asTH = Functions.belowten' g_asTG
                      (g_asTG, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                      (g_asTE, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asTD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTC
                      (g_asTC, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asTB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTA
                      (g_asTA, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTz = Functions.belowten' g_asTy
                      (g_asTy, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                      (g_asTw, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                      (g_asTu, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                      (g_asTs, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                      (g_asTq, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                      (g_asTo, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                      (g_asTm, gpart_asUI) = Genome.Split.split genome_asUG
                    in
                      [Reaction
                         (\ x_asVn
                            -> let
                                 c_MiRs_asVq = ((toVector x_asVn) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVo = ((toVector x_asVn) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTv
                                  * ((p_asTJ + ((c_NPTB_asVo / p_asTx) ** p_asTz))
                                     / (((1 + p_asTJ) + ((c_NPTB_asVo / p_asTx) ** p_asTz))
                                        + ((c_MiRs_asVq / p_asTF) ** p_asTH)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVr
                            -> let
                                 c_MiRs_asVs = ((toVector x_asVr) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVt = ((toVector x_asVr) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTL
                                  / (1
                                     + (((c_MiRs_asVs / p_asTN) ** p_asTP)
                                        + ((c_PTB_asVt / p_asTR) ** p_asTT)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVu
                            -> let
                                 c_RESTc_asVx = ((toVector x_asVu) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asVv = ((toVector x_asVu) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTV
                                  * ((p_asU9
                                      + (((p_asTr / p_asTX) ** p_asTZ)
                                         + ((c_NPTB_asVv / p_asU1) ** p_asU3)))
                                     / (((1 + p_asU9)
                                         + (((p_asTr / p_asTX) ** p_asTZ)
                                            + ((c_NPTB_asVv / p_asU1) ** p_asU3)))
                                        + ((c_RESTc_asVx / p_asU5) ** p_asU7)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVy
                            -> let
                                 c_MiRs_asVB = ((toVector x_asVy) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVz = ((toVector x_asVy) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUb
                                  * ((p_asUp + ((c_PTB_asVz / p_asUd) ** p_asUf))
                                     / (((1 + p_asUp) + ((c_PTB_asVz / p_asUd) ** p_asUf))
                                        + (((p_asTn / p_asUh) ** p_asUj)
                                           + ((c_MiRs_asVB / p_asUl) ** p_asUn))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVC
                            -> let c_RESTc_asVD = ((toVector x_asVC) Data.Vector.Unboxed.! 3)
                               in (p_asUr / (1 + ((c_RESTc_asVD / p_asUt) ** p_asUv))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVE
                            -> let c_PTB_asVF = ((toVector x_asVE) Data.Vector.Unboxed.! 0)
                               in (p_asUx * c_PTB_asVF))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVG
                            -> let c_NPTB_asVH = ((toVector x_asVG) Data.Vector.Unboxed.! 1)
                               in (p_asUz * c_NPTB_asVH))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVI
                            -> let c_MiRs_asVJ = ((toVector x_asVI) Data.Vector.Unboxed.! 2)
                               in (p_asUB * c_MiRs_asVJ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVK
                            -> let c_RESTc_asVL = ((toVector x_asVK) Data.Vector.Unboxed.! 3)
                               in (p_asUD * c_RESTc_asVL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVM
                            -> let
                                 c_EndoNeuroTFs_asVN = ((toVector x_asVM) Data.Vector.Unboxed.! 4)
                               in (p_asUF * c_EndoNeuroTFs_asVN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUG
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWx
                            p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                            (g_asUE, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                            (g_asUA, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asUv = Functions.belowten' g_asUu
                            (g_asUu, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                            (g_asUq, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asUn = Functions.belowten' g_asUm
                            (g_asUm, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                            (g_asUk, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asUj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUi
                            (g_asUi, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asUh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUg
                            (g_asUg, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asUf = Functions.belowten' g_asUe
                            (g_asUe, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asU7 = Functions.belowten' g_asU6
                            (g_asU6, gpart_asWg) = Genome.Split.split gpart_asWf
                            p_asU5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU4
                            (g_asU4, gpart_asWf) = Genome.Split.split gpart_asWe
                            p_asU3 = Functions.belowten' g_asU2
                            (g_asU2, gpart_asWe) = Genome.Split.split gpart_asWd
                            p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                            (g_asU0, gpart_asWd) = Genome.Split.split gpart_asWc
                            p_asTZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTY
                            (g_asTY, gpart_asWc) = Genome.Split.split gpart_asWb
                            p_asTX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTW
                            (g_asTW, gpart_asWb) = Genome.Split.split gpart_asWa
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asWa) = Genome.Split.split gpart_asW9
                            p_asTT = Functions.belowten' g_asTS
                            (g_asTS, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                            (g_asTQ, gpart_asW8) = Genome.Split.split gpart_asW7
                            p_asTP = Functions.belowten' g_asTO
                            (g_asTO, gpart_asW7) = Genome.Split.split gpart_asW6
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asTL = code-0.1.0.0:Genome.FixedList.Functions.double g_asTK
                            (g_asTK, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asTJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTI
                            (g_asTI, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asTH = Functions.belowten' g_asTG
                            (g_asTG, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                            (g_asTE, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asTD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTC
                            (g_asTC, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asTB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTA
                            (g_asTA, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asTz = Functions.belowten' g_asTy
                            (g_asTy, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                            (g_asTw, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                            (g_asTu, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTt = code-0.1.0.0:Genome.FixedList.Functions.double g_asTs
                            (g_asTs, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTr = code-0.1.0.0:Genome.FixedList.Functions.double g_asTq
                            (g_asTq, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTp = code-0.1.0.0:Genome.FixedList.Functions.double g_asTo
                            (g_asTo, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTn = code-0.1.0.0:Genome.FixedList.Functions.double g_asTm
                            (g_asTm, gpart_asVT) = Genome.Split.split genome_asUG
                          in
                            \ desc_asUH
                              -> case desc_asUH of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTn)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTp)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTr)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTt)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYy
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZe
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                      (g_asYu, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                      (g_asYs, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asYn = Functions.belowten' g_asYm
                      (g_asYm, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asYf = Functions.belowten' g_asYe
                      (g_asYe, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asYb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYa
                      (g_asYa, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asY9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY8
                      (g_asY8, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asY7 = Functions.belowten' g_asY6
                      (g_asY6, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXZ = Functions.belowten' g_asXY
                      (g_asXY, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asXV = Functions.belowten' g_asXU
                      (g_asXU, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asXR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXQ
                      (g_asXQ, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asXP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                      (g_asXO, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                      (g_asXM, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asXL = Functions.belowten' g_asXK
                      (g_asXK, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asXH = Functions.belowten' g_asXG
                      (g_asXG, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXz = Functions.belowten' g_asXy
                      (g_asXy, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                      (g_asXw, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXu
                      (g_asXu, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                      (g_asXs, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXr = Functions.belowten' g_asXq
                      (g_asXq, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                      (g_asXo, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                      (g_asXm, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                      (g_asXg, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                      (g_asXe, gpart_asYA) = Genome.Split.split genome_asYy
                    in
                      [Reaction
                         (\ x_asZf
                            -> let
                                 c_MiRs_asZi = ((toVector x_asZf) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZg = ((toVector x_asZf) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXn
                                  * ((p_asXB + ((c_NPTB_asZg / p_asXp) ** p_asXr))
                                     / (((1 + p_asXB) + ((c_NPTB_asZg / p_asXp) ** p_asXr))
                                        + ((c_MiRs_asZi / p_asXx) ** p_asXz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZj
                            -> let
                                 c_MiRs_asZk = ((toVector x_asZj) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZl = ((toVector x_asZj) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXD
                                  / (1
                                     + (((c_MiRs_asZk / p_asXF) ** p_asXH)
                                        + ((c_PTB_asZl / p_asXJ) ** p_asXL)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZm
                            -> let
                                 c_RESTc_asZp = ((toVector x_asZm) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asZn = ((toVector x_asZm) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXN
                                  * ((p_asY1 + ((c_NPTB_asZn / p_asXT) ** p_asXV))
                                     / (((1 + p_asY1) + ((c_NPTB_asZn / p_asXT) ** p_asXV))
                                        + ((c_RESTc_asZp / p_asXX) ** p_asXZ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZq
                            -> let
                                 c_MiRs_asZt = ((toVector x_asZq) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZr = ((toVector x_asZq) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY3
                                  * ((p_asYh + ((c_PTB_asZr / p_asY5) ** p_asY7))
                                     / (((1 + p_asYh) + ((c_PTB_asZr / p_asY5) ** p_asY7))
                                        + (((p_asXf / p_asY9) ** p_asYb)
                                           + ((c_MiRs_asZt / p_asYd) ** p_asYf))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZu
                            -> let c_RESTc_asZv = ((toVector x_asZu) Data.Vector.Unboxed.! 3)
                               in (p_asYj / (1 + ((c_RESTc_asZv / p_asYl) ** p_asYn))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZw
                            -> let c_PTB_asZx = ((toVector x_asZw) Data.Vector.Unboxed.! 0)
                               in (p_asYp * c_PTB_asZx))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZy
                            -> let c_NPTB_asZz = ((toVector x_asZy) Data.Vector.Unboxed.! 1)
                               in (p_asYr * c_NPTB_asZz))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZA
                            -> let c_MiRs_asZB = ((toVector x_asZA) Data.Vector.Unboxed.! 2)
                               in (p_asYt * c_MiRs_asZB))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZC
                            -> let c_RESTc_asZD = ((toVector x_asZC) Data.Vector.Unboxed.! 3)
                               in (p_asYv * c_RESTc_asZD))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZE
                            -> let
                                 c_EndoNeuroTFs_asZF = ((toVector x_asZE) Data.Vector.Unboxed.! 4)
                               in (p_asYx * c_EndoNeuroTFs_asZF))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYy
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0k
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                            (g_asYu, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                            (g_asYs, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asYn = Functions.belowten' g_asYm
                            (g_asYm, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asYf = Functions.belowten' g_asYe
                            (g_asYe, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asYb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYa
                            (g_asYa, gpart_at09) = Genome.Split.split gpart_at08
                            p_asY9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY8
                            (g_asY8, gpart_at08) = Genome.Split.split gpart_at07
                            p_asY7 = Functions.belowten' g_asY6
                            (g_asY6, gpart_at07) = Genome.Split.split gpart_at06
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_at06) = Genome.Split.split gpart_at05
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at05) = Genome.Split.split gpart_at04
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_at04) = Genome.Split.split gpart_at03
                            p_asXZ = Functions.belowten' g_asXY
                            (g_asXY, gpart_at03) = Genome.Split.split gpart_at02
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_at02) = Genome.Split.split gpart_at01
                            p_asXV = Functions.belowten' g_asXU
                            (g_asXU, gpart_at01) = Genome.Split.split gpart_at00
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asXR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXQ
                            (g_asXQ, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asXP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                            (g_asXO, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                            (g_asXM, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asXL = Functions.belowten' g_asXK
                            (g_asXK, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXH = Functions.belowten' g_asXG
                            (g_asXG, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXz = Functions.belowten' g_asXy
                            (g_asXy, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                            (g_asXw, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXu
                            (g_asXu, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                            (g_asXs, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXr = Functions.belowten' g_asXq
                            (g_asXq, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                            (g_asXo, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                            (g_asXm, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                            (g_asXg, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                            (g_asXe, gpart_asZG) = Genome.Split.split genome_asYy
                          in
                            \ desc_asYz
                              -> case desc_asYz of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2l
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at31
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at31) = Genome.Split.split gpart_at30
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at2a = Functions.belowten' g_at29
                      (g_at29, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at22 = Functions.belowten' g_at21
                      (g_at21, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at1Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                      (g_at1X, gpart_at2Q) = Genome.Split.split gpart_at2P
                      p_at1W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1V
                      (g_at1V, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at1U = Functions.belowten' g_at1T
                      (g_at1T, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at2N) = Genome.Split.split gpart_at2M
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2M) = Genome.Split.split gpart_at2L
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2L) = Genome.Split.split gpart_at2K
                      p_at1M = Functions.belowten' g_at1L
                      (g_at1L, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at1I = Functions.belowten' g_at1H
                      (g_at1H, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1D
                      (g_at1D, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1B
                      (g_at1B, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1y = Functions.belowten' g_at1x
                      (g_at1x, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                      (g_at1v, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1u = Functions.belowten' g_at1t
                      (g_at1t, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                      (g_at1p, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                      (g_at1n, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1m = Functions.belowten' g_at1l
                      (g_at1l, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                      (g_at1h, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1f
                      (g_at1f, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1e = Functions.belowten' g_at1d
                      (g_at1d, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                      (g_at19, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                      (g_at17, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                      (g_at15, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at14 = code-0.1.0.0:Genome.FixedList.Functions.double g_at13
                      (g_at13, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                      (g_at11, gpart_at2n) = Genome.Split.split genome_at2l
                    in
                      [Reaction
                         (\ x_at32
                            -> let
                                 c_MiRs_at35 = ((toVector x_at32) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at33 = ((toVector x_at32) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1a
                                  * ((p_at1o + ((c_NPTB_at33 / p_at1c) ** p_at1e))
                                     / (((1 + p_at1o) + ((c_NPTB_at33 / p_at1c) ** p_at1e))
                                        + ((c_MiRs_at35 / p_at1k) ** p_at1m)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at36
                            -> let
                                 c_MiRs_at37 = ((toVector x_at36) Data.Vector.Unboxed.! 2)
                                 c_PTB_at38 = ((toVector x_at36) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1q
                                  / (1
                                     + (((c_MiRs_at37 / p_at1s) ** p_at1u)
                                        + ((c_PTB_at38 / p_at1w) ** p_at1y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at39
                            -> let
                                 c_RESTc_at3c = ((toVector x_at39) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at3a = ((toVector x_at39) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1A
                                  * ((p_at1O + ((c_NPTB_at3a / p_at1G) ** p_at1I))
                                     / (((1 + p_at1O) + ((c_NPTB_at3a / p_at1G) ** p_at1I))
                                        + ((c_RESTc_at3c / p_at1K) ** p_at1M)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3d
                            -> let
                                 c_MiRs_at3g = ((toVector x_at3d) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3e = ((toVector x_at3d) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1Q
                                  * ((p_at24 + ((c_PTB_at3e / p_at1S) ** p_at1U))
                                     / (((1 + p_at24) + ((c_PTB_at3e / p_at1S) ** p_at1U))
                                        + ((c_MiRs_at3g / p_at20) ** p_at22)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3h
                            -> let c_RESTc_at3i = ((toVector x_at3h) Data.Vector.Unboxed.! 3)
                               in (p_at26 / (1 + ((c_RESTc_at3i / p_at28) ** p_at2a))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3j
                            -> let c_PTB_at3k = ((toVector x_at3j) Data.Vector.Unboxed.! 0)
                               in (p_at2c * c_PTB_at3k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3l
                            -> let c_NPTB_at3m = ((toVector x_at3l) Data.Vector.Unboxed.! 1)
                               in (p_at2e * c_NPTB_at3m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3n
                            -> let c_MiRs_at3o = ((toVector x_at3n) Data.Vector.Unboxed.! 2)
                               in (p_at2g * c_MiRs_at3o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3p
                            -> let c_RESTc_at3q = ((toVector x_at3p) Data.Vector.Unboxed.! 3)
                               in (p_at2i * c_RESTc_at3q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3r
                            -> let
                                 c_EndoNeuroTFs_at3s = ((toVector x_at3r) Data.Vector.Unboxed.! 4)
                               in (p_at2k * c_EndoNeuroTFs_at3s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2l
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at47
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at47) = Genome.Split.split gpart_at46
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at46) = Genome.Split.split gpart_at45
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at45) = Genome.Split.split gpart_at44
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at44) = Genome.Split.split gpart_at43
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at43) = Genome.Split.split gpart_at42
                            p_at2a = Functions.belowten' g_at29
                            (g_at29, gpart_at42) = Genome.Split.split gpart_at41
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at41) = Genome.Split.split gpart_at40
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at22 = Functions.belowten' g_at21
                            (g_at21, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at1Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                            (g_at1X, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at1W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1V
                            (g_at1V, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at1U = Functions.belowten' g_at1T
                            (g_at1T, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at3T) = Genome.Split.split gpart_at3S
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at3S) = Genome.Split.split gpart_at3R
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at1M = Functions.belowten' g_at1L
                            (g_at1L, gpart_at3Q) = Genome.Split.split gpart_at3P
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at1I = Functions.belowten' g_at1H
                            (g_at1H, gpart_at3O) = Genome.Split.split gpart_at3N
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at3N) = Genome.Split.split gpart_at3M
                            p_at1E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1D
                            (g_at1D, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at1C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1B
                            (g_at1B, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1y = Functions.belowten' g_at1x
                            (g_at1x, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                            (g_at1v, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1u = Functions.belowten' g_at1t
                            (g_at1t, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                            (g_at1p, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                            (g_at1n, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1m = Functions.belowten' g_at1l
                            (g_at1l, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                            (g_at1h, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1f
                            (g_at1f, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1e = Functions.belowten' g_at1d
                            (g_at1d, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                            (g_at19, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                            (g_at17, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                            (g_at15, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at14 = code-0.1.0.0:Genome.FixedList.Functions.double g_at13
                            (g_at13, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at12 = code-0.1.0.0:Genome.FixedList.Functions.double g_at11
                            (g_at11, gpart_at3t) = Genome.Split.split genome_at2l
                          in
                            \ desc_at2m
                              -> case desc_at2m of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at68
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6O
                      p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                      (g_at66, gpart_at6O) = Genome.Split.split gpart_at6N
                      p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                      (g_at64, gpart_at6N) = Genome.Split.split gpart_at6M
                      p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                      (g_at62, gpart_at6M) = Genome.Split.split gpart_at6L
                      p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                      (g_at60, gpart_at6L) = Genome.Split.split gpart_at6K
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at6K) = Genome.Split.split gpart_at6J
                      p_at5X = Functions.belowten' g_at5W
                      (g_at5W, gpart_at6J) = Genome.Split.split gpart_at6I
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at6I) = Genome.Split.split gpart_at6H
                      p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                      (g_at5S, gpart_at6H) = Genome.Split.split gpart_at6G
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at6G) = Genome.Split.split gpart_at6F
                      p_at5P = Functions.belowten' g_at5O
                      (g_at5O, gpart_at6F) = Genome.Split.split gpart_at6E
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at6E) = Genome.Split.split gpart_at6D
                      p_at5L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5K
                      (g_at5K, gpart_at6D) = Genome.Split.split gpart_at6C
                      p_at5J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5I
                      (g_at5I, gpart_at6C) = Genome.Split.split gpart_at6B
                      p_at5H = Functions.belowten' g_at5G
                      (g_at5G, gpart_at6B) = Genome.Split.split gpart_at6A
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6A) = Genome.Split.split gpart_at6z
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at6z) = Genome.Split.split gpart_at6y
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6y) = Genome.Split.split gpart_at6x
                      p_at5z = Functions.belowten' g_at5y
                      (g_at5y, gpart_at6x) = Genome.Split.split gpart_at6w
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6w) = Genome.Split.split gpart_at6v
                      p_at5v = Functions.belowten' g_at5u
                      (g_at5u, gpart_at6v) = Genome.Split.split gpart_at6u
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6u) = Genome.Split.split gpart_at6t
                      p_at5r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                      (g_at5q, gpart_at6t) = Genome.Split.split gpart_at6s
                      p_at5p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5o
                      (g_at5o, gpart_at6s) = Genome.Split.split gpart_at6r
                      p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                      (g_at5m, gpart_at6r) = Genome.Split.split gpart_at6q
                      p_at5l = Functions.belowten' g_at5k
                      (g_at5k, gpart_at6q) = Genome.Split.split gpart_at6p
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at6p) = Genome.Split.split gpart_at6o
                      p_at5h = Functions.belowten' g_at5g
                      (g_at5g, gpart_at6o) = Genome.Split.split gpart_at6n
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                      (g_at5a, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at59 = Functions.belowten' g_at58
                      (g_at58, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                      (g_at56, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at55
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                      (g_at54, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at53
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                      (g_at52, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at51 = Functions.belowten' g_at50
                      (g_at50, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                      (g_at4Y, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                      (g_at4U, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at6a) = Genome.Split.split genome_at68
                    in
                      [Reaction
                         (\ x_at6P
                            -> let
                                 c_MiRs_at6S = ((toVector x_at6P) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at6Q = ((toVector x_at6P) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4X
                                  * ((p_at5b + ((c_NPTB_at6Q / p_at4Z) ** p_at51))
                                     / (((1 + p_at5b) + ((c_NPTB_at6Q / p_at4Z) ** p_at51))
                                        + (((p_at4P / p_at53) ** p_at55)
                                           + ((c_MiRs_at6S / p_at57) ** p_at59))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6T
                            -> let
                                 c_MiRs_at6U = ((toVector x_at6T) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6V = ((toVector x_at6T) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5d
                                  / (1
                                     + (((c_MiRs_at6U / p_at5f) ** p_at5h)
                                        + ((c_PTB_at6V / p_at5j) ** p_at5l)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6W
                            -> let
                                 c_RESTc_at6Z = ((toVector x_at6W) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at6X = ((toVector x_at6W) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5n
                                  * ((p_at5B + ((c_NPTB_at6X / p_at5t) ** p_at5v))
                                     / (((1 + p_at5B) + ((c_NPTB_at6X / p_at5t) ** p_at5v))
                                        + ((c_RESTc_at6Z / p_at5x) ** p_at5z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at70
                            -> let
                                 c_MiRs_at73 = ((toVector x_at70) Data.Vector.Unboxed.! 2)
                                 c_PTB_at71 = ((toVector x_at70) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5D
                                  * ((p_at5R + ((c_PTB_at71 / p_at5F) ** p_at5H))
                                     / (((1 + p_at5R) + ((c_PTB_at71 / p_at5F) ** p_at5H))
                                        + ((c_MiRs_at73 / p_at5N) ** p_at5P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at74
                            -> let c_RESTc_at75 = ((toVector x_at74) Data.Vector.Unboxed.! 3)
                               in (p_at5T / (1 + ((c_RESTc_at75 / p_at5V) ** p_at5X))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at76
                            -> let c_PTB_at77 = ((toVector x_at76) Data.Vector.Unboxed.! 0)
                               in (p_at5Z * c_PTB_at77))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at78
                            -> let c_NPTB_at79 = ((toVector x_at78) Data.Vector.Unboxed.! 1)
                               in (p_at61 * c_NPTB_at79))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7a
                            -> let c_MiRs_at7b = ((toVector x_at7a) Data.Vector.Unboxed.! 2)
                               in (p_at63 * c_MiRs_at7b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7c
                            -> let c_RESTc_at7d = ((toVector x_at7c) Data.Vector.Unboxed.! 3)
                               in (p_at65 * c_RESTc_at7d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7e
                            -> let
                                 c_EndoNeuroTFs_at7f = ((toVector x_at7e) Data.Vector.Unboxed.! 4)
                               in (p_at67 * c_EndoNeuroTFs_at7f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at68
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7U
                            p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                            (g_at66, gpart_at7U) = Genome.Split.split gpart_at7T
                            p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                            (g_at64, gpart_at7T) = Genome.Split.split gpart_at7S
                            p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                            (g_at62, gpart_at7S) = Genome.Split.split gpart_at7R
                            p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                            (g_at60, gpart_at7R) = Genome.Split.split gpart_at7Q
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at7Q) = Genome.Split.split gpart_at7P
                            p_at5X = Functions.belowten' g_at5W
                            (g_at5W, gpart_at7P) = Genome.Split.split gpart_at7O
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at7O) = Genome.Split.split gpart_at7N
                            p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                            (g_at5S, gpart_at7N) = Genome.Split.split gpart_at7M
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at7M) = Genome.Split.split gpart_at7L
                            p_at5P = Functions.belowten' g_at5O
                            (g_at5O, gpart_at7L) = Genome.Split.split gpart_at7K
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at7K) = Genome.Split.split gpart_at7J
                            p_at5L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5K
                            (g_at5K, gpart_at7J) = Genome.Split.split gpart_at7I
                            p_at5J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5I
                            (g_at5I, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5H = Functions.belowten' g_at5G
                            (g_at5G, gpart_at7H) = Genome.Split.split gpart_at7G
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7G) = Genome.Split.split gpart_at7F
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at7F) = Genome.Split.split gpart_at7E
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7E) = Genome.Split.split gpart_at7D
                            p_at5z = Functions.belowten' g_at5y
                            (g_at5y, gpart_at7D) = Genome.Split.split gpart_at7C
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7C) = Genome.Split.split gpart_at7B
                            p_at5v = Functions.belowten' g_at5u
                            (g_at5u, gpart_at7B) = Genome.Split.split gpart_at7A
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7A) = Genome.Split.split gpart_at7z
                            p_at5r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                            (g_at5q, gpart_at7z) = Genome.Split.split gpart_at7y
                            p_at5p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5o
                            (g_at5o, gpart_at7y) = Genome.Split.split gpart_at7x
                            p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                            (g_at5m, gpart_at7x) = Genome.Split.split gpart_at7w
                            p_at5l = Functions.belowten' g_at5k
                            (g_at5k, gpart_at7w) = Genome.Split.split gpart_at7v
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at7v) = Genome.Split.split gpart_at7u
                            p_at5h = Functions.belowten' g_at5g
                            (g_at5g, gpart_at7u) = Genome.Split.split gpart_at7t
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at7t) = Genome.Split.split gpart_at7s
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at7s) = Genome.Split.split gpart_at7r
                            p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                            (g_at5a, gpart_at7r) = Genome.Split.split gpart_at7q
                            p_at59 = Functions.belowten' g_at58
                            (g_at58, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                            (g_at56, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at55
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                            (g_at54, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at53
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                            (g_at52, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at51 = Functions.belowten' g_at50
                            (g_at50, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                            (g_at4Y, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                            (g_at4U, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at7g) = Genome.Split.split genome_at68
                          in
                            \ desc_at69
                              -> case desc_at69 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   _ -> Nothing }}
