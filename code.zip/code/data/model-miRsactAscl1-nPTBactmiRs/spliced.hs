src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24SV
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24TB
                      p_a24SU = double g_a24ST
                      (g_a24ST, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24SS = double g_a24SR
                      (g_a24SR, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24SQ = double g_a24SP
                      (g_a24SP, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24SO = double g_a24SN
                      (g_a24SN, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24SM = double g_a24SL
                      (g_a24SL, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24SK = double g_a24SJ
                      (g_a24SJ, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24SI = Functions.belowten' g_a24SH
                      (g_a24SH, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24SG = double g_a24SF
                      (g_a24SF, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24SE = Functions.belowten' g_a24SD
                      (g_a24SD, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24SC = double g_a24SB
                      (g_a24SB, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24SA = double g_a24Sz
                      (g_a24Sz, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24Sy = double g_a24Sx
                      (g_a24Sx, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24Sw = Functions.belowten' g_a24Sv
                      (g_a24Sv, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24Su = double g_a24St
                      (g_a24St, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24Ss
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                      (g_a24Sr, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24Sq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sp
                      (g_a24Sp, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24So = Functions.belowten' g_a24Sn
                      (g_a24Sn, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24Sm = double g_a24Sl
                      (g_a24Sl, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24Sk = double g_a24Sj
                      (g_a24Sj, gpart_a24Tj) = Genome.Split.split gpart_a24Ti
                      p_a24Si = double g_a24Sh
                      (g_a24Sh, gpart_a24Ti) = Genome.Split.split gpart_a24Th
                      p_a24Sg = Functions.belowten' g_a24Sf
                      (g_a24Sf, gpart_a24Th) = Genome.Split.split gpart_a24Tg
                      p_a24Se = double g_a24Sd
                      (g_a24Sd, gpart_a24Tg) = Genome.Split.split gpart_a24Tf
                      p_a24Sc = Functions.belowten' g_a24Sb
                      (g_a24Sb, gpart_a24Tf) = Genome.Split.split gpart_a24Te
                      p_a24Sa = double g_a24S9
                      (g_a24S9, gpart_a24Te) = Genome.Split.split gpart_a24Td
                      p_a24S8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S7
                      (g_a24S7, gpart_a24Td) = Genome.Split.split gpart_a24Tc
                      p_a24S6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S5
                      (g_a24S5, gpart_a24Tc) = Genome.Split.split gpart_a24Tb
                      p_a24S4 = double g_a24S3
                      (g_a24S3, gpart_a24Tb) = Genome.Split.split gpart_a24Ta
                      p_a24S2 = Functions.belowten' g_a24S1
                      (g_a24S1, gpart_a24Ta) = Genome.Split.split gpart_a24T9
                      p_a24S0 = double g_a24RZ
                      (g_a24RZ, gpart_a24T9) = Genome.Split.split gpart_a24T8
                      p_a24RY = Functions.belowten' g_a24RX
                      (g_a24RX, gpart_a24T8) = Genome.Split.split gpart_a24T7
                      p_a24RW = double g_a24RV
                      (g_a24RV, gpart_a24T7) = Genome.Split.split gpart_a24T6
                      p_a24RU = double g_a24RT
                      (g_a24RT, gpart_a24T6) = Genome.Split.split gpart_a24T5
                      p_a24RS = Functions.belowten' g_a24RR
                      (g_a24RR, gpart_a24T5) = Genome.Split.split gpart_a24T4
                      p_a24RQ = double g_a24RP
                      (g_a24RP, gpart_a24T4) = Genome.Split.split gpart_a24T3
                      p_a24RO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RN
                      (g_a24RN, gpart_a24T3) = Genome.Split.split gpart_a24T2
                      p_a24RM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RL
                      (g_a24RL, gpart_a24T2) = Genome.Split.split gpart_a24T1
                      p_a24RK = double g_a24RJ
                      (g_a24RJ, gpart_a24T1) = Genome.Split.split gpart_a24T0
                      p_a24RI = double g_a24RH
                      (g_a24RH, gpart_a24T0) = Genome.Split.split gpart_a24SZ
                      p_a24RG = double g_a24RF
                      (g_a24RF, gpart_a24SZ) = Genome.Split.split gpart_a24SY
                      p_a24RE = double g_a24RD
                      (g_a24RD, gpart_a24SY) = Genome.Split.split gpart_a24SX
                      p_a24RC = double g_a24RB
                      (g_a24RB, gpart_a24SX) = Genome.Split.split genome_a24SV
                    in  \ x_a24TC
                          -> let
                               c_PTB_a24TF
                                 = ((Data.Fixed.Vector.toVector x_a24TC) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TD
                                 = ((Data.Fixed.Vector.toVector x_a24TC) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24TJ
                                 = ((Data.Fixed.Vector.toVector x_a24TC) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24TM
                                 = ((Data.Fixed.Vector.toVector x_a24TC) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24TY
                                 = ((Data.Fixed.Vector.toVector x_a24TC) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24RK / (1 + ((c_MiRs_a24TD / p_a24RQ) ** p_a24RS)))
                                    + (negate (p_a24SM * c_PTB_a24TF))),
                                   ((p_a24RU
                                     / (1
                                        + (((c_MiRs_a24TD / p_a24RW) ** p_a24RY)
                                           + ((c_PTB_a24TF / p_a24S0) ** p_a24S2))))
                                    + (negate (p_a24SO * c_NPTB_a24TJ))),
                                   ((p_a24S4
                                     * ((p_a24Si
                                         + (((p_a24RG / p_a24S6) ** p_a24S8)
                                            + ((c_NPTB_a24TJ / p_a24Sa) ** p_a24Sc)))
                                        / (((1 + p_a24Si)
                                            + (((p_a24RG / p_a24S6) ** p_a24S8)
                                               + ((c_NPTB_a24TJ / p_a24Sa) ** p_a24Sc)))
                                           + ((c_RESTc_a24TM / p_a24Se) ** p_a24Sg))))
                                    + (negate (p_a24SQ * c_MiRs_a24TD))),
                                   ((p_a24Sk
                                     * ((p_a24Sy + ((c_PTB_a24TF / p_a24Sm) ** p_a24So))
                                        / (((1 + p_a24Sy) + ((c_PTB_a24TF / p_a24Sm) ** p_a24So))
                                           + (((p_a24RC / p_a24Sq) ** p_a24Ss)
                                              + ((c_MiRs_a24TD / p_a24Su) ** p_a24Sw)))))
                                    + (negate (p_a24SS * c_RESTc_a24TM))),
                                   ((p_a24SA
                                     * ((p_a24SK + ((c_MiRs_a24TD / p_a24SC) ** p_a24SE))
                                        / (((1 + p_a24SK) + ((c_MiRs_a24TD / p_a24SC) ** p_a24SE))
                                           + ((c_RESTc_a24TM / p_a24SG) ** p_a24SI))))
                                    + (negate (p_a24SU * c_EndoNeuroTFs_a24TY)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505158",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505160",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505178",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505180",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505198",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505200",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24SV
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UD
                            p_a24SU = double g_a24ST
                            (g_a24ST, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24SS = double g_a24SR
                            (g_a24SR, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24SQ = double g_a24SP
                            (g_a24SP, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24SO = double g_a24SN
                            (g_a24SN, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24SM = double g_a24SL
                            (g_a24SL, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24SK = double g_a24SJ
                            (g_a24SJ, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24SI = Functions.belowten' g_a24SH
                            (g_a24SH, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24SG = double g_a24SF
                            (g_a24SF, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24SE = Functions.belowten' g_a24SD
                            (g_a24SD, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24SC = double g_a24SB
                            (g_a24SB, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24SA = double g_a24Sz
                            (g_a24Sz, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24Sy = double g_a24Sx
                            (g_a24Sx, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24Sw = Functions.belowten' g_a24Sv
                            (g_a24Sv, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24Su = double g_a24St
                            (g_a24St, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24Ss
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                            (g_a24Sr, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24Sq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sp
                            (g_a24Sp, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24So = Functions.belowten' g_a24Sn
                            (g_a24Sn, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24Sm = double g_a24Sl
                            (g_a24Sl, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24Sk = double g_a24Sj
                            (g_a24Sj, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                            p_a24Si = double g_a24Sh
                            (g_a24Sh, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                            p_a24Sg = Functions.belowten' g_a24Sf
                            (g_a24Sf, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                            p_a24Se = double g_a24Sd
                            (g_a24Sd, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                            p_a24Sc = Functions.belowten' g_a24Sb
                            (g_a24Sb, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                            p_a24Sa = double g_a24S9
                            (g_a24S9, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                            p_a24S8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S7
                            (g_a24S7, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                            p_a24S6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S5
                            (g_a24S5, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                            p_a24S4 = double g_a24S3
                            (g_a24S3, gpart_a24Ud) = Genome.Split.split gpart_a24Uc
                            p_a24S2 = Functions.belowten' g_a24S1
                            (g_a24S1, gpart_a24Uc) = Genome.Split.split gpart_a24Ub
                            p_a24S0 = double g_a24RZ
                            (g_a24RZ, gpart_a24Ub) = Genome.Split.split gpart_a24Ua
                            p_a24RY = Functions.belowten' g_a24RX
                            (g_a24RX, gpart_a24Ua) = Genome.Split.split gpart_a24U9
                            p_a24RW = double g_a24RV
                            (g_a24RV, gpart_a24U9) = Genome.Split.split gpart_a24U8
                            p_a24RU = double g_a24RT
                            (g_a24RT, gpart_a24U8) = Genome.Split.split gpart_a24U7
                            p_a24RS = Functions.belowten' g_a24RR
                            (g_a24RR, gpart_a24U7) = Genome.Split.split gpart_a24U6
                            p_a24RQ = double g_a24RP
                            (g_a24RP, gpart_a24U6) = Genome.Split.split gpart_a24U5
                            p_a24RO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RN
                            (g_a24RN, gpart_a24U5) = Genome.Split.split gpart_a24U4
                            p_a24RM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RL
                            (g_a24RL, gpart_a24U4) = Genome.Split.split gpart_a24U3
                            p_a24RK = double g_a24RJ
                            (g_a24RJ, gpart_a24U3) = Genome.Split.split gpart_a24U2
                            p_a24RI = double g_a24RH
                            (g_a24RH, gpart_a24U2) = Genome.Split.split gpart_a24U1
                            p_a24RG = double g_a24RF
                            (g_a24RF, gpart_a24U1) = Genome.Split.split gpart_a24U0
                            p_a24RE = double g_a24RD
                            (g_a24RD, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                            p_a24RC = double g_a24RB
                            (g_a24RB, gpart_a24TZ) = Genome.Split.split genome_a24SV
                          in
                            \ desc_a24SW
                              -> case desc_a24SW of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RK)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RM)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RO)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RQ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S2)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S4)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S6)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S8)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sa)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sc)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Se)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sg)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Si)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sk)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sm)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24So)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sq)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ss)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Su)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sw)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sy)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SA)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SC)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SE)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SG)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SI)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SK)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SM)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SO)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SQ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SS)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SU)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24X7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24XN
                      p_a24X6 = double g_a24X5
                      (g_a24X5, gpart_a24XN) = Genome.Split.split gpart_a24XM
                      p_a24X4 = double g_a24X3
                      (g_a24X3, gpart_a24XM) = Genome.Split.split gpart_a24XL
                      p_a24X2 = double g_a24X1
                      (g_a24X1, gpart_a24XL) = Genome.Split.split gpart_a24XK
                      p_a24X0 = double g_a24WZ
                      (g_a24WZ, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                      p_a24WY = double g_a24WX
                      (g_a24WX, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24WW = double g_a24WV
                      (g_a24WV, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24WU = Functions.belowten' g_a24WT
                      (g_a24WT, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24WS = double g_a24WR
                      (g_a24WR, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24WQ = Functions.belowten' g_a24WP
                      (g_a24WP, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24WO = double g_a24WN
                      (g_a24WN, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24WM = double g_a24WL
                      (g_a24WL, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24WK = double g_a24WJ
                      (g_a24WJ, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24WI = Functions.belowten' g_a24WH
                      (g_a24WH, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24WG = double g_a24WF
                      (g_a24WF, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24WE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                      (g_a24WD, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24WC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                      (g_a24WB, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24WA = Functions.belowten' g_a24Wz
                      (g_a24Wz, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24Wy = double g_a24Wx
                      (g_a24Wx, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24Ww = double g_a24Wv
                      (g_a24Wv, gpart_a24Xv) = Genome.Split.split gpart_a24Xu
                      p_a24Wu = double g_a24Wt
                      (g_a24Wt, gpart_a24Xu) = Genome.Split.split gpart_a24Xt
                      p_a24Ws = Functions.belowten' g_a24Wr
                      (g_a24Wr, gpart_a24Xt) = Genome.Split.split gpart_a24Xs
                      p_a24Wq = double g_a24Wp
                      (g_a24Wp, gpart_a24Xs) = Genome.Split.split gpart_a24Xr
                      p_a24Wo = Functions.belowten' g_a24Wn
                      (g_a24Wn, gpart_a24Xr) = Genome.Split.split gpart_a24Xq
                      p_a24Wm = double g_a24Wl
                      (g_a24Wl, gpart_a24Xq) = Genome.Split.split gpart_a24Xp
                      p_a24Wk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                      (g_a24Wj, gpart_a24Xp) = Genome.Split.split gpart_a24Xo
                      p_a24Wi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                      (g_a24Wh, gpart_a24Xo) = Genome.Split.split gpart_a24Xn
                      p_a24Wg = double g_a24Wf
                      (g_a24Wf, gpart_a24Xn) = Genome.Split.split gpart_a24Xm
                      p_a24We = Functions.belowten' g_a24Wd
                      (g_a24Wd, gpart_a24Xm) = Genome.Split.split gpart_a24Xl
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24Xl) = Genome.Split.split gpart_a24Xk
                      p_a24Wa = Functions.belowten' g_a24W9
                      (g_a24W9, gpart_a24Xk) = Genome.Split.split gpart_a24Xj
                      p_a24W8 = double g_a24W7
                      (g_a24W7, gpart_a24Xj) = Genome.Split.split gpart_a24Xi
                      p_a24W6 = double g_a24W5
                      (g_a24W5, gpart_a24Xi) = Genome.Split.split gpart_a24Xh
                      p_a24W4 = Functions.belowten' g_a24W3
                      (g_a24W3, gpart_a24Xh) = Genome.Split.split gpart_a24Xg
                      p_a24W2 = double g_a24W1
                      (g_a24W1, gpart_a24Xg) = Genome.Split.split gpart_a24Xf
                      p_a24W0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VZ
                      (g_a24VZ, gpart_a24Xf) = Genome.Split.split gpart_a24Xe
                      p_a24VY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VX
                      (g_a24VX, gpart_a24Xe) = Genome.Split.split gpart_a24Xd
                      p_a24VW = double g_a24VV
                      (g_a24VV, gpart_a24Xd) = Genome.Split.split gpart_a24Xc
                      p_a24VU = double g_a24VT
                      (g_a24VT, gpart_a24Xc) = Genome.Split.split gpart_a24Xb
                      p_a24VS = double g_a24VR
                      (g_a24VR, gpart_a24Xb) = Genome.Split.split gpart_a24Xa
                      p_a24VQ = double g_a24VP
                      (g_a24VP, gpart_a24Xa) = Genome.Split.split gpart_a24X9
                      p_a24VO = double g_a24VN
                      (g_a24VN, gpart_a24X9) = Genome.Split.split genome_a24X7
                    in  \ x_a24XO
                          -> let
                               c_PTB_a24XR
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24XP
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24XV
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24XY
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Ya
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24VW / (1 + ((c_MiRs_a24XP / p_a24W2) ** p_a24W4)))
                                    + (negate (p_a24WY * c_PTB_a24XR))),
                                   ((p_a24W6
                                     / (1
                                        + (((c_MiRs_a24XP / p_a24W8) ** p_a24Wa)
                                           + ((c_PTB_a24XR / p_a24Wc) ** p_a24We))))
                                    + (negate (p_a24X0 * c_NPTB_a24XV))),
                                   ((p_a24Wg
                                     * ((p_a24Wu + ((c_NPTB_a24XV / p_a24Wm) ** p_a24Wo))
                                        / (((1 + p_a24Wu) + ((c_NPTB_a24XV / p_a24Wm) ** p_a24Wo))
                                           + ((c_RESTc_a24XY / p_a24Wq) ** p_a24Ws))))
                                    + (negate (p_a24X2 * c_MiRs_a24XP))),
                                   ((p_a24Ww
                                     * ((p_a24WK + ((c_PTB_a24XR / p_a24Wy) ** p_a24WA))
                                        / (((1 + p_a24WK) + ((c_PTB_a24XR / p_a24Wy) ** p_a24WA))
                                           + (((p_a24VO / p_a24WC) ** p_a24WE)
                                              + ((c_MiRs_a24XP / p_a24WG) ** p_a24WI)))))
                                    + (negate (p_a24X4 * c_RESTc_a24XY))),
                                   ((p_a24WM
                                     * ((p_a24WW + ((c_MiRs_a24XP / p_a24WO) ** p_a24WQ))
                                        / (((1 + p_a24WW) + ((c_MiRs_a24XP / p_a24WO) ** p_a24WQ))
                                           + ((c_RESTc_a24XY / p_a24WS) ** p_a24WU))))
                                    + (negate (p_a24X6 * c_EndoNeuroTFs_a24Ya)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505418",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505420",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505460",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24X7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24YP
                            p_a24X6 = double g_a24X5
                            (g_a24X5, gpart_a24YP) = Genome.Split.split gpart_a24YO
                            p_a24X4 = double g_a24X3
                            (g_a24X3, gpart_a24YO) = Genome.Split.split gpart_a24YN
                            p_a24X2 = double g_a24X1
                            (g_a24X1, gpart_a24YN) = Genome.Split.split gpart_a24YM
                            p_a24X0 = double g_a24WZ
                            (g_a24WZ, gpart_a24YM) = Genome.Split.split gpart_a24YL
                            p_a24WY = double g_a24WX
                            (g_a24WX, gpart_a24YL) = Genome.Split.split gpart_a24YK
                            p_a24WW = double g_a24WV
                            (g_a24WV, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24WU = Functions.belowten' g_a24WT
                            (g_a24WT, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24WS = double g_a24WR
                            (g_a24WR, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24WQ = Functions.belowten' g_a24WP
                            (g_a24WP, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24WO = double g_a24WN
                            (g_a24WN, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24WM = double g_a24WL
                            (g_a24WL, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24WK = double g_a24WJ
                            (g_a24WJ, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24WI = Functions.belowten' g_a24WH
                            (g_a24WH, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24WG = double g_a24WF
                            (g_a24WF, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24WE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                            (g_a24WD, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24WC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                            (g_a24WB, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24WA = Functions.belowten' g_a24Wz
                            (g_a24Wz, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24Wy = double g_a24Wx
                            (g_a24Wx, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24Ww = double g_a24Wv
                            (g_a24Wv, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                            p_a24Wu = double g_a24Wt
                            (g_a24Wt, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                            p_a24Ws = Functions.belowten' g_a24Wr
                            (g_a24Wr, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                            p_a24Wq = double g_a24Wp
                            (g_a24Wp, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                            p_a24Wo = Functions.belowten' g_a24Wn
                            (g_a24Wn, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                            p_a24Wm = double g_a24Wl
                            (g_a24Wl, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                            p_a24Wk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                            (g_a24Wj, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                            p_a24Wi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                            (g_a24Wh, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                            p_a24Wg = double g_a24Wf
                            (g_a24Wf, gpart_a24Yp) = Genome.Split.split gpart_a24Yo
                            p_a24We = Functions.belowten' g_a24Wd
                            (g_a24Wd, gpart_a24Yo) = Genome.Split.split gpart_a24Yn
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Yn) = Genome.Split.split gpart_a24Ym
                            p_a24Wa = Functions.belowten' g_a24W9
                            (g_a24W9, gpart_a24Ym) = Genome.Split.split gpart_a24Yl
                            p_a24W8 = double g_a24W7
                            (g_a24W7, gpart_a24Yl) = Genome.Split.split gpart_a24Yk
                            p_a24W6 = double g_a24W5
                            (g_a24W5, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                            p_a24W4 = Functions.belowten' g_a24W3
                            (g_a24W3, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                            p_a24W2 = double g_a24W1
                            (g_a24W1, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                            p_a24W0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VZ
                            (g_a24VZ, gpart_a24Yh) = Genome.Split.split gpart_a24Yg
                            p_a24VY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VX
                            (g_a24VX, gpart_a24Yg) = Genome.Split.split gpart_a24Yf
                            p_a24VW = double g_a24VV
                            (g_a24VV, gpart_a24Yf) = Genome.Split.split gpart_a24Ye
                            p_a24VU = double g_a24VT
                            (g_a24VT, gpart_a24Ye) = Genome.Split.split gpart_a24Yd
                            p_a24VS = double g_a24VR
                            (g_a24VR, gpart_a24Yd) = Genome.Split.split gpart_a24Yc
                            p_a24VQ = double g_a24VP
                            (g_a24VP, gpart_a24Yc) = Genome.Split.split gpart_a24Yb
                            p_a24VO = double g_a24VN
                            (g_a24VN, gpart_a24Yb) = Genome.Split.split genome_a24X7
                          in
                            \ desc_a24X8
                              -> case desc_a24X8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VW)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VY)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W0)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W2)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W4)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WM)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WO)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WU)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X6)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a251j
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a251Z
                      p_a251i = double g_a251h
                      (g_a251h, gpart_a251Z) = Genome.Split.split gpart_a251Y
                      p_a251g = double g_a251f
                      (g_a251f, gpart_a251Y) = Genome.Split.split gpart_a251X
                      p_a251e = double g_a251d
                      (g_a251d, gpart_a251X) = Genome.Split.split gpart_a251W
                      p_a251c = double g_a251b
                      (g_a251b, gpart_a251W) = Genome.Split.split gpart_a251V
                      p_a251a = double g_a2519
                      (g_a2519, gpart_a251V) = Genome.Split.split gpart_a251U
                      p_a2518 = double g_a2517
                      (g_a2517, gpart_a251U) = Genome.Split.split gpart_a251T
                      p_a2516 = Functions.belowten' g_a2515
                      (g_a2515, gpart_a251T) = Genome.Split.split gpart_a251S
                      p_a2514 = double g_a2513
                      (g_a2513, gpart_a251S) = Genome.Split.split gpart_a251R
                      p_a2512 = Functions.belowten' g_a2511
                      (g_a2511, gpart_a251R) = Genome.Split.split gpart_a251Q
                      p_a2510 = double g_a250Z
                      (g_a250Z, gpart_a251Q) = Genome.Split.split gpart_a251P
                      p_a250Y = double g_a250X
                      (g_a250X, gpart_a251P) = Genome.Split.split gpart_a251O
                      p_a250W = double g_a250V
                      (g_a250V, gpart_a251O) = Genome.Split.split gpart_a251N
                      p_a250U = Functions.belowten' g_a250T
                      (g_a250T, gpart_a251N) = Genome.Split.split gpart_a251M
                      p_a250S = double g_a250R
                      (g_a250R, gpart_a251M) = Genome.Split.split gpart_a251L
                      p_a250Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                      (g_a250P, gpart_a251L) = Genome.Split.split gpart_a251K
                      p_a250O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250N
                      (g_a250N, gpart_a251K) = Genome.Split.split gpart_a251J
                      p_a250M = Functions.belowten' g_a250L
                      (g_a250L, gpart_a251J) = Genome.Split.split gpart_a251I
                      p_a250K = double g_a250J
                      (g_a250J, gpart_a251I) = Genome.Split.split gpart_a251H
                      p_a250I = double g_a250H
                      (g_a250H, gpart_a251H) = Genome.Split.split gpart_a251G
                      p_a250G = double g_a250F
                      (g_a250F, gpart_a251G) = Genome.Split.split gpart_a251F
                      p_a250E = Functions.belowten' g_a250D
                      (g_a250D, gpart_a251F) = Genome.Split.split gpart_a251E
                      p_a250C = double g_a250B
                      (g_a250B, gpart_a251E) = Genome.Split.split gpart_a251D
                      p_a250A = Functions.belowten' g_a250z
                      (g_a250z, gpart_a251D) = Genome.Split.split gpart_a251C
                      p_a250y = double g_a250x
                      (g_a250x, gpart_a251C) = Genome.Split.split gpart_a251B
                      p_a250w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250v
                      (g_a250v, gpart_a251B) = Genome.Split.split gpart_a251A
                      p_a250u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250t
                      (g_a250t, gpart_a251A) = Genome.Split.split gpart_a251z
                      p_a250s = double g_a250r
                      (g_a250r, gpart_a251z) = Genome.Split.split gpart_a251y
                      p_a250q = Functions.belowten' g_a250p
                      (g_a250p, gpart_a251y) = Genome.Split.split gpart_a251x
                      p_a250o = double g_a250n
                      (g_a250n, gpart_a251x) = Genome.Split.split gpart_a251w
                      p_a250m = Functions.belowten' g_a250l
                      (g_a250l, gpart_a251w) = Genome.Split.split gpart_a251v
                      p_a250k = double g_a250j
                      (g_a250j, gpart_a251v) = Genome.Split.split gpart_a251u
                      p_a250i = double g_a250h
                      (g_a250h, gpart_a251u) = Genome.Split.split gpart_a251t
                      p_a250g = Functions.belowten' g_a250f
                      (g_a250f, gpart_a251t) = Genome.Split.split gpart_a251s
                      p_a250e = double g_a250d
                      (g_a250d, gpart_a251s) = Genome.Split.split gpart_a251r
                      p_a250c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250b
                      (g_a250b, gpart_a251r) = Genome.Split.split gpart_a251q
                      p_a250a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2509
                      (g_a2509, gpart_a251q) = Genome.Split.split gpart_a251p
                      p_a2508 = double g_a2507
                      (g_a2507, gpart_a251p) = Genome.Split.split gpart_a251o
                      p_a2506 = double g_a2505
                      (g_a2505, gpart_a251o) = Genome.Split.split gpart_a251n
                      p_a2504 = double g_a2503
                      (g_a2503, gpart_a251n) = Genome.Split.split gpart_a251m
                      p_a2502 = double g_a2501
                      (g_a2501, gpart_a251m) = Genome.Split.split gpart_a251l
                      p_a2500 = double g_a24ZZ
                      (g_a24ZZ, gpart_a251l) = Genome.Split.split genome_a251j
                    in  \ x_a2520
                          -> let
                               c_PTB_a2523
                                 = ((Data.Fixed.Vector.toVector x_a2520) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2521
                                 = ((Data.Fixed.Vector.toVector x_a2520) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2527
                                 = ((Data.Fixed.Vector.toVector x_a2520) Data.Vector.Unboxed.! 1)
                               c_RESTc_a252a
                                 = ((Data.Fixed.Vector.toVector x_a2520) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a252m
                                 = ((Data.Fixed.Vector.toVector x_a2520) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2508 / (1 + ((c_MiRs_a2521 / p_a250e) ** p_a250g)))
                                    + (negate (p_a251a * c_PTB_a2523))),
                                   ((p_a250i
                                     / (1
                                        + (((c_MiRs_a2521 / p_a250k) ** p_a250m)
                                           + ((c_PTB_a2523 / p_a250o) ** p_a250q))))
                                    + (negate (p_a251c * c_NPTB_a2527))),
                                   ((p_a250s
                                     * ((p_a250G + ((c_NPTB_a2527 / p_a250y) ** p_a250A))
                                        / (((1 + p_a250G) + ((c_NPTB_a2527 / p_a250y) ** p_a250A))
                                           + ((c_RESTc_a252a / p_a250C) ** p_a250E))))
                                    + (negate (p_a251e * c_MiRs_a2521))),
                                   ((p_a250I
                                     * ((p_a250W + ((c_PTB_a2523 / p_a250K) ** p_a250M))
                                        / (((1 + p_a250W) + ((c_PTB_a2523 / p_a250K) ** p_a250M))
                                           + ((c_MiRs_a2521 / p_a250S) ** p_a250U))))
                                    + (negate (p_a251g * c_RESTc_a252a))),
                                   ((p_a250Y
                                     * ((p_a2518 + ((c_MiRs_a2521 / p_a2510) ** p_a2512))
                                        / (((1 + p_a2518) + ((c_MiRs_a2521 / p_a2510) ** p_a2512))
                                           + ((c_RESTc_a252a / p_a2514) ** p_a2516))))
                                    + (negate (p_a251i * c_EndoNeuroTFs_a252m)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505678",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505680",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505698",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505700",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505718",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505720",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a251j
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2531
                            p_a251i = double g_a251h
                            (g_a251h, gpart_a2531) = Genome.Split.split gpart_a2530
                            p_a251g = double g_a251f
                            (g_a251f, gpart_a2530) = Genome.Split.split gpart_a252Z
                            p_a251e = double g_a251d
                            (g_a251d, gpart_a252Z) = Genome.Split.split gpart_a252Y
                            p_a251c = double g_a251b
                            (g_a251b, gpart_a252Y) = Genome.Split.split gpart_a252X
                            p_a251a = double g_a2519
                            (g_a2519, gpart_a252X) = Genome.Split.split gpart_a252W
                            p_a2518 = double g_a2517
                            (g_a2517, gpart_a252W) = Genome.Split.split gpart_a252V
                            p_a2516 = Functions.belowten' g_a2515
                            (g_a2515, gpart_a252V) = Genome.Split.split gpart_a252U
                            p_a2514 = double g_a2513
                            (g_a2513, gpart_a252U) = Genome.Split.split gpart_a252T
                            p_a2512 = Functions.belowten' g_a2511
                            (g_a2511, gpart_a252T) = Genome.Split.split gpart_a252S
                            p_a2510 = double g_a250Z
                            (g_a250Z, gpart_a252S) = Genome.Split.split gpart_a252R
                            p_a250Y = double g_a250X
                            (g_a250X, gpart_a252R) = Genome.Split.split gpart_a252Q
                            p_a250W = double g_a250V
                            (g_a250V, gpart_a252Q) = Genome.Split.split gpart_a252P
                            p_a250U = Functions.belowten' g_a250T
                            (g_a250T, gpart_a252P) = Genome.Split.split gpart_a252O
                            p_a250S = double g_a250R
                            (g_a250R, gpart_a252O) = Genome.Split.split gpart_a252N
                            p_a250Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                            (g_a250P, gpart_a252N) = Genome.Split.split gpart_a252M
                            p_a250O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250N
                            (g_a250N, gpart_a252M) = Genome.Split.split gpart_a252L
                            p_a250M = Functions.belowten' g_a250L
                            (g_a250L, gpart_a252L) = Genome.Split.split gpart_a252K
                            p_a250K = double g_a250J
                            (g_a250J, gpart_a252K) = Genome.Split.split gpart_a252J
                            p_a250I = double g_a250H
                            (g_a250H, gpart_a252J) = Genome.Split.split gpart_a252I
                            p_a250G = double g_a250F
                            (g_a250F, gpart_a252I) = Genome.Split.split gpart_a252H
                            p_a250E = Functions.belowten' g_a250D
                            (g_a250D, gpart_a252H) = Genome.Split.split gpart_a252G
                            p_a250C = double g_a250B
                            (g_a250B, gpart_a252G) = Genome.Split.split gpart_a252F
                            p_a250A = Functions.belowten' g_a250z
                            (g_a250z, gpart_a252F) = Genome.Split.split gpart_a252E
                            p_a250y = double g_a250x
                            (g_a250x, gpart_a252E) = Genome.Split.split gpart_a252D
                            p_a250w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250v
                            (g_a250v, gpart_a252D) = Genome.Split.split gpart_a252C
                            p_a250u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250t
                            (g_a250t, gpart_a252C) = Genome.Split.split gpart_a252B
                            p_a250s = double g_a250r
                            (g_a250r, gpart_a252B) = Genome.Split.split gpart_a252A
                            p_a250q = Functions.belowten' g_a250p
                            (g_a250p, gpart_a252A) = Genome.Split.split gpart_a252z
                            p_a250o = double g_a250n
                            (g_a250n, gpart_a252z) = Genome.Split.split gpart_a252y
                            p_a250m = Functions.belowten' g_a250l
                            (g_a250l, gpart_a252y) = Genome.Split.split gpart_a252x
                            p_a250k = double g_a250j
                            (g_a250j, gpart_a252x) = Genome.Split.split gpart_a252w
                            p_a250i = double g_a250h
                            (g_a250h, gpart_a252w) = Genome.Split.split gpart_a252v
                            p_a250g = Functions.belowten' g_a250f
                            (g_a250f, gpart_a252v) = Genome.Split.split gpart_a252u
                            p_a250e = double g_a250d
                            (g_a250d, gpart_a252u) = Genome.Split.split gpart_a252t
                            p_a250c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250b
                            (g_a250b, gpart_a252t) = Genome.Split.split gpart_a252s
                            p_a250a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2509
                            (g_a2509, gpart_a252s) = Genome.Split.split gpart_a252r
                            p_a2508 = double g_a2507
                            (g_a2507, gpart_a252r) = Genome.Split.split gpart_a252q
                            p_a2506 = double g_a2505
                            (g_a2505, gpart_a252q) = Genome.Split.split gpart_a252p
                            p_a2504 = double g_a2503
                            (g_a2503, gpart_a252p) = Genome.Split.split gpart_a252o
                            p_a2502 = double g_a2501
                            (g_a2501, gpart_a252o) = Genome.Split.split gpart_a252n
                            p_a2500 = double g_a24ZZ
                            (g_a24ZZ, gpart_a252n) = Genome.Split.split genome_a251j
                          in
                            \ desc_a251k
                              -> case desc_a251k of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2500)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2502)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2504)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2506)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2508)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250a)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250c)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250e)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250g)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250i)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250k)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250m)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250o)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250q)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250s)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250u)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250w)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250y)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250A)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250C)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250E)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250G)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250I)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250K)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250M)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250O)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Q)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250S)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250U)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250W)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Y)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2510)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2512)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2514)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2516)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2518)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251a)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251c)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251e)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251g)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251i)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a255v
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a256b
                      p_a255u = double g_a255t
                      (g_a255t, gpart_a256b) = Genome.Split.split gpart_a256a
                      p_a255s = double g_a255r
                      (g_a255r, gpart_a256a) = Genome.Split.split gpart_a2569
                      p_a255q = double g_a255p
                      (g_a255p, gpart_a2569) = Genome.Split.split gpart_a2568
                      p_a255o = double g_a255n
                      (g_a255n, gpart_a2568) = Genome.Split.split gpart_a2567
                      p_a255m = double g_a255l
                      (g_a255l, gpart_a2567) = Genome.Split.split gpart_a2566
                      p_a255k = double g_a255j
                      (g_a255j, gpart_a2566) = Genome.Split.split gpart_a2565
                      p_a255i = Functions.belowten' g_a255h
                      (g_a255h, gpart_a2565) = Genome.Split.split gpart_a2564
                      p_a255g = double g_a255f
                      (g_a255f, gpart_a2564) = Genome.Split.split gpart_a2563
                      p_a255e = Functions.belowten' g_a255d
                      (g_a255d, gpart_a2563) = Genome.Split.split gpart_a2562
                      p_a255c = double g_a255b
                      (g_a255b, gpart_a2562) = Genome.Split.split gpart_a2561
                      p_a255a = double g_a2559
                      (g_a2559, gpart_a2561) = Genome.Split.split gpart_a2560
                      p_a2558 = double g_a2557
                      (g_a2557, gpart_a2560) = Genome.Split.split gpart_a255Z
                      p_a2556 = Functions.belowten' g_a2555
                      (g_a2555, gpart_a255Z) = Genome.Split.split gpart_a255Y
                      p_a2554 = double g_a2553
                      (g_a2553, gpart_a255Y) = Genome.Split.split gpart_a255X
                      p_a2552
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2551
                      (g_a2551, gpart_a255X) = Genome.Split.split gpart_a255W
                      p_a2550
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254Z
                      (g_a254Z, gpart_a255W) = Genome.Split.split gpart_a255V
                      p_a254Y = Functions.belowten' g_a254X
                      (g_a254X, gpart_a255V) = Genome.Split.split gpart_a255U
                      p_a254W = double g_a254V
                      (g_a254V, gpart_a255U) = Genome.Split.split gpart_a255T
                      p_a254U = double g_a254T
                      (g_a254T, gpart_a255T) = Genome.Split.split gpart_a255S
                      p_a254S = double g_a254R
                      (g_a254R, gpart_a255S) = Genome.Split.split gpart_a255R
                      p_a254Q = Functions.belowten' g_a254P
                      (g_a254P, gpart_a255R) = Genome.Split.split gpart_a255Q
                      p_a254O = double g_a254N
                      (g_a254N, gpart_a255Q) = Genome.Split.split gpart_a255P
                      p_a254M = Functions.belowten' g_a254L
                      (g_a254L, gpart_a255P) = Genome.Split.split gpart_a255O
                      p_a254K = double g_a254J
                      (g_a254J, gpart_a255O) = Genome.Split.split gpart_a255N
                      p_a254I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254H
                      (g_a254H, gpart_a255N) = Genome.Split.split gpart_a255M
                      p_a254G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254F
                      (g_a254F, gpart_a255M) = Genome.Split.split gpart_a255L
                      p_a254E = double g_a254D
                      (g_a254D, gpart_a255L) = Genome.Split.split gpart_a255K
                      p_a254C = Functions.belowten' g_a254B
                      (g_a254B, gpart_a255K) = Genome.Split.split gpart_a255J
                      p_a254A = double g_a254z
                      (g_a254z, gpart_a255J) = Genome.Split.split gpart_a255I
                      p_a254y = Functions.belowten' g_a254x
                      (g_a254x, gpart_a255I) = Genome.Split.split gpart_a255H
                      p_a254w = double g_a254v
                      (g_a254v, gpart_a255H) = Genome.Split.split gpart_a255G
                      p_a254u = double g_a254t
                      (g_a254t, gpart_a255G) = Genome.Split.split gpart_a255F
                      p_a254s = Functions.belowten' g_a254r
                      (g_a254r, gpart_a255F) = Genome.Split.split gpart_a255E
                      p_a254q = double g_a254p
                      (g_a254p, gpart_a255E) = Genome.Split.split gpart_a255D
                      p_a254o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254n
                      (g_a254n, gpart_a255D) = Genome.Split.split gpart_a255C
                      p_a254m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254l
                      (g_a254l, gpart_a255C) = Genome.Split.split gpart_a255B
                      p_a254k = double g_a254j
                      (g_a254j, gpart_a255B) = Genome.Split.split gpart_a255A
                      p_a254i = double g_a254h
                      (g_a254h, gpart_a255A) = Genome.Split.split gpart_a255z
                      p_a254g = double g_a254f
                      (g_a254f, gpart_a255z) = Genome.Split.split gpart_a255y
                      p_a254e = double g_a254d
                      (g_a254d, gpart_a255y) = Genome.Split.split gpart_a255x
                      p_a254c = double g_a254b
                      (g_a254b, gpart_a255x) = Genome.Split.split genome_a255v
                    in  \ x_a256c
                          -> let
                               c_PTB_a256f
                                 = ((Data.Fixed.Vector.toVector x_a256c) Data.Vector.Unboxed.! 0)
                               c_MiRs_a256d
                                 = ((Data.Fixed.Vector.toVector x_a256c) Data.Vector.Unboxed.! 2)
                               c_NPTB_a256j
                                 = ((Data.Fixed.Vector.toVector x_a256c) Data.Vector.Unboxed.! 1)
                               c_RESTc_a256m
                                 = ((Data.Fixed.Vector.toVector x_a256c) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a256y
                                 = ((Data.Fixed.Vector.toVector x_a256c) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a254k
                                     / (1
                                        + (((p_a254c / p_a254m) ** p_a254o)
                                           + ((c_MiRs_a256d / p_a254q) ** p_a254s))))
                                    + (negate (p_a255m * c_PTB_a256f))),
                                   ((p_a254u
                                     / (1
                                        + (((c_MiRs_a256d / p_a254w) ** p_a254y)
                                           + ((c_PTB_a256f / p_a254A) ** p_a254C))))
                                    + (negate (p_a255o * c_NPTB_a256j))),
                                   ((p_a254E
                                     * ((p_a254S + ((c_NPTB_a256j / p_a254K) ** p_a254M))
                                        / (((1 + p_a254S) + ((c_NPTB_a256j / p_a254K) ** p_a254M))
                                           + ((c_RESTc_a256m / p_a254O) ** p_a254Q))))
                                    + (negate (p_a255q * c_MiRs_a256d))),
                                   ((p_a254U
                                     * ((p_a2558 + ((c_PTB_a256f / p_a254W) ** p_a254Y))
                                        / (((1 + p_a2558) + ((c_PTB_a256f / p_a254W) ** p_a254Y))
                                           + ((c_MiRs_a256d / p_a2554) ** p_a2556))))
                                    + (negate (p_a255s * c_RESTc_a256m))),
                                   ((p_a255a
                                     * ((p_a255k + ((c_MiRs_a256d / p_a255c) ** p_a255e))
                                        / (((1 + p_a255k) + ((c_MiRs_a256d / p_a255c) ** p_a255e))
                                           + ((c_RESTc_a256m / p_a255g) ** p_a255i))))
                                    + (negate (p_a255u * c_EndoNeuroTFs_a256y)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505938",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505958",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505960",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505978",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505980",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679506007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679506008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a255v
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a257d
                            p_a255u = double g_a255t
                            (g_a255t, gpart_a257d) = Genome.Split.split gpart_a257c
                            p_a255s = double g_a255r
                            (g_a255r, gpart_a257c) = Genome.Split.split gpart_a257b
                            p_a255q = double g_a255p
                            (g_a255p, gpart_a257b) = Genome.Split.split gpart_a257a
                            p_a255o = double g_a255n
                            (g_a255n, gpart_a257a) = Genome.Split.split gpart_a2579
                            p_a255m = double g_a255l
                            (g_a255l, gpart_a2579) = Genome.Split.split gpart_a2578
                            p_a255k = double g_a255j
                            (g_a255j, gpart_a2578) = Genome.Split.split gpart_a2577
                            p_a255i = Functions.belowten' g_a255h
                            (g_a255h, gpart_a2577) = Genome.Split.split gpart_a2576
                            p_a255g = double g_a255f
                            (g_a255f, gpart_a2576) = Genome.Split.split gpart_a2575
                            p_a255e = Functions.belowten' g_a255d
                            (g_a255d, gpart_a2575) = Genome.Split.split gpart_a2574
                            p_a255c = double g_a255b
                            (g_a255b, gpart_a2574) = Genome.Split.split gpart_a2573
                            p_a255a = double g_a2559
                            (g_a2559, gpart_a2573) = Genome.Split.split gpart_a2572
                            p_a2558 = double g_a2557
                            (g_a2557, gpart_a2572) = Genome.Split.split gpart_a2571
                            p_a2556 = Functions.belowten' g_a2555
                            (g_a2555, gpart_a2571) = Genome.Split.split gpart_a2570
                            p_a2554 = double g_a2553
                            (g_a2553, gpart_a2570) = Genome.Split.split gpart_a256Z
                            p_a2552
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2551
                            (g_a2551, gpart_a256Z) = Genome.Split.split gpart_a256Y
                            p_a2550
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254Z
                            (g_a254Z, gpart_a256Y) = Genome.Split.split gpart_a256X
                            p_a254Y = Functions.belowten' g_a254X
                            (g_a254X, gpart_a256X) = Genome.Split.split gpart_a256W
                            p_a254W = double g_a254V
                            (g_a254V, gpart_a256W) = Genome.Split.split gpart_a256V
                            p_a254U = double g_a254T
                            (g_a254T, gpart_a256V) = Genome.Split.split gpart_a256U
                            p_a254S = double g_a254R
                            (g_a254R, gpart_a256U) = Genome.Split.split gpart_a256T
                            p_a254Q = Functions.belowten' g_a254P
                            (g_a254P, gpart_a256T) = Genome.Split.split gpart_a256S
                            p_a254O = double g_a254N
                            (g_a254N, gpart_a256S) = Genome.Split.split gpart_a256R
                            p_a254M = Functions.belowten' g_a254L
                            (g_a254L, gpart_a256R) = Genome.Split.split gpart_a256Q
                            p_a254K = double g_a254J
                            (g_a254J, gpart_a256Q) = Genome.Split.split gpart_a256P
                            p_a254I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254H
                            (g_a254H, gpart_a256P) = Genome.Split.split gpart_a256O
                            p_a254G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254F
                            (g_a254F, gpart_a256O) = Genome.Split.split gpart_a256N
                            p_a254E = double g_a254D
                            (g_a254D, gpart_a256N) = Genome.Split.split gpart_a256M
                            p_a254C = Functions.belowten' g_a254B
                            (g_a254B, gpart_a256M) = Genome.Split.split gpart_a256L
                            p_a254A = double g_a254z
                            (g_a254z, gpart_a256L) = Genome.Split.split gpart_a256K
                            p_a254y = Functions.belowten' g_a254x
                            (g_a254x, gpart_a256K) = Genome.Split.split gpart_a256J
                            p_a254w = double g_a254v
                            (g_a254v, gpart_a256J) = Genome.Split.split gpart_a256I
                            p_a254u = double g_a254t
                            (g_a254t, gpart_a256I) = Genome.Split.split gpart_a256H
                            p_a254s = Functions.belowten' g_a254r
                            (g_a254r, gpart_a256H) = Genome.Split.split gpart_a256G
                            p_a254q = double g_a254p
                            (g_a254p, gpart_a256G) = Genome.Split.split gpart_a256F
                            p_a254o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254n
                            (g_a254n, gpart_a256F) = Genome.Split.split gpart_a256E
                            p_a254m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254l
                            (g_a254l, gpart_a256E) = Genome.Split.split gpart_a256D
                            p_a254k = double g_a254j
                            (g_a254j, gpart_a256D) = Genome.Split.split gpart_a256C
                            p_a254i = double g_a254h
                            (g_a254h, gpart_a256C) = Genome.Split.split gpart_a256B
                            p_a254g = double g_a254f
                            (g_a254f, gpart_a256B) = Genome.Split.split gpart_a256A
                            p_a254e = double g_a254d
                            (g_a254d, gpart_a256A) = Genome.Split.split gpart_a256z
                            p_a254c = double g_a254b
                            (g_a254b, gpart_a256z) = Genome.Split.split genome_a255v
                          in
                            \ desc_a255w
                              -> case desc_a255w of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254c)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254e)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254g)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254i)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254k)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254m)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254o)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254s)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254u)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254w)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254y)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254A)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254C)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254E)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254G)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254I)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254K)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254M)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254O)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254Q)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254S)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254U)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254W)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254Y)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2550)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2552)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2554)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2556)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2558)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255a)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255c)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255e)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255g)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255i)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255k)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255m)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255o)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255s)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a255u)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUl
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asV1
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asV1) = Genome.Split.split gpart_asV0
                      p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                      (g_asUh, gpart_asV0) = Genome.Split.split gpart_asUZ
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asUZ) = Genome.Split.split gpart_asUY
                      p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                      (g_asUd, gpart_asUY) = Genome.Split.split gpart_asUX
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asUX) = Genome.Split.split gpart_asUW
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asU8 = Functions.belowten' g_asU7
                      (g_asU7, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asU4 = Functions.belowten' g_asU3
                      (g_asU3, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                      (g_asTZ, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asTW = Functions.belowten' g_asTV
                      (g_asTV, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTR
                      (g_asTR, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTP
                      (g_asTP, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asTO = Functions.belowten' g_asTN
                      (g_asTN, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                      (g_asTL, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                      (g_asTJ, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                      (g_asTH, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTG = Functions.belowten' g_asTF
                      (g_asTF, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                      (g_asTD, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTC = Functions.belowten' g_asTB
                      (g_asTB, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                      (g_asTz, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                      (g_asTx, gpart_asUD) = Genome.Split.split gpart_asUC
                      p_asTw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTv
                      (g_asTv, gpart_asUC) = Genome.Split.split gpart_asUB
                      p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                      (g_asTt, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTs = Functions.belowten' g_asTr
                      (g_asTr, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                      (g_asTp, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTo = Functions.belowten' g_asTn
                      (g_asTn, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                      (g_asTl, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                      (g_asTj, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTi = Functions.belowten' g_asTh
                      (g_asTh, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                      (g_asTf, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTd
                      (g_asTd, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTb
                      (g_asTb, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTa = code-0.1.0.0:Genome.FixedList.Functions.double g_asT9
                      (g_asT9, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asT8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT7
                      (g_asT7, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                      (g_asT5, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                      (g_asT3, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                      (g_asT1, gpart_asUn) = Genome.Split.split genome_asUl
                    in
                      [Reaction
                         (\ x_asV2
                            -> let c_MiRs_asV3 = ((toVector x_asV2) Data.Vector.Unboxed.! 2)
                               in (p_asTa / (1 + ((c_MiRs_asV3 / p_asTg) ** p_asTi))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asV4
                            -> let
                                 c_MiRs_asV5 = ((toVector x_asV4) Data.Vector.Unboxed.! 2)
                                 c_PTB_asV6 = ((toVector x_asV4) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTk
                                  / (1
                                     + (((c_MiRs_asV5 / p_asTm) ** p_asTo)
                                        + ((c_PTB_asV6 / p_asTq) ** p_asTs)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asV7
                            -> let
                                 c_RESTc_asVa = ((toVector x_asV7) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asV8 = ((toVector x_asV7) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTu
                                  * ((p_asTI
                                      + (((p_asT6 / p_asTw) ** p_asTy)
                                         + ((c_NPTB_asV8 / p_asTA) ** p_asTC)))
                                     / (((1 + p_asTI)
                                         + (((p_asT6 / p_asTw) ** p_asTy)
                                            + ((c_NPTB_asV8 / p_asTA) ** p_asTC)))
                                        + ((c_RESTc_asVa / p_asTE) ** p_asTG)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVb
                            -> let
                                 c_MiRs_asVe = ((toVector x_asVb) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVc = ((toVector x_asVb) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTK
                                  * ((p_asTY + ((c_PTB_asVc / p_asTM) ** p_asTO))
                                     / (((1 + p_asTY) + ((c_PTB_asVc / p_asTM) ** p_asTO))
                                        + (((p_asT2 / p_asTQ) ** p_asTS)
                                           + ((c_MiRs_asVe / p_asTU) ** p_asTW))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVf
                            -> let
                                 c_RESTc_asVi = ((toVector x_asVf) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asVg = ((toVector x_asVf) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asU0
                                  * ((p_asUa + ((c_MiRs_asVg / p_asU2) ** p_asU4))
                                     / (((1 + p_asUa) + ((c_MiRs_asVg / p_asU2) ** p_asU4))
                                        + ((c_RESTc_asVi / p_asU6) ** p_asU8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVj
                            -> let c_PTB_asVk = ((toVector x_asVj) Data.Vector.Unboxed.! 0)
                               in (p_asUc * c_PTB_asVk))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVl
                            -> let c_NPTB_asVm = ((toVector x_asVl) Data.Vector.Unboxed.! 1)
                               in (p_asUe * c_NPTB_asVm))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVn
                            -> let c_MiRs_asVo = ((toVector x_asVn) Data.Vector.Unboxed.! 2)
                               in (p_asUg * c_MiRs_asVo))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVp
                            -> let c_RESTc_asVq = ((toVector x_asVp) Data.Vector.Unboxed.! 3)
                               in (p_asUi * c_RESTc_asVq))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVr
                            -> let
                                 c_EndoNeuroTFs_asVs = ((toVector x_asVr) Data.Vector.Unboxed.! 4)
                               in (p_asUk * c_EndoNeuroTFs_asVs))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120842",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120846",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120848",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120866",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120868",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUl
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWc
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWc) = Genome.Split.split gpart_asWb
                            p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                            (g_asUh, gpart_asWb) = Genome.Split.split gpart_asWa
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWa) = Genome.Split.split gpart_asW9
                            p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                            (g_asUd, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asW8) = Genome.Split.split gpart_asW7
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asW7) = Genome.Split.split gpart_asW6
                            p_asU8 = Functions.belowten' g_asU7
                            (g_asU7, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asU4 = Functions.belowten' g_asU3
                            (g_asU3, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                            (g_asTZ, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asTW = Functions.belowten' g_asTV
                            (g_asTV, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTR
                            (g_asTR, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTP
                            (g_asTP, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTO = Functions.belowten' g_asTN
                            (g_asTN, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                            (g_asTL, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                            (g_asTJ, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                            (g_asTH, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asTG = Functions.belowten' g_asTF
                            (g_asTF, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                            (g_asTD, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asTC = Functions.belowten' g_asTB
                            (g_asTB, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                            (g_asTz, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asTy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                            (g_asTx, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTv
                            (g_asTv, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                            (g_asTt, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTs = Functions.belowten' g_asTr
                            (g_asTr, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                            (g_asTp, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTo = Functions.belowten' g_asTn
                            (g_asTn, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                            (g_asTl, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                            (g_asTj, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTi = Functions.belowten' g_asTh
                            (g_asTh, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                            (g_asTf, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTd
                            (g_asTd, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTb
                            (g_asTb, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTa = code-0.1.0.0:Genome.FixedList.Functions.double g_asT9
                            (g_asT9, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asT8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT7
                            (g_asT7, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                            (g_asT5, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                            (g_asT3, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                            (g_asT1, gpart_asVy) = Genome.Split.split genome_asUl
                          in
                            \ desc_asUm
                              -> case desc_asUm of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTa)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTc)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTe)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTi)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTk)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTm)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTo)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTq)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTs)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTu)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTw)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTy)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTA)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTC)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTE)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTG)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTI)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYd
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYT
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                      (g_asY7, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                      (g_asY5, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                      (g_asY3, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                      (g_asY1, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asY0 = Functions.belowten' g_asXZ
                      (g_asXZ, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                      (g_asXX, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asXW = Functions.belowten' g_asXV
                      (g_asXV, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                      (g_asXT, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXO = Functions.belowten' g_asXN
                      (g_asXN, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                      (g_asXL, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXJ
                      (g_asXJ, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                      (g_asXH, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXG = Functions.belowten' g_asXF
                      (g_asXF, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                      (g_asXD, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                      (g_asXz, gpart_asYA) = Genome.Split.split gpart_asYz
                      p_asXy = Functions.belowten' g_asXx
                      (g_asXx, gpart_asYz) = Genome.Split.split gpart_asYy
                      p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                      (g_asXv, gpart_asYy) = Genome.Split.split gpart_asYx
                      p_asXu = Functions.belowten' g_asXt
                      (g_asXt, gpart_asYx) = Genome.Split.split gpart_asYw
                      p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                      (g_asXr, gpart_asYw) = Genome.Split.split gpart_asYv
                      p_asXq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXp
                      (g_asXp, gpart_asYv) = Genome.Split.split gpart_asYu
                      p_asXo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXn
                      (g_asXn, gpart_asYu) = Genome.Split.split gpart_asYt
                      p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                      (g_asXl, gpart_asYt) = Genome.Split.split gpart_asYs
                      p_asXk = Functions.belowten' g_asXj
                      (g_asXj, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXi = code-0.1.0.0:Genome.FixedList.Functions.double g_asXh
                      (g_asXh, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXg = Functions.belowten' g_asXf
                      (g_asXf, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                      (g_asXd, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                      (g_asXb, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXa = Functions.belowten' g_asX9
                      (g_asX9, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asX8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX7
                      (g_asX7, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asX6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX5
                      (g_asX5, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asX4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                      (g_asX3, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asX2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX1
                      (g_asX1, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                      (g_asWZ, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                      (g_asWX, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                      (g_asWV, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                      (g_asWT, gpart_asYf) = Genome.Split.split genome_asYd
                    in
                      [Reaction
                         (\ x_asYU
                            -> let c_MiRs_asYV = ((toVector x_asYU) Data.Vector.Unboxed.! 2)
                               in (p_asX2 / (1 + ((c_MiRs_asYV / p_asX8) ** p_asXa))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYW
                            -> let
                                 c_MiRs_asYX = ((toVector x_asYW) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYY = ((toVector x_asYW) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXc
                                  / (1
                                     + (((c_MiRs_asYX / p_asXe) ** p_asXg)
                                        + ((c_PTB_asYY / p_asXi) ** p_asXk)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYZ
                            -> let
                                 c_RESTc_asZ2 = ((toVector x_asYZ) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asZ0 = ((toVector x_asYZ) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXm
                                  * ((p_asXA + ((c_NPTB_asZ0 / p_asXs) ** p_asXu))
                                     / (((1 + p_asXA) + ((c_NPTB_asZ0 / p_asXs) ** p_asXu))
                                        + ((c_RESTc_asZ2 / p_asXw) ** p_asXy)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZ3
                            -> let
                                 c_MiRs_asZ6 = ((toVector x_asZ3) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZ4 = ((toVector x_asZ3) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXC
                                  * ((p_asXQ + ((c_PTB_asZ4 / p_asXE) ** p_asXG))
                                     / (((1 + p_asXQ) + ((c_PTB_asZ4 / p_asXE) ** p_asXG))
                                        + (((p_asWU / p_asXI) ** p_asXK)
                                           + ((c_MiRs_asZ6 / p_asXM) ** p_asXO))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZ7
                            -> let
                                 c_RESTc_asZa = ((toVector x_asZ7) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZ8 = ((toVector x_asZ7) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asXS
                                  * ((p_asY2 + ((c_MiRs_asZ8 / p_asXU) ** p_asXW))
                                     / (((1 + p_asY2) + ((c_MiRs_asZ8 / p_asXU) ** p_asXW))
                                        + ((c_RESTc_asZa / p_asXY) ** p_asY0)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZb
                            -> let c_PTB_asZc = ((toVector x_asZb) Data.Vector.Unboxed.! 0)
                               in (p_asY4 * c_PTB_asZc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZd
                            -> let c_NPTB_asZe = ((toVector x_asZd) Data.Vector.Unboxed.! 1)
                               in (p_asY6 * c_NPTB_asZe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZf
                            -> let c_MiRs_asZg = ((toVector x_asZf) Data.Vector.Unboxed.! 2)
                               in (p_asY8 * c_MiRs_asZg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZh
                            -> let c_RESTc_asZi = ((toVector x_asZh) Data.Vector.Unboxed.! 3)
                               in (p_asYa * c_RESTc_asZi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZj
                            -> let
                                 c_EndoNeuroTFs_asZk = ((toVector x_asZj) Data.Vector.Unboxed.! 4)
                               in (p_asYc * c_EndoNeuroTFs_asZk))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121084",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121086",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121088",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121090",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121106",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121108",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYd
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZZ
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                            (g_asY7, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                            (g_asY5, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                            (g_asY3, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                            (g_asY1, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asY0 = Functions.belowten' g_asXZ
                            (g_asXZ, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                            (g_asXX, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXW = Functions.belowten' g_asXV
                            (g_asXV, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXU = code-0.1.0.0:Genome.FixedList.Functions.double g_asXT
                            (g_asXT, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXO = Functions.belowten' g_asXN
                            (g_asXN, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                            (g_asXL, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXJ
                            (g_asXJ, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                            (g_asXH, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXG = Functions.belowten' g_asXF
                            (g_asXF, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                            (g_asXD, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                            (g_asXz, gpart_asZG) = Genome.Split.split gpart_asZF
                            p_asXy = Functions.belowten' g_asXx
                            (g_asXx, gpart_asZF) = Genome.Split.split gpart_asZE
                            p_asXw = code-0.1.0.0:Genome.FixedList.Functions.double g_asXv
                            (g_asXv, gpart_asZE) = Genome.Split.split gpart_asZD
                            p_asXu = Functions.belowten' g_asXt
                            (g_asXt, gpart_asZD) = Genome.Split.split gpart_asZC
                            p_asXs = code-0.1.0.0:Genome.FixedList.Functions.double g_asXr
                            (g_asXr, gpart_asZC) = Genome.Split.split gpart_asZB
                            p_asXq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXp
                            (g_asXp, gpart_asZB) = Genome.Split.split gpart_asZA
                            p_asXo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXn
                            (g_asXn, gpart_asZA) = Genome.Split.split gpart_asZz
                            p_asXm = code-0.1.0.0:Genome.FixedList.Functions.double g_asXl
                            (g_asXl, gpart_asZz) = Genome.Split.split gpart_asZy
                            p_asXk = Functions.belowten' g_asXj
                            (g_asXj, gpart_asZy) = Genome.Split.split gpart_asZx
                            p_asXi = code-0.1.0.0:Genome.FixedList.Functions.double g_asXh
                            (g_asXh, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXg = Functions.belowten' g_asXf
                            (g_asXf, gpart_asZw) = Genome.Split.split gpart_asZv
                            p_asXe = code-0.1.0.0:Genome.FixedList.Functions.double g_asXd
                            (g_asXd, gpart_asZv) = Genome.Split.split gpart_asZu
                            p_asXc = code-0.1.0.0:Genome.FixedList.Functions.double g_asXb
                            (g_asXb, gpart_asZu) = Genome.Split.split gpart_asZt
                            p_asXa = Functions.belowten' g_asX9
                            (g_asX9, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asX8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX7
                            (g_asX7, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asX6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX5
                            (g_asX5, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asX4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX3
                            (g_asX3, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asX2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX1
                            (g_asX1, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asX0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asWZ
                            (g_asWZ, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asWY = code-0.1.0.0:Genome.FixedList.Functions.double g_asWX
                            (g_asWX, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asWW = code-0.1.0.0:Genome.FixedList.Functions.double g_asWV
                            (g_asWV, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asWU = code-0.1.0.0:Genome.FixedList.Functions.double g_asWT
                            (g_asWT, gpart_asZl) = Genome.Split.split genome_asYd
                          in
                            \ desc_asYe
                              -> case desc_asYe of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWU)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWW)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWY)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX0)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX2)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX4)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX6)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX8)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXa)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXc)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXe)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXg)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXi)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXk)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXm)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXo)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXq)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXs)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXw)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at20
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2G
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                      (g_at1W, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1V = code-0.1.0.0:Genome.FixedList.Functions.double g_at1U
                      (g_at1U, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                      (g_at1S, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                      (g_at1Q, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                      (g_at1O, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1N = Functions.belowten' g_at1M
                      (g_at1M, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                      (g_at1K, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1J = Functions.belowten' g_at1I
                      (g_at1I, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                      (g_at1G, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                      (g_at1E, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                      (g_at1C, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1B = Functions.belowten' g_at1A
                      (g_at1A, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                      (g_at1y, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1w
                      (g_at1w, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1u
                      (g_at1u, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1t = Functions.belowten' g_at1s
                      (g_at1s, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                      (g_at1q, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1p = code-0.1.0.0:Genome.FixedList.Functions.double g_at1o
                      (g_at1o, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                      (g_at1m, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1l = Functions.belowten' g_at1k
                      (g_at1k, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1h = Functions.belowten' g_at1g
                      (g_at1g, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                      (g_at1e, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at1d
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1c
                      (g_at1c, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at1b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1a
                      (g_at1a, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                      (g_at18, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at17 = Functions.belowten' g_at16
                      (g_at16, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                      (g_at14, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at13 = Functions.belowten' g_at12
                      (g_at12, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                      (g_at10, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                      (g_at0Y, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at0X = Functions.belowten' g_at0W
                      (g_at0W, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                      (g_at0U, gpart_at29) = Genome.Split.split gpart_at28
                      p_at0T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0S
                      (g_at0S, gpart_at28) = Genome.Split.split gpart_at27
                      p_at0R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Q
                      (g_at0Q, gpart_at27) = Genome.Split.split gpart_at26
                      p_at0P = code-0.1.0.0:Genome.FixedList.Functions.double g_at0O
                      (g_at0O, gpart_at26) = Genome.Split.split gpart_at25
                      p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                      (g_at0M, gpart_at25) = Genome.Split.split gpart_at24
                      p_at0L = code-0.1.0.0:Genome.FixedList.Functions.double g_at0K
                      (g_at0K, gpart_at24) = Genome.Split.split gpart_at23
                      p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                      (g_at0I, gpart_at23) = Genome.Split.split gpart_at22
                      p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                      (g_at0G, gpart_at22) = Genome.Split.split genome_at20
                    in
                      [Reaction
                         (\ x_at2H
                            -> let c_MiRs_at2I = ((toVector x_at2H) Data.Vector.Unboxed.! 2)
                               in (p_at0P / (1 + ((c_MiRs_at2I / p_at0V) ** p_at0X))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2J
                            -> let
                                 c_MiRs_at2K = ((toVector x_at2J) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2L = ((toVector x_at2J) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0Z
                                  / (1
                                     + (((c_MiRs_at2K / p_at11) ** p_at13)
                                        + ((c_PTB_at2L / p_at15) ** p_at17)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2M
                            -> let
                                 c_RESTc_at2P = ((toVector x_at2M) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at2N = ((toVector x_at2M) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at19
                                  * ((p_at1n + ((c_NPTB_at2N / p_at1f) ** p_at1h))
                                     / (((1 + p_at1n) + ((c_NPTB_at2N / p_at1f) ** p_at1h))
                                        + ((c_RESTc_at2P / p_at1j) ** p_at1l)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2Q
                            -> let
                                 c_MiRs_at2T = ((toVector x_at2Q) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2R = ((toVector x_at2Q) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1p
                                  * ((p_at1D + ((c_PTB_at2R / p_at1r) ** p_at1t))
                                     / (((1 + p_at1D) + ((c_PTB_at2R / p_at1r) ** p_at1t))
                                        + ((c_MiRs_at2T / p_at1z) ** p_at1B)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2U
                            -> let
                                 c_RESTc_at2X = ((toVector x_at2U) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at2V = ((toVector x_at2U) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at1F
                                  * ((p_at1P + ((c_MiRs_at2V / p_at1H) ** p_at1J))
                                     / (((1 + p_at1P) + ((c_MiRs_at2V / p_at1H) ** p_at1J))
                                        + ((c_RESTc_at2X / p_at1L) ** p_at1N)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2Y
                            -> let c_PTB_at2Z = ((toVector x_at2Y) Data.Vector.Unboxed.! 0)
                               in (p_at1R * c_PTB_at2Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at30
                            -> let c_NPTB_at31 = ((toVector x_at30) Data.Vector.Unboxed.! 1)
                               in (p_at1T * c_NPTB_at31))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at32
                            -> let c_MiRs_at33 = ((toVector x_at32) Data.Vector.Unboxed.! 2)
                               in (p_at1V * c_MiRs_at33))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at34
                            -> let c_RESTc_at35 = ((toVector x_at34) Data.Vector.Unboxed.! 3)
                               in (p_at1X * c_RESTc_at35))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at36
                            -> let
                                 c_EndoNeuroTFs_at37 = ((toVector x_at36) Data.Vector.Unboxed.! 4)
                               in (p_at1Z * c_EndoNeuroTFs_at37))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121321",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121323",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121355",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121361",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121363",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at20
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3M
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                            (g_at1W, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at1V = code-0.1.0.0:Genome.FixedList.Functions.double g_at1U
                            (g_at1U, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                            (g_at1S, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                            (g_at1Q, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                            (g_at1O, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1N = Functions.belowten' g_at1M
                            (g_at1M, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                            (g_at1K, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1J = Functions.belowten' g_at1I
                            (g_at1I, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                            (g_at1G, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                            (g_at1E, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                            (g_at1C, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1B = Functions.belowten' g_at1A
                            (g_at1A, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                            (g_at1y, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1w
                            (g_at1w, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1u
                            (g_at1u, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1t = Functions.belowten' g_at1s
                            (g_at1s, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                            (g_at1q, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1p = code-0.1.0.0:Genome.FixedList.Functions.double g_at1o
                            (g_at1o, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                            (g_at1m, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1l = Functions.belowten' g_at1k
                            (g_at1k, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1h = Functions.belowten' g_at1g
                            (g_at1g, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                            (g_at1e, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1d
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1c
                            (g_at1c, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1a
                            (g_at1a, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                            (g_at18, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at17 = Functions.belowten' g_at16
                            (g_at16, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                            (g_at14, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at13 = Functions.belowten' g_at12
                            (g_at12, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                            (g_at10, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                            (g_at0Y, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at0X = Functions.belowten' g_at0W
                            (g_at0W, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                            (g_at0U, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at0T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0S
                            (g_at0S, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at0R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Q
                            (g_at0Q, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at0P = code-0.1.0.0:Genome.FixedList.Functions.double g_at0O
                            (g_at0O, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                            (g_at0M, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at0L = code-0.1.0.0:Genome.FixedList.Functions.double g_at0K
                            (g_at0K, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                            (g_at0I, gpart_at39) = Genome.Split.split gpart_at38
                            p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                            (g_at0G, gpart_at38) = Genome.Split.split genome_at20
                          in
                            \ desc_at21
                              -> case desc_at21 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0L)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0N)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0P)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0R)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0T)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0V)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0X)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1n)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1p)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1r)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1t)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1v)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1x)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1z)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1B)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1D)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1F)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1N)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1P)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1R)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1T)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1V)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5N
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6t
                      p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                      (g_at5L, gpart_at6t) = Genome.Split.split gpart_at6s
                      p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                      (g_at5J, gpart_at6s) = Genome.Split.split gpart_at6r
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at6r) = Genome.Split.split gpart_at6q
                      p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                      (g_at5F, gpart_at6q) = Genome.Split.split gpart_at6p
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6p) = Genome.Split.split gpart_at6o
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6o) = Genome.Split.split gpart_at6n
                      p_at5A = Functions.belowten' g_at5z
                      (g_at5z, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                      (g_at5x, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5w = Functions.belowten' g_at5v
                      (g_at5v, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                      (g_at5t, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                      (g_at5r, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5p
                      (g_at5p, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5o = Functions.belowten' g_at5n
                      (g_at5n, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5m = code-0.1.0.0:Genome.FixedList.Functions.double g_at5l
                      (g_at5l, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5j
                      (g_at5j, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at5i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5h
                      (g_at5h, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at5g = Functions.belowten' g_at5f
                      (g_at5f, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                      (g_at5d, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                      (g_at5b, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                      (g_at59, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at58 = Functions.belowten' g_at57
                      (g_at57, gpart_at69) = Genome.Split.split gpart_at68
                      p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                      (g_at55, gpart_at68) = Genome.Split.split gpart_at67
                      p_at54 = Functions.belowten' g_at53
                      (g_at53, gpart_at67) = Genome.Split.split gpart_at66
                      p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                      (g_at51, gpart_at66) = Genome.Split.split gpart_at65
                      p_at50
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4Z
                      (g_at4Z, gpart_at65) = Genome.Split.split gpart_at64
                      p_at4Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4X
                      (g_at4X, gpart_at64) = Genome.Split.split gpart_at63
                      p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                      (g_at4V, gpart_at63) = Genome.Split.split gpart_at62
                      p_at4U = Functions.belowten' g_at4T
                      (g_at4T, gpart_at62) = Genome.Split.split gpart_at61
                      p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                      (g_at4R, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4Q = Functions.belowten' g_at4P
                      (g_at4P, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                      (g_at4N, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                      (g_at4L, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4K = Functions.belowten' g_at4J
                      (g_at4J, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                      (g_at4H, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at4G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4F
                      (g_at4F, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at4E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4D
                      (g_at4D, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at4C = code-0.1.0.0:Genome.FixedList.Functions.double g_at4B
                      (g_at4B, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at4A = code-0.1.0.0:Genome.FixedList.Functions.double g_at4z
                      (g_at4z, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at4y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4x
                      (g_at4x, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at4w = code-0.1.0.0:Genome.FixedList.Functions.double g_at4v
                      (g_at4v, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                      (g_at4t, gpart_at5P) = Genome.Split.split genome_at5N
                    in
                      [Reaction
                         (\ x_at6u
                            -> let c_MiRs_at6v = ((toVector x_at6u) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4C
                                  / (1
                                     + (((p_at4u / p_at4E) ** p_at4G)
                                        + ((c_MiRs_at6v / p_at4I) ** p_at4K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6w
                            -> let
                                 c_MiRs_at6x = ((toVector x_at6w) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6y = ((toVector x_at6w) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4M
                                  / (1
                                     + (((c_MiRs_at6x / p_at4O) ** p_at4Q)
                                        + ((c_PTB_at6y / p_at4S) ** p_at4U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6z
                            -> let
                                 c_RESTc_at6C = ((toVector x_at6z) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at6A = ((toVector x_at6z) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4W
                                  * ((p_at5a + ((c_NPTB_at6A / p_at52) ** p_at54))
                                     / (((1 + p_at5a) + ((c_NPTB_at6A / p_at52) ** p_at54))
                                        + ((c_RESTc_at6C / p_at56) ** p_at58)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6D
                            -> let
                                 c_MiRs_at6G = ((toVector x_at6D) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6E = ((toVector x_at6D) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5c
                                  * ((p_at5q + ((c_PTB_at6E / p_at5e) ** p_at5g))
                                     / (((1 + p_at5q) + ((c_PTB_at6E / p_at5e) ** p_at5g))
                                        + ((c_MiRs_at6G / p_at5m) ** p_at5o)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6H
                            -> let
                                 c_RESTc_at6K = ((toVector x_at6H) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6I = ((toVector x_at6H) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5s
                                  * ((p_at5C + ((c_MiRs_at6I / p_at5u) ** p_at5w))
                                     / (((1 + p_at5C) + ((c_MiRs_at6I / p_at5u) ** p_at5w))
                                        + ((c_RESTc_at6K / p_at5y) ** p_at5A)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6L
                            -> let c_PTB_at6M = ((toVector x_at6L) Data.Vector.Unboxed.! 0)
                               in (p_at5E * c_PTB_at6M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6N
                            -> let c_NPTB_at6O = ((toVector x_at6N) Data.Vector.Unboxed.! 1)
                               in (p_at5G * c_NPTB_at6O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6P
                            -> let c_MiRs_at6Q = ((toVector x_at6P) Data.Vector.Unboxed.! 2)
                               in (p_at5I * c_MiRs_at6Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6R
                            -> let c_RESTc_at6S = ((toVector x_at6R) Data.Vector.Unboxed.! 3)
                               in (p_at5K * c_RESTc_at6S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6T
                            -> let
                                 c_EndoNeuroTFs_at6U = ((toVector x_at6T) Data.Vector.Unboxed.! 4)
                               in (p_at5M * c_EndoNeuroTFs_at6U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121556",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121558",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121576",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121578",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121596",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121598",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121600",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5N
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7z
                            p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                            (g_at5L, gpart_at7z) = Genome.Split.split gpart_at7y
                            p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                            (g_at5J, gpart_at7y) = Genome.Split.split gpart_at7x
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at7x) = Genome.Split.split gpart_at7w
                            p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                            (g_at5F, gpart_at7w) = Genome.Split.split gpart_at7v
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at7v) = Genome.Split.split gpart_at7u
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at7u) = Genome.Split.split gpart_at7t
                            p_at5A = Functions.belowten' g_at5z
                            (g_at5z, gpart_at7t) = Genome.Split.split gpart_at7s
                            p_at5y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5x
                            (g_at5x, gpart_at7s) = Genome.Split.split gpart_at7r
                            p_at5w = Functions.belowten' g_at5v
                            (g_at5v, gpart_at7r) = Genome.Split.split gpart_at7q
                            p_at5u = code-0.1.0.0:Genome.FixedList.Functions.double g_at5t
                            (g_at5t, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                            (g_at5r, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at5q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5p
                            (g_at5p, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5o = Functions.belowten' g_at5n
                            (g_at5n, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5m = code-0.1.0.0:Genome.FixedList.Functions.double g_at5l
                            (g_at5l, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5j
                            (g_at5j, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5h
                            (g_at5h, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at5g = Functions.belowten' g_at5f
                            (g_at5f, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at5e = code-0.1.0.0:Genome.FixedList.Functions.double g_at5d
                            (g_at5d, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                            (g_at5b, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at5a = code-0.1.0.0:Genome.FixedList.Functions.double g_at59
                            (g_at59, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at58 = Functions.belowten' g_at57
                            (g_at57, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                            (g_at55, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at54 = Functions.belowten' g_at53
                            (g_at53, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                            (g_at51, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at50
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4Z
                            (g_at4Z, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at4Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4X
                            (g_at4X, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                            (g_at4V, gpart_at79) = Genome.Split.split gpart_at78
                            p_at4U = Functions.belowten' g_at4T
                            (g_at4T, gpart_at78) = Genome.Split.split gpart_at77
                            p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                            (g_at4R, gpart_at77) = Genome.Split.split gpart_at76
                            p_at4Q = Functions.belowten' g_at4P
                            (g_at4P, gpart_at76) = Genome.Split.split gpart_at75
                            p_at4O = code-0.1.0.0:Genome.FixedList.Functions.double g_at4N
                            (g_at4N, gpart_at75) = Genome.Split.split gpart_at74
                            p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                            (g_at4L, gpart_at74) = Genome.Split.split gpart_at73
                            p_at4K = Functions.belowten' g_at4J
                            (g_at4J, gpart_at73) = Genome.Split.split gpart_at72
                            p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                            (g_at4H, gpart_at72) = Genome.Split.split gpart_at71
                            p_at4G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4F
                            (g_at4F, gpart_at71) = Genome.Split.split gpart_at70
                            p_at4E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4D
                            (g_at4D, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at4C = code-0.1.0.0:Genome.FixedList.Functions.double g_at4B
                            (g_at4B, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at4A = code-0.1.0.0:Genome.FixedList.Functions.double g_at4z
                            (g_at4z, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at4y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4x
                            (g_at4x, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at4w = code-0.1.0.0:Genome.FixedList.Functions.double g_at4v
                            (g_at4v, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4u = code-0.1.0.0:Genome.FixedList.Functions.double g_at4t
                            (g_at4t, gpart_at6V) = Genome.Split.split genome_at5N
                          in
                            \ desc_at5O
                              -> case desc_at5O of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4u)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4w)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4y)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4A)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4C)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4E)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4G)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4I)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4K)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4M)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4O)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Q)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4S)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4U)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4W)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Y)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at50)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at52)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at54)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at56)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at58)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5a)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5c)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5e)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5g)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5i)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5k)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5m)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5o)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5q)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5s)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5u)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5w)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5y)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   _ -> Nothing }}
