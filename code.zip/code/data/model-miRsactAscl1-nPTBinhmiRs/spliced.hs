src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24OL
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Pr
                      p_a24OK = double g_a24OJ
                      (g_a24OJ, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24OI = double g_a24OH
                      (g_a24OH, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24OG = double g_a24OF
                      (g_a24OF, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24OE = double g_a24OD
                      (g_a24OD, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24OC = double g_a24OB
                      (g_a24OB, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24OA = double g_a24Oz
                      (g_a24Oz, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24Oy = Functions.belowten' g_a24Ox
                      (g_a24Ox, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24Ow = double g_a24Ov
                      (g_a24Ov, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24Ou = Functions.belowten' g_a24Ot
                      (g_a24Ot, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24Os = double g_a24Or
                      (g_a24Or, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24Oq = double g_a24Op
                      (g_a24Op, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24Oo = double g_a24On
                      (g_a24On, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24Om = Functions.belowten' g_a24Ol
                      (g_a24Ol, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24Ok = double g_a24Oj
                      (g_a24Oj, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24Oi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oh
                      (g_a24Oh, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24Og
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                      (g_a24Of, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24Oe = Functions.belowten' g_a24Od
                      (g_a24Od, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24Oc = double g_a24Ob
                      (g_a24Ob, gpart_a24Pa) = Genome.Split.split gpart_a24P9
                      p_a24Oa = double g_a24O9
                      (g_a24O9, gpart_a24P9) = Genome.Split.split gpart_a24P8
                      p_a24O8 = double g_a24O7
                      (g_a24O7, gpart_a24P8) = Genome.Split.split gpart_a24P7
                      p_a24O6 = Functions.belowten' g_a24O5
                      (g_a24O5, gpart_a24P7) = Genome.Split.split gpart_a24P6
                      p_a24O4 = double g_a24O3
                      (g_a24O3, gpart_a24P6) = Genome.Split.split gpart_a24P5
                      p_a24O2 = Functions.belowten' g_a24O1
                      (g_a24O1, gpart_a24P5) = Genome.Split.split gpart_a24P4
                      p_a24O0 = double g_a24NZ
                      (g_a24NZ, gpart_a24P4) = Genome.Split.split gpart_a24P3
                      p_a24NY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NX
                      (g_a24NX, gpart_a24P3) = Genome.Split.split gpart_a24P2
                      p_a24NW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NV
                      (g_a24NV, gpart_a24P2) = Genome.Split.split gpart_a24P1
                      p_a24NU = double g_a24NT
                      (g_a24NT, gpart_a24P1) = Genome.Split.split gpart_a24P0
                      p_a24NS = Functions.belowten' g_a24NR
                      (g_a24NR, gpart_a24P0) = Genome.Split.split gpart_a24OZ
                      p_a24NQ = double g_a24NP
                      (g_a24NP, gpart_a24OZ) = Genome.Split.split gpart_a24OY
                      p_a24NO = Functions.belowten' g_a24NN
                      (g_a24NN, gpart_a24OY) = Genome.Split.split gpart_a24OX
                      p_a24NM = double g_a24NL
                      (g_a24NL, gpart_a24OX) = Genome.Split.split gpart_a24OW
                      p_a24NK = double g_a24NJ
                      (g_a24NJ, gpart_a24OW) = Genome.Split.split gpart_a24OV
                      p_a24NI = Functions.belowten' g_a24NH
                      (g_a24NH, gpart_a24OV) = Genome.Split.split gpart_a24OU
                      p_a24NG = double g_a24NF
                      (g_a24NF, gpart_a24OU) = Genome.Split.split gpart_a24OT
                      p_a24NE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ND
                      (g_a24ND, gpart_a24OT) = Genome.Split.split gpart_a24OS
                      p_a24NC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NB
                      (g_a24NB, gpart_a24OS) = Genome.Split.split gpart_a24OR
                      p_a24NA = double g_a24Nz
                      (g_a24Nz, gpart_a24OR) = Genome.Split.split gpart_a24OQ
                      p_a24Ny = double g_a24Nx
                      (g_a24Nx, gpart_a24OQ) = Genome.Split.split gpart_a24OP
                      p_a24Nw = double g_a24Nv
                      (g_a24Nv, gpart_a24OP) = Genome.Split.split gpart_a24OO
                      p_a24Nu = double g_a24Nt
                      (g_a24Nt, gpart_a24OO) = Genome.Split.split gpart_a24ON
                      p_a24Ns = double g_a24Nr
                      (g_a24Nr, gpart_a24ON) = Genome.Split.split genome_a24OL
                    in  \ x_a24Ps
                          -> let
                               c_PTB_a24Pv
                                 = ((Data.Fixed.Vector.toVector x_a24Ps) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Pt
                                 = ((Data.Fixed.Vector.toVector x_a24Ps) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Pz
                                 = ((Data.Fixed.Vector.toVector x_a24Ps) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24PB
                                 = ((Data.Fixed.Vector.toVector x_a24Ps) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24PN
                                 = ((Data.Fixed.Vector.toVector x_a24Ps) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NA / (1 + ((c_MiRs_a24Pt / p_a24NG) ** p_a24NI)))
                                    + (negate (p_a24OC * c_PTB_a24Pv))),
                                   ((p_a24NK
                                     / (1
                                        + (((c_MiRs_a24Pt / p_a24NM) ** p_a24NO)
                                           + ((c_PTB_a24Pv / p_a24NQ) ** p_a24NS))))
                                    + (negate (p_a24OE * c_NPTB_a24Pz))),
                                   ((p_a24NU
                                     * ((p_a24O8 + ((p_a24Nw / p_a24NW) ** p_a24NY))
                                        / (((1 + p_a24O8) + ((p_a24Nw / p_a24NW) ** p_a24NY))
                                           + (((c_NPTB_a24Pz / p_a24O0) ** p_a24O2)
                                              + ((c_RESTc_a24PB / p_a24O4) ** p_a24O6)))))
                                    + (negate (p_a24OG * c_MiRs_a24Pt))),
                                   ((p_a24Oa
                                     * ((p_a24Oo + ((c_PTB_a24Pv / p_a24Oc) ** p_a24Oe))
                                        / (((1 + p_a24Oo) + ((c_PTB_a24Pv / p_a24Oc) ** p_a24Oe))
                                           + (((p_a24Ns / p_a24Og) ** p_a24Oi)
                                              + ((c_MiRs_a24Pt / p_a24Ok) ** p_a24Om)))))
                                    + (negate (p_a24OI * c_RESTc_a24PB))),
                                   ((p_a24Oq
                                     * ((p_a24OA + ((c_MiRs_a24Pt / p_a24Os) ** p_a24Ou))
                                        / (((1 + p_a24OA) + ((c_MiRs_a24Pt / p_a24Os) ** p_a24Ou))
                                           + ((c_RESTc_a24PB / p_a24Ow) ** p_a24Oy))))
                                    + (negate (p_a24OK * c_EndoNeuroTFs_a24PN)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504900",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504902",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504922",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504942",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24OL
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Qs
                            p_a24OK = double g_a24OJ
                            (g_a24OJ, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24OI = double g_a24OH
                            (g_a24OH, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24OG = double g_a24OF
                            (g_a24OF, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24OE = double g_a24OD
                            (g_a24OD, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24OC = double g_a24OB
                            (g_a24OB, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24OA = double g_a24Oz
                            (g_a24Oz, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24Oy = Functions.belowten' g_a24Ox
                            (g_a24Ox, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24Ow = double g_a24Ov
                            (g_a24Ov, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24Ou = Functions.belowten' g_a24Ot
                            (g_a24Ot, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24Os = double g_a24Or
                            (g_a24Or, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24Oq = double g_a24Op
                            (g_a24Op, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24Oo = double g_a24On
                            (g_a24On, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24Om = Functions.belowten' g_a24Ol
                            (g_a24Ol, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24Ok = double g_a24Oj
                            (g_a24Oj, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24Oi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oh
                            (g_a24Oh, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24Og
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                            (g_a24Of, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24Oe = Functions.belowten' g_a24Od
                            (g_a24Od, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                            p_a24Oc = double g_a24Ob
                            (g_a24Ob, gpart_a24Qb) = Genome.Split.split gpart_a24Qa
                            p_a24Oa = double g_a24O9
                            (g_a24O9, gpart_a24Qa) = Genome.Split.split gpart_a24Q9
                            p_a24O8 = double g_a24O7
                            (g_a24O7, gpart_a24Q9) = Genome.Split.split gpart_a24Q8
                            p_a24O6 = Functions.belowten' g_a24O5
                            (g_a24O5, gpart_a24Q8) = Genome.Split.split gpart_a24Q7
                            p_a24O4 = double g_a24O3
                            (g_a24O3, gpart_a24Q7) = Genome.Split.split gpart_a24Q6
                            p_a24O2 = Functions.belowten' g_a24O1
                            (g_a24O1, gpart_a24Q6) = Genome.Split.split gpart_a24Q5
                            p_a24O0 = double g_a24NZ
                            (g_a24NZ, gpart_a24Q5) = Genome.Split.split gpart_a24Q4
                            p_a24NY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NX
                            (g_a24NX, gpart_a24Q4) = Genome.Split.split gpart_a24Q3
                            p_a24NW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NV
                            (g_a24NV, gpart_a24Q3) = Genome.Split.split gpart_a24Q2
                            p_a24NU = double g_a24NT
                            (g_a24NT, gpart_a24Q2) = Genome.Split.split gpart_a24Q1
                            p_a24NS = Functions.belowten' g_a24NR
                            (g_a24NR, gpart_a24Q1) = Genome.Split.split gpart_a24Q0
                            p_a24NQ = double g_a24NP
                            (g_a24NP, gpart_a24Q0) = Genome.Split.split gpart_a24PZ
                            p_a24NO = Functions.belowten' g_a24NN
                            (g_a24NN, gpart_a24PZ) = Genome.Split.split gpart_a24PY
                            p_a24NM = double g_a24NL
                            (g_a24NL, gpart_a24PY) = Genome.Split.split gpart_a24PX
                            p_a24NK = double g_a24NJ
                            (g_a24NJ, gpart_a24PX) = Genome.Split.split gpart_a24PW
                            p_a24NI = Functions.belowten' g_a24NH
                            (g_a24NH, gpart_a24PW) = Genome.Split.split gpart_a24PV
                            p_a24NG = double g_a24NF
                            (g_a24NF, gpart_a24PV) = Genome.Split.split gpart_a24PU
                            p_a24NE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ND
                            (g_a24ND, gpart_a24PU) = Genome.Split.split gpart_a24PT
                            p_a24NC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NB
                            (g_a24NB, gpart_a24PT) = Genome.Split.split gpart_a24PS
                            p_a24NA = double g_a24Nz
                            (g_a24Nz, gpart_a24PS) = Genome.Split.split gpart_a24PR
                            p_a24Ny = double g_a24Nx
                            (g_a24Nx, gpart_a24PR) = Genome.Split.split gpart_a24PQ
                            p_a24Nw = double g_a24Nv
                            (g_a24Nv, gpart_a24PQ) = Genome.Split.split gpart_a24PP
                            p_a24Nu = double g_a24Nt
                            (g_a24Nt, gpart_a24PP) = Genome.Split.split gpart_a24PO
                            p_a24Ns = double g_a24Nr
                            (g_a24Nr, gpart_a24PO) = Genome.Split.split genome_a24OL
                          in
                            \ desc_a24OM
                              -> case desc_a24OM of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ns)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nu)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Nw)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ny)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NA)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NC)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NE)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NG)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NI)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NK)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NM)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NO)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NQ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NS)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NU)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NW)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NY)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O0)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O2)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O4)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O6)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O8)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oa)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oc)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oe)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Og)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oi)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ok)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Om)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oo)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oq)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Os)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ou)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ow)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oy)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OA)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OC)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OE)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OG)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OI)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OK)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24SW
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24TC
                      p_a24SV = double g_a24SU
                      (g_a24SU, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24ST = double g_a24SS
                      (g_a24SS, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24SR = double g_a24SQ
                      (g_a24SQ, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24SP = double g_a24SO
                      (g_a24SO, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24SN = double g_a24SM
                      (g_a24SM, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24SL = double g_a24SK
                      (g_a24SK, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24SJ = Functions.belowten' g_a24SI
                      (g_a24SI, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24SH = double g_a24SG
                      (g_a24SG, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24SF = Functions.belowten' g_a24SE
                      (g_a24SE, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24SD = double g_a24SC
                      (g_a24SC, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24SB = double g_a24SA
                      (g_a24SA, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24Sz = double g_a24Sy
                      (g_a24Sy, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24Sx = Functions.belowten' g_a24Sw
                      (g_a24Sw, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24Sv = double g_a24Su
                      (g_a24Su, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24St
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ss
                      (g_a24Ss, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24Sr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sq
                      (g_a24Sq, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24Sp = Functions.belowten' g_a24So
                      (g_a24So, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24Sn = double g_a24Sm
                      (g_a24Sm, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24Sl = double g_a24Sk
                      (g_a24Sk, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24Sj = double g_a24Si
                      (g_a24Si, gpart_a24Tj) = Genome.Split.split gpart_a24Ti
                      p_a24Sh = Functions.belowten' g_a24Sg
                      (g_a24Sg, gpart_a24Ti) = Genome.Split.split gpart_a24Th
                      p_a24Sf = double g_a24Se
                      (g_a24Se, gpart_a24Th) = Genome.Split.split gpart_a24Tg
                      p_a24Sd = Functions.belowten' g_a24Sc
                      (g_a24Sc, gpart_a24Tg) = Genome.Split.split gpart_a24Tf
                      p_a24Sb = double g_a24Sa
                      (g_a24Sa, gpart_a24Tf) = Genome.Split.split gpart_a24Te
                      p_a24S9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S8
                      (g_a24S8, gpart_a24Te) = Genome.Split.split gpart_a24Td
                      p_a24S7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S6
                      (g_a24S6, gpart_a24Td) = Genome.Split.split gpart_a24Tc
                      p_a24S5 = double g_a24S4
                      (g_a24S4, gpart_a24Tc) = Genome.Split.split gpart_a24Tb
                      p_a24S3 = Functions.belowten' g_a24S2
                      (g_a24S2, gpart_a24Tb) = Genome.Split.split gpart_a24Ta
                      p_a24S1 = double g_a24S0
                      (g_a24S0, gpart_a24Ta) = Genome.Split.split gpart_a24T9
                      p_a24RZ = Functions.belowten' g_a24RY
                      (g_a24RY, gpart_a24T9) = Genome.Split.split gpart_a24T8
                      p_a24RX = double g_a24RW
                      (g_a24RW, gpart_a24T8) = Genome.Split.split gpart_a24T7
                      p_a24RV = double g_a24RU
                      (g_a24RU, gpart_a24T7) = Genome.Split.split gpart_a24T6
                      p_a24RT = Functions.belowten' g_a24RS
                      (g_a24RS, gpart_a24T6) = Genome.Split.split gpart_a24T5
                      p_a24RR = double g_a24RQ
                      (g_a24RQ, gpart_a24T5) = Genome.Split.split gpart_a24T4
                      p_a24RP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RO
                      (g_a24RO, gpart_a24T4) = Genome.Split.split gpart_a24T3
                      p_a24RN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RM
                      (g_a24RM, gpart_a24T3) = Genome.Split.split gpart_a24T2
                      p_a24RL = double g_a24RK
                      (g_a24RK, gpart_a24T2) = Genome.Split.split gpart_a24T1
                      p_a24RJ = double g_a24RI
                      (g_a24RI, gpart_a24T1) = Genome.Split.split gpart_a24T0
                      p_a24RH = double g_a24RG
                      (g_a24RG, gpart_a24T0) = Genome.Split.split gpart_a24SZ
                      p_a24RF = double g_a24RE
                      (g_a24RE, gpart_a24SZ) = Genome.Split.split gpart_a24SY
                      p_a24RD = double g_a24RC
                      (g_a24RC, gpart_a24SY) = Genome.Split.split genome_a24SW
                    in  \ x_a24TD
                          -> let
                               c_PTB_a24TG
                                 = ((Data.Fixed.Vector.toVector x_a24TD) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TE
                                 = ((Data.Fixed.Vector.toVector x_a24TD) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24TK
                                 = ((Data.Fixed.Vector.toVector x_a24TD) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24TM
                                 = ((Data.Fixed.Vector.toVector x_a24TD) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24TY
                                 = ((Data.Fixed.Vector.toVector x_a24TD) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24RL / (1 + ((c_MiRs_a24TE / p_a24RR) ** p_a24RT)))
                                    + (negate (p_a24SN * c_PTB_a24TG))),
                                   ((p_a24RV
                                     / (1
                                        + (((c_MiRs_a24TE / p_a24RX) ** p_a24RZ)
                                           + ((c_PTB_a24TG / p_a24S1) ** p_a24S3))))
                                    + (negate (p_a24SP * c_NPTB_a24TK))),
                                   ((p_a24S5
                                     * (p_a24Sj
                                        / ((1 + p_a24Sj)
                                           + (((c_NPTB_a24TK / p_a24Sb) ** p_a24Sd)
                                              + ((c_RESTc_a24TM / p_a24Sf) ** p_a24Sh)))))
                                    + (negate (p_a24SR * c_MiRs_a24TE))),
                                   ((p_a24Sl
                                     * ((p_a24Sz + ((c_PTB_a24TG / p_a24Sn) ** p_a24Sp))
                                        / (((1 + p_a24Sz) + ((c_PTB_a24TG / p_a24Sn) ** p_a24Sp))
                                           + (((p_a24RD / p_a24Sr) ** p_a24St)
                                              + ((c_MiRs_a24TE / p_a24Sv) ** p_a24Sx)))))
                                    + (negate (p_a24ST * c_RESTc_a24TM))),
                                   ((p_a24SB
                                     * ((p_a24SL + ((c_MiRs_a24TE / p_a24SD) ** p_a24SF))
                                        / (((1 + p_a24SL) + ((c_MiRs_a24TE / p_a24SD) ** p_a24SF))
                                           + ((c_RESTc_a24TM / p_a24SH) ** p_a24SJ))))
                                    + (negate (p_a24SV * c_EndoNeuroTFs_a24TY)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505161",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505179",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505181",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505201",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24SW
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UD
                            p_a24SV = double g_a24SU
                            (g_a24SU, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24ST = double g_a24SS
                            (g_a24SS, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24SR = double g_a24SQ
                            (g_a24SQ, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24SP = double g_a24SO
                            (g_a24SO, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24SN = double g_a24SM
                            (g_a24SM, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24SL = double g_a24SK
                            (g_a24SK, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24SJ = Functions.belowten' g_a24SI
                            (g_a24SI, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24SH = double g_a24SG
                            (g_a24SG, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24SF = Functions.belowten' g_a24SE
                            (g_a24SE, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24SD = double g_a24SC
                            (g_a24SC, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24SB = double g_a24SA
                            (g_a24SA, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24Sz = double g_a24Sy
                            (g_a24Sy, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24Sx = Functions.belowten' g_a24Sw
                            (g_a24Sw, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24Sv = double g_a24Su
                            (g_a24Su, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24St
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ss
                            (g_a24Ss, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24Sr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sq
                            (g_a24Sq, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24Sp = Functions.belowten' g_a24So
                            (g_a24So, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24Sn = double g_a24Sm
                            (g_a24Sm, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24Sl = double g_a24Sk
                            (g_a24Sk, gpart_a24Ul) = Genome.Split.split gpart_a24Uk
                            p_a24Sj = double g_a24Si
                            (g_a24Si, gpart_a24Uk) = Genome.Split.split gpart_a24Uj
                            p_a24Sh = Functions.belowten' g_a24Sg
                            (g_a24Sg, gpart_a24Uj) = Genome.Split.split gpart_a24Ui
                            p_a24Sf = double g_a24Se
                            (g_a24Se, gpart_a24Ui) = Genome.Split.split gpart_a24Uh
                            p_a24Sd = Functions.belowten' g_a24Sc
                            (g_a24Sc, gpart_a24Uh) = Genome.Split.split gpart_a24Ug
                            p_a24Sb = double g_a24Sa
                            (g_a24Sa, gpart_a24Ug) = Genome.Split.split gpart_a24Uf
                            p_a24S9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S8
                            (g_a24S8, gpart_a24Uf) = Genome.Split.split gpart_a24Ue
                            p_a24S7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S6
                            (g_a24S6, gpart_a24Ue) = Genome.Split.split gpart_a24Ud
                            p_a24S5 = double g_a24S4
                            (g_a24S4, gpart_a24Ud) = Genome.Split.split gpart_a24Uc
                            p_a24S3 = Functions.belowten' g_a24S2
                            (g_a24S2, gpart_a24Uc) = Genome.Split.split gpart_a24Ub
                            p_a24S1 = double g_a24S0
                            (g_a24S0, gpart_a24Ub) = Genome.Split.split gpart_a24Ua
                            p_a24RZ = Functions.belowten' g_a24RY
                            (g_a24RY, gpart_a24Ua) = Genome.Split.split gpart_a24U9
                            p_a24RX = double g_a24RW
                            (g_a24RW, gpart_a24U9) = Genome.Split.split gpart_a24U8
                            p_a24RV = double g_a24RU
                            (g_a24RU, gpart_a24U8) = Genome.Split.split gpart_a24U7
                            p_a24RT = Functions.belowten' g_a24RS
                            (g_a24RS, gpart_a24U7) = Genome.Split.split gpart_a24U6
                            p_a24RR = double g_a24RQ
                            (g_a24RQ, gpart_a24U6) = Genome.Split.split gpart_a24U5
                            p_a24RP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RO
                            (g_a24RO, gpart_a24U5) = Genome.Split.split gpart_a24U4
                            p_a24RN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RM
                            (g_a24RM, gpart_a24U4) = Genome.Split.split gpart_a24U3
                            p_a24RL = double g_a24RK
                            (g_a24RK, gpart_a24U3) = Genome.Split.split gpart_a24U2
                            p_a24RJ = double g_a24RI
                            (g_a24RI, gpart_a24U2) = Genome.Split.split gpart_a24U1
                            p_a24RH = double g_a24RG
                            (g_a24RG, gpart_a24U1) = Genome.Split.split gpart_a24U0
                            p_a24RF = double g_a24RE
                            (g_a24RE, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                            p_a24RD = double g_a24RC
                            (g_a24RC, gpart_a24TZ) = Genome.Split.split genome_a24SW
                          in
                            \ desc_a24SX
                              -> case desc_a24SX of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RD)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RF)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RH)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RJ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RL)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RN)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RP)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RR)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RT)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RV)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RX)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RZ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S1)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S3)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S5)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S7)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S9)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sb)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sd)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sf)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sh)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sj)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sl)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sn)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sp)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sr)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24St)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sv)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sx)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sz)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SB)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SD)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SF)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SH)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SJ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SL)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SN)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SP)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SR)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ST)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SV)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24X7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24XN
                      p_a24X6 = double g_a24X5
                      (g_a24X5, gpart_a24XN) = Genome.Split.split gpart_a24XM
                      p_a24X4 = double g_a24X3
                      (g_a24X3, gpart_a24XM) = Genome.Split.split gpart_a24XL
                      p_a24X2 = double g_a24X1
                      (g_a24X1, gpart_a24XL) = Genome.Split.split gpart_a24XK
                      p_a24X0 = double g_a24WZ
                      (g_a24WZ, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                      p_a24WY = double g_a24WX
                      (g_a24WX, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24WW = double g_a24WV
                      (g_a24WV, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24WU = Functions.belowten' g_a24WT
                      (g_a24WT, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24WS = double g_a24WR
                      (g_a24WR, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24WQ = Functions.belowten' g_a24WP
                      (g_a24WP, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24WO = double g_a24WN
                      (g_a24WN, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24WM = double g_a24WL
                      (g_a24WL, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24WK = double g_a24WJ
                      (g_a24WJ, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24WI = Functions.belowten' g_a24WH
                      (g_a24WH, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24WG = double g_a24WF
                      (g_a24WF, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24WE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                      (g_a24WD, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24WC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                      (g_a24WB, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24WA = Functions.belowten' g_a24Wz
                      (g_a24Wz, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24Wy = double g_a24Wx
                      (g_a24Wx, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24Ww = double g_a24Wv
                      (g_a24Wv, gpart_a24Xv) = Genome.Split.split gpart_a24Xu
                      p_a24Wu = double g_a24Wt
                      (g_a24Wt, gpart_a24Xu) = Genome.Split.split gpart_a24Xt
                      p_a24Ws = Functions.belowten' g_a24Wr
                      (g_a24Wr, gpart_a24Xt) = Genome.Split.split gpart_a24Xs
                      p_a24Wq = double g_a24Wp
                      (g_a24Wp, gpart_a24Xs) = Genome.Split.split gpart_a24Xr
                      p_a24Wo = Functions.belowten' g_a24Wn
                      (g_a24Wn, gpart_a24Xr) = Genome.Split.split gpart_a24Xq
                      p_a24Wm = double g_a24Wl
                      (g_a24Wl, gpart_a24Xq) = Genome.Split.split gpart_a24Xp
                      p_a24Wk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                      (g_a24Wj, gpart_a24Xp) = Genome.Split.split gpart_a24Xo
                      p_a24Wi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                      (g_a24Wh, gpart_a24Xo) = Genome.Split.split gpart_a24Xn
                      p_a24Wg = double g_a24Wf
                      (g_a24Wf, gpart_a24Xn) = Genome.Split.split gpart_a24Xm
                      p_a24We = Functions.belowten' g_a24Wd
                      (g_a24Wd, gpart_a24Xm) = Genome.Split.split gpart_a24Xl
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24Xl) = Genome.Split.split gpart_a24Xk
                      p_a24Wa = Functions.belowten' g_a24W9
                      (g_a24W9, gpart_a24Xk) = Genome.Split.split gpart_a24Xj
                      p_a24W8 = double g_a24W7
                      (g_a24W7, gpart_a24Xj) = Genome.Split.split gpart_a24Xi
                      p_a24W6 = double g_a24W5
                      (g_a24W5, gpart_a24Xi) = Genome.Split.split gpart_a24Xh
                      p_a24W4 = Functions.belowten' g_a24W3
                      (g_a24W3, gpart_a24Xh) = Genome.Split.split gpart_a24Xg
                      p_a24W2 = double g_a24W1
                      (g_a24W1, gpart_a24Xg) = Genome.Split.split gpart_a24Xf
                      p_a24W0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VZ
                      (g_a24VZ, gpart_a24Xf) = Genome.Split.split gpart_a24Xe
                      p_a24VY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VX
                      (g_a24VX, gpart_a24Xe) = Genome.Split.split gpart_a24Xd
                      p_a24VW = double g_a24VV
                      (g_a24VV, gpart_a24Xd) = Genome.Split.split gpart_a24Xc
                      p_a24VU = double g_a24VT
                      (g_a24VT, gpart_a24Xc) = Genome.Split.split gpart_a24Xb
                      p_a24VS = double g_a24VR
                      (g_a24VR, gpart_a24Xb) = Genome.Split.split gpart_a24Xa
                      p_a24VQ = double g_a24VP
                      (g_a24VP, gpart_a24Xa) = Genome.Split.split gpart_a24X9
                      p_a24VO = double g_a24VN
                      (g_a24VN, gpart_a24X9) = Genome.Split.split genome_a24X7
                    in  \ x_a24XO
                          -> let
                               c_PTB_a24XR
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24XP
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24XV
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24XX
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Y9
                                 = ((Data.Fixed.Vector.toVector x_a24XO) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24VW / (1 + ((c_MiRs_a24XP / p_a24W2) ** p_a24W4)))
                                    + (negate (p_a24WY * c_PTB_a24XR))),
                                   ((p_a24W6
                                     / (1
                                        + (((c_MiRs_a24XP / p_a24W8) ** p_a24Wa)
                                           + ((c_PTB_a24XR / p_a24Wc) ** p_a24We))))
                                    + (negate (p_a24X0 * c_NPTB_a24XV))),
                                   ((p_a24Wg
                                     * (p_a24Wu
                                        / ((1 + p_a24Wu)
                                           + (((c_NPTB_a24XV / p_a24Wm) ** p_a24Wo)
                                              + ((c_RESTc_a24XX / p_a24Wq) ** p_a24Ws)))))
                                    + (negate (p_a24X2 * c_MiRs_a24XP))),
                                   ((p_a24Ww
                                     * ((p_a24WK + ((c_PTB_a24XR / p_a24Wy) ** p_a24WA))
                                        / (((1 + p_a24WK) + ((c_PTB_a24XR / p_a24Wy) ** p_a24WA))
                                           + ((c_MiRs_a24XP / p_a24WG) ** p_a24WI))))
                                    + (negate (p_a24X4 * c_RESTc_a24XX))),
                                   ((p_a24WM
                                     * ((p_a24WW + ((c_MiRs_a24XP / p_a24WO) ** p_a24WQ))
                                        / (((1 + p_a24WW) + ((c_MiRs_a24XP / p_a24WO) ** p_a24WQ))
                                           + ((c_RESTc_a24XX / p_a24WS) ** p_a24WU))))
                                    + (negate (p_a24X6 * c_EndoNeuroTFs_a24Y9)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505418",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505420",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505460",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24X7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24YO
                            p_a24X6 = double g_a24X5
                            (g_a24X5, gpart_a24YO) = Genome.Split.split gpart_a24YN
                            p_a24X4 = double g_a24X3
                            (g_a24X3, gpart_a24YN) = Genome.Split.split gpart_a24YM
                            p_a24X2 = double g_a24X1
                            (g_a24X1, gpart_a24YM) = Genome.Split.split gpart_a24YL
                            p_a24X0 = double g_a24WZ
                            (g_a24WZ, gpart_a24YL) = Genome.Split.split gpart_a24YK
                            p_a24WY = double g_a24WX
                            (g_a24WX, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24WW = double g_a24WV
                            (g_a24WV, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24WU = Functions.belowten' g_a24WT
                            (g_a24WT, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24WS = double g_a24WR
                            (g_a24WR, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24WQ = Functions.belowten' g_a24WP
                            (g_a24WP, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24WO = double g_a24WN
                            (g_a24WN, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24WM = double g_a24WL
                            (g_a24WL, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24WK = double g_a24WJ
                            (g_a24WJ, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24WI = Functions.belowten' g_a24WH
                            (g_a24WH, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24WG = double g_a24WF
                            (g_a24WF, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24WE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                            (g_a24WD, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24WC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WB
                            (g_a24WB, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24WA = Functions.belowten' g_a24Wz
                            (g_a24Wz, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24Wy = double g_a24Wx
                            (g_a24Wx, gpart_a24Yx) = Genome.Split.split gpart_a24Yw
                            p_a24Ww = double g_a24Wv
                            (g_a24Wv, gpart_a24Yw) = Genome.Split.split gpart_a24Yv
                            p_a24Wu = double g_a24Wt
                            (g_a24Wt, gpart_a24Yv) = Genome.Split.split gpart_a24Yu
                            p_a24Ws = Functions.belowten' g_a24Wr
                            (g_a24Wr, gpart_a24Yu) = Genome.Split.split gpart_a24Yt
                            p_a24Wq = double g_a24Wp
                            (g_a24Wp, gpart_a24Yt) = Genome.Split.split gpart_a24Ys
                            p_a24Wo = Functions.belowten' g_a24Wn
                            (g_a24Wn, gpart_a24Ys) = Genome.Split.split gpart_a24Yr
                            p_a24Wm = double g_a24Wl
                            (g_a24Wl, gpart_a24Yr) = Genome.Split.split gpart_a24Yq
                            p_a24Wk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                            (g_a24Wj, gpart_a24Yq) = Genome.Split.split gpart_a24Yp
                            p_a24Wi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wh
                            (g_a24Wh, gpart_a24Yp) = Genome.Split.split gpart_a24Yo
                            p_a24Wg = double g_a24Wf
                            (g_a24Wf, gpart_a24Yo) = Genome.Split.split gpart_a24Yn
                            p_a24We = Functions.belowten' g_a24Wd
                            (g_a24Wd, gpart_a24Yn) = Genome.Split.split gpart_a24Ym
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Ym) = Genome.Split.split gpart_a24Yl
                            p_a24Wa = Functions.belowten' g_a24W9
                            (g_a24W9, gpart_a24Yl) = Genome.Split.split gpart_a24Yk
                            p_a24W8 = double g_a24W7
                            (g_a24W7, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                            p_a24W6 = double g_a24W5
                            (g_a24W5, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                            p_a24W4 = Functions.belowten' g_a24W3
                            (g_a24W3, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                            p_a24W2 = double g_a24W1
                            (g_a24W1, gpart_a24Yh) = Genome.Split.split gpart_a24Yg
                            p_a24W0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VZ
                            (g_a24VZ, gpart_a24Yg) = Genome.Split.split gpart_a24Yf
                            p_a24VY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VX
                            (g_a24VX, gpart_a24Yf) = Genome.Split.split gpart_a24Ye
                            p_a24VW = double g_a24VV
                            (g_a24VV, gpart_a24Ye) = Genome.Split.split gpart_a24Yd
                            p_a24VU = double g_a24VT
                            (g_a24VT, gpart_a24Yd) = Genome.Split.split gpart_a24Yc
                            p_a24VS = double g_a24VR
                            (g_a24VR, gpart_a24Yc) = Genome.Split.split gpart_a24Yb
                            p_a24VQ = double g_a24VP
                            (g_a24VP, gpart_a24Yb) = Genome.Split.split gpart_a24Ya
                            p_a24VO = double g_a24VN
                            (g_a24VN, gpart_a24Ya) = Genome.Split.split genome_a24X7
                          in
                            \ desc_a24X8
                              -> case desc_a24X8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VW)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VY)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W0)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W2)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W4)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WM)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WO)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WU)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X6)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a251i
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a251Y
                      p_a251h = double g_a251g
                      (g_a251g, gpart_a251Y) = Genome.Split.split gpart_a251X
                      p_a251f = double g_a251e
                      (g_a251e, gpart_a251X) = Genome.Split.split gpart_a251W
                      p_a251d = double g_a251c
                      (g_a251c, gpart_a251W) = Genome.Split.split gpart_a251V
                      p_a251b = double g_a251a
                      (g_a251a, gpart_a251V) = Genome.Split.split gpart_a251U
                      p_a2519 = double g_a2518
                      (g_a2518, gpart_a251U) = Genome.Split.split gpart_a251T
                      p_a2517 = double g_a2516
                      (g_a2516, gpart_a251T) = Genome.Split.split gpart_a251S
                      p_a2515 = Functions.belowten' g_a2514
                      (g_a2514, gpart_a251S) = Genome.Split.split gpart_a251R
                      p_a2513 = double g_a2512
                      (g_a2512, gpart_a251R) = Genome.Split.split gpart_a251Q
                      p_a2511 = Functions.belowten' g_a2510
                      (g_a2510, gpart_a251Q) = Genome.Split.split gpart_a251P
                      p_a250Z = double g_a250Y
                      (g_a250Y, gpart_a251P) = Genome.Split.split gpart_a251O
                      p_a250X = double g_a250W
                      (g_a250W, gpart_a251O) = Genome.Split.split gpart_a251N
                      p_a250V = double g_a250U
                      (g_a250U, gpart_a251N) = Genome.Split.split gpart_a251M
                      p_a250T = Functions.belowten' g_a250S
                      (g_a250S, gpart_a251M) = Genome.Split.split gpart_a251L
                      p_a250R = double g_a250Q
                      (g_a250Q, gpart_a251L) = Genome.Split.split gpart_a251K
                      p_a250P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250O
                      (g_a250O, gpart_a251K) = Genome.Split.split gpart_a251J
                      p_a250N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250M
                      (g_a250M, gpart_a251J) = Genome.Split.split gpart_a251I
                      p_a250L = Functions.belowten' g_a250K
                      (g_a250K, gpart_a251I) = Genome.Split.split gpart_a251H
                      p_a250J = double g_a250I
                      (g_a250I, gpart_a251H) = Genome.Split.split gpart_a251G
                      p_a250H = double g_a250G
                      (g_a250G, gpart_a251G) = Genome.Split.split gpart_a251F
                      p_a250F = double g_a250E
                      (g_a250E, gpart_a251F) = Genome.Split.split gpart_a251E
                      p_a250D = Functions.belowten' g_a250C
                      (g_a250C, gpart_a251E) = Genome.Split.split gpart_a251D
                      p_a250B = double g_a250A
                      (g_a250A, gpart_a251D) = Genome.Split.split gpart_a251C
                      p_a250z = Functions.belowten' g_a250y
                      (g_a250y, gpart_a251C) = Genome.Split.split gpart_a251B
                      p_a250x = double g_a250w
                      (g_a250w, gpart_a251B) = Genome.Split.split gpart_a251A
                      p_a250v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250u
                      (g_a250u, gpart_a251A) = Genome.Split.split gpart_a251z
                      p_a250t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250s
                      (g_a250s, gpart_a251z) = Genome.Split.split gpart_a251y
                      p_a250r = double g_a250q
                      (g_a250q, gpart_a251y) = Genome.Split.split gpart_a251x
                      p_a250p = Functions.belowten' g_a250o
                      (g_a250o, gpart_a251x) = Genome.Split.split gpart_a251w
                      p_a250n = double g_a250m
                      (g_a250m, gpart_a251w) = Genome.Split.split gpart_a251v
                      p_a250l = Functions.belowten' g_a250k
                      (g_a250k, gpart_a251v) = Genome.Split.split gpart_a251u
                      p_a250j = double g_a250i
                      (g_a250i, gpart_a251u) = Genome.Split.split gpart_a251t
                      p_a250h = double g_a250g
                      (g_a250g, gpart_a251t) = Genome.Split.split gpart_a251s
                      p_a250f = Functions.belowten' g_a250e
                      (g_a250e, gpart_a251s) = Genome.Split.split gpart_a251r
                      p_a250d = double g_a250c
                      (g_a250c, gpart_a251r) = Genome.Split.split gpart_a251q
                      p_a250b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250a
                      (g_a250a, gpart_a251q) = Genome.Split.split gpart_a251p
                      p_a2509
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2508
                      (g_a2508, gpart_a251p) = Genome.Split.split gpart_a251o
                      p_a2507 = double g_a2506
                      (g_a2506, gpart_a251o) = Genome.Split.split gpart_a251n
                      p_a2505 = double g_a2504
                      (g_a2504, gpart_a251n) = Genome.Split.split gpart_a251m
                      p_a2503 = double g_a2502
                      (g_a2502, gpart_a251m) = Genome.Split.split gpart_a251l
                      p_a2501 = double g_a2500
                      (g_a2500, gpart_a251l) = Genome.Split.split gpart_a251k
                      p_a24ZZ = double g_a24ZY
                      (g_a24ZY, gpart_a251k) = Genome.Split.split genome_a251i
                    in  \ x_a251Z
                          -> let
                               c_PTB_a2522
                                 = ((Data.Fixed.Vector.toVector x_a251Z) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2520
                                 = ((Data.Fixed.Vector.toVector x_a251Z) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2526
                                 = ((Data.Fixed.Vector.toVector x_a251Z) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2528
                                 = ((Data.Fixed.Vector.toVector x_a251Z) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a252k
                                 = ((Data.Fixed.Vector.toVector x_a251Z) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2507
                                     / (1
                                        + (((p_a24ZZ / p_a2509) ** p_a250b)
                                           + ((c_MiRs_a2520 / p_a250d) ** p_a250f))))
                                    + (negate (p_a2519 * c_PTB_a2522))),
                                   ((p_a250h
                                     / (1
                                        + (((c_MiRs_a2520 / p_a250j) ** p_a250l)
                                           + ((c_PTB_a2522 / p_a250n) ** p_a250p))))
                                    + (negate (p_a251b * c_NPTB_a2526))),
                                   ((p_a250r
                                     * (p_a250F
                                        / ((1 + p_a250F)
                                           + (((c_NPTB_a2526 / p_a250x) ** p_a250z)
                                              + ((c_RESTc_a2528 / p_a250B) ** p_a250D)))))
                                    + (negate (p_a251d * c_MiRs_a2520))),
                                   ((p_a250H
                                     * ((p_a250V + ((c_PTB_a2522 / p_a250J) ** p_a250L))
                                        / (((1 + p_a250V) + ((c_PTB_a2522 / p_a250J) ** p_a250L))
                                           + ((c_MiRs_a2520 / p_a250R) ** p_a250T))))
                                    + (negate (p_a251f * c_RESTc_a2528))),
                                   ((p_a250X
                                     * ((p_a2517 + ((c_MiRs_a2520 / p_a250Z) ** p_a2511))
                                        / (((1 + p_a2517) + ((c_MiRs_a2520 / p_a250Z) ** p_a2511))
                                           + ((c_RESTc_a2528 / p_a2513) ** p_a2515))))
                                    + (negate (p_a251h * c_EndoNeuroTFs_a252k)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505677",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505679",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505697",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505699",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505717",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505719",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a251i
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a252Z
                            p_a251h = double g_a251g
                            (g_a251g, gpart_a252Z) = Genome.Split.split gpart_a252Y
                            p_a251f = double g_a251e
                            (g_a251e, gpart_a252Y) = Genome.Split.split gpart_a252X
                            p_a251d = double g_a251c
                            (g_a251c, gpart_a252X) = Genome.Split.split gpart_a252W
                            p_a251b = double g_a251a
                            (g_a251a, gpart_a252W) = Genome.Split.split gpart_a252V
                            p_a2519 = double g_a2518
                            (g_a2518, gpart_a252V) = Genome.Split.split gpart_a252U
                            p_a2517 = double g_a2516
                            (g_a2516, gpart_a252U) = Genome.Split.split gpart_a252T
                            p_a2515 = Functions.belowten' g_a2514
                            (g_a2514, gpart_a252T) = Genome.Split.split gpart_a252S
                            p_a2513 = double g_a2512
                            (g_a2512, gpart_a252S) = Genome.Split.split gpart_a252R
                            p_a2511 = Functions.belowten' g_a2510
                            (g_a2510, gpart_a252R) = Genome.Split.split gpart_a252Q
                            p_a250Z = double g_a250Y
                            (g_a250Y, gpart_a252Q) = Genome.Split.split gpart_a252P
                            p_a250X = double g_a250W
                            (g_a250W, gpart_a252P) = Genome.Split.split gpart_a252O
                            p_a250V = double g_a250U
                            (g_a250U, gpart_a252O) = Genome.Split.split gpart_a252N
                            p_a250T = Functions.belowten' g_a250S
                            (g_a250S, gpart_a252N) = Genome.Split.split gpart_a252M
                            p_a250R = double g_a250Q
                            (g_a250Q, gpart_a252M) = Genome.Split.split gpart_a252L
                            p_a250P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250O
                            (g_a250O, gpart_a252L) = Genome.Split.split gpart_a252K
                            p_a250N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250M
                            (g_a250M, gpart_a252K) = Genome.Split.split gpart_a252J
                            p_a250L = Functions.belowten' g_a250K
                            (g_a250K, gpart_a252J) = Genome.Split.split gpart_a252I
                            p_a250J = double g_a250I
                            (g_a250I, gpart_a252I) = Genome.Split.split gpart_a252H
                            p_a250H = double g_a250G
                            (g_a250G, gpart_a252H) = Genome.Split.split gpart_a252G
                            p_a250F = double g_a250E
                            (g_a250E, gpart_a252G) = Genome.Split.split gpart_a252F
                            p_a250D = Functions.belowten' g_a250C
                            (g_a250C, gpart_a252F) = Genome.Split.split gpart_a252E
                            p_a250B = double g_a250A
                            (g_a250A, gpart_a252E) = Genome.Split.split gpart_a252D
                            p_a250z = Functions.belowten' g_a250y
                            (g_a250y, gpart_a252D) = Genome.Split.split gpart_a252C
                            p_a250x = double g_a250w
                            (g_a250w, gpart_a252C) = Genome.Split.split gpart_a252B
                            p_a250v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250u
                            (g_a250u, gpart_a252B) = Genome.Split.split gpart_a252A
                            p_a250t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250s
                            (g_a250s, gpart_a252A) = Genome.Split.split gpart_a252z
                            p_a250r = double g_a250q
                            (g_a250q, gpart_a252z) = Genome.Split.split gpart_a252y
                            p_a250p = Functions.belowten' g_a250o
                            (g_a250o, gpart_a252y) = Genome.Split.split gpart_a252x
                            p_a250n = double g_a250m
                            (g_a250m, gpart_a252x) = Genome.Split.split gpart_a252w
                            p_a250l = Functions.belowten' g_a250k
                            (g_a250k, gpart_a252w) = Genome.Split.split gpart_a252v
                            p_a250j = double g_a250i
                            (g_a250i, gpart_a252v) = Genome.Split.split gpart_a252u
                            p_a250h = double g_a250g
                            (g_a250g, gpart_a252u) = Genome.Split.split gpart_a252t
                            p_a250f = Functions.belowten' g_a250e
                            (g_a250e, gpart_a252t) = Genome.Split.split gpart_a252s
                            p_a250d = double g_a250c
                            (g_a250c, gpart_a252s) = Genome.Split.split gpart_a252r
                            p_a250b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250a
                            (g_a250a, gpart_a252r) = Genome.Split.split gpart_a252q
                            p_a2509
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2508
                            (g_a2508, gpart_a252q) = Genome.Split.split gpart_a252p
                            p_a2507 = double g_a2506
                            (g_a2506, gpart_a252p) = Genome.Split.split gpart_a252o
                            p_a2505 = double g_a2504
                            (g_a2504, gpart_a252o) = Genome.Split.split gpart_a252n
                            p_a2503 = double g_a2502
                            (g_a2502, gpart_a252n) = Genome.Split.split gpart_a252m
                            p_a2501 = double g_a2500
                            (g_a2500, gpart_a252m) = Genome.Split.split gpart_a252l
                            p_a24ZZ = double g_a24ZY
                            (g_a24ZY, gpart_a252l) = Genome.Split.split genome_a251i
                          in
                            \ desc_a251j
                              -> case desc_a251j of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZZ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2501)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2503)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2505)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2507)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2509)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250b)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250d)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250f)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250h)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250j)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250l)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250n)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250p)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250r)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250t)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250v)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250x)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250z)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250B)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250D)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250F)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250H)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250J)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250L)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250N)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250P)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250R)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250T)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250V)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250X)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Z)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2511)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2513)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2515)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2517)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2519)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251b)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251d)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251f)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251h)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asTV
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUB
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                      (g_asTR, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                      (g_asTN, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                      (g_asTL, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                      (g_asTJ, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTI = Functions.belowten' g_asTH
                      (g_asTH, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                      (g_asTF, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTE = Functions.belowten' g_asTD
                      (g_asTD, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTC = code-0.1.0.0:Genome.FixedList.Functions.double g_asTB
                      (g_asTB, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                      (g_asTz, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTy = code-0.1.0.0:Genome.FixedList.Functions.double g_asTx
                      (g_asTx, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTw = Functions.belowten' g_asTv
                      (g_asTv, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                      (g_asTt, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asTs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTr
                      (g_asTr, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asTq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTp
                      (g_asTp, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asTo = Functions.belowten' g_asTn
                      (g_asTn, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                      (g_asTl, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                      (g_asTj, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asTi = code-0.1.0.0:Genome.FixedList.Functions.double g_asTh
                      (g_asTh, gpart_asUi) = Genome.Split.split gpart_asUh
                      p_asTg = Functions.belowten' g_asTf
                      (g_asTf, gpart_asUh) = Genome.Split.split gpart_asUg
                      p_asTe = code-0.1.0.0:Genome.FixedList.Functions.double g_asTd
                      (g_asTd, gpart_asUg) = Genome.Split.split gpart_asUf
                      p_asTc = Functions.belowten' g_asTb
                      (g_asTb, gpart_asUf) = Genome.Split.split gpart_asUe
                      p_asTa = code-0.1.0.0:Genome.FixedList.Functions.double g_asT9
                      (g_asT9, gpart_asUe) = Genome.Split.split gpart_asUd
                      p_asT8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                      (g_asT7, gpart_asUd) = Genome.Split.split gpart_asUc
                      p_asT6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT5
                      (g_asT5, gpart_asUc) = Genome.Split.split gpart_asUb
                      p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                      (g_asT3, gpart_asUb) = Genome.Split.split gpart_asUa
                      p_asT2 = Functions.belowten' g_asT1
                      (g_asT1, gpart_asUa) = Genome.Split.split gpart_asU9
                      p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                      (g_asSZ, gpart_asU9) = Genome.Split.split gpart_asU8
                      p_asSY = Functions.belowten' g_asSX
                      (g_asSX, gpart_asU8) = Genome.Split.split gpart_asU7
                      p_asSW = code-0.1.0.0:Genome.FixedList.Functions.double g_asSV
                      (g_asSV, gpart_asU7) = Genome.Split.split gpart_asU6
                      p_asSU = code-0.1.0.0:Genome.FixedList.Functions.double g_asST
                      (g_asST, gpart_asU6) = Genome.Split.split gpart_asU5
                      p_asSS = Functions.belowten' g_asSR
                      (g_asSR, gpart_asU5) = Genome.Split.split gpart_asU4
                      p_asSQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSP
                      (g_asSP, gpart_asU4) = Genome.Split.split gpart_asU3
                      p_asSO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSN
                      (g_asSN, gpart_asU3) = Genome.Split.split gpart_asU2
                      p_asSM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSL
                      (g_asSL, gpart_asU2) = Genome.Split.split gpart_asU1
                      p_asSK = code-0.1.0.0:Genome.FixedList.Functions.double g_asSJ
                      (g_asSJ, gpart_asU1) = Genome.Split.split gpart_asU0
                      p_asSI = code-0.1.0.0:Genome.FixedList.Functions.double g_asSH
                      (g_asSH, gpart_asU0) = Genome.Split.split gpart_asTZ
                      p_asSG = code-0.1.0.0:Genome.FixedList.Functions.double g_asSF
                      (g_asSF, gpart_asTZ) = Genome.Split.split gpart_asTY
                      p_asSE = code-0.1.0.0:Genome.FixedList.Functions.double g_asSD
                      (g_asSD, gpart_asTY) = Genome.Split.split gpart_asTX
                      p_asSC = code-0.1.0.0:Genome.FixedList.Functions.double g_asSB
                      (g_asSB, gpart_asTX) = Genome.Split.split genome_asTV
                    in
                      [Reaction
                         (\ x_asUC
                            -> let c_MiRs_asUD = ((toVector x_asUC) Data.Vector.Unboxed.! 2)
                               in (p_asSK / (1 + ((c_MiRs_asUD / p_asSQ) ** p_asSS))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUE
                            -> let
                                 c_MiRs_asUF = ((toVector x_asUE) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUG = ((toVector x_asUE) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asSU
                                  / (1
                                     + (((c_MiRs_asUF / p_asSW) ** p_asSY)
                                        + ((c_PTB_asUG / p_asT0) ** p_asT2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUH
                            -> let
                                 c_RESTc_asUJ = ((toVector x_asUH) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asUI = ((toVector x_asUH) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asT4
                                  * ((p_asTi + ((p_asSG / p_asT6) ** p_asT8))
                                     / (((1 + p_asTi) + ((p_asSG / p_asT6) ** p_asT8))
                                        + (((c_NPTB_asUI / p_asTa) ** p_asTc)
                                           + ((c_RESTc_asUJ / p_asTe) ** p_asTg))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUK
                            -> let
                                 c_MiRs_asUN = ((toVector x_asUK) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUL = ((toVector x_asUK) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTk
                                  * ((p_asTy + ((c_PTB_asUL / p_asTm) ** p_asTo))
                                     / (((1 + p_asTy) + ((c_PTB_asUL / p_asTm) ** p_asTo))
                                        + (((p_asSC / p_asTq) ** p_asTs)
                                           + ((c_MiRs_asUN / p_asTu) ** p_asTw))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asUO
                            -> let
                                 c_RESTc_asUR = ((toVector x_asUO) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asUP = ((toVector x_asUO) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asTA
                                  * ((p_asTK + ((c_MiRs_asUP / p_asTC) ** p_asTE))
                                     / (((1 + p_asTK) + ((c_MiRs_asUP / p_asTC) ** p_asTE))
                                        + ((c_RESTc_asUR / p_asTG) ** p_asTI)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asUS
                            -> let c_PTB_asUT = ((toVector x_asUS) Data.Vector.Unboxed.! 0)
                               in (p_asTM * c_PTB_asUT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUU
                            -> let c_NPTB_asUV = ((toVector x_asUU) Data.Vector.Unboxed.! 1)
                               in (p_asTO * c_NPTB_asUV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asUW
                            -> let c_MiRs_asUX = ((toVector x_asUW) Data.Vector.Unboxed.! 2)
                               in (p_asTQ * c_MiRs_asUX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asUY
                            -> let c_RESTc_asUZ = ((toVector x_asUY) Data.Vector.Unboxed.! 3)
                               in (p_asTS * c_RESTc_asUZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asV0
                            -> let
                                 c_EndoNeuroTFs_asV1 = ((toVector x_asV0) Data.Vector.Unboxed.! 4)
                               in (p_asTU * c_EndoNeuroTFs_asV1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120810",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120812",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120814",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120816",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120817",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120818",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120819",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120820",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120821",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120822",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120823",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120824",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120825",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120826",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120827",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120828",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120829",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120830",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120834",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120840",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120842",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120860",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120862",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asTV
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVL
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                            (g_asTR, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                            (g_asTN, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                            (g_asTL, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                            (g_asTJ, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTI = Functions.belowten' g_asTH
                            (g_asTH, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                            (g_asTF, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTE = Functions.belowten' g_asTD
                            (g_asTD, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTC = code-0.1.0.0:Genome.FixedList.Functions.double g_asTB
                            (g_asTB, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                            (g_asTz, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTy = code-0.1.0.0:Genome.FixedList.Functions.double g_asTx
                            (g_asTx, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTw = Functions.belowten' g_asTv
                            (g_asTv, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                            (g_asTt, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asTs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTr
                            (g_asTr, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asTq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTp
                            (g_asTp, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asTo = Functions.belowten' g_asTn
                            (g_asTn, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                            (g_asTl, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                            (g_asTj, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asTi = code-0.1.0.0:Genome.FixedList.Functions.double g_asTh
                            (g_asTh, gpart_asVs) = Genome.Split.split gpart_asVr
                            p_asTg = Functions.belowten' g_asTf
                            (g_asTf, gpart_asVr) = Genome.Split.split gpart_asVq
                            p_asTe = code-0.1.0.0:Genome.FixedList.Functions.double g_asTd
                            (g_asTd, gpart_asVq) = Genome.Split.split gpart_asVp
                            p_asTc = Functions.belowten' g_asTb
                            (g_asTb, gpart_asVp) = Genome.Split.split gpart_asVo
                            p_asTa = code-0.1.0.0:Genome.FixedList.Functions.double g_asT9
                            (g_asT9, gpart_asVo) = Genome.Split.split gpart_asVn
                            p_asT8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                            (g_asT7, gpart_asVn) = Genome.Split.split gpart_asVm
                            p_asT6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT5
                            (g_asT5, gpart_asVm) = Genome.Split.split gpart_asVl
                            p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                            (g_asT3, gpart_asVl) = Genome.Split.split gpart_asVk
                            p_asT2 = Functions.belowten' g_asT1
                            (g_asT1, gpart_asVk) = Genome.Split.split gpart_asVj
                            p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                            (g_asSZ, gpart_asVj) = Genome.Split.split gpart_asVi
                            p_asSY = Functions.belowten' g_asSX
                            (g_asSX, gpart_asVi) = Genome.Split.split gpart_asVh
                            p_asSW = code-0.1.0.0:Genome.FixedList.Functions.double g_asSV
                            (g_asSV, gpart_asVh) = Genome.Split.split gpart_asVg
                            p_asSU = code-0.1.0.0:Genome.FixedList.Functions.double g_asST
                            (g_asST, gpart_asVg) = Genome.Split.split gpart_asVf
                            p_asSS = Functions.belowten' g_asSR
                            (g_asSR, gpart_asVf) = Genome.Split.split gpart_asVe
                            p_asSQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asSP
                            (g_asSP, gpart_asVe) = Genome.Split.split gpart_asVd
                            p_asSO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSN
                            (g_asSN, gpart_asVd) = Genome.Split.split gpart_asVc
                            p_asSM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSL
                            (g_asSL, gpart_asVc) = Genome.Split.split gpart_asVb
                            p_asSK = code-0.1.0.0:Genome.FixedList.Functions.double g_asSJ
                            (g_asSJ, gpart_asVb) = Genome.Split.split gpart_asVa
                            p_asSI = code-0.1.0.0:Genome.FixedList.Functions.double g_asSH
                            (g_asSH, gpart_asVa) = Genome.Split.split gpart_asV9
                            p_asSG = code-0.1.0.0:Genome.FixedList.Functions.double g_asSF
                            (g_asSF, gpart_asV9) = Genome.Split.split gpart_asV8
                            p_asSE = code-0.1.0.0:Genome.FixedList.Functions.double g_asSD
                            (g_asSD, gpart_asV8) = Genome.Split.split gpart_asV7
                            p_asSC = code-0.1.0.0:Genome.FixedList.Functions.double g_asSB
                            (g_asSB, gpart_asV7) = Genome.Split.split genome_asTV
                          in
                            \ desc_asTW
                              -> case desc_asTW of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSK)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSM)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSO)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSQ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT2)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT4)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT6)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT8)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTa)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTc)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTe)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTg)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTi)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTk)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTm)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTo)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTq)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTs)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTu)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTw)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTy)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTA)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTC)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTE)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTG)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTI)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asXM
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYs
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXz = Functions.belowten' g_asXy
                      (g_asXy, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                      (g_asXw, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asXv = Functions.belowten' g_asXu
                      (g_asXu, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                      (g_asXs, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                      (g_asXq, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                      (g_asXo, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asXn = Functions.belowten' g_asXm
                      (g_asXm, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asXj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXi
                      (g_asXi, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asXh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXg
                      (g_asXg, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asXf = Functions.belowten' g_asXe
                      (g_asXe, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                      (g_asXc, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asXb = code-0.1.0.0:Genome.FixedList.Functions.double g_asXa
                      (g_asXa, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                      (g_asX8, gpart_asY9) = Genome.Split.split gpart_asY8
                      p_asX7 = Functions.belowten' g_asX6
                      (g_asX6, gpart_asY8) = Genome.Split.split gpart_asY7
                      p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                      (g_asX4, gpart_asY7) = Genome.Split.split gpart_asY6
                      p_asX3 = Functions.belowten' g_asX2
                      (g_asX2, gpart_asY6) = Genome.Split.split gpart_asY5
                      p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                      (g_asX0, gpart_asY5) = Genome.Split.split gpart_asY4
                      p_asWZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWY
                      (g_asWY, gpart_asY4) = Genome.Split.split gpart_asY3
                      p_asWX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWW
                      (g_asWW, gpart_asY3) = Genome.Split.split gpart_asY2
                      p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                      (g_asWU, gpart_asY2) = Genome.Split.split gpart_asY1
                      p_asWT = Functions.belowten' g_asWS
                      (g_asWS, gpart_asY1) = Genome.Split.split gpart_asY0
                      p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                      (g_asWQ, gpart_asY0) = Genome.Split.split gpart_asXZ
                      p_asWP = Functions.belowten' g_asWO
                      (g_asWO, gpart_asXZ) = Genome.Split.split gpart_asXY
                      p_asWN = code-0.1.0.0:Genome.FixedList.Functions.double g_asWM
                      (g_asWM, gpart_asXY) = Genome.Split.split gpart_asXX
                      p_asWL = code-0.1.0.0:Genome.FixedList.Functions.double g_asWK
                      (g_asWK, gpart_asXX) = Genome.Split.split gpart_asXW
                      p_asWJ = Functions.belowten' g_asWI
                      (g_asWI, gpart_asXW) = Genome.Split.split gpart_asXV
                      p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                      (g_asWG, gpart_asXV) = Genome.Split.split gpart_asXU
                      p_asWF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWE
                      (g_asWE, gpart_asXU) = Genome.Split.split gpart_asXT
                      p_asWD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWC
                      (g_asWC, gpart_asXT) = Genome.Split.split gpart_asXS
                      p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                      (g_asWA, gpart_asXS) = Genome.Split.split gpart_asXR
                      p_asWz = code-0.1.0.0:Genome.FixedList.Functions.double g_asWy
                      (g_asWy, gpart_asXR) = Genome.Split.split gpart_asXQ
                      p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                      (g_asWw, gpart_asXQ) = Genome.Split.split gpart_asXP
                      p_asWv = code-0.1.0.0:Genome.FixedList.Functions.double g_asWu
                      (g_asWu, gpart_asXP) = Genome.Split.split gpart_asXO
                      p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                      (g_asWs, gpart_asXO) = Genome.Split.split genome_asXM
                    in
                      [Reaction
                         (\ x_asYt
                            -> let c_MiRs_asYu = ((toVector x_asYt) Data.Vector.Unboxed.! 2)
                               in (p_asWB / (1 + ((c_MiRs_asYu / p_asWH) ** p_asWJ))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYv
                            -> let
                                 c_MiRs_asYw = ((toVector x_asYv) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYx = ((toVector x_asYv) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWL
                                  / (1
                                     + (((c_MiRs_asYw / p_asWN) ** p_asWP)
                                        + ((c_PTB_asYx / p_asWR) ** p_asWT)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYy
                            -> let
                                 c_RESTc_asYA = ((toVector x_asYy) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asYz = ((toVector x_asYy) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asWV
                                  * (p_asX9
                                     / ((1 + p_asX9)
                                        + (((c_NPTB_asYz / p_asX1) ** p_asX3)
                                           + ((c_RESTc_asYA / p_asX5) ** p_asX7))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYB
                            -> let
                                 c_MiRs_asYE = ((toVector x_asYB) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYC = ((toVector x_asYB) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXb
                                  * ((p_asXp + ((c_PTB_asYC / p_asXd) ** p_asXf))
                                     / (((1 + p_asXp) + ((c_PTB_asYC / p_asXd) ** p_asXf))
                                        + (((p_asWt / p_asXh) ** p_asXj)
                                           + ((c_MiRs_asYE / p_asXl) ** p_asXn))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asYF
                            -> let
                                 c_RESTc_asYI = ((toVector x_asYF) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asYG = ((toVector x_asYF) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asXr
                                  * ((p_asXB + ((c_MiRs_asYG / p_asXt) ** p_asXv))
                                     / (((1 + p_asXB) + ((c_MiRs_asYG / p_asXt) ** p_asXv))
                                        + ((c_RESTc_asYI / p_asXx) ** p_asXz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asYJ
                            -> let c_PTB_asYK = ((toVector x_asYJ) Data.Vector.Unboxed.! 0)
                               in (p_asXD * c_PTB_asYK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYL
                            -> let c_NPTB_asYM = ((toVector x_asYL) Data.Vector.Unboxed.! 1)
                               in (p_asXF * c_NPTB_asYM))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asYN
                            -> let c_MiRs_asYO = ((toVector x_asYN) Data.Vector.Unboxed.! 2)
                               in (p_asXH * c_MiRs_asYO))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asYP
                            -> let c_RESTc_asYQ = ((toVector x_asYP) Data.Vector.Unboxed.! 3)
                               in (p_asXJ * c_RESTc_asYQ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asYR
                            -> let
                                 c_EndoNeuroTFs_asYS = ((toVector x_asYR) Data.Vector.Unboxed.! 4)
                               in (p_asXL * c_EndoNeuroTFs_asYS))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121059",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121061",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121079",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121081",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121093",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asXM
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZx
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZw) = Genome.Split.split gpart_asZv
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_asZv) = Genome.Split.split gpart_asZu
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_asZu) = Genome.Split.split gpart_asZt
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asXz = Functions.belowten' g_asXy
                            (g_asXy, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                            (g_asXw, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXv = Functions.belowten' g_asXu
                            (g_asXu, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                            (g_asXs, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                            (g_asXq, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                            (g_asXo, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asXn = Functions.belowten' g_asXm
                            (g_asXm, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asXj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXi
                            (g_asXi, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asXh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXg
                            (g_asXg, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asXf = Functions.belowten' g_asXe
                            (g_asXe, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                            (g_asXc, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asXb = code-0.1.0.0:Genome.FixedList.Functions.double g_asXa
                            (g_asXa, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                            (g_asX8, gpart_asZe) = Genome.Split.split gpart_asZd
                            p_asX7 = Functions.belowten' g_asX6
                            (g_asX6, gpart_asZd) = Genome.Split.split gpart_asZc
                            p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                            (g_asX4, gpart_asZc) = Genome.Split.split gpart_asZb
                            p_asX3 = Functions.belowten' g_asX2
                            (g_asX2, gpart_asZb) = Genome.Split.split gpart_asZa
                            p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                            (g_asX0, gpart_asZa) = Genome.Split.split gpart_asZ9
                            p_asWZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWY
                            (g_asWY, gpart_asZ9) = Genome.Split.split gpart_asZ8
                            p_asWX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWW
                            (g_asWW, gpart_asZ8) = Genome.Split.split gpart_asZ7
                            p_asWV = code-0.1.0.0:Genome.FixedList.Functions.double g_asWU
                            (g_asWU, gpart_asZ7) = Genome.Split.split gpart_asZ6
                            p_asWT = Functions.belowten' g_asWS
                            (g_asWS, gpart_asZ6) = Genome.Split.split gpart_asZ5
                            p_asWR = code-0.1.0.0:Genome.FixedList.Functions.double g_asWQ
                            (g_asWQ, gpart_asZ5) = Genome.Split.split gpart_asZ4
                            p_asWP = Functions.belowten' g_asWO
                            (g_asWO, gpart_asZ4) = Genome.Split.split gpart_asZ3
                            p_asWN = code-0.1.0.0:Genome.FixedList.Functions.double g_asWM
                            (g_asWM, gpart_asZ3) = Genome.Split.split gpart_asZ2
                            p_asWL = code-0.1.0.0:Genome.FixedList.Functions.double g_asWK
                            (g_asWK, gpart_asZ2) = Genome.Split.split gpart_asZ1
                            p_asWJ = Functions.belowten' g_asWI
                            (g_asWI, gpart_asZ1) = Genome.Split.split gpart_asZ0
                            p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                            (g_asWG, gpart_asZ0) = Genome.Split.split gpart_asYZ
                            p_asWF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWE
                            (g_asWE, gpart_asYZ) = Genome.Split.split gpart_asYY
                            p_asWD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWC
                            (g_asWC, gpart_asYY) = Genome.Split.split gpart_asYX
                            p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                            (g_asWA, gpart_asYX) = Genome.Split.split gpart_asYW
                            p_asWz = code-0.1.0.0:Genome.FixedList.Functions.double g_asWy
                            (g_asWy, gpart_asYW) = Genome.Split.split gpart_asYV
                            p_asWx = code-0.1.0.0:Genome.FixedList.Functions.double g_asWw
                            (g_asWw, gpart_asYV) = Genome.Split.split gpart_asYU
                            p_asWv = code-0.1.0.0:Genome.FixedList.Functions.double g_asWu
                            (g_asWu, gpart_asYU) = Genome.Split.split gpart_asYT
                            p_asWt = code-0.1.0.0:Genome.FixedList.Functions.double g_asWs
                            (g_asWs, gpart_asYT) = Genome.Split.split genome_asXM
                          in
                            \ desc_asXN
                              -> case desc_asXN of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWt)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWv)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWx)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWz)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWB)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWD)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWF)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWH)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWJ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWL)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWN)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWP)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWR)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWT)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWV)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWX)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWZ)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX9)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXb)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1y
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2e
                      p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                      (g_at1w, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                      (g_at1u, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at1t = code-0.1.0.0:Genome.FixedList.Functions.double g_at1s
                      (g_at1s, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                      (g_at1q, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at1p = code-0.1.0.0:Genome.FixedList.Functions.double g_at1o
                      (g_at1o, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                      (g_at1m, gpart_at29) = Genome.Split.split gpart_at28
                      p_at1l = Functions.belowten' g_at1k
                      (g_at1k, gpart_at28) = Genome.Split.split gpart_at27
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at27) = Genome.Split.split gpart_at26
                      p_at1h = Functions.belowten' g_at1g
                      (g_at1g, gpart_at26) = Genome.Split.split gpart_at25
                      p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                      (g_at1e, gpart_at25) = Genome.Split.split gpart_at24
                      p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                      (g_at1c, gpart_at24) = Genome.Split.split gpart_at23
                      p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                      (g_at1a, gpart_at23) = Genome.Split.split gpart_at22
                      p_at19 = Functions.belowten' g_at18
                      (g_at18, gpart_at22) = Genome.Split.split gpart_at21
                      p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                      (g_at16, gpart_at21) = Genome.Split.split gpart_at20
                      p_at15
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at14
                      (g_at14, gpart_at20) = Genome.Split.split gpart_at1Z
                      p_at13
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at12
                      (g_at12, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at11 = Functions.belowten' g_at10
                      (g_at10, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                      (g_at0Y, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at0X = code-0.1.0.0:Genome.FixedList.Functions.double g_at0W
                      (g_at0W, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                      (g_at0U, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at0T = Functions.belowten' g_at0S
                      (g_at0S, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                      (g_at0Q, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at0P = Functions.belowten' g_at0O
                      (g_at0O, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                      (g_at0M, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at0L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0K
                      (g_at0K, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at0J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                      (g_at0I, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                      (g_at0G, gpart_at1O) = Genome.Split.split gpart_at1N
                      p_at0F = Functions.belowten' g_at0E
                      (g_at0E, gpart_at1N) = Genome.Split.split gpart_at1M
                      p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                      (g_at0C, gpart_at1M) = Genome.Split.split gpart_at1L
                      p_at0B = Functions.belowten' g_at0A
                      (g_at0A, gpart_at1L) = Genome.Split.split gpart_at1K
                      p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                      (g_at0y, gpart_at1K) = Genome.Split.split gpart_at1J
                      p_at0x = code-0.1.0.0:Genome.FixedList.Functions.double g_at0w
                      (g_at0w, gpart_at1J) = Genome.Split.split gpart_at1I
                      p_at0v = Functions.belowten' g_at0u
                      (g_at0u, gpart_at1I) = Genome.Split.split gpart_at1H
                      p_at0t = code-0.1.0.0:Genome.FixedList.Functions.double g_at0s
                      (g_at0s, gpart_at1H) = Genome.Split.split gpart_at1G
                      p_at0r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0q
                      (g_at0q, gpart_at1G) = Genome.Split.split gpart_at1F
                      p_at0p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0o
                      (g_at0o, gpart_at1F) = Genome.Split.split gpart_at1E
                      p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                      (g_at0m, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0l = code-0.1.0.0:Genome.FixedList.Functions.double g_at0k
                      (g_at0k, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                      (g_at0i, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                      (g_at0g, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                      (g_at0e, gpart_at1A) = Genome.Split.split genome_at1y
                    in
                      [Reaction
                         (\ x_at2f
                            -> let c_MiRs_at2g = ((toVector x_at2f) Data.Vector.Unboxed.! 2)
                               in (p_at0n / (1 + ((c_MiRs_at2g / p_at0t) ** p_at0v))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2h
                            -> let
                                 c_MiRs_at2i = ((toVector x_at2h) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2j = ((toVector x_at2h) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0x
                                  / (1
                                     + (((c_MiRs_at2i / p_at0z) ** p_at0B)
                                        + ((c_PTB_at2j / p_at0D) ** p_at0F)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2k
                            -> let
                                 c_RESTc_at2m = ((toVector x_at2k) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at2l = ((toVector x_at2k) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at0H
                                  * (p_at0V
                                     / ((1 + p_at0V)
                                        + (((c_NPTB_at2l / p_at0N) ** p_at0P)
                                           + ((c_RESTc_at2m / p_at0R) ** p_at0T))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2n
                            -> let
                                 c_MiRs_at2q = ((toVector x_at2n) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2o = ((toVector x_at2n) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0X
                                  * ((p_at1b + ((c_PTB_at2o / p_at0Z) ** p_at11))
                                     / (((1 + p_at1b) + ((c_PTB_at2o / p_at0Z) ** p_at11))
                                        + ((c_MiRs_at2q / p_at17) ** p_at19)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2r
                            -> let
                                 c_RESTc_at2u = ((toVector x_at2r) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at2s = ((toVector x_at2r) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at1d
                                  * ((p_at1n + ((c_MiRs_at2s / p_at1f) ** p_at1h))
                                     / (((1 + p_at1n) + ((c_MiRs_at2s / p_at1f) ** p_at1h))
                                        + ((c_RESTc_at2u / p_at1j) ** p_at1l)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2v
                            -> let c_PTB_at2w = ((toVector x_at2v) Data.Vector.Unboxed.! 0)
                               in (p_at1p * c_PTB_at2w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2x
                            -> let c_NPTB_at2y = ((toVector x_at2x) Data.Vector.Unboxed.! 1)
                               in (p_at1r * c_NPTB_at2y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2z
                            -> let c_MiRs_at2A = ((toVector x_at2z) Data.Vector.Unboxed.! 2)
                               in (p_at1t * c_MiRs_at2A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2B
                            -> let c_RESTc_at2C = ((toVector x_at2B) Data.Vector.Unboxed.! 3)
                               in (p_at1v * c_RESTc_at2C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2D
                            -> let
                                 c_EndoNeuroTFs_at2E = ((toVector x_at2D) Data.Vector.Unboxed.! 4)
                               in (p_at1x * c_EndoNeuroTFs_at2E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121293",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121295",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121315",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121355",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1y
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3j
                            p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                            (g_at1w, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                            (g_at1u, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at1t = code-0.1.0.0:Genome.FixedList.Functions.double g_at1s
                            (g_at1s, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                            (g_at1q, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at1p = code-0.1.0.0:Genome.FixedList.Functions.double g_at1o
                            (g_at1o, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                            (g_at1m, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at1l = Functions.belowten' g_at1k
                            (g_at1k, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at1h = Functions.belowten' g_at1g
                            (g_at1g, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                            (g_at1e, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                            (g_at1c, gpart_at39) = Genome.Split.split gpart_at38
                            p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                            (g_at1a, gpart_at38) = Genome.Split.split gpart_at37
                            p_at19 = Functions.belowten' g_at18
                            (g_at18, gpart_at37) = Genome.Split.split gpart_at36
                            p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                            (g_at16, gpart_at36) = Genome.Split.split gpart_at35
                            p_at15
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at14
                            (g_at14, gpart_at35) = Genome.Split.split gpart_at34
                            p_at13
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at12
                            (g_at12, gpart_at34) = Genome.Split.split gpart_at33
                            p_at11 = Functions.belowten' g_at10
                            (g_at10, gpart_at33) = Genome.Split.split gpart_at32
                            p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                            (g_at0Y, gpart_at32) = Genome.Split.split gpart_at31
                            p_at0X = code-0.1.0.0:Genome.FixedList.Functions.double g_at0W
                            (g_at0W, gpart_at31) = Genome.Split.split gpart_at30
                            p_at0V = code-0.1.0.0:Genome.FixedList.Functions.double g_at0U
                            (g_at0U, gpart_at30) = Genome.Split.split gpart_at2Z
                            p_at0T = Functions.belowten' g_at0S
                            (g_at0S, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                            (g_at0Q, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at0P = Functions.belowten' g_at0O
                            (g_at0O, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                            (g_at0M, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at0L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0K
                            (g_at0K, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at0J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                            (g_at0I, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                            (g_at0G, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at0F = Functions.belowten' g_at0E
                            (g_at0E, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                            (g_at0C, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at0B = Functions.belowten' g_at0A
                            (g_at0A, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                            (g_at0y, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0x = code-0.1.0.0:Genome.FixedList.Functions.double g_at0w
                            (g_at0w, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0v = Functions.belowten' g_at0u
                            (g_at0u, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0t = code-0.1.0.0:Genome.FixedList.Functions.double g_at0s
                            (g_at0s, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0q
                            (g_at0q, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0o
                            (g_at0o, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                            (g_at0m, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0l = code-0.1.0.0:Genome.FixedList.Functions.double g_at0k
                            (g_at0k, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                            (g_at0i, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                            (g_at0g, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                            (g_at0e, gpart_at2F) = Genome.Split.split genome_at1y
                          in
                            \ desc_at1z
                              -> case desc_at1z of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0f)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0h)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0j)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0l)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0n)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0p)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0r)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0t)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0v)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0x)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0z)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0B)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0D)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0F)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0L)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0N)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0P)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0R)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0T)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0V)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0X)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1n)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1p)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1r)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1t)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1v)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1x)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5k
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at60
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                      (g_at5a, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                      (g_at58, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at57 = Functions.belowten' g_at56
                      (g_at56, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                      (g_at54, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at53 = Functions.belowten' g_at52
                      (g_at52, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                      (g_at50, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                      (g_at4Y, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at4V = Functions.belowten' g_at4U
                      (g_at4U, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4Q
                      (g_at4Q, gpart_at5M) = Genome.Split.split gpart_at5L
                      p_at4P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4O
                      (g_at4O, gpart_at5L) = Genome.Split.split gpart_at5K
                      p_at4N = Functions.belowten' g_at4M
                      (g_at4M, gpart_at5K) = Genome.Split.split gpart_at5J
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5J) = Genome.Split.split gpart_at5I
                      p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                      (g_at4I, gpart_at5I) = Genome.Split.split gpart_at5H
                      p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                      (g_at4G, gpart_at5H) = Genome.Split.split gpart_at5G
                      p_at4F = Functions.belowten' g_at4E
                      (g_at4E, gpart_at5G) = Genome.Split.split gpart_at5F
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5F) = Genome.Split.split gpart_at5E
                      p_at4B = Functions.belowten' g_at4A
                      (g_at4A, gpart_at5E) = Genome.Split.split gpart_at5D
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5D) = Genome.Split.split gpart_at5C
                      p_at4x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4w
                      (g_at4w, gpart_at5C) = Genome.Split.split gpart_at5B
                      p_at4v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4u
                      (g_at4u, gpart_at5B) = Genome.Split.split gpart_at5A
                      p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                      (g_at4s, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4r = Functions.belowten' g_at4q
                      (g_at4q, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                      (g_at4o, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4n = Functions.belowten' g_at4m
                      (g_at4m, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                      (g_at4k, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                      (g_at4i, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4h = Functions.belowten' g_at4g
                      (g_at4g, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                      (g_at4e, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4d
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4c
                      (g_at4c, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4a
                      (g_at4a, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at47 = code-0.1.0.0:Genome.FixedList.Functions.double g_at46
                      (g_at46, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at43 = code-0.1.0.0:Genome.FixedList.Functions.double g_at42
                      (g_at42, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                      (g_at40, gpart_at5m) = Genome.Split.split genome_at5k
                    in
                      [Reaction
                         (\ x_at61
                            -> let c_MiRs_at62 = ((toVector x_at61) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at49
                                  / (1
                                     + (((p_at41 / p_at4b) ** p_at4d)
                                        + ((c_MiRs_at62 / p_at4f) ** p_at4h)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at63
                            -> let
                                 c_MiRs_at64 = ((toVector x_at63) Data.Vector.Unboxed.! 2)
                                 c_PTB_at65 = ((toVector x_at63) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4j
                                  / (1
                                     + (((c_MiRs_at64 / p_at4l) ** p_at4n)
                                        + ((c_PTB_at65 / p_at4p) ** p_at4r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at66
                            -> let
                                 c_RESTc_at68 = ((toVector x_at66) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at67 = ((toVector x_at66) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4t
                                  * (p_at4H
                                     / ((1 + p_at4H)
                                        + (((c_NPTB_at67 / p_at4z) ** p_at4B)
                                           + ((c_RESTc_at68 / p_at4D) ** p_at4F))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at69
                            -> let
                                 c_MiRs_at6c = ((toVector x_at69) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6a = ((toVector x_at69) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4J
                                  * ((p_at4X + ((c_PTB_at6a / p_at4L) ** p_at4N))
                                     / (((1 + p_at4X) + ((c_PTB_at6a / p_at4L) ** p_at4N))
                                        + ((c_MiRs_at6c / p_at4T) ** p_at4V)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6d
                            -> let
                                 c_RESTc_at6g = ((toVector x_at6d) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6e = ((toVector x_at6d) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4Z
                                  * ((p_at59 + ((c_MiRs_at6e / p_at51) ** p_at53))
                                     / (((1 + p_at59) + ((c_MiRs_at6e / p_at51) ** p_at53))
                                        + ((c_RESTc_at6g / p_at55) ** p_at57)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6h
                            -> let c_PTB_at6i = ((toVector x_at6h) Data.Vector.Unboxed.! 0)
                               in (p_at5b * c_PTB_at6i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6j
                            -> let c_NPTB_at6k = ((toVector x_at6j) Data.Vector.Unboxed.! 1)
                               in (p_at5d * c_NPTB_at6k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6l
                            -> let c_MiRs_at6m = ((toVector x_at6l) Data.Vector.Unboxed.! 2)
                               in (p_at5f * c_MiRs_at6m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6n
                            -> let c_RESTc_at6o = ((toVector x_at6n) Data.Vector.Unboxed.! 3)
                               in (p_at5h * c_RESTc_at6o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6p
                            -> let
                                 c_EndoNeuroTFs_at6q = ((toVector x_at6p) Data.Vector.Unboxed.! 4)
                               in (p_at5j * c_EndoNeuroTFs_at6q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5k
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at75
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at75) = Genome.Split.split gpart_at74
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at74) = Genome.Split.split gpart_at73
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at73) = Genome.Split.split gpart_at72
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at72) = Genome.Split.split gpart_at71
                            p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                            (g_at5a, gpart_at71) = Genome.Split.split gpart_at70
                            p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                            (g_at58, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at57 = Functions.belowten' g_at56
                            (g_at56, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                            (g_at54, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at53 = Functions.belowten' g_at52
                            (g_at52, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                            (g_at50, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                            (g_at4Y, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at4V = Functions.belowten' g_at4U
                            (g_at4U, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at4R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4Q
                            (g_at4Q, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at4P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4O
                            (g_at4O, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4N = Functions.belowten' g_at4M
                            (g_at4M, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                            (g_at4I, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                            (g_at4G, gpart_at6M) = Genome.Split.split gpart_at6L
                            p_at4F = Functions.belowten' g_at4E
                            (g_at4E, gpart_at6L) = Genome.Split.split gpart_at6K
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6K) = Genome.Split.split gpart_at6J
                            p_at4B = Functions.belowten' g_at4A
                            (g_at4A, gpart_at6J) = Genome.Split.split gpart_at6I
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6I) = Genome.Split.split gpart_at6H
                            p_at4x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4w
                            (g_at4w, gpart_at6H) = Genome.Split.split gpart_at6G
                            p_at4v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4u
                            (g_at4u, gpart_at6G) = Genome.Split.split gpart_at6F
                            p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                            (g_at4s, gpart_at6F) = Genome.Split.split gpart_at6E
                            p_at4r = Functions.belowten' g_at4q
                            (g_at4q, gpart_at6E) = Genome.Split.split gpart_at6D
                            p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                            (g_at4o, gpart_at6D) = Genome.Split.split gpart_at6C
                            p_at4n = Functions.belowten' g_at4m
                            (g_at4m, gpart_at6C) = Genome.Split.split gpart_at6B
                            p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                            (g_at4k, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                            (g_at4i, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4h = Functions.belowten' g_at4g
                            (g_at4g, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                            (g_at4e, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4d
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4c
                            (g_at4c, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4a
                            (g_at4a, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at47 = code-0.1.0.0:Genome.FixedList.Functions.double g_at46
                            (g_at46, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at43 = code-0.1.0.0:Genome.FixedList.Functions.double g_at42
                            (g_at42, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at41 = code-0.1.0.0:Genome.FixedList.Functions.double g_at40
                            (g_at40, gpart_at6r) = Genome.Split.split genome_at5k
                          in
                            \ desc_at5l
                              -> case desc_at5l of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   _ -> Nothing }}
