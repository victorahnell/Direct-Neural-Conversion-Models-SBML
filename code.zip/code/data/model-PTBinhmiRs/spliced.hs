src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zak
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZaX
                      p_a1Zaj = double g_a1Zai
                      (g_a1Zai, gpart_a1ZaX) = Genome.Split.split gpart_a1ZaW
                      p_a1Zah = double g_a1Zag
                      (g_a1Zag, gpart_a1ZaW) = Genome.Split.split gpart_a1ZaV
                      p_a1Zaf = double g_a1Zae
                      (g_a1Zae, gpart_a1ZaV) = Genome.Split.split gpart_a1ZaU
                      p_a1Zad = double g_a1Zac
                      (g_a1Zac, gpart_a1ZaU) = Genome.Split.split gpart_a1ZaT
                      p_a1Zab = double g_a1Zaa
                      (g_a1Zaa, gpart_a1ZaT) = Genome.Split.split gpart_a1ZaS
                      p_a1Za9 = Functions.belowten' g_a1Za8
                      (g_a1Za8, gpart_a1ZaS) = Genome.Split.split gpart_a1ZaR
                      p_a1Za7 = double g_a1Za6
                      (g_a1Za6, gpart_a1ZaR) = Genome.Split.split gpart_a1ZaQ
                      p_a1Za5 = double g_a1Za4
                      (g_a1Za4, gpart_a1ZaQ) = Genome.Split.split gpart_a1ZaP
                      p_a1Za3 = double g_a1Za2
                      (g_a1Za2, gpart_a1ZaP) = Genome.Split.split gpart_a1ZaO
                      p_a1Za1 = Functions.belowten' g_a1Za0
                      (g_a1Za0, gpart_a1ZaO) = Genome.Split.split gpart_a1ZaN
                      p_a1Z9Z = double g_a1Z9Y
                      (g_a1Z9Y, gpart_a1ZaN) = Genome.Split.split gpart_a1ZaM
                      p_a1Z9X
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9W
                      (g_a1Z9W, gpart_a1ZaM) = Genome.Split.split gpart_a1ZaL
                      p_a1Z9V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9U
                      (g_a1Z9U, gpart_a1ZaL) = Genome.Split.split gpart_a1ZaK
                      p_a1Z9T = Functions.belowten' g_a1Z9S
                      (g_a1Z9S, gpart_a1ZaK) = Genome.Split.split gpart_a1ZaJ
                      p_a1Z9R = double g_a1Z9Q
                      (g_a1Z9Q, gpart_a1ZaJ) = Genome.Split.split gpart_a1ZaI
                      p_a1Z9P = double g_a1Z9O
                      (g_a1Z9O, gpart_a1ZaI) = Genome.Split.split gpart_a1ZaH
                      p_a1Z9N = double g_a1Z9M
                      (g_a1Z9M, gpart_a1ZaH) = Genome.Split.split gpart_a1ZaG
                      p_a1Z9L = Functions.belowten' g_a1Z9K
                      (g_a1Z9K, gpart_a1ZaG) = Genome.Split.split gpart_a1ZaF
                      p_a1Z9J = double g_a1Z9I
                      (g_a1Z9I, gpart_a1ZaF) = Genome.Split.split gpart_a1ZaE
                      p_a1Z9H = Functions.belowten' g_a1Z9G
                      (g_a1Z9G, gpart_a1ZaE) = Genome.Split.split gpart_a1ZaD
                      p_a1Z9F = double g_a1Z9E
                      (g_a1Z9E, gpart_a1ZaD) = Genome.Split.split gpart_a1ZaC
                      p_a1Z9D
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9C
                      (g_a1Z9C, gpart_a1ZaC) = Genome.Split.split gpart_a1ZaB
                      p_a1Z9B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9A
                      (g_a1Z9A, gpart_a1ZaB) = Genome.Split.split gpart_a1ZaA
                      p_a1Z9z = double g_a1Z9y
                      (g_a1Z9y, gpart_a1ZaA) = Genome.Split.split gpart_a1Zaz
                      p_a1Z9x = Functions.belowten' g_a1Z9w
                      (g_a1Z9w, gpart_a1Zaz) = Genome.Split.split gpart_a1Zay
                      p_a1Z9v = double g_a1Z9u
                      (g_a1Z9u, gpart_a1Zay) = Genome.Split.split gpart_a1Zax
                      p_a1Z9t = Functions.belowten' g_a1Z9s
                      (g_a1Z9s, gpart_a1Zax) = Genome.Split.split gpart_a1Zaw
                      p_a1Z9r = double g_a1Z9q
                      (g_a1Z9q, gpart_a1Zaw) = Genome.Split.split gpart_a1Zav
                      p_a1Z9p = double g_a1Z9o
                      (g_a1Z9o, gpart_a1Zav) = Genome.Split.split gpart_a1Zau
                      p_a1Z9n = Functions.belowten' g_a1Z9m
                      (g_a1Z9m, gpart_a1Zau) = Genome.Split.split gpart_a1Zat
                      p_a1Z9l = double g_a1Z9k
                      (g_a1Z9k, gpart_a1Zat) = Genome.Split.split gpart_a1Zas
                      p_a1Z9j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9i
                      (g_a1Z9i, gpart_a1Zas) = Genome.Split.split gpart_a1Zar
                      p_a1Z9h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9g
                      (g_a1Z9g, gpart_a1Zar) = Genome.Split.split gpart_a1Zaq
                      p_a1Z9f = double g_a1Z9e
                      (g_a1Z9e, gpart_a1Zaq) = Genome.Split.split gpart_a1Zap
                      p_a1Z9d = double g_a1Z9c
                      (g_a1Z9c, gpart_a1Zap) = Genome.Split.split gpart_a1Zao
                      p_a1Z9b = double g_a1Z9a
                      (g_a1Z9a, gpart_a1Zao) = Genome.Split.split gpart_a1Zan
                      p_a1Z99 = double g_a1Z98
                      (g_a1Z98, gpart_a1Zan) = Genome.Split.split gpart_a1Zam
                      p_a1Z97 = double g_a1Z96
                      (g_a1Z96, gpart_a1Zam) = Genome.Split.split genome_a1Zak
                    in  \ x_a1ZaY
                          -> let
                               c_PTB_a1Zb1
                                 = ((Data.Fixed.Vector.toVector x_a1ZaY) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZaZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZaY) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zb5
                                 = ((Data.Fixed.Vector.toVector x_a1ZaY) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zb7
                                 = ((Data.Fixed.Vector.toVector x_a1ZaY) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zbh
                                 = ((Data.Fixed.Vector.toVector x_a1ZaY) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Z9f / (1 + ((c_MiRs_a1ZaZ / p_a1Z9l) ** p_a1Z9n)))
                                    + (negate (p_a1Zab * c_PTB_a1Zb1))),
                                   ((p_a1Z9p
                                     / (1
                                        + (((c_MiRs_a1ZaZ / p_a1Z9r) ** p_a1Z9t)
                                           + ((c_PTB_a1Zb1 / p_a1Z9v) ** p_a1Z9x))))
                                    + (negate (p_a1Zad * c_NPTB_a1Zb5))),
                                   ((p_a1Z9z
                                     * ((p_a1Z9N + ((p_a1Z9b / p_a1Z9B) ** p_a1Z9D))
                                        / (((1 + p_a1Z9N) + ((p_a1Z9b / p_a1Z9B) ** p_a1Z9D))
                                           + (((c_PTB_a1Zb1 / p_a1Z9F) ** p_a1Z9H)
                                              + ((c_RESTc_a1Zb7 / p_a1Z9J) ** p_a1Z9L)))))
                                    + (negate (p_a1Zaf * c_MiRs_a1ZaZ))),
                                   ((p_a1Z9P
                                     * ((p_a1Za3 + ((c_PTB_a1Zb1 / p_a1Z9R) ** p_a1Z9T))
                                        / (((1 + p_a1Za3) + ((c_PTB_a1Zb1 / p_a1Z9R) ** p_a1Z9T))
                                           + (((p_a1Z97 / p_a1Z9V) ** p_a1Z9X)
                                              + ((c_MiRs_a1ZaZ / p_a1Z9Z) ** p_a1Za1)))))
                                    + (negate (p_a1Zah * c_RESTc_a1Zb7))),
                                   ((p_a1Za5 / (1 + ((c_RESTc_a1Zb7 / p_a1Za7) ** p_a1Za9)))
                                    + (negate (p_a1Zaj * c_EndoNeuroTFs_a1Zbh)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483179",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483181",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483201",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483219",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483221",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zak
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZbT
                            p_a1Zaj = double g_a1Zai
                            (g_a1Zai, gpart_a1ZbT) = Genome.Split.split gpart_a1ZbS
                            p_a1Zah = double g_a1Zag
                            (g_a1Zag, gpart_a1ZbS) = Genome.Split.split gpart_a1ZbR
                            p_a1Zaf = double g_a1Zae
                            (g_a1Zae, gpart_a1ZbR) = Genome.Split.split gpart_a1ZbQ
                            p_a1Zad = double g_a1Zac
                            (g_a1Zac, gpart_a1ZbQ) = Genome.Split.split gpart_a1ZbP
                            p_a1Zab = double g_a1Zaa
                            (g_a1Zaa, gpart_a1ZbP) = Genome.Split.split gpart_a1ZbO
                            p_a1Za9 = Functions.belowten' g_a1Za8
                            (g_a1Za8, gpart_a1ZbO) = Genome.Split.split gpart_a1ZbN
                            p_a1Za7 = double g_a1Za6
                            (g_a1Za6, gpart_a1ZbN) = Genome.Split.split gpart_a1ZbM
                            p_a1Za5 = double g_a1Za4
                            (g_a1Za4, gpart_a1ZbM) = Genome.Split.split gpart_a1ZbL
                            p_a1Za3 = double g_a1Za2
                            (g_a1Za2, gpart_a1ZbL) = Genome.Split.split gpart_a1ZbK
                            p_a1Za1 = Functions.belowten' g_a1Za0
                            (g_a1Za0, gpart_a1ZbK) = Genome.Split.split gpart_a1ZbJ
                            p_a1Z9Z = double g_a1Z9Y
                            (g_a1Z9Y, gpart_a1ZbJ) = Genome.Split.split gpart_a1ZbI
                            p_a1Z9X
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9W
                            (g_a1Z9W, gpart_a1ZbI) = Genome.Split.split gpart_a1ZbH
                            p_a1Z9V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9U
                            (g_a1Z9U, gpart_a1ZbH) = Genome.Split.split gpart_a1ZbG
                            p_a1Z9T = Functions.belowten' g_a1Z9S
                            (g_a1Z9S, gpart_a1ZbG) = Genome.Split.split gpart_a1ZbF
                            p_a1Z9R = double g_a1Z9Q
                            (g_a1Z9Q, gpart_a1ZbF) = Genome.Split.split gpart_a1ZbE
                            p_a1Z9P = double g_a1Z9O
                            (g_a1Z9O, gpart_a1ZbE) = Genome.Split.split gpart_a1ZbD
                            p_a1Z9N = double g_a1Z9M
                            (g_a1Z9M, gpart_a1ZbD) = Genome.Split.split gpart_a1ZbC
                            p_a1Z9L = Functions.belowten' g_a1Z9K
                            (g_a1Z9K, gpart_a1ZbC) = Genome.Split.split gpart_a1ZbB
                            p_a1Z9J = double g_a1Z9I
                            (g_a1Z9I, gpart_a1ZbB) = Genome.Split.split gpart_a1ZbA
                            p_a1Z9H = Functions.belowten' g_a1Z9G
                            (g_a1Z9G, gpart_a1ZbA) = Genome.Split.split gpart_a1Zbz
                            p_a1Z9F = double g_a1Z9E
                            (g_a1Z9E, gpart_a1Zbz) = Genome.Split.split gpart_a1Zby
                            p_a1Z9D
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9C
                            (g_a1Z9C, gpart_a1Zby) = Genome.Split.split gpart_a1Zbx
                            p_a1Z9B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9A
                            (g_a1Z9A, gpart_a1Zbx) = Genome.Split.split gpart_a1Zbw
                            p_a1Z9z = double g_a1Z9y
                            (g_a1Z9y, gpart_a1Zbw) = Genome.Split.split gpart_a1Zbv
                            p_a1Z9x = Functions.belowten' g_a1Z9w
                            (g_a1Z9w, gpart_a1Zbv) = Genome.Split.split gpart_a1Zbu
                            p_a1Z9v = double g_a1Z9u
                            (g_a1Z9u, gpart_a1Zbu) = Genome.Split.split gpart_a1Zbt
                            p_a1Z9t = Functions.belowten' g_a1Z9s
                            (g_a1Z9s, gpart_a1Zbt) = Genome.Split.split gpart_a1Zbs
                            p_a1Z9r = double g_a1Z9q
                            (g_a1Z9q, gpart_a1Zbs) = Genome.Split.split gpart_a1Zbr
                            p_a1Z9p = double g_a1Z9o
                            (g_a1Z9o, gpart_a1Zbr) = Genome.Split.split gpart_a1Zbq
                            p_a1Z9n = Functions.belowten' g_a1Z9m
                            (g_a1Z9m, gpart_a1Zbq) = Genome.Split.split gpart_a1Zbp
                            p_a1Z9l = double g_a1Z9k
                            (g_a1Z9k, gpart_a1Zbp) = Genome.Split.split gpart_a1Zbo
                            p_a1Z9j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9i
                            (g_a1Z9i, gpart_a1Zbo) = Genome.Split.split gpart_a1Zbn
                            p_a1Z9h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9g
                            (g_a1Z9g, gpart_a1Zbn) = Genome.Split.split gpart_a1Zbm
                            p_a1Z9f = double g_a1Z9e
                            (g_a1Z9e, gpart_a1Zbm) = Genome.Split.split gpart_a1Zbl
                            p_a1Z9d = double g_a1Z9c
                            (g_a1Z9c, gpart_a1Zbl) = Genome.Split.split gpart_a1Zbk
                            p_a1Z9b = double g_a1Z9a
                            (g_a1Z9a, gpart_a1Zbk) = Genome.Split.split gpart_a1Zbj
                            p_a1Z99 = double g_a1Z98
                            (g_a1Z98, gpart_a1Zbj) = Genome.Split.split gpart_a1Zbi
                            p_a1Z97 = double g_a1Z96
                            (g_a1Z96, gpart_a1Zbi) = Genome.Split.split genome_a1Zak
                          in
                            \ desc_a1Zal
                              -> case desc_a1Zal of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z97)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z99)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9b)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9d)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9f)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9h)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9j)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9l)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9n)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9p)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9r)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9t)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9v)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9x)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9z)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9B)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9D)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9F)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9H)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9J)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9L)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9N)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9P)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9R)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9T)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9V)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9X)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9Z)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za1)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za3)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za5)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za7)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za9)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zab)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zad)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaf)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zah)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaj)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zeh
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZeU
                      p_a1Zeg = double g_a1Zef
                      (g_a1Zef, gpart_a1ZeU) = Genome.Split.split gpart_a1ZeT
                      p_a1Zee = double g_a1Zed
                      (g_a1Zed, gpart_a1ZeT) = Genome.Split.split gpart_a1ZeS
                      p_a1Zec = double g_a1Zeb
                      (g_a1Zeb, gpart_a1ZeS) = Genome.Split.split gpart_a1ZeR
                      p_a1Zea = double g_a1Ze9
                      (g_a1Ze9, gpart_a1ZeR) = Genome.Split.split gpart_a1ZeQ
                      p_a1Ze8 = double g_a1Ze7
                      (g_a1Ze7, gpart_a1ZeQ) = Genome.Split.split gpart_a1ZeP
                      p_a1Ze6 = Functions.belowten' g_a1Ze5
                      (g_a1Ze5, gpart_a1ZeP) = Genome.Split.split gpart_a1ZeO
                      p_a1Ze4 = double g_a1Ze3
                      (g_a1Ze3, gpart_a1ZeO) = Genome.Split.split gpart_a1ZeN
                      p_a1Ze2 = double g_a1Ze1
                      (g_a1Ze1, gpart_a1ZeN) = Genome.Split.split gpart_a1ZeM
                      p_a1Ze0 = double g_a1ZdZ
                      (g_a1ZdZ, gpart_a1ZeM) = Genome.Split.split gpart_a1ZeL
                      p_a1ZdY = Functions.belowten' g_a1ZdX
                      (g_a1ZdX, gpart_a1ZeL) = Genome.Split.split gpart_a1ZeK
                      p_a1ZdW = double g_a1ZdV
                      (g_a1ZdV, gpart_a1ZeK) = Genome.Split.split gpart_a1ZeJ
                      p_a1ZdU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdT
                      (g_a1ZdT, gpart_a1ZeJ) = Genome.Split.split gpart_a1ZeI
                      p_a1ZdS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdR
                      (g_a1ZdR, gpart_a1ZeI) = Genome.Split.split gpart_a1ZeH
                      p_a1ZdQ = Functions.belowten' g_a1ZdP
                      (g_a1ZdP, gpart_a1ZeH) = Genome.Split.split gpart_a1ZeG
                      p_a1ZdO = double g_a1ZdN
                      (g_a1ZdN, gpart_a1ZeG) = Genome.Split.split gpart_a1ZeF
                      p_a1ZdM = double g_a1ZdL
                      (g_a1ZdL, gpart_a1ZeF) = Genome.Split.split gpart_a1ZeE
                      p_a1ZdK = double g_a1ZdJ
                      (g_a1ZdJ, gpart_a1ZeE) = Genome.Split.split gpart_a1ZeD
                      p_a1ZdI = Functions.belowten' g_a1ZdH
                      (g_a1ZdH, gpart_a1ZeD) = Genome.Split.split gpart_a1ZeC
                      p_a1ZdG = double g_a1ZdF
                      (g_a1ZdF, gpart_a1ZeC) = Genome.Split.split gpart_a1ZeB
                      p_a1ZdE = Functions.belowten' g_a1ZdD
                      (g_a1ZdD, gpart_a1ZeB) = Genome.Split.split gpart_a1ZeA
                      p_a1ZdC = double g_a1ZdB
                      (g_a1ZdB, gpart_a1ZeA) = Genome.Split.split gpart_a1Zez
                      p_a1ZdA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdz
                      (g_a1Zdz, gpart_a1Zez) = Genome.Split.split gpart_a1Zey
                      p_a1Zdy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdx
                      (g_a1Zdx, gpart_a1Zey) = Genome.Split.split gpart_a1Zex
                      p_a1Zdw = double g_a1Zdv
                      (g_a1Zdv, gpart_a1Zex) = Genome.Split.split gpart_a1Zew
                      p_a1Zdu = Functions.belowten' g_a1Zdt
                      (g_a1Zdt, gpart_a1Zew) = Genome.Split.split gpart_a1Zev
                      p_a1Zds = double g_a1Zdr
                      (g_a1Zdr, gpart_a1Zev) = Genome.Split.split gpart_a1Zeu
                      p_a1Zdq = Functions.belowten' g_a1Zdp
                      (g_a1Zdp, gpart_a1Zeu) = Genome.Split.split gpart_a1Zet
                      p_a1Zdo = double g_a1Zdn
                      (g_a1Zdn, gpart_a1Zet) = Genome.Split.split gpart_a1Zes
                      p_a1Zdm = double g_a1Zdl
                      (g_a1Zdl, gpart_a1Zes) = Genome.Split.split gpart_a1Zer
                      p_a1Zdk = Functions.belowten' g_a1Zdj
                      (g_a1Zdj, gpart_a1Zer) = Genome.Split.split gpart_a1Zeq
                      p_a1Zdi = double g_a1Zdh
                      (g_a1Zdh, gpart_a1Zeq) = Genome.Split.split gpart_a1Zep
                      p_a1Zdg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdf
                      (g_a1Zdf, gpart_a1Zep) = Genome.Split.split gpart_a1Zeo
                      p_a1Zde
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdd
                      (g_a1Zdd, gpart_a1Zeo) = Genome.Split.split gpart_a1Zen
                      p_a1Zdc = double g_a1Zdb
                      (g_a1Zdb, gpart_a1Zen) = Genome.Split.split gpart_a1Zem
                      p_a1Zda = double g_a1Zd9
                      (g_a1Zd9, gpart_a1Zem) = Genome.Split.split gpart_a1Zel
                      p_a1Zd8 = double g_a1Zd7
                      (g_a1Zd7, gpart_a1Zel) = Genome.Split.split gpart_a1Zek
                      p_a1Zd6 = double g_a1Zd5
                      (g_a1Zd5, gpart_a1Zek) = Genome.Split.split gpart_a1Zej
                      p_a1Zd4 = double g_a1Zd3
                      (g_a1Zd3, gpart_a1Zej) = Genome.Split.split genome_a1Zeh
                    in  \ x_a1ZeV
                          -> let
                               c_PTB_a1ZeY
                                 = ((Data.Fixed.Vector.toVector x_a1ZeV) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZeW
                                 = ((Data.Fixed.Vector.toVector x_a1ZeV) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zf2
                                 = ((Data.Fixed.Vector.toVector x_a1ZeV) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zf4
                                 = ((Data.Fixed.Vector.toVector x_a1ZeV) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zfe
                                 = ((Data.Fixed.Vector.toVector x_a1ZeV) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zdc / (1 + ((c_MiRs_a1ZeW / p_a1Zdi) ** p_a1Zdk)))
                                    + (negate (p_a1Ze8 * c_PTB_a1ZeY))),
                                   ((p_a1Zdm
                                     / (1
                                        + (((c_MiRs_a1ZeW / p_a1Zdo) ** p_a1Zdq)
                                           + ((c_PTB_a1ZeY / p_a1Zds) ** p_a1Zdu))))
                                    + (negate (p_a1Zea * c_NPTB_a1Zf2))),
                                   ((p_a1Zdw
                                     * (p_a1ZdK
                                        / ((1 + p_a1ZdK)
                                           + (((c_PTB_a1ZeY / p_a1ZdC) ** p_a1ZdE)
                                              + ((c_RESTc_a1Zf4 / p_a1ZdG) ** p_a1ZdI)))))
                                    + (negate (p_a1Zec * c_MiRs_a1ZeW))),
                                   ((p_a1ZdM
                                     * ((p_a1Ze0 + ((c_PTB_a1ZeY / p_a1ZdO) ** p_a1ZdQ))
                                        / (((1 + p_a1Ze0) + ((c_PTB_a1ZeY / p_a1ZdO) ** p_a1ZdQ))
                                           + (((p_a1Zd4 / p_a1ZdS) ** p_a1ZdU)
                                              + ((c_MiRs_a1ZeW / p_a1ZdW) ** p_a1ZdY)))))
                                    + (negate (p_a1Zee * c_RESTc_a1Zf4))),
                                   ((p_a1Ze2 / (1 + ((c_RESTc_a1Zf4 / p_a1Ze4) ** p_a1Ze6)))
                                    + (negate (p_a1Zeg * c_EndoNeuroTFs_a1Zfe)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483424",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483426",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483444",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483446",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483464",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483466",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zeh
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZfQ
                            p_a1Zeg = double g_a1Zef
                            (g_a1Zef, gpart_a1ZfQ) = Genome.Split.split gpart_a1ZfP
                            p_a1Zee = double g_a1Zed
                            (g_a1Zed, gpart_a1ZfP) = Genome.Split.split gpart_a1ZfO
                            p_a1Zec = double g_a1Zeb
                            (g_a1Zeb, gpart_a1ZfO) = Genome.Split.split gpart_a1ZfN
                            p_a1Zea = double g_a1Ze9
                            (g_a1Ze9, gpart_a1ZfN) = Genome.Split.split gpart_a1ZfM
                            p_a1Ze8 = double g_a1Ze7
                            (g_a1Ze7, gpart_a1ZfM) = Genome.Split.split gpart_a1ZfL
                            p_a1Ze6 = Functions.belowten' g_a1Ze5
                            (g_a1Ze5, gpart_a1ZfL) = Genome.Split.split gpart_a1ZfK
                            p_a1Ze4 = double g_a1Ze3
                            (g_a1Ze3, gpart_a1ZfK) = Genome.Split.split gpart_a1ZfJ
                            p_a1Ze2 = double g_a1Ze1
                            (g_a1Ze1, gpart_a1ZfJ) = Genome.Split.split gpart_a1ZfI
                            p_a1Ze0 = double g_a1ZdZ
                            (g_a1ZdZ, gpart_a1ZfI) = Genome.Split.split gpart_a1ZfH
                            p_a1ZdY = Functions.belowten' g_a1ZdX
                            (g_a1ZdX, gpart_a1ZfH) = Genome.Split.split gpart_a1ZfG
                            p_a1ZdW = double g_a1ZdV
                            (g_a1ZdV, gpart_a1ZfG) = Genome.Split.split gpart_a1ZfF
                            p_a1ZdU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdT
                            (g_a1ZdT, gpart_a1ZfF) = Genome.Split.split gpart_a1ZfE
                            p_a1ZdS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdR
                            (g_a1ZdR, gpart_a1ZfE) = Genome.Split.split gpart_a1ZfD
                            p_a1ZdQ = Functions.belowten' g_a1ZdP
                            (g_a1ZdP, gpart_a1ZfD) = Genome.Split.split gpart_a1ZfC
                            p_a1ZdO = double g_a1ZdN
                            (g_a1ZdN, gpart_a1ZfC) = Genome.Split.split gpart_a1ZfB
                            p_a1ZdM = double g_a1ZdL
                            (g_a1ZdL, gpart_a1ZfB) = Genome.Split.split gpart_a1ZfA
                            p_a1ZdK = double g_a1ZdJ
                            (g_a1ZdJ, gpart_a1ZfA) = Genome.Split.split gpart_a1Zfz
                            p_a1ZdI = Functions.belowten' g_a1ZdH
                            (g_a1ZdH, gpart_a1Zfz) = Genome.Split.split gpart_a1Zfy
                            p_a1ZdG = double g_a1ZdF
                            (g_a1ZdF, gpart_a1Zfy) = Genome.Split.split gpart_a1Zfx
                            p_a1ZdE = Functions.belowten' g_a1ZdD
                            (g_a1ZdD, gpart_a1Zfx) = Genome.Split.split gpart_a1Zfw
                            p_a1ZdC = double g_a1ZdB
                            (g_a1ZdB, gpart_a1Zfw) = Genome.Split.split gpart_a1Zfv
                            p_a1ZdA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdz
                            (g_a1Zdz, gpart_a1Zfv) = Genome.Split.split gpart_a1Zfu
                            p_a1Zdy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdx
                            (g_a1Zdx, gpart_a1Zfu) = Genome.Split.split gpart_a1Zft
                            p_a1Zdw = double g_a1Zdv
                            (g_a1Zdv, gpart_a1Zft) = Genome.Split.split gpart_a1Zfs
                            p_a1Zdu = Functions.belowten' g_a1Zdt
                            (g_a1Zdt, gpart_a1Zfs) = Genome.Split.split gpart_a1Zfr
                            p_a1Zds = double g_a1Zdr
                            (g_a1Zdr, gpart_a1Zfr) = Genome.Split.split gpart_a1Zfq
                            p_a1Zdq = Functions.belowten' g_a1Zdp
                            (g_a1Zdp, gpart_a1Zfq) = Genome.Split.split gpart_a1Zfp
                            p_a1Zdo = double g_a1Zdn
                            (g_a1Zdn, gpart_a1Zfp) = Genome.Split.split gpart_a1Zfo
                            p_a1Zdm = double g_a1Zdl
                            (g_a1Zdl, gpart_a1Zfo) = Genome.Split.split gpart_a1Zfn
                            p_a1Zdk = Functions.belowten' g_a1Zdj
                            (g_a1Zdj, gpart_a1Zfn) = Genome.Split.split gpart_a1Zfm
                            p_a1Zdi = double g_a1Zdh
                            (g_a1Zdh, gpart_a1Zfm) = Genome.Split.split gpart_a1Zfl
                            p_a1Zdg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdf
                            (g_a1Zdf, gpart_a1Zfl) = Genome.Split.split gpart_a1Zfk
                            p_a1Zde
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zdd
                            (g_a1Zdd, gpart_a1Zfk) = Genome.Split.split gpart_a1Zfj
                            p_a1Zdc = double g_a1Zdb
                            (g_a1Zdb, gpart_a1Zfj) = Genome.Split.split gpart_a1Zfi
                            p_a1Zda = double g_a1Zd9
                            (g_a1Zd9, gpart_a1Zfi) = Genome.Split.split gpart_a1Zfh
                            p_a1Zd8 = double g_a1Zd7
                            (g_a1Zd7, gpart_a1Zfh) = Genome.Split.split gpart_a1Zfg
                            p_a1Zd6 = double g_a1Zd5
                            (g_a1Zd5, gpart_a1Zfg) = Genome.Split.split gpart_a1Zff
                            p_a1Zd4 = double g_a1Zd3
                            (g_a1Zd3, gpart_a1Zff) = Genome.Split.split genome_a1Zeh
                          in
                            \ desc_a1Zei
                              -> case desc_a1Zei of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd4)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd6)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zd8)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zda)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdc)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zde)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdg)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdi)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdk)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdm)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdo)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdq)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zds)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdu)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdw)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdy)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdA)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdC)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdE)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdG)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdI)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdK)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdM)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdO)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdQ)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdS)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdU)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdW)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdY)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze0)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze2)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze4)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze6)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze8)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zea)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zec)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zee)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeg)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zie
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZiR
                      p_a1Zid = double g_a1Zic
                      (g_a1Zic, gpart_a1ZiR) = Genome.Split.split gpart_a1ZiQ
                      p_a1Zib = double g_a1Zia
                      (g_a1Zia, gpart_a1ZiQ) = Genome.Split.split gpart_a1ZiP
                      p_a1Zi9 = double g_a1Zi8
                      (g_a1Zi8, gpart_a1ZiP) = Genome.Split.split gpart_a1ZiO
                      p_a1Zi7 = double g_a1Zi6
                      (g_a1Zi6, gpart_a1ZiO) = Genome.Split.split gpart_a1ZiN
                      p_a1Zi5 = double g_a1Zi4
                      (g_a1Zi4, gpart_a1ZiN) = Genome.Split.split gpart_a1ZiM
                      p_a1Zi3 = Functions.belowten' g_a1Zi2
                      (g_a1Zi2, gpart_a1ZiM) = Genome.Split.split gpart_a1ZiL
                      p_a1Zi1 = double g_a1Zi0
                      (g_a1Zi0, gpart_a1ZiL) = Genome.Split.split gpart_a1ZiK
                      p_a1ZhZ = double g_a1ZhY
                      (g_a1ZhY, gpart_a1ZiK) = Genome.Split.split gpart_a1ZiJ
                      p_a1ZhX = double g_a1ZhW
                      (g_a1ZhW, gpart_a1ZiJ) = Genome.Split.split gpart_a1ZiI
                      p_a1ZhV = Functions.belowten' g_a1ZhU
                      (g_a1ZhU, gpart_a1ZiI) = Genome.Split.split gpart_a1ZiH
                      p_a1ZhT = double g_a1ZhS
                      (g_a1ZhS, gpart_a1ZiH) = Genome.Split.split gpart_a1ZiG
                      p_a1ZhR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhQ
                      (g_a1ZhQ, gpart_a1ZiG) = Genome.Split.split gpart_a1ZiF
                      p_a1ZhP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhO
                      (g_a1ZhO, gpart_a1ZiF) = Genome.Split.split gpart_a1ZiE
                      p_a1ZhN = Functions.belowten' g_a1ZhM
                      (g_a1ZhM, gpart_a1ZiE) = Genome.Split.split gpart_a1ZiD
                      p_a1ZhL = double g_a1ZhK
                      (g_a1ZhK, gpart_a1ZiD) = Genome.Split.split gpart_a1ZiC
                      p_a1ZhJ = double g_a1ZhI
                      (g_a1ZhI, gpart_a1ZiC) = Genome.Split.split gpart_a1ZiB
                      p_a1ZhH = double g_a1ZhG
                      (g_a1ZhG, gpart_a1ZiB) = Genome.Split.split gpart_a1ZiA
                      p_a1ZhF = Functions.belowten' g_a1ZhE
                      (g_a1ZhE, gpart_a1ZiA) = Genome.Split.split gpart_a1Ziz
                      p_a1ZhD = double g_a1ZhC
                      (g_a1ZhC, gpart_a1Ziz) = Genome.Split.split gpart_a1Ziy
                      p_a1ZhB = Functions.belowten' g_a1ZhA
                      (g_a1ZhA, gpart_a1Ziy) = Genome.Split.split gpart_a1Zix
                      p_a1Zhz = double g_a1Zhy
                      (g_a1Zhy, gpart_a1Zix) = Genome.Split.split gpart_a1Ziw
                      p_a1Zhx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhw
                      (g_a1Zhw, gpart_a1Ziw) = Genome.Split.split gpart_a1Ziv
                      p_a1Zhv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhu
                      (g_a1Zhu, gpart_a1Ziv) = Genome.Split.split gpart_a1Ziu
                      p_a1Zht = double g_a1Zhs
                      (g_a1Zhs, gpart_a1Ziu) = Genome.Split.split gpart_a1Zit
                      p_a1Zhr = Functions.belowten' g_a1Zhq
                      (g_a1Zhq, gpart_a1Zit) = Genome.Split.split gpart_a1Zis
                      p_a1Zhp = double g_a1Zho
                      (g_a1Zho, gpart_a1Zis) = Genome.Split.split gpart_a1Zir
                      p_a1Zhn = Functions.belowten' g_a1Zhm
                      (g_a1Zhm, gpart_a1Zir) = Genome.Split.split gpart_a1Ziq
                      p_a1Zhl = double g_a1Zhk
                      (g_a1Zhk, gpart_a1Ziq) = Genome.Split.split gpart_a1Zip
                      p_a1Zhj = double g_a1Zhi
                      (g_a1Zhi, gpart_a1Zip) = Genome.Split.split gpart_a1Zio
                      p_a1Zhh = Functions.belowten' g_a1Zhg
                      (g_a1Zhg, gpart_a1Zio) = Genome.Split.split gpart_a1Zin
                      p_a1Zhf = double g_a1Zhe
                      (g_a1Zhe, gpart_a1Zin) = Genome.Split.split gpart_a1Zim
                      p_a1Zhd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhc
                      (g_a1Zhc, gpart_a1Zim) = Genome.Split.split gpart_a1Zil
                      p_a1Zhb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zha
                      (g_a1Zha, gpart_a1Zil) = Genome.Split.split gpart_a1Zik
                      p_a1Zh9 = double g_a1Zh8
                      (g_a1Zh8, gpart_a1Zik) = Genome.Split.split gpart_a1Zij
                      p_a1Zh7 = double g_a1Zh6
                      (g_a1Zh6, gpart_a1Zij) = Genome.Split.split gpart_a1Zii
                      p_a1Zh5 = double g_a1Zh4
                      (g_a1Zh4, gpart_a1Zii) = Genome.Split.split gpart_a1Zih
                      p_a1Zh3 = double g_a1Zh2
                      (g_a1Zh2, gpart_a1Zih) = Genome.Split.split gpart_a1Zig
                      p_a1Zh1 = double g_a1Zh0
                      (g_a1Zh0, gpart_a1Zig) = Genome.Split.split genome_a1Zie
                    in  \ x_a1ZiS
                          -> let
                               c_PTB_a1ZiV
                                 = ((Data.Fixed.Vector.toVector x_a1ZiS) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZiT
                                 = ((Data.Fixed.Vector.toVector x_a1ZiS) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZiZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZiS) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zj1
                                 = ((Data.Fixed.Vector.toVector x_a1ZiS) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zjb
                                 = ((Data.Fixed.Vector.toVector x_a1ZiS) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zh9 / (1 + ((c_MiRs_a1ZiT / p_a1Zhf) ** p_a1Zhh)))
                                    + (negate (p_a1Zi5 * c_PTB_a1ZiV))),
                                   ((p_a1Zhj
                                     / (1
                                        + (((c_MiRs_a1ZiT / p_a1Zhl) ** p_a1Zhn)
                                           + ((c_PTB_a1ZiV / p_a1Zhp) ** p_a1Zhr))))
                                    + (negate (p_a1Zi7 * c_NPTB_a1ZiZ))),
                                   ((p_a1Zht
                                     * (p_a1ZhH
                                        / ((1 + p_a1ZhH)
                                           + (((c_PTB_a1ZiV / p_a1Zhz) ** p_a1ZhB)
                                              + ((c_RESTc_a1Zj1 / p_a1ZhD) ** p_a1ZhF)))))
                                    + (negate (p_a1Zi9 * c_MiRs_a1ZiT))),
                                   ((p_a1ZhJ
                                     * ((p_a1ZhX + ((c_PTB_a1ZiV / p_a1ZhL) ** p_a1ZhN))
                                        / (((1 + p_a1ZhX) + ((c_PTB_a1ZiV / p_a1ZhL) ** p_a1ZhN))
                                           + ((c_MiRs_a1ZiT / p_a1ZhT) ** p_a1ZhV))))
                                    + (negate (p_a1Zib * c_RESTc_a1Zj1))),
                                   ((p_a1ZhZ / (1 + ((c_RESTc_a1Zj1 / p_a1Zi1) ** p_a1Zi3)))
                                    + (negate (p_a1Zid * c_EndoNeuroTFs_a1Zjb)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483671",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483689",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483691",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483709",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483711",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zie
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZjN
                            p_a1Zid = double g_a1Zic
                            (g_a1Zic, gpart_a1ZjN) = Genome.Split.split gpart_a1ZjM
                            p_a1Zib = double g_a1Zia
                            (g_a1Zia, gpart_a1ZjM) = Genome.Split.split gpart_a1ZjL
                            p_a1Zi9 = double g_a1Zi8
                            (g_a1Zi8, gpart_a1ZjL) = Genome.Split.split gpart_a1ZjK
                            p_a1Zi7 = double g_a1Zi6
                            (g_a1Zi6, gpart_a1ZjK) = Genome.Split.split gpart_a1ZjJ
                            p_a1Zi5 = double g_a1Zi4
                            (g_a1Zi4, gpart_a1ZjJ) = Genome.Split.split gpart_a1ZjI
                            p_a1Zi3 = Functions.belowten' g_a1Zi2
                            (g_a1Zi2, gpart_a1ZjI) = Genome.Split.split gpart_a1ZjH
                            p_a1Zi1 = double g_a1Zi0
                            (g_a1Zi0, gpart_a1ZjH) = Genome.Split.split gpart_a1ZjG
                            p_a1ZhZ = double g_a1ZhY
                            (g_a1ZhY, gpart_a1ZjG) = Genome.Split.split gpart_a1ZjF
                            p_a1ZhX = double g_a1ZhW
                            (g_a1ZhW, gpart_a1ZjF) = Genome.Split.split gpart_a1ZjE
                            p_a1ZhV = Functions.belowten' g_a1ZhU
                            (g_a1ZhU, gpart_a1ZjE) = Genome.Split.split gpart_a1ZjD
                            p_a1ZhT = double g_a1ZhS
                            (g_a1ZhS, gpart_a1ZjD) = Genome.Split.split gpart_a1ZjC
                            p_a1ZhR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhQ
                            (g_a1ZhQ, gpart_a1ZjC) = Genome.Split.split gpart_a1ZjB
                            p_a1ZhP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhO
                            (g_a1ZhO, gpart_a1ZjB) = Genome.Split.split gpart_a1ZjA
                            p_a1ZhN = Functions.belowten' g_a1ZhM
                            (g_a1ZhM, gpart_a1ZjA) = Genome.Split.split gpart_a1Zjz
                            p_a1ZhL = double g_a1ZhK
                            (g_a1ZhK, gpart_a1Zjz) = Genome.Split.split gpart_a1Zjy
                            p_a1ZhJ = double g_a1ZhI
                            (g_a1ZhI, gpart_a1Zjy) = Genome.Split.split gpart_a1Zjx
                            p_a1ZhH = double g_a1ZhG
                            (g_a1ZhG, gpart_a1Zjx) = Genome.Split.split gpart_a1Zjw
                            p_a1ZhF = Functions.belowten' g_a1ZhE
                            (g_a1ZhE, gpart_a1Zjw) = Genome.Split.split gpart_a1Zjv
                            p_a1ZhD = double g_a1ZhC
                            (g_a1ZhC, gpart_a1Zjv) = Genome.Split.split gpart_a1Zju
                            p_a1ZhB = Functions.belowten' g_a1ZhA
                            (g_a1ZhA, gpart_a1Zju) = Genome.Split.split gpart_a1Zjt
                            p_a1Zhz = double g_a1Zhy
                            (g_a1Zhy, gpart_a1Zjt) = Genome.Split.split gpart_a1Zjs
                            p_a1Zhx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhw
                            (g_a1Zhw, gpart_a1Zjs) = Genome.Split.split gpart_a1Zjr
                            p_a1Zhv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhu
                            (g_a1Zhu, gpart_a1Zjr) = Genome.Split.split gpart_a1Zjq
                            p_a1Zht = double g_a1Zhs
                            (g_a1Zhs, gpart_a1Zjq) = Genome.Split.split gpart_a1Zjp
                            p_a1Zhr = Functions.belowten' g_a1Zhq
                            (g_a1Zhq, gpart_a1Zjp) = Genome.Split.split gpart_a1Zjo
                            p_a1Zhp = double g_a1Zho
                            (g_a1Zho, gpart_a1Zjo) = Genome.Split.split gpart_a1Zjn
                            p_a1Zhn = Functions.belowten' g_a1Zhm
                            (g_a1Zhm, gpart_a1Zjn) = Genome.Split.split gpart_a1Zjm
                            p_a1Zhl = double g_a1Zhk
                            (g_a1Zhk, gpart_a1Zjm) = Genome.Split.split gpart_a1Zjl
                            p_a1Zhj = double g_a1Zhi
                            (g_a1Zhi, gpart_a1Zjl) = Genome.Split.split gpart_a1Zjk
                            p_a1Zhh = Functions.belowten' g_a1Zhg
                            (g_a1Zhg, gpart_a1Zjk) = Genome.Split.split gpart_a1Zjj
                            p_a1Zhf = double g_a1Zhe
                            (g_a1Zhe, gpart_a1Zjj) = Genome.Split.split gpart_a1Zji
                            p_a1Zhd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhc
                            (g_a1Zhc, gpart_a1Zji) = Genome.Split.split gpart_a1Zjh
                            p_a1Zhb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zha
                            (g_a1Zha, gpart_a1Zjh) = Genome.Split.split gpart_a1Zjg
                            p_a1Zh9 = double g_a1Zh8
                            (g_a1Zh8, gpart_a1Zjg) = Genome.Split.split gpart_a1Zjf
                            p_a1Zh7 = double g_a1Zh6
                            (g_a1Zh6, gpart_a1Zjf) = Genome.Split.split gpart_a1Zje
                            p_a1Zh5 = double g_a1Zh4
                            (g_a1Zh4, gpart_a1Zje) = Genome.Split.split gpart_a1Zjd
                            p_a1Zh3 = double g_a1Zh2
                            (g_a1Zh2, gpart_a1Zjd) = Genome.Split.split gpart_a1Zjc
                            p_a1Zh1 = double g_a1Zh0
                            (g_a1Zh0, gpart_a1Zjc) = Genome.Split.split genome_a1Zie
                          in
                            \ desc_a1Zif
                              -> case desc_a1Zif of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh1)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh3)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh5)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh7)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zh9)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhb)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhd)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhf)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhh)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zht)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhv)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhx)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhz)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhB)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhD)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhF)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhH)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhJ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhL)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhN)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhP)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhR)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhT)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhV)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhX)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi1)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi3)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi5)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi7)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi9)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zib)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zid)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zmb
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZmO
                      p_a1Zma = double g_a1Zm9
                      (g_a1Zm9, gpart_a1ZmO) = Genome.Split.split gpart_a1ZmN
                      p_a1Zm8 = double g_a1Zm7
                      (g_a1Zm7, gpart_a1ZmN) = Genome.Split.split gpart_a1ZmM
                      p_a1Zm6 = double g_a1Zm5
                      (g_a1Zm5, gpart_a1ZmM) = Genome.Split.split gpart_a1ZmL
                      p_a1Zm4 = double g_a1Zm3
                      (g_a1Zm3, gpart_a1ZmL) = Genome.Split.split gpart_a1ZmK
                      p_a1Zm2 = double g_a1Zm1
                      (g_a1Zm1, gpart_a1ZmK) = Genome.Split.split gpart_a1ZmJ
                      p_a1Zm0 = Functions.belowten' g_a1ZlZ
                      (g_a1ZlZ, gpart_a1ZmJ) = Genome.Split.split gpart_a1ZmI
                      p_a1ZlY = double g_a1ZlX
                      (g_a1ZlX, gpart_a1ZmI) = Genome.Split.split gpart_a1ZmH
                      p_a1ZlW = double g_a1ZlV
                      (g_a1ZlV, gpart_a1ZmH) = Genome.Split.split gpart_a1ZmG
                      p_a1ZlU = double g_a1ZlT
                      (g_a1ZlT, gpart_a1ZmG) = Genome.Split.split gpart_a1ZmF
                      p_a1ZlS = Functions.belowten' g_a1ZlR
                      (g_a1ZlR, gpart_a1ZmF) = Genome.Split.split gpart_a1ZmE
                      p_a1ZlQ = double g_a1ZlP
                      (g_a1ZlP, gpart_a1ZmE) = Genome.Split.split gpart_a1ZmD
                      p_a1ZlO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlN
                      (g_a1ZlN, gpart_a1ZmD) = Genome.Split.split gpart_a1ZmC
                      p_a1ZlM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlL
                      (g_a1ZlL, gpart_a1ZmC) = Genome.Split.split gpart_a1ZmB
                      p_a1ZlK = Functions.belowten' g_a1ZlJ
                      (g_a1ZlJ, gpart_a1ZmB) = Genome.Split.split gpart_a1ZmA
                      p_a1ZlI = double g_a1ZlH
                      (g_a1ZlH, gpart_a1ZmA) = Genome.Split.split gpart_a1Zmz
                      p_a1ZlG = double g_a1ZlF
                      (g_a1ZlF, gpart_a1Zmz) = Genome.Split.split gpart_a1Zmy
                      p_a1ZlE = double g_a1ZlD
                      (g_a1ZlD, gpart_a1Zmy) = Genome.Split.split gpart_a1Zmx
                      p_a1ZlC = Functions.belowten' g_a1ZlB
                      (g_a1ZlB, gpart_a1Zmx) = Genome.Split.split gpart_a1Zmw
                      p_a1ZlA = double g_a1Zlz
                      (g_a1Zlz, gpart_a1Zmw) = Genome.Split.split gpart_a1Zmv
                      p_a1Zly = Functions.belowten' g_a1Zlx
                      (g_a1Zlx, gpart_a1Zmv) = Genome.Split.split gpart_a1Zmu
                      p_a1Zlw = double g_a1Zlv
                      (g_a1Zlv, gpart_a1Zmu) = Genome.Split.split gpart_a1Zmt
                      p_a1Zlu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlt
                      (g_a1Zlt, gpart_a1Zmt) = Genome.Split.split gpart_a1Zms
                      p_a1Zls
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlr
                      (g_a1Zlr, gpart_a1Zms) = Genome.Split.split gpart_a1Zmr
                      p_a1Zlq = double g_a1Zlp
                      (g_a1Zlp, gpart_a1Zmr) = Genome.Split.split gpart_a1Zmq
                      p_a1Zlo = Functions.belowten' g_a1Zln
                      (g_a1Zln, gpart_a1Zmq) = Genome.Split.split gpart_a1Zmp
                      p_a1Zlm = double g_a1Zll
                      (g_a1Zll, gpart_a1Zmp) = Genome.Split.split gpart_a1Zmo
                      p_a1Zlk = Functions.belowten' g_a1Zlj
                      (g_a1Zlj, gpart_a1Zmo) = Genome.Split.split gpart_a1Zmn
                      p_a1Zli = double g_a1Zlh
                      (g_a1Zlh, gpart_a1Zmn) = Genome.Split.split gpart_a1Zmm
                      p_a1Zlg = double g_a1Zlf
                      (g_a1Zlf, gpart_a1Zmm) = Genome.Split.split gpart_a1Zml
                      p_a1Zle = Functions.belowten' g_a1Zld
                      (g_a1Zld, gpart_a1Zml) = Genome.Split.split gpart_a1Zmk
                      p_a1Zlc = double g_a1Zlb
                      (g_a1Zlb, gpart_a1Zmk) = Genome.Split.split gpart_a1Zmj
                      p_a1Zla
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl9
                      (g_a1Zl9, gpart_a1Zmj) = Genome.Split.split gpart_a1Zmi
                      p_a1Zl8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl7
                      (g_a1Zl7, gpart_a1Zmi) = Genome.Split.split gpart_a1Zmh
                      p_a1Zl6 = double g_a1Zl5
                      (g_a1Zl5, gpart_a1Zmh) = Genome.Split.split gpart_a1Zmg
                      p_a1Zl4 = double g_a1Zl3
                      (g_a1Zl3, gpart_a1Zmg) = Genome.Split.split gpart_a1Zmf
                      p_a1Zl2 = double g_a1Zl1
                      (g_a1Zl1, gpart_a1Zmf) = Genome.Split.split gpart_a1Zme
                      p_a1Zl0 = double g_a1ZkZ
                      (g_a1ZkZ, gpart_a1Zme) = Genome.Split.split gpart_a1Zmd
                      p_a1ZkY = double g_a1ZkX
                      (g_a1ZkX, gpart_a1Zmd) = Genome.Split.split genome_a1Zmb
                    in  \ x_a1ZmP
                          -> let
                               c_PTB_a1ZmS
                                 = ((Data.Fixed.Vector.toVector x_a1ZmP) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZmQ
                                 = ((Data.Fixed.Vector.toVector x_a1ZmP) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZmW
                                 = ((Data.Fixed.Vector.toVector x_a1ZmP) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZmY
                                 = ((Data.Fixed.Vector.toVector x_a1ZmP) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zn8
                                 = ((Data.Fixed.Vector.toVector x_a1ZmP) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zl6
                                     / (1
                                        + (((p_a1ZkY / p_a1Zl8) ** p_a1Zla)
                                           + ((c_MiRs_a1ZmQ / p_a1Zlc) ** p_a1Zle))))
                                    + (negate (p_a1Zm2 * c_PTB_a1ZmS))),
                                   ((p_a1Zlg
                                     / (1
                                        + (((c_MiRs_a1ZmQ / p_a1Zli) ** p_a1Zlk)
                                           + ((c_PTB_a1ZmS / p_a1Zlm) ** p_a1Zlo))))
                                    + (negate (p_a1Zm4 * c_NPTB_a1ZmW))),
                                   ((p_a1Zlq
                                     * (p_a1ZlE
                                        / ((1 + p_a1ZlE)
                                           + (((c_PTB_a1ZmS / p_a1Zlw) ** p_a1Zly)
                                              + ((c_RESTc_a1ZmY / p_a1ZlA) ** p_a1ZlC)))))
                                    + (negate (p_a1Zm6 * c_MiRs_a1ZmQ))),
                                   ((p_a1ZlG
                                     * ((p_a1ZlU + ((c_PTB_a1ZmS / p_a1ZlI) ** p_a1ZlK))
                                        / (((1 + p_a1ZlU) + ((c_PTB_a1ZmS / p_a1ZlI) ** p_a1ZlK))
                                           + ((c_MiRs_a1ZmQ / p_a1ZlQ) ** p_a1ZlS))))
                                    + (negate (p_a1Zm8 * c_RESTc_a1ZmY))),
                                   ((p_a1ZlW / (1 + ((c_RESTc_a1ZmY / p_a1ZlY) ** p_a1Zm0)))
                                    + (negate (p_a1Zma * c_EndoNeuroTFs_a1Zn8)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483914",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483916",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483934",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483936",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483954",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483956",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zmb
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZnK
                            p_a1Zma = double g_a1Zm9
                            (g_a1Zm9, gpart_a1ZnK) = Genome.Split.split gpart_a1ZnJ
                            p_a1Zm8 = double g_a1Zm7
                            (g_a1Zm7, gpart_a1ZnJ) = Genome.Split.split gpart_a1ZnI
                            p_a1Zm6 = double g_a1Zm5
                            (g_a1Zm5, gpart_a1ZnI) = Genome.Split.split gpart_a1ZnH
                            p_a1Zm4 = double g_a1Zm3
                            (g_a1Zm3, gpart_a1ZnH) = Genome.Split.split gpart_a1ZnG
                            p_a1Zm2 = double g_a1Zm1
                            (g_a1Zm1, gpart_a1ZnG) = Genome.Split.split gpart_a1ZnF
                            p_a1Zm0 = Functions.belowten' g_a1ZlZ
                            (g_a1ZlZ, gpart_a1ZnF) = Genome.Split.split gpart_a1ZnE
                            p_a1ZlY = double g_a1ZlX
                            (g_a1ZlX, gpart_a1ZnE) = Genome.Split.split gpart_a1ZnD
                            p_a1ZlW = double g_a1ZlV
                            (g_a1ZlV, gpart_a1ZnD) = Genome.Split.split gpart_a1ZnC
                            p_a1ZlU = double g_a1ZlT
                            (g_a1ZlT, gpart_a1ZnC) = Genome.Split.split gpart_a1ZnB
                            p_a1ZlS = Functions.belowten' g_a1ZlR
                            (g_a1ZlR, gpart_a1ZnB) = Genome.Split.split gpart_a1ZnA
                            p_a1ZlQ = double g_a1ZlP
                            (g_a1ZlP, gpart_a1ZnA) = Genome.Split.split gpart_a1Znz
                            p_a1ZlO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlN
                            (g_a1ZlN, gpart_a1Znz) = Genome.Split.split gpart_a1Zny
                            p_a1ZlM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlL
                            (g_a1ZlL, gpart_a1Zny) = Genome.Split.split gpart_a1Znx
                            p_a1ZlK = Functions.belowten' g_a1ZlJ
                            (g_a1ZlJ, gpart_a1Znx) = Genome.Split.split gpart_a1Znw
                            p_a1ZlI = double g_a1ZlH
                            (g_a1ZlH, gpart_a1Znw) = Genome.Split.split gpart_a1Znv
                            p_a1ZlG = double g_a1ZlF
                            (g_a1ZlF, gpart_a1Znv) = Genome.Split.split gpart_a1Znu
                            p_a1ZlE = double g_a1ZlD
                            (g_a1ZlD, gpart_a1Znu) = Genome.Split.split gpart_a1Znt
                            p_a1ZlC = Functions.belowten' g_a1ZlB
                            (g_a1ZlB, gpart_a1Znt) = Genome.Split.split gpart_a1Zns
                            p_a1ZlA = double g_a1Zlz
                            (g_a1Zlz, gpart_a1Zns) = Genome.Split.split gpart_a1Znr
                            p_a1Zly = Functions.belowten' g_a1Zlx
                            (g_a1Zlx, gpart_a1Znr) = Genome.Split.split gpart_a1Znq
                            p_a1Zlw = double g_a1Zlv
                            (g_a1Zlv, gpart_a1Znq) = Genome.Split.split gpart_a1Znp
                            p_a1Zlu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlt
                            (g_a1Zlt, gpart_a1Znp) = Genome.Split.split gpart_a1Zno
                            p_a1Zls
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlr
                            (g_a1Zlr, gpart_a1Zno) = Genome.Split.split gpart_a1Znn
                            p_a1Zlq = double g_a1Zlp
                            (g_a1Zlp, gpart_a1Znn) = Genome.Split.split gpart_a1Znm
                            p_a1Zlo = Functions.belowten' g_a1Zln
                            (g_a1Zln, gpart_a1Znm) = Genome.Split.split gpart_a1Znl
                            p_a1Zlm = double g_a1Zll
                            (g_a1Zll, gpart_a1Znl) = Genome.Split.split gpart_a1Znk
                            p_a1Zlk = Functions.belowten' g_a1Zlj
                            (g_a1Zlj, gpart_a1Znk) = Genome.Split.split gpart_a1Znj
                            p_a1Zli = double g_a1Zlh
                            (g_a1Zlh, gpart_a1Znj) = Genome.Split.split gpart_a1Zni
                            p_a1Zlg = double g_a1Zlf
                            (g_a1Zlf, gpart_a1Zni) = Genome.Split.split gpart_a1Znh
                            p_a1Zle = Functions.belowten' g_a1Zld
                            (g_a1Zld, gpart_a1Znh) = Genome.Split.split gpart_a1Zng
                            p_a1Zlc = double g_a1Zlb
                            (g_a1Zlb, gpart_a1Zng) = Genome.Split.split gpart_a1Znf
                            p_a1Zla
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl9
                            (g_a1Zl9, gpart_a1Znf) = Genome.Split.split gpart_a1Zne
                            p_a1Zl8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zl7
                            (g_a1Zl7, gpart_a1Zne) = Genome.Split.split gpart_a1Znd
                            p_a1Zl6 = double g_a1Zl5
                            (g_a1Zl5, gpart_a1Znd) = Genome.Split.split gpart_a1Znc
                            p_a1Zl4 = double g_a1Zl3
                            (g_a1Zl3, gpart_a1Znc) = Genome.Split.split gpart_a1Znb
                            p_a1Zl2 = double g_a1Zl1
                            (g_a1Zl1, gpart_a1Znb) = Genome.Split.split gpart_a1Zna
                            p_a1Zl0 = double g_a1ZkZ
                            (g_a1ZkZ, gpart_a1Zna) = Genome.Split.split gpart_a1Zn9
                            p_a1ZkY = double g_a1ZkX
                            (g_a1ZkX, gpart_a1Zn9) = Genome.Split.split genome_a1Zmb
                          in
                            \ desc_a1Zmc
                              -> case desc_a1Zmc of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkY)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl0)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl2)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl4)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl6)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zl8)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zla)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlc)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zle)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlg)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zli)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlk)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlm)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlo)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlq)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zls)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlu)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlw)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zly)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlA)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlC)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlE)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlG)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlI)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlK)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlM)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlO)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlQ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlS)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlU)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm0)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm2)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm4)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm6)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm8)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zma)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVe
                      p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                      (g_asUz, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                      (g_asUt, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                      (g_asUr, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asUq = Functions.belowten' g_asUp
                      (g_asUp, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                      (g_asUn, gpart_asV8) = Genome.Split.split gpart_asV7
                      p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                      (g_asUl, gpart_asV7) = Genome.Split.split gpart_asV6
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asV6) = Genome.Split.split gpart_asV5
                      p_asUi = Functions.belowten' g_asUh
                      (g_asUh, gpart_asV5) = Genome.Split.split gpart_asV4
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asV4) = Genome.Split.split gpart_asV3
                      p_asUe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUd
                      (g_asUd, gpart_asV3) = Genome.Split.split gpart_asV2
                      p_asUc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUb
                      (g_asUb, gpart_asV2) = Genome.Split.split gpart_asV1
                      p_asUa = Functions.belowten' g_asU9
                      (g_asU9, gpart_asV1) = Genome.Split.split gpart_asV0
                      p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                      (g_asU7, gpart_asV0) = Genome.Split.split gpart_asUZ
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asUZ) = Genome.Split.split gpart_asUY
                      p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                      (g_asU3, gpart_asUY) = Genome.Split.split gpart_asUX
                      p_asU2 = Functions.belowten' g_asU1
                      (g_asU1, gpart_asUX) = Genome.Split.split gpart_asUW
                      p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                      (g_asTZ, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asTY = Functions.belowten' g_asTX
                      (g_asTX, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asTU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTT
                      (g_asTT, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asTS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTR
                      (g_asTR, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asTO = Functions.belowten' g_asTN
                      (g_asTN, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                      (g_asTL, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTK = Functions.belowten' g_asTJ
                      (g_asTJ, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                      (g_asTH, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                      (g_asTF, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asTE = Functions.belowten' g_asTD
                      (g_asTD, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asTC = code-0.1.0.0:Genome.FixedList.Functions.double g_asTB
                      (g_asTB, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asTA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTz
                      (g_asTz, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                      (g_asTx, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTw = code-0.1.0.0:Genome.FixedList.Functions.double g_asTv
                      (g_asTv, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                      (g_asTt, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTs = code-0.1.0.0:Genome.FixedList.Functions.double g_asTr
                      (g_asTr, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                      (g_asTp, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTo = code-0.1.0.0:Genome.FixedList.Functions.double g_asTn
                      (g_asTn, gpart_asUD) = Genome.Split.split genome_asUB
                    in
                      [Reaction
                         (\ x_asVf
                            -> let c_MiRs_asVg = ((toVector x_asVf) Data.Vector.Unboxed.! 2)
                               in (p_asTw / (1 + ((c_MiRs_asVg / p_asTC) ** p_asTE))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVh
                            -> let
                                 c_MiRs_asVi = ((toVector x_asVh) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVj = ((toVector x_asVh) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTG
                                  / (1
                                     + (((c_MiRs_asVi / p_asTI) ** p_asTK)
                                        + ((c_PTB_asVj / p_asTM) ** p_asTO)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVk
                            -> let
                                 c_RESTc_asVm = ((toVector x_asVk) Data.Vector.Unboxed.! 3)
                                 c_PTB_asVl = ((toVector x_asVk) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTQ
                                  * ((p_asU4 + ((p_asTs / p_asTS) ** p_asTU))
                                     / (((1 + p_asU4) + ((p_asTs / p_asTS) ** p_asTU))
                                        + (((c_PTB_asVl / p_asTW) ** p_asTY)
                                           + ((c_RESTc_asVm / p_asU0) ** p_asU2))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVn
                            -> let
                                 c_MiRs_asVq = ((toVector x_asVn) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVo = ((toVector x_asVn) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asU6
                                  * ((p_asUk + ((c_PTB_asVo / p_asU8) ** p_asUa))
                                     / (((1 + p_asUk) + ((c_PTB_asVo / p_asU8) ** p_asUa))
                                        + (((p_asTo / p_asUc) ** p_asUe)
                                           + ((c_MiRs_asVq / p_asUg) ** p_asUi))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVr
                            -> let c_RESTc_asVs = ((toVector x_asVr) Data.Vector.Unboxed.! 3)
                               in (p_asUm / (1 + ((c_RESTc_asVs / p_asUo) ** p_asUq))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVt
                            -> let c_PTB_asVu = ((toVector x_asVt) Data.Vector.Unboxed.! 0)
                               in (p_asUs * c_PTB_asVu))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVv
                            -> let c_NPTB_asVw = ((toVector x_asVv) Data.Vector.Unboxed.! 1)
                               in (p_asUu * c_NPTB_asVw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVx
                            -> let c_MiRs_asVy = ((toVector x_asVx) Data.Vector.Unboxed.! 2)
                               in (p_asUw * c_MiRs_asVy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVz
                            -> let c_RESTc_asVA = ((toVector x_asVz) Data.Vector.Unboxed.! 3)
                               in (p_asUy * c_RESTc_asVA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVB
                            -> let
                                 c_EndoNeuroTFs_asVC = ((toVector x_asVB) Data.Vector.Unboxed.! 4)
                               in (p_asUA * c_EndoNeuroTFs_asVC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120868",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120870",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWj
                            p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                            (g_asUz, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                            (g_asUt, gpart_asWg) = Genome.Split.split gpart_asWf
                            p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                            (g_asUr, gpart_asWf) = Genome.Split.split gpart_asWe
                            p_asUq = Functions.belowten' g_asUp
                            (g_asUp, gpart_asWe) = Genome.Split.split gpart_asWd
                            p_asUo = code-0.1.0.0:Genome.FixedList.Functions.double g_asUn
                            (g_asUn, gpart_asWd) = Genome.Split.split gpart_asWc
                            p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                            (g_asUl, gpart_asWc) = Genome.Split.split gpart_asWb
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWb) = Genome.Split.split gpart_asWa
                            p_asUi = Functions.belowten' g_asUh
                            (g_asUh, gpart_asWa) = Genome.Split.split gpart_asW9
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asUe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUd
                            (g_asUd, gpart_asW8) = Genome.Split.split gpart_asW7
                            p_asUc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUb
                            (g_asUb, gpart_asW7) = Genome.Split.split gpart_asW6
                            p_asUa = Functions.belowten' g_asU9
                            (g_asU9, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                            (g_asU7, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                            (g_asU3, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asU2 = Functions.belowten' g_asU1
                            (g_asU1, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                            (g_asTZ, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asTY = Functions.belowten' g_asTX
                            (g_asTX, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTT
                            (g_asTT, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTR
                            (g_asTR, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTO = Functions.belowten' g_asTN
                            (g_asTN, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                            (g_asTL, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTK = Functions.belowten' g_asTJ
                            (g_asTJ, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                            (g_asTH, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                            (g_asTF, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asTE = Functions.belowten' g_asTD
                            (g_asTD, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asTC = code-0.1.0.0:Genome.FixedList.Functions.double g_asTB
                            (g_asTB, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asTA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTz
                            (g_asTz, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                            (g_asTx, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTw = code-0.1.0.0:Genome.FixedList.Functions.double g_asTv
                            (g_asTv, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                            (g_asTt, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTs = code-0.1.0.0:Genome.FixedList.Functions.double g_asTr
                            (g_asTr, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                            (g_asTp, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTo = code-0.1.0.0:Genome.FixedList.Functions.double g_asTn
                            (g_asTn, gpart_asVI) = Genome.Split.split genome_asUB
                          in
                            \ desc_asUC
                              -> case desc_asUC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTo)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTq)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTs)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTu)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTw)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTy)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTA)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTC)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTE)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTG)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTI)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYe
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYR
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asY3 = Functions.belowten' g_asY2
                      (g_asY2, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                      (g_asXY, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXV = Functions.belowten' g_asXU
                      (g_asXU, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXQ
                      (g_asXQ, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                      (g_asXO, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXN = Functions.belowten' g_asXM
                      (g_asXM, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXF = Functions.belowten' g_asXE
                      (g_asXE, gpart_asYA) = Genome.Split.split gpart_asYz
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYz) = Genome.Split.split gpart_asYy
                      p_asXB = Functions.belowten' g_asXA
                      (g_asXA, gpart_asYy) = Genome.Split.split gpart_asYx
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYx) = Genome.Split.split gpart_asYw
                      p_asXx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXw
                      (g_asXw, gpart_asYw) = Genome.Split.split gpart_asYv
                      p_asXv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXu
                      (g_asXu, gpart_asYv) = Genome.Split.split gpart_asYu
                      p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                      (g_asXs, gpart_asYu) = Genome.Split.split gpart_asYt
                      p_asXr = Functions.belowten' g_asXq
                      (g_asXq, gpart_asYt) = Genome.Split.split gpart_asYs
                      p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                      (g_asXo, gpart_asYs) = Genome.Split.split gpart_asYr
                      p_asXn = Functions.belowten' g_asXm
                      (g_asXm, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXh = Functions.belowten' g_asXg
                      (g_asXg, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                      (g_asXe, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXc
                      (g_asXc, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                      (g_asXa, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                      (g_asX8, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                      (g_asX6, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                      (g_asX4, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                      (g_asX2, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                      (g_asX0, gpart_asYg) = Genome.Split.split genome_asYe
                    in
                      [Reaction
                         (\ x_asYS
                            -> let c_MiRs_asYT = ((toVector x_asYS) Data.Vector.Unboxed.! 2)
                               in (p_asX9 / (1 + ((c_MiRs_asYT / p_asXf) ** p_asXh))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYU
                            -> let
                                 c_MiRs_asYV = ((toVector x_asYU) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYW = ((toVector x_asYU) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXj
                                  / (1
                                     + (((c_MiRs_asYV / p_asXl) ** p_asXn)
                                        + ((c_PTB_asYW / p_asXp) ** p_asXr)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYX
                            -> let
                                 c_RESTc_asYZ = ((toVector x_asYX) Data.Vector.Unboxed.! 3)
                                 c_PTB_asYY = ((toVector x_asYX) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXt
                                  * (p_asXH
                                     / ((1 + p_asXH)
                                        + (((c_PTB_asYY / p_asXz) ** p_asXB)
                                           + ((c_RESTc_asYZ / p_asXD) ** p_asXF))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZ0
                            -> let
                                 c_MiRs_asZ3 = ((toVector x_asZ0) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZ1 = ((toVector x_asZ0) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXJ
                                  * ((p_asXX + ((c_PTB_asZ1 / p_asXL) ** p_asXN))
                                     / (((1 + p_asXX) + ((c_PTB_asZ1 / p_asXL) ** p_asXN))
                                        + (((p_asX1 / p_asXP) ** p_asXR)
                                           + ((c_MiRs_asZ3 / p_asXT) ** p_asXV))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZ4
                            -> let c_RESTc_asZ5 = ((toVector x_asZ4) Data.Vector.Unboxed.! 3)
                               in (p_asXZ / (1 + ((c_RESTc_asZ5 / p_asY1) ** p_asY3))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZ6
                            -> let c_PTB_asZ7 = ((toVector x_asZ6) Data.Vector.Unboxed.! 0)
                               in (p_asY5 * c_PTB_asZ7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZ8
                            -> let c_NPTB_asZ9 = ((toVector x_asZ8) Data.Vector.Unboxed.! 1)
                               in (p_asY7 * c_NPTB_asZ9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZa
                            -> let c_MiRs_asZb = ((toVector x_asZa) Data.Vector.Unboxed.! 2)
                               in (p_asY9 * c_MiRs_asZb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZc
                            -> let c_RESTc_asZd = ((toVector x_asZc) Data.Vector.Unboxed.! 3)
                               in (p_asYb * c_RESTc_asZd))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZe
                            -> let
                                 c_EndoNeuroTFs_asZf = ((toVector x_asZe) Data.Vector.Unboxed.! 4)
                               in (p_asYd * c_EndoNeuroTFs_asZf))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121093",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYe
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZR
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asY3 = Functions.belowten' g_asY2
                            (g_asY2, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                            (g_asXY, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXV = Functions.belowten' g_asXU
                            (g_asXU, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXQ
                            (g_asXQ, gpart_asZG) = Genome.Split.split gpart_asZF
                            p_asXP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                            (g_asXO, gpart_asZF) = Genome.Split.split gpart_asZE
                            p_asXN = Functions.belowten' g_asXM
                            (g_asXM, gpart_asZE) = Genome.Split.split gpart_asZD
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZD) = Genome.Split.split gpart_asZC
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZC) = Genome.Split.split gpart_asZB
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_asZB) = Genome.Split.split gpart_asZA
                            p_asXF = Functions.belowten' g_asXE
                            (g_asXE, gpart_asZA) = Genome.Split.split gpart_asZz
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZz) = Genome.Split.split gpart_asZy
                            p_asXB = Functions.belowten' g_asXA
                            (g_asXA, gpart_asZy) = Genome.Split.split gpart_asZx
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXw
                            (g_asXw, gpart_asZw) = Genome.Split.split gpart_asZv
                            p_asXv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXu
                            (g_asXu, gpart_asZv) = Genome.Split.split gpart_asZu
                            p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                            (g_asXs, gpart_asZu) = Genome.Split.split gpart_asZt
                            p_asXr = Functions.belowten' g_asXq
                            (g_asXq, gpart_asZt) = Genome.Split.split gpart_asZs
                            p_asXp = code-0.1.0.0:Genome.FixedList.Functions.double g_asXo
                            (g_asXo, gpart_asZs) = Genome.Split.split gpart_asZr
                            p_asXn = Functions.belowten' g_asXm
                            (g_asXm, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asXh = Functions.belowten' g_asXg
                            (g_asXg, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                            (g_asXe, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asXd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXc
                            (g_asXc, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asXb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                            (g_asXa, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asX9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX8
                            (g_asX8, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                            (g_asX6, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asX5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX4
                            (g_asX4, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                            (g_asX2, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asX1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX0
                            (g_asX0, gpart_asZg) = Genome.Split.split genome_asYe
                          in
                            \ desc_asYf
                              -> case desc_asYf of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX9)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXb)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1M
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2p
                      p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                      (g_at1K, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                      (g_at1I, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                      (g_at1G, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                      (g_at1E, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                      (g_at1C, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1B = Functions.belowten' g_at1A
                      (g_at1A, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                      (g_at1y, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                      (g_at1w, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                      (g_at1u, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at1t = Functions.belowten' g_at1s
                      (g_at1s, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                      (g_at1q, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at1p
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1o
                      (g_at1o, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at1n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1m
                      (g_at1m, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at1l = Functions.belowten' g_at1k
                      (g_at1k, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                      (g_at1g, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                      (g_at1e, gpart_at29) = Genome.Split.split gpart_at28
                      p_at1d = Functions.belowten' g_at1c
                      (g_at1c, gpart_at28) = Genome.Split.split gpart_at27
                      p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                      (g_at1a, gpart_at27) = Genome.Split.split gpart_at26
                      p_at19 = Functions.belowten' g_at18
                      (g_at18, gpart_at26) = Genome.Split.split gpart_at25
                      p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                      (g_at16, gpart_at25) = Genome.Split.split gpart_at24
                      p_at15
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at14
                      (g_at14, gpart_at24) = Genome.Split.split gpart_at23
                      p_at13
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at12
                      (g_at12, gpart_at23) = Genome.Split.split gpart_at22
                      p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                      (g_at10, gpart_at22) = Genome.Split.split gpart_at21
                      p_at0Z = Functions.belowten' g_at0Y
                      (g_at0Y, gpart_at21) = Genome.Split.split gpart_at20
                      p_at0X = code-0.1.0.0:Genome.FixedList.Functions.double g_at0W
                      (g_at0W, gpart_at20) = Genome.Split.split gpart_at1Z
                      p_at0V = Functions.belowten' g_at0U
                      (g_at0U, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                      (g_at0S, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                      (g_at0Q, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at0P = Functions.belowten' g_at0O
                      (g_at0O, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                      (g_at0M, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at0L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0K
                      (g_at0K, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at0J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                      (g_at0I, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                      (g_at0G, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                      (g_at0E, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                      (g_at0C, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                      (g_at0A, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                      (g_at0y, gpart_at1O) = Genome.Split.split genome_at1M
                    in
                      [Reaction
                         (\ x_at2q
                            -> let c_MiRs_at2r = ((toVector x_at2q) Data.Vector.Unboxed.! 2)
                               in (p_at0H / (1 + ((c_MiRs_at2r / p_at0N) ** p_at0P))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2s
                            -> let
                                 c_MiRs_at2t = ((toVector x_at2s) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2u = ((toVector x_at2s) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0R
                                  / (1
                                     + (((c_MiRs_at2t / p_at0T) ** p_at0V)
                                        + ((c_PTB_at2u / p_at0X) ** p_at0Z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2v
                            -> let
                                 c_RESTc_at2x = ((toVector x_at2v) Data.Vector.Unboxed.! 3)
                                 c_PTB_at2w = ((toVector x_at2v) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at11
                                  * (p_at1f
                                     / ((1 + p_at1f)
                                        + (((c_PTB_at2w / p_at17) ** p_at19)
                                           + ((c_RESTc_at2x / p_at1b) ** p_at1d))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2y
                            -> let
                                 c_MiRs_at2B = ((toVector x_at2y) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2z = ((toVector x_at2y) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1h
                                  * ((p_at1v + ((c_PTB_at2z / p_at1j) ** p_at1l))
                                     / (((1 + p_at1v) + ((c_PTB_at2z / p_at1j) ** p_at1l))
                                        + ((c_MiRs_at2B / p_at1r) ** p_at1t)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2C
                            -> let c_RESTc_at2D = ((toVector x_at2C) Data.Vector.Unboxed.! 3)
                               in (p_at1x / (1 + ((c_RESTc_at2D / p_at1z) ** p_at1B))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2E
                            -> let c_PTB_at2F = ((toVector x_at2E) Data.Vector.Unboxed.! 0)
                               in (p_at1D * c_PTB_at2F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2G
                            -> let c_NPTB_at2H = ((toVector x_at2G) Data.Vector.Unboxed.! 1)
                               in (p_at1F * c_NPTB_at2H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2I
                            -> let c_MiRs_at2J = ((toVector x_at2I) Data.Vector.Unboxed.! 2)
                               in (p_at1H * c_MiRs_at2J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2K
                            -> let c_RESTc_at2L = ((toVector x_at2K) Data.Vector.Unboxed.! 3)
                               in (p_at1J * c_RESTc_at2L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2M
                            -> let
                                 c_EndoNeuroTFs_at2N = ((toVector x_at2M) Data.Vector.Unboxed.! 4)
                               in (p_at1L * c_EndoNeuroTFs_at2N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121315",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121353",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121355",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1M
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3p
                            p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                            (g_at1K, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                            (g_at1I, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                            (g_at1G, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                            (g_at1E, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                            (g_at1C, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at1B = Functions.belowten' g_at1A
                            (g_at1A, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                            (g_at1y, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                            (g_at1w, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                            (g_at1u, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at1t = Functions.belowten' g_at1s
                            (g_at1s, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                            (g_at1q, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at1p
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1o
                            (g_at1o, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at1n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1m
                            (g_at1m, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at1l = Functions.belowten' g_at1k
                            (g_at1k, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                            (g_at1g, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                            (g_at1e, gpart_at39) = Genome.Split.split gpart_at38
                            p_at1d = Functions.belowten' g_at1c
                            (g_at1c, gpart_at38) = Genome.Split.split gpart_at37
                            p_at1b = code-0.1.0.0:Genome.FixedList.Functions.double g_at1a
                            (g_at1a, gpart_at37) = Genome.Split.split gpart_at36
                            p_at19 = Functions.belowten' g_at18
                            (g_at18, gpart_at36) = Genome.Split.split gpart_at35
                            p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                            (g_at16, gpart_at35) = Genome.Split.split gpart_at34
                            p_at15
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at14
                            (g_at14, gpart_at34) = Genome.Split.split gpart_at33
                            p_at13
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at12
                            (g_at12, gpart_at33) = Genome.Split.split gpart_at32
                            p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                            (g_at10, gpart_at32) = Genome.Split.split gpart_at31
                            p_at0Z = Functions.belowten' g_at0Y
                            (g_at0Y, gpart_at31) = Genome.Split.split gpart_at30
                            p_at0X = code-0.1.0.0:Genome.FixedList.Functions.double g_at0W
                            (g_at0W, gpart_at30) = Genome.Split.split gpart_at2Z
                            p_at0V = Functions.belowten' g_at0U
                            (g_at0U, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                            (g_at0S, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                            (g_at0Q, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at0P = Functions.belowten' g_at0O
                            (g_at0O, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at0N = code-0.1.0.0:Genome.FixedList.Functions.double g_at0M
                            (g_at0M, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at0L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0K
                            (g_at0K, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at0J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                            (g_at0I, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                            (g_at0G, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                            (g_at0E, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                            (g_at0C, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                            (g_at0A, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                            (g_at0y, gpart_at2O) = Genome.Split.split genome_at1M
                          in
                            \ desc_at1N
                              -> case desc_at1N of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0B)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0D)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0F)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0L)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0N)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0P)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0R)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0T)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0V)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0X)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1n)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1p)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1r)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1t)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1v)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1x)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1z)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1B)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1D)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1F)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5k
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5X
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                      (g_at5a, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at59 = Functions.belowten' g_at58
                      (g_at58, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                      (g_at56, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                      (g_at54, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at53 = code-0.1.0.0:Genome.FixedList.Functions.double g_at52
                      (g_at52, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at51 = Functions.belowten' g_at50
                      (g_at50, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                      (g_at4Y, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4X
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4W
                      (g_at4W, gpart_at5M) = Genome.Split.split gpart_at5L
                      p_at4V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4U
                      (g_at4U, gpart_at5L) = Genome.Split.split gpart_at5K
                      p_at4T = Functions.belowten' g_at4S
                      (g_at4S, gpart_at5K) = Genome.Split.split gpart_at5J
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5J) = Genome.Split.split gpart_at5I
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5I) = Genome.Split.split gpart_at5H
                      p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                      (g_at4M, gpart_at5H) = Genome.Split.split gpart_at5G
                      p_at4L = Functions.belowten' g_at4K
                      (g_at4K, gpart_at5G) = Genome.Split.split gpart_at5F
                      p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                      (g_at4I, gpart_at5F) = Genome.Split.split gpart_at5E
                      p_at4H = Functions.belowten' g_at4G
                      (g_at4G, gpart_at5E) = Genome.Split.split gpart_at5D
                      p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                      (g_at4E, gpart_at5D) = Genome.Split.split gpart_at5C
                      p_at4D
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4C
                      (g_at4C, gpart_at5C) = Genome.Split.split gpart_at5B
                      p_at4B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4A
                      (g_at4A, gpart_at5B) = Genome.Split.split gpart_at5A
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5A) = Genome.Split.split gpart_at5z
                      p_at4x = Functions.belowten' g_at4w
                      (g_at4w, gpart_at5z) = Genome.Split.split gpart_at5y
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5y) = Genome.Split.split gpart_at5x
                      p_at4t = Functions.belowten' g_at4s
                      (g_at4s, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                      (g_at4q, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                      (g_at4o, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4n = Functions.belowten' g_at4m
                      (g_at4m, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                      (g_at4k, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4i
                      (g_at4i, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                      (g_at4g, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                      (g_at4e, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                      (g_at4c, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                      (g_at4a, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at47 = code-0.1.0.0:Genome.FixedList.Functions.double g_at46
                      (g_at46, gpart_at5m) = Genome.Split.split genome_at5k
                    in
                      [Reaction
                         (\ x_at5Y
                            -> let c_MiRs_at5Z = ((toVector x_at5Y) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4f
                                  / (1
                                     + (((p_at47 / p_at4h) ** p_at4j)
                                        + ((c_MiRs_at5Z / p_at4l) ** p_at4n)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at60
                            -> let
                                 c_MiRs_at61 = ((toVector x_at60) Data.Vector.Unboxed.! 2)
                                 c_PTB_at62 = ((toVector x_at60) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4p
                                  / (1
                                     + (((c_MiRs_at61 / p_at4r) ** p_at4t)
                                        + ((c_PTB_at62 / p_at4v) ** p_at4x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at63
                            -> let
                                 c_RESTc_at65 = ((toVector x_at63) Data.Vector.Unboxed.! 3)
                                 c_PTB_at64 = ((toVector x_at63) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4z
                                  * (p_at4N
                                     / ((1 + p_at4N)
                                        + (((c_PTB_at64 / p_at4F) ** p_at4H)
                                           + ((c_RESTc_at65 / p_at4J) ** p_at4L))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at66
                            -> let
                                 c_MiRs_at69 = ((toVector x_at66) Data.Vector.Unboxed.! 2)
                                 c_PTB_at67 = ((toVector x_at66) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4P
                                  * ((p_at53 + ((c_PTB_at67 / p_at4R) ** p_at4T))
                                     / (((1 + p_at53) + ((c_PTB_at67 / p_at4R) ** p_at4T))
                                        + ((c_MiRs_at69 / p_at4Z) ** p_at51)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6a
                            -> let c_RESTc_at6b = ((toVector x_at6a) Data.Vector.Unboxed.! 3)
                               in (p_at55 / (1 + ((c_RESTc_at6b / p_at57) ** p_at59))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6c
                            -> let c_PTB_at6d = ((toVector x_at6c) Data.Vector.Unboxed.! 0)
                               in (p_at5b * c_PTB_at6d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6e
                            -> let c_NPTB_at6f = ((toVector x_at6e) Data.Vector.Unboxed.! 1)
                               in (p_at5d * c_NPTB_at6f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6g
                            -> let c_MiRs_at6h = ((toVector x_at6g) Data.Vector.Unboxed.! 2)
                               in (p_at5f * c_MiRs_at6h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6i
                            -> let c_RESTc_at6j = ((toVector x_at6i) Data.Vector.Unboxed.! 3)
                               in (p_at5h * c_RESTc_at6j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6k
                            -> let
                                 c_EndoNeuroTFs_at6l = ((toVector x_at6k) Data.Vector.Unboxed.! 4)
                               in (p_at5j * c_EndoNeuroTFs_at6l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5k
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6X
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                            (g_at5a, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at59 = Functions.belowten' g_at58
                            (g_at58, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                            (g_at56, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                            (g_at54, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at53 = code-0.1.0.0:Genome.FixedList.Functions.double g_at52
                            (g_at52, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at51 = Functions.belowten' g_at50
                            (g_at50, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                            (g_at4Y, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4X
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4W
                            (g_at4W, gpart_at6M) = Genome.Split.split gpart_at6L
                            p_at4V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4U
                            (g_at4U, gpart_at6L) = Genome.Split.split gpart_at6K
                            p_at4T = Functions.belowten' g_at4S
                            (g_at4S, gpart_at6K) = Genome.Split.split gpart_at6J
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6J) = Genome.Split.split gpart_at6I
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6I) = Genome.Split.split gpart_at6H
                            p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                            (g_at4M, gpart_at6H) = Genome.Split.split gpart_at6G
                            p_at4L = Functions.belowten' g_at4K
                            (g_at4K, gpart_at6G) = Genome.Split.split gpart_at6F
                            p_at4J = code-0.1.0.0:Genome.FixedList.Functions.double g_at4I
                            (g_at4I, gpart_at6F) = Genome.Split.split gpart_at6E
                            p_at4H = Functions.belowten' g_at4G
                            (g_at4G, gpart_at6E) = Genome.Split.split gpart_at6D
                            p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                            (g_at4E, gpart_at6D) = Genome.Split.split gpart_at6C
                            p_at4D
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4C
                            (g_at4C, gpart_at6C) = Genome.Split.split gpart_at6B
                            p_at4B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4A
                            (g_at4A, gpart_at6B) = Genome.Split.split gpart_at6A
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6A) = Genome.Split.split gpart_at6z
                            p_at4x = Functions.belowten' g_at4w
                            (g_at4w, gpart_at6z) = Genome.Split.split gpart_at6y
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6y) = Genome.Split.split gpart_at6x
                            p_at4t = Functions.belowten' g_at4s
                            (g_at4s, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                            (g_at4q, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                            (g_at4o, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4n = Functions.belowten' g_at4m
                            (g_at4m, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                            (g_at4k, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at4j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4i
                            (g_at4i, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at4h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                            (g_at4g, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at4f = code-0.1.0.0:Genome.FixedList.Functions.double g_at4e
                            (g_at4e, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                            (g_at4c, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                            (g_at4a, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at47 = code-0.1.0.0:Genome.FixedList.Functions.double g_at46
                            (g_at46, gpart_at6m) = Genome.Split.split genome_at5k
                          in
                            \ desc_at5l
                              -> case desc_at5l of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Inhibition coef [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Inhibition hill [PTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   _ -> Nothing }}
