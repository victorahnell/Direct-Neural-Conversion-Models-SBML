src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2abB
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ack
                      p_a2abA = double g_a2abz
                      (g_a2abz, gpart_a2ack) = Genome.Split.split gpart_a2acj
                      p_a2aby = double g_a2abx
                      (g_a2abx, gpart_a2acj) = Genome.Split.split gpart_a2aci
                      p_a2abw = double g_a2abv
                      (g_a2abv, gpart_a2aci) = Genome.Split.split gpart_a2ach
                      p_a2abu = double g_a2abt
                      (g_a2abt, gpart_a2ach) = Genome.Split.split gpart_a2acg
                      p_a2abs = double g_a2abr
                      (g_a2abr, gpart_a2acg) = Genome.Split.split gpart_a2acf
                      p_a2abq = double g_a2abp
                      (g_a2abp, gpart_a2acf) = Genome.Split.split gpart_a2ace
                      p_a2abo = Functions.belowten' g_a2abn
                      (g_a2abn, gpart_a2ace) = Genome.Split.split gpart_a2acd
                      p_a2abm = double g_a2abl
                      (g_a2abl, gpart_a2acd) = Genome.Split.split gpart_a2acc
                      p_a2abk = Functions.belowten' g_a2abj
                      (g_a2abj, gpart_a2acc) = Genome.Split.split gpart_a2acb
                      p_a2abi = double g_a2abh
                      (g_a2abh, gpart_a2acb) = Genome.Split.split gpart_a2aca
                      p_a2abg = double g_a2abf
                      (g_a2abf, gpart_a2aca) = Genome.Split.split gpart_a2ac9
                      p_a2abe = double g_a2abd
                      (g_a2abd, gpart_a2ac9) = Genome.Split.split gpart_a2ac8
                      p_a2abc = Functions.belowten' g_a2abb
                      (g_a2abb, gpart_a2ac8) = Genome.Split.split gpart_a2ac7
                      p_a2aba = double g_a2ab9
                      (g_a2ab9, gpart_a2ac7) = Genome.Split.split gpart_a2ac6
                      p_a2ab8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ab7
                      (g_a2ab7, gpart_a2ac6) = Genome.Split.split gpart_a2ac5
                      p_a2ab6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ab5
                      (g_a2ab5, gpart_a2ac5) = Genome.Split.split gpart_a2ac4
                      p_a2ab4 = Functions.belowten' g_a2ab3
                      (g_a2ab3, gpart_a2ac4) = Genome.Split.split gpart_a2ac3
                      p_a2ab2 = double g_a2ab1
                      (g_a2ab1, gpart_a2ac3) = Genome.Split.split gpart_a2ac2
                      p_a2ab0 = double g_a2aaZ
                      (g_a2aaZ, gpart_a2ac2) = Genome.Split.split gpart_a2ac1
                      p_a2aaY = double g_a2aaX
                      (g_a2aaX, gpart_a2ac1) = Genome.Split.split gpart_a2ac0
                      p_a2aaW = Functions.belowten' g_a2aaV
                      (g_a2aaV, gpart_a2ac0) = Genome.Split.split gpart_a2abZ
                      p_a2aaU = double g_a2aaT
                      (g_a2aaT, gpart_a2abZ) = Genome.Split.split gpart_a2abY
                      p_a2aaS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aaR
                      (g_a2aaR, gpart_a2abY) = Genome.Split.split gpart_a2abX
                      p_a2aaQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aaP
                      (g_a2aaP, gpart_a2abX) = Genome.Split.split gpart_a2abW
                      p_a2aaO = double g_a2aaN
                      (g_a2aaN, gpart_a2abW) = Genome.Split.split gpart_a2abV
                      p_a2aaM = Functions.belowten' g_a2aaL
                      (g_a2aaL, gpart_a2abV) = Genome.Split.split gpart_a2abU
                      p_a2aaK = double g_a2aaJ
                      (g_a2aaJ, gpart_a2abU) = Genome.Split.split gpart_a2abT
                      p_a2aaI = Functions.belowten' g_a2aaH
                      (g_a2aaH, gpart_a2abT) = Genome.Split.split gpart_a2abS
                      p_a2aaG = double g_a2aaF
                      (g_a2aaF, gpart_a2abS) = Genome.Split.split gpart_a2abR
                      p_a2aaE = Functions.belowten' g_a2aaD
                      (g_a2aaD, gpart_a2abR) = Genome.Split.split gpart_a2abQ
                      p_a2aaC = double g_a2aaB
                      (g_a2aaB, gpart_a2abQ) = Genome.Split.split gpart_a2abP
                      p_a2aaA = double g_a2aaz
                      (g_a2aaz, gpart_a2abP) = Genome.Split.split gpart_a2abO
                      p_a2aay = double g_a2aax
                      (g_a2aax, gpart_a2abO) = Genome.Split.split gpart_a2abN
                      p_a2aaw = Functions.belowten' g_a2aav
                      (g_a2aav, gpart_a2abN) = Genome.Split.split gpart_a2abM
                      p_a2aau = double g_a2aat
                      (g_a2aat, gpart_a2abM) = Genome.Split.split gpart_a2abL
                      p_a2aas
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aar
                      (g_a2aar, gpart_a2abL) = Genome.Split.split gpart_a2abK
                      p_a2aaq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aap
                      (g_a2aap, gpart_a2abK) = Genome.Split.split gpart_a2abJ
                      p_a2aao = Functions.belowten' g_a2aan
                      (g_a2aan, gpart_a2abJ) = Genome.Split.split gpart_a2abI
                      p_a2aam = double g_a2aal
                      (g_a2aal, gpart_a2abI) = Genome.Split.split gpart_a2abH
                      p_a2aak = double g_a2aaj
                      (g_a2aaj, gpart_a2abH) = Genome.Split.split gpart_a2abG
                      p_a2aai = double g_a2aah
                      (g_a2aah, gpart_a2abG) = Genome.Split.split gpart_a2abF
                      p_a2aag = double g_a2aaf
                      (g_a2aaf, gpart_a2abF) = Genome.Split.split gpart_a2abE
                      p_a2aae = double g_a2aad
                      (g_a2aad, gpart_a2abE) = Genome.Split.split gpart_a2abD
                      p_a2aac = double g_a2aab
                      (g_a2aab, gpart_a2abD) = Genome.Split.split genome_a2abB
                    in  \ x_a2acl
                          -> let
                               c_PTB_a2acq
                                 = ((Data.Fixed.Vector.toVector x_a2acl) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2aco
                                 = ((Data.Fixed.Vector.toVector x_a2acl) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2acm
                                 = ((Data.Fixed.Vector.toVector x_a2acl) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2acr
                                 = ((Data.Fixed.Vector.toVector x_a2acl) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2acI
                                 = ((Data.Fixed.Vector.toVector x_a2acl) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aak
                                     * ((p_a2aay + ((c_NPTB_a2acm / p_a2aam) ** p_a2aao))
                                        / (((1 + p_a2aay) + ((c_NPTB_a2acm / p_a2aam) ** p_a2aao))
                                           + ((c_MiRs_a2aco / p_a2aau) ** p_a2aaw))))
                                    + (negate (p_a2abs * c_PTB_a2acq))),
                                   ((p_a2aaA
                                     / (1
                                        + ((((c_RESTc_a2acr / p_a2aaC) ** p_a2aaE)
                                            + ((c_MiRs_a2aco / p_a2aaG) ** p_a2aaI))
                                           + ((c_PTB_a2acq / p_a2aaK) ** p_a2aaM))))
                                    + (negate (p_a2abu * c_NPTB_a2acm))),
                                   ((p_a2aaO
                                     * ((p_a2aaY + ((p_a2aag / p_a2aaQ) ** p_a2aaS))
                                        / (((1 + p_a2aaY) + ((p_a2aag / p_a2aaQ) ** p_a2aaS))
                                           + ((c_RESTc_a2acr / p_a2aaU) ** p_a2aaW))))
                                    + (negate (p_a2abw * c_MiRs_a2aco))),
                                   ((p_a2ab0
                                     * ((p_a2abe + ((c_PTB_a2acq / p_a2ab2) ** p_a2ab4))
                                        / (((1 + p_a2abe) + ((c_PTB_a2acq / p_a2ab2) ** p_a2ab4))
                                           + (((p_a2aac / p_a2ab6) ** p_a2ab8)
                                              + ((c_MiRs_a2aco / p_a2aba) ** p_a2abc)))))
                                    + (negate (p_a2aby * c_RESTc_a2acr))),
                                   ((p_a2abg
                                     * ((p_a2abq + ((c_MiRs_a2aco / p_a2abi) ** p_a2abk))
                                        / (((1 + p_a2abq) + ((c_MiRs_a2aco / p_a2abi) ** p_a2abk))
                                           + ((c_RESTc_a2acr / p_a2abm) ** p_a2abo))))
                                    + (negate (p_a2abA * c_EndoNeuroTFs_a2acI)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525534",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525536",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525560",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525562",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525576",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525578",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525598",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525600",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2abB
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2adq
                            p_a2abA = double g_a2abz
                            (g_a2abz, gpart_a2adq) = Genome.Split.split gpart_a2adp
                            p_a2aby = double g_a2abx
                            (g_a2abx, gpart_a2adp) = Genome.Split.split gpart_a2ado
                            p_a2abw = double g_a2abv
                            (g_a2abv, gpart_a2ado) = Genome.Split.split gpart_a2adn
                            p_a2abu = double g_a2abt
                            (g_a2abt, gpart_a2adn) = Genome.Split.split gpart_a2adm
                            p_a2abs = double g_a2abr
                            (g_a2abr, gpart_a2adm) = Genome.Split.split gpart_a2adl
                            p_a2abq = double g_a2abp
                            (g_a2abp, gpart_a2adl) = Genome.Split.split gpart_a2adk
                            p_a2abo = Functions.belowten' g_a2abn
                            (g_a2abn, gpart_a2adk) = Genome.Split.split gpart_a2adj
                            p_a2abm = double g_a2abl
                            (g_a2abl, gpart_a2adj) = Genome.Split.split gpart_a2adi
                            p_a2abk = Functions.belowten' g_a2abj
                            (g_a2abj, gpart_a2adi) = Genome.Split.split gpart_a2adh
                            p_a2abi = double g_a2abh
                            (g_a2abh, gpart_a2adh) = Genome.Split.split gpart_a2adg
                            p_a2abg = double g_a2abf
                            (g_a2abf, gpart_a2adg) = Genome.Split.split gpart_a2adf
                            p_a2abe = double g_a2abd
                            (g_a2abd, gpart_a2adf) = Genome.Split.split gpart_a2ade
                            p_a2abc = Functions.belowten' g_a2abb
                            (g_a2abb, gpart_a2ade) = Genome.Split.split gpart_a2add
                            p_a2aba = double g_a2ab9
                            (g_a2ab9, gpart_a2add) = Genome.Split.split gpart_a2adc
                            p_a2ab8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ab7
                            (g_a2ab7, gpart_a2adc) = Genome.Split.split gpart_a2adb
                            p_a2ab6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ab5
                            (g_a2ab5, gpart_a2adb) = Genome.Split.split gpart_a2ada
                            p_a2ab4 = Functions.belowten' g_a2ab3
                            (g_a2ab3, gpart_a2ada) = Genome.Split.split gpart_a2ad9
                            p_a2ab2 = double g_a2ab1
                            (g_a2ab1, gpart_a2ad9) = Genome.Split.split gpart_a2ad8
                            p_a2ab0 = double g_a2aaZ
                            (g_a2aaZ, gpart_a2ad8) = Genome.Split.split gpart_a2ad7
                            p_a2aaY = double g_a2aaX
                            (g_a2aaX, gpart_a2ad7) = Genome.Split.split gpart_a2ad6
                            p_a2aaW = Functions.belowten' g_a2aaV
                            (g_a2aaV, gpart_a2ad6) = Genome.Split.split gpart_a2ad5
                            p_a2aaU = double g_a2aaT
                            (g_a2aaT, gpart_a2ad5) = Genome.Split.split gpart_a2ad4
                            p_a2aaS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aaR
                            (g_a2aaR, gpart_a2ad4) = Genome.Split.split gpart_a2ad3
                            p_a2aaQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aaP
                            (g_a2aaP, gpart_a2ad3) = Genome.Split.split gpart_a2ad2
                            p_a2aaO = double g_a2aaN
                            (g_a2aaN, gpart_a2ad2) = Genome.Split.split gpart_a2ad1
                            p_a2aaM = Functions.belowten' g_a2aaL
                            (g_a2aaL, gpart_a2ad1) = Genome.Split.split gpart_a2ad0
                            p_a2aaK = double g_a2aaJ
                            (g_a2aaJ, gpart_a2ad0) = Genome.Split.split gpart_a2acZ
                            p_a2aaI = Functions.belowten' g_a2aaH
                            (g_a2aaH, gpart_a2acZ) = Genome.Split.split gpart_a2acY
                            p_a2aaG = double g_a2aaF
                            (g_a2aaF, gpart_a2acY) = Genome.Split.split gpart_a2acX
                            p_a2aaE = Functions.belowten' g_a2aaD
                            (g_a2aaD, gpart_a2acX) = Genome.Split.split gpart_a2acW
                            p_a2aaC = double g_a2aaB
                            (g_a2aaB, gpart_a2acW) = Genome.Split.split gpart_a2acV
                            p_a2aaA = double g_a2aaz
                            (g_a2aaz, gpart_a2acV) = Genome.Split.split gpart_a2acU
                            p_a2aay = double g_a2aax
                            (g_a2aax, gpart_a2acU) = Genome.Split.split gpart_a2acT
                            p_a2aaw = Functions.belowten' g_a2aav
                            (g_a2aav, gpart_a2acT) = Genome.Split.split gpart_a2acS
                            p_a2aau = double g_a2aat
                            (g_a2aat, gpart_a2acS) = Genome.Split.split gpart_a2acR
                            p_a2aas
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aar
                            (g_a2aar, gpart_a2acR) = Genome.Split.split gpart_a2acQ
                            p_a2aaq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aap
                            (g_a2aap, gpart_a2acQ) = Genome.Split.split gpart_a2acP
                            p_a2aao = Functions.belowten' g_a2aan
                            (g_a2aan, gpart_a2acP) = Genome.Split.split gpart_a2acO
                            p_a2aam = double g_a2aal
                            (g_a2aal, gpart_a2acO) = Genome.Split.split gpart_a2acN
                            p_a2aak = double g_a2aaj
                            (g_a2aaj, gpart_a2acN) = Genome.Split.split gpart_a2acM
                            p_a2aai = double g_a2aah
                            (g_a2aah, gpart_a2acM) = Genome.Split.split gpart_a2acL
                            p_a2aag = double g_a2aaf
                            (g_a2aaf, gpart_a2acL) = Genome.Split.split gpart_a2acK
                            p_a2aae = double g_a2aad
                            (g_a2aad, gpart_a2acK) = Genome.Split.split gpart_a2acJ
                            p_a2aac = double g_a2aab
                            (g_a2aab, gpart_a2acJ) = Genome.Split.split genome_a2abB
                          in
                            \ desc_a2abC
                              -> case desc_a2abC of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aac)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aae)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aag)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aai)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aak)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aam)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aao)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaq)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aas)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aau)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaw)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aay)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaA)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaC)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaE)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaG)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaI)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaK)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaM)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaO)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaQ)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaS)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaU)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaW)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aaY)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ab0)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ab2)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ab4)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ab6)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ab8)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aba)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abc)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abe)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abg)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abi)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abk)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abm)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abo)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abq)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abs)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abu)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abw)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aby)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2abA)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a2ag0
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2agJ
                      p_a2afZ = double g_a2afY
                      (g_a2afY, gpart_a2agJ) = Genome.Split.split gpart_a2agI
                      p_a2afX = double g_a2afW
                      (g_a2afW, gpart_a2agI) = Genome.Split.split gpart_a2agH
                      p_a2afV = double g_a2afU
                      (g_a2afU, gpart_a2agH) = Genome.Split.split gpart_a2agG
                      p_a2afT = double g_a2afS
                      (g_a2afS, gpart_a2agG) = Genome.Split.split gpart_a2agF
                      p_a2afR = double g_a2afQ
                      (g_a2afQ, gpart_a2agF) = Genome.Split.split gpart_a2agE
                      p_a2afP = double g_a2afO
                      (g_a2afO, gpart_a2agE) = Genome.Split.split gpart_a2agD
                      p_a2afN = Functions.belowten' g_a2afM
                      (g_a2afM, gpart_a2agD) = Genome.Split.split gpart_a2agC
                      p_a2afL = double g_a2afK
                      (g_a2afK, gpart_a2agC) = Genome.Split.split gpart_a2agB
                      p_a2afJ = Functions.belowten' g_a2afI
                      (g_a2afI, gpart_a2agB) = Genome.Split.split gpart_a2agA
                      p_a2afH = double g_a2afG
                      (g_a2afG, gpart_a2agA) = Genome.Split.split gpart_a2agz
                      p_a2afF = double g_a2afE
                      (g_a2afE, gpart_a2agz) = Genome.Split.split gpart_a2agy
                      p_a2afD = double g_a2afC
                      (g_a2afC, gpart_a2agy) = Genome.Split.split gpart_a2agx
                      p_a2afB = Functions.belowten' g_a2afA
                      (g_a2afA, gpart_a2agx) = Genome.Split.split gpart_a2agw
                      p_a2afz = double g_a2afy
                      (g_a2afy, gpart_a2agw) = Genome.Split.split gpart_a2agv
                      p_a2afx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afw
                      (g_a2afw, gpart_a2agv) = Genome.Split.split gpart_a2agu
                      p_a2afv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afu
                      (g_a2afu, gpart_a2agu) = Genome.Split.split gpart_a2agt
                      p_a2aft = Functions.belowten' g_a2afs
                      (g_a2afs, gpart_a2agt) = Genome.Split.split gpart_a2ags
                      p_a2afr = double g_a2afq
                      (g_a2afq, gpart_a2ags) = Genome.Split.split gpart_a2agr
                      p_a2afp = double g_a2afo
                      (g_a2afo, gpart_a2agr) = Genome.Split.split gpart_a2agq
                      p_a2afn = double g_a2afm
                      (g_a2afm, gpart_a2agq) = Genome.Split.split gpart_a2agp
                      p_a2afl = Functions.belowten' g_a2afk
                      (g_a2afk, gpart_a2agp) = Genome.Split.split gpart_a2ago
                      p_a2afj = double g_a2afi
                      (g_a2afi, gpart_a2ago) = Genome.Split.split gpart_a2agn
                      p_a2afh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afg
                      (g_a2afg, gpart_a2agn) = Genome.Split.split gpart_a2agm
                      p_a2aff
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afe
                      (g_a2afe, gpart_a2agm) = Genome.Split.split gpart_a2agl
                      p_a2afd = double g_a2afc
                      (g_a2afc, gpart_a2agl) = Genome.Split.split gpart_a2agk
                      p_a2afb = Functions.belowten' g_a2afa
                      (g_a2afa, gpart_a2agk) = Genome.Split.split gpart_a2agj
                      p_a2af9 = double g_a2af8
                      (g_a2af8, gpart_a2agj) = Genome.Split.split gpart_a2agi
                      p_a2af7 = Functions.belowten' g_a2af6
                      (g_a2af6, gpart_a2agi) = Genome.Split.split gpart_a2agh
                      p_a2af5 = double g_a2af4
                      (g_a2af4, gpart_a2agh) = Genome.Split.split gpart_a2agg
                      p_a2af3 = Functions.belowten' g_a2af2
                      (g_a2af2, gpart_a2agg) = Genome.Split.split gpart_a2agf
                      p_a2af1 = double g_a2af0
                      (g_a2af0, gpart_a2agf) = Genome.Split.split gpart_a2age
                      p_a2aeZ = double g_a2aeY
                      (g_a2aeY, gpart_a2age) = Genome.Split.split gpart_a2agd
                      p_a2aeX = double g_a2aeW
                      (g_a2aeW, gpart_a2agd) = Genome.Split.split gpart_a2agc
                      p_a2aeV = Functions.belowten' g_a2aeU
                      (g_a2aeU, gpart_a2agc) = Genome.Split.split gpart_a2agb
                      p_a2aeT = double g_a2aeS
                      (g_a2aeS, gpart_a2agb) = Genome.Split.split gpart_a2aga
                      p_a2aeR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aeQ
                      (g_a2aeQ, gpart_a2aga) = Genome.Split.split gpart_a2ag9
                      p_a2aeP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aeO
                      (g_a2aeO, gpart_a2ag9) = Genome.Split.split gpart_a2ag8
                      p_a2aeN = Functions.belowten' g_a2aeM
                      (g_a2aeM, gpart_a2ag8) = Genome.Split.split gpart_a2ag7
                      p_a2aeL = double g_a2aeK
                      (g_a2aeK, gpart_a2ag7) = Genome.Split.split gpart_a2ag6
                      p_a2aeJ = double g_a2aeI
                      (g_a2aeI, gpart_a2ag6) = Genome.Split.split gpart_a2ag5
                      p_a2aeH = double g_a2aeG
                      (g_a2aeG, gpart_a2ag5) = Genome.Split.split gpart_a2ag4
                      p_a2aeF = double g_a2aeE
                      (g_a2aeE, gpart_a2ag4) = Genome.Split.split gpart_a2ag3
                      p_a2aeD = double g_a2aeC
                      (g_a2aeC, gpart_a2ag3) = Genome.Split.split gpart_a2ag2
                      p_a2aeB = double g_a2aeA
                      (g_a2aeA, gpart_a2ag2) = Genome.Split.split genome_a2ag0
                    in  \ x_a2agK
                          -> let
                               c_PTB_a2agP
                                 = ((Data.Fixed.Vector.toVector x_a2agK) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2agN
                                 = ((Data.Fixed.Vector.toVector x_a2agK) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2agL
                                 = ((Data.Fixed.Vector.toVector x_a2agK) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2agQ
                                 = ((Data.Fixed.Vector.toVector x_a2agK) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2ah7
                                 = ((Data.Fixed.Vector.toVector x_a2agK) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aeJ
                                     * ((p_a2aeX + ((c_NPTB_a2agL / p_a2aeL) ** p_a2aeN))
                                        / (((1 + p_a2aeX) + ((c_NPTB_a2agL / p_a2aeL) ** p_a2aeN))
                                           + ((c_MiRs_a2agN / p_a2aeT) ** p_a2aeV))))
                                    + (negate (p_a2afR * c_PTB_a2agP))),
                                   ((p_a2aeZ
                                     / (1
                                        + ((((c_RESTc_a2agQ / p_a2af1) ** p_a2af3)
                                            + ((c_MiRs_a2agN / p_a2af5) ** p_a2af7))
                                           + ((c_PTB_a2agP / p_a2af9) ** p_a2afb))))
                                    + (negate (p_a2afT * c_NPTB_a2agL))),
                                   ((p_a2afd
                                     * (p_a2afn
                                        / ((1 + p_a2afn) + ((c_RESTc_a2agQ / p_a2afj) ** p_a2afl))))
                                    + (negate (p_a2afV * c_MiRs_a2agN))),
                                   ((p_a2afp
                                     * ((p_a2afD + ((c_PTB_a2agP / p_a2afr) ** p_a2aft))
                                        / (((1 + p_a2afD) + ((c_PTB_a2agP / p_a2afr) ** p_a2aft))
                                           + (((p_a2aeB / p_a2afv) ** p_a2afx)
                                              + ((c_MiRs_a2agN / p_a2afz) ** p_a2afB)))))
                                    + (negate (p_a2afX * c_RESTc_a2agQ))),
                                   ((p_a2afF
                                     * ((p_a2afP + ((c_MiRs_a2agN / p_a2afH) ** p_a2afJ))
                                        / (((1 + p_a2afP) + ((c_MiRs_a2agN / p_a2afH) ** p_a2afJ))
                                           + ((c_RESTc_a2agQ / p_a2afL) ** p_a2afN))))
                                    + (negate (p_a2afZ * c_EndoNeuroTFs_a2ah7)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525807",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525809",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525833",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525835",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525849",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525851",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2ag0
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ahP
                            p_a2afZ = double g_a2afY
                            (g_a2afY, gpart_a2ahP) = Genome.Split.split gpart_a2ahO
                            p_a2afX = double g_a2afW
                            (g_a2afW, gpart_a2ahO) = Genome.Split.split gpart_a2ahN
                            p_a2afV = double g_a2afU
                            (g_a2afU, gpart_a2ahN) = Genome.Split.split gpart_a2ahM
                            p_a2afT = double g_a2afS
                            (g_a2afS, gpart_a2ahM) = Genome.Split.split gpart_a2ahL
                            p_a2afR = double g_a2afQ
                            (g_a2afQ, gpart_a2ahL) = Genome.Split.split gpart_a2ahK
                            p_a2afP = double g_a2afO
                            (g_a2afO, gpart_a2ahK) = Genome.Split.split gpart_a2ahJ
                            p_a2afN = Functions.belowten' g_a2afM
                            (g_a2afM, gpart_a2ahJ) = Genome.Split.split gpart_a2ahI
                            p_a2afL = double g_a2afK
                            (g_a2afK, gpart_a2ahI) = Genome.Split.split gpart_a2ahH
                            p_a2afJ = Functions.belowten' g_a2afI
                            (g_a2afI, gpart_a2ahH) = Genome.Split.split gpart_a2ahG
                            p_a2afH = double g_a2afG
                            (g_a2afG, gpart_a2ahG) = Genome.Split.split gpart_a2ahF
                            p_a2afF = double g_a2afE
                            (g_a2afE, gpart_a2ahF) = Genome.Split.split gpart_a2ahE
                            p_a2afD = double g_a2afC
                            (g_a2afC, gpart_a2ahE) = Genome.Split.split gpart_a2ahD
                            p_a2afB = Functions.belowten' g_a2afA
                            (g_a2afA, gpart_a2ahD) = Genome.Split.split gpart_a2ahC
                            p_a2afz = double g_a2afy
                            (g_a2afy, gpart_a2ahC) = Genome.Split.split gpart_a2ahB
                            p_a2afx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afw
                            (g_a2afw, gpart_a2ahB) = Genome.Split.split gpart_a2ahA
                            p_a2afv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afu
                            (g_a2afu, gpart_a2ahA) = Genome.Split.split gpart_a2ahz
                            p_a2aft = Functions.belowten' g_a2afs
                            (g_a2afs, gpart_a2ahz) = Genome.Split.split gpart_a2ahy
                            p_a2afr = double g_a2afq
                            (g_a2afq, gpart_a2ahy) = Genome.Split.split gpart_a2ahx
                            p_a2afp = double g_a2afo
                            (g_a2afo, gpart_a2ahx) = Genome.Split.split gpart_a2ahw
                            p_a2afn = double g_a2afm
                            (g_a2afm, gpart_a2ahw) = Genome.Split.split gpart_a2ahv
                            p_a2afl = Functions.belowten' g_a2afk
                            (g_a2afk, gpart_a2ahv) = Genome.Split.split gpart_a2ahu
                            p_a2afj = double g_a2afi
                            (g_a2afi, gpart_a2ahu) = Genome.Split.split gpart_a2aht
                            p_a2afh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afg
                            (g_a2afg, gpart_a2aht) = Genome.Split.split gpart_a2ahs
                            p_a2aff
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2afe
                            (g_a2afe, gpart_a2ahs) = Genome.Split.split gpart_a2ahr
                            p_a2afd = double g_a2afc
                            (g_a2afc, gpart_a2ahr) = Genome.Split.split gpart_a2ahq
                            p_a2afb = Functions.belowten' g_a2afa
                            (g_a2afa, gpart_a2ahq) = Genome.Split.split gpart_a2ahp
                            p_a2af9 = double g_a2af8
                            (g_a2af8, gpart_a2ahp) = Genome.Split.split gpart_a2aho
                            p_a2af7 = Functions.belowten' g_a2af6
                            (g_a2af6, gpart_a2aho) = Genome.Split.split gpart_a2ahn
                            p_a2af5 = double g_a2af4
                            (g_a2af4, gpart_a2ahn) = Genome.Split.split gpart_a2ahm
                            p_a2af3 = Functions.belowten' g_a2af2
                            (g_a2af2, gpart_a2ahm) = Genome.Split.split gpart_a2ahl
                            p_a2af1 = double g_a2af0
                            (g_a2af0, gpart_a2ahl) = Genome.Split.split gpart_a2ahk
                            p_a2aeZ = double g_a2aeY
                            (g_a2aeY, gpart_a2ahk) = Genome.Split.split gpart_a2ahj
                            p_a2aeX = double g_a2aeW
                            (g_a2aeW, gpart_a2ahj) = Genome.Split.split gpart_a2ahi
                            p_a2aeV = Functions.belowten' g_a2aeU
                            (g_a2aeU, gpart_a2ahi) = Genome.Split.split gpart_a2ahh
                            p_a2aeT = double g_a2aeS
                            (g_a2aeS, gpart_a2ahh) = Genome.Split.split gpart_a2ahg
                            p_a2aeR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aeQ
                            (g_a2aeQ, gpart_a2ahg) = Genome.Split.split gpart_a2ahf
                            p_a2aeP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aeO
                            (g_a2aeO, gpart_a2ahf) = Genome.Split.split gpart_a2ahe
                            p_a2aeN = Functions.belowten' g_a2aeM
                            (g_a2aeM, gpart_a2ahe) = Genome.Split.split gpart_a2ahd
                            p_a2aeL = double g_a2aeK
                            (g_a2aeK, gpart_a2ahd) = Genome.Split.split gpart_a2ahc
                            p_a2aeJ = double g_a2aeI
                            (g_a2aeI, gpart_a2ahc) = Genome.Split.split gpart_a2ahb
                            p_a2aeH = double g_a2aeG
                            (g_a2aeG, gpart_a2ahb) = Genome.Split.split gpart_a2aha
                            p_a2aeF = double g_a2aeE
                            (g_a2aeE, gpart_a2aha) = Genome.Split.split gpart_a2ah9
                            p_a2aeD = double g_a2aeC
                            (g_a2aeC, gpart_a2ah9) = Genome.Split.split gpart_a2ah8
                            p_a2aeB = double g_a2aeA
                            (g_a2aeA, gpart_a2ah8) = Genome.Split.split genome_a2ag0
                          in
                            \ desc_a2ag1
                              -> case desc_a2ag1 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeB)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeD)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeF)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeH)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeJ)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeL)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeN)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeP)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeR)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeT)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeV)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeX)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aeZ)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2af1)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2af3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2af5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2af7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2af9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afd)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aff)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afh)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afj)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afl)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afn)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afp)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afr)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aft)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afv)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afx)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afz)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afB)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afD)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afF)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afH)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afN)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afP)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afR)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afT)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afV)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afX)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afZ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a2akp
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2al8
                      p_a2ako = double g_a2akn
                      (g_a2akn, gpart_a2al8) = Genome.Split.split gpart_a2al7
                      p_a2akm = double g_a2akl
                      (g_a2akl, gpart_a2al7) = Genome.Split.split gpart_a2al6
                      p_a2akk = double g_a2akj
                      (g_a2akj, gpart_a2al6) = Genome.Split.split gpart_a2al5
                      p_a2aki = double g_a2akh
                      (g_a2akh, gpart_a2al5) = Genome.Split.split gpart_a2al4
                      p_a2akg = double g_a2akf
                      (g_a2akf, gpart_a2al4) = Genome.Split.split gpart_a2al3
                      p_a2ake = double g_a2akd
                      (g_a2akd, gpart_a2al3) = Genome.Split.split gpart_a2al2
                      p_a2akc = Functions.belowten' g_a2akb
                      (g_a2akb, gpart_a2al2) = Genome.Split.split gpart_a2al1
                      p_a2aka = double g_a2ak9
                      (g_a2ak9, gpart_a2al1) = Genome.Split.split gpart_a2al0
                      p_a2ak8 = Functions.belowten' g_a2ak7
                      (g_a2ak7, gpart_a2al0) = Genome.Split.split gpart_a2akZ
                      p_a2ak6 = double g_a2ak5
                      (g_a2ak5, gpart_a2akZ) = Genome.Split.split gpart_a2akY
                      p_a2ak4 = double g_a2ak3
                      (g_a2ak3, gpart_a2akY) = Genome.Split.split gpart_a2akX
                      p_a2ak2 = double g_a2ak1
                      (g_a2ak1, gpart_a2akX) = Genome.Split.split gpart_a2akW
                      p_a2ak0 = Functions.belowten' g_a2ajZ
                      (g_a2ajZ, gpart_a2akW) = Genome.Split.split gpart_a2akV
                      p_a2ajY = double g_a2ajX
                      (g_a2ajX, gpart_a2akV) = Genome.Split.split gpart_a2akU
                      p_a2ajW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajV
                      (g_a2ajV, gpart_a2akU) = Genome.Split.split gpart_a2akT
                      p_a2ajU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajT
                      (g_a2ajT, gpart_a2akT) = Genome.Split.split gpart_a2akS
                      p_a2ajS = Functions.belowten' g_a2ajR
                      (g_a2ajR, gpart_a2akS) = Genome.Split.split gpart_a2akR
                      p_a2ajQ = double g_a2ajP
                      (g_a2ajP, gpart_a2akR) = Genome.Split.split gpart_a2akQ
                      p_a2ajO = double g_a2ajN
                      (g_a2ajN, gpart_a2akQ) = Genome.Split.split gpart_a2akP
                      p_a2ajM = double g_a2ajL
                      (g_a2ajL, gpart_a2akP) = Genome.Split.split gpart_a2akO
                      p_a2ajK = Functions.belowten' g_a2ajJ
                      (g_a2ajJ, gpart_a2akO) = Genome.Split.split gpart_a2akN
                      p_a2ajI = double g_a2ajH
                      (g_a2ajH, gpart_a2akN) = Genome.Split.split gpart_a2akM
                      p_a2ajG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajF
                      (g_a2ajF, gpart_a2akM) = Genome.Split.split gpart_a2akL
                      p_a2ajE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajD
                      (g_a2ajD, gpart_a2akL) = Genome.Split.split gpart_a2akK
                      p_a2ajC = double g_a2ajB
                      (g_a2ajB, gpart_a2akK) = Genome.Split.split gpart_a2akJ
                      p_a2ajA = Functions.belowten' g_a2ajz
                      (g_a2ajz, gpart_a2akJ) = Genome.Split.split gpart_a2akI
                      p_a2ajy = double g_a2ajx
                      (g_a2ajx, gpart_a2akI) = Genome.Split.split gpart_a2akH
                      p_a2ajw = Functions.belowten' g_a2ajv
                      (g_a2ajv, gpart_a2akH) = Genome.Split.split gpart_a2akG
                      p_a2aju = double g_a2ajt
                      (g_a2ajt, gpart_a2akG) = Genome.Split.split gpart_a2akF
                      p_a2ajs = Functions.belowten' g_a2ajr
                      (g_a2ajr, gpart_a2akF) = Genome.Split.split gpart_a2akE
                      p_a2ajq = double g_a2ajp
                      (g_a2ajp, gpart_a2akE) = Genome.Split.split gpart_a2akD
                      p_a2ajo = double g_a2ajn
                      (g_a2ajn, gpart_a2akD) = Genome.Split.split gpart_a2akC
                      p_a2ajm = double g_a2ajl
                      (g_a2ajl, gpart_a2akC) = Genome.Split.split gpart_a2akB
                      p_a2ajk = Functions.belowten' g_a2ajj
                      (g_a2ajj, gpart_a2akB) = Genome.Split.split gpart_a2akA
                      p_a2aji = double g_a2ajh
                      (g_a2ajh, gpart_a2akA) = Genome.Split.split gpart_a2akz
                      p_a2ajg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajf
                      (g_a2ajf, gpart_a2akz) = Genome.Split.split gpart_a2aky
                      p_a2aje
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajd
                      (g_a2ajd, gpart_a2aky) = Genome.Split.split gpart_a2akx
                      p_a2ajc = Functions.belowten' g_a2ajb
                      (g_a2ajb, gpart_a2akx) = Genome.Split.split gpart_a2akw
                      p_a2aja = double g_a2aj9
                      (g_a2aj9, gpart_a2akw) = Genome.Split.split gpart_a2akv
                      p_a2aj8 = double g_a2aj7
                      (g_a2aj7, gpart_a2akv) = Genome.Split.split gpart_a2aku
                      p_a2aj6 = double g_a2aj5
                      (g_a2aj5, gpart_a2aku) = Genome.Split.split gpart_a2akt
                      p_a2aj4 = double g_a2aj3
                      (g_a2aj3, gpart_a2akt) = Genome.Split.split gpart_a2aks
                      p_a2aj2 = double g_a2aj1
                      (g_a2aj1, gpart_a2aks) = Genome.Split.split gpart_a2akr
                      p_a2aj0 = double g_a2aiZ
                      (g_a2aiZ, gpart_a2akr) = Genome.Split.split genome_a2akp
                    in  \ x_a2al9
                          -> let
                               c_PTB_a2ale
                                 = ((Data.Fixed.Vector.toVector x_a2al9) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2alc
                                 = ((Data.Fixed.Vector.toVector x_a2al9) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2ala
                                 = ((Data.Fixed.Vector.toVector x_a2al9) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2alf
                                 = ((Data.Fixed.Vector.toVector x_a2al9) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2alw
                                 = ((Data.Fixed.Vector.toVector x_a2al9) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aj8
                                     * ((p_a2ajm + ((c_NPTB_a2ala / p_a2aja) ** p_a2ajc))
                                        / (((1 + p_a2ajm) + ((c_NPTB_a2ala / p_a2aja) ** p_a2ajc))
                                           + ((c_MiRs_a2alc / p_a2aji) ** p_a2ajk))))
                                    + (negate (p_a2akg * c_PTB_a2ale))),
                                   ((p_a2ajo
                                     / (1
                                        + ((((c_RESTc_a2alf / p_a2ajq) ** p_a2ajs)
                                            + ((c_MiRs_a2alc / p_a2aju) ** p_a2ajw))
                                           + ((c_PTB_a2ale / p_a2ajy) ** p_a2ajA))))
                                    + (negate (p_a2aki * c_NPTB_a2ala))),
                                   ((p_a2ajC
                                     * (p_a2ajM
                                        / ((1 + p_a2ajM) + ((c_RESTc_a2alf / p_a2ajI) ** p_a2ajK))))
                                    + (negate (p_a2akk * c_MiRs_a2alc))),
                                   ((p_a2ajO
                                     * ((p_a2ak2 + ((c_PTB_a2ale / p_a2ajQ) ** p_a2ajS))
                                        / (((1 + p_a2ak2) + ((c_PTB_a2ale / p_a2ajQ) ** p_a2ajS))
                                           + ((c_MiRs_a2alc / p_a2ajY) ** p_a2ak0))))
                                    + (negate (p_a2akm * c_RESTc_a2alf))),
                                   ((p_a2ak4
                                     * ((p_a2ake + ((c_MiRs_a2alc / p_a2ak6) ** p_a2ak8))
                                        / (((1 + p_a2ake) + ((c_MiRs_a2alc / p_a2ak6) ** p_a2ak8))
                                           + ((c_RESTc_a2alf / p_a2aka) ** p_a2akc))))
                                    + (negate (p_a2ako * c_EndoNeuroTFs_a2alw)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526080",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526082",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526084",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526086",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526088",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526090",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526106",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526108",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526122",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526124",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526126",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2akp
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ame
                            p_a2ako = double g_a2akn
                            (g_a2akn, gpart_a2ame) = Genome.Split.split gpart_a2amd
                            p_a2akm = double g_a2akl
                            (g_a2akl, gpart_a2amd) = Genome.Split.split gpart_a2amc
                            p_a2akk = double g_a2akj
                            (g_a2akj, gpart_a2amc) = Genome.Split.split gpart_a2amb
                            p_a2aki = double g_a2akh
                            (g_a2akh, gpart_a2amb) = Genome.Split.split gpart_a2ama
                            p_a2akg = double g_a2akf
                            (g_a2akf, gpart_a2ama) = Genome.Split.split gpart_a2am9
                            p_a2ake = double g_a2akd
                            (g_a2akd, gpart_a2am9) = Genome.Split.split gpart_a2am8
                            p_a2akc = Functions.belowten' g_a2akb
                            (g_a2akb, gpart_a2am8) = Genome.Split.split gpart_a2am7
                            p_a2aka = double g_a2ak9
                            (g_a2ak9, gpart_a2am7) = Genome.Split.split gpart_a2am6
                            p_a2ak8 = Functions.belowten' g_a2ak7
                            (g_a2ak7, gpart_a2am6) = Genome.Split.split gpart_a2am5
                            p_a2ak6 = double g_a2ak5
                            (g_a2ak5, gpart_a2am5) = Genome.Split.split gpart_a2am4
                            p_a2ak4 = double g_a2ak3
                            (g_a2ak3, gpart_a2am4) = Genome.Split.split gpart_a2am3
                            p_a2ak2 = double g_a2ak1
                            (g_a2ak1, gpart_a2am3) = Genome.Split.split gpart_a2am2
                            p_a2ak0 = Functions.belowten' g_a2ajZ
                            (g_a2ajZ, gpart_a2am2) = Genome.Split.split gpart_a2am1
                            p_a2ajY = double g_a2ajX
                            (g_a2ajX, gpart_a2am1) = Genome.Split.split gpart_a2am0
                            p_a2ajW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajV
                            (g_a2ajV, gpart_a2am0) = Genome.Split.split gpart_a2alZ
                            p_a2ajU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajT
                            (g_a2ajT, gpart_a2alZ) = Genome.Split.split gpart_a2alY
                            p_a2ajS = Functions.belowten' g_a2ajR
                            (g_a2ajR, gpart_a2alY) = Genome.Split.split gpart_a2alX
                            p_a2ajQ = double g_a2ajP
                            (g_a2ajP, gpart_a2alX) = Genome.Split.split gpart_a2alW
                            p_a2ajO = double g_a2ajN
                            (g_a2ajN, gpart_a2alW) = Genome.Split.split gpart_a2alV
                            p_a2ajM = double g_a2ajL
                            (g_a2ajL, gpart_a2alV) = Genome.Split.split gpart_a2alU
                            p_a2ajK = Functions.belowten' g_a2ajJ
                            (g_a2ajJ, gpart_a2alU) = Genome.Split.split gpart_a2alT
                            p_a2ajI = double g_a2ajH
                            (g_a2ajH, gpart_a2alT) = Genome.Split.split gpart_a2alS
                            p_a2ajG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajF
                            (g_a2ajF, gpart_a2alS) = Genome.Split.split gpart_a2alR
                            p_a2ajE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajD
                            (g_a2ajD, gpart_a2alR) = Genome.Split.split gpart_a2alQ
                            p_a2ajC = double g_a2ajB
                            (g_a2ajB, gpart_a2alQ) = Genome.Split.split gpart_a2alP
                            p_a2ajA = Functions.belowten' g_a2ajz
                            (g_a2ajz, gpart_a2alP) = Genome.Split.split gpart_a2alO
                            p_a2ajy = double g_a2ajx
                            (g_a2ajx, gpart_a2alO) = Genome.Split.split gpart_a2alN
                            p_a2ajw = Functions.belowten' g_a2ajv
                            (g_a2ajv, gpart_a2alN) = Genome.Split.split gpart_a2alM
                            p_a2aju = double g_a2ajt
                            (g_a2ajt, gpart_a2alM) = Genome.Split.split gpart_a2alL
                            p_a2ajs = Functions.belowten' g_a2ajr
                            (g_a2ajr, gpart_a2alL) = Genome.Split.split gpart_a2alK
                            p_a2ajq = double g_a2ajp
                            (g_a2ajp, gpart_a2alK) = Genome.Split.split gpart_a2alJ
                            p_a2ajo = double g_a2ajn
                            (g_a2ajn, gpart_a2alJ) = Genome.Split.split gpart_a2alI
                            p_a2ajm = double g_a2ajl
                            (g_a2ajl, gpart_a2alI) = Genome.Split.split gpart_a2alH
                            p_a2ajk = Functions.belowten' g_a2ajj
                            (g_a2ajj, gpart_a2alH) = Genome.Split.split gpart_a2alG
                            p_a2aji = double g_a2ajh
                            (g_a2ajh, gpart_a2alG) = Genome.Split.split gpart_a2alF
                            p_a2ajg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajf
                            (g_a2ajf, gpart_a2alF) = Genome.Split.split gpart_a2alE
                            p_a2aje
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ajd
                            (g_a2ajd, gpart_a2alE) = Genome.Split.split gpart_a2alD
                            p_a2ajc = Functions.belowten' g_a2ajb
                            (g_a2ajb, gpart_a2alD) = Genome.Split.split gpart_a2alC
                            p_a2aja = double g_a2aj9
                            (g_a2aj9, gpart_a2alC) = Genome.Split.split gpart_a2alB
                            p_a2aj8 = double g_a2aj7
                            (g_a2aj7, gpart_a2alB) = Genome.Split.split gpart_a2alA
                            p_a2aj6 = double g_a2aj5
                            (g_a2aj5, gpart_a2alA) = Genome.Split.split gpart_a2alz
                            p_a2aj4 = double g_a2aj3
                            (g_a2aj3, gpart_a2alz) = Genome.Split.split gpart_a2aly
                            p_a2aj2 = double g_a2aj1
                            (g_a2aj1, gpart_a2aly) = Genome.Split.split gpart_a2alx
                            p_a2aj0 = double g_a2aiZ
                            (g_a2aiZ, gpart_a2alx) = Genome.Split.split genome_a2akp
                          in
                            \ desc_a2akq
                              -> case desc_a2akq of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aj0)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aj2)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aj4)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aj6)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aj8)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aja)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajc)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aje)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajg)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aji)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajk)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajm)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajo)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajq)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajs)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aju)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajw)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajy)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajS)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajU)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ajY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ak0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ak2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ak4)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ak6)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ak8)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aka)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akc)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ake)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akg)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aki)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akk)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akm)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ako)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a2aoO
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2apx
                      p_a2aoN = double g_a2aoM
                      (g_a2aoM, gpart_a2apx) = Genome.Split.split gpart_a2apw
                      p_a2aoL = double g_a2aoK
                      (g_a2aoK, gpart_a2apw) = Genome.Split.split gpart_a2apv
                      p_a2aoJ = double g_a2aoI
                      (g_a2aoI, gpart_a2apv) = Genome.Split.split gpart_a2apu
                      p_a2aoH = double g_a2aoG
                      (g_a2aoG, gpart_a2apu) = Genome.Split.split gpart_a2apt
                      p_a2aoF = double g_a2aoE
                      (g_a2aoE, gpart_a2apt) = Genome.Split.split gpart_a2aps
                      p_a2aoD = double g_a2aoC
                      (g_a2aoC, gpart_a2aps) = Genome.Split.split gpart_a2apr
                      p_a2aoB = Functions.belowten' g_a2aoA
                      (g_a2aoA, gpart_a2apr) = Genome.Split.split gpart_a2apq
                      p_a2aoz = double g_a2aoy
                      (g_a2aoy, gpart_a2apq) = Genome.Split.split gpart_a2app
                      p_a2aox = Functions.belowten' g_a2aow
                      (g_a2aow, gpart_a2app) = Genome.Split.split gpart_a2apo
                      p_a2aov = double g_a2aou
                      (g_a2aou, gpart_a2apo) = Genome.Split.split gpart_a2apn
                      p_a2aot = double g_a2aos
                      (g_a2aos, gpart_a2apn) = Genome.Split.split gpart_a2apm
                      p_a2aor = double g_a2aoq
                      (g_a2aoq, gpart_a2apm) = Genome.Split.split gpart_a2apl
                      p_a2aop = Functions.belowten' g_a2aoo
                      (g_a2aoo, gpart_a2apl) = Genome.Split.split gpart_a2apk
                      p_a2aon = double g_a2aom
                      (g_a2aom, gpart_a2apk) = Genome.Split.split gpart_a2apj
                      p_a2aol
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aok
                      (g_a2aok, gpart_a2apj) = Genome.Split.split gpart_a2api
                      p_a2aoj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoi
                      (g_a2aoi, gpart_a2api) = Genome.Split.split gpart_a2aph
                      p_a2aoh = Functions.belowten' g_a2aog
                      (g_a2aog, gpart_a2aph) = Genome.Split.split gpart_a2apg
                      p_a2aof = double g_a2aoe
                      (g_a2aoe, gpart_a2apg) = Genome.Split.split gpart_a2apf
                      p_a2aod = double g_a2aoc
                      (g_a2aoc, gpart_a2apf) = Genome.Split.split gpart_a2ape
                      p_a2aob = double g_a2aoa
                      (g_a2aoa, gpart_a2ape) = Genome.Split.split gpart_a2apd
                      p_a2ao9 = Functions.belowten' g_a2ao8
                      (g_a2ao8, gpart_a2apd) = Genome.Split.split gpart_a2apc
                      p_a2ao7 = double g_a2ao6
                      (g_a2ao6, gpart_a2apc) = Genome.Split.split gpart_a2apb
                      p_a2ao5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ao4
                      (g_a2ao4, gpart_a2apb) = Genome.Split.split gpart_a2apa
                      p_a2ao3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ao2
                      (g_a2ao2, gpart_a2apa) = Genome.Split.split gpart_a2ap9
                      p_a2ao1 = double g_a2ao0
                      (g_a2ao0, gpart_a2ap9) = Genome.Split.split gpart_a2ap8
                      p_a2anZ = Functions.belowten' g_a2anY
                      (g_a2anY, gpart_a2ap8) = Genome.Split.split gpart_a2ap7
                      p_a2anX = double g_a2anW
                      (g_a2anW, gpart_a2ap7) = Genome.Split.split gpart_a2ap6
                      p_a2anV = Functions.belowten' g_a2anU
                      (g_a2anU, gpart_a2ap6) = Genome.Split.split gpart_a2ap5
                      p_a2anT = double g_a2anS
                      (g_a2anS, gpart_a2ap5) = Genome.Split.split gpart_a2ap4
                      p_a2anR = Functions.belowten' g_a2anQ
                      (g_a2anQ, gpart_a2ap4) = Genome.Split.split gpart_a2ap3
                      p_a2anP = double g_a2anO
                      (g_a2anO, gpart_a2ap3) = Genome.Split.split gpart_a2ap2
                      p_a2anN = double g_a2anM
                      (g_a2anM, gpart_a2ap2) = Genome.Split.split gpart_a2ap1
                      p_a2anL = double g_a2anK
                      (g_a2anK, gpart_a2ap1) = Genome.Split.split gpart_a2ap0
                      p_a2anJ = Functions.belowten' g_a2anI
                      (g_a2anI, gpart_a2ap0) = Genome.Split.split gpart_a2aoZ
                      p_a2anH = double g_a2anG
                      (g_a2anG, gpart_a2aoZ) = Genome.Split.split gpart_a2aoY
                      p_a2anF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2anE
                      (g_a2anE, gpart_a2aoY) = Genome.Split.split gpart_a2aoX
                      p_a2anD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2anC
                      (g_a2anC, gpart_a2aoX) = Genome.Split.split gpart_a2aoW
                      p_a2anB = Functions.belowten' g_a2anA
                      (g_a2anA, gpart_a2aoW) = Genome.Split.split gpart_a2aoV
                      p_a2anz = double g_a2any
                      (g_a2any, gpart_a2aoV) = Genome.Split.split gpart_a2aoU
                      p_a2anx = double g_a2anw
                      (g_a2anw, gpart_a2aoU) = Genome.Split.split gpart_a2aoT
                      p_a2anv = double g_a2anu
                      (g_a2anu, gpart_a2aoT) = Genome.Split.split gpart_a2aoS
                      p_a2ant = double g_a2ans
                      (g_a2ans, gpart_a2aoS) = Genome.Split.split gpart_a2aoR
                      p_a2anr = double g_a2anq
                      (g_a2anq, gpart_a2aoR) = Genome.Split.split gpart_a2aoQ
                      p_a2anp = double g_a2ano
                      (g_a2ano, gpart_a2aoQ) = Genome.Split.split genome_a2aoO
                    in  \ x_a2apy
                          -> let
                               c_PTB_a2apD
                                 = ((Data.Fixed.Vector.toVector x_a2apy) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2apB
                                 = ((Data.Fixed.Vector.toVector x_a2apy) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2apz
                                 = ((Data.Fixed.Vector.toVector x_a2apy) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2apE
                                 = ((Data.Fixed.Vector.toVector x_a2apy) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2apV
                                 = ((Data.Fixed.Vector.toVector x_a2apy) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2anx
                                     * ((p_a2anL + ((c_NPTB_a2apz / p_a2anz) ** p_a2anB))
                                        / (((1 + p_a2anL) + ((c_NPTB_a2apz / p_a2anz) ** p_a2anB))
                                           + (((p_a2anp / p_a2anD) ** p_a2anF)
                                              + ((c_MiRs_a2apB / p_a2anH) ** p_a2anJ)))))
                                    + (negate (p_a2aoF * c_PTB_a2apD))),
                                   ((p_a2anN
                                     / (1
                                        + ((((c_RESTc_a2apE / p_a2anP) ** p_a2anR)
                                            + ((c_MiRs_a2apB / p_a2anT) ** p_a2anV))
                                           + ((c_PTB_a2apD / p_a2anX) ** p_a2anZ))))
                                    + (negate (p_a2aoH * c_NPTB_a2apz))),
                                   ((p_a2ao1
                                     * (p_a2aob
                                        / ((1 + p_a2aob) + ((c_RESTc_a2apE / p_a2ao7) ** p_a2ao9))))
                                    + (negate (p_a2aoJ * c_MiRs_a2apB))),
                                   ((p_a2aod
                                     * ((p_a2aor + ((c_PTB_a2apD / p_a2aof) ** p_a2aoh))
                                        / (((1 + p_a2aor) + ((c_PTB_a2apD / p_a2aof) ** p_a2aoh))
                                           + ((c_MiRs_a2apB / p_a2aon) ** p_a2aop))))
                                    + (negate (p_a2aoL * c_RESTc_a2apE))),
                                   ((p_a2aot
                                     * ((p_a2aoD + ((c_MiRs_a2apB / p_a2aov) ** p_a2aox))
                                        / (((1 + p_a2aoD) + ((c_MiRs_a2apB / p_a2aov) ** p_a2aox))
                                           + ((c_RESTc_a2apE / p_a2aoz) ** p_a2aoB))))
                                    + (negate (p_a2aoN * c_EndoNeuroTFs_a2apV)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526353",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526355",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526379",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526381",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526395",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526397",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aoO
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aqD
                            p_a2aoN = double g_a2aoM
                            (g_a2aoM, gpart_a2aqD) = Genome.Split.split gpart_a2aqC
                            p_a2aoL = double g_a2aoK
                            (g_a2aoK, gpart_a2aqC) = Genome.Split.split gpart_a2aqB
                            p_a2aoJ = double g_a2aoI
                            (g_a2aoI, gpart_a2aqB) = Genome.Split.split gpart_a2aqA
                            p_a2aoH = double g_a2aoG
                            (g_a2aoG, gpart_a2aqA) = Genome.Split.split gpart_a2aqz
                            p_a2aoF = double g_a2aoE
                            (g_a2aoE, gpart_a2aqz) = Genome.Split.split gpart_a2aqy
                            p_a2aoD = double g_a2aoC
                            (g_a2aoC, gpart_a2aqy) = Genome.Split.split gpart_a2aqx
                            p_a2aoB = Functions.belowten' g_a2aoA
                            (g_a2aoA, gpart_a2aqx) = Genome.Split.split gpart_a2aqw
                            p_a2aoz = double g_a2aoy
                            (g_a2aoy, gpart_a2aqw) = Genome.Split.split gpart_a2aqv
                            p_a2aox = Functions.belowten' g_a2aow
                            (g_a2aow, gpart_a2aqv) = Genome.Split.split gpart_a2aqu
                            p_a2aov = double g_a2aou
                            (g_a2aou, gpart_a2aqu) = Genome.Split.split gpart_a2aqt
                            p_a2aot = double g_a2aos
                            (g_a2aos, gpart_a2aqt) = Genome.Split.split gpart_a2aqs
                            p_a2aor = double g_a2aoq
                            (g_a2aoq, gpart_a2aqs) = Genome.Split.split gpart_a2aqr
                            p_a2aop = Functions.belowten' g_a2aoo
                            (g_a2aoo, gpart_a2aqr) = Genome.Split.split gpart_a2aqq
                            p_a2aon = double g_a2aom
                            (g_a2aom, gpart_a2aqq) = Genome.Split.split gpart_a2aqp
                            p_a2aol
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aok
                            (g_a2aok, gpart_a2aqp) = Genome.Split.split gpart_a2aqo
                            p_a2aoj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoi
                            (g_a2aoi, gpart_a2aqo) = Genome.Split.split gpart_a2aqn
                            p_a2aoh = Functions.belowten' g_a2aog
                            (g_a2aog, gpart_a2aqn) = Genome.Split.split gpart_a2aqm
                            p_a2aof = double g_a2aoe
                            (g_a2aoe, gpart_a2aqm) = Genome.Split.split gpart_a2aql
                            p_a2aod = double g_a2aoc
                            (g_a2aoc, gpart_a2aql) = Genome.Split.split gpart_a2aqk
                            p_a2aob = double g_a2aoa
                            (g_a2aoa, gpart_a2aqk) = Genome.Split.split gpart_a2aqj
                            p_a2ao9 = Functions.belowten' g_a2ao8
                            (g_a2ao8, gpart_a2aqj) = Genome.Split.split gpart_a2aqi
                            p_a2ao7 = double g_a2ao6
                            (g_a2ao6, gpart_a2aqi) = Genome.Split.split gpart_a2aqh
                            p_a2ao5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ao4
                            (g_a2ao4, gpart_a2aqh) = Genome.Split.split gpart_a2aqg
                            p_a2ao3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ao2
                            (g_a2ao2, gpart_a2aqg) = Genome.Split.split gpart_a2aqf
                            p_a2ao1 = double g_a2ao0
                            (g_a2ao0, gpart_a2aqf) = Genome.Split.split gpart_a2aqe
                            p_a2anZ = Functions.belowten' g_a2anY
                            (g_a2anY, gpart_a2aqe) = Genome.Split.split gpart_a2aqd
                            p_a2anX = double g_a2anW
                            (g_a2anW, gpart_a2aqd) = Genome.Split.split gpart_a2aqc
                            p_a2anV = Functions.belowten' g_a2anU
                            (g_a2anU, gpart_a2aqc) = Genome.Split.split gpart_a2aqb
                            p_a2anT = double g_a2anS
                            (g_a2anS, gpart_a2aqb) = Genome.Split.split gpart_a2aqa
                            p_a2anR = Functions.belowten' g_a2anQ
                            (g_a2anQ, gpart_a2aqa) = Genome.Split.split gpart_a2aq9
                            p_a2anP = double g_a2anO
                            (g_a2anO, gpart_a2aq9) = Genome.Split.split gpart_a2aq8
                            p_a2anN = double g_a2anM
                            (g_a2anM, gpart_a2aq8) = Genome.Split.split gpart_a2aq7
                            p_a2anL = double g_a2anK
                            (g_a2anK, gpart_a2aq7) = Genome.Split.split gpart_a2aq6
                            p_a2anJ = Functions.belowten' g_a2anI
                            (g_a2anI, gpart_a2aq6) = Genome.Split.split gpart_a2aq5
                            p_a2anH = double g_a2anG
                            (g_a2anG, gpart_a2aq5) = Genome.Split.split gpart_a2aq4
                            p_a2anF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2anE
                            (g_a2anE, gpart_a2aq4) = Genome.Split.split gpart_a2aq3
                            p_a2anD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2anC
                            (g_a2anC, gpart_a2aq3) = Genome.Split.split gpart_a2aq2
                            p_a2anB = Functions.belowten' g_a2anA
                            (g_a2anA, gpart_a2aq2) = Genome.Split.split gpart_a2aq1
                            p_a2anz = double g_a2any
                            (g_a2any, gpart_a2aq1) = Genome.Split.split gpart_a2aq0
                            p_a2anx = double g_a2anw
                            (g_a2anw, gpart_a2aq0) = Genome.Split.split gpart_a2apZ
                            p_a2anv = double g_a2anu
                            (g_a2anu, gpart_a2apZ) = Genome.Split.split gpart_a2apY
                            p_a2ant = double g_a2ans
                            (g_a2ans, gpart_a2apY) = Genome.Split.split gpart_a2apX
                            p_a2anr = double g_a2anq
                            (g_a2anq, gpart_a2apX) = Genome.Split.split gpart_a2apW
                            p_a2anp = double g_a2ano
                            (g_a2ano, gpart_a2apW) = Genome.Split.split genome_a2aoO
                          in
                            \ desc_a2aoP
                              -> case desc_a2aoP of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anp)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anr)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ant)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anv)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anx)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anz)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anB)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anD)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anF)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anH)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anJ)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anL)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anN)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anP)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anR)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anT)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anV)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anX)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2anZ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ao1)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ao3)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ao5)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ao7)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ao9)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aob)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aod)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aof)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoh)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoj)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aol)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aon)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aop)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aor)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aot)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aov)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aox)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoz)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoB)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoD)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoF)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoH)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoJ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoL)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoN)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWi
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWi) = Genome.Split.split gpart_asWh
                      p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                      (g_asVv, gpart_asWh) = Genome.Split.split gpart_asWg
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWg) = Genome.Split.split gpart_asWf
                      p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                      (g_asVr, gpart_asWf) = Genome.Split.split gpart_asWe
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWe) = Genome.Split.split gpart_asWd
                      p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                      (g_asVn, gpart_asWd) = Genome.Split.split gpart_asWc
                      p_asVm = Functions.belowten' g_asVl
                      (g_asVl, gpart_asWc) = Genome.Split.split gpart_asWb
                      p_asVk = code-0.1.0.0:Genome.FixedList.Functions.double g_asVj
                      (g_asVj, gpart_asWb) = Genome.Split.split gpart_asWa
                      p_asVi = Functions.belowten' g_asVh
                      (g_asVh, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                      (g_asVf, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                      (g_asVd, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                      (g_asVb, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asVa = Functions.belowten' g_asV9
                      (g_asV9, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asV6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                      (g_asV5, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asV4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV3
                      (g_asV3, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asV2 = Functions.belowten' g_asV1
                      (g_asV1, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asUU = Functions.belowten' g_asUT
                      (g_asUT, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asUQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                      (g_asUP, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                      (g_asUN, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                      (g_asUL, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUK = Functions.belowten' g_asUJ
                      (g_asUJ, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                      (g_asUH, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUG = Functions.belowten' g_asUF
                      (g_asUF, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                      (g_asUD, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUC = Functions.belowten' g_asUB
                      (g_asUB, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                      (g_asUz, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUu = Functions.belowten' g_asUt
                      (g_asUt, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                      (g_asUr, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUp
                      (g_asUp, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                      (g_asUn, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUm = Functions.belowten' g_asUl
                      (g_asUl, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                      (g_asUh, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                      (g_asUd, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asVB) = Genome.Split.split genome_asVz
                    in
                      [Reaction
                         (\ x_asWj
                            -> let
                                 c_MiRs_asWm = ((toVector x_asWj) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asWk = ((toVector x_asWj) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUi
                                  * ((p_asUw + ((c_NPTB_asWk / p_asUk) ** p_asUm))
                                     / (((1 + p_asUw) + ((c_NPTB_asWk / p_asUk) ** p_asUm))
                                        + ((c_MiRs_asWm / p_asUs) ** p_asUu)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWn
                            -> let
                                 c_MiRs_asWp = ((toVector x_asWn) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWo = ((toVector x_asWn) Data.Vector.Unboxed.! 3)
                                 c_PTB_asWq = ((toVector x_asWn) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUy
                                  / (1
                                     + ((((c_RESTc_asWo / p_asUA) ** p_asUC)
                                         + ((c_MiRs_asWp / p_asUE) ** p_asUG))
                                        + ((c_PTB_asWq / p_asUI) ** p_asUK)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWr
                            -> let c_RESTc_asWs = ((toVector x_asWr) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUM
                                  * ((p_asUW + ((p_asUe / p_asUO) ** p_asUQ))
                                     / (((1 + p_asUW) + ((p_asUe / p_asUO) ** p_asUQ))
                                        + ((c_RESTc_asWs / p_asUS) ** p_asUU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWt
                            -> let
                                 c_MiRs_asWw = ((toVector x_asWt) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWu = ((toVector x_asWt) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUY
                                  * ((p_asVc + ((c_PTB_asWu / p_asV0) ** p_asV2))
                                     / (((1 + p_asVc) + ((c_PTB_asWu / p_asV0) ** p_asV2))
                                        + (((p_asUa / p_asV4) ** p_asV6)
                                           + ((c_MiRs_asWw / p_asV8) ** p_asVa))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWx
                            -> let
                                 c_RESTc_asWA = ((toVector x_asWx) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWy = ((toVector x_asWx) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asVe
                                  * ((p_asVo + ((c_MiRs_asWy / p_asVg) ** p_asVi))
                                     / (((1 + p_asVo) + ((c_MiRs_asWy / p_asVg) ** p_asVi))
                                        + ((c_RESTc_asWA / p_asVk) ** p_asVm)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWB
                            -> let c_PTB_asWC = ((toVector x_asWB) Data.Vector.Unboxed.! 0)
                               in (p_asVq * c_PTB_asWC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWD
                            -> let c_NPTB_asWE = ((toVector x_asWD) Data.Vector.Unboxed.! 1)
                               in (p_asVs * c_NPTB_asWE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWF
                            -> let c_MiRs_asWG = ((toVector x_asWF) Data.Vector.Unboxed.! 2)
                               in (p_asVu * c_MiRs_asWG))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWH
                            -> let c_RESTc_asWI = ((toVector x_asWH) Data.Vector.Unboxed.! 3)
                               in (p_asVw * c_RESTc_asWI))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWJ
                            -> let
                                 c_EndoNeuroTFs_asWK = ((toVector x_asWJ) Data.Vector.Unboxed.! 4)
                               in (p_asVy * c_EndoNeuroTFs_asWK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXx
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                            (g_asVv, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                            (g_asVr, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                            (g_asVn, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVm = Functions.belowten' g_asVl
                            (g_asVl, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVk = code-0.1.0.0:Genome.FixedList.Functions.double g_asVj
                            (g_asVj, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVi = Functions.belowten' g_asVh
                            (g_asVh, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVg = code-0.1.0.0:Genome.FixedList.Functions.double g_asVf
                            (g_asVf, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                            (g_asVd, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                            (g_asVb, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asVa = Functions.belowten' g_asV9
                            (g_asV9, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asV6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                            (g_asV5, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asV4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV3
                            (g_asV3, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asV2 = Functions.belowten' g_asV1
                            (g_asV1, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asUU = Functions.belowten' g_asUT
                            (g_asUT, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asUQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUP
                            (g_asUP, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asUO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUN
                            (g_asUN, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                            (g_asUL, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asUK = Functions.belowten' g_asUJ
                            (g_asUJ, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asUI = code-0.1.0.0:Genome.FixedList.Functions.double g_asUH
                            (g_asUH, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUG = Functions.belowten' g_asUF
                            (g_asUF, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUE = code-0.1.0.0:Genome.FixedList.Functions.double g_asUD
                            (g_asUD, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUC = Functions.belowten' g_asUB
                            (g_asUB, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                            (g_asUz, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUu = Functions.belowten' g_asUt
                            (g_asUt, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUs = code-0.1.0.0:Genome.FixedList.Functions.double g_asUr
                            (g_asUr, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUp
                            (g_asUp, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                            (g_asUn, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUm = Functions.belowten' g_asUl
                            (g_asUl, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUi = code-0.1.0.0:Genome.FixedList.Functions.double g_asUh
                            (g_asUh, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUe = code-0.1.0.0:Genome.FixedList.Functions.double g_asUd
                            (g_asUd, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asWQ) = Genome.Split.split genome_asVz
                          in
                            \ desc_asVA
                              -> case desc_asVA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZE
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0n
                      p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                      (g_asZC, gpart_at0n) = Genome.Split.split gpart_at0m
                      p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                      (g_asZA, gpart_at0m) = Genome.Split.split gpart_at0l
                      p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                      (g_asZy, gpart_at0l) = Genome.Split.split gpart_at0k
                      p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                      (g_asZw, gpart_at0k) = Genome.Split.split gpart_at0j
                      p_asZv = code-0.1.0.0:Genome.FixedList.Functions.double g_asZu
                      (g_asZu, gpart_at0j) = Genome.Split.split gpart_at0i
                      p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                      (g_asZs, gpart_at0i) = Genome.Split.split gpart_at0h
                      p_asZr = Functions.belowten' g_asZq
                      (g_asZq, gpart_at0h) = Genome.Split.split gpart_at0g
                      p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                      (g_asZo, gpart_at0g) = Genome.Split.split gpart_at0f
                      p_asZn = Functions.belowten' g_asZm
                      (g_asZm, gpart_at0f) = Genome.Split.split gpart_at0e
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at0e) = Genome.Split.split gpart_at0d
                      p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                      (g_asZi, gpart_at0d) = Genome.Split.split gpart_at0c
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at0c) = Genome.Split.split gpart_at0b
                      p_asZf = Functions.belowten' g_asZe
                      (g_asZe, gpart_at0b) = Genome.Split.split gpart_at0a
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_at0a) = Genome.Split.split gpart_at09
                      p_asZb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZa
                      (g_asZa, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZ9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ8
                      (g_asZ8, gpart_at08) = Genome.Split.split gpart_at07
                      p_asZ7 = Functions.belowten' g_asZ6
                      (g_asZ6, gpart_at07) = Genome.Split.split gpart_at06
                      p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                      (g_asZ4, gpart_at06) = Genome.Split.split gpart_at05
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_at05) = Genome.Split.split gpart_at04
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_at04) = Genome.Split.split gpart_at03
                      p_asYZ = Functions.belowten' g_asYY
                      (g_asYY, gpart_at03) = Genome.Split.split gpart_at02
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_at02) = Genome.Split.split gpart_at01
                      p_asYV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYU
                      (g_asYU, gpart_at01) = Genome.Split.split gpart_at00
                      p_asYT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                      (g_asYS, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                      (g_asYQ, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asYP = Functions.belowten' g_asYO
                      (g_asYO, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asYL = Functions.belowten' g_asYK
                      (g_asYK, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYH = Functions.belowten' g_asYG
                      (g_asYG, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                      (g_asYE, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                      (g_asYC, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYz = Functions.belowten' g_asYy
                      (g_asYy, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYu
                      (g_asYu, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYs
                      (g_asYs, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYr = Functions.belowten' g_asYq
                      (g_asYq, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                      (g_asYe, gpart_asZG) = Genome.Split.split genome_asZE
                    in
                      [Reaction
                         (\ x_at0o
                            -> let
                                 c_MiRs_at0r = ((toVector x_at0o) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at0p = ((toVector x_at0o) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYn
                                  * ((p_asYB + ((c_NPTB_at0p / p_asYp) ** p_asYr))
                                     / (((1 + p_asYB) + ((c_NPTB_at0p / p_asYp) ** p_asYr))
                                        + ((c_MiRs_at0r / p_asYx) ** p_asYz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0s
                            -> let
                                 c_MiRs_at0u = ((toVector x_at0s) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at0t = ((toVector x_at0s) Data.Vector.Unboxed.! 3)
                                 c_PTB_at0v = ((toVector x_at0s) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYD
                                  / (1
                                     + ((((c_RESTc_at0t / p_asYF) ** p_asYH)
                                         + ((c_MiRs_at0u / p_asYJ) ** p_asYL))
                                        + ((c_PTB_at0v / p_asYN) ** p_asYP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0w
                            -> let c_RESTc_at0x = ((toVector x_at0w) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYR
                                  * (p_asZ1
                                     / ((1 + p_asZ1) + ((c_RESTc_at0x / p_asYX) ** p_asYZ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0y
                            -> let
                                 c_MiRs_at0B = ((toVector x_at0y) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0z = ((toVector x_at0y) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZ3
                                  * ((p_asZh + ((c_PTB_at0z / p_asZ5) ** p_asZ7))
                                     / (((1 + p_asZh) + ((c_PTB_at0z / p_asZ5) ** p_asZ7))
                                        + (((p_asYf / p_asZ9) ** p_asZb)
                                           + ((c_MiRs_at0B / p_asZd) ** p_asZf))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0C
                            -> let
                                 c_RESTc_at0F = ((toVector x_at0C) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0D = ((toVector x_at0C) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZj
                                  * ((p_asZt + ((c_MiRs_at0D / p_asZl) ** p_asZn))
                                     / (((1 + p_asZt) + ((c_MiRs_at0D / p_asZl) ** p_asZn))
                                        + ((c_RESTc_at0F / p_asZp) ** p_asZr)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0G
                            -> let c_PTB_at0H = ((toVector x_at0G) Data.Vector.Unboxed.! 0)
                               in (p_asZv * c_PTB_at0H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0I
                            -> let c_NPTB_at0J = ((toVector x_at0I) Data.Vector.Unboxed.! 1)
                               in (p_asZx * c_NPTB_at0J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0K
                            -> let c_MiRs_at0L = ((toVector x_at0K) Data.Vector.Unboxed.! 2)
                               in (p_asZz * c_MiRs_at0L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0M
                            -> let c_RESTc_at0N = ((toVector x_at0M) Data.Vector.Unboxed.! 3)
                               in (p_asZB * c_RESTc_at0N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0O
                            -> let
                                 c_EndoNeuroTFs_at0P = ((toVector x_at0O) Data.Vector.Unboxed.! 4)
                               in (p_asZD * c_EndoNeuroTFs_at0P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZE
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1x
                            p_asZD = code-0.1.0.0:Genome.FixedList.Functions.double g_asZC
                            (g_asZC, gpart_at1x) = Genome.Split.split gpart_at1w
                            p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                            (g_asZA, gpart_at1w) = Genome.Split.split gpart_at1v
                            p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                            (g_asZy, gpart_at1v) = Genome.Split.split gpart_at1u
                            p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                            (g_asZw, gpart_at1u) = Genome.Split.split gpart_at1t
                            p_asZv = code-0.1.0.0:Genome.FixedList.Functions.double g_asZu
                            (g_asZu, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                            (g_asZs, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZr = Functions.belowten' g_asZq
                            (g_asZq, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                            (g_asZo, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZn = Functions.belowten' g_asZm
                            (g_asZm, gpart_at1p) = Genome.Split.split gpart_at1o
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at1o) = Genome.Split.split gpart_at1n
                            p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                            (g_asZi, gpart_at1n) = Genome.Split.split gpart_at1m
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at1m) = Genome.Split.split gpart_at1l
                            p_asZf = Functions.belowten' g_asZe
                            (g_asZe, gpart_at1l) = Genome.Split.split gpart_at1k
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at1k) = Genome.Split.split gpart_at1j
                            p_asZb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZa
                            (g_asZa, gpart_at1j) = Genome.Split.split gpart_at1i
                            p_asZ9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ8
                            (g_asZ8, gpart_at1i) = Genome.Split.split gpart_at1h
                            p_asZ7 = Functions.belowten' g_asZ6
                            (g_asZ6, gpart_at1h) = Genome.Split.split gpart_at1g
                            p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                            (g_asZ4, gpart_at1g) = Genome.Split.split gpart_at1f
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asYZ = Functions.belowten' g_asYY
                            (g_asYY, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asYV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYU
                            (g_asYU, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asYT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                            (g_asYS, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                            (g_asYQ, gpart_at19) = Genome.Split.split gpart_at18
                            p_asYP = Functions.belowten' g_asYO
                            (g_asYO, gpart_at18) = Genome.Split.split gpart_at17
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at17) = Genome.Split.split gpart_at16
                            p_asYL = Functions.belowten' g_asYK
                            (g_asYK, gpart_at16) = Genome.Split.split gpart_at15
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at15) = Genome.Split.split gpart_at14
                            p_asYH = Functions.belowten' g_asYG
                            (g_asYG, gpart_at14) = Genome.Split.split gpart_at13
                            p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                            (g_asYE, gpart_at13) = Genome.Split.split gpart_at12
                            p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                            (g_asYC, gpart_at12) = Genome.Split.split gpart_at11
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYz = Functions.belowten' g_asYy
                            (g_asYy, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYu
                            (g_asYu, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYs
                            (g_asYs, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYr = Functions.belowten' g_asYq
                            (g_asYq, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                            (g_asYe, gpart_at0Q) = Genome.Split.split genome_asZE
                          in
                            \ desc_asZF
                              -> case desc_asZF of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZp)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZt)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZv)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZx)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZz)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZB)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZD)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3E
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4n
                      p_at3D = code-0.1.0.0:Genome.FixedList.Functions.double g_at3C
                      (g_at3C, gpart_at4n) = Genome.Split.split gpart_at4m
                      p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                      (g_at3A, gpart_at4m) = Genome.Split.split gpart_at4l
                      p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                      (g_at3y, gpart_at4l) = Genome.Split.split gpart_at4k
                      p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                      (g_at3w, gpart_at4k) = Genome.Split.split gpart_at4j
                      p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                      (g_at3u, gpart_at4j) = Genome.Split.split gpart_at4i
                      p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                      (g_at3s, gpart_at4i) = Genome.Split.split gpart_at4h
                      p_at3r = Functions.belowten' g_at3q
                      (g_at3q, gpart_at4h) = Genome.Split.split gpart_at4g
                      p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                      (g_at3o, gpart_at4g) = Genome.Split.split gpart_at4f
                      p_at3n = Functions.belowten' g_at3m
                      (g_at3m, gpart_at4f) = Genome.Split.split gpart_at4e
                      p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                      (g_at3k, gpart_at4e) = Genome.Split.split gpart_at4d
                      p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                      (g_at3i, gpart_at4d) = Genome.Split.split gpart_at4c
                      p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                      (g_at3g, gpart_at4c) = Genome.Split.split gpart_at4b
                      p_at3f = Functions.belowten' g_at3e
                      (g_at3e, gpart_at4b) = Genome.Split.split gpart_at4a
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at4a) = Genome.Split.split gpart_at49
                      p_at3b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3a
                      (g_at3a, gpart_at49) = Genome.Split.split gpart_at48
                      p_at39
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at38
                      (g_at38, gpart_at48) = Genome.Split.split gpart_at47
                      p_at37 = Functions.belowten' g_at36
                      (g_at36, gpart_at47) = Genome.Split.split gpart_at46
                      p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                      (g_at34, gpart_at46) = Genome.Split.split gpart_at45
                      p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                      (g_at32, gpart_at45) = Genome.Split.split gpart_at44
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at44) = Genome.Split.split gpart_at43
                      p_at2Z = Functions.belowten' g_at2Y
                      (g_at2Y, gpart_at43) = Genome.Split.split gpart_at42
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at42) = Genome.Split.split gpart_at41
                      p_at2V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2U
                      (g_at2U, gpart_at41) = Genome.Split.split gpart_at40
                      p_at2T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2S
                      (g_at2S, gpart_at40) = Genome.Split.split gpart_at3Z
                      p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                      (g_at2Q, gpart_at3Z) = Genome.Split.split gpart_at3Y
                      p_at2P = Functions.belowten' g_at2O
                      (g_at2O, gpart_at3Y) = Genome.Split.split gpart_at3X
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at3X) = Genome.Split.split gpart_at3W
                      p_at2L = Functions.belowten' g_at2K
                      (g_at2K, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at2H = Functions.belowten' g_at2G
                      (g_at2G, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                      (g_at2E, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                      (g_at2C, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                      (g_at2A, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at2z = Functions.belowten' g_at2y
                      (g_at2y, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                      (g_at2w, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at2v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2u
                      (g_at2u, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at2t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2s
                      (g_at2s, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at2r = Functions.belowten' g_at2q
                      (g_at2q, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                      (g_at2m, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                      (g_at2k, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                      (g_at2i, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                      (g_at2g, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                      (g_at2e, gpart_at3G) = Genome.Split.split genome_at3E
                    in
                      [Reaction
                         (\ x_at4o
                            -> let
                                 c_MiRs_at4r = ((toVector x_at4o) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at4p = ((toVector x_at4o) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2n
                                  * ((p_at2B + ((c_NPTB_at4p / p_at2p) ** p_at2r))
                                     / (((1 + p_at2B) + ((c_NPTB_at4p / p_at2p) ** p_at2r))
                                        + ((c_MiRs_at4r / p_at2x) ** p_at2z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4s
                            -> let
                                 c_MiRs_at4u = ((toVector x_at4s) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at4t = ((toVector x_at4s) Data.Vector.Unboxed.! 3)
                                 c_PTB_at4v = ((toVector x_at4s) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2D
                                  / (1
                                     + ((((c_RESTc_at4t / p_at2F) ** p_at2H)
                                         + ((c_MiRs_at4u / p_at2J) ** p_at2L))
                                        + ((c_PTB_at4v / p_at2N) ** p_at2P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at4w
                            -> let c_RESTc_at4x = ((toVector x_at4w) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2R
                                  * (p_at31
                                     / ((1 + p_at31) + ((c_RESTc_at4x / p_at2X) ** p_at2Z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4y
                            -> let
                                 c_MiRs_at4B = ((toVector x_at4y) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4z = ((toVector x_at4y) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at33
                                  * ((p_at3h + ((c_PTB_at4z / p_at35) ** p_at37))
                                     / (((1 + p_at3h) + ((c_PTB_at4z / p_at35) ** p_at37))
                                        + ((c_MiRs_at4B / p_at3d) ** p_at3f)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4C
                            -> let
                                 c_RESTc_at4F = ((toVector x_at4C) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at4D = ((toVector x_at4C) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3j
                                  * ((p_at3t + ((c_MiRs_at4D / p_at3l) ** p_at3n))
                                     / (((1 + p_at3t) + ((c_MiRs_at4D / p_at3l) ** p_at3n))
                                        + ((c_RESTc_at4F / p_at3p) ** p_at3r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4G
                            -> let c_PTB_at4H = ((toVector x_at4G) Data.Vector.Unboxed.! 0)
                               in (p_at3v * c_PTB_at4H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4I
                            -> let c_NPTB_at4J = ((toVector x_at4I) Data.Vector.Unboxed.! 1)
                               in (p_at3x * c_NPTB_at4J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4K
                            -> let c_MiRs_at4L = ((toVector x_at4K) Data.Vector.Unboxed.! 2)
                               in (p_at3z * c_MiRs_at4L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4M
                            -> let c_RESTc_at4N = ((toVector x_at4M) Data.Vector.Unboxed.! 3)
                               in (p_at3B * c_RESTc_at4N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4O
                            -> let
                                 c_EndoNeuroTFs_at4P = ((toVector x_at4O) Data.Vector.Unboxed.! 4)
                               in (p_at3D * c_EndoNeuroTFs_at4P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121481",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121483",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3E
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5x
                            p_at3D = code-0.1.0.0:Genome.FixedList.Functions.double g_at3C
                            (g_at3C, gpart_at5x) = Genome.Split.split gpart_at5w
                            p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                            (g_at3A, gpart_at5w) = Genome.Split.split gpart_at5v
                            p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                            (g_at3y, gpart_at5v) = Genome.Split.split gpart_at5u
                            p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                            (g_at3w, gpart_at5u) = Genome.Split.split gpart_at5t
                            p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                            (g_at3u, gpart_at5t) = Genome.Split.split gpart_at5s
                            p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                            (g_at3s, gpart_at5s) = Genome.Split.split gpart_at5r
                            p_at3r = Functions.belowten' g_at3q
                            (g_at3q, gpart_at5r) = Genome.Split.split gpart_at5q
                            p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                            (g_at3o, gpart_at5q) = Genome.Split.split gpart_at5p
                            p_at3n = Functions.belowten' g_at3m
                            (g_at3m, gpart_at5p) = Genome.Split.split gpart_at5o
                            p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                            (g_at3k, gpart_at5o) = Genome.Split.split gpart_at5n
                            p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                            (g_at3i, gpart_at5n) = Genome.Split.split gpart_at5m
                            p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                            (g_at3g, gpart_at5m) = Genome.Split.split gpart_at5l
                            p_at3f = Functions.belowten' g_at3e
                            (g_at3e, gpart_at5l) = Genome.Split.split gpart_at5k
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at5k) = Genome.Split.split gpart_at5j
                            p_at3b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3a
                            (g_at3a, gpart_at5j) = Genome.Split.split gpart_at5i
                            p_at39
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at38
                            (g_at38, gpart_at5i) = Genome.Split.split gpart_at5h
                            p_at37 = Functions.belowten' g_at36
                            (g_at36, gpart_at5h) = Genome.Split.split gpart_at5g
                            p_at35 = code-0.1.0.0:Genome.FixedList.Functions.double g_at34
                            (g_at34, gpart_at5g) = Genome.Split.split gpart_at5f
                            p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                            (g_at32, gpart_at5f) = Genome.Split.split gpart_at5e
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at5e) = Genome.Split.split gpart_at5d
                            p_at2Z = Functions.belowten' g_at2Y
                            (g_at2Y, gpart_at5d) = Genome.Split.split gpart_at5c
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at5c) = Genome.Split.split gpart_at5b
                            p_at2V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2U
                            (g_at2U, gpart_at5b) = Genome.Split.split gpart_at5a
                            p_at2T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2S
                            (g_at2S, gpart_at5a) = Genome.Split.split gpart_at59
                            p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                            (g_at2Q, gpart_at59) = Genome.Split.split gpart_at58
                            p_at2P = Functions.belowten' g_at2O
                            (g_at2O, gpart_at58) = Genome.Split.split gpart_at57
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at57) = Genome.Split.split gpart_at56
                            p_at2L = Functions.belowten' g_at2K
                            (g_at2K, gpart_at56) = Genome.Split.split gpart_at55
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at55) = Genome.Split.split gpart_at54
                            p_at2H = Functions.belowten' g_at2G
                            (g_at2G, gpart_at54) = Genome.Split.split gpart_at53
                            p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                            (g_at2E, gpart_at53) = Genome.Split.split gpart_at52
                            p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                            (g_at2C, gpart_at52) = Genome.Split.split gpart_at51
                            p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                            (g_at2A, gpart_at51) = Genome.Split.split gpart_at50
                            p_at2z = Functions.belowten' g_at2y
                            (g_at2y, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at2x = code-0.1.0.0:Genome.FixedList.Functions.double g_at2w
                            (g_at2w, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at2v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2u
                            (g_at2u, gpart_at4Y) = Genome.Split.split gpart_at4X
                            p_at2t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2s
                            (g_at2s, gpart_at4X) = Genome.Split.split gpart_at4W
                            p_at2r = Functions.belowten' g_at2q
                            (g_at2q, gpart_at4W) = Genome.Split.split gpart_at4V
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                            (g_at2m, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                            (g_at2k, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                            (g_at2i, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                            (g_at2g, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                            (g_at2e, gpart_at4Q) = Genome.Split.split genome_at3E
                          in
                            \ desc_at3F
                              -> case desc_at3F of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at33)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at35)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3h)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3j)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3l)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3n)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3p)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3r)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3t)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3v)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3x)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3z)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3B)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3D)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at7E
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8n
                      p_at7D = code-0.1.0.0:Genome.FixedList.Functions.double g_at7C
                      (g_at7C, gpart_at8n) = Genome.Split.split gpart_at8m
                      p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                      (g_at7A, gpart_at8m) = Genome.Split.split gpart_at8l
                      p_at7z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7y
                      (g_at7y, gpart_at8l) = Genome.Split.split gpart_at8k
                      p_at7x = code-0.1.0.0:Genome.FixedList.Functions.double g_at7w
                      (g_at7w, gpart_at8k) = Genome.Split.split gpart_at8j
                      p_at7v = code-0.1.0.0:Genome.FixedList.Functions.double g_at7u
                      (g_at7u, gpart_at8j) = Genome.Split.split gpart_at8i
                      p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                      (g_at7s, gpart_at8i) = Genome.Split.split gpart_at8h
                      p_at7r = Functions.belowten' g_at7q
                      (g_at7q, gpart_at8h) = Genome.Split.split gpart_at8g
                      p_at7p = code-0.1.0.0:Genome.FixedList.Functions.double g_at7o
                      (g_at7o, gpart_at8g) = Genome.Split.split gpart_at8f
                      p_at7n = Functions.belowten' g_at7m
                      (g_at7m, gpart_at8f) = Genome.Split.split gpart_at8e
                      p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                      (g_at7k, gpart_at8e) = Genome.Split.split gpart_at8d
                      p_at7j = code-0.1.0.0:Genome.FixedList.Functions.double g_at7i
                      (g_at7i, gpart_at8d) = Genome.Split.split gpart_at8c
                      p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                      (g_at7g, gpart_at8c) = Genome.Split.split gpart_at8b
                      p_at7f = Functions.belowten' g_at7e
                      (g_at7e, gpart_at8b) = Genome.Split.split gpart_at8a
                      p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                      (g_at7c, gpart_at8a) = Genome.Split.split gpart_at89
                      p_at7b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7a
                      (g_at7a, gpart_at89) = Genome.Split.split gpart_at88
                      p_at79
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at78
                      (g_at78, gpart_at88) = Genome.Split.split gpart_at87
                      p_at77 = Functions.belowten' g_at76
                      (g_at76, gpart_at87) = Genome.Split.split gpart_at86
                      p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                      (g_at74, gpart_at86) = Genome.Split.split gpart_at85
                      p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                      (g_at72, gpart_at85) = Genome.Split.split gpart_at84
                      p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                      (g_at70, gpart_at84) = Genome.Split.split gpart_at83
                      p_at6Z = Functions.belowten' g_at6Y
                      (g_at6Y, gpart_at83) = Genome.Split.split gpart_at82
                      p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                      (g_at6W, gpart_at82) = Genome.Split.split gpart_at81
                      p_at6V
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6U
                      (g_at6U, gpart_at81) = Genome.Split.split gpart_at80
                      p_at6T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6S
                      (g_at6S, gpart_at80) = Genome.Split.split gpart_at7Z
                      p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                      (g_at6Q, gpart_at7Z) = Genome.Split.split gpart_at7Y
                      p_at6P = Functions.belowten' g_at6O
                      (g_at6O, gpart_at7Y) = Genome.Split.split gpart_at7X
                      p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                      (g_at6M, gpart_at7X) = Genome.Split.split gpart_at7W
                      p_at6L = Functions.belowten' g_at6K
                      (g_at6K, gpart_at7W) = Genome.Split.split gpart_at7V
                      p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                      (g_at6I, gpart_at7V) = Genome.Split.split gpart_at7U
                      p_at6H = Functions.belowten' g_at6G
                      (g_at6G, gpart_at7U) = Genome.Split.split gpart_at7T
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7T) = Genome.Split.split gpart_at7S
                      p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                      (g_at6C, gpart_at7S) = Genome.Split.split gpart_at7R
                      p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                      (g_at6A, gpart_at7R) = Genome.Split.split gpart_at7Q
                      p_at6z = Functions.belowten' g_at6y
                      (g_at6y, gpart_at7Q) = Genome.Split.split gpart_at7P
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7P) = Genome.Split.split gpart_at7O
                      p_at6v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6u
                      (g_at6u, gpart_at7O) = Genome.Split.split gpart_at7N
                      p_at6t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                      (g_at6s, gpart_at7N) = Genome.Split.split gpart_at7M
                      p_at6r = Functions.belowten' g_at6q
                      (g_at6q, gpart_at7M) = Genome.Split.split gpart_at7L
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7L) = Genome.Split.split gpart_at7K
                      p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                      (g_at6m, gpart_at7K) = Genome.Split.split gpart_at7J
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at7J) = Genome.Split.split gpart_at7I
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7I) = Genome.Split.split gpart_at7H
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at7H) = Genome.Split.split gpart_at7G
                      p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                      (g_at6e, gpart_at7G) = Genome.Split.split genome_at7E
                    in
                      [Reaction
                         (\ x_at8o
                            -> let
                                 c_MiRs_at8r = ((toVector x_at8o) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at8p = ((toVector x_at8o) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at6n
                                  * ((p_at6B + ((c_NPTB_at8p / p_at6p) ** p_at6r))
                                     / (((1 + p_at6B) + ((c_NPTB_at8p / p_at6p) ** p_at6r))
                                        + (((p_at6f / p_at6t) ** p_at6v)
                                           + ((c_MiRs_at8r / p_at6x) ** p_at6z))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8s
                            -> let
                                 c_MiRs_at8u = ((toVector x_at8s) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at8t = ((toVector x_at8s) Data.Vector.Unboxed.! 3)
                                 c_PTB_at8v = ((toVector x_at8s) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6D
                                  / (1
                                     + ((((c_RESTc_at8t / p_at6F) ** p_at6H)
                                         + ((c_MiRs_at8u / p_at6J) ** p_at6L))
                                        + ((c_PTB_at8v / p_at6N) ** p_at6P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at8w
                            -> let c_RESTc_at8x = ((toVector x_at8w) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6R
                                  * (p_at71
                                     / ((1 + p_at71) + ((c_RESTc_at8x / p_at6X) ** p_at6Z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at8y
                            -> let
                                 c_MiRs_at8B = ((toVector x_at8y) Data.Vector.Unboxed.! 2)
                                 c_PTB_at8z = ((toVector x_at8y) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at73
                                  * ((p_at7h + ((c_PTB_at8z / p_at75) ** p_at77))
                                     / (((1 + p_at7h) + ((c_PTB_at8z / p_at75) ** p_at77))
                                        + ((c_MiRs_at8B / p_at7d) ** p_at7f)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at8C
                            -> let
                                 c_RESTc_at8F = ((toVector x_at8C) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at8D = ((toVector x_at8C) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at7j
                                  * ((p_at7t + ((c_MiRs_at8D / p_at7l) ** p_at7n))
                                     / (((1 + p_at7t) + ((c_MiRs_at8D / p_at7l) ** p_at7n))
                                        + ((c_RESTc_at8F / p_at7p) ** p_at7r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at8G
                            -> let c_PTB_at8H = ((toVector x_at8G) Data.Vector.Unboxed.! 0)
                               in (p_at7v * c_PTB_at8H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at8I
                            -> let c_NPTB_at8J = ((toVector x_at8I) Data.Vector.Unboxed.! 1)
                               in (p_at7x * c_NPTB_at8J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at8K
                            -> let c_MiRs_at8L = ((toVector x_at8K) Data.Vector.Unboxed.! 2)
                               in (p_at7z * c_MiRs_at8L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at8M
                            -> let c_RESTc_at8N = ((toVector x_at8M) Data.Vector.Unboxed.! 3)
                               in (p_at7B * c_RESTc_at8N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at8O
                            -> let
                                 c_EndoNeuroTFs_at8P = ((toVector x_at8O) Data.Vector.Unboxed.! 4)
                               in (p_at7D * c_EndoNeuroTFs_at8P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121711",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121713",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at7E
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9x
                            p_at7D = code-0.1.0.0:Genome.FixedList.Functions.double g_at7C
                            (g_at7C, gpart_at9x) = Genome.Split.split gpart_at9w
                            p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                            (g_at7A, gpart_at9w) = Genome.Split.split gpart_at9v
                            p_at7z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7y
                            (g_at7y, gpart_at9v) = Genome.Split.split gpart_at9u
                            p_at7x = code-0.1.0.0:Genome.FixedList.Functions.double g_at7w
                            (g_at7w, gpart_at9u) = Genome.Split.split gpart_at9t
                            p_at7v = code-0.1.0.0:Genome.FixedList.Functions.double g_at7u
                            (g_at7u, gpart_at9t) = Genome.Split.split gpart_at9s
                            p_at7t = code-0.1.0.0:Genome.FixedList.Functions.double g_at7s
                            (g_at7s, gpart_at9s) = Genome.Split.split gpart_at9r
                            p_at7r = Functions.belowten' g_at7q
                            (g_at7q, gpart_at9r) = Genome.Split.split gpart_at9q
                            p_at7p = code-0.1.0.0:Genome.FixedList.Functions.double g_at7o
                            (g_at7o, gpart_at9q) = Genome.Split.split gpart_at9p
                            p_at7n = Functions.belowten' g_at7m
                            (g_at7m, gpart_at9p) = Genome.Split.split gpart_at9o
                            p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                            (g_at7k, gpart_at9o) = Genome.Split.split gpart_at9n
                            p_at7j = code-0.1.0.0:Genome.FixedList.Functions.double g_at7i
                            (g_at7i, gpart_at9n) = Genome.Split.split gpart_at9m
                            p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                            (g_at7g, gpart_at9m) = Genome.Split.split gpart_at9l
                            p_at7f = Functions.belowten' g_at7e
                            (g_at7e, gpart_at9l) = Genome.Split.split gpart_at9k
                            p_at7d = code-0.1.0.0:Genome.FixedList.Functions.double g_at7c
                            (g_at7c, gpart_at9k) = Genome.Split.split gpart_at9j
                            p_at7b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7a
                            (g_at7a, gpart_at9j) = Genome.Split.split gpart_at9i
                            p_at79
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at78
                            (g_at78, gpart_at9i) = Genome.Split.split gpart_at9h
                            p_at77 = Functions.belowten' g_at76
                            (g_at76, gpart_at9h) = Genome.Split.split gpart_at9g
                            p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                            (g_at74, gpart_at9g) = Genome.Split.split gpart_at9f
                            p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                            (g_at72, gpart_at9f) = Genome.Split.split gpart_at9e
                            p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                            (g_at70, gpart_at9e) = Genome.Split.split gpart_at9d
                            p_at6Z = Functions.belowten' g_at6Y
                            (g_at6Y, gpart_at9d) = Genome.Split.split gpart_at9c
                            p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                            (g_at6W, gpart_at9c) = Genome.Split.split gpart_at9b
                            p_at6V
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6U
                            (g_at6U, gpart_at9b) = Genome.Split.split gpart_at9a
                            p_at6T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6S
                            (g_at6S, gpart_at9a) = Genome.Split.split gpart_at99
                            p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                            (g_at6Q, gpart_at99) = Genome.Split.split gpart_at98
                            p_at6P = Functions.belowten' g_at6O
                            (g_at6O, gpart_at98) = Genome.Split.split gpart_at97
                            p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                            (g_at6M, gpart_at97) = Genome.Split.split gpart_at96
                            p_at6L = Functions.belowten' g_at6K
                            (g_at6K, gpart_at96) = Genome.Split.split gpart_at95
                            p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                            (g_at6I, gpart_at95) = Genome.Split.split gpart_at94
                            p_at6H = Functions.belowten' g_at6G
                            (g_at6G, gpart_at94) = Genome.Split.split gpart_at93
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at93) = Genome.Split.split gpart_at92
                            p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                            (g_at6C, gpart_at92) = Genome.Split.split gpart_at91
                            p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                            (g_at6A, gpart_at91) = Genome.Split.split gpart_at90
                            p_at6z = Functions.belowten' g_at6y
                            (g_at6y, gpart_at90) = Genome.Split.split gpart_at8Z
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8Z) = Genome.Split.split gpart_at8Y
                            p_at6v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6u
                            (g_at6u, gpart_at8Y) = Genome.Split.split gpart_at8X
                            p_at6t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                            (g_at6s, gpart_at8X) = Genome.Split.split gpart_at8W
                            p_at6r = Functions.belowten' g_at6q
                            (g_at6q, gpart_at8W) = Genome.Split.split gpart_at8V
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8V) = Genome.Split.split gpart_at8U
                            p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                            (g_at6m, gpart_at8U) = Genome.Split.split gpart_at8T
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8T) = Genome.Split.split gpart_at8S
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8S) = Genome.Split.split gpart_at8R
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8R) = Genome.Split.split gpart_at8Q
                            p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                            (g_at6e, gpart_at8Q) = Genome.Split.split genome_at7E
                          in
                            \ desc_at7F
                              -> case desc_at7F of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6X)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Z)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at71)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at73)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at75)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at77)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at79)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7b)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7d)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7f)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7h)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7j)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7l)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7n)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7p)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7r)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7t)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7v)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7x)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7z)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7B)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7D)
                                   _ -> Nothing }}
