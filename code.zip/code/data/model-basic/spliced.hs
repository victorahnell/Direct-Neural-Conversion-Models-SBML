src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1VxQ
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Vyr
                      p_a1VxP = double g_a1VxO
                      (g_a1VxO, gpart_a1Vyr) = Genome.Split.split gpart_a1Vyq
                      p_a1VxN = double g_a1VxM
                      (g_a1VxM, gpart_a1Vyq) = Genome.Split.split gpart_a1Vyp
                      p_a1VxL = double g_a1VxK
                      (g_a1VxK, gpart_a1Vyp) = Genome.Split.split gpart_a1Vyo
                      p_a1VxJ = double g_a1VxI
                      (g_a1VxI, gpart_a1Vyo) = Genome.Split.split gpart_a1Vyn
                      p_a1VxH = double g_a1VxG
                      (g_a1VxG, gpart_a1Vyn) = Genome.Split.split gpart_a1Vym
                      p_a1VxF = Functions.belowten' g_a1VxE
                      (g_a1VxE, gpart_a1Vym) = Genome.Split.split gpart_a1Vyl
                      p_a1VxD = double g_a1VxC
                      (g_a1VxC, gpart_a1Vyl) = Genome.Split.split gpart_a1Vyk
                      p_a1VxB = double g_a1VxA
                      (g_a1VxA, gpart_a1Vyk) = Genome.Split.split gpart_a1Vyj
                      p_a1Vxz = double g_a1Vxy
                      (g_a1Vxy, gpart_a1Vyj) = Genome.Split.split gpart_a1Vyi
                      p_a1Vxx = Functions.belowten' g_a1Vxw
                      (g_a1Vxw, gpart_a1Vyi) = Genome.Split.split gpart_a1Vyh
                      p_a1Vxv = double g_a1Vxu
                      (g_a1Vxu, gpart_a1Vyh) = Genome.Split.split gpart_a1Vyg
                      p_a1Vxt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxs
                      (g_a1Vxs, gpart_a1Vyg) = Genome.Split.split gpart_a1Vyf
                      p_a1Vxr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxq
                      (g_a1Vxq, gpart_a1Vyf) = Genome.Split.split gpart_a1Vye
                      p_a1Vxp = Functions.belowten' g_a1Vxo
                      (g_a1Vxo, gpart_a1Vye) = Genome.Split.split gpart_a1Vyd
                      p_a1Vxn = double g_a1Vxm
                      (g_a1Vxm, gpart_a1Vyd) = Genome.Split.split gpart_a1Vyc
                      p_a1Vxl = double g_a1Vxk
                      (g_a1Vxk, gpart_a1Vyc) = Genome.Split.split gpart_a1Vyb
                      p_a1Vxj = double g_a1Vxi
                      (g_a1Vxi, gpart_a1Vyb) = Genome.Split.split gpart_a1Vya
                      p_a1Vxh = Functions.belowten' g_a1Vxg
                      (g_a1Vxg, gpart_a1Vya) = Genome.Split.split gpart_a1Vy9
                      p_a1Vxf = double g_a1Vxe
                      (g_a1Vxe, gpart_a1Vy9) = Genome.Split.split gpart_a1Vy8
                      p_a1Vxd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxc
                      (g_a1Vxc, gpart_a1Vy8) = Genome.Split.split gpart_a1Vy7
                      p_a1Vxb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxa
                      (g_a1Vxa, gpart_a1Vy7) = Genome.Split.split gpart_a1Vy6
                      p_a1Vx9 = double g_a1Vx8
                      (g_a1Vx8, gpart_a1Vy6) = Genome.Split.split gpart_a1Vy5
                      p_a1Vx7 = Functions.belowten' g_a1Vx6
                      (g_a1Vx6, gpart_a1Vy5) = Genome.Split.split gpart_a1Vy4
                      p_a1Vx5 = double g_a1Vx4
                      (g_a1Vx4, gpart_a1Vy4) = Genome.Split.split gpart_a1Vy3
                      p_a1Vx3 = Functions.belowten' g_a1Vx2
                      (g_a1Vx2, gpart_a1Vy3) = Genome.Split.split gpart_a1Vy2
                      p_a1Vx1 = double g_a1Vx0
                      (g_a1Vx0, gpart_a1Vy2) = Genome.Split.split gpart_a1Vy1
                      p_a1VwZ = double g_a1VwY
                      (g_a1VwY, gpart_a1Vy1) = Genome.Split.split gpart_a1Vy0
                      p_a1VwX = Functions.belowten' g_a1VwW
                      (g_a1VwW, gpart_a1Vy0) = Genome.Split.split gpart_a1VxZ
                      p_a1VwV = double g_a1VwU
                      (g_a1VwU, gpart_a1VxZ) = Genome.Split.split gpart_a1VxY
                      p_a1VwT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VwS
                      (g_a1VwS, gpart_a1VxY) = Genome.Split.split gpart_a1VxX
                      p_a1VwR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VwQ
                      (g_a1VwQ, gpart_a1VxX) = Genome.Split.split gpart_a1VxW
                      p_a1VwP = double g_a1VwO
                      (g_a1VwO, gpart_a1VxW) = Genome.Split.split gpart_a1VxV
                      p_a1VwN = double g_a1VwM
                      (g_a1VwM, gpart_a1VxV) = Genome.Split.split gpart_a1VxU
                      p_a1VwL = double g_a1VwK
                      (g_a1VwK, gpart_a1VxU) = Genome.Split.split gpart_a1VxT
                      p_a1VwJ = double g_a1VwI
                      (g_a1VwI, gpart_a1VxT) = Genome.Split.split gpart_a1VxS
                      p_a1VwH = double g_a1VwG
                      (g_a1VwG, gpart_a1VxS) = Genome.Split.split genome_a1VxQ
                    in  \ x_a1Vys
                          -> let
                               c_PTB_a1Vyv
                                 = ((Data.Fixed.Vector.toVector x_a1Vys) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Vyt
                                 = ((Data.Fixed.Vector.toVector x_a1Vys) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Vyz
                                 = ((Data.Fixed.Vector.toVector x_a1Vys) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1VyA
                                 = ((Data.Fixed.Vector.toVector x_a1Vys) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1VyK
                                 = ((Data.Fixed.Vector.toVector x_a1Vys) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1VwP / (1 + ((c_MiRs_a1Vyt / p_a1VwV) ** p_a1VwX)))
                                    + (negate (p_a1VxH * c_PTB_a1Vyv))),
                                   ((p_a1VwZ
                                     / (1
                                        + (((c_MiRs_a1Vyt / p_a1Vx1) ** p_a1Vx3)
                                           + ((c_PTB_a1Vyv / p_a1Vx5) ** p_a1Vx7))))
                                    + (negate (p_a1VxJ * c_NPTB_a1Vyz))),
                                   ((p_a1Vx9
                                     * ((p_a1Vxj + ((p_a1VwL / p_a1Vxb) ** p_a1Vxd))
                                        / (((1 + p_a1Vxj) + ((p_a1VwL / p_a1Vxb) ** p_a1Vxd))
                                           + ((c_RESTc_a1VyA / p_a1Vxf) ** p_a1Vxh))))
                                    + (negate (p_a1VxL * c_MiRs_a1Vyt))),
                                   ((p_a1Vxl
                                     * ((p_a1Vxz + ((c_PTB_a1Vyv / p_a1Vxn) ** p_a1Vxp))
                                        / (((1 + p_a1Vxz) + ((c_PTB_a1Vyv / p_a1Vxn) ** p_a1Vxp))
                                           + (((p_a1VwH / p_a1Vxr) ** p_a1Vxt)
                                              + ((c_MiRs_a1Vyt / p_a1Vxv) ** p_a1Vxx)))))
                                    + (negate (p_a1VxN * c_RESTc_a1VyA))),
                                   ((p_a1VxB / (1 + ((c_RESTc_a1VyA / p_a1VxD) ** p_a1VxF)))
                                    + (negate (p_a1VxP * c_EndoNeuroTFs_a1VyK)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469265",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469267",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469285",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469287",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469301",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469303",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1VxQ
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Vzk
                            p_a1VxP = double g_a1VxO
                            (g_a1VxO, gpart_a1Vzk) = Genome.Split.split gpart_a1Vzj
                            p_a1VxN = double g_a1VxM
                            (g_a1VxM, gpart_a1Vzj) = Genome.Split.split gpart_a1Vzi
                            p_a1VxL = double g_a1VxK
                            (g_a1VxK, gpart_a1Vzi) = Genome.Split.split gpart_a1Vzh
                            p_a1VxJ = double g_a1VxI
                            (g_a1VxI, gpart_a1Vzh) = Genome.Split.split gpart_a1Vzg
                            p_a1VxH = double g_a1VxG
                            (g_a1VxG, gpart_a1Vzg) = Genome.Split.split gpart_a1Vzf
                            p_a1VxF = Functions.belowten' g_a1VxE
                            (g_a1VxE, gpart_a1Vzf) = Genome.Split.split gpart_a1Vze
                            p_a1VxD = double g_a1VxC
                            (g_a1VxC, gpart_a1Vze) = Genome.Split.split gpart_a1Vzd
                            p_a1VxB = double g_a1VxA
                            (g_a1VxA, gpart_a1Vzd) = Genome.Split.split gpart_a1Vzc
                            p_a1Vxz = double g_a1Vxy
                            (g_a1Vxy, gpart_a1Vzc) = Genome.Split.split gpart_a1Vzb
                            p_a1Vxx = Functions.belowten' g_a1Vxw
                            (g_a1Vxw, gpart_a1Vzb) = Genome.Split.split gpart_a1Vza
                            p_a1Vxv = double g_a1Vxu
                            (g_a1Vxu, gpart_a1Vza) = Genome.Split.split gpart_a1Vz9
                            p_a1Vxt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxs
                            (g_a1Vxs, gpart_a1Vz9) = Genome.Split.split gpart_a1Vz8
                            p_a1Vxr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxq
                            (g_a1Vxq, gpart_a1Vz8) = Genome.Split.split gpart_a1Vz7
                            p_a1Vxp = Functions.belowten' g_a1Vxo
                            (g_a1Vxo, gpart_a1Vz7) = Genome.Split.split gpart_a1Vz6
                            p_a1Vxn = double g_a1Vxm
                            (g_a1Vxm, gpart_a1Vz6) = Genome.Split.split gpart_a1Vz5
                            p_a1Vxl = double g_a1Vxk
                            (g_a1Vxk, gpart_a1Vz5) = Genome.Split.split gpart_a1Vz4
                            p_a1Vxj = double g_a1Vxi
                            (g_a1Vxi, gpart_a1Vz4) = Genome.Split.split gpart_a1Vz3
                            p_a1Vxh = Functions.belowten' g_a1Vxg
                            (g_a1Vxg, gpart_a1Vz3) = Genome.Split.split gpart_a1Vz2
                            p_a1Vxf = double g_a1Vxe
                            (g_a1Vxe, gpart_a1Vz2) = Genome.Split.split gpart_a1Vz1
                            p_a1Vxd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxc
                            (g_a1Vxc, gpart_a1Vz1) = Genome.Split.split gpart_a1Vz0
                            p_a1Vxb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Vxa
                            (g_a1Vxa, gpart_a1Vz0) = Genome.Split.split gpart_a1VyZ
                            p_a1Vx9 = double g_a1Vx8
                            (g_a1Vx8, gpart_a1VyZ) = Genome.Split.split gpart_a1VyY
                            p_a1Vx7 = Functions.belowten' g_a1Vx6
                            (g_a1Vx6, gpart_a1VyY) = Genome.Split.split gpart_a1VyX
                            p_a1Vx5 = double g_a1Vx4
                            (g_a1Vx4, gpart_a1VyX) = Genome.Split.split gpart_a1VyW
                            p_a1Vx3 = Functions.belowten' g_a1Vx2
                            (g_a1Vx2, gpart_a1VyW) = Genome.Split.split gpart_a1VyV
                            p_a1Vx1 = double g_a1Vx0
                            (g_a1Vx0, gpart_a1VyV) = Genome.Split.split gpart_a1VyU
                            p_a1VwZ = double g_a1VwY
                            (g_a1VwY, gpart_a1VyU) = Genome.Split.split gpart_a1VyT
                            p_a1VwX = Functions.belowten' g_a1VwW
                            (g_a1VwW, gpart_a1VyT) = Genome.Split.split gpart_a1VyS
                            p_a1VwV = double g_a1VwU
                            (g_a1VwU, gpart_a1VyS) = Genome.Split.split gpart_a1VyR
                            p_a1VwT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VwS
                            (g_a1VwS, gpart_a1VyR) = Genome.Split.split gpart_a1VyQ
                            p_a1VwR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VwQ
                            (g_a1VwQ, gpart_a1VyQ) = Genome.Split.split gpart_a1VyP
                            p_a1VwP = double g_a1VwO
                            (g_a1VwO, gpart_a1VyP) = Genome.Split.split gpart_a1VyO
                            p_a1VwN = double g_a1VwM
                            (g_a1VwM, gpart_a1VyO) = Genome.Split.split gpart_a1VyN
                            p_a1VwL = double g_a1VwK
                            (g_a1VwK, gpart_a1VyN) = Genome.Split.split gpart_a1VyM
                            p_a1VwJ = double g_a1VwI
                            (g_a1VwI, gpart_a1VyM) = Genome.Split.split gpart_a1VyL
                            p_a1VwH = double g_a1VwG
                            (g_a1VwG, gpart_a1VyL) = Genome.Split.split genome_a1VxQ
                          in
                            \ desc_a1VxR
                              -> case desc_a1VxR of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwH)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwJ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwL)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwN)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwP)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwR)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwT)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwX)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VwZ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vx1)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vx3)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vx5)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vx7)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vx9)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxb)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxd)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxf)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxh)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxj)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxl)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxn)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxp)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxr)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxt)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxv)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxx)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Vxz)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxB)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxD)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxF)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxH)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxJ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxL)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxN)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VxP)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1VBE
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VCf
                      p_a1VBD = double g_a1VBC
                      (g_a1VBC, gpart_a1VCf) = Genome.Split.split gpart_a1VCe
                      p_a1VBB = double g_a1VBA
                      (g_a1VBA, gpart_a1VCe) = Genome.Split.split gpart_a1VCd
                      p_a1VBz = double g_a1VBy
                      (g_a1VBy, gpart_a1VCd) = Genome.Split.split gpart_a1VCc
                      p_a1VBx = double g_a1VBw
                      (g_a1VBw, gpart_a1VCc) = Genome.Split.split gpart_a1VCb
                      p_a1VBv = double g_a1VBu
                      (g_a1VBu, gpart_a1VCb) = Genome.Split.split gpart_a1VCa
                      p_a1VBt = Functions.belowten' g_a1VBs
                      (g_a1VBs, gpart_a1VCa) = Genome.Split.split gpart_a1VC9
                      p_a1VBr = double g_a1VBq
                      (g_a1VBq, gpart_a1VC9) = Genome.Split.split gpart_a1VC8
                      p_a1VBp = double g_a1VBo
                      (g_a1VBo, gpart_a1VC8) = Genome.Split.split gpart_a1VC7
                      p_a1VBn = double g_a1VBm
                      (g_a1VBm, gpart_a1VC7) = Genome.Split.split gpart_a1VC6
                      p_a1VBl = Functions.belowten' g_a1VBk
                      (g_a1VBk, gpart_a1VC6) = Genome.Split.split gpart_a1VC5
                      p_a1VBj = double g_a1VBi
                      (g_a1VBi, gpart_a1VC5) = Genome.Split.split gpart_a1VC4
                      p_a1VBh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VBg
                      (g_a1VBg, gpart_a1VC4) = Genome.Split.split gpart_a1VC3
                      p_a1VBf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VBe
                      (g_a1VBe, gpart_a1VC3) = Genome.Split.split gpart_a1VC2
                      p_a1VBd = Functions.belowten' g_a1VBc
                      (g_a1VBc, gpart_a1VC2) = Genome.Split.split gpart_a1VC1
                      p_a1VBb = double g_a1VBa
                      (g_a1VBa, gpart_a1VC1) = Genome.Split.split gpart_a1VC0
                      p_a1VB9 = double g_a1VB8
                      (g_a1VB8, gpart_a1VC0) = Genome.Split.split gpart_a1VBZ
                      p_a1VB7 = double g_a1VB6
                      (g_a1VB6, gpart_a1VBZ) = Genome.Split.split gpart_a1VBY
                      p_a1VB5 = Functions.belowten' g_a1VB4
                      (g_a1VB4, gpart_a1VBY) = Genome.Split.split gpart_a1VBX
                      p_a1VB3 = double g_a1VB2
                      (g_a1VB2, gpart_a1VBX) = Genome.Split.split gpart_a1VBW
                      p_a1VB1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VB0
                      (g_a1VB0, gpart_a1VBW) = Genome.Split.split gpart_a1VBV
                      p_a1VAZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAY
                      (g_a1VAY, gpart_a1VBV) = Genome.Split.split gpart_a1VBU
                      p_a1VAX = double g_a1VAW
                      (g_a1VAW, gpart_a1VBU) = Genome.Split.split gpart_a1VBT
                      p_a1VAV = Functions.belowten' g_a1VAU
                      (g_a1VAU, gpart_a1VBT) = Genome.Split.split gpart_a1VBS
                      p_a1VAT = double g_a1VAS
                      (g_a1VAS, gpart_a1VBS) = Genome.Split.split gpart_a1VBR
                      p_a1VAR = Functions.belowten' g_a1VAQ
                      (g_a1VAQ, gpart_a1VBR) = Genome.Split.split gpart_a1VBQ
                      p_a1VAP = double g_a1VAO
                      (g_a1VAO, gpart_a1VBQ) = Genome.Split.split gpart_a1VBP
                      p_a1VAN = double g_a1VAM
                      (g_a1VAM, gpart_a1VBP) = Genome.Split.split gpart_a1VBO
                      p_a1VAL = Functions.belowten' g_a1VAK
                      (g_a1VAK, gpart_a1VBO) = Genome.Split.split gpart_a1VBN
                      p_a1VAJ = double g_a1VAI
                      (g_a1VAI, gpart_a1VBN) = Genome.Split.split gpart_a1VBM
                      p_a1VAH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAG
                      (g_a1VAG, gpart_a1VBM) = Genome.Split.split gpart_a1VBL
                      p_a1VAF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAE
                      (g_a1VAE, gpart_a1VBL) = Genome.Split.split gpart_a1VBK
                      p_a1VAD = double g_a1VAC
                      (g_a1VAC, gpart_a1VBK) = Genome.Split.split gpart_a1VBJ
                      p_a1VAB = double g_a1VAA
                      (g_a1VAA, gpart_a1VBJ) = Genome.Split.split gpart_a1VBI
                      p_a1VAz = double g_a1VAy
                      (g_a1VAy, gpart_a1VBI) = Genome.Split.split gpart_a1VBH
                      p_a1VAx = double g_a1VAw
                      (g_a1VAw, gpart_a1VBH) = Genome.Split.split gpart_a1VBG
                      p_a1VAv = double g_a1VAu
                      (g_a1VAu, gpart_a1VBG) = Genome.Split.split genome_a1VBE
                    in  \ x_a1VCg
                          -> let
                               c_PTB_a1VCj
                                 = ((Data.Fixed.Vector.toVector x_a1VCg) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1VCh
                                 = ((Data.Fixed.Vector.toVector x_a1VCg) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1VCn
                                 = ((Data.Fixed.Vector.toVector x_a1VCg) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1VCo
                                 = ((Data.Fixed.Vector.toVector x_a1VCg) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1VCy
                                 = ((Data.Fixed.Vector.toVector x_a1VCg) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1VAD / (1 + ((c_MiRs_a1VCh / p_a1VAJ) ** p_a1VAL)))
                                    + (negate (p_a1VBv * c_PTB_a1VCj))),
                                   ((p_a1VAN
                                     / (1
                                        + (((c_MiRs_a1VCh / p_a1VAP) ** p_a1VAR)
                                           + ((c_PTB_a1VCj / p_a1VAT) ** p_a1VAV))))
                                    + (negate (p_a1VBx * c_NPTB_a1VCn))),
                                   ((p_a1VAX
                                     * (p_a1VB7
                                        / ((1 + p_a1VB7) + ((c_RESTc_a1VCo / p_a1VB3) ** p_a1VB5))))
                                    + (negate (p_a1VBz * c_MiRs_a1VCh))),
                                   ((p_a1VB9
                                     * ((p_a1VBn + ((c_PTB_a1VCj / p_a1VBb) ** p_a1VBd))
                                        / (((1 + p_a1VBn) + ((c_PTB_a1VCj / p_a1VBb) ** p_a1VBd))
                                           + (((p_a1VAv / p_a1VBf) ** p_a1VBh)
                                              + ((c_MiRs_a1VCh / p_a1VBj) ** p_a1VBl)))))
                                    + (negate (p_a1VBB * c_RESTc_a1VCo))),
                                   ((p_a1VBp / (1 + ((c_RESTc_a1VCo / p_a1VBr) ** p_a1VBt)))
                                    + (negate (p_a1VBD * c_EndoNeuroTFs_a1VCy)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469501",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469503",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469521",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469523",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469537",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469539",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1VBE
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VD8
                            p_a1VBD = double g_a1VBC
                            (g_a1VBC, gpart_a1VD8) = Genome.Split.split gpart_a1VD7
                            p_a1VBB = double g_a1VBA
                            (g_a1VBA, gpart_a1VD7) = Genome.Split.split gpart_a1VD6
                            p_a1VBz = double g_a1VBy
                            (g_a1VBy, gpart_a1VD6) = Genome.Split.split gpart_a1VD5
                            p_a1VBx = double g_a1VBw
                            (g_a1VBw, gpart_a1VD5) = Genome.Split.split gpart_a1VD4
                            p_a1VBv = double g_a1VBu
                            (g_a1VBu, gpart_a1VD4) = Genome.Split.split gpart_a1VD3
                            p_a1VBt = Functions.belowten' g_a1VBs
                            (g_a1VBs, gpart_a1VD3) = Genome.Split.split gpart_a1VD2
                            p_a1VBr = double g_a1VBq
                            (g_a1VBq, gpart_a1VD2) = Genome.Split.split gpart_a1VD1
                            p_a1VBp = double g_a1VBo
                            (g_a1VBo, gpart_a1VD1) = Genome.Split.split gpart_a1VD0
                            p_a1VBn = double g_a1VBm
                            (g_a1VBm, gpart_a1VD0) = Genome.Split.split gpart_a1VCZ
                            p_a1VBl = Functions.belowten' g_a1VBk
                            (g_a1VBk, gpart_a1VCZ) = Genome.Split.split gpart_a1VCY
                            p_a1VBj = double g_a1VBi
                            (g_a1VBi, gpart_a1VCY) = Genome.Split.split gpart_a1VCX
                            p_a1VBh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VBg
                            (g_a1VBg, gpart_a1VCX) = Genome.Split.split gpart_a1VCW
                            p_a1VBf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VBe
                            (g_a1VBe, gpart_a1VCW) = Genome.Split.split gpart_a1VCV
                            p_a1VBd = Functions.belowten' g_a1VBc
                            (g_a1VBc, gpart_a1VCV) = Genome.Split.split gpart_a1VCU
                            p_a1VBb = double g_a1VBa
                            (g_a1VBa, gpart_a1VCU) = Genome.Split.split gpart_a1VCT
                            p_a1VB9 = double g_a1VB8
                            (g_a1VB8, gpart_a1VCT) = Genome.Split.split gpart_a1VCS
                            p_a1VB7 = double g_a1VB6
                            (g_a1VB6, gpart_a1VCS) = Genome.Split.split gpart_a1VCR
                            p_a1VB5 = Functions.belowten' g_a1VB4
                            (g_a1VB4, gpart_a1VCR) = Genome.Split.split gpart_a1VCQ
                            p_a1VB3 = double g_a1VB2
                            (g_a1VB2, gpart_a1VCQ) = Genome.Split.split gpart_a1VCP
                            p_a1VB1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VB0
                            (g_a1VB0, gpart_a1VCP) = Genome.Split.split gpart_a1VCO
                            p_a1VAZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAY
                            (g_a1VAY, gpart_a1VCO) = Genome.Split.split gpart_a1VCN
                            p_a1VAX = double g_a1VAW
                            (g_a1VAW, gpart_a1VCN) = Genome.Split.split gpart_a1VCM
                            p_a1VAV = Functions.belowten' g_a1VAU
                            (g_a1VAU, gpart_a1VCM) = Genome.Split.split gpart_a1VCL
                            p_a1VAT = double g_a1VAS
                            (g_a1VAS, gpart_a1VCL) = Genome.Split.split gpart_a1VCK
                            p_a1VAR = Functions.belowten' g_a1VAQ
                            (g_a1VAQ, gpart_a1VCK) = Genome.Split.split gpart_a1VCJ
                            p_a1VAP = double g_a1VAO
                            (g_a1VAO, gpart_a1VCJ) = Genome.Split.split gpart_a1VCI
                            p_a1VAN = double g_a1VAM
                            (g_a1VAM, gpart_a1VCI) = Genome.Split.split gpart_a1VCH
                            p_a1VAL = Functions.belowten' g_a1VAK
                            (g_a1VAK, gpart_a1VCH) = Genome.Split.split gpart_a1VCG
                            p_a1VAJ = double g_a1VAI
                            (g_a1VAI, gpart_a1VCG) = Genome.Split.split gpart_a1VCF
                            p_a1VAH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAG
                            (g_a1VAG, gpart_a1VCF) = Genome.Split.split gpart_a1VCE
                            p_a1VAF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VAE
                            (g_a1VAE, gpart_a1VCE) = Genome.Split.split gpart_a1VCD
                            p_a1VAD = double g_a1VAC
                            (g_a1VAC, gpart_a1VCD) = Genome.Split.split gpart_a1VCC
                            p_a1VAB = double g_a1VAA
                            (g_a1VAA, gpart_a1VCC) = Genome.Split.split gpart_a1VCB
                            p_a1VAz = double g_a1VAy
                            (g_a1VAy, gpart_a1VCB) = Genome.Split.split gpart_a1VCA
                            p_a1VAx = double g_a1VAw
                            (g_a1VAw, gpart_a1VCA) = Genome.Split.split gpart_a1VCz
                            p_a1VAv = double g_a1VAu
                            (g_a1VAu, gpart_a1VCz) = Genome.Split.split genome_a1VBE
                          in
                            \ desc_a1VBF
                              -> case desc_a1VBF of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAv)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAx)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAz)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAB)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAD)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAF)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAH)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAJ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAL)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAN)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAP)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAR)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAT)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAV)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAX)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VAZ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VB1)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VB3)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VB5)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VB7)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VB9)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBb)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBd)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBf)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBh)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBj)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBl)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBn)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBp)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBr)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBt)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBv)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBx)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBz)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBB)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VBD)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1VFs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VG3
                      p_a1VFr = double g_a1VFq
                      (g_a1VFq, gpart_a1VG3) = Genome.Split.split gpart_a1VG2
                      p_a1VFp = double g_a1VFo
                      (g_a1VFo, gpart_a1VG2) = Genome.Split.split gpart_a1VG1
                      p_a1VFn = double g_a1VFm
                      (g_a1VFm, gpart_a1VG1) = Genome.Split.split gpart_a1VG0
                      p_a1VFl = double g_a1VFk
                      (g_a1VFk, gpart_a1VG0) = Genome.Split.split gpart_a1VFZ
                      p_a1VFj = double g_a1VFi
                      (g_a1VFi, gpart_a1VFZ) = Genome.Split.split gpart_a1VFY
                      p_a1VFh = Functions.belowten' g_a1VFg
                      (g_a1VFg, gpart_a1VFY) = Genome.Split.split gpart_a1VFX
                      p_a1VFf = double g_a1VFe
                      (g_a1VFe, gpart_a1VFX) = Genome.Split.split gpart_a1VFW
                      p_a1VFd = double g_a1VFc
                      (g_a1VFc, gpart_a1VFW) = Genome.Split.split gpart_a1VFV
                      p_a1VFb = double g_a1VFa
                      (g_a1VFa, gpart_a1VFV) = Genome.Split.split gpart_a1VFU
                      p_a1VF9 = Functions.belowten' g_a1VF8
                      (g_a1VF8, gpart_a1VFU) = Genome.Split.split gpart_a1VFT
                      p_a1VF7 = double g_a1VF6
                      (g_a1VF6, gpart_a1VFT) = Genome.Split.split gpart_a1VFS
                      p_a1VF5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VF4
                      (g_a1VF4, gpart_a1VFS) = Genome.Split.split gpart_a1VFR
                      p_a1VF3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VF2
                      (g_a1VF2, gpart_a1VFR) = Genome.Split.split gpart_a1VFQ
                      p_a1VF1 = Functions.belowten' g_a1VF0
                      (g_a1VF0, gpart_a1VFQ) = Genome.Split.split gpart_a1VFP
                      p_a1VEZ = double g_a1VEY
                      (g_a1VEY, gpart_a1VFP) = Genome.Split.split gpart_a1VFO
                      p_a1VEX = double g_a1VEW
                      (g_a1VEW, gpart_a1VFO) = Genome.Split.split gpart_a1VFN
                      p_a1VEV = double g_a1VEU
                      (g_a1VEU, gpart_a1VFN) = Genome.Split.split gpart_a1VFM
                      p_a1VET = Functions.belowten' g_a1VES
                      (g_a1VES, gpart_a1VFM) = Genome.Split.split gpart_a1VFL
                      p_a1VER = double g_a1VEQ
                      (g_a1VEQ, gpart_a1VFL) = Genome.Split.split gpart_a1VFK
                      p_a1VEP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEO
                      (g_a1VEO, gpart_a1VFK) = Genome.Split.split gpart_a1VFJ
                      p_a1VEN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEM
                      (g_a1VEM, gpart_a1VFJ) = Genome.Split.split gpart_a1VFI
                      p_a1VEL = double g_a1VEK
                      (g_a1VEK, gpart_a1VFI) = Genome.Split.split gpart_a1VFH
                      p_a1VEJ = Functions.belowten' g_a1VEI
                      (g_a1VEI, gpart_a1VFH) = Genome.Split.split gpart_a1VFG
                      p_a1VEH = double g_a1VEG
                      (g_a1VEG, gpart_a1VFG) = Genome.Split.split gpart_a1VFF
                      p_a1VEF = Functions.belowten' g_a1VEE
                      (g_a1VEE, gpart_a1VFF) = Genome.Split.split gpart_a1VFE
                      p_a1VED = double g_a1VEC
                      (g_a1VEC, gpart_a1VFE) = Genome.Split.split gpart_a1VFD
                      p_a1VEB = double g_a1VEA
                      (g_a1VEA, gpart_a1VFD) = Genome.Split.split gpart_a1VFC
                      p_a1VEz = Functions.belowten' g_a1VEy
                      (g_a1VEy, gpart_a1VFC) = Genome.Split.split gpart_a1VFB
                      p_a1VEx = double g_a1VEw
                      (g_a1VEw, gpart_a1VFB) = Genome.Split.split gpart_a1VFA
                      p_a1VEv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEu
                      (g_a1VEu, gpart_a1VFA) = Genome.Split.split gpart_a1VFz
                      p_a1VEt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEs
                      (g_a1VEs, gpart_a1VFz) = Genome.Split.split gpart_a1VFy
                      p_a1VEr = double g_a1VEq
                      (g_a1VEq, gpart_a1VFy) = Genome.Split.split gpart_a1VFx
                      p_a1VEp = double g_a1VEo
                      (g_a1VEo, gpart_a1VFx) = Genome.Split.split gpart_a1VFw
                      p_a1VEn = double g_a1VEm
                      (g_a1VEm, gpart_a1VFw) = Genome.Split.split gpart_a1VFv
                      p_a1VEl = double g_a1VEk
                      (g_a1VEk, gpart_a1VFv) = Genome.Split.split gpart_a1VFu
                      p_a1VEj = double g_a1VEi
                      (g_a1VEi, gpart_a1VFu) = Genome.Split.split genome_a1VFs
                    in  \ x_a1VG4
                          -> let
                               c_PTB_a1VG7
                                 = ((Data.Fixed.Vector.toVector x_a1VG4) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1VG5
                                 = ((Data.Fixed.Vector.toVector x_a1VG4) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1VGb
                                 = ((Data.Fixed.Vector.toVector x_a1VG4) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1VGc
                                 = ((Data.Fixed.Vector.toVector x_a1VG4) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1VGm
                                 = ((Data.Fixed.Vector.toVector x_a1VG4) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1VEr / (1 + ((c_MiRs_a1VG5 / p_a1VEx) ** p_a1VEz)))
                                    + (negate (p_a1VFj * c_PTB_a1VG7))),
                                   ((p_a1VEB
                                     / (1
                                        + (((c_MiRs_a1VG5 / p_a1VED) ** p_a1VEF)
                                           + ((c_PTB_a1VG7 / p_a1VEH) ** p_a1VEJ))))
                                    + (negate (p_a1VFl * c_NPTB_a1VGb))),
                                   ((p_a1VEL
                                     * (p_a1VEV
                                        / ((1 + p_a1VEV) + ((c_RESTc_a1VGc / p_a1VER) ** p_a1VET))))
                                    + (negate (p_a1VFn * c_MiRs_a1VG5))),
                                   ((p_a1VEX
                                     * ((p_a1VFb + ((c_PTB_a1VG7 / p_a1VEZ) ** p_a1VF1))
                                        / (((1 + p_a1VFb) + ((c_PTB_a1VG7 / p_a1VEZ) ** p_a1VF1))
                                           + ((c_MiRs_a1VG5 / p_a1VF7) ** p_a1VF9))))
                                    + (negate (p_a1VFp * c_RESTc_a1VGc))),
                                   ((p_a1VFd / (1 + ((c_RESTc_a1VGc / p_a1VFf) ** p_a1VFh)))
                                    + (negate (p_a1VFr * c_EndoNeuroTFs_a1VGm)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469737",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469739",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469757",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469759",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469773",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469775",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469785",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1VFs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VGW
                            p_a1VFr = double g_a1VFq
                            (g_a1VFq, gpart_a1VGW) = Genome.Split.split gpart_a1VGV
                            p_a1VFp = double g_a1VFo
                            (g_a1VFo, gpart_a1VGV) = Genome.Split.split gpart_a1VGU
                            p_a1VFn = double g_a1VFm
                            (g_a1VFm, gpart_a1VGU) = Genome.Split.split gpart_a1VGT
                            p_a1VFl = double g_a1VFk
                            (g_a1VFk, gpart_a1VGT) = Genome.Split.split gpart_a1VGS
                            p_a1VFj = double g_a1VFi
                            (g_a1VFi, gpart_a1VGS) = Genome.Split.split gpart_a1VGR
                            p_a1VFh = Functions.belowten' g_a1VFg
                            (g_a1VFg, gpart_a1VGR) = Genome.Split.split gpart_a1VGQ
                            p_a1VFf = double g_a1VFe
                            (g_a1VFe, gpart_a1VGQ) = Genome.Split.split gpart_a1VGP
                            p_a1VFd = double g_a1VFc
                            (g_a1VFc, gpart_a1VGP) = Genome.Split.split gpart_a1VGO
                            p_a1VFb = double g_a1VFa
                            (g_a1VFa, gpart_a1VGO) = Genome.Split.split gpart_a1VGN
                            p_a1VF9 = Functions.belowten' g_a1VF8
                            (g_a1VF8, gpart_a1VGN) = Genome.Split.split gpart_a1VGM
                            p_a1VF7 = double g_a1VF6
                            (g_a1VF6, gpart_a1VGM) = Genome.Split.split gpart_a1VGL
                            p_a1VF5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VF4
                            (g_a1VF4, gpart_a1VGL) = Genome.Split.split gpart_a1VGK
                            p_a1VF3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VF2
                            (g_a1VF2, gpart_a1VGK) = Genome.Split.split gpart_a1VGJ
                            p_a1VF1 = Functions.belowten' g_a1VF0
                            (g_a1VF0, gpart_a1VGJ) = Genome.Split.split gpart_a1VGI
                            p_a1VEZ = double g_a1VEY
                            (g_a1VEY, gpart_a1VGI) = Genome.Split.split gpart_a1VGH
                            p_a1VEX = double g_a1VEW
                            (g_a1VEW, gpart_a1VGH) = Genome.Split.split gpart_a1VGG
                            p_a1VEV = double g_a1VEU
                            (g_a1VEU, gpart_a1VGG) = Genome.Split.split gpart_a1VGF
                            p_a1VET = Functions.belowten' g_a1VES
                            (g_a1VES, gpart_a1VGF) = Genome.Split.split gpart_a1VGE
                            p_a1VER = double g_a1VEQ
                            (g_a1VEQ, gpart_a1VGE) = Genome.Split.split gpart_a1VGD
                            p_a1VEP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEO
                            (g_a1VEO, gpart_a1VGD) = Genome.Split.split gpart_a1VGC
                            p_a1VEN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEM
                            (g_a1VEM, gpart_a1VGC) = Genome.Split.split gpart_a1VGB
                            p_a1VEL = double g_a1VEK
                            (g_a1VEK, gpart_a1VGB) = Genome.Split.split gpart_a1VGA
                            p_a1VEJ = Functions.belowten' g_a1VEI
                            (g_a1VEI, gpart_a1VGA) = Genome.Split.split gpart_a1VGz
                            p_a1VEH = double g_a1VEG
                            (g_a1VEG, gpart_a1VGz) = Genome.Split.split gpart_a1VGy
                            p_a1VEF = Functions.belowten' g_a1VEE
                            (g_a1VEE, gpart_a1VGy) = Genome.Split.split gpart_a1VGx
                            p_a1VED = double g_a1VEC
                            (g_a1VEC, gpart_a1VGx) = Genome.Split.split gpart_a1VGw
                            p_a1VEB = double g_a1VEA
                            (g_a1VEA, gpart_a1VGw) = Genome.Split.split gpart_a1VGv
                            p_a1VEz = Functions.belowten' g_a1VEy
                            (g_a1VEy, gpart_a1VGv) = Genome.Split.split gpart_a1VGu
                            p_a1VEx = double g_a1VEw
                            (g_a1VEw, gpart_a1VGu) = Genome.Split.split gpart_a1VGt
                            p_a1VEv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEu
                            (g_a1VEu, gpart_a1VGt) = Genome.Split.split gpart_a1VGs
                            p_a1VEt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VEs
                            (g_a1VEs, gpart_a1VGs) = Genome.Split.split gpart_a1VGr
                            p_a1VEr = double g_a1VEq
                            (g_a1VEq, gpart_a1VGr) = Genome.Split.split gpart_a1VGq
                            p_a1VEp = double g_a1VEo
                            (g_a1VEo, gpart_a1VGq) = Genome.Split.split gpart_a1VGp
                            p_a1VEn = double g_a1VEm
                            (g_a1VEm, gpart_a1VGp) = Genome.Split.split gpart_a1VGo
                            p_a1VEl = double g_a1VEk
                            (g_a1VEk, gpart_a1VGo) = Genome.Split.split gpart_a1VGn
                            p_a1VEj = double g_a1VEi
                            (g_a1VEi, gpart_a1VGn) = Genome.Split.split genome_a1VFs
                          in
                            \ desc_a1VFt
                              -> case desc_a1VFt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEj)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEl)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEn)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEp)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEr)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEt)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VED)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEJ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEL)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEN)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VER)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VET)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VEZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VF1)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VF3)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VF5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VF7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VF9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VFr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1VJg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VJR
                      p_a1VJf = double g_a1VJe
                      (g_a1VJe, gpart_a1VJR) = Genome.Split.split gpart_a1VJQ
                      p_a1VJd = double g_a1VJc
                      (g_a1VJc, gpart_a1VJQ) = Genome.Split.split gpart_a1VJP
                      p_a1VJb = double g_a1VJa
                      (g_a1VJa, gpart_a1VJP) = Genome.Split.split gpart_a1VJO
                      p_a1VJ9 = double g_a1VJ8
                      (g_a1VJ8, gpart_a1VJO) = Genome.Split.split gpart_a1VJN
                      p_a1VJ7 = double g_a1VJ6
                      (g_a1VJ6, gpart_a1VJN) = Genome.Split.split gpart_a1VJM
                      p_a1VJ5 = Functions.belowten' g_a1VJ4
                      (g_a1VJ4, gpart_a1VJM) = Genome.Split.split gpart_a1VJL
                      p_a1VJ3 = double g_a1VJ2
                      (g_a1VJ2, gpart_a1VJL) = Genome.Split.split gpart_a1VJK
                      p_a1VJ1 = double g_a1VJ0
                      (g_a1VJ0, gpart_a1VJK) = Genome.Split.split gpart_a1VJJ
                      p_a1VIZ = double g_a1VIY
                      (g_a1VIY, gpart_a1VJJ) = Genome.Split.split gpart_a1VJI
                      p_a1VIX = Functions.belowten' g_a1VIW
                      (g_a1VIW, gpart_a1VJI) = Genome.Split.split gpart_a1VJH
                      p_a1VIV = double g_a1VIU
                      (g_a1VIU, gpart_a1VJH) = Genome.Split.split gpart_a1VJG
                      p_a1VIT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIS
                      (g_a1VIS, gpart_a1VJG) = Genome.Split.split gpart_a1VJF
                      p_a1VIR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIQ
                      (g_a1VIQ, gpart_a1VJF) = Genome.Split.split gpart_a1VJE
                      p_a1VIP = Functions.belowten' g_a1VIO
                      (g_a1VIO, gpart_a1VJE) = Genome.Split.split gpart_a1VJD
                      p_a1VIN = double g_a1VIM
                      (g_a1VIM, gpart_a1VJD) = Genome.Split.split gpart_a1VJC
                      p_a1VIL = double g_a1VIK
                      (g_a1VIK, gpart_a1VJC) = Genome.Split.split gpart_a1VJB
                      p_a1VIJ = double g_a1VII
                      (g_a1VII, gpart_a1VJB) = Genome.Split.split gpart_a1VJA
                      p_a1VIH = Functions.belowten' g_a1VIG
                      (g_a1VIG, gpart_a1VJA) = Genome.Split.split gpart_a1VJz
                      p_a1VIF = double g_a1VIE
                      (g_a1VIE, gpart_a1VJz) = Genome.Split.split gpart_a1VJy
                      p_a1VID
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIC
                      (g_a1VIC, gpart_a1VJy) = Genome.Split.split gpart_a1VJx
                      p_a1VIB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIA
                      (g_a1VIA, gpart_a1VJx) = Genome.Split.split gpart_a1VJw
                      p_a1VIz = double g_a1VIy
                      (g_a1VIy, gpart_a1VJw) = Genome.Split.split gpart_a1VJv
                      p_a1VIx = Functions.belowten' g_a1VIw
                      (g_a1VIw, gpart_a1VJv) = Genome.Split.split gpart_a1VJu
                      p_a1VIv = double g_a1VIu
                      (g_a1VIu, gpart_a1VJu) = Genome.Split.split gpart_a1VJt
                      p_a1VIt = Functions.belowten' g_a1VIs
                      (g_a1VIs, gpart_a1VJt) = Genome.Split.split gpart_a1VJs
                      p_a1VIr = double g_a1VIq
                      (g_a1VIq, gpart_a1VJs) = Genome.Split.split gpart_a1VJr
                      p_a1VIp = double g_a1VIo
                      (g_a1VIo, gpart_a1VJr) = Genome.Split.split gpart_a1VJq
                      p_a1VIn = Functions.belowten' g_a1VIm
                      (g_a1VIm, gpart_a1VJq) = Genome.Split.split gpart_a1VJp
                      p_a1VIl = double g_a1VIk
                      (g_a1VIk, gpart_a1VJp) = Genome.Split.split gpart_a1VJo
                      p_a1VIj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIi
                      (g_a1VIi, gpart_a1VJo) = Genome.Split.split gpart_a1VJn
                      p_a1VIh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIg
                      (g_a1VIg, gpart_a1VJn) = Genome.Split.split gpart_a1VJm
                      p_a1VIf = double g_a1VIe
                      (g_a1VIe, gpart_a1VJm) = Genome.Split.split gpart_a1VJl
                      p_a1VId = double g_a1VIc
                      (g_a1VIc, gpart_a1VJl) = Genome.Split.split gpart_a1VJk
                      p_a1VIb = double g_a1VIa
                      (g_a1VIa, gpart_a1VJk) = Genome.Split.split gpart_a1VJj
                      p_a1VI9 = double g_a1VI8
                      (g_a1VI8, gpart_a1VJj) = Genome.Split.split gpart_a1VJi
                      p_a1VI7 = double g_a1VI6
                      (g_a1VI6, gpart_a1VJi) = Genome.Split.split genome_a1VJg
                    in  \ x_a1VJS
                          -> let
                               c_PTB_a1VJV
                                 = ((Data.Fixed.Vector.toVector x_a1VJS) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1VJT
                                 = ((Data.Fixed.Vector.toVector x_a1VJS) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1VJZ
                                 = ((Data.Fixed.Vector.toVector x_a1VJS) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1VK0
                                 = ((Data.Fixed.Vector.toVector x_a1VJS) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1VKa
                                 = ((Data.Fixed.Vector.toVector x_a1VJS) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1VIf
                                     / (1
                                        + (((p_a1VI7 / p_a1VIh) ** p_a1VIj)
                                           + ((c_MiRs_a1VJT / p_a1VIl) ** p_a1VIn))))
                                    + (negate (p_a1VJ7 * c_PTB_a1VJV))),
                                   ((p_a1VIp
                                     / (1
                                        + (((c_MiRs_a1VJT / p_a1VIr) ** p_a1VIt)
                                           + ((c_PTB_a1VJV / p_a1VIv) ** p_a1VIx))))
                                    + (negate (p_a1VJ9 * c_NPTB_a1VJZ))),
                                   ((p_a1VIz
                                     * (p_a1VIJ
                                        / ((1 + p_a1VIJ) + ((c_RESTc_a1VK0 / p_a1VIF) ** p_a1VIH))))
                                    + (negate (p_a1VJb * c_MiRs_a1VJT))),
                                   ((p_a1VIL
                                     * ((p_a1VIZ + ((c_PTB_a1VJV / p_a1VIN) ** p_a1VIP))
                                        / (((1 + p_a1VIZ) + ((c_PTB_a1VJV / p_a1VIN) ** p_a1VIP))
                                           + ((c_MiRs_a1VJT / p_a1VIV) ** p_a1VIX))))
                                    + (negate (p_a1VJd * c_RESTc_a1VK0))),
                                   ((p_a1VJ1 / (1 + ((c_RESTc_a1VK0 / p_a1VJ3) ** p_a1VJ5)))
                                    + (negate (p_a1VJf * c_EndoNeuroTFs_a1VKa)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469973",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469975",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469991",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469993",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469995",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679469998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679469999",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470001",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470009",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470011",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679470032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679470033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1VJg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1VKK
                            p_a1VJf = double g_a1VJe
                            (g_a1VJe, gpart_a1VKK) = Genome.Split.split gpart_a1VKJ
                            p_a1VJd = double g_a1VJc
                            (g_a1VJc, gpart_a1VKJ) = Genome.Split.split gpart_a1VKI
                            p_a1VJb = double g_a1VJa
                            (g_a1VJa, gpart_a1VKI) = Genome.Split.split gpart_a1VKH
                            p_a1VJ9 = double g_a1VJ8
                            (g_a1VJ8, gpart_a1VKH) = Genome.Split.split gpart_a1VKG
                            p_a1VJ7 = double g_a1VJ6
                            (g_a1VJ6, gpart_a1VKG) = Genome.Split.split gpart_a1VKF
                            p_a1VJ5 = Functions.belowten' g_a1VJ4
                            (g_a1VJ4, gpart_a1VKF) = Genome.Split.split gpart_a1VKE
                            p_a1VJ3 = double g_a1VJ2
                            (g_a1VJ2, gpart_a1VKE) = Genome.Split.split gpart_a1VKD
                            p_a1VJ1 = double g_a1VJ0
                            (g_a1VJ0, gpart_a1VKD) = Genome.Split.split gpart_a1VKC
                            p_a1VIZ = double g_a1VIY
                            (g_a1VIY, gpart_a1VKC) = Genome.Split.split gpart_a1VKB
                            p_a1VIX = Functions.belowten' g_a1VIW
                            (g_a1VIW, gpart_a1VKB) = Genome.Split.split gpart_a1VKA
                            p_a1VIV = double g_a1VIU
                            (g_a1VIU, gpart_a1VKA) = Genome.Split.split gpart_a1VKz
                            p_a1VIT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIS
                            (g_a1VIS, gpart_a1VKz) = Genome.Split.split gpart_a1VKy
                            p_a1VIR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIQ
                            (g_a1VIQ, gpart_a1VKy) = Genome.Split.split gpart_a1VKx
                            p_a1VIP = Functions.belowten' g_a1VIO
                            (g_a1VIO, gpart_a1VKx) = Genome.Split.split gpart_a1VKw
                            p_a1VIN = double g_a1VIM
                            (g_a1VIM, gpart_a1VKw) = Genome.Split.split gpart_a1VKv
                            p_a1VIL = double g_a1VIK
                            (g_a1VIK, gpart_a1VKv) = Genome.Split.split gpart_a1VKu
                            p_a1VIJ = double g_a1VII
                            (g_a1VII, gpart_a1VKu) = Genome.Split.split gpart_a1VKt
                            p_a1VIH = Functions.belowten' g_a1VIG
                            (g_a1VIG, gpart_a1VKt) = Genome.Split.split gpart_a1VKs
                            p_a1VIF = double g_a1VIE
                            (g_a1VIE, gpart_a1VKs) = Genome.Split.split gpart_a1VKr
                            p_a1VID
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIC
                            (g_a1VIC, gpart_a1VKr) = Genome.Split.split gpart_a1VKq
                            p_a1VIB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIA
                            (g_a1VIA, gpart_a1VKq) = Genome.Split.split gpart_a1VKp
                            p_a1VIz = double g_a1VIy
                            (g_a1VIy, gpart_a1VKp) = Genome.Split.split gpart_a1VKo
                            p_a1VIx = Functions.belowten' g_a1VIw
                            (g_a1VIw, gpart_a1VKo) = Genome.Split.split gpart_a1VKn
                            p_a1VIv = double g_a1VIu
                            (g_a1VIu, gpart_a1VKn) = Genome.Split.split gpart_a1VKm
                            p_a1VIt = Functions.belowten' g_a1VIs
                            (g_a1VIs, gpart_a1VKm) = Genome.Split.split gpart_a1VKl
                            p_a1VIr = double g_a1VIq
                            (g_a1VIq, gpart_a1VKl) = Genome.Split.split gpart_a1VKk
                            p_a1VIp = double g_a1VIo
                            (g_a1VIo, gpart_a1VKk) = Genome.Split.split gpart_a1VKj
                            p_a1VIn = Functions.belowten' g_a1VIm
                            (g_a1VIm, gpart_a1VKj) = Genome.Split.split gpart_a1VKi
                            p_a1VIl = double g_a1VIk
                            (g_a1VIk, gpart_a1VKi) = Genome.Split.split gpart_a1VKh
                            p_a1VIj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIi
                            (g_a1VIi, gpart_a1VKh) = Genome.Split.split gpart_a1VKg
                            p_a1VIh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1VIg
                            (g_a1VIg, gpart_a1VKg) = Genome.Split.split gpart_a1VKf
                            p_a1VIf = double g_a1VIe
                            (g_a1VIe, gpart_a1VKf) = Genome.Split.split gpart_a1VKe
                            p_a1VId = double g_a1VIc
                            (g_a1VIc, gpart_a1VKe) = Genome.Split.split gpart_a1VKd
                            p_a1VIb = double g_a1VIa
                            (g_a1VIa, gpart_a1VKd) = Genome.Split.split gpart_a1VKc
                            p_a1VI9 = double g_a1VI8
                            (g_a1VI8, gpart_a1VKc) = Genome.Split.split gpart_a1VKb
                            p_a1VI7 = double g_a1VI6
                            (g_a1VI6, gpart_a1VKb) = Genome.Split.split genome_a1VJg
                          in
                            \ desc_a1VJh
                              -> case desc_a1VJh of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VI7)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VI9)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIb)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VId)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIf)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIh)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIj)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIl)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIn)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIp)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIr)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIt)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIv)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIx)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIz)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIB)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VID)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIL)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIN)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIP)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIR)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIT)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIV)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIX)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VIZ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJ1)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJ3)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJ5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJ7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJ9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1VJf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asSz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asTa
                      p_asSy = code-0.1.0.0:Genome.FixedList.Functions.double g_asSx
                      (g_asSx, gpart_asTa) = Genome.Split.split gpart_asT9
                      p_asSw = code-0.1.0.0:Genome.FixedList.Functions.double g_asSv
                      (g_asSv, gpart_asT9) = Genome.Split.split gpart_asT8
                      p_asSu = code-0.1.0.0:Genome.FixedList.Functions.double g_asSt
                      (g_asSt, gpart_asT8) = Genome.Split.split gpart_asT7
                      p_asSs = code-0.1.0.0:Genome.FixedList.Functions.double g_asSr
                      (g_asSr, gpart_asT7) = Genome.Split.split gpart_asT6
                      p_asSq = code-0.1.0.0:Genome.FixedList.Functions.double g_asSp
                      (g_asSp, gpart_asT6) = Genome.Split.split gpart_asT5
                      p_asSo = Functions.belowten' g_asSn
                      (g_asSn, gpart_asT5) = Genome.Split.split gpart_asT4
                      p_asSm = code-0.1.0.0:Genome.FixedList.Functions.double g_asSl
                      (g_asSl, gpart_asT4) = Genome.Split.split gpart_asT3
                      p_asSk = code-0.1.0.0:Genome.FixedList.Functions.double g_asSj
                      (g_asSj, gpart_asT3) = Genome.Split.split gpart_asT2
                      p_asSi = code-0.1.0.0:Genome.FixedList.Functions.double g_asSh
                      (g_asSh, gpart_asT2) = Genome.Split.split gpart_asT1
                      p_asSg = Functions.belowten' g_asSf
                      (g_asSf, gpart_asT1) = Genome.Split.split gpart_asT0
                      p_asSe = code-0.1.0.0:Genome.FixedList.Functions.double g_asSd
                      (g_asSd, gpart_asT0) = Genome.Split.split gpart_asSZ
                      p_asSc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSb
                      (g_asSb, gpart_asSZ) = Genome.Split.split gpart_asSY
                      p_asSa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS9
                      (g_asS9, gpart_asSY) = Genome.Split.split gpart_asSX
                      p_asS8 = Functions.belowten' g_asS7
                      (g_asS7, gpart_asSX) = Genome.Split.split gpart_asSW
                      p_asS6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS5
                      (g_asS5, gpart_asSW) = Genome.Split.split gpart_asSV
                      p_asS4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS3
                      (g_asS3, gpart_asSV) = Genome.Split.split gpart_asSU
                      p_asS2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS1
                      (g_asS1, gpart_asSU) = Genome.Split.split gpart_asST
                      p_asS0 = Functions.belowten' g_asRZ
                      (g_asRZ, gpart_asST) = Genome.Split.split gpart_asSS
                      p_asRY = code-0.1.0.0:Genome.FixedList.Functions.double g_asRX
                      (g_asRX, gpart_asSS) = Genome.Split.split gpart_asSR
                      p_asRW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRV
                      (g_asRV, gpart_asSR) = Genome.Split.split gpart_asSQ
                      p_asRU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRT
                      (g_asRT, gpart_asSQ) = Genome.Split.split gpart_asSP
                      p_asRS = code-0.1.0.0:Genome.FixedList.Functions.double g_asRR
                      (g_asRR, gpart_asSP) = Genome.Split.split gpart_asSO
                      p_asRQ = Functions.belowten' g_asRP
                      (g_asRP, gpart_asSO) = Genome.Split.split gpart_asSN
                      p_asRO = code-0.1.0.0:Genome.FixedList.Functions.double g_asRN
                      (g_asRN, gpart_asSN) = Genome.Split.split gpart_asSM
                      p_asRM = Functions.belowten' g_asRL
                      (g_asRL, gpart_asSM) = Genome.Split.split gpart_asSL
                      p_asRK = code-0.1.0.0:Genome.FixedList.Functions.double g_asRJ
                      (g_asRJ, gpart_asSL) = Genome.Split.split gpart_asSK
                      p_asRI = code-0.1.0.0:Genome.FixedList.Functions.double g_asRH
                      (g_asRH, gpart_asSK) = Genome.Split.split gpart_asSJ
                      p_asRG = Functions.belowten' g_asRF
                      (g_asRF, gpart_asSJ) = Genome.Split.split gpart_asSI
                      p_asRE = code-0.1.0.0:Genome.FixedList.Functions.double g_asRD
                      (g_asRD, gpart_asSI) = Genome.Split.split gpart_asSH
                      p_asRC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRB
                      (g_asRB, gpart_asSH) = Genome.Split.split gpart_asSG
                      p_asRA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRz
                      (g_asRz, gpart_asSG) = Genome.Split.split gpart_asSF
                      p_asRy = code-0.1.0.0:Genome.FixedList.Functions.double g_asRx
                      (g_asRx, gpart_asSF) = Genome.Split.split gpart_asSE
                      p_asRw = code-0.1.0.0:Genome.FixedList.Functions.double g_asRv
                      (g_asRv, gpart_asSE) = Genome.Split.split gpart_asSD
                      p_asRu = code-0.1.0.0:Genome.FixedList.Functions.double g_asRt
                      (g_asRt, gpart_asSD) = Genome.Split.split gpart_asSC
                      p_asRs = code-0.1.0.0:Genome.FixedList.Functions.double g_asRr
                      (g_asRr, gpart_asSC) = Genome.Split.split gpart_asSB
                      p_asRq = code-0.1.0.0:Genome.FixedList.Functions.double g_asRp
                      (g_asRp, gpart_asSB) = Genome.Split.split genome_asSz
                    in
                      [Reaction
                         (\ x_asTb
                            -> let c_MiRs_asTc = ((toVector x_asTb) Data.Vector.Unboxed.! 2)
                               in (p_asRy / (1 + ((c_MiRs_asTc / p_asRE) ** p_asRG))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTd
                            -> let
                                 c_MiRs_asTe = ((toVector x_asTd) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTf = ((toVector x_asTd) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asRI
                                  / (1
                                     + (((c_MiRs_asTe / p_asRK) ** p_asRM)
                                        + ((c_PTB_asTf / p_asRO) ** p_asRQ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asTg
                            -> let c_RESTc_asTh = ((toVector x_asTg) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asRS
                                  * ((p_asS2 + ((p_asRu / p_asRU) ** p_asRW))
                                     / (((1 + p_asS2) + ((p_asRu / p_asRU) ** p_asRW))
                                        + ((c_RESTc_asTh / p_asRY) ** p_asS0)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asTi
                            -> let
                                 c_MiRs_asTl = ((toVector x_asTi) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTj = ((toVector x_asTi) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asS4
                                  * ((p_asSi + ((c_PTB_asTj / p_asS6) ** p_asS8))
                                     / (((1 + p_asSi) + ((c_PTB_asTj / p_asS6) ** p_asS8))
                                        + (((p_asRq / p_asSa) ** p_asSc)
                                           + ((c_MiRs_asTl / p_asSe) ** p_asSg))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asTm
                            -> let c_RESTc_asTn = ((toVector x_asTm) Data.Vector.Unboxed.! 3)
                               in (p_asSk / (1 + ((c_RESTc_asTn / p_asSm) ** p_asSo))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asTo
                            -> let c_PTB_asTp = ((toVector x_asTo) Data.Vector.Unboxed.! 0)
                               in (p_asSq * c_PTB_asTp))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTq
                            -> let c_NPTB_asTr = ((toVector x_asTq) Data.Vector.Unboxed.! 1)
                               in (p_asSs * c_NPTB_asTr))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asTs
                            -> let c_MiRs_asTt = ((toVector x_asTs) Data.Vector.Unboxed.! 2)
                               in (p_asSu * c_MiRs_asTt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asTu
                            -> let c_RESTc_asTv = ((toVector x_asTu) Data.Vector.Unboxed.! 3)
                               in (p_asSw * c_RESTc_asTv))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asTw
                            -> let
                                 c_EndoNeuroTFs_asTx = ((toVector x_asTw) Data.Vector.Unboxed.! 4)
                               in (p_asSy * c_EndoNeuroTFs_asTx))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120746",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120748",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120766",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120768",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120782",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120784",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120792",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asSz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUc
                            p_asSy = code-0.1.0.0:Genome.FixedList.Functions.double g_asSx
                            (g_asSx, gpart_asUc) = Genome.Split.split gpart_asUb
                            p_asSw = code-0.1.0.0:Genome.FixedList.Functions.double g_asSv
                            (g_asSv, gpart_asUb) = Genome.Split.split gpart_asUa
                            p_asSu = code-0.1.0.0:Genome.FixedList.Functions.double g_asSt
                            (g_asSt, gpart_asUa) = Genome.Split.split gpart_asU9
                            p_asSs = code-0.1.0.0:Genome.FixedList.Functions.double g_asSr
                            (g_asSr, gpart_asU9) = Genome.Split.split gpart_asU8
                            p_asSq = code-0.1.0.0:Genome.FixedList.Functions.double g_asSp
                            (g_asSp, gpart_asU8) = Genome.Split.split gpart_asU7
                            p_asSo = Functions.belowten' g_asSn
                            (g_asSn, gpart_asU7) = Genome.Split.split gpart_asU6
                            p_asSm = code-0.1.0.0:Genome.FixedList.Functions.double g_asSl
                            (g_asSl, gpart_asU6) = Genome.Split.split gpart_asU5
                            p_asSk = code-0.1.0.0:Genome.FixedList.Functions.double g_asSj
                            (g_asSj, gpart_asU5) = Genome.Split.split gpart_asU4
                            p_asSi = code-0.1.0.0:Genome.FixedList.Functions.double g_asSh
                            (g_asSh, gpart_asU4) = Genome.Split.split gpart_asU3
                            p_asSg = Functions.belowten' g_asSf
                            (g_asSf, gpart_asU3) = Genome.Split.split gpart_asU2
                            p_asSe = code-0.1.0.0:Genome.FixedList.Functions.double g_asSd
                            (g_asSd, gpart_asU2) = Genome.Split.split gpart_asU1
                            p_asSc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSb
                            (g_asSb, gpart_asU1) = Genome.Split.split gpart_asU0
                            p_asSa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asS9
                            (g_asS9, gpart_asU0) = Genome.Split.split gpart_asTZ
                            p_asS8 = Functions.belowten' g_asS7
                            (g_asS7, gpart_asTZ) = Genome.Split.split gpart_asTY
                            p_asS6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS5
                            (g_asS5, gpart_asTY) = Genome.Split.split gpart_asTX
                            p_asS4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS3
                            (g_asS3, gpart_asTX) = Genome.Split.split gpart_asTW
                            p_asS2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS1
                            (g_asS1, gpart_asTW) = Genome.Split.split gpart_asTV
                            p_asS0 = Functions.belowten' g_asRZ
                            (g_asRZ, gpart_asTV) = Genome.Split.split gpart_asTU
                            p_asRY = code-0.1.0.0:Genome.FixedList.Functions.double g_asRX
                            (g_asRX, gpart_asTU) = Genome.Split.split gpart_asTT
                            p_asRW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRV
                            (g_asRV, gpart_asTT) = Genome.Split.split gpart_asTS
                            p_asRU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRT
                            (g_asRT, gpart_asTS) = Genome.Split.split gpart_asTR
                            p_asRS = code-0.1.0.0:Genome.FixedList.Functions.double g_asRR
                            (g_asRR, gpart_asTR) = Genome.Split.split gpart_asTQ
                            p_asRQ = Functions.belowten' g_asRP
                            (g_asRP, gpart_asTQ) = Genome.Split.split gpart_asTP
                            p_asRO = code-0.1.0.0:Genome.FixedList.Functions.double g_asRN
                            (g_asRN, gpart_asTP) = Genome.Split.split gpart_asTO
                            p_asRM = Functions.belowten' g_asRL
                            (g_asRL, gpart_asTO) = Genome.Split.split gpart_asTN
                            p_asRK = code-0.1.0.0:Genome.FixedList.Functions.double g_asRJ
                            (g_asRJ, gpart_asTN) = Genome.Split.split gpart_asTM
                            p_asRI = code-0.1.0.0:Genome.FixedList.Functions.double g_asRH
                            (g_asRH, gpart_asTM) = Genome.Split.split gpart_asTL
                            p_asRG = Functions.belowten' g_asRF
                            (g_asRF, gpart_asTL) = Genome.Split.split gpart_asTK
                            p_asRE = code-0.1.0.0:Genome.FixedList.Functions.double g_asRD
                            (g_asRD, gpart_asTK) = Genome.Split.split gpart_asTJ
                            p_asRC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRB
                            (g_asRB, gpart_asTJ) = Genome.Split.split gpart_asTI
                            p_asRA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRz
                            (g_asRz, gpart_asTI) = Genome.Split.split gpart_asTH
                            p_asRy = code-0.1.0.0:Genome.FixedList.Functions.double g_asRx
                            (g_asRx, gpart_asTH) = Genome.Split.split gpart_asTG
                            p_asRw = code-0.1.0.0:Genome.FixedList.Functions.double g_asRv
                            (g_asRv, gpart_asTG) = Genome.Split.split gpart_asTF
                            p_asRu = code-0.1.0.0:Genome.FixedList.Functions.double g_asRt
                            (g_asRt, gpart_asTF) = Genome.Split.split gpart_asTE
                            p_asRs = code-0.1.0.0:Genome.FixedList.Functions.double g_asRr
                            (g_asRr, gpart_asTE) = Genome.Split.split gpart_asTD
                            p_asRq = code-0.1.0.0:Genome.FixedList.Functions.double g_asRp
                            (g_asRp, gpart_asTD) = Genome.Split.split genome_asSz
                          in
                            \ desc_asSA
                              -> case desc_asSA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRq)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRs)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRu)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRw)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRy)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRA)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRC)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRE)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRG)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRI)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRK)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRM)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRO)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRQ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRS)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRU)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRW)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRY)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS0)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS2)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS4)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS6)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS8)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSa)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSc)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSe)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSg)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSi)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSk)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSm)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSo)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSs)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSu)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSy)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asW3
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWE
                      p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                      (g_asW1, gpart_asWE) = Genome.Split.split gpart_asWD
                      p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                      (g_asVZ, gpart_asWD) = Genome.Split.split gpart_asWC
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asWC) = Genome.Split.split gpart_asWB
                      p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                      (g_asVV, gpart_asWB) = Genome.Split.split gpart_asWA
                      p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                      (g_asVT, gpart_asWA) = Genome.Split.split gpart_asWz
                      p_asVS = Functions.belowten' g_asVR
                      (g_asVR, gpart_asWz) = Genome.Split.split gpart_asWy
                      p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                      (g_asVP, gpart_asWy) = Genome.Split.split gpart_asWx
                      p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                      (g_asVN, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                      (g_asVL, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asVK = Functions.belowten' g_asVJ
                      (g_asVJ, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                      (g_asVH, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asVG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVF
                      (g_asVF, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asVE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVD
                      (g_asVD, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asVC = Functions.belowten' g_asVB
                      (g_asVB, gpart_asWr) = Genome.Split.split gpart_asWq
                      p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                      (g_asVz, gpart_asWq) = Genome.Split.split gpart_asWp
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWp) = Genome.Split.split gpart_asWo
                      p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                      (g_asVv, gpart_asWo) = Genome.Split.split gpart_asWn
                      p_asVu = Functions.belowten' g_asVt
                      (g_asVt, gpart_asWn) = Genome.Split.split gpart_asWm
                      p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                      (g_asVr, gpart_asWm) = Genome.Split.split gpart_asWl
                      p_asVq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVp
                      (g_asVp, gpart_asWl) = Genome.Split.split gpart_asWk
                      p_asVo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVn
                      (g_asVn, gpart_asWk) = Genome.Split.split gpart_asWj
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWj) = Genome.Split.split gpart_asWi
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asWi) = Genome.Split.split gpart_asWh
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asWh) = Genome.Split.split gpart_asWg
                      p_asVg = Functions.belowten' g_asVf
                      (g_asVf, gpart_asWg) = Genome.Split.split gpart_asWf
                      p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                      (g_asVd, gpart_asWf) = Genome.Split.split gpart_asWe
                      p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                      (g_asVb, gpart_asWe) = Genome.Split.split gpart_asWd
                      p_asVa = Functions.belowten' g_asV9
                      (g_asV9, gpart_asWd) = Genome.Split.split gpart_asWc
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asWc) = Genome.Split.split gpart_asWb
                      p_asV6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                      (g_asV5, gpart_asWb) = Genome.Split.split gpart_asWa
                      p_asV4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV3
                      (g_asV3, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                      (g_asUT, gpart_asW5) = Genome.Split.split genome_asW3
                    in
                      [Reaction
                         (\ x_asWF
                            -> let c_MiRs_asWG = ((toVector x_asWF) Data.Vector.Unboxed.! 2)
                               in (p_asV2 / (1 + ((c_MiRs_asWG / p_asV8) ** p_asVa))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWH
                            -> let
                                 c_MiRs_asWI = ((toVector x_asWH) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWJ = ((toVector x_asWH) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVc
                                  / (1
                                     + (((c_MiRs_asWI / p_asVe) ** p_asVg)
                                        + ((c_PTB_asWJ / p_asVi) ** p_asVk)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWK
                            -> let c_RESTc_asWL = ((toVector x_asWK) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asVm
                                  * (p_asVw
                                     / ((1 + p_asVw) + ((c_RESTc_asWL / p_asVs) ** p_asVu)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWM
                            -> let
                                 c_MiRs_asWP = ((toVector x_asWM) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWN = ((toVector x_asWM) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVy
                                  * ((p_asVM + ((c_PTB_asWN / p_asVA) ** p_asVC))
                                     / (((1 + p_asVM) + ((c_PTB_asWN / p_asVA) ** p_asVC))
                                        + (((p_asUU / p_asVE) ** p_asVG)
                                           + ((c_MiRs_asWP / p_asVI) ** p_asVK))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWQ
                            -> let c_RESTc_asWR = ((toVector x_asWQ) Data.Vector.Unboxed.! 3)
                               in (p_asVO / (1 + ((c_RESTc_asWR / p_asVQ) ** p_asVS))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWS
                            -> let c_PTB_asWT = ((toVector x_asWS) Data.Vector.Unboxed.! 0)
                               in (p_asVU * c_PTB_asWT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWU
                            -> let c_NPTB_asWV = ((toVector x_asWU) Data.Vector.Unboxed.! 1)
                               in (p_asVW * c_NPTB_asWV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWW
                            -> let c_MiRs_asWX = ((toVector x_asWW) Data.Vector.Unboxed.! 2)
                               in (p_asVY * c_MiRs_asWX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWY
                            -> let c_RESTc_asWZ = ((toVector x_asWY) Data.Vector.Unboxed.! 3)
                               in (p_asW0 * c_RESTc_asWZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asX0
                            -> let
                                 c_EndoNeuroTFs_asX1 = ((toVector x_asX0) Data.Vector.Unboxed.! 4)
                               in (p_asW2 * c_EndoNeuroTFs_asX1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asW3
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXB
                            p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                            (g_asW1, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asW0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asVZ
                            (g_asVZ, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asXz) = Genome.Split.split gpart_asXy
                            p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                            (g_asVV, gpart_asXy) = Genome.Split.split gpart_asXx
                            p_asVU = code-0.1.0.0:Genome.FixedList.Functions.double g_asVT
                            (g_asVT, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVS = Functions.belowten' g_asVR
                            (g_asVR, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                            (g_asVP, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                            (g_asVN, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                            (g_asVL, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVK = Functions.belowten' g_asVJ
                            (g_asVJ, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                            (g_asVH, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVF
                            (g_asVF, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVD
                            (g_asVD, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVC = Functions.belowten' g_asVB
                            (g_asVB, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                            (g_asVz, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asVw = code-0.1.0.0:Genome.FixedList.Functions.double g_asVv
                            (g_asVv, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asVu = Functions.belowten' g_asVt
                            (g_asVt, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVs = code-0.1.0.0:Genome.FixedList.Functions.double g_asVr
                            (g_asVr, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVp
                            (g_asVp, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asVo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVn
                            (g_asVn, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asVg = Functions.belowten' g_asVf
                            (g_asVf, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asVe = code-0.1.0.0:Genome.FixedList.Functions.double g_asVd
                            (g_asVd, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asVc = code-0.1.0.0:Genome.FixedList.Functions.double g_asVb
                            (g_asVb, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asVa = Functions.belowten' g_asV9
                            (g_asV9, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asV6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV5
                            (g_asV5, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asV4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV3
                            (g_asV3, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                            (g_asUT, gpart_asX2) = Genome.Split.split genome_asW3
                          in
                            \ desc_asW4
                              -> case desc_asW4 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_asZs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at03
                      p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                      (g_asZq, gpart_at03) = Genome.Split.split gpart_at02
                      p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                      (g_asZo, gpart_at02) = Genome.Split.split gpart_at01
                      p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                      (g_asZm, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                      (g_asZi, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZh = Functions.belowten' g_asZg
                      (g_asZg, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                      (g_asZe, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                      (g_asZa, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asZ9 = Functions.belowten' g_asZ8
                      (g_asZ8, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                      (g_asZ6, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asZ5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ4
                      (g_asZ4, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asZ3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ2
                      (g_asZ2, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asZ1 = Functions.belowten' g_asZ0
                      (g_asZ0, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYT = Functions.belowten' g_asYS
                      (g_asYS, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                      (g_asYQ, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYO
                      (g_asYO, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYM
                      (g_asYM, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYJ = Functions.belowten' g_asYI
                      (g_asYI, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYF = Functions.belowten' g_asYE
                      (g_asYE, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                      (g_asYC, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYz = Functions.belowten' g_asYy
                      (g_asYy, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYu
                      (g_asYu, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYs
                      (g_asYs, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZu) = Genome.Split.split genome_asZs
                    in
                      [Reaction
                         (\ x_at04
                            -> let c_MiRs_at05 = ((toVector x_at04) Data.Vector.Unboxed.! 2)
                               in (p_asYr / (1 + ((c_MiRs_at05 / p_asYx) ** p_asYz))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at06
                            -> let
                                 c_MiRs_at07 = ((toVector x_at06) Data.Vector.Unboxed.! 2)
                                 c_PTB_at08 = ((toVector x_at06) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYB
                                  / (1
                                     + (((c_MiRs_at07 / p_asYD) ** p_asYF)
                                        + ((c_PTB_at08 / p_asYH) ** p_asYJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at09
                            -> let c_RESTc_at0a = ((toVector x_at09) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYL
                                  * (p_asYV
                                     / ((1 + p_asYV) + ((c_RESTc_at0a / p_asYR) ** p_asYT)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0b
                            -> let
                                 c_MiRs_at0e = ((toVector x_at0b) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0c = ((toVector x_at0b) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYX
                                  * ((p_asZb + ((c_PTB_at0c / p_asYZ) ** p_asZ1))
                                     / (((1 + p_asZb) + ((c_PTB_at0c / p_asYZ) ** p_asZ1))
                                        + ((c_MiRs_at0e / p_asZ7) ** p_asZ9)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0f
                            -> let c_RESTc_at0g = ((toVector x_at0f) Data.Vector.Unboxed.! 3)
                               in (p_asZd / (1 + ((c_RESTc_at0g / p_asZf) ** p_asZh))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0h
                            -> let c_PTB_at0i = ((toVector x_at0h) Data.Vector.Unboxed.! 0)
                               in (p_asZj * c_PTB_at0i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0j
                            -> let c_NPTB_at0k = ((toVector x_at0j) Data.Vector.Unboxed.! 1)
                               in (p_asZl * c_NPTB_at0k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0l
                            -> let c_MiRs_at0m = ((toVector x_at0l) Data.Vector.Unboxed.! 2)
                               in (p_asZn * c_MiRs_at0m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0n
                            -> let c_RESTc_at0o = ((toVector x_at0n) Data.Vector.Unboxed.! 3)
                               in (p_asZp * c_RESTc_at0o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0p
                            -> let
                                 c_EndoNeuroTFs_at0q = ((toVector x_at0p) Data.Vector.Unboxed.! 4)
                               in (p_asZr * c_EndoNeuroTFs_at0q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at10
                            p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                            (g_asZq, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asZp = code-0.1.0.0:Genome.FixedList.Functions.double g_asZo
                            (g_asZo, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                            (g_asZm, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                            (g_asZi, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asZh = Functions.belowten' g_asZg
                            (g_asZg, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                            (g_asZe, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                            (g_asZa, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asZ9 = Functions.belowten' g_asZ8
                            (g_asZ8, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                            (g_asZ6, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asZ5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ4
                            (g_asZ4, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asZ3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ2
                            (g_asZ2, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asZ1 = Functions.belowten' g_asZ0
                            (g_asZ0, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYT = Functions.belowten' g_asYS
                            (g_asYS, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                            (g_asYQ, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYO
                            (g_asYO, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYM
                            (g_asYM, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYJ = Functions.belowten' g_asYI
                            (g_asYI, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYF = Functions.belowten' g_asYE
                            (g_asYE, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                            (g_asYC, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYz = Functions.belowten' g_asYy
                            (g_asYy, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYu
                            (g_asYu, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYs
                            (g_asYs, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at0r) = Genome.Split.split genome_asZs
                          in
                            \ desc_asZt
                              -> case desc_asZt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at2R
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3s
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                      (g_at2J, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2G = Functions.belowten' g_at2F
                      (g_at2F, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                      (g_at2z, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2y = Functions.belowten' g_at2x
                      (g_at2x, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at2u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                      (g_at2t, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at2s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2r
                      (g_at2r, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at2q = Functions.belowten' g_at2p
                      (g_at2p, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                      (g_at2l, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at2i = Functions.belowten' g_at2h
                      (g_at2h, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at2e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2d
                      (g_at2d, gpart_at39) = Genome.Split.split gpart_at38
                      p_at2c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2b
                      (g_at2b, gpart_at38) = Genome.Split.split gpart_at37
                      p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                      (g_at29, gpart_at37) = Genome.Split.split gpart_at36
                      p_at28 = Functions.belowten' g_at27
                      (g_at27, gpart_at36) = Genome.Split.split gpart_at35
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at35) = Genome.Split.split gpart_at34
                      p_at24 = Functions.belowten' g_at23
                      (g_at23, gpart_at34) = Genome.Split.split gpart_at33
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at33) = Genome.Split.split gpart_at32
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1Y = Functions.belowten' g_at1X
                      (g_at1X, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1T
                      (g_at1T, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at1S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                      (g_at1R, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                      (g_at1L, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at2T) = Genome.Split.split genome_at2R
                    in
                      [Reaction
                         (\ x_at3t
                            -> let c_MiRs_at3u = ((toVector x_at3t) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at1Q
                                  / (1
                                     + (((p_at1I / p_at1S) ** p_at1U)
                                        + ((c_MiRs_at3u / p_at1W) ** p_at1Y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3v
                            -> let
                                 c_MiRs_at3w = ((toVector x_at3v) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3x = ((toVector x_at3v) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at20
                                  / (1
                                     + (((c_MiRs_at3w / p_at22) ** p_at24)
                                        + ((c_PTB_at3x / p_at26) ** p_at28)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3y
                            -> let c_RESTc_at3z = ((toVector x_at3y) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2a
                                  * (p_at2k
                                     / ((1 + p_at2k) + ((c_RESTc_at3z / p_at2g) ** p_at2i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3A
                            -> let
                                 c_MiRs_at3D = ((toVector x_at3A) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3B = ((toVector x_at3A) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2m
                                  * ((p_at2A + ((c_PTB_at3B / p_at2o) ** p_at2q))
                                     / (((1 + p_at2A) + ((c_PTB_at3B / p_at2o) ** p_at2q))
                                        + ((c_MiRs_at3D / p_at2w) ** p_at2y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3E
                            -> let c_RESTc_at3F = ((toVector x_at3E) Data.Vector.Unboxed.! 3)
                               in (p_at2C / (1 + ((c_RESTc_at3F / p_at2E) ** p_at2G))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3G
                            -> let c_PTB_at3H = ((toVector x_at3G) Data.Vector.Unboxed.! 0)
                               in (p_at2I * c_PTB_at3H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3I
                            -> let c_NPTB_at3J = ((toVector x_at3I) Data.Vector.Unboxed.! 1)
                               in (p_at2K * c_NPTB_at3J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3K
                            -> let c_MiRs_at3L = ((toVector x_at3K) Data.Vector.Unboxed.! 2)
                               in (p_at2M * c_MiRs_at3L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3M
                            -> let c_RESTc_at3N = ((toVector x_at3M) Data.Vector.Unboxed.! 3)
                               in (p_at2O * c_RESTc_at3N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3O
                            -> let
                                 c_EndoNeuroTFs_at3P = ((toVector x_at3O) Data.Vector.Unboxed.! 4)
                               in (p_at2Q * c_EndoNeuroTFs_at3P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2R
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4p
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at2K = code-0.1.0.0:Genome.FixedList.Functions.double g_at2J
                            (g_at2J, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at2G = Functions.belowten' g_at2F
                            (g_at2F, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                            (g_at2z, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at2y = Functions.belowten' g_at2x
                            (g_at2x, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at2u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                            (g_at2t, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at2s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2r
                            (g_at2r, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at2q = Functions.belowten' g_at2p
                            (g_at2p, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                            (g_at2l, gpart_at4a) = Genome.Split.split gpart_at49
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at49) = Genome.Split.split gpart_at48
                            p_at2i = Functions.belowten' g_at2h
                            (g_at2h, gpart_at48) = Genome.Split.split gpart_at47
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at47) = Genome.Split.split gpart_at46
                            p_at2e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2d
                            (g_at2d, gpart_at46) = Genome.Split.split gpart_at45
                            p_at2c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2b
                            (g_at2b, gpart_at45) = Genome.Split.split gpart_at44
                            p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                            (g_at29, gpart_at44) = Genome.Split.split gpart_at43
                            p_at28 = Functions.belowten' g_at27
                            (g_at27, gpart_at43) = Genome.Split.split gpart_at42
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at42) = Genome.Split.split gpart_at41
                            p_at24 = Functions.belowten' g_at23
                            (g_at23, gpart_at41) = Genome.Split.split gpart_at40
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at1Y = Functions.belowten' g_at1X
                            (g_at1X, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at1U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1T
                            (g_at1T, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at1S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                            (g_at1R, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at3T) = Genome.Split.split gpart_at3S
                            p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                            (g_at1L, gpart_at3S) = Genome.Split.split gpart_at3R
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at3Q) = Genome.Split.split genome_at2R
                          in
                            \ desc_at2S
                              -> case desc_at2S of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   _ -> Nothing }}
