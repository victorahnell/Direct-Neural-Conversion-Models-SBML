src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a2ahd
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ahW
                      p_a2ahc = double g_a2ahb
                      (g_a2ahb, gpart_a2ahW) = Genome.Split.split gpart_a2ahV
                      p_a2aha = double g_a2ah9
                      (g_a2ah9, gpart_a2ahV) = Genome.Split.split gpart_a2ahU
                      p_a2ah8 = double g_a2ah7
                      (g_a2ah7, gpart_a2ahU) = Genome.Split.split gpart_a2ahT
                      p_a2ah6 = double g_a2ah5
                      (g_a2ah5, gpart_a2ahT) = Genome.Split.split gpart_a2ahS
                      p_a2ah4 = double g_a2ah3
                      (g_a2ah3, gpart_a2ahS) = Genome.Split.split gpart_a2ahR
                      p_a2ah2 = double g_a2ah1
                      (g_a2ah1, gpart_a2ahR) = Genome.Split.split gpart_a2ahQ
                      p_a2ah0 = Functions.belowten' g_a2agZ
                      (g_a2agZ, gpart_a2ahQ) = Genome.Split.split gpart_a2ahP
                      p_a2agY = double g_a2agX
                      (g_a2agX, gpart_a2ahP) = Genome.Split.split gpart_a2ahO
                      p_a2agW = Functions.belowten' g_a2agV
                      (g_a2agV, gpart_a2ahO) = Genome.Split.split gpart_a2ahN
                      p_a2agU = double g_a2agT
                      (g_a2agT, gpart_a2ahN) = Genome.Split.split gpart_a2ahM
                      p_a2agS = double g_a2agR
                      (g_a2agR, gpart_a2ahM) = Genome.Split.split gpart_a2ahL
                      p_a2agQ = double g_a2agP
                      (g_a2agP, gpart_a2ahL) = Genome.Split.split gpart_a2ahK
                      p_a2agO = Functions.belowten' g_a2agN
                      (g_a2agN, gpart_a2ahK) = Genome.Split.split gpart_a2ahJ
                      p_a2agM = double g_a2agL
                      (g_a2agL, gpart_a2ahJ) = Genome.Split.split gpart_a2ahI
                      p_a2agK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agJ
                      (g_a2agJ, gpart_a2ahI) = Genome.Split.split gpart_a2ahH
                      p_a2agI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agH
                      (g_a2agH, gpart_a2ahH) = Genome.Split.split gpart_a2ahG
                      p_a2agG = Functions.belowten' g_a2agF
                      (g_a2agF, gpart_a2ahG) = Genome.Split.split gpart_a2ahF
                      p_a2agE = double g_a2agD
                      (g_a2agD, gpart_a2ahF) = Genome.Split.split gpart_a2ahE
                      p_a2agC = double g_a2agB
                      (g_a2agB, gpart_a2ahE) = Genome.Split.split gpart_a2ahD
                      p_a2agA = double g_a2agz
                      (g_a2agz, gpart_a2ahD) = Genome.Split.split gpart_a2ahC
                      p_a2agy = Functions.belowten' g_a2agx
                      (g_a2agx, gpart_a2ahC) = Genome.Split.split gpart_a2ahB
                      p_a2agw = double g_a2agv
                      (g_a2agv, gpart_a2ahB) = Genome.Split.split gpart_a2ahA
                      p_a2agu = Functions.belowten' g_a2agt
                      (g_a2agt, gpart_a2ahA) = Genome.Split.split gpart_a2ahz
                      p_a2ags = double g_a2agr
                      (g_a2agr, gpart_a2ahz) = Genome.Split.split gpart_a2ahy
                      p_a2agq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agp
                      (g_a2agp, gpart_a2ahy) = Genome.Split.split gpart_a2ahx
                      p_a2ago
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agn
                      (g_a2agn, gpart_a2ahx) = Genome.Split.split gpart_a2ahw
                      p_a2agm = double g_a2agl
                      (g_a2agl, gpart_a2ahw) = Genome.Split.split gpart_a2ahv
                      p_a2agk = Functions.belowten' g_a2agj
                      (g_a2agj, gpart_a2ahv) = Genome.Split.split gpart_a2ahu
                      p_a2agi = double g_a2agh
                      (g_a2agh, gpart_a2ahu) = Genome.Split.split gpart_a2aht
                      p_a2agg = Functions.belowten' g_a2agf
                      (g_a2agf, gpart_a2aht) = Genome.Split.split gpart_a2ahs
                      p_a2age = double g_a2agd
                      (g_a2agd, gpart_a2ahs) = Genome.Split.split gpart_a2ahr
                      p_a2agc = double g_a2agb
                      (g_a2agb, gpart_a2ahr) = Genome.Split.split gpart_a2ahq
                      p_a2aga = double g_a2ag9
                      (g_a2ag9, gpart_a2ahq) = Genome.Split.split gpart_a2ahp
                      p_a2ag8 = Functions.belowten' g_a2ag7
                      (g_a2ag7, gpart_a2ahp) = Genome.Split.split gpart_a2aho
                      p_a2ag6 = double g_a2ag5
                      (g_a2ag5, gpart_a2aho) = Genome.Split.split gpart_a2ahn
                      p_a2ag4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ag3
                      (g_a2ag3, gpart_a2ahn) = Genome.Split.split gpart_a2ahm
                      p_a2ag2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ag1
                      (g_a2ag1, gpart_a2ahm) = Genome.Split.split gpart_a2ahl
                      p_a2ag0 = Functions.belowten' g_a2afZ
                      (g_a2afZ, gpart_a2ahl) = Genome.Split.split gpart_a2ahk
                      p_a2afY = double g_a2afX
                      (g_a2afX, gpart_a2ahk) = Genome.Split.split gpart_a2ahj
                      p_a2afW = double g_a2afV
                      (g_a2afV, gpart_a2ahj) = Genome.Split.split gpart_a2ahi
                      p_a2afU = double g_a2afT
                      (g_a2afT, gpart_a2ahi) = Genome.Split.split gpart_a2ahh
                      p_a2afS = double g_a2afR
                      (g_a2afR, gpart_a2ahh) = Genome.Split.split gpart_a2ahg
                      p_a2afQ = double g_a2afP
                      (g_a2afP, gpart_a2ahg) = Genome.Split.split gpart_a2ahf
                      p_a2afO = double g_a2afN
                      (g_a2afN, gpart_a2ahf) = Genome.Split.split genome_a2ahd
                    in  \ x_a2ahX
                          -> let
                               c_PTB_a2ai2
                                 = ((Data.Fixed.Vector.toVector x_a2ahX) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2ai0
                                 = ((Data.Fixed.Vector.toVector x_a2ahX) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2ahY
                                 = ((Data.Fixed.Vector.toVector x_a2ahX) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2ai9
                                 = ((Data.Fixed.Vector.toVector x_a2ahX) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2ail
                                 = ((Data.Fixed.Vector.toVector x_a2ahX) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2afW
                                     * ((p_a2aga + ((c_NPTB_a2ahY / p_a2afY) ** p_a2ag0))
                                        / (((1 + p_a2aga) + ((c_NPTB_a2ahY / p_a2afY) ** p_a2ag0))
                                           + ((c_MiRs_a2ai0 / p_a2ag6) ** p_a2ag8))))
                                    + (negate (p_a2ah4 * c_PTB_a2ai2))),
                                   ((p_a2agc
                                     / (1
                                        + (((c_MiRs_a2ai0 / p_a2age) ** p_a2agg)
                                           + ((c_PTB_a2ai2 / p_a2agi) ** p_a2agk))))
                                    + (negate (p_a2ah6 * c_NPTB_a2ahY))),
                                   ((p_a2agm
                                     * ((p_a2agA
                                         + (((p_a2afS / p_a2ago) ** p_a2agq)
                                            + ((c_NPTB_a2ahY / p_a2ags) ** p_a2agu)))
                                        / (((1 + p_a2agA)
                                            + (((p_a2afS / p_a2ago) ** p_a2agq)
                                               + ((c_NPTB_a2ahY / p_a2ags) ** p_a2agu)))
                                           + ((c_RESTc_a2ai9 / p_a2agw) ** p_a2agy))))
                                    + (negate (p_a2ah8 * c_MiRs_a2ai0))),
                                   ((p_a2agC
                                     * ((p_a2agQ + ((c_PTB_a2ai2 / p_a2agE) ** p_a2agG))
                                        / (((1 + p_a2agQ) + ((c_PTB_a2ai2 / p_a2agE) ** p_a2agG))
                                           + (((p_a2afO / p_a2agI) ** p_a2agK)
                                              + ((c_MiRs_a2ai0 / p_a2agM) ** p_a2agO)))))
                                    + (negate (p_a2aha * c_RESTc_a2ai9))),
                                   ((p_a2agS
                                     * ((p_a2ah2 + ((c_MiRs_a2ai0 / p_a2agU) ** p_a2agW))
                                        / (((1 + p_a2ah2) + ((c_MiRs_a2ai0 / p_a2agU) ** p_a2agW))
                                           + ((c_RESTc_a2ai9 / p_a2agY) ** p_a2ah0))))
                                    + (negate (p_a2ahc * c_EndoNeuroTFs_a2ail)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525882",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525884",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525904",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525906",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525924",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525926",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679525953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679525954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2ahd
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aj3
                            p_a2ahc = double g_a2ahb
                            (g_a2ahb, gpart_a2aj3) = Genome.Split.split gpart_a2aj2
                            p_a2aha = double g_a2ah9
                            (g_a2ah9, gpart_a2aj2) = Genome.Split.split gpart_a2aj1
                            p_a2ah8 = double g_a2ah7
                            (g_a2ah7, gpart_a2aj1) = Genome.Split.split gpart_a2aj0
                            p_a2ah6 = double g_a2ah5
                            (g_a2ah5, gpart_a2aj0) = Genome.Split.split gpart_a2aiZ
                            p_a2ah4 = double g_a2ah3
                            (g_a2ah3, gpart_a2aiZ) = Genome.Split.split gpart_a2aiY
                            p_a2ah2 = double g_a2ah1
                            (g_a2ah1, gpart_a2aiY) = Genome.Split.split gpart_a2aiX
                            p_a2ah0 = Functions.belowten' g_a2agZ
                            (g_a2agZ, gpart_a2aiX) = Genome.Split.split gpart_a2aiW
                            p_a2agY = double g_a2agX
                            (g_a2agX, gpart_a2aiW) = Genome.Split.split gpart_a2aiV
                            p_a2agW = Functions.belowten' g_a2agV
                            (g_a2agV, gpart_a2aiV) = Genome.Split.split gpart_a2aiU
                            p_a2agU = double g_a2agT
                            (g_a2agT, gpart_a2aiU) = Genome.Split.split gpart_a2aiT
                            p_a2agS = double g_a2agR
                            (g_a2agR, gpart_a2aiT) = Genome.Split.split gpart_a2aiS
                            p_a2agQ = double g_a2agP
                            (g_a2agP, gpart_a2aiS) = Genome.Split.split gpart_a2aiR
                            p_a2agO = Functions.belowten' g_a2agN
                            (g_a2agN, gpart_a2aiR) = Genome.Split.split gpart_a2aiQ
                            p_a2agM = double g_a2agL
                            (g_a2agL, gpart_a2aiQ) = Genome.Split.split gpart_a2aiP
                            p_a2agK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agJ
                            (g_a2agJ, gpart_a2aiP) = Genome.Split.split gpart_a2aiO
                            p_a2agI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agH
                            (g_a2agH, gpart_a2aiO) = Genome.Split.split gpart_a2aiN
                            p_a2agG = Functions.belowten' g_a2agF
                            (g_a2agF, gpart_a2aiN) = Genome.Split.split gpart_a2aiM
                            p_a2agE = double g_a2agD
                            (g_a2agD, gpart_a2aiM) = Genome.Split.split gpart_a2aiL
                            p_a2agC = double g_a2agB
                            (g_a2agB, gpart_a2aiL) = Genome.Split.split gpart_a2aiK
                            p_a2agA = double g_a2agz
                            (g_a2agz, gpart_a2aiK) = Genome.Split.split gpart_a2aiJ
                            p_a2agy = Functions.belowten' g_a2agx
                            (g_a2agx, gpart_a2aiJ) = Genome.Split.split gpart_a2aiI
                            p_a2agw = double g_a2agv
                            (g_a2agv, gpart_a2aiI) = Genome.Split.split gpart_a2aiH
                            p_a2agu = Functions.belowten' g_a2agt
                            (g_a2agt, gpart_a2aiH) = Genome.Split.split gpart_a2aiG
                            p_a2ags = double g_a2agr
                            (g_a2agr, gpart_a2aiG) = Genome.Split.split gpart_a2aiF
                            p_a2agq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agp
                            (g_a2agp, gpart_a2aiF) = Genome.Split.split gpart_a2aiE
                            p_a2ago
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2agn
                            (g_a2agn, gpart_a2aiE) = Genome.Split.split gpart_a2aiD
                            p_a2agm = double g_a2agl
                            (g_a2agl, gpart_a2aiD) = Genome.Split.split gpart_a2aiC
                            p_a2agk = Functions.belowten' g_a2agj
                            (g_a2agj, gpart_a2aiC) = Genome.Split.split gpart_a2aiB
                            p_a2agi = double g_a2agh
                            (g_a2agh, gpart_a2aiB) = Genome.Split.split gpart_a2aiA
                            p_a2agg = Functions.belowten' g_a2agf
                            (g_a2agf, gpart_a2aiA) = Genome.Split.split gpart_a2aiz
                            p_a2age = double g_a2agd
                            (g_a2agd, gpart_a2aiz) = Genome.Split.split gpart_a2aiy
                            p_a2agc = double g_a2agb
                            (g_a2agb, gpart_a2aiy) = Genome.Split.split gpart_a2aix
                            p_a2aga = double g_a2ag9
                            (g_a2ag9, gpart_a2aix) = Genome.Split.split gpart_a2aiw
                            p_a2ag8 = Functions.belowten' g_a2ag7
                            (g_a2ag7, gpart_a2aiw) = Genome.Split.split gpart_a2aiv
                            p_a2ag6 = double g_a2ag5
                            (g_a2ag5, gpart_a2aiv) = Genome.Split.split gpart_a2aiu
                            p_a2ag4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ag3
                            (g_a2ag3, gpart_a2aiu) = Genome.Split.split gpart_a2ait
                            p_a2ag2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ag1
                            (g_a2ag1, gpart_a2ait) = Genome.Split.split gpart_a2ais
                            p_a2ag0 = Functions.belowten' g_a2afZ
                            (g_a2afZ, gpart_a2ais) = Genome.Split.split gpart_a2air
                            p_a2afY = double g_a2afX
                            (g_a2afX, gpart_a2air) = Genome.Split.split gpart_a2aiq
                            p_a2afW = double g_a2afV
                            (g_a2afV, gpart_a2aiq) = Genome.Split.split gpart_a2aip
                            p_a2afU = double g_a2afT
                            (g_a2afT, gpart_a2aip) = Genome.Split.split gpart_a2aio
                            p_a2afS = double g_a2afR
                            (g_a2afR, gpart_a2aio) = Genome.Split.split gpart_a2ain
                            p_a2afQ = double g_a2afP
                            (g_a2afP, gpart_a2ain) = Genome.Split.split gpart_a2aim
                            p_a2afO = double g_a2afN
                            (g_a2afN, gpart_a2aim) = Genome.Split.split genome_a2ahd
                          in
                            \ desc_a2ahe
                              -> case desc_a2ahe of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afW)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2afY)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ag0)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ag2)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ag4)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ag6)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ag8)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aga)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agc)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2age)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agg)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agi)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agk)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agm)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ago)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agq)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ags)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agw)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agy)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agE)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agG)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agI)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agS)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agU)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2agY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ah0)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ah2)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ah4)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ah6)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ah8)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aha)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ahc)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a2alD
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2amm
                      p_a2alC = double g_a2alB
                      (g_a2alB, gpart_a2amm) = Genome.Split.split gpart_a2aml
                      p_a2alA = double g_a2alz
                      (g_a2alz, gpart_a2aml) = Genome.Split.split gpart_a2amk
                      p_a2aly = double g_a2alx
                      (g_a2alx, gpart_a2amk) = Genome.Split.split gpart_a2amj
                      p_a2alw = double g_a2alv
                      (g_a2alv, gpart_a2amj) = Genome.Split.split gpart_a2ami
                      p_a2alu = double g_a2alt
                      (g_a2alt, gpart_a2ami) = Genome.Split.split gpart_a2amh
                      p_a2als = double g_a2alr
                      (g_a2alr, gpart_a2amh) = Genome.Split.split gpart_a2amg
                      p_a2alq = Functions.belowten' g_a2alp
                      (g_a2alp, gpart_a2amg) = Genome.Split.split gpart_a2amf
                      p_a2alo = double g_a2aln
                      (g_a2aln, gpart_a2amf) = Genome.Split.split gpart_a2ame
                      p_a2alm = Functions.belowten' g_a2all
                      (g_a2all, gpart_a2ame) = Genome.Split.split gpart_a2amd
                      p_a2alk = double g_a2alj
                      (g_a2alj, gpart_a2amd) = Genome.Split.split gpart_a2amc
                      p_a2ali = double g_a2alh
                      (g_a2alh, gpart_a2amc) = Genome.Split.split gpart_a2amb
                      p_a2alg = double g_a2alf
                      (g_a2alf, gpart_a2amb) = Genome.Split.split gpart_a2ama
                      p_a2ale = Functions.belowten' g_a2ald
                      (g_a2ald, gpart_a2ama) = Genome.Split.split gpart_a2am9
                      p_a2alc = double g_a2alb
                      (g_a2alb, gpart_a2am9) = Genome.Split.split gpart_a2am8
                      p_a2ala
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2al9
                      (g_a2al9, gpart_a2am8) = Genome.Split.split gpart_a2am7
                      p_a2al8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2al7
                      (g_a2al7, gpart_a2am7) = Genome.Split.split gpart_a2am6
                      p_a2al6 = Functions.belowten' g_a2al5
                      (g_a2al5, gpart_a2am6) = Genome.Split.split gpart_a2am5
                      p_a2al4 = double g_a2al3
                      (g_a2al3, gpart_a2am5) = Genome.Split.split gpart_a2am4
                      p_a2al2 = double g_a2al1
                      (g_a2al1, gpart_a2am4) = Genome.Split.split gpart_a2am3
                      p_a2al0 = double g_a2akZ
                      (g_a2akZ, gpart_a2am3) = Genome.Split.split gpart_a2am2
                      p_a2akY = Functions.belowten' g_a2akX
                      (g_a2akX, gpart_a2am2) = Genome.Split.split gpart_a2am1
                      p_a2akW = double g_a2akV
                      (g_a2akV, gpart_a2am1) = Genome.Split.split gpart_a2am0
                      p_a2akU = Functions.belowten' g_a2akT
                      (g_a2akT, gpart_a2am0) = Genome.Split.split gpart_a2alZ
                      p_a2akS = double g_a2akR
                      (g_a2akR, gpart_a2alZ) = Genome.Split.split gpart_a2alY
                      p_a2akQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akP
                      (g_a2akP, gpart_a2alY) = Genome.Split.split gpart_a2alX
                      p_a2akO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akN
                      (g_a2akN, gpart_a2alX) = Genome.Split.split gpart_a2alW
                      p_a2akM = double g_a2akL
                      (g_a2akL, gpart_a2alW) = Genome.Split.split gpart_a2alV
                      p_a2akK = Functions.belowten' g_a2akJ
                      (g_a2akJ, gpart_a2alV) = Genome.Split.split gpart_a2alU
                      p_a2akI = double g_a2akH
                      (g_a2akH, gpart_a2alU) = Genome.Split.split gpart_a2alT
                      p_a2akG = Functions.belowten' g_a2akF
                      (g_a2akF, gpart_a2alT) = Genome.Split.split gpart_a2alS
                      p_a2akE = double g_a2akD
                      (g_a2akD, gpart_a2alS) = Genome.Split.split gpart_a2alR
                      p_a2akC = double g_a2akB
                      (g_a2akB, gpart_a2alR) = Genome.Split.split gpart_a2alQ
                      p_a2akA = double g_a2akz
                      (g_a2akz, gpart_a2alQ) = Genome.Split.split gpart_a2alP
                      p_a2aky = Functions.belowten' g_a2akx
                      (g_a2akx, gpart_a2alP) = Genome.Split.split gpart_a2alO
                      p_a2akw = double g_a2akv
                      (g_a2akv, gpart_a2alO) = Genome.Split.split gpart_a2alN
                      p_a2aku
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akt
                      (g_a2akt, gpart_a2alN) = Genome.Split.split gpart_a2alM
                      p_a2aks
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akr
                      (g_a2akr, gpart_a2alM) = Genome.Split.split gpart_a2alL
                      p_a2akq = Functions.belowten' g_a2akp
                      (g_a2akp, gpart_a2alL) = Genome.Split.split gpart_a2alK
                      p_a2ako = double g_a2akn
                      (g_a2akn, gpart_a2alK) = Genome.Split.split gpart_a2alJ
                      p_a2akm = double g_a2akl
                      (g_a2akl, gpart_a2alJ) = Genome.Split.split gpart_a2alI
                      p_a2akk = double g_a2akj
                      (g_a2akj, gpart_a2alI) = Genome.Split.split gpart_a2alH
                      p_a2aki = double g_a2akh
                      (g_a2akh, gpart_a2alH) = Genome.Split.split gpart_a2alG
                      p_a2akg = double g_a2akf
                      (g_a2akf, gpart_a2alG) = Genome.Split.split gpart_a2alF
                      p_a2ake = double g_a2akd
                      (g_a2akd, gpart_a2alF) = Genome.Split.split genome_a2alD
                    in  \ x_a2amn
                          -> let
                               c_PTB_a2ams
                                 = ((Data.Fixed.Vector.toVector x_a2amn) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2amq
                                 = ((Data.Fixed.Vector.toVector x_a2amn) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2amo
                                 = ((Data.Fixed.Vector.toVector x_a2amn) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2amz
                                 = ((Data.Fixed.Vector.toVector x_a2amn) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2amL
                                 = ((Data.Fixed.Vector.toVector x_a2amn) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2akm
                                     * ((p_a2akA + ((c_NPTB_a2amo / p_a2ako) ** p_a2akq))
                                        / (((1 + p_a2akA) + ((c_NPTB_a2amo / p_a2ako) ** p_a2akq))
                                           + ((c_MiRs_a2amq / p_a2akw) ** p_a2aky))))
                                    + (negate (p_a2alu * c_PTB_a2ams))),
                                   ((p_a2akC
                                     / (1
                                        + (((c_MiRs_a2amq / p_a2akE) ** p_a2akG)
                                           + ((c_PTB_a2ams / p_a2akI) ** p_a2akK))))
                                    + (negate (p_a2alw * c_NPTB_a2amo))),
                                   ((p_a2akM
                                     * ((p_a2al0 + ((c_NPTB_a2amo / p_a2akS) ** p_a2akU))
                                        / (((1 + p_a2al0) + ((c_NPTB_a2amo / p_a2akS) ** p_a2akU))
                                           + ((c_RESTc_a2amz / p_a2akW) ** p_a2akY))))
                                    + (negate (p_a2aly * c_MiRs_a2amq))),
                                   ((p_a2al2
                                     * ((p_a2alg + ((c_PTB_a2ams / p_a2al4) ** p_a2al6))
                                        / (((1 + p_a2alg) + ((c_PTB_a2ams / p_a2al4) ** p_a2al6))
                                           + (((p_a2ake / p_a2al8) ** p_a2ala)
                                              + ((c_MiRs_a2amq / p_a2alc) ** p_a2ale)))))
                                    + (negate (p_a2alA * c_RESTc_a2amz))),
                                   ((p_a2ali
                                     * ((p_a2als + ((c_MiRs_a2amq / p_a2alk) ** p_a2alm))
                                        / (((1 + p_a2als) + ((c_MiRs_a2amq / p_a2alk) ** p_a2alm))
                                           + ((c_RESTc_a2amz / p_a2alo) ** p_a2alq))))
                                    + (negate (p_a2alC * c_EndoNeuroTFs_a2amL)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526156",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526158",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526178",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526180",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526198",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526200",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2alD
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2ant
                            p_a2alC = double g_a2alB
                            (g_a2alB, gpart_a2ant) = Genome.Split.split gpart_a2ans
                            p_a2alA = double g_a2alz
                            (g_a2alz, gpart_a2ans) = Genome.Split.split gpart_a2anr
                            p_a2aly = double g_a2alx
                            (g_a2alx, gpart_a2anr) = Genome.Split.split gpart_a2anq
                            p_a2alw = double g_a2alv
                            (g_a2alv, gpart_a2anq) = Genome.Split.split gpart_a2anp
                            p_a2alu = double g_a2alt
                            (g_a2alt, gpart_a2anp) = Genome.Split.split gpart_a2ano
                            p_a2als = double g_a2alr
                            (g_a2alr, gpart_a2ano) = Genome.Split.split gpart_a2ann
                            p_a2alq = Functions.belowten' g_a2alp
                            (g_a2alp, gpart_a2ann) = Genome.Split.split gpart_a2anm
                            p_a2alo = double g_a2aln
                            (g_a2aln, gpart_a2anm) = Genome.Split.split gpart_a2anl
                            p_a2alm = Functions.belowten' g_a2all
                            (g_a2all, gpart_a2anl) = Genome.Split.split gpart_a2ank
                            p_a2alk = double g_a2alj
                            (g_a2alj, gpart_a2ank) = Genome.Split.split gpart_a2anj
                            p_a2ali = double g_a2alh
                            (g_a2alh, gpart_a2anj) = Genome.Split.split gpart_a2ani
                            p_a2alg = double g_a2alf
                            (g_a2alf, gpart_a2ani) = Genome.Split.split gpart_a2anh
                            p_a2ale = Functions.belowten' g_a2ald
                            (g_a2ald, gpart_a2anh) = Genome.Split.split gpart_a2ang
                            p_a2alc = double g_a2alb
                            (g_a2alb, gpart_a2ang) = Genome.Split.split gpart_a2anf
                            p_a2ala
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2al9
                            (g_a2al9, gpart_a2anf) = Genome.Split.split gpart_a2ane
                            p_a2al8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2al7
                            (g_a2al7, gpart_a2ane) = Genome.Split.split gpart_a2and
                            p_a2al6 = Functions.belowten' g_a2al5
                            (g_a2al5, gpart_a2and) = Genome.Split.split gpart_a2anc
                            p_a2al4 = double g_a2al3
                            (g_a2al3, gpart_a2anc) = Genome.Split.split gpart_a2anb
                            p_a2al2 = double g_a2al1
                            (g_a2al1, gpart_a2anb) = Genome.Split.split gpart_a2ana
                            p_a2al0 = double g_a2akZ
                            (g_a2akZ, gpart_a2ana) = Genome.Split.split gpart_a2an9
                            p_a2akY = Functions.belowten' g_a2akX
                            (g_a2akX, gpart_a2an9) = Genome.Split.split gpart_a2an8
                            p_a2akW = double g_a2akV
                            (g_a2akV, gpart_a2an8) = Genome.Split.split gpart_a2an7
                            p_a2akU = Functions.belowten' g_a2akT
                            (g_a2akT, gpart_a2an7) = Genome.Split.split gpart_a2an6
                            p_a2akS = double g_a2akR
                            (g_a2akR, gpart_a2an6) = Genome.Split.split gpart_a2an5
                            p_a2akQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akP
                            (g_a2akP, gpart_a2an5) = Genome.Split.split gpart_a2an4
                            p_a2akO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akN
                            (g_a2akN, gpart_a2an4) = Genome.Split.split gpart_a2an3
                            p_a2akM = double g_a2akL
                            (g_a2akL, gpart_a2an3) = Genome.Split.split gpart_a2an2
                            p_a2akK = Functions.belowten' g_a2akJ
                            (g_a2akJ, gpart_a2an2) = Genome.Split.split gpart_a2an1
                            p_a2akI = double g_a2akH
                            (g_a2akH, gpart_a2an1) = Genome.Split.split gpart_a2an0
                            p_a2akG = Functions.belowten' g_a2akF
                            (g_a2akF, gpart_a2an0) = Genome.Split.split gpart_a2amZ
                            p_a2akE = double g_a2akD
                            (g_a2akD, gpart_a2amZ) = Genome.Split.split gpart_a2amY
                            p_a2akC = double g_a2akB
                            (g_a2akB, gpart_a2amY) = Genome.Split.split gpart_a2amX
                            p_a2akA = double g_a2akz
                            (g_a2akz, gpart_a2amX) = Genome.Split.split gpart_a2amW
                            p_a2aky = Functions.belowten' g_a2akx
                            (g_a2akx, gpart_a2amW) = Genome.Split.split gpart_a2amV
                            p_a2akw = double g_a2akv
                            (g_a2akv, gpart_a2amV) = Genome.Split.split gpart_a2amU
                            p_a2aku
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akt
                            (g_a2akt, gpart_a2amU) = Genome.Split.split gpart_a2amT
                            p_a2aks
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2akr
                            (g_a2akr, gpart_a2amT) = Genome.Split.split gpart_a2amS
                            p_a2akq = Functions.belowten' g_a2akp
                            (g_a2akp, gpart_a2amS) = Genome.Split.split gpart_a2amR
                            p_a2ako = double g_a2akn
                            (g_a2akn, gpart_a2amR) = Genome.Split.split gpart_a2amQ
                            p_a2akm = double g_a2akl
                            (g_a2akl, gpart_a2amQ) = Genome.Split.split gpart_a2amP
                            p_a2akk = double g_a2akj
                            (g_a2akj, gpart_a2amP) = Genome.Split.split gpart_a2amO
                            p_a2aki = double g_a2akh
                            (g_a2akh, gpart_a2amO) = Genome.Split.split gpart_a2amN
                            p_a2akg = double g_a2akf
                            (g_a2akf, gpart_a2amN) = Genome.Split.split gpart_a2amM
                            p_a2ake = double g_a2akd
                            (g_a2akd, gpart_a2amM) = Genome.Split.split genome_a2alD
                          in
                            \ desc_a2alE
                              -> case desc_a2alE of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ake)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akg)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aki)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akk)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akm)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ako)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akq)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aks)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aku)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akw)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aky)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akA)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akC)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akE)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akG)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akI)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akK)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akM)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akO)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akQ)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akS)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akU)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akW)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2akY)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2al0)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2al2)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2al4)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2al6)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2al8)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ala)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alc)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ale)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alg)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ali)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alk)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alm)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alo)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alq)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2als)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alu)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alw)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aly)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alA)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2alC)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a2aq3
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2aqM
                      p_a2aq2 = double g_a2aq1
                      (g_a2aq1, gpart_a2aqM) = Genome.Split.split gpart_a2aqL
                      p_a2aq0 = double g_a2apZ
                      (g_a2apZ, gpart_a2aqL) = Genome.Split.split gpart_a2aqK
                      p_a2apY = double g_a2apX
                      (g_a2apX, gpart_a2aqK) = Genome.Split.split gpart_a2aqJ
                      p_a2apW = double g_a2apV
                      (g_a2apV, gpart_a2aqJ) = Genome.Split.split gpart_a2aqI
                      p_a2apU = double g_a2apT
                      (g_a2apT, gpart_a2aqI) = Genome.Split.split gpart_a2aqH
                      p_a2apS = double g_a2apR
                      (g_a2apR, gpart_a2aqH) = Genome.Split.split gpart_a2aqG
                      p_a2apQ = Functions.belowten' g_a2apP
                      (g_a2apP, gpart_a2aqG) = Genome.Split.split gpart_a2aqF
                      p_a2apO = double g_a2apN
                      (g_a2apN, gpart_a2aqF) = Genome.Split.split gpart_a2aqE
                      p_a2apM = Functions.belowten' g_a2apL
                      (g_a2apL, gpart_a2aqE) = Genome.Split.split gpart_a2aqD
                      p_a2apK = double g_a2apJ
                      (g_a2apJ, gpart_a2aqD) = Genome.Split.split gpart_a2aqC
                      p_a2apI = double g_a2apH
                      (g_a2apH, gpart_a2aqC) = Genome.Split.split gpart_a2aqB
                      p_a2apG = double g_a2apF
                      (g_a2apF, gpart_a2aqB) = Genome.Split.split gpart_a2aqA
                      p_a2apE = Functions.belowten' g_a2apD
                      (g_a2apD, gpart_a2aqA) = Genome.Split.split gpart_a2aqz
                      p_a2apC = double g_a2apB
                      (g_a2apB, gpart_a2aqz) = Genome.Split.split gpart_a2aqy
                      p_a2apA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apz
                      (g_a2apz, gpart_a2aqy) = Genome.Split.split gpart_a2aqx
                      p_a2apy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apx
                      (g_a2apx, gpart_a2aqx) = Genome.Split.split gpart_a2aqw
                      p_a2apw = Functions.belowten' g_a2apv
                      (g_a2apv, gpart_a2aqw) = Genome.Split.split gpart_a2aqv
                      p_a2apu = double g_a2apt
                      (g_a2apt, gpart_a2aqv) = Genome.Split.split gpart_a2aqu
                      p_a2aps = double g_a2apr
                      (g_a2apr, gpart_a2aqu) = Genome.Split.split gpart_a2aqt
                      p_a2apq = double g_a2app
                      (g_a2app, gpart_a2aqt) = Genome.Split.split gpart_a2aqs
                      p_a2apo = Functions.belowten' g_a2apn
                      (g_a2apn, gpart_a2aqs) = Genome.Split.split gpart_a2aqr
                      p_a2apm = double g_a2apl
                      (g_a2apl, gpart_a2aqr) = Genome.Split.split gpart_a2aqq
                      p_a2apk = Functions.belowten' g_a2apj
                      (g_a2apj, gpart_a2aqq) = Genome.Split.split gpart_a2aqp
                      p_a2api = double g_a2aph
                      (g_a2aph, gpart_a2aqp) = Genome.Split.split gpart_a2aqo
                      p_a2apg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apf
                      (g_a2apf, gpart_a2aqo) = Genome.Split.split gpart_a2aqn
                      p_a2ape
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apd
                      (g_a2apd, gpart_a2aqn) = Genome.Split.split gpart_a2aqm
                      p_a2apc = double g_a2apb
                      (g_a2apb, gpart_a2aqm) = Genome.Split.split gpart_a2aql
                      p_a2apa = Functions.belowten' g_a2ap9
                      (g_a2ap9, gpart_a2aql) = Genome.Split.split gpart_a2aqk
                      p_a2ap8 = double g_a2ap7
                      (g_a2ap7, gpart_a2aqk) = Genome.Split.split gpart_a2aqj
                      p_a2ap6 = Functions.belowten' g_a2ap5
                      (g_a2ap5, gpart_a2aqj) = Genome.Split.split gpart_a2aqi
                      p_a2ap4 = double g_a2ap3
                      (g_a2ap3, gpart_a2aqi) = Genome.Split.split gpart_a2aqh
                      p_a2ap2 = double g_a2ap1
                      (g_a2ap1, gpart_a2aqh) = Genome.Split.split gpart_a2aqg
                      p_a2ap0 = double g_a2aoZ
                      (g_a2aoZ, gpart_a2aqg) = Genome.Split.split gpart_a2aqf
                      p_a2aoY = Functions.belowten' g_a2aoX
                      (g_a2aoX, gpart_a2aqf) = Genome.Split.split gpart_a2aqe
                      p_a2aoW = double g_a2aoV
                      (g_a2aoV, gpart_a2aqe) = Genome.Split.split gpart_a2aqd
                      p_a2aoU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoT
                      (g_a2aoT, gpart_a2aqd) = Genome.Split.split gpart_a2aqc
                      p_a2aoS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoR
                      (g_a2aoR, gpart_a2aqc) = Genome.Split.split gpart_a2aqb
                      p_a2aoQ = Functions.belowten' g_a2aoP
                      (g_a2aoP, gpart_a2aqb) = Genome.Split.split gpart_a2aqa
                      p_a2aoO = double g_a2aoN
                      (g_a2aoN, gpart_a2aqa) = Genome.Split.split gpart_a2aq9
                      p_a2aoM = double g_a2aoL
                      (g_a2aoL, gpart_a2aq9) = Genome.Split.split gpart_a2aq8
                      p_a2aoK = double g_a2aoJ
                      (g_a2aoJ, gpart_a2aq8) = Genome.Split.split gpart_a2aq7
                      p_a2aoI = double g_a2aoH
                      (g_a2aoH, gpart_a2aq7) = Genome.Split.split gpart_a2aq6
                      p_a2aoG = double g_a2aoF
                      (g_a2aoF, gpart_a2aq6) = Genome.Split.split gpart_a2aq5
                      p_a2aoE = double g_a2aoD
                      (g_a2aoD, gpart_a2aq5) = Genome.Split.split genome_a2aq3
                    in  \ x_a2aqN
                          -> let
                               c_PTB_a2aqS
                                 = ((Data.Fixed.Vector.toVector x_a2aqN) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2aqQ
                                 = ((Data.Fixed.Vector.toVector x_a2aqN) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2aqO
                                 = ((Data.Fixed.Vector.toVector x_a2aqN) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2aqZ
                                 = ((Data.Fixed.Vector.toVector x_a2aqN) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2arb
                                 = ((Data.Fixed.Vector.toVector x_a2aqN) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2aoM
                                     * ((p_a2ap0 + ((c_NPTB_a2aqO / p_a2aoO) ** p_a2aoQ))
                                        / (((1 + p_a2ap0) + ((c_NPTB_a2aqO / p_a2aoO) ** p_a2aoQ))
                                           + ((c_MiRs_a2aqQ / p_a2aoW) ** p_a2aoY))))
                                    + (negate (p_a2apU * c_PTB_a2aqS))),
                                   ((p_a2ap2
                                     / (1
                                        + (((c_MiRs_a2aqQ / p_a2ap4) ** p_a2ap6)
                                           + ((c_PTB_a2aqS / p_a2ap8) ** p_a2apa))))
                                    + (negate (p_a2apW * c_NPTB_a2aqO))),
                                   ((p_a2apc
                                     * ((p_a2apq + ((c_NPTB_a2aqO / p_a2api) ** p_a2apk))
                                        / (((1 + p_a2apq) + ((c_NPTB_a2aqO / p_a2api) ** p_a2apk))
                                           + ((c_RESTc_a2aqZ / p_a2apm) ** p_a2apo))))
                                    + (negate (p_a2apY * c_MiRs_a2aqQ))),
                                   ((p_a2aps
                                     * ((p_a2apG + ((c_PTB_a2aqS / p_a2apu) ** p_a2apw))
                                        / (((1 + p_a2apG) + ((c_PTB_a2aqS / p_a2apu) ** p_a2apw))
                                           + ((c_MiRs_a2aqQ / p_a2apC) ** p_a2apE))))
                                    + (negate (p_a2aq0 * c_RESTc_a2aqZ))),
                                   ((p_a2apI
                                     * ((p_a2apS + ((c_MiRs_a2aqQ / p_a2apK) ** p_a2apM))
                                        / (((1 + p_a2apS) + ((c_MiRs_a2aqQ / p_a2apK) ** p_a2apM))
                                           + ((c_RESTc_a2aqZ / p_a2apO) ** p_a2apQ))))
                                    + (negate (p_a2aq2 * c_EndoNeuroTFs_a2arb)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526430",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526432",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526452",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526454",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526472",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526474",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aq3
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2arT
                            p_a2aq2 = double g_a2aq1
                            (g_a2aq1, gpart_a2arT) = Genome.Split.split gpart_a2arS
                            p_a2aq0 = double g_a2apZ
                            (g_a2apZ, gpart_a2arS) = Genome.Split.split gpart_a2arR
                            p_a2apY = double g_a2apX
                            (g_a2apX, gpart_a2arR) = Genome.Split.split gpart_a2arQ
                            p_a2apW = double g_a2apV
                            (g_a2apV, gpart_a2arQ) = Genome.Split.split gpart_a2arP
                            p_a2apU = double g_a2apT
                            (g_a2apT, gpart_a2arP) = Genome.Split.split gpart_a2arO
                            p_a2apS = double g_a2apR
                            (g_a2apR, gpart_a2arO) = Genome.Split.split gpart_a2arN
                            p_a2apQ = Functions.belowten' g_a2apP
                            (g_a2apP, gpart_a2arN) = Genome.Split.split gpart_a2arM
                            p_a2apO = double g_a2apN
                            (g_a2apN, gpart_a2arM) = Genome.Split.split gpart_a2arL
                            p_a2apM = Functions.belowten' g_a2apL
                            (g_a2apL, gpart_a2arL) = Genome.Split.split gpart_a2arK
                            p_a2apK = double g_a2apJ
                            (g_a2apJ, gpart_a2arK) = Genome.Split.split gpart_a2arJ
                            p_a2apI = double g_a2apH
                            (g_a2apH, gpart_a2arJ) = Genome.Split.split gpart_a2arI
                            p_a2apG = double g_a2apF
                            (g_a2apF, gpart_a2arI) = Genome.Split.split gpart_a2arH
                            p_a2apE = Functions.belowten' g_a2apD
                            (g_a2apD, gpart_a2arH) = Genome.Split.split gpart_a2arG
                            p_a2apC = double g_a2apB
                            (g_a2apB, gpart_a2arG) = Genome.Split.split gpart_a2arF
                            p_a2apA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apz
                            (g_a2apz, gpart_a2arF) = Genome.Split.split gpart_a2arE
                            p_a2apy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apx
                            (g_a2apx, gpart_a2arE) = Genome.Split.split gpart_a2arD
                            p_a2apw = Functions.belowten' g_a2apv
                            (g_a2apv, gpart_a2arD) = Genome.Split.split gpart_a2arC
                            p_a2apu = double g_a2apt
                            (g_a2apt, gpart_a2arC) = Genome.Split.split gpart_a2arB
                            p_a2aps = double g_a2apr
                            (g_a2apr, gpart_a2arB) = Genome.Split.split gpart_a2arA
                            p_a2apq = double g_a2app
                            (g_a2app, gpart_a2arA) = Genome.Split.split gpart_a2arz
                            p_a2apo = Functions.belowten' g_a2apn
                            (g_a2apn, gpart_a2arz) = Genome.Split.split gpart_a2ary
                            p_a2apm = double g_a2apl
                            (g_a2apl, gpart_a2ary) = Genome.Split.split gpart_a2arx
                            p_a2apk = Functions.belowten' g_a2apj
                            (g_a2apj, gpart_a2arx) = Genome.Split.split gpart_a2arw
                            p_a2api = double g_a2aph
                            (g_a2aph, gpart_a2arw) = Genome.Split.split gpart_a2arv
                            p_a2apg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apf
                            (g_a2apf, gpart_a2arv) = Genome.Split.split gpart_a2aru
                            p_a2ape
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2apd
                            (g_a2apd, gpart_a2aru) = Genome.Split.split gpart_a2art
                            p_a2apc = double g_a2apb
                            (g_a2apb, gpart_a2art) = Genome.Split.split gpart_a2ars
                            p_a2apa = Functions.belowten' g_a2ap9
                            (g_a2ap9, gpart_a2ars) = Genome.Split.split gpart_a2arr
                            p_a2ap8 = double g_a2ap7
                            (g_a2ap7, gpart_a2arr) = Genome.Split.split gpart_a2arq
                            p_a2ap6 = Functions.belowten' g_a2ap5
                            (g_a2ap5, gpart_a2arq) = Genome.Split.split gpart_a2arp
                            p_a2ap4 = double g_a2ap3
                            (g_a2ap3, gpart_a2arp) = Genome.Split.split gpart_a2aro
                            p_a2ap2 = double g_a2ap1
                            (g_a2ap1, gpart_a2aro) = Genome.Split.split gpart_a2arn
                            p_a2ap0 = double g_a2aoZ
                            (g_a2aoZ, gpart_a2arn) = Genome.Split.split gpart_a2arm
                            p_a2aoY = Functions.belowten' g_a2aoX
                            (g_a2aoX, gpart_a2arm) = Genome.Split.split gpart_a2arl
                            p_a2aoW = double g_a2aoV
                            (g_a2aoV, gpart_a2arl) = Genome.Split.split gpart_a2ark
                            p_a2aoU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoT
                            (g_a2aoT, gpart_a2ark) = Genome.Split.split gpart_a2arj
                            p_a2aoS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2aoR
                            (g_a2aoR, gpart_a2arj) = Genome.Split.split gpart_a2ari
                            p_a2aoQ = Functions.belowten' g_a2aoP
                            (g_a2aoP, gpart_a2ari) = Genome.Split.split gpart_a2arh
                            p_a2aoO = double g_a2aoN
                            (g_a2aoN, gpart_a2arh) = Genome.Split.split gpart_a2arg
                            p_a2aoM = double g_a2aoL
                            (g_a2aoL, gpart_a2arg) = Genome.Split.split gpart_a2arf
                            p_a2aoK = double g_a2aoJ
                            (g_a2aoJ, gpart_a2arf) = Genome.Split.split gpart_a2are
                            p_a2aoI = double g_a2aoH
                            (g_a2aoH, gpart_a2are) = Genome.Split.split gpart_a2ard
                            p_a2aoG = double g_a2aoF
                            (g_a2aoF, gpart_a2ard) = Genome.Split.split gpart_a2arc
                            p_a2aoE = double g_a2aoD
                            (g_a2aoD, gpart_a2arc) = Genome.Split.split genome_a2aq3
                          in
                            \ desc_a2aq4
                              -> case desc_a2aq4 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoE)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoG)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoI)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoK)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoM)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoO)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoQ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoS)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoU)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoW)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aoY)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ap0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ap2)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ap4)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ap6)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ap8)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apa)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apc)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ape)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apg)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2api)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apk)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apm)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apo)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apq)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aps)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apu)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apw)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apy)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apA)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apC)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apE)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apG)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apI)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apK)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apM)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apO)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apQ)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apS)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apU)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apW)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2apY)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq0)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aq2)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a2aut
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2avc
                      p_a2aus = double g_a2aur
                      (g_a2aur, gpart_a2avc) = Genome.Split.split gpart_a2avb
                      p_a2auq = double g_a2aup
                      (g_a2aup, gpart_a2avb) = Genome.Split.split gpart_a2ava
                      p_a2auo = double g_a2aun
                      (g_a2aun, gpart_a2ava) = Genome.Split.split gpart_a2av9
                      p_a2aum = double g_a2aul
                      (g_a2aul, gpart_a2av9) = Genome.Split.split gpart_a2av8
                      p_a2auk = double g_a2auj
                      (g_a2auj, gpart_a2av8) = Genome.Split.split gpart_a2av7
                      p_a2aui = double g_a2auh
                      (g_a2auh, gpart_a2av7) = Genome.Split.split gpart_a2av6
                      p_a2aug = Functions.belowten' g_a2auf
                      (g_a2auf, gpart_a2av6) = Genome.Split.split gpart_a2av5
                      p_a2aue = double g_a2aud
                      (g_a2aud, gpart_a2av5) = Genome.Split.split gpart_a2av4
                      p_a2auc = Functions.belowten' g_a2aub
                      (g_a2aub, gpart_a2av4) = Genome.Split.split gpart_a2av3
                      p_a2aua = double g_a2au9
                      (g_a2au9, gpart_a2av3) = Genome.Split.split gpart_a2av2
                      p_a2au8 = double g_a2au7
                      (g_a2au7, gpart_a2av2) = Genome.Split.split gpart_a2av1
                      p_a2au6 = double g_a2au5
                      (g_a2au5, gpart_a2av1) = Genome.Split.split gpart_a2av0
                      p_a2au4 = Functions.belowten' g_a2au3
                      (g_a2au3, gpart_a2av0) = Genome.Split.split gpart_a2auZ
                      p_a2au2 = double g_a2au1
                      (g_a2au1, gpart_a2auZ) = Genome.Split.split gpart_a2auY
                      p_a2au0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atZ
                      (g_a2atZ, gpart_a2auY) = Genome.Split.split gpart_a2auX
                      p_a2atY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atX
                      (g_a2atX, gpart_a2auX) = Genome.Split.split gpart_a2auW
                      p_a2atW = Functions.belowten' g_a2atV
                      (g_a2atV, gpart_a2auW) = Genome.Split.split gpart_a2auV
                      p_a2atU = double g_a2atT
                      (g_a2atT, gpart_a2auV) = Genome.Split.split gpart_a2auU
                      p_a2atS = double g_a2atR
                      (g_a2atR, gpart_a2auU) = Genome.Split.split gpart_a2auT
                      p_a2atQ = double g_a2atP
                      (g_a2atP, gpart_a2auT) = Genome.Split.split gpart_a2auS
                      p_a2atO = Functions.belowten' g_a2atN
                      (g_a2atN, gpart_a2auS) = Genome.Split.split gpart_a2auR
                      p_a2atM = double g_a2atL
                      (g_a2atL, gpart_a2auR) = Genome.Split.split gpart_a2auQ
                      p_a2atK = Functions.belowten' g_a2atJ
                      (g_a2atJ, gpart_a2auQ) = Genome.Split.split gpart_a2auP
                      p_a2atI = double g_a2atH
                      (g_a2atH, gpart_a2auP) = Genome.Split.split gpart_a2auO
                      p_a2atG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atF
                      (g_a2atF, gpart_a2auO) = Genome.Split.split gpart_a2auN
                      p_a2atE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atD
                      (g_a2atD, gpart_a2auN) = Genome.Split.split gpart_a2auM
                      p_a2atC = double g_a2atB
                      (g_a2atB, gpart_a2auM) = Genome.Split.split gpart_a2auL
                      p_a2atA = Functions.belowten' g_a2atz
                      (g_a2atz, gpart_a2auL) = Genome.Split.split gpart_a2auK
                      p_a2aty = double g_a2atx
                      (g_a2atx, gpart_a2auK) = Genome.Split.split gpart_a2auJ
                      p_a2atw = Functions.belowten' g_a2atv
                      (g_a2atv, gpart_a2auJ) = Genome.Split.split gpart_a2auI
                      p_a2atu = double g_a2att
                      (g_a2att, gpart_a2auI) = Genome.Split.split gpart_a2auH
                      p_a2ats = double g_a2atr
                      (g_a2atr, gpart_a2auH) = Genome.Split.split gpart_a2auG
                      p_a2atq = double g_a2atp
                      (g_a2atp, gpart_a2auG) = Genome.Split.split gpart_a2auF
                      p_a2ato = Functions.belowten' g_a2atn
                      (g_a2atn, gpart_a2auF) = Genome.Split.split gpart_a2auE
                      p_a2atm = double g_a2atl
                      (g_a2atl, gpart_a2auE) = Genome.Split.split gpart_a2auD
                      p_a2atk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atj
                      (g_a2atj, gpart_a2auD) = Genome.Split.split gpart_a2auC
                      p_a2ati
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ath
                      (g_a2ath, gpart_a2auC) = Genome.Split.split gpart_a2auB
                      p_a2atg = Functions.belowten' g_a2atf
                      (g_a2atf, gpart_a2auB) = Genome.Split.split gpart_a2auA
                      p_a2ate = double g_a2atd
                      (g_a2atd, gpart_a2auA) = Genome.Split.split gpart_a2auz
                      p_a2atc = double g_a2atb
                      (g_a2atb, gpart_a2auz) = Genome.Split.split gpart_a2auy
                      p_a2ata = double g_a2at9
                      (g_a2at9, gpart_a2auy) = Genome.Split.split gpart_a2aux
                      p_a2at8 = double g_a2at7
                      (g_a2at7, gpart_a2aux) = Genome.Split.split gpart_a2auw
                      p_a2at6 = double g_a2at5
                      (g_a2at5, gpart_a2auw) = Genome.Split.split gpart_a2auv
                      p_a2at4 = double g_a2at3
                      (g_a2at3, gpart_a2auv) = Genome.Split.split genome_a2aut
                    in  \ x_a2avd
                          -> let
                               c_PTB_a2avi
                                 = ((Data.Fixed.Vector.toVector x_a2avd) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2avg
                                 = ((Data.Fixed.Vector.toVector x_a2avd) Data.Vector.Unboxed.! 2)
                               c_NPTB_a2ave
                                 = ((Data.Fixed.Vector.toVector x_a2avd) Data.Vector.Unboxed.! 1)
                               c_RESTc_a2avp
                                 = ((Data.Fixed.Vector.toVector x_a2avd) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2avB
                                 = ((Data.Fixed.Vector.toVector x_a2avd) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a2atc
                                     * ((p_a2atq + ((c_NPTB_a2ave / p_a2ate) ** p_a2atg))
                                        / (((1 + p_a2atq) + ((c_NPTB_a2ave / p_a2ate) ** p_a2atg))
                                           + (((p_a2at4 / p_a2ati) ** p_a2atk)
                                              + ((c_MiRs_a2avg / p_a2atm) ** p_a2ato)))))
                                    + (negate (p_a2auk * c_PTB_a2avi))),
                                   ((p_a2ats
                                     / (1
                                        + (((c_MiRs_a2avg / p_a2atu) ** p_a2atw)
                                           + ((c_PTB_a2avi / p_a2aty) ** p_a2atA))))
                                    + (negate (p_a2aum * c_NPTB_a2ave))),
                                   ((p_a2atC
                                     * ((p_a2atQ + ((c_NPTB_a2ave / p_a2atI) ** p_a2atK))
                                        / (((1 + p_a2atQ) + ((c_NPTB_a2ave / p_a2atI) ** p_a2atK))
                                           + ((c_RESTc_a2avp / p_a2atM) ** p_a2atO))))
                                    + (negate (p_a2auo * c_MiRs_a2avg))),
                                   ((p_a2atS
                                     * ((p_a2au6 + ((c_PTB_a2avi / p_a2atU) ** p_a2atW))
                                        / (((1 + p_a2au6) + ((c_PTB_a2avi / p_a2atU) ** p_a2atW))
                                           + ((c_MiRs_a2avg / p_a2au2) ** p_a2au4))))
                                    + (negate (p_a2auq * c_RESTc_a2avp))),
                                   ((p_a2au8
                                     * ((p_a2aui + ((c_MiRs_a2avg / p_a2aua) ** p_a2auc))
                                        / (((1 + p_a2aui) + ((c_MiRs_a2avg / p_a2aua) ** p_a2auc))
                                           + ((c_RESTc_a2avp / p_a2aue) ** p_a2aug))))
                                    + (negate (p_a2aus * c_EndoNeuroTFs_a2avB)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526704",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526706",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526726",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526728",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526746",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526748",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679526775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679526776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a2aut
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2awj
                            p_a2aus = double g_a2aur
                            (g_a2aur, gpart_a2awj) = Genome.Split.split gpart_a2awi
                            p_a2auq = double g_a2aup
                            (g_a2aup, gpart_a2awi) = Genome.Split.split gpart_a2awh
                            p_a2auo = double g_a2aun
                            (g_a2aun, gpart_a2awh) = Genome.Split.split gpart_a2awg
                            p_a2aum = double g_a2aul
                            (g_a2aul, gpart_a2awg) = Genome.Split.split gpart_a2awf
                            p_a2auk = double g_a2auj
                            (g_a2auj, gpart_a2awf) = Genome.Split.split gpart_a2awe
                            p_a2aui = double g_a2auh
                            (g_a2auh, gpart_a2awe) = Genome.Split.split gpart_a2awd
                            p_a2aug = Functions.belowten' g_a2auf
                            (g_a2auf, gpart_a2awd) = Genome.Split.split gpart_a2awc
                            p_a2aue = double g_a2aud
                            (g_a2aud, gpart_a2awc) = Genome.Split.split gpart_a2awb
                            p_a2auc = Functions.belowten' g_a2aub
                            (g_a2aub, gpart_a2awb) = Genome.Split.split gpart_a2awa
                            p_a2aua = double g_a2au9
                            (g_a2au9, gpart_a2awa) = Genome.Split.split gpart_a2aw9
                            p_a2au8 = double g_a2au7
                            (g_a2au7, gpart_a2aw9) = Genome.Split.split gpart_a2aw8
                            p_a2au6 = double g_a2au5
                            (g_a2au5, gpart_a2aw8) = Genome.Split.split gpart_a2aw7
                            p_a2au4 = Functions.belowten' g_a2au3
                            (g_a2au3, gpart_a2aw7) = Genome.Split.split gpart_a2aw6
                            p_a2au2 = double g_a2au1
                            (g_a2au1, gpart_a2aw6) = Genome.Split.split gpart_a2aw5
                            p_a2au0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atZ
                            (g_a2atZ, gpart_a2aw5) = Genome.Split.split gpart_a2aw4
                            p_a2atY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atX
                            (g_a2atX, gpart_a2aw4) = Genome.Split.split gpart_a2aw3
                            p_a2atW = Functions.belowten' g_a2atV
                            (g_a2atV, gpart_a2aw3) = Genome.Split.split gpart_a2aw2
                            p_a2atU = double g_a2atT
                            (g_a2atT, gpart_a2aw2) = Genome.Split.split gpart_a2aw1
                            p_a2atS = double g_a2atR
                            (g_a2atR, gpart_a2aw1) = Genome.Split.split gpart_a2aw0
                            p_a2atQ = double g_a2atP
                            (g_a2atP, gpart_a2aw0) = Genome.Split.split gpart_a2avZ
                            p_a2atO = Functions.belowten' g_a2atN
                            (g_a2atN, gpart_a2avZ) = Genome.Split.split gpart_a2avY
                            p_a2atM = double g_a2atL
                            (g_a2atL, gpart_a2avY) = Genome.Split.split gpart_a2avX
                            p_a2atK = Functions.belowten' g_a2atJ
                            (g_a2atJ, gpart_a2avX) = Genome.Split.split gpart_a2avW
                            p_a2atI = double g_a2atH
                            (g_a2atH, gpart_a2avW) = Genome.Split.split gpart_a2avV
                            p_a2atG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atF
                            (g_a2atF, gpart_a2avV) = Genome.Split.split gpart_a2avU
                            p_a2atE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atD
                            (g_a2atD, gpart_a2avU) = Genome.Split.split gpart_a2avT
                            p_a2atC = double g_a2atB
                            (g_a2atB, gpart_a2avT) = Genome.Split.split gpart_a2avS
                            p_a2atA = Functions.belowten' g_a2atz
                            (g_a2atz, gpart_a2avS) = Genome.Split.split gpart_a2avR
                            p_a2aty = double g_a2atx
                            (g_a2atx, gpart_a2avR) = Genome.Split.split gpart_a2avQ
                            p_a2atw = Functions.belowten' g_a2atv
                            (g_a2atv, gpart_a2avQ) = Genome.Split.split gpart_a2avP
                            p_a2atu = double g_a2att
                            (g_a2att, gpart_a2avP) = Genome.Split.split gpart_a2avO
                            p_a2ats = double g_a2atr
                            (g_a2atr, gpart_a2avO) = Genome.Split.split gpart_a2avN
                            p_a2atq = double g_a2atp
                            (g_a2atp, gpart_a2avN) = Genome.Split.split gpart_a2avM
                            p_a2ato = Functions.belowten' g_a2atn
                            (g_a2atn, gpart_a2avM) = Genome.Split.split gpart_a2avL
                            p_a2atm = double g_a2atl
                            (g_a2atl, gpart_a2avL) = Genome.Split.split gpart_a2avK
                            p_a2atk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2atj
                            (g_a2atj, gpart_a2avK) = Genome.Split.split gpart_a2avJ
                            p_a2ati
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2ath
                            (g_a2ath, gpart_a2avJ) = Genome.Split.split gpart_a2avI
                            p_a2atg = Functions.belowten' g_a2atf
                            (g_a2atf, gpart_a2avI) = Genome.Split.split gpart_a2avH
                            p_a2ate = double g_a2atd
                            (g_a2atd, gpart_a2avH) = Genome.Split.split gpart_a2avG
                            p_a2atc = double g_a2atb
                            (g_a2atb, gpart_a2avG) = Genome.Split.split gpart_a2avF
                            p_a2ata = double g_a2at9
                            (g_a2at9, gpart_a2avF) = Genome.Split.split gpart_a2avE
                            p_a2at8 = double g_a2at7
                            (g_a2at7, gpart_a2avE) = Genome.Split.split gpart_a2avD
                            p_a2at6 = double g_a2at5
                            (g_a2at5, gpart_a2avD) = Genome.Split.split gpart_a2avC
                            p_a2at4 = double g_a2at3
                            (g_a2at3, gpart_a2avC) = Genome.Split.split genome_a2aut
                          in
                            \ desc_a2auu
                              -> case desc_a2auu of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2at4)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2at6)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2at8)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ata)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atc)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ate)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atg)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ati)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atk)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atm)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ato)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atq)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2ats)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atu)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atw)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aty)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atG)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atI)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atK)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atM)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atO)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atQ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atS)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atU)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atW)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2atY)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2au0)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2au2)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2au4)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2au6)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2au8)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aua)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auc)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aue)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aug)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aui)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auk)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aum)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auo)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2auq)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2aus)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asWp
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX8
                      p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                      (g_asWn, gpart_asX8) = Genome.Split.split gpart_asX7
                      p_asWm = code-0.1.0.0:Genome.FixedList.Functions.double g_asWl
                      (g_asWl, gpart_asX7) = Genome.Split.split gpart_asX6
                      p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                      (g_asWj, gpart_asX6) = Genome.Split.split gpart_asX5
                      p_asWi = code-0.1.0.0:Genome.FixedList.Functions.double g_asWh
                      (g_asWh, gpart_asX5) = Genome.Split.split gpart_asX4
                      p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                      (g_asWf, gpart_asX4) = Genome.Split.split gpart_asX3
                      p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                      (g_asWd, gpart_asX3) = Genome.Split.split gpart_asX2
                      p_asWc = Functions.belowten' g_asWb
                      (g_asWb, gpart_asX2) = Genome.Split.split gpart_asX1
                      p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                      (g_asW9, gpart_asX1) = Genome.Split.split gpart_asX0
                      p_asW8 = Functions.belowten' g_asW7
                      (g_asW7, gpart_asX0) = Genome.Split.split gpart_asWZ
                      p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                      (g_asW5, gpart_asWZ) = Genome.Split.split gpart_asWY
                      p_asW4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW3
                      (g_asW3, gpart_asWY) = Genome.Split.split gpart_asWX
                      p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                      (g_asW1, gpart_asWX) = Genome.Split.split gpart_asWW
                      p_asW0 = Functions.belowten' g_asVZ
                      (g_asVZ, gpart_asWW) = Genome.Split.split gpart_asWV
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asWV) = Genome.Split.split gpart_asWU
                      p_asVW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVV
                      (g_asVV, gpart_asWU) = Genome.Split.split gpart_asWT
                      p_asVU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVT
                      (g_asVT, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asVS = Functions.belowten' g_asVR
                      (g_asVR, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                      (g_asVP, gpart_asWR) = Genome.Split.split gpart_asWQ
                      p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                      (g_asVN, gpart_asWQ) = Genome.Split.split gpart_asWP
                      p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                      (g_asVL, gpart_asWP) = Genome.Split.split gpart_asWO
                      p_asVK = Functions.belowten' g_asVJ
                      (g_asVJ, gpart_asWO) = Genome.Split.split gpart_asWN
                      p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                      (g_asVH, gpart_asWN) = Genome.Split.split gpart_asWM
                      p_asVG = Functions.belowten' g_asVF
                      (g_asVF, gpart_asWM) = Genome.Split.split gpart_asWL
                      p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                      (g_asVD, gpart_asWL) = Genome.Split.split gpart_asWK
                      p_asVC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVB
                      (g_asVB, gpart_asWK) = Genome.Split.split gpart_asWJ
                      p_asVA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVz
                      (g_asVz, gpart_asWJ) = Genome.Split.split gpart_asWI
                      p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                      (g_asVx, gpart_asWI) = Genome.Split.split gpart_asWH
                      p_asVw = Functions.belowten' g_asVv
                      (g_asVv, gpart_asWH) = Genome.Split.split gpart_asWG
                      p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                      (g_asVt, gpart_asWG) = Genome.Split.split gpart_asWF
                      p_asVs = Functions.belowten' g_asVr
                      (g_asVr, gpart_asWF) = Genome.Split.split gpart_asWE
                      p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                      (g_asVp, gpart_asWE) = Genome.Split.split gpart_asWD
                      p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                      (g_asVn, gpart_asWD) = Genome.Split.split gpart_asWC
                      p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                      (g_asVl, gpart_asWC) = Genome.Split.split gpart_asWB
                      p_asVk = Functions.belowten' g_asVj
                      (g_asVj, gpart_asWB) = Genome.Split.split gpart_asWA
                      p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                      (g_asVh, gpart_asWA) = Genome.Split.split gpart_asWz
                      p_asVg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                      (g_asVf, gpart_asWz) = Genome.Split.split gpart_asWy
                      p_asVe
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                      (g_asVd, gpart_asWy) = Genome.Split.split gpart_asWx
                      p_asVc = Functions.belowten' g_asVb
                      (g_asVb, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                      (g_asV3, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asWr) = Genome.Split.split genome_asWp
                    in
                      [Reaction
                         (\ x_asX9
                            -> let
                                 c_MiRs_asXc = ((toVector x_asX9) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asXa = ((toVector x_asX9) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asV8
                                  * ((p_asVm + ((c_NPTB_asXa / p_asVa) ** p_asVc))
                                     / (((1 + p_asVm) + ((c_NPTB_asXa / p_asVa) ** p_asVc))
                                        + ((c_MiRs_asXc / p_asVi) ** p_asVk)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXd
                            -> let
                                 c_MiRs_asXe = ((toVector x_asXd) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXf = ((toVector x_asXd) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVo
                                  / (1
                                     + (((c_MiRs_asXe / p_asVq) ** p_asVs)
                                        + ((c_PTB_asXf / p_asVu) ** p_asVw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXg
                            -> let
                                 c_RESTc_asXj = ((toVector x_asXg) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asXh = ((toVector x_asXg) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asVy
                                  * ((p_asVM
                                      + (((p_asV4 / p_asVA) ** p_asVC)
                                         + ((c_NPTB_asXh / p_asVE) ** p_asVG)))
                                     / (((1 + p_asVM)
                                         + (((p_asV4 / p_asVA) ** p_asVC)
                                            + ((c_NPTB_asXh / p_asVE) ** p_asVG)))
                                        + ((c_RESTc_asXj / p_asVI) ** p_asVK)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXk
                            -> let
                                 c_MiRs_asXn = ((toVector x_asXk) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXl = ((toVector x_asXk) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVO
                                  * ((p_asW2 + ((c_PTB_asXl / p_asVQ) ** p_asVS))
                                     / (((1 + p_asW2) + ((c_PTB_asXl / p_asVQ) ** p_asVS))
                                        + (((p_asV0 / p_asVU) ** p_asVW)
                                           + ((c_MiRs_asXn / p_asVY) ** p_asW0))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXo
                            -> let
                                 c_RESTc_asXr = ((toVector x_asXo) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asXp = ((toVector x_asXo) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asW4
                                  * ((p_asWe + ((c_MiRs_asXp / p_asW6) ** p_asW8))
                                     / (((1 + p_asWe) + ((c_MiRs_asXp / p_asW6) ** p_asW8))
                                        + ((c_RESTc_asXr / p_asWa) ** p_asWc)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXs
                            -> let c_PTB_asXt = ((toVector x_asXs) Data.Vector.Unboxed.! 0)
                               in (p_asWg * c_PTB_asXt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXu
                            -> let c_NPTB_asXv = ((toVector x_asXu) Data.Vector.Unboxed.! 1)
                               in (p_asWi * c_NPTB_asXv))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXw
                            -> let c_MiRs_asXx = ((toVector x_asXw) Data.Vector.Unboxed.! 2)
                               in (p_asWk * c_MiRs_asXx))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXy
                            -> let c_RESTc_asXz = ((toVector x_asXy) Data.Vector.Unboxed.! 3)
                               in (p_asWm * c_RESTc_asXz))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXA
                            -> let
                                 c_EndoNeuroTFs_asXB = ((toVector x_asXA) Data.Vector.Unboxed.! 4)
                               in (p_asWo * c_EndoNeuroTFs_asXB))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120972",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120974",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWp
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYo
                            p_asWo = code-0.1.0.0:Genome.FixedList.Functions.double g_asWn
                            (g_asWn, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asWm = code-0.1.0.0:Genome.FixedList.Functions.double g_asWl
                            (g_asWl, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                            (g_asWj, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asWi = code-0.1.0.0:Genome.FixedList.Functions.double g_asWh
                            (g_asWh, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                            (g_asWf, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asWe = code-0.1.0.0:Genome.FixedList.Functions.double g_asWd
                            (g_asWd, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asWc = Functions.belowten' g_asWb
                            (g_asWb, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asWa = code-0.1.0.0:Genome.FixedList.Functions.double g_asW9
                            (g_asW9, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asW8 = Functions.belowten' g_asW7
                            (g_asW7, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                            (g_asW5, gpart_asYf) = Genome.Split.split gpart_asYe
                            p_asW4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW3
                            (g_asW3, gpart_asYe) = Genome.Split.split gpart_asYd
                            p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                            (g_asW1, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asW0 = Functions.belowten' g_asVZ
                            (g_asVZ, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asVW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVV
                            (g_asVV, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asVU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVT
                            (g_asVT, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asVS = Functions.belowten' g_asVR
                            (g_asVR, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asVQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVP
                            (g_asVP, gpart_asY7) = Genome.Split.split gpart_asY6
                            p_asVO = code-0.1.0.0:Genome.FixedList.Functions.double g_asVN
                            (g_asVN, gpart_asY6) = Genome.Split.split gpart_asY5
                            p_asVM = code-0.1.0.0:Genome.FixedList.Functions.double g_asVL
                            (g_asVL, gpart_asY5) = Genome.Split.split gpart_asY4
                            p_asVK = Functions.belowten' g_asVJ
                            (g_asVJ, gpart_asY4) = Genome.Split.split gpart_asY3
                            p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                            (g_asVH, gpart_asY3) = Genome.Split.split gpart_asY2
                            p_asVG = Functions.belowten' g_asVF
                            (g_asVF, gpart_asY2) = Genome.Split.split gpart_asY1
                            p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                            (g_asVD, gpart_asY1) = Genome.Split.split gpart_asY0
                            p_asVC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVB
                            (g_asVB, gpart_asY0) = Genome.Split.split gpart_asXZ
                            p_asVA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVz
                            (g_asVz, gpart_asXZ) = Genome.Split.split gpart_asXY
                            p_asVy = code-0.1.0.0:Genome.FixedList.Functions.double g_asVx
                            (g_asVx, gpart_asXY) = Genome.Split.split gpart_asXX
                            p_asVw = Functions.belowten' g_asVv
                            (g_asVv, gpart_asXX) = Genome.Split.split gpart_asXW
                            p_asVu = code-0.1.0.0:Genome.FixedList.Functions.double g_asVt
                            (g_asVt, gpart_asXW) = Genome.Split.split gpart_asXV
                            p_asVs = Functions.belowten' g_asVr
                            (g_asVr, gpart_asXV) = Genome.Split.split gpart_asXU
                            p_asVq = code-0.1.0.0:Genome.FixedList.Functions.double g_asVp
                            (g_asVp, gpart_asXU) = Genome.Split.split gpart_asXT
                            p_asVo = code-0.1.0.0:Genome.FixedList.Functions.double g_asVn
                            (g_asVn, gpart_asXT) = Genome.Split.split gpart_asXS
                            p_asVm = code-0.1.0.0:Genome.FixedList.Functions.double g_asVl
                            (g_asVl, gpart_asXS) = Genome.Split.split gpart_asXR
                            p_asVk = Functions.belowten' g_asVj
                            (g_asVj, gpart_asXR) = Genome.Split.split gpart_asXQ
                            p_asVi = code-0.1.0.0:Genome.FixedList.Functions.double g_asVh
                            (g_asVh, gpart_asXQ) = Genome.Split.split gpart_asXP
                            p_asVg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVf
                            (g_asVf, gpart_asXP) = Genome.Split.split gpart_asXO
                            p_asVe
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVd
                            (g_asVd, gpart_asXO) = Genome.Split.split gpart_asXN
                            p_asVc = Functions.belowten' g_asVb
                            (g_asVb, gpart_asXN) = Genome.Split.split gpart_asXM
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asXM) = Genome.Split.split gpart_asXL
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asXL) = Genome.Split.split gpart_asXK
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asXK) = Genome.Split.split gpart_asXJ
                            p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                            (g_asV3, gpart_asXJ) = Genome.Split.split gpart_asXI
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asXI) = Genome.Split.split gpart_asXH
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asXH) = Genome.Split.split genome_asWp
                          in
                            \ desc_asWq
                              -> case desc_asWq of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVc)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVe)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVg)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVi)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVk)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVm)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVo)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVq)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVs)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVu)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVw)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVy)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW4)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW6)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW8)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWa)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWc)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWe)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWg)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWi)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWk)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWm)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWo)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0v
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1e
                      p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                      (g_at0t, gpart_at1e) = Genome.Split.split gpart_at1d
                      p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                      (g_at0r, gpart_at1d) = Genome.Split.split gpart_at1c
                      p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                      (g_at0p, gpart_at1c) = Genome.Split.split gpart_at1b
                      p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                      (g_at0n, gpart_at1b) = Genome.Split.split gpart_at1a
                      p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                      (g_at0l, gpart_at1a) = Genome.Split.split gpart_at19
                      p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                      (g_at0j, gpart_at19) = Genome.Split.split gpart_at18
                      p_at0i = Functions.belowten' g_at0h
                      (g_at0h, gpart_at18) = Genome.Split.split gpart_at17
                      p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                      (g_at0f, gpart_at17) = Genome.Split.split gpart_at16
                      p_at0e = Functions.belowten' g_at0d
                      (g_at0d, gpart_at16) = Genome.Split.split gpart_at15
                      p_at0c = code-0.1.0.0:Genome.FixedList.Functions.double g_at0b
                      (g_at0b, gpart_at15) = Genome.Split.split gpart_at14
                      p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                      (g_at09, gpart_at14) = Genome.Split.split gpart_at13
                      p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                      (g_at07, gpart_at13) = Genome.Split.split gpart_at12
                      p_at06 = Functions.belowten' g_at05
                      (g_at05, gpart_at12) = Genome.Split.split gpart_at11
                      p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                      (g_at03, gpart_at11) = Genome.Split.split gpart_at10
                      p_at02
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at01
                      (g_at01, gpart_at10) = Genome.Split.split gpart_at0Z
                      p_at00
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZZ
                      (g_asZZ, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_asZY = Functions.belowten' g_asZX
                      (g_asZX, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                      (g_asZV, gpart_at0X) = Genome.Split.split gpart_at0W
                      p_asZU = code-0.1.0.0:Genome.FixedList.Functions.double g_asZT
                      (g_asZT, gpart_at0W) = Genome.Split.split gpart_at0V
                      p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                      (g_asZR, gpart_at0V) = Genome.Split.split gpart_at0U
                      p_asZQ = Functions.belowten' g_asZP
                      (g_asZP, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                      (g_asZN, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_asZM = Functions.belowten' g_asZL
                      (g_asZL, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                      (g_asZJ, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_asZI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZH
                      (g_asZH, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_asZG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZF
                      (g_asZF, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                      (g_asZD, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZC = Functions.belowten' g_asZB
                      (g_asZB, gpart_at0N) = Genome.Split.split gpart_at0M
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0M) = Genome.Split.split gpart_at0L
                      p_asZy = Functions.belowten' g_asZx
                      (g_asZx, gpart_at0L) = Genome.Split.split gpart_at0K
                      p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                      (g_asZv, gpart_at0K) = Genome.Split.split gpart_at0J
                      p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                      (g_asZt, gpart_at0J) = Genome.Split.split gpart_at0I
                      p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                      (g_asZr, gpart_at0I) = Genome.Split.split gpart_at0H
                      p_asZq = Functions.belowten' g_asZp
                      (g_asZp, gpart_at0H) = Genome.Split.split gpart_at0G
                      p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                      (g_asZn, gpart_at0G) = Genome.Split.split gpart_at0F
                      p_asZm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZl
                      (g_asZl, gpart_at0F) = Genome.Split.split gpart_at0E
                      p_asZk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZj
                      (g_asZj, gpart_at0E) = Genome.Split.split gpart_at0D
                      p_asZi = Functions.belowten' g_asZh
                      (g_asZh, gpart_at0D) = Genome.Split.split gpart_at0C
                      p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                      (g_asZf, gpart_at0C) = Genome.Split.split gpart_at0B
                      p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                      (g_asZd, gpart_at0B) = Genome.Split.split gpart_at0A
                      p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                      (g_asZb, gpart_at0A) = Genome.Split.split gpart_at0z
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_at0z) = Genome.Split.split gpart_at0y
                      p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                      (g_asZ7, gpart_at0y) = Genome.Split.split gpart_at0x
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_at0x) = Genome.Split.split genome_at0v
                    in
                      [Reaction
                         (\ x_at1f
                            -> let
                                 c_MiRs_at1i = ((toVector x_at1f) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at1g = ((toVector x_at1f) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZe
                                  * ((p_asZs + ((c_NPTB_at1g / p_asZg) ** p_asZi))
                                     / (((1 + p_asZs) + ((c_NPTB_at1g / p_asZg) ** p_asZi))
                                        + ((c_MiRs_at1i / p_asZo) ** p_asZq)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1j
                            -> let
                                 c_MiRs_at1k = ((toVector x_at1j) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1l = ((toVector x_at1j) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZu
                                  / (1
                                     + (((c_MiRs_at1k / p_asZw) ** p_asZy)
                                        + ((c_PTB_at1l / p_asZA) ** p_asZC)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at1m
                            -> let
                                 c_RESTc_at1p = ((toVector x_at1m) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at1n = ((toVector x_at1m) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZE
                                  * ((p_asZS + ((c_NPTB_at1n / p_asZK) ** p_asZM))
                                     / (((1 + p_asZS) + ((c_NPTB_at1n / p_asZK) ** p_asZM))
                                        + ((c_RESTc_at1p / p_asZO) ** p_asZQ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at1q
                            -> let
                                 c_MiRs_at1t = ((toVector x_at1q) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1r = ((toVector x_at1q) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZU
                                  * ((p_at08 + ((c_PTB_at1r / p_asZW) ** p_asZY))
                                     / (((1 + p_at08) + ((c_PTB_at1r / p_asZW) ** p_asZY))
                                        + (((p_asZ6 / p_at00) ** p_at02)
                                           + ((c_MiRs_at1t / p_at04) ** p_at06))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1u
                            -> let
                                 c_RESTc_at1x = ((toVector x_at1u) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at1v = ((toVector x_at1u) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at0a
                                  * ((p_at0k + ((c_MiRs_at1v / p_at0c) ** p_at0e))
                                     / (((1 + p_at0k) + ((c_MiRs_at1v / p_at0c) ** p_at0e))
                                        + ((c_RESTc_at1x / p_at0g) ** p_at0i)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1y
                            -> let c_PTB_at1z = ((toVector x_at1y) Data.Vector.Unboxed.! 0)
                               in (p_at0m * c_PTB_at1z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1A
                            -> let c_NPTB_at1B = ((toVector x_at1A) Data.Vector.Unboxed.! 1)
                               in (p_at0o * c_NPTB_at1B))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1C
                            -> let c_MiRs_at1D = ((toVector x_at1C) Data.Vector.Unboxed.! 2)
                               in (p_at0q * c_MiRs_at1D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1E
                            -> let c_RESTc_at1F = ((toVector x_at1E) Data.Vector.Unboxed.! 3)
                               in (p_at0s * c_RESTc_at1F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1G
                            -> let
                                 c_EndoNeuroTFs_at1H = ((toVector x_at1G) Data.Vector.Unboxed.! 4)
                               in (p_at0u * c_EndoNeuroTFs_at1H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121228",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121268",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121270",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121272",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121286",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121288",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0v
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2p
                            p_at0u = code-0.1.0.0:Genome.FixedList.Functions.double g_at0t
                            (g_at0t, gpart_at2p) = Genome.Split.split gpart_at2o
                            p_at0s = code-0.1.0.0:Genome.FixedList.Functions.double g_at0r
                            (g_at0r, gpart_at2o) = Genome.Split.split gpart_at2n
                            p_at0q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0p
                            (g_at0p, gpart_at2n) = Genome.Split.split gpart_at2m
                            p_at0o = code-0.1.0.0:Genome.FixedList.Functions.double g_at0n
                            (g_at0n, gpart_at2m) = Genome.Split.split gpart_at2l
                            p_at0m = code-0.1.0.0:Genome.FixedList.Functions.double g_at0l
                            (g_at0l, gpart_at2l) = Genome.Split.split gpart_at2k
                            p_at0k = code-0.1.0.0:Genome.FixedList.Functions.double g_at0j
                            (g_at0j, gpart_at2k) = Genome.Split.split gpart_at2j
                            p_at0i = Functions.belowten' g_at0h
                            (g_at0h, gpart_at2j) = Genome.Split.split gpart_at2i
                            p_at0g = code-0.1.0.0:Genome.FixedList.Functions.double g_at0f
                            (g_at0f, gpart_at2i) = Genome.Split.split gpart_at2h
                            p_at0e = Functions.belowten' g_at0d
                            (g_at0d, gpart_at2h) = Genome.Split.split gpart_at2g
                            p_at0c = code-0.1.0.0:Genome.FixedList.Functions.double g_at0b
                            (g_at0b, gpart_at2g) = Genome.Split.split gpart_at2f
                            p_at0a = code-0.1.0.0:Genome.FixedList.Functions.double g_at09
                            (g_at09, gpart_at2f) = Genome.Split.split gpart_at2e
                            p_at08 = code-0.1.0.0:Genome.FixedList.Functions.double g_at07
                            (g_at07, gpart_at2e) = Genome.Split.split gpart_at2d
                            p_at06 = Functions.belowten' g_at05
                            (g_at05, gpart_at2d) = Genome.Split.split gpart_at2c
                            p_at04 = code-0.1.0.0:Genome.FixedList.Functions.double g_at03
                            (g_at03, gpart_at2c) = Genome.Split.split gpart_at2b
                            p_at02
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at01
                            (g_at01, gpart_at2b) = Genome.Split.split gpart_at2a
                            p_at00
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZZ
                            (g_asZZ, gpart_at2a) = Genome.Split.split gpart_at29
                            p_asZY = Functions.belowten' g_asZX
                            (g_asZX, gpart_at29) = Genome.Split.split gpart_at28
                            p_asZW = code-0.1.0.0:Genome.FixedList.Functions.double g_asZV
                            (g_asZV, gpart_at28) = Genome.Split.split gpart_at27
                            p_asZU = code-0.1.0.0:Genome.FixedList.Functions.double g_asZT
                            (g_asZT, gpart_at27) = Genome.Split.split gpart_at26
                            p_asZS = code-0.1.0.0:Genome.FixedList.Functions.double g_asZR
                            (g_asZR, gpart_at26) = Genome.Split.split gpart_at25
                            p_asZQ = Functions.belowten' g_asZP
                            (g_asZP, gpart_at25) = Genome.Split.split gpart_at24
                            p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                            (g_asZN, gpart_at24) = Genome.Split.split gpart_at23
                            p_asZM = Functions.belowten' g_asZL
                            (g_asZL, gpart_at23) = Genome.Split.split gpart_at22
                            p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                            (g_asZJ, gpart_at22) = Genome.Split.split gpart_at21
                            p_asZI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZH
                            (g_asZH, gpart_at21) = Genome.Split.split gpart_at20
                            p_asZG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZF
                            (g_asZF, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_asZE = code-0.1.0.0:Genome.FixedList.Functions.double g_asZD
                            (g_asZD, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_asZC = Functions.belowten' g_asZB
                            (g_asZB, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_asZy = Functions.belowten' g_asZx
                            (g_asZx, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_asZw = code-0.1.0.0:Genome.FixedList.Functions.double g_asZv
                            (g_asZv, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                            (g_asZt, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_asZs = code-0.1.0.0:Genome.FixedList.Functions.double g_asZr
                            (g_asZr, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_asZq = Functions.belowten' g_asZp
                            (g_asZp, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_asZo = code-0.1.0.0:Genome.FixedList.Functions.double g_asZn
                            (g_asZn, gpart_at1R) = Genome.Split.split gpart_at1Q
                            p_asZm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZl
                            (g_asZl, gpart_at1Q) = Genome.Split.split gpart_at1P
                            p_asZk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZj
                            (g_asZj, gpart_at1P) = Genome.Split.split gpart_at1O
                            p_asZi = Functions.belowten' g_asZh
                            (g_asZh, gpart_at1O) = Genome.Split.split gpart_at1N
                            p_asZg = code-0.1.0.0:Genome.FixedList.Functions.double g_asZf
                            (g_asZf, gpart_at1N) = Genome.Split.split gpart_at1M
                            p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                            (g_asZd, gpart_at1M) = Genome.Split.split gpart_at1L
                            p_asZc = code-0.1.0.0:Genome.FixedList.Functions.double g_asZb
                            (g_asZb, gpart_at1L) = Genome.Split.split gpart_at1K
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at1K) = Genome.Split.split gpart_at1J
                            p_asZ8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ7
                            (g_asZ7, gpart_at1J) = Genome.Split.split gpart_at1I
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at1I) = Genome.Split.split genome_at0v
                          in
                            \ desc_at0w
                              -> case desc_at0w of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZm)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZo)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZu)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZM)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZO)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZQ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZS)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZU)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZW)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZY)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at00)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at02)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at04)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at06)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at08)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0a)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0c)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0e)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0g)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0i)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0k)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0m)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0o)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0q)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0s)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0u)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at4w
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5f
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5f) = Genome.Split.split gpart_at5e
                      p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                      (g_at4s, gpart_at5e) = Genome.Split.split gpart_at5d
                      p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                      (g_at4q, gpart_at5d) = Genome.Split.split gpart_at5c
                      p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                      (g_at4o, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                      (g_at4m, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                      (g_at4k, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at4j = Functions.belowten' g_at4i
                      (g_at4i, gpart_at59) = Genome.Split.split gpart_at58
                      p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                      (g_at4g, gpart_at58) = Genome.Split.split gpart_at57
                      p_at4f = Functions.belowten' g_at4e
                      (g_at4e, gpart_at57) = Genome.Split.split gpart_at56
                      p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                      (g_at4c, gpart_at56) = Genome.Split.split gpart_at55
                      p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                      (g_at4a, gpart_at55) = Genome.Split.split gpart_at54
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at54) = Genome.Split.split gpart_at53
                      p_at47 = Functions.belowten' g_at46
                      (g_at46, gpart_at53) = Genome.Split.split gpart_at52
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at52) = Genome.Split.split gpart_at51
                      p_at43
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at42
                      (g_at42, gpart_at51) = Genome.Split.split gpart_at50
                      p_at41
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at40
                      (g_at40, gpart_at50) = Genome.Split.split gpart_at4Z
                      p_at3Z = Functions.belowten' g_at3Y
                      (g_at3Y, gpart_at4Z) = Genome.Split.split gpart_at4Y
                      p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                      (g_at3W, gpart_at4Y) = Genome.Split.split gpart_at4X
                      p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                      (g_at3U, gpart_at4X) = Genome.Split.split gpart_at4W
                      p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                      (g_at3S, gpart_at4W) = Genome.Split.split gpart_at4V
                      p_at3R = Functions.belowten' g_at3Q
                      (g_at3Q, gpart_at4V) = Genome.Split.split gpart_at4U
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at4U) = Genome.Split.split gpart_at4T
                      p_at3N = Functions.belowten' g_at3M
                      (g_at3M, gpart_at4T) = Genome.Split.split gpart_at4S
                      p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                      (g_at3K, gpart_at4S) = Genome.Split.split gpart_at4R
                      p_at3J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3I
                      (g_at3I, gpart_at4R) = Genome.Split.split gpart_at4Q
                      p_at3H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3G
                      (g_at3G, gpart_at4Q) = Genome.Split.split gpart_at4P
                      p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                      (g_at3E, gpart_at4P) = Genome.Split.split gpart_at4O
                      p_at3D = Functions.belowten' g_at3C
                      (g_at3C, gpart_at4O) = Genome.Split.split gpart_at4N
                      p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                      (g_at3A, gpart_at4N) = Genome.Split.split gpart_at4M
                      p_at3z = Functions.belowten' g_at3y
                      (g_at3y, gpart_at4M) = Genome.Split.split gpart_at4L
                      p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                      (g_at3w, gpart_at4L) = Genome.Split.split gpart_at4K
                      p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                      (g_at3u, gpart_at4K) = Genome.Split.split gpart_at4J
                      p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                      (g_at3s, gpart_at4J) = Genome.Split.split gpart_at4I
                      p_at3r = Functions.belowten' g_at3q
                      (g_at3q, gpart_at4I) = Genome.Split.split gpart_at4H
                      p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                      (g_at3o, gpart_at4H) = Genome.Split.split gpart_at4G
                      p_at3n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3m
                      (g_at3m, gpart_at4G) = Genome.Split.split gpart_at4F
                      p_at3l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3k
                      (g_at3k, gpart_at4F) = Genome.Split.split gpart_at4E
                      p_at3j = Functions.belowten' g_at3i
                      (g_at3i, gpart_at4E) = Genome.Split.split gpart_at4D
                      p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                      (g_at3g, gpart_at4D) = Genome.Split.split gpart_at4C
                      p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                      (g_at3e, gpart_at4C) = Genome.Split.split gpart_at4B
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at4B) = Genome.Split.split gpart_at4A
                      p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                      (g_at3a, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                      (g_at38, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                      (g_at36, gpart_at4y) = Genome.Split.split genome_at4w
                    in
                      [Reaction
                         (\ x_at5g
                            -> let
                                 c_MiRs_at5j = ((toVector x_at5g) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at5h = ((toVector x_at5g) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3f
                                  * ((p_at3t + ((c_NPTB_at5h / p_at3h) ** p_at3j))
                                     / (((1 + p_at3t) + ((c_NPTB_at5h / p_at3h) ** p_at3j))
                                        + ((c_MiRs_at5j / p_at3p) ** p_at3r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5k
                            -> let
                                 c_MiRs_at5l = ((toVector x_at5k) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5m = ((toVector x_at5k) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3v
                                  / (1
                                     + (((c_MiRs_at5l / p_at3x) ** p_at3z)
                                        + ((c_PTB_at5m / p_at3B) ** p_at3D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5n
                            -> let
                                 c_RESTc_at5q = ((toVector x_at5n) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at5o = ((toVector x_at5n) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at3F
                                  * ((p_at3T + ((c_NPTB_at5o / p_at3L) ** p_at3N))
                                     / (((1 + p_at3T) + ((c_NPTB_at5o / p_at3L) ** p_at3N))
                                        + ((c_RESTc_at5q / p_at3P) ** p_at3R)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5r
                            -> let
                                 c_MiRs_at5u = ((toVector x_at5r) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5s = ((toVector x_at5r) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3V
                                  * ((p_at49 + ((c_PTB_at5s / p_at3X) ** p_at3Z))
                                     / (((1 + p_at49) + ((c_PTB_at5s / p_at3X) ** p_at3Z))
                                        + ((c_MiRs_at5u / p_at45) ** p_at47)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5v
                            -> let
                                 c_RESTc_at5y = ((toVector x_at5v) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at5w = ((toVector x_at5v) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4b
                                  * ((p_at4l + ((c_MiRs_at5w / p_at4d) ** p_at4f))
                                     / (((1 + p_at4l) + ((c_MiRs_at5w / p_at4d) ** p_at4f))
                                        + ((c_RESTc_at5y / p_at4h) ** p_at4j)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5z
                            -> let c_PTB_at5A = ((toVector x_at5z) Data.Vector.Unboxed.! 0)
                               in (p_at4n * c_PTB_at5A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5B
                            -> let c_NPTB_at5C = ((toVector x_at5B) Data.Vector.Unboxed.! 1)
                               in (p_at4p * c_NPTB_at5C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5D
                            -> let c_MiRs_at5E = ((toVector x_at5D) Data.Vector.Unboxed.! 2)
                               in (p_at4r * c_MiRs_at5E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5F
                            -> let c_RESTc_at5G = ((toVector x_at5F) Data.Vector.Unboxed.! 3)
                               in (p_at4t * c_RESTc_at5G))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5H
                            -> let
                                 c_EndoNeuroTFs_at5I = ((toVector x_at5H) Data.Vector.Unboxed.! 4)
                               in (p_at4v * c_EndoNeuroTFs_at5I))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121475",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121477",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121481",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121483",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4w
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6q
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                            (g_at4s, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                            (g_at4q, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                            (g_at4o, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                            (g_at4m, gpart_at6m) = Genome.Split.split gpart_at6l
                            p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                            (g_at4k, gpart_at6l) = Genome.Split.split gpart_at6k
                            p_at4j = Functions.belowten' g_at4i
                            (g_at4i, gpart_at6k) = Genome.Split.split gpart_at6j
                            p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                            (g_at4g, gpart_at6j) = Genome.Split.split gpart_at6i
                            p_at4f = Functions.belowten' g_at4e
                            (g_at4e, gpart_at6i) = Genome.Split.split gpart_at6h
                            p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                            (g_at4c, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                            (g_at4a, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at47 = Functions.belowten' g_at46
                            (g_at46, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at43
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at42
                            (g_at42, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at41
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at40
                            (g_at40, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at3Z = Functions.belowten' g_at3Y
                            (g_at3Y, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                            (g_at3W, gpart_at69) = Genome.Split.split gpart_at68
                            p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                            (g_at3U, gpart_at68) = Genome.Split.split gpart_at67
                            p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                            (g_at3S, gpart_at67) = Genome.Split.split gpart_at66
                            p_at3R = Functions.belowten' g_at3Q
                            (g_at3Q, gpart_at66) = Genome.Split.split gpart_at65
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at65) = Genome.Split.split gpart_at64
                            p_at3N = Functions.belowten' g_at3M
                            (g_at3M, gpart_at64) = Genome.Split.split gpart_at63
                            p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                            (g_at3K, gpart_at63) = Genome.Split.split gpart_at62
                            p_at3J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3I
                            (g_at3I, gpart_at62) = Genome.Split.split gpart_at61
                            p_at3H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3G
                            (g_at3G, gpart_at61) = Genome.Split.split gpart_at60
                            p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                            (g_at3E, gpart_at60) = Genome.Split.split gpart_at5Z
                            p_at3D = Functions.belowten' g_at3C
                            (g_at3C, gpart_at5Z) = Genome.Split.split gpart_at5Y
                            p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                            (g_at3A, gpart_at5Y) = Genome.Split.split gpart_at5X
                            p_at3z = Functions.belowten' g_at3y
                            (g_at3y, gpart_at5X) = Genome.Split.split gpart_at5W
                            p_at3x = code-0.1.0.0:Genome.FixedList.Functions.double g_at3w
                            (g_at3w, gpart_at5W) = Genome.Split.split gpart_at5V
                            p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                            (g_at3u, gpart_at5V) = Genome.Split.split gpart_at5U
                            p_at3t = code-0.1.0.0:Genome.FixedList.Functions.double g_at3s
                            (g_at3s, gpart_at5U) = Genome.Split.split gpart_at5T
                            p_at3r = Functions.belowten' g_at3q
                            (g_at3q, gpart_at5T) = Genome.Split.split gpart_at5S
                            p_at3p = code-0.1.0.0:Genome.FixedList.Functions.double g_at3o
                            (g_at3o, gpart_at5S) = Genome.Split.split gpart_at5R
                            p_at3n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3m
                            (g_at3m, gpart_at5R) = Genome.Split.split gpart_at5Q
                            p_at3l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3k
                            (g_at3k, gpart_at5Q) = Genome.Split.split gpart_at5P
                            p_at3j = Functions.belowten' g_at3i
                            (g_at3i, gpart_at5P) = Genome.Split.split gpart_at5O
                            p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                            (g_at3g, gpart_at5O) = Genome.Split.split gpart_at5N
                            p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                            (g_at3e, gpart_at5N) = Genome.Split.split gpart_at5M
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                            (g_at3a, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                            (g_at38, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                            (g_at36, gpart_at5J) = Genome.Split.split genome_at4w
                          in
                            \ desc_at4x
                              -> case desc_at4x of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3h)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3j)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3l)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3n)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3p)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3r)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3t)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3v)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3x)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3z)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3B)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3D)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3F)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3R)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3T)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3V)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3X)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Z)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at8x
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at9g
                      p_at8w = code-0.1.0.0:Genome.FixedList.Functions.double g_at8v
                      (g_at8v, gpart_at9g) = Genome.Split.split gpart_at9f
                      p_at8u = code-0.1.0.0:Genome.FixedList.Functions.double g_at8t
                      (g_at8t, gpart_at9f) = Genome.Split.split gpart_at9e
                      p_at8s = code-0.1.0.0:Genome.FixedList.Functions.double g_at8r
                      (g_at8r, gpart_at9e) = Genome.Split.split gpart_at9d
                      p_at8q = code-0.1.0.0:Genome.FixedList.Functions.double g_at8p
                      (g_at8p, gpart_at9d) = Genome.Split.split gpart_at9c
                      p_at8o = code-0.1.0.0:Genome.FixedList.Functions.double g_at8n
                      (g_at8n, gpart_at9c) = Genome.Split.split gpart_at9b
                      p_at8m = code-0.1.0.0:Genome.FixedList.Functions.double g_at8l
                      (g_at8l, gpart_at9b) = Genome.Split.split gpart_at9a
                      p_at8k = Functions.belowten' g_at8j
                      (g_at8j, gpart_at9a) = Genome.Split.split gpart_at99
                      p_at8i = code-0.1.0.0:Genome.FixedList.Functions.double g_at8h
                      (g_at8h, gpart_at99) = Genome.Split.split gpart_at98
                      p_at8g = Functions.belowten' g_at8f
                      (g_at8f, gpart_at98) = Genome.Split.split gpart_at97
                      p_at8e = code-0.1.0.0:Genome.FixedList.Functions.double g_at8d
                      (g_at8d, gpart_at97) = Genome.Split.split gpart_at96
                      p_at8c = code-0.1.0.0:Genome.FixedList.Functions.double g_at8b
                      (g_at8b, gpart_at96) = Genome.Split.split gpart_at95
                      p_at8a = code-0.1.0.0:Genome.FixedList.Functions.double g_at89
                      (g_at89, gpart_at95) = Genome.Split.split gpart_at94
                      p_at88 = Functions.belowten' g_at87
                      (g_at87, gpart_at94) = Genome.Split.split gpart_at93
                      p_at86 = code-0.1.0.0:Genome.FixedList.Functions.double g_at85
                      (g_at85, gpart_at93) = Genome.Split.split gpart_at92
                      p_at84
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at83
                      (g_at83, gpart_at92) = Genome.Split.split gpart_at91
                      p_at82
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at81
                      (g_at81, gpart_at91) = Genome.Split.split gpart_at90
                      p_at80 = Functions.belowten' g_at7Z
                      (g_at7Z, gpart_at90) = Genome.Split.split gpart_at8Z
                      p_at7Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7X
                      (g_at7X, gpart_at8Z) = Genome.Split.split gpart_at8Y
                      p_at7W = code-0.1.0.0:Genome.FixedList.Functions.double g_at7V
                      (g_at7V, gpart_at8Y) = Genome.Split.split gpart_at8X
                      p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                      (g_at7T, gpart_at8X) = Genome.Split.split gpart_at8W
                      p_at7S = Functions.belowten' g_at7R
                      (g_at7R, gpart_at8W) = Genome.Split.split gpart_at8V
                      p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                      (g_at7P, gpart_at8V) = Genome.Split.split gpart_at8U
                      p_at7O = Functions.belowten' g_at7N
                      (g_at7N, gpart_at8U) = Genome.Split.split gpart_at8T
                      p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                      (g_at7L, gpart_at8T) = Genome.Split.split gpart_at8S
                      p_at7K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7J
                      (g_at7J, gpart_at8S) = Genome.Split.split gpart_at8R
                      p_at7I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7H
                      (g_at7H, gpart_at8R) = Genome.Split.split gpart_at8Q
                      p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                      (g_at7F, gpart_at8Q) = Genome.Split.split gpart_at8P
                      p_at7E = Functions.belowten' g_at7D
                      (g_at7D, gpart_at8P) = Genome.Split.split gpart_at8O
                      p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                      (g_at7B, gpart_at8O) = Genome.Split.split gpart_at8N
                      p_at7A = Functions.belowten' g_at7z
                      (g_at7z, gpart_at8N) = Genome.Split.split gpart_at8M
                      p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                      (g_at7x, gpart_at8M) = Genome.Split.split gpart_at8L
                      p_at7w = code-0.1.0.0:Genome.FixedList.Functions.double g_at7v
                      (g_at7v, gpart_at8L) = Genome.Split.split gpart_at8K
                      p_at7u = code-0.1.0.0:Genome.FixedList.Functions.double g_at7t
                      (g_at7t, gpart_at8K) = Genome.Split.split gpart_at8J
                      p_at7s = Functions.belowten' g_at7r
                      (g_at7r, gpart_at8J) = Genome.Split.split gpart_at8I
                      p_at7q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7p
                      (g_at7p, gpart_at8I) = Genome.Split.split gpart_at8H
                      p_at7o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7n
                      (g_at7n, gpart_at8H) = Genome.Split.split gpart_at8G
                      p_at7m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7l
                      (g_at7l, gpart_at8G) = Genome.Split.split gpart_at8F
                      p_at7k = Functions.belowten' g_at7j
                      (g_at7j, gpart_at8F) = Genome.Split.split gpart_at8E
                      p_at7i = code-0.1.0.0:Genome.FixedList.Functions.double g_at7h
                      (g_at7h, gpart_at8E) = Genome.Split.split gpart_at8D
                      p_at7g = code-0.1.0.0:Genome.FixedList.Functions.double g_at7f
                      (g_at7f, gpart_at8D) = Genome.Split.split gpart_at8C
                      p_at7e = code-0.1.0.0:Genome.FixedList.Functions.double g_at7d
                      (g_at7d, gpart_at8C) = Genome.Split.split gpart_at8B
                      p_at7c = code-0.1.0.0:Genome.FixedList.Functions.double g_at7b
                      (g_at7b, gpart_at8B) = Genome.Split.split gpart_at8A
                      p_at7a = code-0.1.0.0:Genome.FixedList.Functions.double g_at79
                      (g_at79, gpart_at8A) = Genome.Split.split gpart_at8z
                      p_at78 = code-0.1.0.0:Genome.FixedList.Functions.double g_at77
                      (g_at77, gpart_at8z) = Genome.Split.split genome_at8x
                    in
                      [Reaction
                         (\ x_at9h
                            -> let
                                 c_MiRs_at9k = ((toVector x_at9h) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at9i = ((toVector x_at9h) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at7g
                                  * ((p_at7u + ((c_NPTB_at9i / p_at7i) ** p_at7k))
                                     / (((1 + p_at7u) + ((c_NPTB_at9i / p_at7i) ** p_at7k))
                                        + (((p_at78 / p_at7m) ** p_at7o)
                                           + ((c_MiRs_at9k / p_at7q) ** p_at7s))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at9l
                            -> let
                                 c_MiRs_at9m = ((toVector x_at9l) Data.Vector.Unboxed.! 2)
                                 c_PTB_at9n = ((toVector x_at9l) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7w
                                  / (1
                                     + (((c_MiRs_at9m / p_at7y) ** p_at7A)
                                        + ((c_PTB_at9n / p_at7C) ** p_at7E)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at9o
                            -> let
                                 c_RESTc_at9r = ((toVector x_at9o) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at9p = ((toVector x_at9o) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at7G
                                  * ((p_at7U + ((c_NPTB_at9p / p_at7M) ** p_at7O))
                                     / (((1 + p_at7U) + ((c_NPTB_at9p / p_at7M) ** p_at7O))
                                        + ((c_RESTc_at9r / p_at7Q) ** p_at7S)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at9s
                            -> let
                                 c_MiRs_at9v = ((toVector x_at9s) Data.Vector.Unboxed.! 2)
                                 c_PTB_at9t = ((toVector x_at9s) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7W
                                  * ((p_at8a + ((c_PTB_at9t / p_at7Y) ** p_at80))
                                     / (((1 + p_at8a) + ((c_PTB_at9t / p_at7Y) ** p_at80))
                                        + ((c_MiRs_at9v / p_at86) ** p_at88)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at9w
                            -> let
                                 c_RESTc_at9z = ((toVector x_at9w) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at9x = ((toVector x_at9w) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at8c
                                  * ((p_at8m + ((c_MiRs_at9x / p_at8e) ** p_at8g))
                                     / (((1 + p_at8m) + ((c_MiRs_at9x / p_at8e) ** p_at8g))
                                        + ((c_RESTc_at9z / p_at8i) ** p_at8k)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at9A
                            -> let c_PTB_at9B = ((toVector x_at9A) Data.Vector.Unboxed.! 0)
                               in (p_at8o * c_PTB_at9B))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at9C
                            -> let c_NPTB_at9D = ((toVector x_at9C) Data.Vector.Unboxed.! 1)
                               in (p_at8q * c_NPTB_at9D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at9E
                            -> let c_MiRs_at9F = ((toVector x_at9E) Data.Vector.Unboxed.! 2)
                               in (p_at8s * c_MiRs_at9F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at9G
                            -> let c_RESTc_at9H = ((toVector x_at9G) Data.Vector.Unboxed.! 3)
                               in (p_at8u * c_RESTc_at9H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at9I
                            -> let
                                 c_EndoNeuroTFs_at9J = ((toVector x_at9I) Data.Vector.Unboxed.! 4)
                               in (p_at8w * c_EndoNeuroTFs_at9J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121720",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121722",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121724",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121726",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121746",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121748",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121766",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121768",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121772",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121786",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121788",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121792",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at8x
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_atar
                            p_at8w = code-0.1.0.0:Genome.FixedList.Functions.double g_at8v
                            (g_at8v, gpart_atar) = Genome.Split.split gpart_ataq
                            p_at8u = code-0.1.0.0:Genome.FixedList.Functions.double g_at8t
                            (g_at8t, gpart_ataq) = Genome.Split.split gpart_atap
                            p_at8s = code-0.1.0.0:Genome.FixedList.Functions.double g_at8r
                            (g_at8r, gpart_atap) = Genome.Split.split gpart_atao
                            p_at8q = code-0.1.0.0:Genome.FixedList.Functions.double g_at8p
                            (g_at8p, gpart_atao) = Genome.Split.split gpart_atan
                            p_at8o = code-0.1.0.0:Genome.FixedList.Functions.double g_at8n
                            (g_at8n, gpart_atan) = Genome.Split.split gpart_atam
                            p_at8m = code-0.1.0.0:Genome.FixedList.Functions.double g_at8l
                            (g_at8l, gpart_atam) = Genome.Split.split gpart_atal
                            p_at8k = Functions.belowten' g_at8j
                            (g_at8j, gpart_atal) = Genome.Split.split gpart_atak
                            p_at8i = code-0.1.0.0:Genome.FixedList.Functions.double g_at8h
                            (g_at8h, gpart_atak) = Genome.Split.split gpart_ataj
                            p_at8g = Functions.belowten' g_at8f
                            (g_at8f, gpart_ataj) = Genome.Split.split gpart_atai
                            p_at8e = code-0.1.0.0:Genome.FixedList.Functions.double g_at8d
                            (g_at8d, gpart_atai) = Genome.Split.split gpart_atah
                            p_at8c = code-0.1.0.0:Genome.FixedList.Functions.double g_at8b
                            (g_at8b, gpart_atah) = Genome.Split.split gpart_atag
                            p_at8a = code-0.1.0.0:Genome.FixedList.Functions.double g_at89
                            (g_at89, gpart_atag) = Genome.Split.split gpart_ataf
                            p_at88 = Functions.belowten' g_at87
                            (g_at87, gpart_ataf) = Genome.Split.split gpart_atae
                            p_at86 = code-0.1.0.0:Genome.FixedList.Functions.double g_at85
                            (g_at85, gpart_atae) = Genome.Split.split gpart_atad
                            p_at84
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at83
                            (g_at83, gpart_atad) = Genome.Split.split gpart_atac
                            p_at82
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at81
                            (g_at81, gpart_atac) = Genome.Split.split gpart_atab
                            p_at80 = Functions.belowten' g_at7Z
                            (g_at7Z, gpart_atab) = Genome.Split.split gpart_ataa
                            p_at7Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7X
                            (g_at7X, gpart_ataa) = Genome.Split.split gpart_ata9
                            p_at7W = code-0.1.0.0:Genome.FixedList.Functions.double g_at7V
                            (g_at7V, gpart_ata9) = Genome.Split.split gpart_ata8
                            p_at7U = code-0.1.0.0:Genome.FixedList.Functions.double g_at7T
                            (g_at7T, gpart_ata8) = Genome.Split.split gpart_ata7
                            p_at7S = Functions.belowten' g_at7R
                            (g_at7R, gpart_ata7) = Genome.Split.split gpart_ata6
                            p_at7Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7P
                            (g_at7P, gpart_ata6) = Genome.Split.split gpart_ata5
                            p_at7O = Functions.belowten' g_at7N
                            (g_at7N, gpart_ata5) = Genome.Split.split gpart_ata4
                            p_at7M = code-0.1.0.0:Genome.FixedList.Functions.double g_at7L
                            (g_at7L, gpart_ata4) = Genome.Split.split gpart_ata3
                            p_at7K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7J
                            (g_at7J, gpart_ata3) = Genome.Split.split gpart_ata2
                            p_at7I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7H
                            (g_at7H, gpart_ata2) = Genome.Split.split gpart_ata1
                            p_at7G = code-0.1.0.0:Genome.FixedList.Functions.double g_at7F
                            (g_at7F, gpart_ata1) = Genome.Split.split gpart_ata0
                            p_at7E = Functions.belowten' g_at7D
                            (g_at7D, gpart_ata0) = Genome.Split.split gpart_at9Z
                            p_at7C = code-0.1.0.0:Genome.FixedList.Functions.double g_at7B
                            (g_at7B, gpart_at9Z) = Genome.Split.split gpart_at9Y
                            p_at7A = Functions.belowten' g_at7z
                            (g_at7z, gpart_at9Y) = Genome.Split.split gpart_at9X
                            p_at7y = code-0.1.0.0:Genome.FixedList.Functions.double g_at7x
                            (g_at7x, gpart_at9X) = Genome.Split.split gpart_at9W
                            p_at7w = code-0.1.0.0:Genome.FixedList.Functions.double g_at7v
                            (g_at7v, gpart_at9W) = Genome.Split.split gpart_at9V
                            p_at7u = code-0.1.0.0:Genome.FixedList.Functions.double g_at7t
                            (g_at7t, gpart_at9V) = Genome.Split.split gpart_at9U
                            p_at7s = Functions.belowten' g_at7r
                            (g_at7r, gpart_at9U) = Genome.Split.split gpart_at9T
                            p_at7q = code-0.1.0.0:Genome.FixedList.Functions.double g_at7p
                            (g_at7p, gpart_at9T) = Genome.Split.split gpart_at9S
                            p_at7o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7n
                            (g_at7n, gpart_at9S) = Genome.Split.split gpart_at9R
                            p_at7m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7l
                            (g_at7l, gpart_at9R) = Genome.Split.split gpart_at9Q
                            p_at7k = Functions.belowten' g_at7j
                            (g_at7j, gpart_at9Q) = Genome.Split.split gpart_at9P
                            p_at7i = code-0.1.0.0:Genome.FixedList.Functions.double g_at7h
                            (g_at7h, gpart_at9P) = Genome.Split.split gpart_at9O
                            p_at7g = code-0.1.0.0:Genome.FixedList.Functions.double g_at7f
                            (g_at7f, gpart_at9O) = Genome.Split.split gpart_at9N
                            p_at7e = code-0.1.0.0:Genome.FixedList.Functions.double g_at7d
                            (g_at7d, gpart_at9N) = Genome.Split.split gpart_at9M
                            p_at7c = code-0.1.0.0:Genome.FixedList.Functions.double g_at7b
                            (g_at7b, gpart_at9M) = Genome.Split.split gpart_at9L
                            p_at7a = code-0.1.0.0:Genome.FixedList.Functions.double g_at79
                            (g_at79, gpart_at9L) = Genome.Split.split gpart_at9K
                            p_at78 = code-0.1.0.0:Genome.FixedList.Functions.double g_at77
                            (g_at77, gpart_at9K) = Genome.Split.split genome_at8x
                          in
                            \ desc_at8y
                              -> case desc_at8y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at78)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7a)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7c)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7e)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7g)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7i)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7k)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7m)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7o)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7q)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7s)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7u)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7w)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7A)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7C)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7E)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7G)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7I)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7K)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7M)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7O)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Q)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7S)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7U)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7W)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Y)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at80)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at82)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at84)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at86)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at88)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8a)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8c)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8e)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8g)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8i)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8k)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8m)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8o)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8s)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8u)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8w)
                                   _ -> Nothing }}
