{-# LANGUAGE DataKinds       #-}
{-# LANGUAGE TemplateHaskell #-}

module Model
     ( module Model
     ) where

import           Phenotype.TH.Description
import           Phenotype.TH.ReactionNetwork

import           Data
import           Functions

neuroreactions :: Cocktail -> GenomeBuilder [Reaction'D Factor]
neuroreactions cocktail =
    do inhib1 <- conF <$> buildParam "External inhibition parameter 1" real
       inhib2 <- conF <$> buildParam "External inhibition parameter 2" real
       viral1 <- conF <$> buildParam "External activation parameter 1" real
       viral2 <- conF <$> buildParam "External activation parameter 2" real
       -- NOTE: inhib2 and viral2 are placeholders for future use. They are not used in the fitting process but add another variable that can be modified without refitting.
       sequence $
           [ transcription PTB $
             background
             `inhibitedBy` c MiRs
             `inhibitedByConstant` (case cocktail of PTBdepletion -> inhib1; _ -> 0)
           , transcription NPTB $
             background
             `inhibitedBy` c PTB
             `inhibitedBy` c MiRs
           , transcription MiRs $
             background
             `inhibitedBy` c RESTc
             `activatedBy` c NPTB    --Added
             `activatedByConstant` (case cocktail of Cocktail10 -> viral1; _ -> 0)
           , transcription RESTc $
             background
             `inhibitedBy` c MiRs
             `activatedBy` c PTB
             `inhibitedByConstant` (case cocktail of Cocktail10 -> inhib1; RESTi -> inhib1; _ -> 0)
           , transcription EndoNeuroTFs $
             background
             `inhibitedBy` c RESTc
           ] ++ map decay [PTB, NPTB, MiRs, RESTc, EndoNeuroTFs]
