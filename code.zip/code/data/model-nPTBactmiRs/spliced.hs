src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zh0
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZhD
                      p_a1ZgZ = double g_a1ZgY
                      (g_a1ZgY, gpart_a1ZhD) = Genome.Split.split gpart_a1ZhC
                      p_a1ZgX = double g_a1ZgW
                      (g_a1ZgW, gpart_a1ZhC) = Genome.Split.split gpart_a1ZhB
                      p_a1ZgV = double g_a1ZgU
                      (g_a1ZgU, gpart_a1ZhB) = Genome.Split.split gpart_a1ZhA
                      p_a1ZgT = double g_a1ZgS
                      (g_a1ZgS, gpart_a1ZhA) = Genome.Split.split gpart_a1Zhz
                      p_a1ZgR = double g_a1ZgQ
                      (g_a1ZgQ, gpart_a1Zhz) = Genome.Split.split gpart_a1Zhy
                      p_a1ZgP = Functions.belowten' g_a1ZgO
                      (g_a1ZgO, gpart_a1Zhy) = Genome.Split.split gpart_a1Zhx
                      p_a1ZgN = double g_a1ZgM
                      (g_a1ZgM, gpart_a1Zhx) = Genome.Split.split gpart_a1Zhw
                      p_a1ZgL = double g_a1ZgK
                      (g_a1ZgK, gpart_a1Zhw) = Genome.Split.split gpart_a1Zhv
                      p_a1ZgJ = double g_a1ZgI
                      (g_a1ZgI, gpart_a1Zhv) = Genome.Split.split gpart_a1Zhu
                      p_a1ZgH = Functions.belowten' g_a1ZgG
                      (g_a1ZgG, gpart_a1Zhu) = Genome.Split.split gpart_a1Zht
                      p_a1ZgF = double g_a1ZgE
                      (g_a1ZgE, gpart_a1Zht) = Genome.Split.split gpart_a1Zhs
                      p_a1ZgD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgC
                      (g_a1ZgC, gpart_a1Zhs) = Genome.Split.split gpart_a1Zhr
                      p_a1ZgB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgA
                      (g_a1ZgA, gpart_a1Zhr) = Genome.Split.split gpart_a1Zhq
                      p_a1Zgz = Functions.belowten' g_a1Zgy
                      (g_a1Zgy, gpart_a1Zhq) = Genome.Split.split gpart_a1Zhp
                      p_a1Zgx = double g_a1Zgw
                      (g_a1Zgw, gpart_a1Zhp) = Genome.Split.split gpart_a1Zho
                      p_a1Zgv = double g_a1Zgu
                      (g_a1Zgu, gpart_a1Zho) = Genome.Split.split gpart_a1Zhn
                      p_a1Zgt = double g_a1Zgs
                      (g_a1Zgs, gpart_a1Zhn) = Genome.Split.split gpart_a1Zhm
                      p_a1Zgr = Functions.belowten' g_a1Zgq
                      (g_a1Zgq, gpart_a1Zhm) = Genome.Split.split gpart_a1Zhl
                      p_a1Zgp = double g_a1Zgo
                      (g_a1Zgo, gpart_a1Zhl) = Genome.Split.split gpart_a1Zhk
                      p_a1Zgn = Functions.belowten' g_a1Zgm
                      (g_a1Zgm, gpart_a1Zhk) = Genome.Split.split gpart_a1Zhj
                      p_a1Zgl = double g_a1Zgk
                      (g_a1Zgk, gpart_a1Zhj) = Genome.Split.split gpart_a1Zhi
                      p_a1Zgj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgi
                      (g_a1Zgi, gpart_a1Zhi) = Genome.Split.split gpart_a1Zhh
                      p_a1Zgh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgg
                      (g_a1Zgg, gpart_a1Zhh) = Genome.Split.split gpart_a1Zhg
                      p_a1Zgf = double g_a1Zge
                      (g_a1Zge, gpart_a1Zhg) = Genome.Split.split gpart_a1Zhf
                      p_a1Zgd = Functions.belowten' g_a1Zgc
                      (g_a1Zgc, gpart_a1Zhf) = Genome.Split.split gpart_a1Zhe
                      p_a1Zgb = double g_a1Zga
                      (g_a1Zga, gpart_a1Zhe) = Genome.Split.split gpart_a1Zhd
                      p_a1Zg9 = Functions.belowten' g_a1Zg8
                      (g_a1Zg8, gpart_a1Zhd) = Genome.Split.split gpart_a1Zhc
                      p_a1Zg7 = double g_a1Zg6
                      (g_a1Zg6, gpart_a1Zhc) = Genome.Split.split gpart_a1Zhb
                      p_a1Zg5 = double g_a1Zg4
                      (g_a1Zg4, gpart_a1Zhb) = Genome.Split.split gpart_a1Zha
                      p_a1Zg3 = Functions.belowten' g_a1Zg2
                      (g_a1Zg2, gpart_a1Zha) = Genome.Split.split gpart_a1Zh9
                      p_a1Zg1 = double g_a1Zg0
                      (g_a1Zg0, gpart_a1Zh9) = Genome.Split.split gpart_a1Zh8
                      p_a1ZfZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfY
                      (g_a1ZfY, gpart_a1Zh8) = Genome.Split.split gpart_a1Zh7
                      p_a1ZfX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfW
                      (g_a1ZfW, gpart_a1Zh7) = Genome.Split.split gpart_a1Zh6
                      p_a1ZfV = double g_a1ZfU
                      (g_a1ZfU, gpart_a1Zh6) = Genome.Split.split gpart_a1Zh5
                      p_a1ZfT = double g_a1ZfS
                      (g_a1ZfS, gpart_a1Zh5) = Genome.Split.split gpart_a1Zh4
                      p_a1ZfR = double g_a1ZfQ
                      (g_a1ZfQ, gpart_a1Zh4) = Genome.Split.split gpart_a1Zh3
                      p_a1ZfP = double g_a1ZfO
                      (g_a1ZfO, gpart_a1Zh3) = Genome.Split.split gpart_a1Zh2
                      p_a1ZfN = double g_a1ZfM
                      (g_a1ZfM, gpart_a1Zh2) = Genome.Split.split genome_a1Zh0
                    in  \ x_a1ZhE
                          -> let
                               c_PTB_a1ZhH
                                 = ((Data.Fixed.Vector.toVector x_a1ZhE) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZhF
                                 = ((Data.Fixed.Vector.toVector x_a1ZhE) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZhL
                                 = ((Data.Fixed.Vector.toVector x_a1ZhE) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZhO
                                 = ((Data.Fixed.Vector.toVector x_a1ZhE) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZhY
                                 = ((Data.Fixed.Vector.toVector x_a1ZhE) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZfV / (1 + ((c_MiRs_a1ZhF / p_a1Zg1) ** p_a1Zg3)))
                                    + (negate (p_a1ZgR * c_PTB_a1ZhH))),
                                   ((p_a1Zg5
                                     / (1
                                        + (((c_MiRs_a1ZhF / p_a1Zg7) ** p_a1Zg9)
                                           + ((c_PTB_a1ZhH / p_a1Zgb) ** p_a1Zgd))))
                                    + (negate (p_a1ZgT * c_NPTB_a1ZhL))),
                                   ((p_a1Zgf
                                     * ((p_a1Zgt
                                         + (((p_a1ZfR / p_a1Zgh) ** p_a1Zgj)
                                            + ((c_NPTB_a1ZhL / p_a1Zgl) ** p_a1Zgn)))
                                        / (((1 + p_a1Zgt)
                                            + (((p_a1ZfR / p_a1Zgh) ** p_a1Zgj)
                                               + ((c_NPTB_a1ZhL / p_a1Zgl) ** p_a1Zgn)))
                                           + ((c_RESTc_a1ZhO / p_a1Zgp) ** p_a1Zgr))))
                                    + (negate (p_a1ZgV * c_MiRs_a1ZhF))),
                                   ((p_a1Zgv
                                     * ((p_a1ZgJ + ((c_PTB_a1ZhH / p_a1Zgx) ** p_a1Zgz))
                                        / (((1 + p_a1ZgJ) + ((c_PTB_a1ZhH / p_a1Zgx) ** p_a1Zgz))
                                           + (((p_a1ZfN / p_a1ZgB) ** p_a1ZgD)
                                              + ((c_MiRs_a1ZhF / p_a1ZgF) ** p_a1ZgH)))))
                                    + (negate (p_a1ZgX * c_RESTc_a1ZhO))),
                                   ((p_a1ZgL / (1 + ((c_RESTc_a1ZhO / p_a1ZgN) ** p_a1ZgP)))
                                    + (negate (p_a1ZgZ * c_EndoNeuroTFs_a1ZhY)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483593",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483595",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483613",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483615",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483633",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483635",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zh0
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZiA
                            p_a1ZgZ = double g_a1ZgY
                            (g_a1ZgY, gpart_a1ZiA) = Genome.Split.split gpart_a1Ziz
                            p_a1ZgX = double g_a1ZgW
                            (g_a1ZgW, gpart_a1Ziz) = Genome.Split.split gpart_a1Ziy
                            p_a1ZgV = double g_a1ZgU
                            (g_a1ZgU, gpart_a1Ziy) = Genome.Split.split gpart_a1Zix
                            p_a1ZgT = double g_a1ZgS
                            (g_a1ZgS, gpart_a1Zix) = Genome.Split.split gpart_a1Ziw
                            p_a1ZgR = double g_a1ZgQ
                            (g_a1ZgQ, gpart_a1Ziw) = Genome.Split.split gpart_a1Ziv
                            p_a1ZgP = Functions.belowten' g_a1ZgO
                            (g_a1ZgO, gpart_a1Ziv) = Genome.Split.split gpart_a1Ziu
                            p_a1ZgN = double g_a1ZgM
                            (g_a1ZgM, gpart_a1Ziu) = Genome.Split.split gpart_a1Zit
                            p_a1ZgL = double g_a1ZgK
                            (g_a1ZgK, gpart_a1Zit) = Genome.Split.split gpart_a1Zis
                            p_a1ZgJ = double g_a1ZgI
                            (g_a1ZgI, gpart_a1Zis) = Genome.Split.split gpart_a1Zir
                            p_a1ZgH = Functions.belowten' g_a1ZgG
                            (g_a1ZgG, gpart_a1Zir) = Genome.Split.split gpart_a1Ziq
                            p_a1ZgF = double g_a1ZgE
                            (g_a1ZgE, gpart_a1Ziq) = Genome.Split.split gpart_a1Zip
                            p_a1ZgD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgC
                            (g_a1ZgC, gpart_a1Zip) = Genome.Split.split gpart_a1Zio
                            p_a1ZgB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZgA
                            (g_a1ZgA, gpart_a1Zio) = Genome.Split.split gpart_a1Zin
                            p_a1Zgz = Functions.belowten' g_a1Zgy
                            (g_a1Zgy, gpart_a1Zin) = Genome.Split.split gpart_a1Zim
                            p_a1Zgx = double g_a1Zgw
                            (g_a1Zgw, gpart_a1Zim) = Genome.Split.split gpart_a1Zil
                            p_a1Zgv = double g_a1Zgu
                            (g_a1Zgu, gpart_a1Zil) = Genome.Split.split gpart_a1Zik
                            p_a1Zgt = double g_a1Zgs
                            (g_a1Zgs, gpart_a1Zik) = Genome.Split.split gpart_a1Zij
                            p_a1Zgr = Functions.belowten' g_a1Zgq
                            (g_a1Zgq, gpart_a1Zij) = Genome.Split.split gpart_a1Zii
                            p_a1Zgp = double g_a1Zgo
                            (g_a1Zgo, gpart_a1Zii) = Genome.Split.split gpart_a1Zih
                            p_a1Zgn = Functions.belowten' g_a1Zgm
                            (g_a1Zgm, gpart_a1Zih) = Genome.Split.split gpart_a1Zig
                            p_a1Zgl = double g_a1Zgk
                            (g_a1Zgk, gpart_a1Zig) = Genome.Split.split gpart_a1Zif
                            p_a1Zgj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgi
                            (g_a1Zgi, gpart_a1Zif) = Genome.Split.split gpart_a1Zie
                            p_a1Zgh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zgg
                            (g_a1Zgg, gpart_a1Zie) = Genome.Split.split gpart_a1Zid
                            p_a1Zgf = double g_a1Zge
                            (g_a1Zge, gpart_a1Zid) = Genome.Split.split gpart_a1Zic
                            p_a1Zgd = Functions.belowten' g_a1Zgc
                            (g_a1Zgc, gpart_a1Zic) = Genome.Split.split gpart_a1Zib
                            p_a1Zgb = double g_a1Zga
                            (g_a1Zga, gpart_a1Zib) = Genome.Split.split gpart_a1Zia
                            p_a1Zg9 = Functions.belowten' g_a1Zg8
                            (g_a1Zg8, gpart_a1Zia) = Genome.Split.split gpart_a1Zi9
                            p_a1Zg7 = double g_a1Zg6
                            (g_a1Zg6, gpart_a1Zi9) = Genome.Split.split gpart_a1Zi8
                            p_a1Zg5 = double g_a1Zg4
                            (g_a1Zg4, gpart_a1Zi8) = Genome.Split.split gpart_a1Zi7
                            p_a1Zg3 = Functions.belowten' g_a1Zg2
                            (g_a1Zg2, gpart_a1Zi7) = Genome.Split.split gpart_a1Zi6
                            p_a1Zg1 = double g_a1Zg0
                            (g_a1Zg0, gpart_a1Zi6) = Genome.Split.split gpart_a1Zi5
                            p_a1ZfZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfY
                            (g_a1ZfY, gpart_a1Zi5) = Genome.Split.split gpart_a1Zi4
                            p_a1ZfX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfW
                            (g_a1ZfW, gpart_a1Zi4) = Genome.Split.split gpart_a1Zi3
                            p_a1ZfV = double g_a1ZfU
                            (g_a1ZfU, gpart_a1Zi3) = Genome.Split.split gpart_a1Zi2
                            p_a1ZfT = double g_a1ZfS
                            (g_a1ZfS, gpart_a1Zi2) = Genome.Split.split gpart_a1Zi1
                            p_a1ZfR = double g_a1ZfQ
                            (g_a1ZfQ, gpart_a1Zi1) = Genome.Split.split gpart_a1Zi0
                            p_a1ZfP = double g_a1ZfO
                            (g_a1ZfO, gpart_a1Zi0) = Genome.Split.split gpart_a1ZhZ
                            p_a1ZfN = double g_a1ZfM
                            (g_a1ZfM, gpart_a1ZhZ) = Genome.Split.split genome_a1Zh0
                          in
                            \ desc_a1Zh1
                              -> case desc_a1Zh1 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfN)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfP)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfR)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfT)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfV)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfX)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfZ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg1)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg3)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg5)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg7)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg9)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgb)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgd)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgf)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgh)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgj)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgl)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgn)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgp)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgr)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgt)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgv)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgx)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgz)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgB)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgD)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgF)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgH)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgJ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgL)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgN)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgP)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgR)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgT)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgV)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgX)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZgZ)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1ZkY
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZlB
                      p_a1ZkX = double g_a1ZkW
                      (g_a1ZkW, gpart_a1ZlB) = Genome.Split.split gpart_a1ZlA
                      p_a1ZkV = double g_a1ZkU
                      (g_a1ZkU, gpart_a1ZlA) = Genome.Split.split gpart_a1Zlz
                      p_a1ZkT = double g_a1ZkS
                      (g_a1ZkS, gpart_a1Zlz) = Genome.Split.split gpart_a1Zly
                      p_a1ZkR = double g_a1ZkQ
                      (g_a1ZkQ, gpart_a1Zly) = Genome.Split.split gpart_a1Zlx
                      p_a1ZkP = double g_a1ZkO
                      (g_a1ZkO, gpart_a1Zlx) = Genome.Split.split gpart_a1Zlw
                      p_a1ZkN = Functions.belowten' g_a1ZkM
                      (g_a1ZkM, gpart_a1Zlw) = Genome.Split.split gpart_a1Zlv
                      p_a1ZkL = double g_a1ZkK
                      (g_a1ZkK, gpart_a1Zlv) = Genome.Split.split gpart_a1Zlu
                      p_a1ZkJ = double g_a1ZkI
                      (g_a1ZkI, gpart_a1Zlu) = Genome.Split.split gpart_a1Zlt
                      p_a1ZkH = double g_a1ZkG
                      (g_a1ZkG, gpart_a1Zlt) = Genome.Split.split gpart_a1Zls
                      p_a1ZkF = Functions.belowten' g_a1ZkE
                      (g_a1ZkE, gpart_a1Zls) = Genome.Split.split gpart_a1Zlr
                      p_a1ZkD = double g_a1ZkC
                      (g_a1ZkC, gpart_a1Zlr) = Genome.Split.split gpart_a1Zlq
                      p_a1ZkB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkA
                      (g_a1ZkA, gpart_a1Zlq) = Genome.Split.split gpart_a1Zlp
                      p_a1Zkz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zky
                      (g_a1Zky, gpart_a1Zlp) = Genome.Split.split gpart_a1Zlo
                      p_a1Zkx = Functions.belowten' g_a1Zkw
                      (g_a1Zkw, gpart_a1Zlo) = Genome.Split.split gpart_a1Zln
                      p_a1Zkv = double g_a1Zku
                      (g_a1Zku, gpart_a1Zln) = Genome.Split.split gpart_a1Zlm
                      p_a1Zkt = double g_a1Zks
                      (g_a1Zks, gpart_a1Zlm) = Genome.Split.split gpart_a1Zll
                      p_a1Zkr = double g_a1Zkq
                      (g_a1Zkq, gpart_a1Zll) = Genome.Split.split gpart_a1Zlk
                      p_a1Zkp = Functions.belowten' g_a1Zko
                      (g_a1Zko, gpart_a1Zlk) = Genome.Split.split gpart_a1Zlj
                      p_a1Zkn = double g_a1Zkm
                      (g_a1Zkm, gpart_a1Zlj) = Genome.Split.split gpart_a1Zli
                      p_a1Zkl = Functions.belowten' g_a1Zkk
                      (g_a1Zkk, gpart_a1Zli) = Genome.Split.split gpart_a1Zlh
                      p_a1Zkj = double g_a1Zki
                      (g_a1Zki, gpart_a1Zlh) = Genome.Split.split gpart_a1Zlg
                      p_a1Zkh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkg
                      (g_a1Zkg, gpart_a1Zlg) = Genome.Split.split gpart_a1Zlf
                      p_a1Zkf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zke
                      (g_a1Zke, gpart_a1Zlf) = Genome.Split.split gpart_a1Zle
                      p_a1Zkd = double g_a1Zkc
                      (g_a1Zkc, gpart_a1Zle) = Genome.Split.split gpart_a1Zld
                      p_a1Zkb = Functions.belowten' g_a1Zka
                      (g_a1Zka, gpart_a1Zld) = Genome.Split.split gpart_a1Zlc
                      p_a1Zk9 = double g_a1Zk8
                      (g_a1Zk8, gpart_a1Zlc) = Genome.Split.split gpart_a1Zlb
                      p_a1Zk7 = Functions.belowten' g_a1Zk6
                      (g_a1Zk6, gpart_a1Zlb) = Genome.Split.split gpart_a1Zla
                      p_a1Zk5 = double g_a1Zk4
                      (g_a1Zk4, gpart_a1Zla) = Genome.Split.split gpart_a1Zl9
                      p_a1Zk3 = double g_a1Zk2
                      (g_a1Zk2, gpart_a1Zl9) = Genome.Split.split gpart_a1Zl8
                      p_a1Zk1 = Functions.belowten' g_a1Zk0
                      (g_a1Zk0, gpart_a1Zl8) = Genome.Split.split gpart_a1Zl7
                      p_a1ZjZ = double g_a1ZjY
                      (g_a1ZjY, gpart_a1Zl7) = Genome.Split.split gpart_a1Zl6
                      p_a1ZjX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjW
                      (g_a1ZjW, gpart_a1Zl6) = Genome.Split.split gpart_a1Zl5
                      p_a1ZjV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjU
                      (g_a1ZjU, gpart_a1Zl5) = Genome.Split.split gpart_a1Zl4
                      p_a1ZjT = double g_a1ZjS
                      (g_a1ZjS, gpart_a1Zl4) = Genome.Split.split gpart_a1Zl3
                      p_a1ZjR = double g_a1ZjQ
                      (g_a1ZjQ, gpart_a1Zl3) = Genome.Split.split gpart_a1Zl2
                      p_a1ZjP = double g_a1ZjO
                      (g_a1ZjO, gpart_a1Zl2) = Genome.Split.split gpart_a1Zl1
                      p_a1ZjN = double g_a1ZjM
                      (g_a1ZjM, gpart_a1Zl1) = Genome.Split.split gpart_a1Zl0
                      p_a1ZjL = double g_a1ZjK
                      (g_a1ZjK, gpart_a1Zl0) = Genome.Split.split genome_a1ZkY
                    in  \ x_a1ZlC
                          -> let
                               c_PTB_a1ZlF
                                 = ((Data.Fixed.Vector.toVector x_a1ZlC) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZlD
                                 = ((Data.Fixed.Vector.toVector x_a1ZlC) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZlJ
                                 = ((Data.Fixed.Vector.toVector x_a1ZlC) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZlM
                                 = ((Data.Fixed.Vector.toVector x_a1ZlC) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZlW
                                 = ((Data.Fixed.Vector.toVector x_a1ZlC) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZjT / (1 + ((c_MiRs_a1ZlD / p_a1ZjZ) ** p_a1Zk1)))
                                    + (negate (p_a1ZkP * c_PTB_a1ZlF))),
                                   ((p_a1Zk3
                                     / (1
                                        + (((c_MiRs_a1ZlD / p_a1Zk5) ** p_a1Zk7)
                                           + ((c_PTB_a1ZlF / p_a1Zk9) ** p_a1Zkb))))
                                    + (negate (p_a1ZkR * c_NPTB_a1ZlJ))),
                                   ((p_a1Zkd
                                     * ((p_a1Zkr + ((c_NPTB_a1ZlJ / p_a1Zkj) ** p_a1Zkl))
                                        / (((1 + p_a1Zkr) + ((c_NPTB_a1ZlJ / p_a1Zkj) ** p_a1Zkl))
                                           + ((c_RESTc_a1ZlM / p_a1Zkn) ** p_a1Zkp))))
                                    + (negate (p_a1ZkT * c_MiRs_a1ZlD))),
                                   ((p_a1Zkt
                                     * ((p_a1ZkH + ((c_PTB_a1ZlF / p_a1Zkv) ** p_a1Zkx))
                                        / (((1 + p_a1ZkH) + ((c_PTB_a1ZlF / p_a1Zkv) ** p_a1Zkx))
                                           + (((p_a1ZjL / p_a1Zkz) ** p_a1ZkB)
                                              + ((c_MiRs_a1ZlD / p_a1ZkD) ** p_a1ZkF)))))
                                    + (negate (p_a1ZkV * c_RESTc_a1ZlM))),
                                   ((p_a1ZkJ / (1 + ((c_RESTc_a1ZlM / p_a1ZkL) ** p_a1ZkN)))
                                    + (negate (p_a1ZkX * c_EndoNeuroTFs_a1ZlW)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483839",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483841",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483859",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483861",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483879",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483881",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483901",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZkY
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zmy
                            p_a1ZkX = double g_a1ZkW
                            (g_a1ZkW, gpart_a1Zmy) = Genome.Split.split gpart_a1Zmx
                            p_a1ZkV = double g_a1ZkU
                            (g_a1ZkU, gpart_a1Zmx) = Genome.Split.split gpart_a1Zmw
                            p_a1ZkT = double g_a1ZkS
                            (g_a1ZkS, gpart_a1Zmw) = Genome.Split.split gpart_a1Zmv
                            p_a1ZkR = double g_a1ZkQ
                            (g_a1ZkQ, gpart_a1Zmv) = Genome.Split.split gpart_a1Zmu
                            p_a1ZkP = double g_a1ZkO
                            (g_a1ZkO, gpart_a1Zmu) = Genome.Split.split gpart_a1Zmt
                            p_a1ZkN = Functions.belowten' g_a1ZkM
                            (g_a1ZkM, gpart_a1Zmt) = Genome.Split.split gpart_a1Zms
                            p_a1ZkL = double g_a1ZkK
                            (g_a1ZkK, gpart_a1Zms) = Genome.Split.split gpart_a1Zmr
                            p_a1ZkJ = double g_a1ZkI
                            (g_a1ZkI, gpart_a1Zmr) = Genome.Split.split gpart_a1Zmq
                            p_a1ZkH = double g_a1ZkG
                            (g_a1ZkG, gpart_a1Zmq) = Genome.Split.split gpart_a1Zmp
                            p_a1ZkF = Functions.belowten' g_a1ZkE
                            (g_a1ZkE, gpart_a1Zmp) = Genome.Split.split gpart_a1Zmo
                            p_a1ZkD = double g_a1ZkC
                            (g_a1ZkC, gpart_a1Zmo) = Genome.Split.split gpart_a1Zmn
                            p_a1ZkB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZkA
                            (g_a1ZkA, gpart_a1Zmn) = Genome.Split.split gpart_a1Zmm
                            p_a1Zkz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zky
                            (g_a1Zky, gpart_a1Zmm) = Genome.Split.split gpart_a1Zml
                            p_a1Zkx = Functions.belowten' g_a1Zkw
                            (g_a1Zkw, gpart_a1Zml) = Genome.Split.split gpart_a1Zmk
                            p_a1Zkv = double g_a1Zku
                            (g_a1Zku, gpart_a1Zmk) = Genome.Split.split gpart_a1Zmj
                            p_a1Zkt = double g_a1Zks
                            (g_a1Zks, gpart_a1Zmj) = Genome.Split.split gpart_a1Zmi
                            p_a1Zkr = double g_a1Zkq
                            (g_a1Zkq, gpart_a1Zmi) = Genome.Split.split gpart_a1Zmh
                            p_a1Zkp = Functions.belowten' g_a1Zko
                            (g_a1Zko, gpart_a1Zmh) = Genome.Split.split gpart_a1Zmg
                            p_a1Zkn = double g_a1Zkm
                            (g_a1Zkm, gpart_a1Zmg) = Genome.Split.split gpart_a1Zmf
                            p_a1Zkl = Functions.belowten' g_a1Zkk
                            (g_a1Zkk, gpart_a1Zmf) = Genome.Split.split gpart_a1Zme
                            p_a1Zkj = double g_a1Zki
                            (g_a1Zki, gpart_a1Zme) = Genome.Split.split gpart_a1Zmd
                            p_a1Zkh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zkg
                            (g_a1Zkg, gpart_a1Zmd) = Genome.Split.split gpart_a1Zmc
                            p_a1Zkf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zke
                            (g_a1Zke, gpart_a1Zmc) = Genome.Split.split gpart_a1Zmb
                            p_a1Zkd = double g_a1Zkc
                            (g_a1Zkc, gpart_a1Zmb) = Genome.Split.split gpart_a1Zma
                            p_a1Zkb = Functions.belowten' g_a1Zka
                            (g_a1Zka, gpart_a1Zma) = Genome.Split.split gpart_a1Zm9
                            p_a1Zk9 = double g_a1Zk8
                            (g_a1Zk8, gpart_a1Zm9) = Genome.Split.split gpart_a1Zm8
                            p_a1Zk7 = Functions.belowten' g_a1Zk6
                            (g_a1Zk6, gpart_a1Zm8) = Genome.Split.split gpart_a1Zm7
                            p_a1Zk5 = double g_a1Zk4
                            (g_a1Zk4, gpart_a1Zm7) = Genome.Split.split gpart_a1Zm6
                            p_a1Zk3 = double g_a1Zk2
                            (g_a1Zk2, gpart_a1Zm6) = Genome.Split.split gpart_a1Zm5
                            p_a1Zk1 = Functions.belowten' g_a1Zk0
                            (g_a1Zk0, gpart_a1Zm5) = Genome.Split.split gpart_a1Zm4
                            p_a1ZjZ = double g_a1ZjY
                            (g_a1ZjY, gpart_a1Zm4) = Genome.Split.split gpart_a1Zm3
                            p_a1ZjX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjW
                            (g_a1ZjW, gpart_a1Zm3) = Genome.Split.split gpart_a1Zm2
                            p_a1ZjV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjU
                            (g_a1ZjU, gpart_a1Zm2) = Genome.Split.split gpart_a1Zm1
                            p_a1ZjT = double g_a1ZjS
                            (g_a1ZjS, gpart_a1Zm1) = Genome.Split.split gpart_a1Zm0
                            p_a1ZjR = double g_a1ZjQ
                            (g_a1ZjQ, gpart_a1Zm0) = Genome.Split.split gpart_a1ZlZ
                            p_a1ZjP = double g_a1ZjO
                            (g_a1ZjO, gpart_a1ZlZ) = Genome.Split.split gpart_a1ZlY
                            p_a1ZjN = double g_a1ZjM
                            (g_a1ZjM, gpart_a1ZlY) = Genome.Split.split gpart_a1ZlX
                            p_a1ZjL = double g_a1ZjK
                            (g_a1ZjK, gpart_a1ZlX) = Genome.Split.split genome_a1ZkY
                          in
                            \ desc_a1ZkZ
                              -> case desc_a1ZkZ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjL)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjN)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjP)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjR)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjT)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjV)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjX)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjZ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk1)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk3)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk5)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk7)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk9)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkb)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkd)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkf)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkh)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkj)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkl)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkn)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkp)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkr)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkt)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkv)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkx)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkz)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkB)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkD)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkF)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkH)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkJ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkL)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkN)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkP)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkR)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkT)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkV)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZkX)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1ZoW
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zpz
                      p_a1ZoV = double g_a1ZoU
                      (g_a1ZoU, gpart_a1Zpz) = Genome.Split.split gpart_a1Zpy
                      p_a1ZoT = double g_a1ZoS
                      (g_a1ZoS, gpart_a1Zpy) = Genome.Split.split gpart_a1Zpx
                      p_a1ZoR = double g_a1ZoQ
                      (g_a1ZoQ, gpart_a1Zpx) = Genome.Split.split gpart_a1Zpw
                      p_a1ZoP = double g_a1ZoO
                      (g_a1ZoO, gpart_a1Zpw) = Genome.Split.split gpart_a1Zpv
                      p_a1ZoN = double g_a1ZoM
                      (g_a1ZoM, gpart_a1Zpv) = Genome.Split.split gpart_a1Zpu
                      p_a1ZoL = Functions.belowten' g_a1ZoK
                      (g_a1ZoK, gpart_a1Zpu) = Genome.Split.split gpart_a1Zpt
                      p_a1ZoJ = double g_a1ZoI
                      (g_a1ZoI, gpart_a1Zpt) = Genome.Split.split gpart_a1Zps
                      p_a1ZoH = double g_a1ZoG
                      (g_a1ZoG, gpart_a1Zps) = Genome.Split.split gpart_a1Zpr
                      p_a1ZoF = double g_a1ZoE
                      (g_a1ZoE, gpart_a1Zpr) = Genome.Split.split gpart_a1Zpq
                      p_a1ZoD = Functions.belowten' g_a1ZoC
                      (g_a1ZoC, gpart_a1Zpq) = Genome.Split.split gpart_a1Zpp
                      p_a1ZoB = double g_a1ZoA
                      (g_a1ZoA, gpart_a1Zpp) = Genome.Split.split gpart_a1Zpo
                      p_a1Zoz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoy
                      (g_a1Zoy, gpart_a1Zpo) = Genome.Split.split gpart_a1Zpn
                      p_a1Zox
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zow
                      (g_a1Zow, gpart_a1Zpn) = Genome.Split.split gpart_a1Zpm
                      p_a1Zov = Functions.belowten' g_a1Zou
                      (g_a1Zou, gpart_a1Zpm) = Genome.Split.split gpart_a1Zpl
                      p_a1Zot = double g_a1Zos
                      (g_a1Zos, gpart_a1Zpl) = Genome.Split.split gpart_a1Zpk
                      p_a1Zor = double g_a1Zoq
                      (g_a1Zoq, gpart_a1Zpk) = Genome.Split.split gpart_a1Zpj
                      p_a1Zop = double g_a1Zoo
                      (g_a1Zoo, gpart_a1Zpj) = Genome.Split.split gpart_a1Zpi
                      p_a1Zon = Functions.belowten' g_a1Zom
                      (g_a1Zom, gpart_a1Zpi) = Genome.Split.split gpart_a1Zph
                      p_a1Zol = double g_a1Zok
                      (g_a1Zok, gpart_a1Zph) = Genome.Split.split gpart_a1Zpg
                      p_a1Zoj = Functions.belowten' g_a1Zoi
                      (g_a1Zoi, gpart_a1Zpg) = Genome.Split.split gpart_a1Zpf
                      p_a1Zoh = double g_a1Zog
                      (g_a1Zog, gpart_a1Zpf) = Genome.Split.split gpart_a1Zpe
                      p_a1Zof
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoe
                      (g_a1Zoe, gpart_a1Zpe) = Genome.Split.split gpart_a1Zpd
                      p_a1Zod
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoc
                      (g_a1Zoc, gpart_a1Zpd) = Genome.Split.split gpart_a1Zpc
                      p_a1Zob = double g_a1Zoa
                      (g_a1Zoa, gpart_a1Zpc) = Genome.Split.split gpart_a1Zpb
                      p_a1Zo9 = Functions.belowten' g_a1Zo8
                      (g_a1Zo8, gpart_a1Zpb) = Genome.Split.split gpart_a1Zpa
                      p_a1Zo7 = double g_a1Zo6
                      (g_a1Zo6, gpart_a1Zpa) = Genome.Split.split gpart_a1Zp9
                      p_a1Zo5 = Functions.belowten' g_a1Zo4
                      (g_a1Zo4, gpart_a1Zp9) = Genome.Split.split gpart_a1Zp8
                      p_a1Zo3 = double g_a1Zo2
                      (g_a1Zo2, gpart_a1Zp8) = Genome.Split.split gpart_a1Zp7
                      p_a1Zo1 = double g_a1Zo0
                      (g_a1Zo0, gpart_a1Zp7) = Genome.Split.split gpart_a1Zp6
                      p_a1ZnZ = Functions.belowten' g_a1ZnY
                      (g_a1ZnY, gpart_a1Zp6) = Genome.Split.split gpart_a1Zp5
                      p_a1ZnX = double g_a1ZnW
                      (g_a1ZnW, gpart_a1Zp5) = Genome.Split.split gpart_a1Zp4
                      p_a1ZnV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnU
                      (g_a1ZnU, gpart_a1Zp4) = Genome.Split.split gpart_a1Zp3
                      p_a1ZnT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnS
                      (g_a1ZnS, gpart_a1Zp3) = Genome.Split.split gpart_a1Zp2
                      p_a1ZnR = double g_a1ZnQ
                      (g_a1ZnQ, gpart_a1Zp2) = Genome.Split.split gpart_a1Zp1
                      p_a1ZnP = double g_a1ZnO
                      (g_a1ZnO, gpart_a1Zp1) = Genome.Split.split gpart_a1Zp0
                      p_a1ZnN = double g_a1ZnM
                      (g_a1ZnM, gpart_a1Zp0) = Genome.Split.split gpart_a1ZoZ
                      p_a1ZnL = double g_a1ZnK
                      (g_a1ZnK, gpart_a1ZoZ) = Genome.Split.split gpart_a1ZoY
                      p_a1ZnJ = double g_a1ZnI
                      (g_a1ZnI, gpart_a1ZoY) = Genome.Split.split genome_a1ZoW
                    in  \ x_a1ZpA
                          -> let
                               c_PTB_a1ZpD
                                 = ((Data.Fixed.Vector.toVector x_a1ZpA) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZpB
                                 = ((Data.Fixed.Vector.toVector x_a1ZpA) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZpH
                                 = ((Data.Fixed.Vector.toVector x_a1ZpA) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZpK
                                 = ((Data.Fixed.Vector.toVector x_a1ZpA) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZpU
                                 = ((Data.Fixed.Vector.toVector x_a1ZpA) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZnR / (1 + ((c_MiRs_a1ZpB / p_a1ZnX) ** p_a1ZnZ)))
                                    + (negate (p_a1ZoN * c_PTB_a1ZpD))),
                                   ((p_a1Zo1
                                     / (1
                                        + (((c_MiRs_a1ZpB / p_a1Zo3) ** p_a1Zo5)
                                           + ((c_PTB_a1ZpD / p_a1Zo7) ** p_a1Zo9))))
                                    + (negate (p_a1ZoP * c_NPTB_a1ZpH))),
                                   ((p_a1Zob
                                     * ((p_a1Zop + ((c_NPTB_a1ZpH / p_a1Zoh) ** p_a1Zoj))
                                        / (((1 + p_a1Zop) + ((c_NPTB_a1ZpH / p_a1Zoh) ** p_a1Zoj))
                                           + ((c_RESTc_a1ZpK / p_a1Zol) ** p_a1Zon))))
                                    + (negate (p_a1ZoR * c_MiRs_a1ZpB))),
                                   ((p_a1Zor
                                     * ((p_a1ZoF + ((c_PTB_a1ZpD / p_a1Zot) ** p_a1Zov))
                                        / (((1 + p_a1ZoF) + ((c_PTB_a1ZpD / p_a1Zot) ** p_a1Zov))
                                           + ((c_MiRs_a1ZpB / p_a1ZoB) ** p_a1ZoD))))
                                    + (negate (p_a1ZoT * c_RESTc_a1ZpK))),
                                   ((p_a1ZoH / (1 + ((c_RESTc_a1ZpK / p_a1ZoJ) ** p_a1ZoL)))
                                    + (negate (p_a1ZoV * c_EndoNeuroTFs_a1ZpU)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484085",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484087",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484091",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484093",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484105",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484107",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484125",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484127",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZoW
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zqw
                            p_a1ZoV = double g_a1ZoU
                            (g_a1ZoU, gpart_a1Zqw) = Genome.Split.split gpart_a1Zqv
                            p_a1ZoT = double g_a1ZoS
                            (g_a1ZoS, gpart_a1Zqv) = Genome.Split.split gpart_a1Zqu
                            p_a1ZoR = double g_a1ZoQ
                            (g_a1ZoQ, gpart_a1Zqu) = Genome.Split.split gpart_a1Zqt
                            p_a1ZoP = double g_a1ZoO
                            (g_a1ZoO, gpart_a1Zqt) = Genome.Split.split gpart_a1Zqs
                            p_a1ZoN = double g_a1ZoM
                            (g_a1ZoM, gpart_a1Zqs) = Genome.Split.split gpart_a1Zqr
                            p_a1ZoL = Functions.belowten' g_a1ZoK
                            (g_a1ZoK, gpart_a1Zqr) = Genome.Split.split gpart_a1Zqq
                            p_a1ZoJ = double g_a1ZoI
                            (g_a1ZoI, gpart_a1Zqq) = Genome.Split.split gpart_a1Zqp
                            p_a1ZoH = double g_a1ZoG
                            (g_a1ZoG, gpart_a1Zqp) = Genome.Split.split gpart_a1Zqo
                            p_a1ZoF = double g_a1ZoE
                            (g_a1ZoE, gpart_a1Zqo) = Genome.Split.split gpart_a1Zqn
                            p_a1ZoD = Functions.belowten' g_a1ZoC
                            (g_a1ZoC, gpart_a1Zqn) = Genome.Split.split gpart_a1Zqm
                            p_a1ZoB = double g_a1ZoA
                            (g_a1ZoA, gpart_a1Zqm) = Genome.Split.split gpart_a1Zql
                            p_a1Zoz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoy
                            (g_a1Zoy, gpart_a1Zql) = Genome.Split.split gpart_a1Zqk
                            p_a1Zox
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zow
                            (g_a1Zow, gpart_a1Zqk) = Genome.Split.split gpart_a1Zqj
                            p_a1Zov = Functions.belowten' g_a1Zou
                            (g_a1Zou, gpart_a1Zqj) = Genome.Split.split gpart_a1Zqi
                            p_a1Zot = double g_a1Zos
                            (g_a1Zos, gpart_a1Zqi) = Genome.Split.split gpart_a1Zqh
                            p_a1Zor = double g_a1Zoq
                            (g_a1Zoq, gpart_a1Zqh) = Genome.Split.split gpart_a1Zqg
                            p_a1Zop = double g_a1Zoo
                            (g_a1Zoo, gpart_a1Zqg) = Genome.Split.split gpart_a1Zqf
                            p_a1Zon = Functions.belowten' g_a1Zom
                            (g_a1Zom, gpart_a1Zqf) = Genome.Split.split gpart_a1Zqe
                            p_a1Zol = double g_a1Zok
                            (g_a1Zok, gpart_a1Zqe) = Genome.Split.split gpart_a1Zqd
                            p_a1Zoj = Functions.belowten' g_a1Zoi
                            (g_a1Zoi, gpart_a1Zqd) = Genome.Split.split gpart_a1Zqc
                            p_a1Zoh = double g_a1Zog
                            (g_a1Zog, gpart_a1Zqc) = Genome.Split.split gpart_a1Zqb
                            p_a1Zof
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoe
                            (g_a1Zoe, gpart_a1Zqb) = Genome.Split.split gpart_a1Zqa
                            p_a1Zod
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zoc
                            (g_a1Zoc, gpart_a1Zqa) = Genome.Split.split gpart_a1Zq9
                            p_a1Zob = double g_a1Zoa
                            (g_a1Zoa, gpart_a1Zq9) = Genome.Split.split gpart_a1Zq8
                            p_a1Zo9 = Functions.belowten' g_a1Zo8
                            (g_a1Zo8, gpart_a1Zq8) = Genome.Split.split gpart_a1Zq7
                            p_a1Zo7 = double g_a1Zo6
                            (g_a1Zo6, gpart_a1Zq7) = Genome.Split.split gpart_a1Zq6
                            p_a1Zo5 = Functions.belowten' g_a1Zo4
                            (g_a1Zo4, gpart_a1Zq6) = Genome.Split.split gpart_a1Zq5
                            p_a1Zo3 = double g_a1Zo2
                            (g_a1Zo2, gpart_a1Zq5) = Genome.Split.split gpart_a1Zq4
                            p_a1Zo1 = double g_a1Zo0
                            (g_a1Zo0, gpart_a1Zq4) = Genome.Split.split gpart_a1Zq3
                            p_a1ZnZ = Functions.belowten' g_a1ZnY
                            (g_a1ZnY, gpart_a1Zq3) = Genome.Split.split gpart_a1Zq2
                            p_a1ZnX = double g_a1ZnW
                            (g_a1ZnW, gpart_a1Zq2) = Genome.Split.split gpart_a1Zq1
                            p_a1ZnV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnU
                            (g_a1ZnU, gpart_a1Zq1) = Genome.Split.split gpart_a1Zq0
                            p_a1ZnT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnS
                            (g_a1ZnS, gpart_a1Zq0) = Genome.Split.split gpart_a1ZpZ
                            p_a1ZnR = double g_a1ZnQ
                            (g_a1ZnQ, gpart_a1ZpZ) = Genome.Split.split gpart_a1ZpY
                            p_a1ZnP = double g_a1ZnO
                            (g_a1ZnO, gpart_a1ZpY) = Genome.Split.split gpart_a1ZpX
                            p_a1ZnN = double g_a1ZnM
                            (g_a1ZnM, gpart_a1ZpX) = Genome.Split.split gpart_a1ZpW
                            p_a1ZnL = double g_a1ZnK
                            (g_a1ZnK, gpart_a1ZpW) = Genome.Split.split gpart_a1ZpV
                            p_a1ZnJ = double g_a1ZnI
                            (g_a1ZnI, gpart_a1ZpV) = Genome.Split.split genome_a1ZoW
                          in
                            \ desc_a1ZoX
                              -> case desc_a1ZoX of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnJ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnL)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnN)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnP)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnR)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnT)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnV)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnX)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnZ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo1)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo3)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo5)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo7)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo9)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zob)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zod)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zof)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoh)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoj)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zol)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zon)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zop)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zor)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zot)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zov)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zox)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoz)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoB)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoD)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoF)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoH)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoJ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoL)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoN)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoP)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoR)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoT)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZoV)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1ZsU
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Ztx
                      p_a1ZsT = double g_a1ZsS
                      (g_a1ZsS, gpart_a1Ztx) = Genome.Split.split gpart_a1Ztw
                      p_a1ZsR = double g_a1ZsQ
                      (g_a1ZsQ, gpart_a1Ztw) = Genome.Split.split gpart_a1Ztv
                      p_a1ZsP = double g_a1ZsO
                      (g_a1ZsO, gpart_a1Ztv) = Genome.Split.split gpart_a1Ztu
                      p_a1ZsN = double g_a1ZsM
                      (g_a1ZsM, gpart_a1Ztu) = Genome.Split.split gpart_a1Ztt
                      p_a1ZsL = double g_a1ZsK
                      (g_a1ZsK, gpart_a1Ztt) = Genome.Split.split gpart_a1Zts
                      p_a1ZsJ = Functions.belowten' g_a1ZsI
                      (g_a1ZsI, gpart_a1Zts) = Genome.Split.split gpart_a1Ztr
                      p_a1ZsH = double g_a1ZsG
                      (g_a1ZsG, gpart_a1Ztr) = Genome.Split.split gpart_a1Ztq
                      p_a1ZsF = double g_a1ZsE
                      (g_a1ZsE, gpart_a1Ztq) = Genome.Split.split gpart_a1Ztp
                      p_a1ZsD = double g_a1ZsC
                      (g_a1ZsC, gpart_a1Ztp) = Genome.Split.split gpart_a1Zto
                      p_a1ZsB = Functions.belowten' g_a1ZsA
                      (g_a1ZsA, gpart_a1Zto) = Genome.Split.split gpart_a1Ztn
                      p_a1Zsz = double g_a1Zsy
                      (g_a1Zsy, gpart_a1Ztn) = Genome.Split.split gpart_a1Ztm
                      p_a1Zsx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsw
                      (g_a1Zsw, gpart_a1Ztm) = Genome.Split.split gpart_a1Ztl
                      p_a1Zsv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsu
                      (g_a1Zsu, gpart_a1Ztl) = Genome.Split.split gpart_a1Ztk
                      p_a1Zst = Functions.belowten' g_a1Zss
                      (g_a1Zss, gpart_a1Ztk) = Genome.Split.split gpart_a1Ztj
                      p_a1Zsr = double g_a1Zsq
                      (g_a1Zsq, gpart_a1Ztj) = Genome.Split.split gpart_a1Zti
                      p_a1Zsp = double g_a1Zso
                      (g_a1Zso, gpart_a1Zti) = Genome.Split.split gpart_a1Zth
                      p_a1Zsn = double g_a1Zsm
                      (g_a1Zsm, gpart_a1Zth) = Genome.Split.split gpart_a1Ztg
                      p_a1Zsl = Functions.belowten' g_a1Zsk
                      (g_a1Zsk, gpart_a1Ztg) = Genome.Split.split gpart_a1Ztf
                      p_a1Zsj = double g_a1Zsi
                      (g_a1Zsi, gpart_a1Ztf) = Genome.Split.split gpart_a1Zte
                      p_a1Zsh = Functions.belowten' g_a1Zsg
                      (g_a1Zsg, gpart_a1Zte) = Genome.Split.split gpart_a1Ztd
                      p_a1Zsf = double g_a1Zse
                      (g_a1Zse, gpart_a1Ztd) = Genome.Split.split gpart_a1Ztc
                      p_a1Zsd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsc
                      (g_a1Zsc, gpart_a1Ztc) = Genome.Split.split gpart_a1Ztb
                      p_a1Zsb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsa
                      (g_a1Zsa, gpart_a1Ztb) = Genome.Split.split gpart_a1Zta
                      p_a1Zs9 = double g_a1Zs8
                      (g_a1Zs8, gpart_a1Zta) = Genome.Split.split gpart_a1Zt9
                      p_a1Zs7 = Functions.belowten' g_a1Zs6
                      (g_a1Zs6, gpart_a1Zt9) = Genome.Split.split gpart_a1Zt8
                      p_a1Zs5 = double g_a1Zs4
                      (g_a1Zs4, gpart_a1Zt8) = Genome.Split.split gpart_a1Zt7
                      p_a1Zs3 = Functions.belowten' g_a1Zs2
                      (g_a1Zs2, gpart_a1Zt7) = Genome.Split.split gpart_a1Zt6
                      p_a1Zs1 = double g_a1Zs0
                      (g_a1Zs0, gpart_a1Zt6) = Genome.Split.split gpart_a1Zt5
                      p_a1ZrZ = double g_a1ZrY
                      (g_a1ZrY, gpart_a1Zt5) = Genome.Split.split gpart_a1Zt4
                      p_a1ZrX = Functions.belowten' g_a1ZrW
                      (g_a1ZrW, gpart_a1Zt4) = Genome.Split.split gpart_a1Zt3
                      p_a1ZrV = double g_a1ZrU
                      (g_a1ZrU, gpart_a1Zt3) = Genome.Split.split gpart_a1Zt2
                      p_a1ZrT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrS
                      (g_a1ZrS, gpart_a1Zt2) = Genome.Split.split gpart_a1Zt1
                      p_a1ZrR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrQ
                      (g_a1ZrQ, gpart_a1Zt1) = Genome.Split.split gpart_a1Zt0
                      p_a1ZrP = double g_a1ZrO
                      (g_a1ZrO, gpart_a1Zt0) = Genome.Split.split gpart_a1ZsZ
                      p_a1ZrN = double g_a1ZrM
                      (g_a1ZrM, gpart_a1ZsZ) = Genome.Split.split gpart_a1ZsY
                      p_a1ZrL = double g_a1ZrK
                      (g_a1ZrK, gpart_a1ZsY) = Genome.Split.split gpart_a1ZsX
                      p_a1ZrJ = double g_a1ZrI
                      (g_a1ZrI, gpart_a1ZsX) = Genome.Split.split gpart_a1ZsW
                      p_a1ZrH = double g_a1ZrG
                      (g_a1ZrG, gpart_a1ZsW) = Genome.Split.split genome_a1ZsU
                    in  \ x_a1Zty
                          -> let
                               c_PTB_a1ZtB
                                 = ((Data.Fixed.Vector.toVector x_a1Zty) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Ztz
                                 = ((Data.Fixed.Vector.toVector x_a1Zty) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZtF
                                 = ((Data.Fixed.Vector.toVector x_a1Zty) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZtI
                                 = ((Data.Fixed.Vector.toVector x_a1Zty) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1ZtS
                                 = ((Data.Fixed.Vector.toVector x_a1Zty) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZrP
                                     / (1
                                        + (((p_a1ZrH / p_a1ZrR) ** p_a1ZrT)
                                           + ((c_MiRs_a1Ztz / p_a1ZrV) ** p_a1ZrX))))
                                    + (negate (p_a1ZsL * c_PTB_a1ZtB))),
                                   ((p_a1ZrZ
                                     / (1
                                        + (((c_MiRs_a1Ztz / p_a1Zs1) ** p_a1Zs3)
                                           + ((c_PTB_a1ZtB / p_a1Zs5) ** p_a1Zs7))))
                                    + (negate (p_a1ZsN * c_NPTB_a1ZtF))),
                                   ((p_a1Zs9
                                     * ((p_a1Zsn + ((c_NPTB_a1ZtF / p_a1Zsf) ** p_a1Zsh))
                                        / (((1 + p_a1Zsn) + ((c_NPTB_a1ZtF / p_a1Zsf) ** p_a1Zsh))
                                           + ((c_RESTc_a1ZtI / p_a1Zsj) ** p_a1Zsl))))
                                    + (negate (p_a1ZsP * c_MiRs_a1Ztz))),
                                   ((p_a1Zsp
                                     * ((p_a1ZsD + ((c_PTB_a1ZtB / p_a1Zsr) ** p_a1Zst))
                                        / (((1 + p_a1ZsD) + ((c_PTB_a1ZtB / p_a1Zsr) ** p_a1Zst))
                                           + ((c_MiRs_a1Ztz / p_a1Zsz) ** p_a1ZsB))))
                                    + (negate (p_a1ZsR * c_RESTc_a1ZtI))),
                                   ((p_a1ZsF / (1 + ((c_RESTc_a1ZtI / p_a1ZsH) ** p_a1ZsJ)))
                                    + (negate (p_a1ZsT * c_EndoNeuroTFs_a1ZtS)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484331",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484333",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484351",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484353",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484355",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484371",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484373",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZsU
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zuu
                            p_a1ZsT = double g_a1ZsS
                            (g_a1ZsS, gpart_a1Zuu) = Genome.Split.split gpart_a1Zut
                            p_a1ZsR = double g_a1ZsQ
                            (g_a1ZsQ, gpart_a1Zut) = Genome.Split.split gpart_a1Zus
                            p_a1ZsP = double g_a1ZsO
                            (g_a1ZsO, gpart_a1Zus) = Genome.Split.split gpart_a1Zur
                            p_a1ZsN = double g_a1ZsM
                            (g_a1ZsM, gpart_a1Zur) = Genome.Split.split gpart_a1Zuq
                            p_a1ZsL = double g_a1ZsK
                            (g_a1ZsK, gpart_a1Zuq) = Genome.Split.split gpart_a1Zup
                            p_a1ZsJ = Functions.belowten' g_a1ZsI
                            (g_a1ZsI, gpart_a1Zup) = Genome.Split.split gpart_a1Zuo
                            p_a1ZsH = double g_a1ZsG
                            (g_a1ZsG, gpart_a1Zuo) = Genome.Split.split gpart_a1Zun
                            p_a1ZsF = double g_a1ZsE
                            (g_a1ZsE, gpart_a1Zun) = Genome.Split.split gpart_a1Zum
                            p_a1ZsD = double g_a1ZsC
                            (g_a1ZsC, gpart_a1Zum) = Genome.Split.split gpart_a1Zul
                            p_a1ZsB = Functions.belowten' g_a1ZsA
                            (g_a1ZsA, gpart_a1Zul) = Genome.Split.split gpart_a1Zuk
                            p_a1Zsz = double g_a1Zsy
                            (g_a1Zsy, gpart_a1Zuk) = Genome.Split.split gpart_a1Zuj
                            p_a1Zsx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsw
                            (g_a1Zsw, gpart_a1Zuj) = Genome.Split.split gpart_a1Zui
                            p_a1Zsv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsu
                            (g_a1Zsu, gpart_a1Zui) = Genome.Split.split gpart_a1Zuh
                            p_a1Zst = Functions.belowten' g_a1Zss
                            (g_a1Zss, gpart_a1Zuh) = Genome.Split.split gpart_a1Zug
                            p_a1Zsr = double g_a1Zsq
                            (g_a1Zsq, gpart_a1Zug) = Genome.Split.split gpart_a1Zuf
                            p_a1Zsp = double g_a1Zso
                            (g_a1Zso, gpart_a1Zuf) = Genome.Split.split gpart_a1Zue
                            p_a1Zsn = double g_a1Zsm
                            (g_a1Zsm, gpart_a1Zue) = Genome.Split.split gpart_a1Zud
                            p_a1Zsl = Functions.belowten' g_a1Zsk
                            (g_a1Zsk, gpart_a1Zud) = Genome.Split.split gpart_a1Zuc
                            p_a1Zsj = double g_a1Zsi
                            (g_a1Zsi, gpart_a1Zuc) = Genome.Split.split gpart_a1Zub
                            p_a1Zsh = Functions.belowten' g_a1Zsg
                            (g_a1Zsg, gpart_a1Zub) = Genome.Split.split gpart_a1Zua
                            p_a1Zsf = double g_a1Zse
                            (g_a1Zse, gpart_a1Zua) = Genome.Split.split gpart_a1Zu9
                            p_a1Zsd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsc
                            (g_a1Zsc, gpart_a1Zu9) = Genome.Split.split gpart_a1Zu8
                            p_a1Zsb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zsa
                            (g_a1Zsa, gpart_a1Zu8) = Genome.Split.split gpart_a1Zu7
                            p_a1Zs9 = double g_a1Zs8
                            (g_a1Zs8, gpart_a1Zu7) = Genome.Split.split gpart_a1Zu6
                            p_a1Zs7 = Functions.belowten' g_a1Zs6
                            (g_a1Zs6, gpart_a1Zu6) = Genome.Split.split gpart_a1Zu5
                            p_a1Zs5 = double g_a1Zs4
                            (g_a1Zs4, gpart_a1Zu5) = Genome.Split.split gpart_a1Zu4
                            p_a1Zs3 = Functions.belowten' g_a1Zs2
                            (g_a1Zs2, gpart_a1Zu4) = Genome.Split.split gpart_a1Zu3
                            p_a1Zs1 = double g_a1Zs0
                            (g_a1Zs0, gpart_a1Zu3) = Genome.Split.split gpart_a1Zu2
                            p_a1ZrZ = double g_a1ZrY
                            (g_a1ZrY, gpart_a1Zu2) = Genome.Split.split gpart_a1Zu1
                            p_a1ZrX = Functions.belowten' g_a1ZrW
                            (g_a1ZrW, gpart_a1Zu1) = Genome.Split.split gpart_a1Zu0
                            p_a1ZrV = double g_a1ZrU
                            (g_a1ZrU, gpart_a1Zu0) = Genome.Split.split gpart_a1ZtZ
                            p_a1ZrT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrS
                            (g_a1ZrS, gpart_a1ZtZ) = Genome.Split.split gpart_a1ZtY
                            p_a1ZrR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrQ
                            (g_a1ZrQ, gpart_a1ZtY) = Genome.Split.split gpart_a1ZtX
                            p_a1ZrP = double g_a1ZrO
                            (g_a1ZrO, gpart_a1ZtX) = Genome.Split.split gpart_a1ZtW
                            p_a1ZrN = double g_a1ZrM
                            (g_a1ZrM, gpart_a1ZtW) = Genome.Split.split gpart_a1ZtV
                            p_a1ZrL = double g_a1ZrK
                            (g_a1ZrK, gpart_a1ZtV) = Genome.Split.split gpart_a1ZtU
                            p_a1ZrJ = double g_a1ZrI
                            (g_a1ZrI, gpart_a1ZtU) = Genome.Split.split gpart_a1ZtT
                            p_a1ZrH = double g_a1ZrG
                            (g_a1ZrG, gpart_a1ZtT) = Genome.Split.split genome_a1ZsU
                          in
                            \ desc_a1ZsV
                              -> case desc_a1ZsV of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrH)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrJ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrL)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrN)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrP)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrR)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrT)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrX)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrZ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs1)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs3)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs5)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs7)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs9)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsb)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsd)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsf)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsh)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsj)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsl)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsn)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsp)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsr)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zst)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsv)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsx)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsz)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsB)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsD)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsF)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsH)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsJ)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsL)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsN)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsP)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsR)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZsT)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asSC
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asTf
                      p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                      (g_asSA, gpart_asTf) = Genome.Split.split gpart_asTe
                      p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                      (g_asSy, gpart_asTe) = Genome.Split.split gpart_asTd
                      p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                      (g_asSw, gpart_asTd) = Genome.Split.split gpart_asTc
                      p_asSv = code-0.1.0.0:Genome.FixedList.Functions.double g_asSu
                      (g_asSu, gpart_asTc) = Genome.Split.split gpart_asTb
                      p_asSt = code-0.1.0.0:Genome.FixedList.Functions.double g_asSs
                      (g_asSs, gpart_asTb) = Genome.Split.split gpart_asTa
                      p_asSr = Functions.belowten' g_asSq
                      (g_asSq, gpart_asTa) = Genome.Split.split gpart_asT9
                      p_asSp = code-0.1.0.0:Genome.FixedList.Functions.double g_asSo
                      (g_asSo, gpart_asT9) = Genome.Split.split gpart_asT8
                      p_asSn = code-0.1.0.0:Genome.FixedList.Functions.double g_asSm
                      (g_asSm, gpart_asT8) = Genome.Split.split gpart_asT7
                      p_asSl = code-0.1.0.0:Genome.FixedList.Functions.double g_asSk
                      (g_asSk, gpart_asT7) = Genome.Split.split gpart_asT6
                      p_asSj = Functions.belowten' g_asSi
                      (g_asSi, gpart_asT6) = Genome.Split.split gpart_asT5
                      p_asSh = code-0.1.0.0:Genome.FixedList.Functions.double g_asSg
                      (g_asSg, gpart_asT5) = Genome.Split.split gpart_asT4
                      p_asSf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSe
                      (g_asSe, gpart_asT4) = Genome.Split.split gpart_asT3
                      p_asSd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSc
                      (g_asSc, gpart_asT3) = Genome.Split.split gpart_asT2
                      p_asSb = Functions.belowten' g_asSa
                      (g_asSa, gpart_asT2) = Genome.Split.split gpart_asT1
                      p_asS9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS8
                      (g_asS8, gpart_asT1) = Genome.Split.split gpart_asT0
                      p_asS7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS6
                      (g_asS6, gpart_asT0) = Genome.Split.split gpart_asSZ
                      p_asS5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS4
                      (g_asS4, gpart_asSZ) = Genome.Split.split gpart_asSY
                      p_asS3 = Functions.belowten' g_asS2
                      (g_asS2, gpart_asSY) = Genome.Split.split gpart_asSX
                      p_asS1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS0
                      (g_asS0, gpart_asSX) = Genome.Split.split gpart_asSW
                      p_asRZ = Functions.belowten' g_asRY
                      (g_asRY, gpart_asSW) = Genome.Split.split gpart_asSV
                      p_asRX = code-0.1.0.0:Genome.FixedList.Functions.double g_asRW
                      (g_asRW, gpart_asSV) = Genome.Split.split gpart_asSU
                      p_asRV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRU
                      (g_asRU, gpart_asSU) = Genome.Split.split gpart_asST
                      p_asRT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRS
                      (g_asRS, gpart_asST) = Genome.Split.split gpart_asSS
                      p_asRR = code-0.1.0.0:Genome.FixedList.Functions.double g_asRQ
                      (g_asRQ, gpart_asSS) = Genome.Split.split gpart_asSR
                      p_asRP = Functions.belowten' g_asRO
                      (g_asRO, gpart_asSR) = Genome.Split.split gpart_asSQ
                      p_asRN = code-0.1.0.0:Genome.FixedList.Functions.double g_asRM
                      (g_asRM, gpart_asSQ) = Genome.Split.split gpart_asSP
                      p_asRL = Functions.belowten' g_asRK
                      (g_asRK, gpart_asSP) = Genome.Split.split gpart_asSO
                      p_asRJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asRI
                      (g_asRI, gpart_asSO) = Genome.Split.split gpart_asSN
                      p_asRH = code-0.1.0.0:Genome.FixedList.Functions.double g_asRG
                      (g_asRG, gpart_asSN) = Genome.Split.split gpart_asSM
                      p_asRF = Functions.belowten' g_asRE
                      (g_asRE, gpart_asSM) = Genome.Split.split gpart_asSL
                      p_asRD = code-0.1.0.0:Genome.FixedList.Functions.double g_asRC
                      (g_asRC, gpart_asSL) = Genome.Split.split gpart_asSK
                      p_asRB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRA
                      (g_asRA, gpart_asSK) = Genome.Split.split gpart_asSJ
                      p_asRz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRy
                      (g_asRy, gpart_asSJ) = Genome.Split.split gpart_asSI
                      p_asRx = code-0.1.0.0:Genome.FixedList.Functions.double g_asRw
                      (g_asRw, gpart_asSI) = Genome.Split.split gpart_asSH
                      p_asRv = code-0.1.0.0:Genome.FixedList.Functions.double g_asRu
                      (g_asRu, gpart_asSH) = Genome.Split.split gpart_asSG
                      p_asRt = code-0.1.0.0:Genome.FixedList.Functions.double g_asRs
                      (g_asRs, gpart_asSG) = Genome.Split.split gpart_asSF
                      p_asRr = code-0.1.0.0:Genome.FixedList.Functions.double g_asRq
                      (g_asRq, gpart_asSF) = Genome.Split.split gpart_asSE
                      p_asRp = code-0.1.0.0:Genome.FixedList.Functions.double g_asRo
                      (g_asRo, gpart_asSE) = Genome.Split.split genome_asSC
                    in
                      [Reaction
                         (\ x_asTg
                            -> let c_MiRs_asTh = ((toVector x_asTg) Data.Vector.Unboxed.! 2)
                               in (p_asRx / (1 + ((c_MiRs_asTh / p_asRD) ** p_asRF))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTi
                            -> let
                                 c_MiRs_asTj = ((toVector x_asTi) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTk = ((toVector x_asTi) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asRH
                                  / (1
                                     + (((c_MiRs_asTj / p_asRJ) ** p_asRL)
                                        + ((c_PTB_asTk / p_asRN) ** p_asRP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asTl
                            -> let
                                 c_RESTc_asTo = ((toVector x_asTl) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asTm = ((toVector x_asTl) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asRR
                                  * ((p_asS5
                                      + (((p_asRt / p_asRT) ** p_asRV)
                                         + ((c_NPTB_asTm / p_asRX) ** p_asRZ)))
                                     / (((1 + p_asS5)
                                         + (((p_asRt / p_asRT) ** p_asRV)
                                            + ((c_NPTB_asTm / p_asRX) ** p_asRZ)))
                                        + ((c_RESTc_asTo / p_asS1) ** p_asS3)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asTp
                            -> let
                                 c_MiRs_asTs = ((toVector x_asTp) Data.Vector.Unboxed.! 2)
                                 c_PTB_asTq = ((toVector x_asTp) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asS7
                                  * ((p_asSl + ((c_PTB_asTq / p_asS9) ** p_asSb))
                                     / (((1 + p_asSl) + ((c_PTB_asTq / p_asS9) ** p_asSb))
                                        + (((p_asRp / p_asSd) ** p_asSf)
                                           + ((c_MiRs_asTs / p_asSh) ** p_asSj))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asTt
                            -> let c_RESTc_asTu = ((toVector x_asTt) Data.Vector.Unboxed.! 3)
                               in (p_asSn / (1 + ((c_RESTc_asTu / p_asSp) ** p_asSr))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asTv
                            -> let c_PTB_asTw = ((toVector x_asTv) Data.Vector.Unboxed.! 0)
                               in (p_asSt * c_PTB_asTw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asTx
                            -> let c_NPTB_asTy = ((toVector x_asTx) Data.Vector.Unboxed.! 1)
                               in (p_asSv * c_NPTB_asTy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asTz
                            -> let c_MiRs_asTA = ((toVector x_asTz) Data.Vector.Unboxed.! 2)
                               in (p_asSx * c_MiRs_asTA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asTB
                            -> let c_RESTc_asTC = ((toVector x_asTB) Data.Vector.Unboxed.! 3)
                               in (p_asSz * c_RESTc_asTC))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asTD
                            -> let
                                 c_EndoNeuroTFs_asTE = ((toVector x_asTD) Data.Vector.Unboxed.! 4)
                               in (p_asSB * c_EndoNeuroTFs_asTE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120745",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120747",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120765",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120767",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120785",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120787",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asSC
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUl
                            p_asSB = code-0.1.0.0:Genome.FixedList.Functions.double g_asSA
                            (g_asSA, gpart_asUl) = Genome.Split.split gpart_asUk
                            p_asSz = code-0.1.0.0:Genome.FixedList.Functions.double g_asSy
                            (g_asSy, gpart_asUk) = Genome.Split.split gpart_asUj
                            p_asSx = code-0.1.0.0:Genome.FixedList.Functions.double g_asSw
                            (g_asSw, gpart_asUj) = Genome.Split.split gpart_asUi
                            p_asSv = code-0.1.0.0:Genome.FixedList.Functions.double g_asSu
                            (g_asSu, gpart_asUi) = Genome.Split.split gpart_asUh
                            p_asSt = code-0.1.0.0:Genome.FixedList.Functions.double g_asSs
                            (g_asSs, gpart_asUh) = Genome.Split.split gpart_asUg
                            p_asSr = Functions.belowten' g_asSq
                            (g_asSq, gpart_asUg) = Genome.Split.split gpart_asUf
                            p_asSp = code-0.1.0.0:Genome.FixedList.Functions.double g_asSo
                            (g_asSo, gpart_asUf) = Genome.Split.split gpart_asUe
                            p_asSn = code-0.1.0.0:Genome.FixedList.Functions.double g_asSm
                            (g_asSm, gpart_asUe) = Genome.Split.split gpart_asUd
                            p_asSl = code-0.1.0.0:Genome.FixedList.Functions.double g_asSk
                            (g_asSk, gpart_asUd) = Genome.Split.split gpart_asUc
                            p_asSj = Functions.belowten' g_asSi
                            (g_asSi, gpart_asUc) = Genome.Split.split gpart_asUb
                            p_asSh = code-0.1.0.0:Genome.FixedList.Functions.double g_asSg
                            (g_asSg, gpart_asUb) = Genome.Split.split gpart_asUa
                            p_asSf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSe
                            (g_asSe, gpart_asUa) = Genome.Split.split gpart_asU9
                            p_asSd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asSc
                            (g_asSc, gpart_asU9) = Genome.Split.split gpart_asU8
                            p_asSb = Functions.belowten' g_asSa
                            (g_asSa, gpart_asU8) = Genome.Split.split gpart_asU7
                            p_asS9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS8
                            (g_asS8, gpart_asU7) = Genome.Split.split gpart_asU6
                            p_asS7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS6
                            (g_asS6, gpart_asU6) = Genome.Split.split gpart_asU5
                            p_asS5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS4
                            (g_asS4, gpart_asU5) = Genome.Split.split gpart_asU4
                            p_asS3 = Functions.belowten' g_asS2
                            (g_asS2, gpart_asU4) = Genome.Split.split gpart_asU3
                            p_asS1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asS0
                            (g_asS0, gpart_asU3) = Genome.Split.split gpart_asU2
                            p_asRZ = Functions.belowten' g_asRY
                            (g_asRY, gpart_asU2) = Genome.Split.split gpart_asU1
                            p_asRX = code-0.1.0.0:Genome.FixedList.Functions.double g_asRW
                            (g_asRW, gpart_asU1) = Genome.Split.split gpart_asU0
                            p_asRV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRU
                            (g_asRU, gpart_asU0) = Genome.Split.split gpart_asTZ
                            p_asRT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRS
                            (g_asRS, gpart_asTZ) = Genome.Split.split gpart_asTY
                            p_asRR = code-0.1.0.0:Genome.FixedList.Functions.double g_asRQ
                            (g_asRQ, gpart_asTY) = Genome.Split.split gpart_asTX
                            p_asRP = Functions.belowten' g_asRO
                            (g_asRO, gpart_asTX) = Genome.Split.split gpart_asTW
                            p_asRN = code-0.1.0.0:Genome.FixedList.Functions.double g_asRM
                            (g_asRM, gpart_asTW) = Genome.Split.split gpart_asTV
                            p_asRL = Functions.belowten' g_asRK
                            (g_asRK, gpart_asTV) = Genome.Split.split gpart_asTU
                            p_asRJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asRI
                            (g_asRI, gpart_asTU) = Genome.Split.split gpart_asTT
                            p_asRH = code-0.1.0.0:Genome.FixedList.Functions.double g_asRG
                            (g_asRG, gpart_asTT) = Genome.Split.split gpart_asTS
                            p_asRF = Functions.belowten' g_asRE
                            (g_asRE, gpart_asTS) = Genome.Split.split gpart_asTR
                            p_asRD = code-0.1.0.0:Genome.FixedList.Functions.double g_asRC
                            (g_asRC, gpart_asTR) = Genome.Split.split gpart_asTQ
                            p_asRB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRA
                            (g_asRA, gpart_asTQ) = Genome.Split.split gpart_asTP
                            p_asRz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asRy
                            (g_asRy, gpart_asTP) = Genome.Split.split gpart_asTO
                            p_asRx = code-0.1.0.0:Genome.FixedList.Functions.double g_asRw
                            (g_asRw, gpart_asTO) = Genome.Split.split gpart_asTN
                            p_asRv = code-0.1.0.0:Genome.FixedList.Functions.double g_asRu
                            (g_asRu, gpart_asTN) = Genome.Split.split gpart_asTM
                            p_asRt = code-0.1.0.0:Genome.FixedList.Functions.double g_asRs
                            (g_asRs, gpart_asTM) = Genome.Split.split gpart_asTL
                            p_asRr = code-0.1.0.0:Genome.FixedList.Functions.double g_asRq
                            (g_asRq, gpart_asTL) = Genome.Split.split gpart_asTK
                            p_asRp = code-0.1.0.0:Genome.FixedList.Functions.double g_asRo
                            (g_asRo, gpart_asTK) = Genome.Split.split genome_asSC
                          in
                            \ desc_asSD
                              -> case desc_asSD of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRp)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRr)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRt)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRv)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRx)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRz)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRB)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRD)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRF)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRH)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRJ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRL)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRN)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRP)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRR)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRT)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRV)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRX)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asRZ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS1)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS3)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS5)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS7)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asS9)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSb)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSd)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSf)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSh)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSj)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSl)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSn)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSp)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSr)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSt)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSv)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSx)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSz)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSB)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asWg
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWT
                      p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                      (g_asWe, gpart_asWT) = Genome.Split.split gpart_asWS
                      p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                      (g_asWc, gpart_asWS) = Genome.Split.split gpart_asWR
                      p_asWb = code-0.1.0.0:Genome.FixedList.Functions.double g_asWa
                      (g_asWa, gpart_asWR) = Genome.Split.split gpart_asWQ
                      p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                      (g_asW8, gpart_asWQ) = Genome.Split.split gpart_asWP
                      p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                      (g_asW6, gpart_asWP) = Genome.Split.split gpart_asWO
                      p_asW5 = Functions.belowten' g_asW4
                      (g_asW4, gpart_asWO) = Genome.Split.split gpart_asWN
                      p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                      (g_asW2, gpart_asWN) = Genome.Split.split gpart_asWM
                      p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                      (g_asW0, gpart_asWM) = Genome.Split.split gpart_asWL
                      p_asVZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVY
                      (g_asVY, gpart_asWL) = Genome.Split.split gpart_asWK
                      p_asVX = Functions.belowten' g_asVW
                      (g_asVW, gpart_asWK) = Genome.Split.split gpart_asWJ
                      p_asVV = code-0.1.0.0:Genome.FixedList.Functions.double g_asVU
                      (g_asVU, gpart_asWJ) = Genome.Split.split gpart_asWI
                      p_asVT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVS
                      (g_asVS, gpart_asWI) = Genome.Split.split gpart_asWH
                      p_asVR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVQ
                      (g_asVQ, gpart_asWH) = Genome.Split.split gpart_asWG
                      p_asVP = Functions.belowten' g_asVO
                      (g_asVO, gpart_asWG) = Genome.Split.split gpart_asWF
                      p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                      (g_asVM, gpart_asWF) = Genome.Split.split gpart_asWE
                      p_asVL = code-0.1.0.0:Genome.FixedList.Functions.double g_asVK
                      (g_asVK, gpart_asWE) = Genome.Split.split gpart_asWD
                      p_asVJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVI
                      (g_asVI, gpart_asWD) = Genome.Split.split gpart_asWC
                      p_asVH = Functions.belowten' g_asVG
                      (g_asVG, gpart_asWC) = Genome.Split.split gpart_asWB
                      p_asVF = code-0.1.0.0:Genome.FixedList.Functions.double g_asVE
                      (g_asVE, gpart_asWB) = Genome.Split.split gpart_asWA
                      p_asVD = Functions.belowten' g_asVC
                      (g_asVC, gpart_asWA) = Genome.Split.split gpart_asWz
                      p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                      (g_asVA, gpart_asWz) = Genome.Split.split gpart_asWy
                      p_asVz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVy
                      (g_asVy, gpart_asWy) = Genome.Split.split gpart_asWx
                      p_asVx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVw
                      (g_asVw, gpart_asWx) = Genome.Split.split gpart_asWw
                      p_asVv = code-0.1.0.0:Genome.FixedList.Functions.double g_asVu
                      (g_asVu, gpart_asWw) = Genome.Split.split gpart_asWv
                      p_asVt = Functions.belowten' g_asVs
                      (g_asVs, gpart_asWv) = Genome.Split.split gpart_asWu
                      p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                      (g_asVq, gpart_asWu) = Genome.Split.split gpart_asWt
                      p_asVp = Functions.belowten' g_asVo
                      (g_asVo, gpart_asWt) = Genome.Split.split gpart_asWs
                      p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                      (g_asVm, gpart_asWs) = Genome.Split.split gpart_asWr
                      p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                      (g_asVk, gpart_asWr) = Genome.Split.split gpart_asWq
                      p_asVj = Functions.belowten' g_asVi
                      (g_asVi, gpart_asWq) = Genome.Split.split gpart_asWp
                      p_asVh = code-0.1.0.0:Genome.FixedList.Functions.double g_asVg
                      (g_asVg, gpart_asWp) = Genome.Split.split gpart_asWo
                      p_asVf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVe
                      (g_asVe, gpart_asWo) = Genome.Split.split gpart_asWn
                      p_asVd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVc
                      (g_asVc, gpart_asWn) = Genome.Split.split gpart_asWm
                      p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                      (g_asVa, gpart_asWm) = Genome.Split.split gpart_asWl
                      p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                      (g_asV8, gpart_asWl) = Genome.Split.split gpart_asWk
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asWk) = Genome.Split.split gpart_asWj
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asWj) = Genome.Split.split gpart_asWi
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asWi) = Genome.Split.split genome_asWg
                    in
                      [Reaction
                         (\ x_asWU
                            -> let c_MiRs_asWV = ((toVector x_asWU) Data.Vector.Unboxed.! 2)
                               in (p_asVb / (1 + ((c_MiRs_asWV / p_asVh) ** p_asVj))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWW
                            -> let
                                 c_MiRs_asWX = ((toVector x_asWW) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWY = ((toVector x_asWW) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVl
                                  / (1
                                     + (((c_MiRs_asWX / p_asVn) ** p_asVp)
                                        + ((c_PTB_asWY / p_asVr) ** p_asVt)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWZ
                            -> let
                                 c_RESTc_asX2 = ((toVector x_asWZ) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asX0 = ((toVector x_asWZ) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asVv
                                  * ((p_asVJ + ((c_NPTB_asX0 / p_asVB) ** p_asVD))
                                     / (((1 + p_asVJ) + ((c_NPTB_asX0 / p_asVB) ** p_asVD))
                                        + ((c_RESTc_asX2 / p_asVF) ** p_asVH)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asX3
                            -> let
                                 c_MiRs_asX6 = ((toVector x_asX3) Data.Vector.Unboxed.! 2)
                                 c_PTB_asX4 = ((toVector x_asX3) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVL
                                  * ((p_asVZ + ((c_PTB_asX4 / p_asVN) ** p_asVP))
                                     / (((1 + p_asVZ) + ((c_PTB_asX4 / p_asVN) ** p_asVP))
                                        + (((p_asV3 / p_asVR) ** p_asVT)
                                           + ((c_MiRs_asX6 / p_asVV) ** p_asVX))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asX7
                            -> let c_RESTc_asX8 = ((toVector x_asX7) Data.Vector.Unboxed.! 3)
                               in (p_asW1 / (1 + ((c_RESTc_asX8 / p_asW3) ** p_asW5))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asX9
                            -> let c_PTB_asXa = ((toVector x_asX9) Data.Vector.Unboxed.! 0)
                               in (p_asW7 * c_PTB_asXa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXb
                            -> let c_NPTB_asXc = ((toVector x_asXb) Data.Vector.Unboxed.! 1)
                               in (p_asW9 * c_NPTB_asXc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXd
                            -> let c_MiRs_asXe = ((toVector x_asXd) Data.Vector.Unboxed.! 2)
                               in (p_asWb * c_MiRs_asXe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXf
                            -> let c_RESTc_asXg = ((toVector x_asXf) Data.Vector.Unboxed.! 3)
                               in (p_asWd * c_RESTc_asXg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXh
                            -> let
                                 c_EndoNeuroTFs_asXi = ((toVector x_asXh) Data.Vector.Unboxed.! 4)
                               in (p_asWf * c_EndoNeuroTFs_asXi))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120971",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120973",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120988",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120989",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120990",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120991",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120992",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120993",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120994",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120995",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120996",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120997",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120998",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120999",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121000",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121001",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121002",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121003",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121004",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121005",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121011",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121013",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121021",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121023",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWg
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXU
                            p_asWf = code-0.1.0.0:Genome.FixedList.Functions.double g_asWe
                            (g_asWe, gpart_asXU) = Genome.Split.split gpart_asXT
                            p_asWd = code-0.1.0.0:Genome.FixedList.Functions.double g_asWc
                            (g_asWc, gpart_asXT) = Genome.Split.split gpart_asXS
                            p_asWb = code-0.1.0.0:Genome.FixedList.Functions.double g_asWa
                            (g_asWa, gpart_asXS) = Genome.Split.split gpart_asXR
                            p_asW9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW8
                            (g_asW8, gpart_asXR) = Genome.Split.split gpart_asXQ
                            p_asW7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW6
                            (g_asW6, gpart_asXQ) = Genome.Split.split gpart_asXP
                            p_asW5 = Functions.belowten' g_asW4
                            (g_asW4, gpart_asXP) = Genome.Split.split gpart_asXO
                            p_asW3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW2
                            (g_asW2, gpart_asXO) = Genome.Split.split gpart_asXN
                            p_asW1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW0
                            (g_asW0, gpart_asXN) = Genome.Split.split gpart_asXM
                            p_asVZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVY
                            (g_asVY, gpart_asXM) = Genome.Split.split gpart_asXL
                            p_asVX = Functions.belowten' g_asVW
                            (g_asVW, gpart_asXL) = Genome.Split.split gpart_asXK
                            p_asVV = code-0.1.0.0:Genome.FixedList.Functions.double g_asVU
                            (g_asVU, gpart_asXK) = Genome.Split.split gpart_asXJ
                            p_asVT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVS
                            (g_asVS, gpart_asXJ) = Genome.Split.split gpart_asXI
                            p_asVR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVQ
                            (g_asVQ, gpart_asXI) = Genome.Split.split gpart_asXH
                            p_asVP = Functions.belowten' g_asVO
                            (g_asVO, gpart_asXH) = Genome.Split.split gpart_asXG
                            p_asVN = code-0.1.0.0:Genome.FixedList.Functions.double g_asVM
                            (g_asVM, gpart_asXG) = Genome.Split.split gpart_asXF
                            p_asVL = code-0.1.0.0:Genome.FixedList.Functions.double g_asVK
                            (g_asVK, gpart_asXF) = Genome.Split.split gpart_asXE
                            p_asVJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asVI
                            (g_asVI, gpart_asXE) = Genome.Split.split gpart_asXD
                            p_asVH = Functions.belowten' g_asVG
                            (g_asVG, gpart_asXD) = Genome.Split.split gpart_asXC
                            p_asVF = code-0.1.0.0:Genome.FixedList.Functions.double g_asVE
                            (g_asVE, gpart_asXC) = Genome.Split.split gpart_asXB
                            p_asVD = Functions.belowten' g_asVC
                            (g_asVC, gpart_asXB) = Genome.Split.split gpart_asXA
                            p_asVB = code-0.1.0.0:Genome.FixedList.Functions.double g_asVA
                            (g_asVA, gpart_asXA) = Genome.Split.split gpart_asXz
                            p_asVz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVy
                            (g_asVy, gpart_asXz) = Genome.Split.split gpart_asXy
                            p_asVx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVw
                            (g_asVw, gpart_asXy) = Genome.Split.split gpart_asXx
                            p_asVv = code-0.1.0.0:Genome.FixedList.Functions.double g_asVu
                            (g_asVu, gpart_asXx) = Genome.Split.split gpart_asXw
                            p_asVt = Functions.belowten' g_asVs
                            (g_asVs, gpart_asXw) = Genome.Split.split gpart_asXv
                            p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                            (g_asVq, gpart_asXv) = Genome.Split.split gpart_asXu
                            p_asVp = Functions.belowten' g_asVo
                            (g_asVo, gpart_asXu) = Genome.Split.split gpart_asXt
                            p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                            (g_asVm, gpart_asXt) = Genome.Split.split gpart_asXs
                            p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                            (g_asVk, gpart_asXs) = Genome.Split.split gpart_asXr
                            p_asVj = Functions.belowten' g_asVi
                            (g_asVi, gpart_asXr) = Genome.Split.split gpart_asXq
                            p_asVh = code-0.1.0.0:Genome.FixedList.Functions.double g_asVg
                            (g_asVg, gpart_asXq) = Genome.Split.split gpart_asXp
                            p_asVf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVe
                            (g_asVe, gpart_asXp) = Genome.Split.split gpart_asXo
                            p_asVd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVc
                            (g_asVc, gpart_asXo) = Genome.Split.split gpart_asXn
                            p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                            (g_asVa, gpart_asXn) = Genome.Split.split gpart_asXm
                            p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                            (g_asV8, gpart_asXm) = Genome.Split.split gpart_asXl
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asXj) = Genome.Split.split genome_asWg
                          in
                            \ desc_asWh
                              -> case desc_asWh of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVb)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVd)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVf)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVh)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVj)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVl)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVn)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVp)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVr)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVt)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVv)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVx)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVz)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVB)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVD)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVL)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVN)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVP)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVR)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVT)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVV)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVX)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVZ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW1)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW3)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW5)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW7)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW9)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWb)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWd)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWf)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_asZP
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0s
                      p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                      (g_asZN, gpart_at0s) = Genome.Split.split gpart_at0r
                      p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                      (g_asZL, gpart_at0r) = Genome.Split.split gpart_at0q
                      p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                      (g_asZJ, gpart_at0q) = Genome.Split.split gpart_at0p
                      p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                      (g_asZH, gpart_at0p) = Genome.Split.split gpart_at0o
                      p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                      (g_asZF, gpart_at0o) = Genome.Split.split gpart_at0n
                      p_asZE = Functions.belowten' g_asZD
                      (g_asZD, gpart_at0n) = Genome.Split.split gpart_at0m
                      p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                      (g_asZB, gpart_at0m) = Genome.Split.split gpart_at0l
                      p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                      (g_asZz, gpart_at0l) = Genome.Split.split gpart_at0k
                      p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                      (g_asZx, gpart_at0k) = Genome.Split.split gpart_at0j
                      p_asZw = Functions.belowten' g_asZv
                      (g_asZv, gpart_at0j) = Genome.Split.split gpart_at0i
                      p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                      (g_asZt, gpart_at0i) = Genome.Split.split gpart_at0h
                      p_asZs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZr
                      (g_asZr, gpart_at0h) = Genome.Split.split gpart_at0g
                      p_asZq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZp
                      (g_asZp, gpart_at0g) = Genome.Split.split gpart_at0f
                      p_asZo = Functions.belowten' g_asZn
                      (g_asZn, gpart_at0f) = Genome.Split.split gpart_at0e
                      p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                      (g_asZl, gpart_at0e) = Genome.Split.split gpart_at0d
                      p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                      (g_asZj, gpart_at0d) = Genome.Split.split gpart_at0c
                      p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                      (g_asZh, gpart_at0c) = Genome.Split.split gpart_at0b
                      p_asZg = Functions.belowten' g_asZf
                      (g_asZf, gpart_at0b) = Genome.Split.split gpart_at0a
                      p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                      (g_asZd, gpart_at0a) = Genome.Split.split gpart_at09
                      p_asZc = Functions.belowten' g_asZb
                      (g_asZb, gpart_at09) = Genome.Split.split gpart_at08
                      p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                      (g_asZ9, gpart_at08) = Genome.Split.split gpart_at07
                      p_asZ8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ7
                      (g_asZ7, gpart_at07) = Genome.Split.split gpart_at06
                      p_asZ6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ5
                      (g_asZ5, gpart_at06) = Genome.Split.split gpart_at05
                      p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                      (g_asZ3, gpart_at05) = Genome.Split.split gpart_at04
                      p_asZ2 = Functions.belowten' g_asZ1
                      (g_asZ1, gpart_at04) = Genome.Split.split gpart_at03
                      p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                      (g_asYZ, gpart_at03) = Genome.Split.split gpart_at02
                      p_asYY = Functions.belowten' g_asYX
                      (g_asYX, gpart_at02) = Genome.Split.split gpart_at01
                      p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                      (g_asYV, gpart_at01) = Genome.Split.split gpart_at00
                      p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                      (g_asYT, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asYS = Functions.belowten' g_asYR
                      (g_asYR, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                      (g_asYP, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asYO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYN
                      (g_asYN, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asYM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYL
                      (g_asYL, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                      (g_asYD, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZR) = Genome.Split.split genome_asZP
                    in
                      [Reaction
                         (\ x_at0t
                            -> let c_MiRs_at0u = ((toVector x_at0t) Data.Vector.Unboxed.! 2)
                               in (p_asYK / (1 + ((c_MiRs_at0u / p_asYQ) ** p_asYS))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0v
                            -> let
                                 c_MiRs_at0w = ((toVector x_at0v) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0x = ((toVector x_at0v) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYU
                                  / (1
                                     + (((c_MiRs_at0w / p_asYW) ** p_asYY)
                                        + ((c_PTB_at0x / p_asZ0) ** p_asZ2)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0y
                            -> let
                                 c_RESTc_at0B = ((toVector x_at0y) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at0z = ((toVector x_at0y) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asZ4
                                  * ((p_asZi + ((c_NPTB_at0z / p_asZa) ** p_asZc))
                                     / (((1 + p_asZi) + ((c_NPTB_at0z / p_asZa) ** p_asZc))
                                        + ((c_RESTc_at0B / p_asZe) ** p_asZg)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0C
                            -> let
                                 c_MiRs_at0F = ((toVector x_at0C) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0D = ((toVector x_at0C) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZk
                                  * ((p_asZy + ((c_PTB_at0D / p_asZm) ** p_asZo))
                                     / (((1 + p_asZy) + ((c_PTB_at0D / p_asZm) ** p_asZo))
                                        + ((c_MiRs_at0F / p_asZu) ** p_asZw)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0G
                            -> let c_RESTc_at0H = ((toVector x_at0G) Data.Vector.Unboxed.! 3)
                               in (p_asZA / (1 + ((c_RESTc_at0H / p_asZC) ** p_asZE))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0I
                            -> let c_PTB_at0J = ((toVector x_at0I) Data.Vector.Unboxed.! 0)
                               in (p_asZG * c_PTB_at0J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0K
                            -> let c_NPTB_at0L = ((toVector x_at0K) Data.Vector.Unboxed.! 1)
                               in (p_asZI * c_NPTB_at0L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0M
                            -> let c_MiRs_at0N = ((toVector x_at0M) Data.Vector.Unboxed.! 2)
                               in (p_asZK * c_MiRs_at0N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0O
                            -> let c_RESTc_at0P = ((toVector x_at0O) Data.Vector.Unboxed.! 3)
                               in (p_asZM * c_RESTc_at0P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0Q
                            -> let
                                 c_EndoNeuroTFs_at0R = ((toVector x_at0Q) Data.Vector.Unboxed.! 4)
                               in (p_asZO * c_EndoNeuroTFs_at0R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121214",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121220",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121222",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121232",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121234",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121252",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZP
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1t
                            p_asZO = code-0.1.0.0:Genome.FixedList.Functions.double g_asZN
                            (g_asZN, gpart_at1t) = Genome.Split.split gpart_at1s
                            p_asZM = code-0.1.0.0:Genome.FixedList.Functions.double g_asZL
                            (g_asZL, gpart_at1s) = Genome.Split.split gpart_at1r
                            p_asZK = code-0.1.0.0:Genome.FixedList.Functions.double g_asZJ
                            (g_asZJ, gpart_at1r) = Genome.Split.split gpart_at1q
                            p_asZI = code-0.1.0.0:Genome.FixedList.Functions.double g_asZH
                            (g_asZH, gpart_at1q) = Genome.Split.split gpart_at1p
                            p_asZG = code-0.1.0.0:Genome.FixedList.Functions.double g_asZF
                            (g_asZF, gpart_at1p) = Genome.Split.split gpart_at1o
                            p_asZE = Functions.belowten' g_asZD
                            (g_asZD, gpart_at1o) = Genome.Split.split gpart_at1n
                            p_asZC = code-0.1.0.0:Genome.FixedList.Functions.double g_asZB
                            (g_asZB, gpart_at1n) = Genome.Split.split gpart_at1m
                            p_asZA = code-0.1.0.0:Genome.FixedList.Functions.double g_asZz
                            (g_asZz, gpart_at1m) = Genome.Split.split gpart_at1l
                            p_asZy = code-0.1.0.0:Genome.FixedList.Functions.double g_asZx
                            (g_asZx, gpart_at1l) = Genome.Split.split gpart_at1k
                            p_asZw = Functions.belowten' g_asZv
                            (g_asZv, gpart_at1k) = Genome.Split.split gpart_at1j
                            p_asZu = code-0.1.0.0:Genome.FixedList.Functions.double g_asZt
                            (g_asZt, gpart_at1j) = Genome.Split.split gpart_at1i
                            p_asZs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZr
                            (g_asZr, gpart_at1i) = Genome.Split.split gpart_at1h
                            p_asZq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZp
                            (g_asZp, gpart_at1h) = Genome.Split.split gpart_at1g
                            p_asZo = Functions.belowten' g_asZn
                            (g_asZn, gpart_at1g) = Genome.Split.split gpart_at1f
                            p_asZm = code-0.1.0.0:Genome.FixedList.Functions.double g_asZl
                            (g_asZl, gpart_at1f) = Genome.Split.split gpart_at1e
                            p_asZk = code-0.1.0.0:Genome.FixedList.Functions.double g_asZj
                            (g_asZj, gpart_at1e) = Genome.Split.split gpart_at1d
                            p_asZi = code-0.1.0.0:Genome.FixedList.Functions.double g_asZh
                            (g_asZh, gpart_at1d) = Genome.Split.split gpart_at1c
                            p_asZg = Functions.belowten' g_asZf
                            (g_asZf, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asZe = code-0.1.0.0:Genome.FixedList.Functions.double g_asZd
                            (g_asZd, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asZc = Functions.belowten' g_asZb
                            (g_asZb, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asZa = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ9
                            (g_asZ9, gpart_at19) = Genome.Split.split gpart_at18
                            p_asZ8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ7
                            (g_asZ7, gpart_at18) = Genome.Split.split gpart_at17
                            p_asZ6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZ5
                            (g_asZ5, gpart_at17) = Genome.Split.split gpart_at16
                            p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                            (g_asZ3, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZ2 = Functions.belowten' g_asZ1
                            (g_asZ1, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                            (g_asYZ, gpart_at14) = Genome.Split.split gpart_at13
                            p_asYY = Functions.belowten' g_asYX
                            (g_asYX, gpart_at13) = Genome.Split.split gpart_at12
                            p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                            (g_asYV, gpart_at12) = Genome.Split.split gpart_at11
                            p_asYU = code-0.1.0.0:Genome.FixedList.Functions.double g_asYT
                            (g_asYT, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYS = Functions.belowten' g_asYR
                            (g_asYR, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYP
                            (g_asYP, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYN
                            (g_asYN, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYL
                            (g_asYL, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                            (g_asYD, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0S) = Genome.Split.split genome_asZP
                          in
                            \ desc_asZQ
                              -> case desc_asZQ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ8)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZa)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZc)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZe)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZg)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZi)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZk)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZm)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZo)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZq)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZs)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZu)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZw)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZy)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZA)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZC)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZE)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZG)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZI)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZK)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZM)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZO)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at3o
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at41
                      p_at3n = code-0.1.0.0:Genome.FixedList.Functions.double g_at3m
                      (g_at3m, gpart_at41) = Genome.Split.split gpart_at40
                      p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                      (g_at3k, gpart_at40) = Genome.Split.split gpart_at3Z
                      p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                      (g_at3i, gpart_at3Z) = Genome.Split.split gpart_at3Y
                      p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                      (g_at3g, gpart_at3Y) = Genome.Split.split gpart_at3X
                      p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                      (g_at3e, gpart_at3X) = Genome.Split.split gpart_at3W
                      p_at3d = Functions.belowten' g_at3c
                      (g_at3c, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                      (g_at3a, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                      (g_at38, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                      (g_at36, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at35 = Functions.belowten' g_at34
                      (g_at34, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                      (g_at32, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at31
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at30
                      (g_at30, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at2Z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2Y
                      (g_at2Y, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at2X = Functions.belowten' g_at2W
                      (g_at2W, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                      (g_at2U, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                      (g_at2Q, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2P = Functions.belowten' g_at2O
                      (g_at2O, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2L = Functions.belowten' g_at2K
                      (g_at2K, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2G
                      (g_at2G, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2E
                      (g_at2E, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                      (g_at2C, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2B = Functions.belowten' g_at2A
                      (g_at2A, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                      (g_at2y, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2x = Functions.belowten' g_at2w
                      (g_at2w, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                      (g_at2u, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                      (g_at2s, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2r = Functions.belowten' g_at2q
                      (g_at2q, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2m
                      (g_at2m, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2k
                      (g_at2k, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                      (g_at2i, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                      (g_at2g, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                      (g_at2e, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                      (g_at2c, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at3q) = Genome.Split.split genome_at3o
                    in
                      [Reaction
                         (\ x_at42
                            -> let c_MiRs_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2j
                                  / (1
                                     + (((p_at2b / p_at2l) ** p_at2n)
                                        + ((c_MiRs_at43 / p_at2p) ** p_at2r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at44
                            -> let
                                 c_MiRs_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 2)
                                 c_PTB_at46 = ((toVector x_at44) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2t
                                  / (1
                                     + (((c_MiRs_at45 / p_at2v) ** p_at2x)
                                        + ((c_PTB_at46 / p_at2z) ** p_at2B)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at47
                            -> let
                                 c_RESTc_at4a = ((toVector x_at47) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at48 = ((toVector x_at47) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2D
                                  * ((p_at2R + ((c_NPTB_at48 / p_at2J) ** p_at2L))
                                     / (((1 + p_at2R) + ((c_NPTB_at48 / p_at2J) ** p_at2L))
                                        + ((c_RESTc_at4a / p_at2N) ** p_at2P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at4b
                            -> let
                                 c_MiRs_at4e = ((toVector x_at4b) Data.Vector.Unboxed.! 2)
                                 c_PTB_at4c = ((toVector x_at4b) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2T
                                  * ((p_at37 + ((c_PTB_at4c / p_at2V) ** p_at2X))
                                     / (((1 + p_at37) + ((c_PTB_at4c / p_at2V) ** p_at2X))
                                        + ((c_MiRs_at4e / p_at33) ** p_at35)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4f
                            -> let c_RESTc_at4g = ((toVector x_at4f) Data.Vector.Unboxed.! 3)
                               in (p_at39 / (1 + ((c_RESTc_at4g / p_at3b) ** p_at3d))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4h
                            -> let c_PTB_at4i = ((toVector x_at4h) Data.Vector.Unboxed.! 0)
                               in (p_at3f * c_PTB_at4i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4j
                            -> let c_NPTB_at4k = ((toVector x_at4j) Data.Vector.Unboxed.! 1)
                               in (p_at3h * c_NPTB_at4k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4l
                            -> let c_MiRs_at4m = ((toVector x_at4l) Data.Vector.Unboxed.! 2)
                               in (p_at3j * c_MiRs_at4m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4n
                            -> let c_RESTc_at4o = ((toVector x_at4n) Data.Vector.Unboxed.! 3)
                               in (p_at3l * c_RESTc_at4o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4p
                            -> let
                                 c_EndoNeuroTFs_at4q = ((toVector x_at4p) Data.Vector.Unboxed.! 4)
                               in (p_at3n * c_EndoNeuroTFs_at4q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121456",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121457",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121458",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121459",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121460",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121461",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121462",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121463",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121464",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121465",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3o
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at52
                            p_at3n = code-0.1.0.0:Genome.FixedList.Functions.double g_at3m
                            (g_at3m, gpart_at52) = Genome.Split.split gpart_at51
                            p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                            (g_at3k, gpart_at51) = Genome.Split.split gpart_at50
                            p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                            (g_at3i, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                            (g_at3g, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                            (g_at3e, gpart_at4Y) = Genome.Split.split gpart_at4X
                            p_at3d = Functions.belowten' g_at3c
                            (g_at3c, gpart_at4X) = Genome.Split.split gpart_at4W
                            p_at3b = code-0.1.0.0:Genome.FixedList.Functions.double g_at3a
                            (g_at3a, gpart_at4W) = Genome.Split.split gpart_at4V
                            p_at39 = code-0.1.0.0:Genome.FixedList.Functions.double g_at38
                            (g_at38, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at37 = code-0.1.0.0:Genome.FixedList.Functions.double g_at36
                            (g_at36, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at35 = Functions.belowten' g_at34
                            (g_at34, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at33 = code-0.1.0.0:Genome.FixedList.Functions.double g_at32
                            (g_at32, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at31
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at30
                            (g_at30, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2Z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2Y
                            (g_at2Y, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2X = Functions.belowten' g_at2W
                            (g_at2W, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                            (g_at2U, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                            (g_at2Q, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2P = Functions.belowten' g_at2O
                            (g_at2O, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2L = Functions.belowten' g_at2K
                            (g_at2K, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2G
                            (g_at2G, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2E
                            (g_at2E, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                            (g_at2C, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2B = Functions.belowten' g_at2A
                            (g_at2A, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                            (g_at2y, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2x = Functions.belowten' g_at2w
                            (g_at2w, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                            (g_at2u, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                            (g_at2s, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2r = Functions.belowten' g_at2q
                            (g_at2q, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2m
                            (g_at2m, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2k
                            (g_at2k, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2j = code-0.1.0.0:Genome.FixedList.Functions.double g_at2i
                            (g_at2i, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                            (g_at2g, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                            (g_at2e, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                            (g_at2c, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at4r) = Genome.Split.split genome_at3o
                          in
                            \ desc_at3p
                              -> case desc_at3p of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Activation coef [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Activation hill [NPTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at33)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at35)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at37)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at39)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3b)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3h)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3j)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3l)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3n)
                                   _ -> Nothing }}
