src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24Ss
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24T8
                      p_a24Sr = double g_a24Sq
                      (g_a24Sq, gpart_a24T8) = Genome.Split.split gpart_a24T7
                      p_a24Sp = double g_a24So
                      (g_a24So, gpart_a24T7) = Genome.Split.split gpart_a24T6
                      p_a24Sn = double g_a24Sm
                      (g_a24Sm, gpart_a24T6) = Genome.Split.split gpart_a24T5
                      p_a24Sl = double g_a24Sk
                      (g_a24Sk, gpart_a24T5) = Genome.Split.split gpart_a24T4
                      p_a24Sj = double g_a24Si
                      (g_a24Si, gpart_a24T4) = Genome.Split.split gpart_a24T3
                      p_a24Sh = double g_a24Sg
                      (g_a24Sg, gpart_a24T3) = Genome.Split.split gpart_a24T2
                      p_a24Sf = Functions.belowten' g_a24Se
                      (g_a24Se, gpart_a24T2) = Genome.Split.split gpart_a24T1
                      p_a24Sd = double g_a24Sc
                      (g_a24Sc, gpart_a24T1) = Genome.Split.split gpart_a24T0
                      p_a24Sb = Functions.belowten' g_a24Sa
                      (g_a24Sa, gpart_a24T0) = Genome.Split.split gpart_a24SZ
                      p_a24S9 = double g_a24S8
                      (g_a24S8, gpart_a24SZ) = Genome.Split.split gpart_a24SY
                      p_a24S7 = double g_a24S6
                      (g_a24S6, gpart_a24SY) = Genome.Split.split gpart_a24SX
                      p_a24S5 = double g_a24S4
                      (g_a24S4, gpart_a24SX) = Genome.Split.split gpart_a24SW
                      p_a24S3 = Functions.belowten' g_a24S2
                      (g_a24S2, gpart_a24SW) = Genome.Split.split gpart_a24SV
                      p_a24S1 = double g_a24S0
                      (g_a24S0, gpart_a24SV) = Genome.Split.split gpart_a24SU
                      p_a24RZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RY
                      (g_a24RY, gpart_a24SU) = Genome.Split.split gpart_a24ST
                      p_a24RX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RW
                      (g_a24RW, gpart_a24ST) = Genome.Split.split gpart_a24SS
                      p_a24RV = Functions.belowten' g_a24RU
                      (g_a24RU, gpart_a24SS) = Genome.Split.split gpart_a24SR
                      p_a24RT = double g_a24RS
                      (g_a24RS, gpart_a24SR) = Genome.Split.split gpart_a24SQ
                      p_a24RR = double g_a24RQ
                      (g_a24RQ, gpart_a24SQ) = Genome.Split.split gpart_a24SP
                      p_a24RP = double g_a24RO
                      (g_a24RO, gpart_a24SP) = Genome.Split.split gpart_a24SO
                      p_a24RN = Functions.belowten' g_a24RM
                      (g_a24RM, gpart_a24SO) = Genome.Split.split gpart_a24SN
                      p_a24RL = double g_a24RK
                      (g_a24RK, gpart_a24SN) = Genome.Split.split gpart_a24SM
                      p_a24RJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RI
                      (g_a24RI, gpart_a24SM) = Genome.Split.split gpart_a24SL
                      p_a24RH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RG
                      (g_a24RG, gpart_a24SL) = Genome.Split.split gpart_a24SK
                      p_a24RF = double g_a24RE
                      (g_a24RE, gpart_a24SK) = Genome.Split.split gpart_a24SJ
                      p_a24RD = Functions.belowten' g_a24RC
                      (g_a24RC, gpart_a24SJ) = Genome.Split.split gpart_a24SI
                      p_a24RB = double g_a24RA
                      (g_a24RA, gpart_a24SI) = Genome.Split.split gpart_a24SH
                      p_a24Rz = Functions.belowten' g_a24Ry
                      (g_a24Ry, gpart_a24SH) = Genome.Split.split gpart_a24SG
                      p_a24Rx = double g_a24Rw
                      (g_a24Rw, gpart_a24SG) = Genome.Split.split gpart_a24SF
                      p_a24Rv = double g_a24Ru
                      (g_a24Ru, gpart_a24SF) = Genome.Split.split gpart_a24SE
                      p_a24Rt = Functions.belowten' g_a24Rs
                      (g_a24Rs, gpart_a24SE) = Genome.Split.split gpart_a24SD
                      p_a24Rr = double g_a24Rq
                      (g_a24Rq, gpart_a24SD) = Genome.Split.split gpart_a24SC
                      p_a24Rp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ro
                      (g_a24Ro, gpart_a24SC) = Genome.Split.split gpart_a24SB
                      p_a24Rn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Rm
                      (g_a24Rm, gpart_a24SB) = Genome.Split.split gpart_a24SA
                      p_a24Rl = Functions.belowten' g_a24Rk
                      (g_a24Rk, gpart_a24SA) = Genome.Split.split gpart_a24Sz
                      p_a24Rj = double g_a24Ri
                      (g_a24Ri, gpart_a24Sz) = Genome.Split.split gpart_a24Sy
                      p_a24Rh = double g_a24Rg
                      (g_a24Rg, gpart_a24Sy) = Genome.Split.split gpart_a24Sx
                      p_a24Rf = double g_a24Re
                      (g_a24Re, gpart_a24Sx) = Genome.Split.split gpart_a24Sw
                      p_a24Rd = double g_a24Rc
                      (g_a24Rc, gpart_a24Sw) = Genome.Split.split gpart_a24Sv
                      p_a24Rb = double g_a24Ra
                      (g_a24Ra, gpart_a24Sv) = Genome.Split.split gpart_a24Su
                      p_a24R9 = double g_a24R8
                      (g_a24R8, gpart_a24Su) = Genome.Split.split genome_a24Ss
                    in  \ x_a24T9
                          -> let
                               c_PTB_a24Td
                                 = ((Data.Fixed.Vector.toVector x_a24T9) Data.Vector.Unboxed.! 0)
                               c_NPTB_a24Ta
                                 = ((Data.Fixed.Vector.toVector x_a24T9) Data.Vector.Unboxed.! 1)
                               c_MiRs_a24Tb
                                 = ((Data.Fixed.Vector.toVector x_a24T9) Data.Vector.Unboxed.! 2)
                               c_RESTc_a24Ti
                                 = ((Data.Fixed.Vector.toVector x_a24T9) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Tu
                                 = ((Data.Fixed.Vector.toVector x_a24T9) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Rh
                                     / (1
                                        + (((c_NPTB_a24Ta / p_a24Rj) ** p_a24Rl)
                                           + ((c_MiRs_a24Tb / p_a24Rr) ** p_a24Rt))))
                                    + (negate (p_a24Sj * c_PTB_a24Td))),
                                   ((p_a24Rv
                                     / (1
                                        + (((c_MiRs_a24Tb / p_a24Rx) ** p_a24Rz)
                                           + ((c_PTB_a24Td / p_a24RB) ** p_a24RD))))
                                    + (negate (p_a24Sl * c_NPTB_a24Ta))),
                                   ((p_a24RF
                                     * ((p_a24RP + ((p_a24Rd / p_a24RH) ** p_a24RJ))
                                        / (((1 + p_a24RP) + ((p_a24Rd / p_a24RH) ** p_a24RJ))
                                           + ((c_RESTc_a24Ti / p_a24RL) ** p_a24RN))))
                                    + (negate (p_a24Sn * c_MiRs_a24Tb))),
                                   ((p_a24RR
                                     * ((p_a24S5 + ((c_PTB_a24Td / p_a24RT) ** p_a24RV))
                                        / (((1 + p_a24S5) + ((c_PTB_a24Td / p_a24RT) ** p_a24RV))
                                           + (((p_a24R9 / p_a24RX) ** p_a24RZ)
                                              + ((c_MiRs_a24Tb / p_a24S1) ** p_a24S3)))))
                                    + (negate (p_a24Sp * c_RESTc_a24Ti))),
                                   ((p_a24S7
                                     * ((p_a24Sh + ((c_MiRs_a24Tb / p_a24S9) ** p_a24Sb))
                                        / (((1 + p_a24Sh) + ((c_MiRs_a24Tb / p_a24S9) ** p_a24Sb))
                                           + ((c_RESTc_a24Ti / p_a24Sd) ** p_a24Sf))))
                                    + (negate (p_a24Sr * c_EndoNeuroTFs_a24Tu)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505133",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505135",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505153",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505155",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505169",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505171",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Ss
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24U9
                            p_a24Sr = double g_a24Sq
                            (g_a24Sq, gpart_a24U9) = Genome.Split.split gpart_a24U8
                            p_a24Sp = double g_a24So
                            (g_a24So, gpart_a24U8) = Genome.Split.split gpart_a24U7
                            p_a24Sn = double g_a24Sm
                            (g_a24Sm, gpart_a24U7) = Genome.Split.split gpart_a24U6
                            p_a24Sl = double g_a24Sk
                            (g_a24Sk, gpart_a24U6) = Genome.Split.split gpart_a24U5
                            p_a24Sj = double g_a24Si
                            (g_a24Si, gpart_a24U5) = Genome.Split.split gpart_a24U4
                            p_a24Sh = double g_a24Sg
                            (g_a24Sg, gpart_a24U4) = Genome.Split.split gpart_a24U3
                            p_a24Sf = Functions.belowten' g_a24Se
                            (g_a24Se, gpart_a24U3) = Genome.Split.split gpart_a24U2
                            p_a24Sd = double g_a24Sc
                            (g_a24Sc, gpart_a24U2) = Genome.Split.split gpart_a24U1
                            p_a24Sb = Functions.belowten' g_a24Sa
                            (g_a24Sa, gpart_a24U1) = Genome.Split.split gpart_a24U0
                            p_a24S9 = double g_a24S8
                            (g_a24S8, gpart_a24U0) = Genome.Split.split gpart_a24TZ
                            p_a24S7 = double g_a24S6
                            (g_a24S6, gpart_a24TZ) = Genome.Split.split gpart_a24TY
                            p_a24S5 = double g_a24S4
                            (g_a24S4, gpart_a24TY) = Genome.Split.split gpart_a24TX
                            p_a24S3 = Functions.belowten' g_a24S2
                            (g_a24S2, gpart_a24TX) = Genome.Split.split gpart_a24TW
                            p_a24S1 = double g_a24S0
                            (g_a24S0, gpart_a24TW) = Genome.Split.split gpart_a24TV
                            p_a24RZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RY
                            (g_a24RY, gpart_a24TV) = Genome.Split.split gpart_a24TU
                            p_a24RX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RW
                            (g_a24RW, gpart_a24TU) = Genome.Split.split gpart_a24TT
                            p_a24RV = Functions.belowten' g_a24RU
                            (g_a24RU, gpart_a24TT) = Genome.Split.split gpart_a24TS
                            p_a24RT = double g_a24RS
                            (g_a24RS, gpart_a24TS) = Genome.Split.split gpart_a24TR
                            p_a24RR = double g_a24RQ
                            (g_a24RQ, gpart_a24TR) = Genome.Split.split gpart_a24TQ
                            p_a24RP = double g_a24RO
                            (g_a24RO, gpart_a24TQ) = Genome.Split.split gpart_a24TP
                            p_a24RN = Functions.belowten' g_a24RM
                            (g_a24RM, gpart_a24TP) = Genome.Split.split gpart_a24TO
                            p_a24RL = double g_a24RK
                            (g_a24RK, gpart_a24TO) = Genome.Split.split gpart_a24TN
                            p_a24RJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RI
                            (g_a24RI, gpart_a24TN) = Genome.Split.split gpart_a24TM
                            p_a24RH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24RG
                            (g_a24RG, gpart_a24TM) = Genome.Split.split gpart_a24TL
                            p_a24RF = double g_a24RE
                            (g_a24RE, gpart_a24TL) = Genome.Split.split gpart_a24TK
                            p_a24RD = Functions.belowten' g_a24RC
                            (g_a24RC, gpart_a24TK) = Genome.Split.split gpart_a24TJ
                            p_a24RB = double g_a24RA
                            (g_a24RA, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                            p_a24Rz = Functions.belowten' g_a24Ry
                            (g_a24Ry, gpart_a24TI) = Genome.Split.split gpart_a24TH
                            p_a24Rx = double g_a24Rw
                            (g_a24Rw, gpart_a24TH) = Genome.Split.split gpart_a24TG
                            p_a24Rv = double g_a24Ru
                            (g_a24Ru, gpart_a24TG) = Genome.Split.split gpart_a24TF
                            p_a24Rt = Functions.belowten' g_a24Rs
                            (g_a24Rs, gpart_a24TF) = Genome.Split.split gpart_a24TE
                            p_a24Rr = double g_a24Rq
                            (g_a24Rq, gpart_a24TE) = Genome.Split.split gpart_a24TD
                            p_a24Rp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ro
                            (g_a24Ro, gpart_a24TD) = Genome.Split.split gpart_a24TC
                            p_a24Rn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Rm
                            (g_a24Rm, gpart_a24TC) = Genome.Split.split gpart_a24TB
                            p_a24Rl = Functions.belowten' g_a24Rk
                            (g_a24Rk, gpart_a24TB) = Genome.Split.split gpart_a24TA
                            p_a24Rj = double g_a24Ri
                            (g_a24Ri, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                            p_a24Rh = double g_a24Rg
                            (g_a24Rg, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                            p_a24Rf = double g_a24Re
                            (g_a24Re, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                            p_a24Rd = double g_a24Rc
                            (g_a24Rc, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                            p_a24Rb = double g_a24Ra
                            (g_a24Ra, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                            p_a24R9 = double g_a24R8
                            (g_a24R8, gpart_a24Tv) = Genome.Split.split genome_a24Ss
                          in
                            \ desc_a24St
                              -> case desc_a24St of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24R9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rh)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rj)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rl)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rn)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rp)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rr)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rt)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rv)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rx)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Rz)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RB)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RD)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RF)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RH)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S7)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S9)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sb)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sd)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sf)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24WD
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Xj
                      p_a24WC = double g_a24WB
                      (g_a24WB, gpart_a24Xj) = Genome.Split.split gpart_a24Xi
                      p_a24WA = double g_a24Wz
                      (g_a24Wz, gpart_a24Xi) = Genome.Split.split gpart_a24Xh
                      p_a24Wy = double g_a24Wx
                      (g_a24Wx, gpart_a24Xh) = Genome.Split.split gpart_a24Xg
                      p_a24Ww = double g_a24Wv
                      (g_a24Wv, gpart_a24Xg) = Genome.Split.split gpart_a24Xf
                      p_a24Wu = double g_a24Wt
                      (g_a24Wt, gpart_a24Xf) = Genome.Split.split gpart_a24Xe
                      p_a24Ws = double g_a24Wr
                      (g_a24Wr, gpart_a24Xe) = Genome.Split.split gpart_a24Xd
                      p_a24Wq = Functions.belowten' g_a24Wp
                      (g_a24Wp, gpart_a24Xd) = Genome.Split.split gpart_a24Xc
                      p_a24Wo = double g_a24Wn
                      (g_a24Wn, gpart_a24Xc) = Genome.Split.split gpart_a24Xb
                      p_a24Wm = Functions.belowten' g_a24Wl
                      (g_a24Wl, gpart_a24Xb) = Genome.Split.split gpart_a24Xa
                      p_a24Wk = double g_a24Wj
                      (g_a24Wj, gpart_a24Xa) = Genome.Split.split gpart_a24X9
                      p_a24Wi = double g_a24Wh
                      (g_a24Wh, gpart_a24X9) = Genome.Split.split gpart_a24X8
                      p_a24Wg = double g_a24Wf
                      (g_a24Wf, gpart_a24X8) = Genome.Split.split gpart_a24X7
                      p_a24We = Functions.belowten' g_a24Wd
                      (g_a24Wd, gpart_a24X7) = Genome.Split.split gpart_a24X6
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24X6) = Genome.Split.split gpart_a24X5
                      p_a24Wa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W9
                      (g_a24W9, gpart_a24X5) = Genome.Split.split gpart_a24X4
                      p_a24W8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W7
                      (g_a24W7, gpart_a24X4) = Genome.Split.split gpart_a24X3
                      p_a24W6 = Functions.belowten' g_a24W5
                      (g_a24W5, gpart_a24X3) = Genome.Split.split gpart_a24X2
                      p_a24W4 = double g_a24W3
                      (g_a24W3, gpart_a24X2) = Genome.Split.split gpart_a24X1
                      p_a24W2 = double g_a24W1
                      (g_a24W1, gpart_a24X1) = Genome.Split.split gpart_a24X0
                      p_a24W0 = double g_a24VZ
                      (g_a24VZ, gpart_a24X0) = Genome.Split.split gpart_a24WZ
                      p_a24VY = Functions.belowten' g_a24VX
                      (g_a24VX, gpart_a24WZ) = Genome.Split.split gpart_a24WY
                      p_a24VW = double g_a24VV
                      (g_a24VV, gpart_a24WY) = Genome.Split.split gpart_a24WX
                      p_a24VU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VT
                      (g_a24VT, gpart_a24WX) = Genome.Split.split gpart_a24WW
                      p_a24VS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VR
                      (g_a24VR, gpart_a24WW) = Genome.Split.split gpart_a24WV
                      p_a24VQ = double g_a24VP
                      (g_a24VP, gpart_a24WV) = Genome.Split.split gpart_a24WU
                      p_a24VO = Functions.belowten' g_a24VN
                      (g_a24VN, gpart_a24WU) = Genome.Split.split gpart_a24WT
                      p_a24VM = double g_a24VL
                      (g_a24VL, gpart_a24WT) = Genome.Split.split gpart_a24WS
                      p_a24VK = Functions.belowten' g_a24VJ
                      (g_a24VJ, gpart_a24WS) = Genome.Split.split gpart_a24WR
                      p_a24VI = double g_a24VH
                      (g_a24VH, gpart_a24WR) = Genome.Split.split gpart_a24WQ
                      p_a24VG = double g_a24VF
                      (g_a24VF, gpart_a24WQ) = Genome.Split.split gpart_a24WP
                      p_a24VE = Functions.belowten' g_a24VD
                      (g_a24VD, gpart_a24WP) = Genome.Split.split gpart_a24WO
                      p_a24VC = double g_a24VB
                      (g_a24VB, gpart_a24WO) = Genome.Split.split gpart_a24WN
                      p_a24VA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Vz
                      (g_a24Vz, gpart_a24WN) = Genome.Split.split gpart_a24WM
                      p_a24Vy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Vx
                      (g_a24Vx, gpart_a24WM) = Genome.Split.split gpart_a24WL
                      p_a24Vw = Functions.belowten' g_a24Vv
                      (g_a24Vv, gpart_a24WL) = Genome.Split.split gpart_a24WK
                      p_a24Vu = double g_a24Vt
                      (g_a24Vt, gpart_a24WK) = Genome.Split.split gpart_a24WJ
                      p_a24Vs = double g_a24Vr
                      (g_a24Vr, gpart_a24WJ) = Genome.Split.split gpart_a24WI
                      p_a24Vq = double g_a24Vp
                      (g_a24Vp, gpart_a24WI) = Genome.Split.split gpart_a24WH
                      p_a24Vo = double g_a24Vn
                      (g_a24Vn, gpart_a24WH) = Genome.Split.split gpart_a24WG
                      p_a24Vm = double g_a24Vl
                      (g_a24Vl, gpart_a24WG) = Genome.Split.split gpart_a24WF
                      p_a24Vk = double g_a24Vj
                      (g_a24Vj, gpart_a24WF) = Genome.Split.split genome_a24WD
                    in  \ x_a24Xk
                          -> let
                               c_PTB_a24Xo
                                 = ((Data.Fixed.Vector.toVector x_a24Xk) Data.Vector.Unboxed.! 0)
                               c_NPTB_a24Xl
                                 = ((Data.Fixed.Vector.toVector x_a24Xk) Data.Vector.Unboxed.! 1)
                               c_MiRs_a24Xm
                                 = ((Data.Fixed.Vector.toVector x_a24Xk) Data.Vector.Unboxed.! 2)
                               c_RESTc_a24Xt
                                 = ((Data.Fixed.Vector.toVector x_a24Xk) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24XF
                                 = ((Data.Fixed.Vector.toVector x_a24Xk) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Vs
                                     / (1
                                        + (((c_NPTB_a24Xl / p_a24Vu) ** p_a24Vw)
                                           + ((c_MiRs_a24Xm / p_a24VC) ** p_a24VE))))
                                    + (negate (p_a24Wu * c_PTB_a24Xo))),
                                   ((p_a24VG
                                     / (1
                                        + (((c_MiRs_a24Xm / p_a24VI) ** p_a24VK)
                                           + ((c_PTB_a24Xo / p_a24VM) ** p_a24VO))))
                                    + (negate (p_a24Ww * c_NPTB_a24Xl))),
                                   ((p_a24VQ
                                     * (p_a24W0
                                        / ((1 + p_a24W0) + ((c_RESTc_a24Xt / p_a24VW) ** p_a24VY))))
                                    + (negate (p_a24Wy * c_MiRs_a24Xm))),
                                   ((p_a24W2
                                     * ((p_a24Wg + ((c_PTB_a24Xo / p_a24W4) ** p_a24W6))
                                        / (((1 + p_a24Wg) + ((c_PTB_a24Xo / p_a24W4) ** p_a24W6))
                                           + (((p_a24Vk / p_a24W8) ** p_a24Wa)
                                              + ((c_MiRs_a24Xm / p_a24Wc) ** p_a24We)))))
                                    + (negate (p_a24WA * c_RESTc_a24Xt))),
                                   ((p_a24Wi
                                     * ((p_a24Ws + ((c_MiRs_a24Xm / p_a24Wk) ** p_a24Wm))
                                        / (((1 + p_a24Ws) + ((c_MiRs_a24Xm / p_a24Wk) ** p_a24Wm))
                                           + ((c_RESTc_a24Xt / p_a24Wo) ** p_a24Wq))))
                                    + (negate (p_a24WC * c_EndoNeuroTFs_a24XF)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505392",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505394",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505412",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505428",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24WD
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Yk
                            p_a24WC = double g_a24WB
                            (g_a24WB, gpart_a24Yk) = Genome.Split.split gpart_a24Yj
                            p_a24WA = double g_a24Wz
                            (g_a24Wz, gpart_a24Yj) = Genome.Split.split gpart_a24Yi
                            p_a24Wy = double g_a24Wx
                            (g_a24Wx, gpart_a24Yi) = Genome.Split.split gpart_a24Yh
                            p_a24Ww = double g_a24Wv
                            (g_a24Wv, gpart_a24Yh) = Genome.Split.split gpart_a24Yg
                            p_a24Wu = double g_a24Wt
                            (g_a24Wt, gpart_a24Yg) = Genome.Split.split gpart_a24Yf
                            p_a24Ws = double g_a24Wr
                            (g_a24Wr, gpart_a24Yf) = Genome.Split.split gpart_a24Ye
                            p_a24Wq = Functions.belowten' g_a24Wp
                            (g_a24Wp, gpart_a24Ye) = Genome.Split.split gpart_a24Yd
                            p_a24Wo = double g_a24Wn
                            (g_a24Wn, gpart_a24Yd) = Genome.Split.split gpart_a24Yc
                            p_a24Wm = Functions.belowten' g_a24Wl
                            (g_a24Wl, gpart_a24Yc) = Genome.Split.split gpart_a24Yb
                            p_a24Wk = double g_a24Wj
                            (g_a24Wj, gpart_a24Yb) = Genome.Split.split gpart_a24Ya
                            p_a24Wi = double g_a24Wh
                            (g_a24Wh, gpart_a24Ya) = Genome.Split.split gpart_a24Y9
                            p_a24Wg = double g_a24Wf
                            (g_a24Wf, gpart_a24Y9) = Genome.Split.split gpart_a24Y8
                            p_a24We = Functions.belowten' g_a24Wd
                            (g_a24Wd, gpart_a24Y8) = Genome.Split.split gpart_a24Y7
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Y7) = Genome.Split.split gpart_a24Y6
                            p_a24Wa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W9
                            (g_a24W9, gpart_a24Y6) = Genome.Split.split gpart_a24Y5
                            p_a24W8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24W7
                            (g_a24W7, gpart_a24Y5) = Genome.Split.split gpart_a24Y4
                            p_a24W6 = Functions.belowten' g_a24W5
                            (g_a24W5, gpart_a24Y4) = Genome.Split.split gpart_a24Y3
                            p_a24W4 = double g_a24W3
                            (g_a24W3, gpart_a24Y3) = Genome.Split.split gpart_a24Y2
                            p_a24W2 = double g_a24W1
                            (g_a24W1, gpart_a24Y2) = Genome.Split.split gpart_a24Y1
                            p_a24W0 = double g_a24VZ
                            (g_a24VZ, gpart_a24Y1) = Genome.Split.split gpart_a24Y0
                            p_a24VY = Functions.belowten' g_a24VX
                            (g_a24VX, gpart_a24Y0) = Genome.Split.split gpart_a24XZ
                            p_a24VW = double g_a24VV
                            (g_a24VV, gpart_a24XZ) = Genome.Split.split gpart_a24XY
                            p_a24VU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VT
                            (g_a24VT, gpart_a24XY) = Genome.Split.split gpart_a24XX
                            p_a24VS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24VR
                            (g_a24VR, gpart_a24XX) = Genome.Split.split gpart_a24XW
                            p_a24VQ = double g_a24VP
                            (g_a24VP, gpart_a24XW) = Genome.Split.split gpart_a24XV
                            p_a24VO = Functions.belowten' g_a24VN
                            (g_a24VN, gpart_a24XV) = Genome.Split.split gpart_a24XU
                            p_a24VM = double g_a24VL
                            (g_a24VL, gpart_a24XU) = Genome.Split.split gpart_a24XT
                            p_a24VK = Functions.belowten' g_a24VJ
                            (g_a24VJ, gpart_a24XT) = Genome.Split.split gpart_a24XS
                            p_a24VI = double g_a24VH
                            (g_a24VH, gpart_a24XS) = Genome.Split.split gpart_a24XR
                            p_a24VG = double g_a24VF
                            (g_a24VF, gpart_a24XR) = Genome.Split.split gpart_a24XQ
                            p_a24VE = Functions.belowten' g_a24VD
                            (g_a24VD, gpart_a24XQ) = Genome.Split.split gpart_a24XP
                            p_a24VC = double g_a24VB
                            (g_a24VB, gpart_a24XP) = Genome.Split.split gpart_a24XO
                            p_a24VA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Vz
                            (g_a24Vz, gpart_a24XO) = Genome.Split.split gpart_a24XN
                            p_a24Vy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Vx
                            (g_a24Vx, gpart_a24XN) = Genome.Split.split gpart_a24XM
                            p_a24Vw = Functions.belowten' g_a24Vv
                            (g_a24Vv, gpart_a24XM) = Genome.Split.split gpart_a24XL
                            p_a24Vu = double g_a24Vt
                            (g_a24Vt, gpart_a24XL) = Genome.Split.split gpart_a24XK
                            p_a24Vs = double g_a24Vr
                            (g_a24Vr, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                            p_a24Vq = double g_a24Vp
                            (g_a24Vp, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                            p_a24Vo = double g_a24Vn
                            (g_a24Vn, gpart_a24XI) = Genome.Split.split gpart_a24XH
                            p_a24Vm = double g_a24Vl
                            (g_a24Vl, gpart_a24XH) = Genome.Split.split gpart_a24XG
                            p_a24Vk = double g_a24Vj
                            (g_a24Vj, gpart_a24XG) = Genome.Split.split genome_a24WD
                          in
                            \ desc_a24WE
                              -> case desc_a24WE of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vk)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vm)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vo)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vq)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vs)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vu)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vw)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Vy)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VA)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VC)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VE)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VG)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VI)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VK)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VM)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VO)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VQ)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VS)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VU)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VW)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24VY)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W0)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W2)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W4)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W6)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24W8)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a250O
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a251u
                      p_a250N = double g_a250M
                      (g_a250M, gpart_a251u) = Genome.Split.split gpart_a251t
                      p_a250L = double g_a250K
                      (g_a250K, gpart_a251t) = Genome.Split.split gpart_a251s
                      p_a250J = double g_a250I
                      (g_a250I, gpart_a251s) = Genome.Split.split gpart_a251r
                      p_a250H = double g_a250G
                      (g_a250G, gpart_a251r) = Genome.Split.split gpart_a251q
                      p_a250F = double g_a250E
                      (g_a250E, gpart_a251q) = Genome.Split.split gpart_a251p
                      p_a250D = double g_a250C
                      (g_a250C, gpart_a251p) = Genome.Split.split gpart_a251o
                      p_a250B = Functions.belowten' g_a250A
                      (g_a250A, gpart_a251o) = Genome.Split.split gpart_a251n
                      p_a250z = double g_a250y
                      (g_a250y, gpart_a251n) = Genome.Split.split gpart_a251m
                      p_a250x = Functions.belowten' g_a250w
                      (g_a250w, gpart_a251m) = Genome.Split.split gpart_a251l
                      p_a250v = double g_a250u
                      (g_a250u, gpart_a251l) = Genome.Split.split gpart_a251k
                      p_a250t = double g_a250s
                      (g_a250s, gpart_a251k) = Genome.Split.split gpart_a251j
                      p_a250r = double g_a250q
                      (g_a250q, gpart_a251j) = Genome.Split.split gpart_a251i
                      p_a250p = Functions.belowten' g_a250o
                      (g_a250o, gpart_a251i) = Genome.Split.split gpart_a251h
                      p_a250n = double g_a250m
                      (g_a250m, gpart_a251h) = Genome.Split.split gpart_a251g
                      p_a250l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250k
                      (g_a250k, gpart_a251g) = Genome.Split.split gpart_a251f
                      p_a250j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250i
                      (g_a250i, gpart_a251f) = Genome.Split.split gpart_a251e
                      p_a250h = Functions.belowten' g_a250g
                      (g_a250g, gpart_a251e) = Genome.Split.split gpart_a251d
                      p_a250f = double g_a250e
                      (g_a250e, gpart_a251d) = Genome.Split.split gpart_a251c
                      p_a250d = double g_a250c
                      (g_a250c, gpart_a251c) = Genome.Split.split gpart_a251b
                      p_a250b = double g_a250a
                      (g_a250a, gpart_a251b) = Genome.Split.split gpart_a251a
                      p_a2509 = Functions.belowten' g_a2508
                      (g_a2508, gpart_a251a) = Genome.Split.split gpart_a2519
                      p_a2507 = double g_a2506
                      (g_a2506, gpart_a2519) = Genome.Split.split gpart_a2518
                      p_a2505
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2504
                      (g_a2504, gpart_a2518) = Genome.Split.split gpart_a2517
                      p_a2503
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2502
                      (g_a2502, gpart_a2517) = Genome.Split.split gpart_a2516
                      p_a2501 = double g_a2500
                      (g_a2500, gpart_a2516) = Genome.Split.split gpart_a2515
                      p_a24ZZ = Functions.belowten' g_a24ZY
                      (g_a24ZY, gpart_a2515) = Genome.Split.split gpart_a2514
                      p_a24ZX = double g_a24ZW
                      (g_a24ZW, gpart_a2514) = Genome.Split.split gpart_a2513
                      p_a24ZV = Functions.belowten' g_a24ZU
                      (g_a24ZU, gpart_a2513) = Genome.Split.split gpart_a2512
                      p_a24ZT = double g_a24ZS
                      (g_a24ZS, gpart_a2512) = Genome.Split.split gpart_a2511
                      p_a24ZR = double g_a24ZQ
                      (g_a24ZQ, gpart_a2511) = Genome.Split.split gpart_a2510
                      p_a24ZP = Functions.belowten' g_a24ZO
                      (g_a24ZO, gpart_a2510) = Genome.Split.split gpart_a250Z
                      p_a24ZN = double g_a24ZM
                      (g_a24ZM, gpart_a250Z) = Genome.Split.split gpart_a250Y
                      p_a24ZL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ZK
                      (g_a24ZK, gpart_a250Y) = Genome.Split.split gpart_a250X
                      p_a24ZJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ZI
                      (g_a24ZI, gpart_a250X) = Genome.Split.split gpart_a250W
                      p_a24ZH = Functions.belowten' g_a24ZG
                      (g_a24ZG, gpart_a250W) = Genome.Split.split gpart_a250V
                      p_a24ZF = double g_a24ZE
                      (g_a24ZE, gpart_a250V) = Genome.Split.split gpart_a250U
                      p_a24ZD = double g_a24ZC
                      (g_a24ZC, gpart_a250U) = Genome.Split.split gpart_a250T
                      p_a24ZB = double g_a24ZA
                      (g_a24ZA, gpart_a250T) = Genome.Split.split gpart_a250S
                      p_a24Zz = double g_a24Zy
                      (g_a24Zy, gpart_a250S) = Genome.Split.split gpart_a250R
                      p_a24Zx = double g_a24Zw
                      (g_a24Zw, gpart_a250R) = Genome.Split.split gpart_a250Q
                      p_a24Zv = double g_a24Zu
                      (g_a24Zu, gpart_a250Q) = Genome.Split.split genome_a250O
                    in  \ x_a251v
                          -> let
                               c_PTB_a251z
                                 = ((Data.Fixed.Vector.toVector x_a251v) Data.Vector.Unboxed.! 0)
                               c_NPTB_a251w
                                 = ((Data.Fixed.Vector.toVector x_a251v) Data.Vector.Unboxed.! 1)
                               c_MiRs_a251x
                                 = ((Data.Fixed.Vector.toVector x_a251v) Data.Vector.Unboxed.! 2)
                               c_RESTc_a251E
                                 = ((Data.Fixed.Vector.toVector x_a251v) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a251Q
                                 = ((Data.Fixed.Vector.toVector x_a251v) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24ZD
                                     / (1
                                        + (((c_NPTB_a251w / p_a24ZF) ** p_a24ZH)
                                           + ((c_MiRs_a251x / p_a24ZN) ** p_a24ZP))))
                                    + (negate (p_a250F * c_PTB_a251z))),
                                   ((p_a24ZR
                                     / (1
                                        + (((c_MiRs_a251x / p_a24ZT) ** p_a24ZV)
                                           + ((c_PTB_a251z / p_a24ZX) ** p_a24ZZ))))
                                    + (negate (p_a250H * c_NPTB_a251w))),
                                   ((p_a2501
                                     * (p_a250b
                                        / ((1 + p_a250b) + ((c_RESTc_a251E / p_a2507) ** p_a2509))))
                                    + (negate (p_a250J * c_MiRs_a251x))),
                                   ((p_a250d
                                     * ((p_a250r + ((c_PTB_a251z / p_a250f) ** p_a250h))
                                        / (((1 + p_a250r) + ((c_PTB_a251z / p_a250f) ** p_a250h))
                                           + ((c_MiRs_a251x / p_a250n) ** p_a250p))))
                                    + (negate (p_a250L * c_RESTc_a251E))),
                                   ((p_a250t
                                     * ((p_a250D + ((c_MiRs_a251x / p_a250v) ** p_a250x))
                                        / (((1 + p_a250D) + ((c_MiRs_a251x / p_a250v) ** p_a250x))
                                           + ((c_RESTc_a251E / p_a250z) ** p_a250B))))
                                    + (negate (p_a250N * c_EndoNeuroTFs_a251Q)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505651",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505653",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505671",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505673",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505687",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505689",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505717",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a250O
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a252v
                            p_a250N = double g_a250M
                            (g_a250M, gpart_a252v) = Genome.Split.split gpart_a252u
                            p_a250L = double g_a250K
                            (g_a250K, gpart_a252u) = Genome.Split.split gpart_a252t
                            p_a250J = double g_a250I
                            (g_a250I, gpart_a252t) = Genome.Split.split gpart_a252s
                            p_a250H = double g_a250G
                            (g_a250G, gpart_a252s) = Genome.Split.split gpart_a252r
                            p_a250F = double g_a250E
                            (g_a250E, gpart_a252r) = Genome.Split.split gpart_a252q
                            p_a250D = double g_a250C
                            (g_a250C, gpart_a252q) = Genome.Split.split gpart_a252p
                            p_a250B = Functions.belowten' g_a250A
                            (g_a250A, gpart_a252p) = Genome.Split.split gpart_a252o
                            p_a250z = double g_a250y
                            (g_a250y, gpart_a252o) = Genome.Split.split gpart_a252n
                            p_a250x = Functions.belowten' g_a250w
                            (g_a250w, gpart_a252n) = Genome.Split.split gpart_a252m
                            p_a250v = double g_a250u
                            (g_a250u, gpart_a252m) = Genome.Split.split gpart_a252l
                            p_a250t = double g_a250s
                            (g_a250s, gpart_a252l) = Genome.Split.split gpart_a252k
                            p_a250r = double g_a250q
                            (g_a250q, gpart_a252k) = Genome.Split.split gpart_a252j
                            p_a250p = Functions.belowten' g_a250o
                            (g_a250o, gpart_a252j) = Genome.Split.split gpart_a252i
                            p_a250n = double g_a250m
                            (g_a250m, gpart_a252i) = Genome.Split.split gpart_a252h
                            p_a250l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250k
                            (g_a250k, gpart_a252h) = Genome.Split.split gpart_a252g
                            p_a250j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250i
                            (g_a250i, gpart_a252g) = Genome.Split.split gpart_a252f
                            p_a250h = Functions.belowten' g_a250g
                            (g_a250g, gpart_a252f) = Genome.Split.split gpart_a252e
                            p_a250f = double g_a250e
                            (g_a250e, gpart_a252e) = Genome.Split.split gpart_a252d
                            p_a250d = double g_a250c
                            (g_a250c, gpart_a252d) = Genome.Split.split gpart_a252c
                            p_a250b = double g_a250a
                            (g_a250a, gpart_a252c) = Genome.Split.split gpart_a252b
                            p_a2509 = Functions.belowten' g_a2508
                            (g_a2508, gpart_a252b) = Genome.Split.split gpart_a252a
                            p_a2507 = double g_a2506
                            (g_a2506, gpart_a252a) = Genome.Split.split gpart_a2529
                            p_a2505
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2504
                            (g_a2504, gpart_a2529) = Genome.Split.split gpart_a2528
                            p_a2503
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2502
                            (g_a2502, gpart_a2528) = Genome.Split.split gpart_a2527
                            p_a2501 = double g_a2500
                            (g_a2500, gpart_a2527) = Genome.Split.split gpart_a2526
                            p_a24ZZ = Functions.belowten' g_a24ZY
                            (g_a24ZY, gpart_a2526) = Genome.Split.split gpart_a2525
                            p_a24ZX = double g_a24ZW
                            (g_a24ZW, gpart_a2525) = Genome.Split.split gpart_a2524
                            p_a24ZV = Functions.belowten' g_a24ZU
                            (g_a24ZU, gpart_a2524) = Genome.Split.split gpart_a2523
                            p_a24ZT = double g_a24ZS
                            (g_a24ZS, gpart_a2523) = Genome.Split.split gpart_a2522
                            p_a24ZR = double g_a24ZQ
                            (g_a24ZQ, gpart_a2522) = Genome.Split.split gpart_a2521
                            p_a24ZP = Functions.belowten' g_a24ZO
                            (g_a24ZO, gpart_a2521) = Genome.Split.split gpart_a2520
                            p_a24ZN = double g_a24ZM
                            (g_a24ZM, gpart_a2520) = Genome.Split.split gpart_a251Z
                            p_a24ZL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ZK
                            (g_a24ZK, gpart_a251Z) = Genome.Split.split gpart_a251Y
                            p_a24ZJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24ZI
                            (g_a24ZI, gpart_a251Y) = Genome.Split.split gpart_a251X
                            p_a24ZH = Functions.belowten' g_a24ZG
                            (g_a24ZG, gpart_a251X) = Genome.Split.split gpart_a251W
                            p_a24ZF = double g_a24ZE
                            (g_a24ZE, gpart_a251W) = Genome.Split.split gpart_a251V
                            p_a24ZD = double g_a24ZC
                            (g_a24ZC, gpart_a251V) = Genome.Split.split gpart_a251U
                            p_a24ZB = double g_a24ZA
                            (g_a24ZA, gpart_a251U) = Genome.Split.split gpart_a251T
                            p_a24Zz = double g_a24Zy
                            (g_a24Zy, gpart_a251T) = Genome.Split.split gpart_a251S
                            p_a24Zx = double g_a24Zw
                            (g_a24Zw, gpart_a251S) = Genome.Split.split gpart_a251R
                            p_a24Zv = double g_a24Zu
                            (g_a24Zu, gpart_a251R) = Genome.Split.split genome_a250O
                          in
                            \ desc_a250P
                              -> case desc_a250P of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Zv)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Zx)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Zz)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZB)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZD)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZF)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZH)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZJ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZL)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZN)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZP)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZR)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZT)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZV)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZX)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24ZZ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2501)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2503)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2505)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2507)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2509)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250b)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250d)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250f)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250h)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250j)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250l)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250n)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250p)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250r)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250t)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250v)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250x)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250z)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250B)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250D)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250F)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250H)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250J)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250L)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250N)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a254Z
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a255F
                      p_a254Y = double g_a254X
                      (g_a254X, gpart_a255F) = Genome.Split.split gpart_a255E
                      p_a254W = double g_a254V
                      (g_a254V, gpart_a255E) = Genome.Split.split gpart_a255D
                      p_a254U = double g_a254T
                      (g_a254T, gpart_a255D) = Genome.Split.split gpart_a255C
                      p_a254S = double g_a254R
                      (g_a254R, gpart_a255C) = Genome.Split.split gpart_a255B
                      p_a254Q = double g_a254P
                      (g_a254P, gpart_a255B) = Genome.Split.split gpart_a255A
                      p_a254O = double g_a254N
                      (g_a254N, gpart_a255A) = Genome.Split.split gpart_a255z
                      p_a254M = Functions.belowten' g_a254L
                      (g_a254L, gpart_a255z) = Genome.Split.split gpart_a255y
                      p_a254K = double g_a254J
                      (g_a254J, gpart_a255y) = Genome.Split.split gpart_a255x
                      p_a254I = Functions.belowten' g_a254H
                      (g_a254H, gpart_a255x) = Genome.Split.split gpart_a255w
                      p_a254G = double g_a254F
                      (g_a254F, gpart_a255w) = Genome.Split.split gpart_a255v
                      p_a254E = double g_a254D
                      (g_a254D, gpart_a255v) = Genome.Split.split gpart_a255u
                      p_a254C = double g_a254B
                      (g_a254B, gpart_a255u) = Genome.Split.split gpart_a255t
                      p_a254A = Functions.belowten' g_a254z
                      (g_a254z, gpart_a255t) = Genome.Split.split gpart_a255s
                      p_a254y = double g_a254x
                      (g_a254x, gpart_a255s) = Genome.Split.split gpart_a255r
                      p_a254w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254v
                      (g_a254v, gpart_a255r) = Genome.Split.split gpart_a255q
                      p_a254u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254t
                      (g_a254t, gpart_a255q) = Genome.Split.split gpart_a255p
                      p_a254s = Functions.belowten' g_a254r
                      (g_a254r, gpart_a255p) = Genome.Split.split gpart_a255o
                      p_a254q = double g_a254p
                      (g_a254p, gpart_a255o) = Genome.Split.split gpart_a255n
                      p_a254o = double g_a254n
                      (g_a254n, gpart_a255n) = Genome.Split.split gpart_a255m
                      p_a254m = double g_a254l
                      (g_a254l, gpart_a255m) = Genome.Split.split gpart_a255l
                      p_a254k = Functions.belowten' g_a254j
                      (g_a254j, gpart_a255l) = Genome.Split.split gpart_a255k
                      p_a254i = double g_a254h
                      (g_a254h, gpart_a255k) = Genome.Split.split gpart_a255j
                      p_a254g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254f
                      (g_a254f, gpart_a255j) = Genome.Split.split gpart_a255i
                      p_a254e
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254d
                      (g_a254d, gpart_a255i) = Genome.Split.split gpart_a255h
                      p_a254c = double g_a254b
                      (g_a254b, gpart_a255h) = Genome.Split.split gpart_a255g
                      p_a254a = Functions.belowten' g_a2549
                      (g_a2549, gpart_a255g) = Genome.Split.split gpart_a255f
                      p_a2548 = double g_a2547
                      (g_a2547, gpart_a255f) = Genome.Split.split gpart_a255e
                      p_a2546 = Functions.belowten' g_a2545
                      (g_a2545, gpart_a255e) = Genome.Split.split gpart_a255d
                      p_a2544 = double g_a2543
                      (g_a2543, gpart_a255d) = Genome.Split.split gpart_a255c
                      p_a2542 = double g_a2541
                      (g_a2541, gpart_a255c) = Genome.Split.split gpart_a255b
                      p_a2540 = Functions.belowten' g_a253Z
                      (g_a253Z, gpart_a255b) = Genome.Split.split gpart_a255a
                      p_a253Y = double g_a253X
                      (g_a253X, gpart_a255a) = Genome.Split.split gpart_a2559
                      p_a253W
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a253V
                      (g_a253V, gpart_a2559) = Genome.Split.split gpart_a2558
                      p_a253U
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a253T
                      (g_a253T, gpart_a2558) = Genome.Split.split gpart_a2557
                      p_a253S = Functions.belowten' g_a253R
                      (g_a253R, gpart_a2557) = Genome.Split.split gpart_a2556
                      p_a253Q = double g_a253P
                      (g_a253P, gpart_a2556) = Genome.Split.split gpart_a2555
                      p_a253O = double g_a253N
                      (g_a253N, gpart_a2555) = Genome.Split.split gpart_a2554
                      p_a253M = double g_a253L
                      (g_a253L, gpart_a2554) = Genome.Split.split gpart_a2553
                      p_a253K = double g_a253J
                      (g_a253J, gpart_a2553) = Genome.Split.split gpart_a2552
                      p_a253I = double g_a253H
                      (g_a253H, gpart_a2552) = Genome.Split.split gpart_a2551
                      p_a253G = double g_a253F
                      (g_a253F, gpart_a2551) = Genome.Split.split genome_a254Z
                    in  \ x_a255G
                          -> let
                               c_PTB_a255K
                                 = ((Data.Fixed.Vector.toVector x_a255G) Data.Vector.Unboxed.! 0)
                               c_NPTB_a255H
                                 = ((Data.Fixed.Vector.toVector x_a255G) Data.Vector.Unboxed.! 1)
                               c_MiRs_a255I
                                 = ((Data.Fixed.Vector.toVector x_a255G) Data.Vector.Unboxed.! 2)
                               c_RESTc_a255P
                                 = ((Data.Fixed.Vector.toVector x_a255G) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a2561
                                 = ((Data.Fixed.Vector.toVector x_a255G) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a253O
                                     / (1
                                        + ((((c_NPTB_a255H / p_a253Q) ** p_a253S)
                                            + ((p_a253G / p_a253U) ** p_a253W))
                                           + ((c_MiRs_a255I / p_a253Y) ** p_a2540))))
                                    + (negate (p_a254Q * c_PTB_a255K))),
                                   ((p_a2542
                                     / (1
                                        + (((c_MiRs_a255I / p_a2544) ** p_a2546)
                                           + ((c_PTB_a255K / p_a2548) ** p_a254a))))
                                    + (negate (p_a254S * c_NPTB_a255H))),
                                   ((p_a254c
                                     * (p_a254m
                                        / ((1 + p_a254m) + ((c_RESTc_a255P / p_a254i) ** p_a254k))))
                                    + (negate (p_a254U * c_MiRs_a255I))),
                                   ((p_a254o
                                     * ((p_a254C + ((c_PTB_a255K / p_a254q) ** p_a254s))
                                        / (((1 + p_a254C) + ((c_PTB_a255K / p_a254q) ** p_a254s))
                                           + ((c_MiRs_a255I / p_a254y) ** p_a254A))))
                                    + (negate (p_a254W * c_RESTc_a255P))),
                                   ((p_a254E
                                     * ((p_a254O + ((c_MiRs_a255I / p_a254G) ** p_a254I))
                                        / (((1 + p_a254O) + ((c_MiRs_a255I / p_a254G) ** p_a254I))
                                           + ((c_RESTc_a255P / p_a254K) ** p_a254M))))
                                    + (negate (p_a254Y * c_EndoNeuroTFs_a2561)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505910",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505912",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505930",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505932",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505946",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505948",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a254Z
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a256G
                            p_a254Y = double g_a254X
                            (g_a254X, gpart_a256G) = Genome.Split.split gpart_a256F
                            p_a254W = double g_a254V
                            (g_a254V, gpart_a256F) = Genome.Split.split gpart_a256E
                            p_a254U = double g_a254T
                            (g_a254T, gpart_a256E) = Genome.Split.split gpart_a256D
                            p_a254S = double g_a254R
                            (g_a254R, gpart_a256D) = Genome.Split.split gpart_a256C
                            p_a254Q = double g_a254P
                            (g_a254P, gpart_a256C) = Genome.Split.split gpart_a256B
                            p_a254O = double g_a254N
                            (g_a254N, gpart_a256B) = Genome.Split.split gpart_a256A
                            p_a254M = Functions.belowten' g_a254L
                            (g_a254L, gpart_a256A) = Genome.Split.split gpart_a256z
                            p_a254K = double g_a254J
                            (g_a254J, gpart_a256z) = Genome.Split.split gpart_a256y
                            p_a254I = Functions.belowten' g_a254H
                            (g_a254H, gpart_a256y) = Genome.Split.split gpart_a256x
                            p_a254G = double g_a254F
                            (g_a254F, gpart_a256x) = Genome.Split.split gpart_a256w
                            p_a254E = double g_a254D
                            (g_a254D, gpart_a256w) = Genome.Split.split gpart_a256v
                            p_a254C = double g_a254B
                            (g_a254B, gpart_a256v) = Genome.Split.split gpart_a256u
                            p_a254A = Functions.belowten' g_a254z
                            (g_a254z, gpart_a256u) = Genome.Split.split gpart_a256t
                            p_a254y = double g_a254x
                            (g_a254x, gpart_a256t) = Genome.Split.split gpart_a256s
                            p_a254w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254v
                            (g_a254v, gpart_a256s) = Genome.Split.split gpart_a256r
                            p_a254u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254t
                            (g_a254t, gpart_a256r) = Genome.Split.split gpart_a256q
                            p_a254s = Functions.belowten' g_a254r
                            (g_a254r, gpart_a256q) = Genome.Split.split gpart_a256p
                            p_a254q = double g_a254p
                            (g_a254p, gpart_a256p) = Genome.Split.split gpart_a256o
                            p_a254o = double g_a254n
                            (g_a254n, gpart_a256o) = Genome.Split.split gpart_a256n
                            p_a254m = double g_a254l
                            (g_a254l, gpart_a256n) = Genome.Split.split gpart_a256m
                            p_a254k = Functions.belowten' g_a254j
                            (g_a254j, gpart_a256m) = Genome.Split.split gpart_a256l
                            p_a254i = double g_a254h
                            (g_a254h, gpart_a256l) = Genome.Split.split gpart_a256k
                            p_a254g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254f
                            (g_a254f, gpart_a256k) = Genome.Split.split gpart_a256j
                            p_a254e
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a254d
                            (g_a254d, gpart_a256j) = Genome.Split.split gpart_a256i
                            p_a254c = double g_a254b
                            (g_a254b, gpart_a256i) = Genome.Split.split gpart_a256h
                            p_a254a = Functions.belowten' g_a2549
                            (g_a2549, gpart_a256h) = Genome.Split.split gpart_a256g
                            p_a2548 = double g_a2547
                            (g_a2547, gpart_a256g) = Genome.Split.split gpart_a256f
                            p_a2546 = Functions.belowten' g_a2545
                            (g_a2545, gpart_a256f) = Genome.Split.split gpart_a256e
                            p_a2544 = double g_a2543
                            (g_a2543, gpart_a256e) = Genome.Split.split gpart_a256d
                            p_a2542 = double g_a2541
                            (g_a2541, gpart_a256d) = Genome.Split.split gpart_a256c
                            p_a2540 = Functions.belowten' g_a253Z
                            (g_a253Z, gpart_a256c) = Genome.Split.split gpart_a256b
                            p_a253Y = double g_a253X
                            (g_a253X, gpart_a256b) = Genome.Split.split gpart_a256a
                            p_a253W
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a253V
                            (g_a253V, gpart_a256a) = Genome.Split.split gpart_a2569
                            p_a253U
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a253T
                            (g_a253T, gpart_a2569) = Genome.Split.split gpart_a2568
                            p_a253S = Functions.belowten' g_a253R
                            (g_a253R, gpart_a2568) = Genome.Split.split gpart_a2567
                            p_a253Q = double g_a253P
                            (g_a253P, gpart_a2567) = Genome.Split.split gpart_a2566
                            p_a253O = double g_a253N
                            (g_a253N, gpart_a2566) = Genome.Split.split gpart_a2565
                            p_a253M = double g_a253L
                            (g_a253L, gpart_a2565) = Genome.Split.split gpart_a2564
                            p_a253K = double g_a253J
                            (g_a253J, gpart_a2564) = Genome.Split.split gpart_a2563
                            p_a253I = double g_a253H
                            (g_a253H, gpart_a2563) = Genome.Split.split gpart_a2562
                            p_a253G = double g_a253F
                            (g_a253F, gpart_a2562) = Genome.Split.split genome_a254Z
                          in
                            \ desc_a2550
                              -> case desc_a2550 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253G)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253I)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253K)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253M)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253O)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253Q)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253S)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253U)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253W)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a253Y)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2540)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2542)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2544)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2546)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2548)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254a)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254c)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254e)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254g)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254i)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254k)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254m)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254o)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254q)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254s)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254u)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254w)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254y)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254A)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254C)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254E)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254G)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254I)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254K)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254M)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254O)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254Q)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254S)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254U)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254W)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a254Y)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asWT
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXz
                      p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                      (g_asWR, gpart_asXz) = Genome.Split.split gpart_asXy
                      p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                      (g_asWP, gpart_asXy) = Genome.Split.split gpart_asXx
                      p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                      (g_asWN, gpart_asXx) = Genome.Split.split gpart_asXw
                      p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                      (g_asWL, gpart_asXw) = Genome.Split.split gpart_asXv
                      p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                      (g_asWJ, gpart_asXv) = Genome.Split.split gpart_asXu
                      p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                      (g_asWH, gpart_asXu) = Genome.Split.split gpart_asXt
                      p_asWG = Functions.belowten' g_asWF
                      (g_asWF, gpart_asXt) = Genome.Split.split gpart_asXs
                      p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                      (g_asWD, gpart_asXs) = Genome.Split.split gpart_asXr
                      p_asWC = Functions.belowten' g_asWB
                      (g_asWB, gpart_asXr) = Genome.Split.split gpart_asXq
                      p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                      (g_asWz, gpart_asXq) = Genome.Split.split gpart_asXp
                      p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                      (g_asWx, gpart_asXp) = Genome.Split.split gpart_asXo
                      p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                      (g_asWv, gpart_asXo) = Genome.Split.split gpart_asXn
                      p_asWu = Functions.belowten' g_asWt
                      (g_asWt, gpart_asXn) = Genome.Split.split gpart_asXm
                      p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                      (g_asWr, gpart_asXm) = Genome.Split.split gpart_asXl
                      p_asWq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWp
                      (g_asWp, gpart_asXl) = Genome.Split.split gpart_asXk
                      p_asWo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWn
                      (g_asWn, gpart_asXk) = Genome.Split.split gpart_asXj
                      p_asWm = Functions.belowten' g_asWl
                      (g_asWl, gpart_asXj) = Genome.Split.split gpart_asXi
                      p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                      (g_asWj, gpart_asXi) = Genome.Split.split gpart_asXh
                      p_asWi = code-0.1.0.0:Genome.FixedList.Functions.double g_asWh
                      (g_asWh, gpart_asXh) = Genome.Split.split gpart_asXg
                      p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                      (g_asWf, gpart_asXg) = Genome.Split.split gpart_asXf
                      p_asWe = Functions.belowten' g_asWd
                      (g_asWd, gpart_asXf) = Genome.Split.split gpart_asXe
                      p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                      (g_asWb, gpart_asXe) = Genome.Split.split gpart_asXd
                      p_asWa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW9
                      (g_asW9, gpart_asXd) = Genome.Split.split gpart_asXc
                      p_asW8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW7
                      (g_asW7, gpart_asXc) = Genome.Split.split gpart_asXb
                      p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                      (g_asW5, gpart_asXb) = Genome.Split.split gpart_asXa
                      p_asW4 = Functions.belowten' g_asW3
                      (g_asW3, gpart_asXa) = Genome.Split.split gpart_asX9
                      p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                      (g_asW1, gpart_asX9) = Genome.Split.split gpart_asX8
                      p_asW0 = Functions.belowten' g_asVZ
                      (g_asVZ, gpart_asX8) = Genome.Split.split gpart_asX7
                      p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                      (g_asVX, gpart_asX7) = Genome.Split.split gpart_asX6
                      p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                      (g_asVV, gpart_asX6) = Genome.Split.split gpart_asX5
                      p_asVU = Functions.belowten' g_asVT
                      (g_asVT, gpart_asX5) = Genome.Split.split gpart_asX4
                      p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                      (g_asVR, gpart_asX4) = Genome.Split.split gpart_asX3
                      p_asVQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVP
                      (g_asVP, gpart_asX3) = Genome.Split.split gpart_asX2
                      p_asVO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVN
                      (g_asVN, gpart_asX2) = Genome.Split.split gpart_asX1
                      p_asVM = Functions.belowten' g_asVL
                      (g_asVL, gpart_asX1) = Genome.Split.split gpart_asX0
                      p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                      (g_asVJ, gpart_asX0) = Genome.Split.split gpart_asWZ
                      p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                      (g_asVH, gpart_asWZ) = Genome.Split.split gpart_asWY
                      p_asVG = code-0.1.0.0:Genome.FixedList.Functions.double g_asVF
                      (g_asVF, gpart_asWY) = Genome.Split.split gpart_asWX
                      p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                      (g_asVD, gpart_asWX) = Genome.Split.split gpart_asWW
                      p_asVC = code-0.1.0.0:Genome.FixedList.Functions.double g_asVB
                      (g_asVB, gpart_asWW) = Genome.Split.split gpart_asWV
                      p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                      (g_asVz, gpart_asWV) = Genome.Split.split genome_asWT
                    in
                      [Reaction
                         (\ x_asXA
                            -> let
                                 c_NPTB_asXB = ((toVector x_asXA) Data.Vector.Unboxed.! 1)
                                 c_MiRs_asXC = ((toVector x_asXA) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asVI
                                  / (1
                                     + (((c_NPTB_asXB / p_asVK) ** p_asVM)
                                        + ((c_MiRs_asXC / p_asVS) ** p_asVU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXD
                            -> let
                                 c_MiRs_asXE = ((toVector x_asXD) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXF = ((toVector x_asXD) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asVW
                                  / (1
                                     + (((c_MiRs_asXE / p_asVY) ** p_asW0)
                                        + ((c_PTB_asXF / p_asW2) ** p_asW4)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asXG
                            -> let c_RESTc_asXH = ((toVector x_asXG) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asW6
                                  * ((p_asWg + ((p_asVE / p_asW8) ** p_asWa))
                                     / (((1 + p_asWg) + ((p_asVE / p_asW8) ** p_asWa))
                                        + ((c_RESTc_asXH / p_asWc) ** p_asWe)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asXI
                            -> let
                                 c_MiRs_asXL = ((toVector x_asXI) Data.Vector.Unboxed.! 2)
                                 c_PTB_asXJ = ((toVector x_asXI) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWi
                                  * ((p_asWw + ((c_PTB_asXJ / p_asWk) ** p_asWm))
                                     / (((1 + p_asWw) + ((c_PTB_asXJ / p_asWk) ** p_asWm))
                                        + (((p_asVA / p_asWo) ** p_asWq)
                                           + ((c_MiRs_asXL / p_asWs) ** p_asWu))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asXM
                            -> let
                                 c_RESTc_asXP = ((toVector x_asXM) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asXN = ((toVector x_asXM) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asWy
                                  * ((p_asWI + ((c_MiRs_asXN / p_asWA) ** p_asWC))
                                     / (((1 + p_asWI) + ((c_MiRs_asXN / p_asWA) ** p_asWC))
                                        + ((c_RESTc_asXP / p_asWE) ** p_asWG)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asXQ
                            -> let c_PTB_asXR = ((toVector x_asXQ) Data.Vector.Unboxed.! 0)
                               in (p_asWK * c_PTB_asXR))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asXS
                            -> let c_NPTB_asXT = ((toVector x_asXS) Data.Vector.Unboxed.! 1)
                               in (p_asWM * c_NPTB_asXT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asXU
                            -> let c_MiRs_asXV = ((toVector x_asXU) Data.Vector.Unboxed.! 2)
                               in (p_asWO * c_MiRs_asXV))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asXW
                            -> let c_RESTc_asXX = ((toVector x_asXW) Data.Vector.Unboxed.! 3)
                               in (p_asWQ * c_RESTc_asXX))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asXY
                            -> let
                                 c_EndoNeuroTFs_asXZ = ((toVector x_asXY) Data.Vector.Unboxed.! 4)
                               in (p_asWS * c_EndoNeuroTFs_asXZ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121008",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121010",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121028",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121030",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121044",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121046",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121072",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121074",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asWT
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYJ
                            p_asWS = code-0.1.0.0:Genome.FixedList.Functions.double g_asWR
                            (g_asWR, gpart_asYJ) = Genome.Split.split gpart_asYI
                            p_asWQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWP
                            (g_asWP, gpart_asYI) = Genome.Split.split gpart_asYH
                            p_asWO = code-0.1.0.0:Genome.FixedList.Functions.double g_asWN
                            (g_asWN, gpart_asYH) = Genome.Split.split gpart_asYG
                            p_asWM = code-0.1.0.0:Genome.FixedList.Functions.double g_asWL
                            (g_asWL, gpart_asYG) = Genome.Split.split gpart_asYF
                            p_asWK = code-0.1.0.0:Genome.FixedList.Functions.double g_asWJ
                            (g_asWJ, gpart_asYF) = Genome.Split.split gpart_asYE
                            p_asWI = code-0.1.0.0:Genome.FixedList.Functions.double g_asWH
                            (g_asWH, gpart_asYE) = Genome.Split.split gpart_asYD
                            p_asWG = Functions.belowten' g_asWF
                            (g_asWF, gpart_asYD) = Genome.Split.split gpart_asYC
                            p_asWE = code-0.1.0.0:Genome.FixedList.Functions.double g_asWD
                            (g_asWD, gpart_asYC) = Genome.Split.split gpart_asYB
                            p_asWC = Functions.belowten' g_asWB
                            (g_asWB, gpart_asYB) = Genome.Split.split gpart_asYA
                            p_asWA = code-0.1.0.0:Genome.FixedList.Functions.double g_asWz
                            (g_asWz, gpart_asYA) = Genome.Split.split gpart_asYz
                            p_asWy = code-0.1.0.0:Genome.FixedList.Functions.double g_asWx
                            (g_asWx, gpart_asYz) = Genome.Split.split gpart_asYy
                            p_asWw = code-0.1.0.0:Genome.FixedList.Functions.double g_asWv
                            (g_asWv, gpart_asYy) = Genome.Split.split gpart_asYx
                            p_asWu = Functions.belowten' g_asWt
                            (g_asWt, gpart_asYx) = Genome.Split.split gpart_asYw
                            p_asWs = code-0.1.0.0:Genome.FixedList.Functions.double g_asWr
                            (g_asWr, gpart_asYw) = Genome.Split.split gpart_asYv
                            p_asWq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWp
                            (g_asWp, gpart_asYv) = Genome.Split.split gpart_asYu
                            p_asWo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWn
                            (g_asWn, gpart_asYu) = Genome.Split.split gpart_asYt
                            p_asWm = Functions.belowten' g_asWl
                            (g_asWl, gpart_asYt) = Genome.Split.split gpart_asYs
                            p_asWk = code-0.1.0.0:Genome.FixedList.Functions.double g_asWj
                            (g_asWj, gpart_asYs) = Genome.Split.split gpart_asYr
                            p_asWi = code-0.1.0.0:Genome.FixedList.Functions.double g_asWh
                            (g_asWh, gpart_asYr) = Genome.Split.split gpart_asYq
                            p_asWg = code-0.1.0.0:Genome.FixedList.Functions.double g_asWf
                            (g_asWf, gpart_asYq) = Genome.Split.split gpart_asYp
                            p_asWe = Functions.belowten' g_asWd
                            (g_asWd, gpart_asYp) = Genome.Split.split gpart_asYo
                            p_asWc = code-0.1.0.0:Genome.FixedList.Functions.double g_asWb
                            (g_asWb, gpart_asYo) = Genome.Split.split gpart_asYn
                            p_asWa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW9
                            (g_asW9, gpart_asYn) = Genome.Split.split gpart_asYm
                            p_asW8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asW7
                            (g_asW7, gpart_asYm) = Genome.Split.split gpart_asYl
                            p_asW6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW5
                            (g_asW5, gpart_asYl) = Genome.Split.split gpart_asYk
                            p_asW4 = Functions.belowten' g_asW3
                            (g_asW3, gpart_asYk) = Genome.Split.split gpart_asYj
                            p_asW2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asW1
                            (g_asW1, gpart_asYj) = Genome.Split.split gpart_asYi
                            p_asW0 = Functions.belowten' g_asVZ
                            (g_asVZ, gpart_asYi) = Genome.Split.split gpart_asYh
                            p_asVY = code-0.1.0.0:Genome.FixedList.Functions.double g_asVX
                            (g_asVX, gpart_asYh) = Genome.Split.split gpart_asYg
                            p_asVW = code-0.1.0.0:Genome.FixedList.Functions.double g_asVV
                            (g_asVV, gpart_asYg) = Genome.Split.split gpart_asYf
                            p_asVU = Functions.belowten' g_asVT
                            (g_asVT, gpart_asYf) = Genome.Split.split gpart_asYe
                            p_asVS = code-0.1.0.0:Genome.FixedList.Functions.double g_asVR
                            (g_asVR, gpart_asYe) = Genome.Split.split gpart_asYd
                            p_asVQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVP
                            (g_asVP, gpart_asYd) = Genome.Split.split gpart_asYc
                            p_asVO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asVN
                            (g_asVN, gpart_asYc) = Genome.Split.split gpart_asYb
                            p_asVM = Functions.belowten' g_asVL
                            (g_asVL, gpart_asYb) = Genome.Split.split gpart_asYa
                            p_asVK = code-0.1.0.0:Genome.FixedList.Functions.double g_asVJ
                            (g_asVJ, gpart_asYa) = Genome.Split.split gpart_asY9
                            p_asVI = code-0.1.0.0:Genome.FixedList.Functions.double g_asVH
                            (g_asVH, gpart_asY9) = Genome.Split.split gpart_asY8
                            p_asVG = code-0.1.0.0:Genome.FixedList.Functions.double g_asVF
                            (g_asVF, gpart_asY8) = Genome.Split.split gpart_asY7
                            p_asVE = code-0.1.0.0:Genome.FixedList.Functions.double g_asVD
                            (g_asVD, gpart_asY7) = Genome.Split.split gpart_asY6
                            p_asVC = code-0.1.0.0:Genome.FixedList.Functions.double g_asVB
                            (g_asVB, gpart_asY6) = Genome.Split.split gpart_asY5
                            p_asVA = code-0.1.0.0:Genome.FixedList.Functions.double g_asVz
                            (g_asVz, gpart_asY5) = Genome.Split.split genome_asWT
                          in
                            \ desc_asWU
                              -> case desc_asWU of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVA)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVC)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVE)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVG)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVI)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVK)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVM)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVO)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVQ)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVS)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVU)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVW)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVY)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW0)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW2)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW4)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW6)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asW8)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWa)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWc)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWe)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWg)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWi)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWk)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWm)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWo)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWq)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWs)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWu)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWw)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWy)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWA)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWC)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWE)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWG)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWI)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWK)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWM)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWO)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWQ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWS)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_at0K
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1q
                      p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                      (g_at0I, gpart_at1q) = Genome.Split.split gpart_at1p
                      p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                      (g_at0G, gpart_at1p) = Genome.Split.split gpart_at1o
                      p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                      (g_at0E, gpart_at1o) = Genome.Split.split gpart_at1n
                      p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                      (g_at0C, gpart_at1n) = Genome.Split.split gpart_at1m
                      p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                      (g_at0A, gpart_at1m) = Genome.Split.split gpart_at1l
                      p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                      (g_at0y, gpart_at1l) = Genome.Split.split gpart_at1k
                      p_at0x = Functions.belowten' g_at0w
                      (g_at0w, gpart_at1k) = Genome.Split.split gpart_at1j
                      p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                      (g_at0u, gpart_at1j) = Genome.Split.split gpart_at1i
                      p_at0t = Functions.belowten' g_at0s
                      (g_at0s, gpart_at1i) = Genome.Split.split gpart_at1h
                      p_at0r = code-0.1.0.0:Genome.FixedList.Functions.double g_at0q
                      (g_at0q, gpart_at1h) = Genome.Split.split gpart_at1g
                      p_at0p = code-0.1.0.0:Genome.FixedList.Functions.double g_at0o
                      (g_at0o, gpart_at1g) = Genome.Split.split gpart_at1f
                      p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                      (g_at0m, gpart_at1f) = Genome.Split.split gpart_at1e
                      p_at0l = Functions.belowten' g_at0k
                      (g_at0k, gpart_at1e) = Genome.Split.split gpart_at1d
                      p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                      (g_at0i, gpart_at1d) = Genome.Split.split gpart_at1c
                      p_at0h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0g
                      (g_at0g, gpart_at1c) = Genome.Split.split gpart_at1b
                      p_at0f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0e
                      (g_at0e, gpart_at1b) = Genome.Split.split gpart_at1a
                      p_at0d = Functions.belowten' g_at0c
                      (g_at0c, gpart_at1a) = Genome.Split.split gpart_at19
                      p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                      (g_at0a, gpart_at19) = Genome.Split.split gpart_at18
                      p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                      (g_at08, gpart_at18) = Genome.Split.split gpart_at17
                      p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                      (g_at06, gpart_at17) = Genome.Split.split gpart_at16
                      p_at05 = Functions.belowten' g_at04
                      (g_at04, gpart_at16) = Genome.Split.split gpart_at15
                      p_at03 = code-0.1.0.0:Genome.FixedList.Functions.double g_at02
                      (g_at02, gpart_at15) = Genome.Split.split gpart_at14
                      p_at01
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at00
                      (g_at00, gpart_at14) = Genome.Split.split gpart_at13
                      p_asZZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZY
                      (g_asZY, gpart_at13) = Genome.Split.split gpart_at12
                      p_asZX = code-0.1.0.0:Genome.FixedList.Functions.double g_asZW
                      (g_asZW, gpart_at12) = Genome.Split.split gpart_at11
                      p_asZV = Functions.belowten' g_asZU
                      (g_asZU, gpart_at11) = Genome.Split.split gpart_at10
                      p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                      (g_asZS, gpart_at10) = Genome.Split.split gpart_at0Z
                      p_asZR = Functions.belowten' g_asZQ
                      (g_asZQ, gpart_at0Z) = Genome.Split.split gpart_at0Y
                      p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                      (g_asZO, gpart_at0Y) = Genome.Split.split gpart_at0X
                      p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                      (g_asZM, gpart_at0X) = Genome.Split.split gpart_at0W
                      p_asZL = Functions.belowten' g_asZK
                      (g_asZK, gpart_at0W) = Genome.Split.split gpart_at0V
                      p_asZJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZI
                      (g_asZI, gpart_at0V) = Genome.Split.split gpart_at0U
                      p_asZH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZG
                      (g_asZG, gpart_at0U) = Genome.Split.split gpart_at0T
                      p_asZF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZE
                      (g_asZE, gpart_at0T) = Genome.Split.split gpart_at0S
                      p_asZD = Functions.belowten' g_asZC
                      (g_asZC, gpart_at0S) = Genome.Split.split gpart_at0R
                      p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                      (g_asZA, gpart_at0R) = Genome.Split.split gpart_at0Q
                      p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                      (g_asZy, gpart_at0Q) = Genome.Split.split gpart_at0P
                      p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                      (g_asZw, gpart_at0P) = Genome.Split.split gpart_at0O
                      p_asZv = code-0.1.0.0:Genome.FixedList.Functions.double g_asZu
                      (g_asZu, gpart_at0O) = Genome.Split.split gpart_at0N
                      p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                      (g_asZs, gpart_at0N) = Genome.Split.split gpart_at0M
                      p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                      (g_asZq, gpart_at0M) = Genome.Split.split genome_at0K
                    in
                      [Reaction
                         (\ x_at1r
                            -> let
                                 c_NPTB_at1s = ((toVector x_at1r) Data.Vector.Unboxed.! 1)
                                 c_MiRs_at1t = ((toVector x_at1r) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZz
                                  / (1
                                     + (((c_NPTB_at1s / p_asZB) ** p_asZD)
                                        + ((c_MiRs_at1t / p_asZJ) ** p_asZL)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1u
                            -> let
                                 c_MiRs_at1v = ((toVector x_at1u) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1w = ((toVector x_at1u) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asZN
                                  / (1
                                     + (((c_MiRs_at1v / p_asZP) ** p_asZR)
                                        + ((c_PTB_at1w / p_asZT) ** p_asZV)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at1x
                            -> let c_RESTc_at1y = ((toVector x_at1x) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asZX
                                  * (p_at07
                                     / ((1 + p_at07) + ((c_RESTc_at1y / p_at03) ** p_at05)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at1z
                            -> let
                                 c_MiRs_at1C = ((toVector x_at1z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at1A = ((toVector x_at1z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at09
                                  * ((p_at0n + ((c_PTB_at1A / p_at0b) ** p_at0d))
                                     / (((1 + p_at0n) + ((c_PTB_at1A / p_at0b) ** p_at0d))
                                        + (((p_asZr / p_at0f) ** p_at0h)
                                           + ((c_MiRs_at1C / p_at0j) ** p_at0l))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at1D
                            -> let
                                 c_RESTc_at1G = ((toVector x_at1D) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at1E = ((toVector x_at1D) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at0p
                                  * ((p_at0z + ((c_MiRs_at1E / p_at0r) ** p_at0t))
                                     / (((1 + p_at0z) + ((c_MiRs_at1E / p_at0r) ** p_at0t))
                                        + ((c_RESTc_at1G / p_at0v) ** p_at0x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at1H
                            -> let c_PTB_at1I = ((toVector x_at1H) Data.Vector.Unboxed.! 0)
                               in (p_at0B * c_PTB_at1I))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at1J
                            -> let c_NPTB_at1K = ((toVector x_at1J) Data.Vector.Unboxed.! 1)
                               in (p_at0D * c_NPTB_at1K))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at1L
                            -> let c_MiRs_at1M = ((toVector x_at1L) Data.Vector.Unboxed.! 2)
                               in (p_at0F * c_MiRs_at1M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at1N
                            -> let c_RESTc_at1O = ((toVector x_at1N) Data.Vector.Unboxed.! 3)
                               in (p_at0H * c_RESTc_at1O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at1P
                            -> let
                                 c_EndoNeuroTFs_at1Q = ((toVector x_at1P) Data.Vector.Unboxed.! 4)
                               in (p_at0J * c_EndoNeuroTFs_at1Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121247",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121249",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121267",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121269",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121283",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121285",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at0K
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2v
                            p_at0J = code-0.1.0.0:Genome.FixedList.Functions.double g_at0I
                            (g_at0I, gpart_at2v) = Genome.Split.split gpart_at2u
                            p_at0H = code-0.1.0.0:Genome.FixedList.Functions.double g_at0G
                            (g_at0G, gpart_at2u) = Genome.Split.split gpart_at2t
                            p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                            (g_at0E, gpart_at2t) = Genome.Split.split gpart_at2s
                            p_at0D = code-0.1.0.0:Genome.FixedList.Functions.double g_at0C
                            (g_at0C, gpart_at2s) = Genome.Split.split gpart_at2r
                            p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                            (g_at0A, gpart_at2r) = Genome.Split.split gpart_at2q
                            p_at0z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0y
                            (g_at0y, gpart_at2q) = Genome.Split.split gpart_at2p
                            p_at0x = Functions.belowten' g_at0w
                            (g_at0w, gpart_at2p) = Genome.Split.split gpart_at2o
                            p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                            (g_at0u, gpart_at2o) = Genome.Split.split gpart_at2n
                            p_at0t = Functions.belowten' g_at0s
                            (g_at0s, gpart_at2n) = Genome.Split.split gpart_at2m
                            p_at0r = code-0.1.0.0:Genome.FixedList.Functions.double g_at0q
                            (g_at0q, gpart_at2m) = Genome.Split.split gpart_at2l
                            p_at0p = code-0.1.0.0:Genome.FixedList.Functions.double g_at0o
                            (g_at0o, gpart_at2l) = Genome.Split.split gpart_at2k
                            p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                            (g_at0m, gpart_at2k) = Genome.Split.split gpart_at2j
                            p_at0l = Functions.belowten' g_at0k
                            (g_at0k, gpart_at2j) = Genome.Split.split gpart_at2i
                            p_at0j = code-0.1.0.0:Genome.FixedList.Functions.double g_at0i
                            (g_at0i, gpart_at2i) = Genome.Split.split gpart_at2h
                            p_at0h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0g
                            (g_at0g, gpart_at2h) = Genome.Split.split gpart_at2g
                            p_at0f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0e
                            (g_at0e, gpart_at2g) = Genome.Split.split gpart_at2f
                            p_at0d = Functions.belowten' g_at0c
                            (g_at0c, gpart_at2f) = Genome.Split.split gpart_at2e
                            p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                            (g_at0a, gpart_at2e) = Genome.Split.split gpart_at2d
                            p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                            (g_at08, gpart_at2d) = Genome.Split.split gpart_at2c
                            p_at07 = code-0.1.0.0:Genome.FixedList.Functions.double g_at06
                            (g_at06, gpart_at2c) = Genome.Split.split gpart_at2b
                            p_at05 = Functions.belowten' g_at04
                            (g_at04, gpart_at2b) = Genome.Split.split gpart_at2a
                            p_at03 = code-0.1.0.0:Genome.FixedList.Functions.double g_at02
                            (g_at02, gpart_at2a) = Genome.Split.split gpart_at29
                            p_at01
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at00
                            (g_at00, gpart_at29) = Genome.Split.split gpart_at28
                            p_asZZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZY
                            (g_asZY, gpart_at28) = Genome.Split.split gpart_at27
                            p_asZX = code-0.1.0.0:Genome.FixedList.Functions.double g_asZW
                            (g_asZW, gpart_at27) = Genome.Split.split gpart_at26
                            p_asZV = Functions.belowten' g_asZU
                            (g_asZU, gpart_at26) = Genome.Split.split gpart_at25
                            p_asZT = code-0.1.0.0:Genome.FixedList.Functions.double g_asZS
                            (g_asZS, gpart_at25) = Genome.Split.split gpart_at24
                            p_asZR = Functions.belowten' g_asZQ
                            (g_asZQ, gpart_at24) = Genome.Split.split gpart_at23
                            p_asZP = code-0.1.0.0:Genome.FixedList.Functions.double g_asZO
                            (g_asZO, gpart_at23) = Genome.Split.split gpart_at22
                            p_asZN = code-0.1.0.0:Genome.FixedList.Functions.double g_asZM
                            (g_asZM, gpart_at22) = Genome.Split.split gpart_at21
                            p_asZL = Functions.belowten' g_asZK
                            (g_asZK, gpart_at21) = Genome.Split.split gpart_at20
                            p_asZJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asZI
                            (g_asZI, gpart_at20) = Genome.Split.split gpart_at1Z
                            p_asZH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZG
                            (g_asZG, gpart_at1Z) = Genome.Split.split gpart_at1Y
                            p_asZF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asZE
                            (g_asZE, gpart_at1Y) = Genome.Split.split gpart_at1X
                            p_asZD = Functions.belowten' g_asZC
                            (g_asZC, gpart_at1X) = Genome.Split.split gpart_at1W
                            p_asZB = code-0.1.0.0:Genome.FixedList.Functions.double g_asZA
                            (g_asZA, gpart_at1W) = Genome.Split.split gpart_at1V
                            p_asZz = code-0.1.0.0:Genome.FixedList.Functions.double g_asZy
                            (g_asZy, gpart_at1V) = Genome.Split.split gpart_at1U
                            p_asZx = code-0.1.0.0:Genome.FixedList.Functions.double g_asZw
                            (g_asZw, gpart_at1U) = Genome.Split.split gpart_at1T
                            p_asZv = code-0.1.0.0:Genome.FixedList.Functions.double g_asZu
                            (g_asZu, gpart_at1T) = Genome.Split.split gpart_at1S
                            p_asZt = code-0.1.0.0:Genome.FixedList.Functions.double g_asZs
                            (g_asZs, gpart_at1S) = Genome.Split.split gpart_at1R
                            p_asZr = code-0.1.0.0:Genome.FixedList.Functions.double g_asZq
                            (g_asZq, gpart_at1R) = Genome.Split.split genome_at0K
                          in
                            \ desc_at0L
                              -> case desc_at0L of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZr)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZt)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZv)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZx)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZz)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZB)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZD)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZF)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZH)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZJ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZL)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZN)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZP)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZR)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZT)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZV)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZX)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZZ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at01)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at03)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at05)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at07)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at09)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0b)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0d)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0f)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0h)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0j)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0l)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0n)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0p)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0r)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0t)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0v)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0x)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0z)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0B)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0D)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0F)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at4w
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5c
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                      (g_at4s, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                      (g_at4q, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                      (g_at4o, gpart_at59) = Genome.Split.split gpart_at58
                      p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                      (g_at4m, gpart_at58) = Genome.Split.split gpart_at57
                      p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                      (g_at4k, gpart_at57) = Genome.Split.split gpart_at56
                      p_at4j = Functions.belowten' g_at4i
                      (g_at4i, gpart_at56) = Genome.Split.split gpart_at55
                      p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                      (g_at4g, gpart_at55) = Genome.Split.split gpart_at54
                      p_at4f = Functions.belowten' g_at4e
                      (g_at4e, gpart_at54) = Genome.Split.split gpart_at53
                      p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                      (g_at4c, gpart_at53) = Genome.Split.split gpart_at52
                      p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                      (g_at4a, gpart_at52) = Genome.Split.split gpart_at51
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at51) = Genome.Split.split gpart_at50
                      p_at47 = Functions.belowten' g_at46
                      (g_at46, gpart_at50) = Genome.Split.split gpart_at4Z
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at4Z) = Genome.Split.split gpart_at4Y
                      p_at43
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at42
                      (g_at42, gpart_at4Y) = Genome.Split.split gpart_at4X
                      p_at41
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at40
                      (g_at40, gpart_at4X) = Genome.Split.split gpart_at4W
                      p_at3Z = Functions.belowten' g_at3Y
                      (g_at3Y, gpart_at4W) = Genome.Split.split gpart_at4V
                      p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                      (g_at3W, gpart_at4V) = Genome.Split.split gpart_at4U
                      p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                      (g_at3U, gpart_at4U) = Genome.Split.split gpart_at4T
                      p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                      (g_at3S, gpart_at4T) = Genome.Split.split gpart_at4S
                      p_at3R = Functions.belowten' g_at3Q
                      (g_at3Q, gpart_at4S) = Genome.Split.split gpart_at4R
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at4R) = Genome.Split.split gpart_at4Q
                      p_at3N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3M
                      (g_at3M, gpart_at4Q) = Genome.Split.split gpart_at4P
                      p_at3L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3K
                      (g_at3K, gpart_at4P) = Genome.Split.split gpart_at4O
                      p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                      (g_at3I, gpart_at4O) = Genome.Split.split gpart_at4N
                      p_at3H = Functions.belowten' g_at3G
                      (g_at3G, gpart_at4N) = Genome.Split.split gpart_at4M
                      p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                      (g_at3E, gpart_at4M) = Genome.Split.split gpart_at4L
                      p_at3D = Functions.belowten' g_at3C
                      (g_at3C, gpart_at4L) = Genome.Split.split gpart_at4K
                      p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                      (g_at3A, gpart_at4K) = Genome.Split.split gpart_at4J
                      p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                      (g_at3y, gpart_at4J) = Genome.Split.split gpart_at4I
                      p_at3x = Functions.belowten' g_at3w
                      (g_at3w, gpart_at4I) = Genome.Split.split gpart_at4H
                      p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                      (g_at3u, gpart_at4H) = Genome.Split.split gpart_at4G
                      p_at3t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3s
                      (g_at3s, gpart_at4G) = Genome.Split.split gpart_at4F
                      p_at3r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3q
                      (g_at3q, gpart_at4F) = Genome.Split.split gpart_at4E
                      p_at3p = Functions.belowten' g_at3o
                      (g_at3o, gpart_at4E) = Genome.Split.split gpart_at4D
                      p_at3n = code-0.1.0.0:Genome.FixedList.Functions.double g_at3m
                      (g_at3m, gpart_at4D) = Genome.Split.split gpart_at4C
                      p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                      (g_at3k, gpart_at4C) = Genome.Split.split gpart_at4B
                      p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                      (g_at3i, gpart_at4B) = Genome.Split.split gpart_at4A
                      p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                      (g_at3g, gpart_at4A) = Genome.Split.split gpart_at4z
                      p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                      (g_at3e, gpart_at4z) = Genome.Split.split gpart_at4y
                      p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                      (g_at3c, gpart_at4y) = Genome.Split.split genome_at4w
                    in
                      [Reaction
                         (\ x_at5d
                            -> let
                                 c_NPTB_at5e = ((toVector x_at5d) Data.Vector.Unboxed.! 1)
                                 c_MiRs_at5f = ((toVector x_at5d) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3l
                                  / (1
                                     + (((c_NPTB_at5e / p_at3n) ** p_at3p)
                                        + ((c_MiRs_at5f / p_at3v) ** p_at3x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5g
                            -> let
                                 c_MiRs_at5h = ((toVector x_at5g) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5i = ((toVector x_at5g) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3z
                                  / (1
                                     + (((c_MiRs_at5h / p_at3B) ** p_at3D)
                                        + ((c_PTB_at5i / p_at3F) ** p_at3H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5j
                            -> let c_RESTc_at5k = ((toVector x_at5j) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at3J
                                  * (p_at3T
                                     / ((1 + p_at3T) + ((c_RESTc_at5k / p_at3P) ** p_at3R)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5l
                            -> let
                                 c_MiRs_at5o = ((toVector x_at5l) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5m = ((toVector x_at5l) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at3V
                                  * ((p_at49 + ((c_PTB_at5m / p_at3X) ** p_at3Z))
                                     / (((1 + p_at49) + ((c_PTB_at5m / p_at3X) ** p_at3Z))
                                        + ((c_MiRs_at5o / p_at45) ** p_at47)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5p
                            -> let
                                 c_RESTc_at5s = ((toVector x_at5p) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at5q = ((toVector x_at5p) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4b
                                  * ((p_at4l + ((c_MiRs_at5q / p_at4d) ** p_at4f))
                                     / (((1 + p_at4l) + ((c_MiRs_at5q / p_at4d) ** p_at4f))
                                        + ((c_RESTc_at5s / p_at4h) ** p_at4j)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5t
                            -> let c_PTB_at5u = ((toVector x_at5t) Data.Vector.Unboxed.! 0)
                               in (p_at4n * c_PTB_at5u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5v
                            -> let c_NPTB_at5w = ((toVector x_at5v) Data.Vector.Unboxed.! 1)
                               in (p_at4p * c_NPTB_at5w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5x
                            -> let c_MiRs_at5y = ((toVector x_at5x) Data.Vector.Unboxed.! 2)
                               in (p_at4r * c_MiRs_at5y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5z
                            -> let c_RESTc_at5A = ((toVector x_at5z) Data.Vector.Unboxed.! 3)
                               in (p_at4t * c_RESTc_at5A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5B
                            -> let
                                 c_EndoNeuroTFs_at5C = ((toVector x_at5B) Data.Vector.Unboxed.! 4)
                               in (p_at4v * c_EndoNeuroTFs_at5C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121466",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121467",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121468",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121469",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121470",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121471",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121472",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121473",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121474",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121475",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121476",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121477",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121478",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121479",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121480",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121481",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121482",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121483",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121484",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121485",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121486",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121487",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121488",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121489",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121490",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121491",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121492",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121493",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121494",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121495",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4w
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6h
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                            (g_at4s, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                            (g_at4q, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                            (g_at4o, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                            (g_at4m, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at4l = code-0.1.0.0:Genome.FixedList.Functions.double g_at4k
                            (g_at4k, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at4j = Functions.belowten' g_at4i
                            (g_at4i, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at4h = code-0.1.0.0:Genome.FixedList.Functions.double g_at4g
                            (g_at4g, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at4f = Functions.belowten' g_at4e
                            (g_at4e, gpart_at69) = Genome.Split.split gpart_at68
                            p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                            (g_at4c, gpart_at68) = Genome.Split.split gpart_at67
                            p_at4b = code-0.1.0.0:Genome.FixedList.Functions.double g_at4a
                            (g_at4a, gpart_at67) = Genome.Split.split gpart_at66
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at66) = Genome.Split.split gpart_at65
                            p_at47 = Functions.belowten' g_at46
                            (g_at46, gpart_at65) = Genome.Split.split gpart_at64
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at64) = Genome.Split.split gpart_at63
                            p_at43
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at42
                            (g_at42, gpart_at63) = Genome.Split.split gpart_at62
                            p_at41
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at40
                            (g_at40, gpart_at62) = Genome.Split.split gpart_at61
                            p_at3Z = Functions.belowten' g_at3Y
                            (g_at3Y, gpart_at61) = Genome.Split.split gpart_at60
                            p_at3X = code-0.1.0.0:Genome.FixedList.Functions.double g_at3W
                            (g_at3W, gpart_at60) = Genome.Split.split gpart_at5Z
                            p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                            (g_at3U, gpart_at5Z) = Genome.Split.split gpart_at5Y
                            p_at3T = code-0.1.0.0:Genome.FixedList.Functions.double g_at3S
                            (g_at3S, gpart_at5Y) = Genome.Split.split gpart_at5X
                            p_at3R = Functions.belowten' g_at3Q
                            (g_at3Q, gpart_at5X) = Genome.Split.split gpart_at5W
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at5W) = Genome.Split.split gpart_at5V
                            p_at3N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3M
                            (g_at3M, gpart_at5V) = Genome.Split.split gpart_at5U
                            p_at3L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3K
                            (g_at3K, gpart_at5U) = Genome.Split.split gpart_at5T
                            p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                            (g_at3I, gpart_at5T) = Genome.Split.split gpart_at5S
                            p_at3H = Functions.belowten' g_at3G
                            (g_at3G, gpart_at5S) = Genome.Split.split gpart_at5R
                            p_at3F = code-0.1.0.0:Genome.FixedList.Functions.double g_at3E
                            (g_at3E, gpart_at5R) = Genome.Split.split gpart_at5Q
                            p_at3D = Functions.belowten' g_at3C
                            (g_at3C, gpart_at5Q) = Genome.Split.split gpart_at5P
                            p_at3B = code-0.1.0.0:Genome.FixedList.Functions.double g_at3A
                            (g_at3A, gpart_at5P) = Genome.Split.split gpart_at5O
                            p_at3z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3y
                            (g_at3y, gpart_at5O) = Genome.Split.split gpart_at5N
                            p_at3x = Functions.belowten' g_at3w
                            (g_at3w, gpart_at5N) = Genome.Split.split gpart_at5M
                            p_at3v = code-0.1.0.0:Genome.FixedList.Functions.double g_at3u
                            (g_at3u, gpart_at5M) = Genome.Split.split gpart_at5L
                            p_at3t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3s
                            (g_at3s, gpart_at5L) = Genome.Split.split gpart_at5K
                            p_at3r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3q
                            (g_at3q, gpart_at5K) = Genome.Split.split gpart_at5J
                            p_at3p = Functions.belowten' g_at3o
                            (g_at3o, gpart_at5J) = Genome.Split.split gpart_at5I
                            p_at3n = code-0.1.0.0:Genome.FixedList.Functions.double g_at3m
                            (g_at3m, gpart_at5I) = Genome.Split.split gpart_at5H
                            p_at3l = code-0.1.0.0:Genome.FixedList.Functions.double g_at3k
                            (g_at3k, gpart_at5H) = Genome.Split.split gpart_at5G
                            p_at3j = code-0.1.0.0:Genome.FixedList.Functions.double g_at3i
                            (g_at3i, gpart_at5G) = Genome.Split.split gpart_at5F
                            p_at3h = code-0.1.0.0:Genome.FixedList.Functions.double g_at3g
                            (g_at3g, gpart_at5F) = Genome.Split.split gpart_at5E
                            p_at3f = code-0.1.0.0:Genome.FixedList.Functions.double g_at3e
                            (g_at3e, gpart_at5E) = Genome.Split.split gpart_at5D
                            p_at3d = code-0.1.0.0:Genome.FixedList.Functions.double g_at3c
                            (g_at3c, gpart_at5D) = Genome.Split.split genome_at4w
                          in
                            \ desc_at4x
                              -> case desc_at4x of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3d)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3f)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3h)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3j)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3l)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3n)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3p)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3r)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3t)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3v)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3x)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3z)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3B)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3D)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3F)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3R)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3T)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3V)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3X)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Z)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at8i
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8Y
                      p_at8h = code-0.1.0.0:Genome.FixedList.Functions.double g_at8g
                      (g_at8g, gpart_at8Y) = Genome.Split.split gpart_at8X
                      p_at8f = code-0.1.0.0:Genome.FixedList.Functions.double g_at8e
                      (g_at8e, gpart_at8X) = Genome.Split.split gpart_at8W
                      p_at8d = code-0.1.0.0:Genome.FixedList.Functions.double g_at8c
                      (g_at8c, gpart_at8W) = Genome.Split.split gpart_at8V
                      p_at8b = code-0.1.0.0:Genome.FixedList.Functions.double g_at8a
                      (g_at8a, gpart_at8V) = Genome.Split.split gpart_at8U
                      p_at89 = code-0.1.0.0:Genome.FixedList.Functions.double g_at88
                      (g_at88, gpart_at8U) = Genome.Split.split gpart_at8T
                      p_at87 = code-0.1.0.0:Genome.FixedList.Functions.double g_at86
                      (g_at86, gpart_at8T) = Genome.Split.split gpart_at8S
                      p_at85 = Functions.belowten' g_at84
                      (g_at84, gpart_at8S) = Genome.Split.split gpart_at8R
                      p_at83 = code-0.1.0.0:Genome.FixedList.Functions.double g_at82
                      (g_at82, gpart_at8R) = Genome.Split.split gpart_at8Q
                      p_at81 = Functions.belowten' g_at80
                      (g_at80, gpart_at8Q) = Genome.Split.split gpart_at8P
                      p_at7Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7Y
                      (g_at7Y, gpart_at8P) = Genome.Split.split gpart_at8O
                      p_at7X = code-0.1.0.0:Genome.FixedList.Functions.double g_at7W
                      (g_at7W, gpart_at8O) = Genome.Split.split gpart_at8N
                      p_at7V = code-0.1.0.0:Genome.FixedList.Functions.double g_at7U
                      (g_at7U, gpart_at8N) = Genome.Split.split gpart_at8M
                      p_at7T = Functions.belowten' g_at7S
                      (g_at7S, gpart_at8M) = Genome.Split.split gpart_at8L
                      p_at7R = code-0.1.0.0:Genome.FixedList.Functions.double g_at7Q
                      (g_at7Q, gpart_at8L) = Genome.Split.split gpart_at8K
                      p_at7P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7O
                      (g_at7O, gpart_at8K) = Genome.Split.split gpart_at8J
                      p_at7N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7M
                      (g_at7M, gpart_at8J) = Genome.Split.split gpart_at8I
                      p_at7L = Functions.belowten' g_at7K
                      (g_at7K, gpart_at8I) = Genome.Split.split gpart_at8H
                      p_at7J = code-0.1.0.0:Genome.FixedList.Functions.double g_at7I
                      (g_at7I, gpart_at8H) = Genome.Split.split gpart_at8G
                      p_at7H = code-0.1.0.0:Genome.FixedList.Functions.double g_at7G
                      (g_at7G, gpart_at8G) = Genome.Split.split gpart_at8F
                      p_at7F = code-0.1.0.0:Genome.FixedList.Functions.double g_at7E
                      (g_at7E, gpart_at8F) = Genome.Split.split gpart_at8E
                      p_at7D = Functions.belowten' g_at7C
                      (g_at7C, gpart_at8E) = Genome.Split.split gpart_at8D
                      p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                      (g_at7A, gpart_at8D) = Genome.Split.split gpart_at8C
                      p_at7z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7y
                      (g_at7y, gpart_at8C) = Genome.Split.split gpart_at8B
                      p_at7x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7w
                      (g_at7w, gpart_at8B) = Genome.Split.split gpart_at8A
                      p_at7v = code-0.1.0.0:Genome.FixedList.Functions.double g_at7u
                      (g_at7u, gpart_at8A) = Genome.Split.split gpart_at8z
                      p_at7t = Functions.belowten' g_at7s
                      (g_at7s, gpart_at8z) = Genome.Split.split gpart_at8y
                      p_at7r = code-0.1.0.0:Genome.FixedList.Functions.double g_at7q
                      (g_at7q, gpart_at8y) = Genome.Split.split gpart_at8x
                      p_at7p = Functions.belowten' g_at7o
                      (g_at7o, gpart_at8x) = Genome.Split.split gpart_at8w
                      p_at7n = code-0.1.0.0:Genome.FixedList.Functions.double g_at7m
                      (g_at7m, gpart_at8w) = Genome.Split.split gpart_at8v
                      p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                      (g_at7k, gpart_at8v) = Genome.Split.split gpart_at8u
                      p_at7j = Functions.belowten' g_at7i
                      (g_at7i, gpart_at8u) = Genome.Split.split gpart_at8t
                      p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                      (g_at7g, gpart_at8t) = Genome.Split.split gpart_at8s
                      p_at7f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7e
                      (g_at7e, gpart_at8s) = Genome.Split.split gpart_at8r
                      p_at7d
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7c
                      (g_at7c, gpart_at8r) = Genome.Split.split gpart_at8q
                      p_at7b = Functions.belowten' g_at7a
                      (g_at7a, gpart_at8q) = Genome.Split.split gpart_at8p
                      p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                      (g_at78, gpart_at8p) = Genome.Split.split gpart_at8o
                      p_at77 = code-0.1.0.0:Genome.FixedList.Functions.double g_at76
                      (g_at76, gpart_at8o) = Genome.Split.split gpart_at8n
                      p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                      (g_at74, gpart_at8n) = Genome.Split.split gpart_at8m
                      p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                      (g_at72, gpart_at8m) = Genome.Split.split gpart_at8l
                      p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                      (g_at70, gpart_at8l) = Genome.Split.split gpart_at8k
                      p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                      (g_at6Y, gpart_at8k) = Genome.Split.split genome_at8i
                    in
                      [Reaction
                         (\ x_at8Z
                            -> let
                                 c_NPTB_at90 = ((toVector x_at8Z) Data.Vector.Unboxed.! 1)
                                 c_MiRs_at91 = ((toVector x_at8Z) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at77
                                  / (1
                                     + ((((c_NPTB_at90 / p_at79) ** p_at7b)
                                         + ((p_at6Z / p_at7d) ** p_at7f))
                                        + ((c_MiRs_at91 / p_at7h) ** p_at7j)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at92
                            -> let
                                 c_MiRs_at93 = ((toVector x_at92) Data.Vector.Unboxed.! 2)
                                 c_PTB_at94 = ((toVector x_at92) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7l
                                  / (1
                                     + (((c_MiRs_at93 / p_at7n) ** p_at7p)
                                        + ((c_PTB_at94 / p_at7r) ** p_at7t)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at95
                            -> let c_RESTc_at96 = ((toVector x_at95) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at7v
                                  * (p_at7F
                                     / ((1 + p_at7F) + ((c_RESTc_at96 / p_at7B) ** p_at7D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at97
                            -> let
                                 c_MiRs_at9a = ((toVector x_at97) Data.Vector.Unboxed.! 2)
                                 c_PTB_at98 = ((toVector x_at97) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at7H
                                  * ((p_at7V + ((c_PTB_at98 / p_at7J) ** p_at7L))
                                     / (((1 + p_at7V) + ((c_PTB_at98 / p_at7J) ** p_at7L))
                                        + ((c_MiRs_at9a / p_at7R) ** p_at7T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at9b
                            -> let
                                 c_RESTc_at9e = ((toVector x_at9b) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at9c = ((toVector x_at9b) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at7X
                                  * ((p_at87 + ((c_MiRs_at9c / p_at7Z) ** p_at81))
                                     / (((1 + p_at87) + ((c_MiRs_at9c / p_at7Z) ** p_at81))
                                        + ((c_RESTc_at9e / p_at83) ** p_at85)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at9f
                            -> let c_PTB_at9g = ((toVector x_at9f) Data.Vector.Unboxed.! 0)
                               in (p_at89 * c_PTB_at9g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at9h
                            -> let c_NPTB_at9i = ((toVector x_at9h) Data.Vector.Unboxed.! 1)
                               in (p_at8b * c_NPTB_at9i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at9j
                            -> let c_MiRs_at9k = ((toVector x_at9j) Data.Vector.Unboxed.! 2)
                               in (p_at8d * c_MiRs_at9k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at9l
                            -> let c_RESTc_at9m = ((toVector x_at9l) Data.Vector.Unboxed.! 3)
                               in (p_at8f * c_RESTc_at9m))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at9n
                            -> let
                                 c_EndoNeuroTFs_at9o = ((toVector x_at9n) Data.Vector.Unboxed.! 4)
                               in (p_at8h * c_EndoNeuroTFs_at9o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121715",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121717",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121735",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121737",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121751",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121753",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at8i
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_ata3
                            p_at8h = code-0.1.0.0:Genome.FixedList.Functions.double g_at8g
                            (g_at8g, gpart_ata3) = Genome.Split.split gpart_ata2
                            p_at8f = code-0.1.0.0:Genome.FixedList.Functions.double g_at8e
                            (g_at8e, gpart_ata2) = Genome.Split.split gpart_ata1
                            p_at8d = code-0.1.0.0:Genome.FixedList.Functions.double g_at8c
                            (g_at8c, gpart_ata1) = Genome.Split.split gpart_ata0
                            p_at8b = code-0.1.0.0:Genome.FixedList.Functions.double g_at8a
                            (g_at8a, gpart_ata0) = Genome.Split.split gpart_at9Z
                            p_at89 = code-0.1.0.0:Genome.FixedList.Functions.double g_at88
                            (g_at88, gpart_at9Z) = Genome.Split.split gpart_at9Y
                            p_at87 = code-0.1.0.0:Genome.FixedList.Functions.double g_at86
                            (g_at86, gpart_at9Y) = Genome.Split.split gpart_at9X
                            p_at85 = Functions.belowten' g_at84
                            (g_at84, gpart_at9X) = Genome.Split.split gpart_at9W
                            p_at83 = code-0.1.0.0:Genome.FixedList.Functions.double g_at82
                            (g_at82, gpart_at9W) = Genome.Split.split gpart_at9V
                            p_at81 = Functions.belowten' g_at80
                            (g_at80, gpart_at9V) = Genome.Split.split gpart_at9U
                            p_at7Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at7Y
                            (g_at7Y, gpart_at9U) = Genome.Split.split gpart_at9T
                            p_at7X = code-0.1.0.0:Genome.FixedList.Functions.double g_at7W
                            (g_at7W, gpart_at9T) = Genome.Split.split gpart_at9S
                            p_at7V = code-0.1.0.0:Genome.FixedList.Functions.double g_at7U
                            (g_at7U, gpart_at9S) = Genome.Split.split gpart_at9R
                            p_at7T = Functions.belowten' g_at7S
                            (g_at7S, gpart_at9R) = Genome.Split.split gpart_at9Q
                            p_at7R = code-0.1.0.0:Genome.FixedList.Functions.double g_at7Q
                            (g_at7Q, gpart_at9Q) = Genome.Split.split gpart_at9P
                            p_at7P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7O
                            (g_at7O, gpart_at9P) = Genome.Split.split gpart_at9O
                            p_at7N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7M
                            (g_at7M, gpart_at9O) = Genome.Split.split gpart_at9N
                            p_at7L = Functions.belowten' g_at7K
                            (g_at7K, gpart_at9N) = Genome.Split.split gpart_at9M
                            p_at7J = code-0.1.0.0:Genome.FixedList.Functions.double g_at7I
                            (g_at7I, gpart_at9M) = Genome.Split.split gpart_at9L
                            p_at7H = code-0.1.0.0:Genome.FixedList.Functions.double g_at7G
                            (g_at7G, gpart_at9L) = Genome.Split.split gpart_at9K
                            p_at7F = code-0.1.0.0:Genome.FixedList.Functions.double g_at7E
                            (g_at7E, gpart_at9K) = Genome.Split.split gpart_at9J
                            p_at7D = Functions.belowten' g_at7C
                            (g_at7C, gpart_at9J) = Genome.Split.split gpart_at9I
                            p_at7B = code-0.1.0.0:Genome.FixedList.Functions.double g_at7A
                            (g_at7A, gpart_at9I) = Genome.Split.split gpart_at9H
                            p_at7z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7y
                            (g_at7y, gpart_at9H) = Genome.Split.split gpart_at9G
                            p_at7x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7w
                            (g_at7w, gpart_at9G) = Genome.Split.split gpart_at9F
                            p_at7v = code-0.1.0.0:Genome.FixedList.Functions.double g_at7u
                            (g_at7u, gpart_at9F) = Genome.Split.split gpart_at9E
                            p_at7t = Functions.belowten' g_at7s
                            (g_at7s, gpart_at9E) = Genome.Split.split gpart_at9D
                            p_at7r = code-0.1.0.0:Genome.FixedList.Functions.double g_at7q
                            (g_at7q, gpart_at9D) = Genome.Split.split gpart_at9C
                            p_at7p = Functions.belowten' g_at7o
                            (g_at7o, gpart_at9C) = Genome.Split.split gpart_at9B
                            p_at7n = code-0.1.0.0:Genome.FixedList.Functions.double g_at7m
                            (g_at7m, gpart_at9B) = Genome.Split.split gpart_at9A
                            p_at7l = code-0.1.0.0:Genome.FixedList.Functions.double g_at7k
                            (g_at7k, gpart_at9A) = Genome.Split.split gpart_at9z
                            p_at7j = Functions.belowten' g_at7i
                            (g_at7i, gpart_at9z) = Genome.Split.split gpart_at9y
                            p_at7h = code-0.1.0.0:Genome.FixedList.Functions.double g_at7g
                            (g_at7g, gpart_at9y) = Genome.Split.split gpart_at9x
                            p_at7f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7e
                            (g_at7e, gpart_at9x) = Genome.Split.split gpart_at9w
                            p_at7d
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at7c
                            (g_at7c, gpart_at9w) = Genome.Split.split gpart_at9v
                            p_at7b = Functions.belowten' g_at7a
                            (g_at7a, gpart_at9v) = Genome.Split.split gpart_at9u
                            p_at79 = code-0.1.0.0:Genome.FixedList.Functions.double g_at78
                            (g_at78, gpart_at9u) = Genome.Split.split gpart_at9t
                            p_at77 = code-0.1.0.0:Genome.FixedList.Functions.double g_at76
                            (g_at76, gpart_at9t) = Genome.Split.split gpart_at9s
                            p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                            (g_at74, gpart_at9s) = Genome.Split.split gpart_at9r
                            p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                            (g_at72, gpart_at9r) = Genome.Split.split gpart_at9q
                            p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                            (g_at70, gpart_at9q) = Genome.Split.split gpart_at9p
                            p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                            (g_at6Y, gpart_at9p) = Genome.Split.split genome_at8i
                          in
                            \ desc_at8j
                              -> case desc_at8j of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at71)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at73)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at75)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at77)
                                   "Inhibition coef [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at79)
                                   "Inhibition hill [NPTB] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7b)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7d)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7f)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7h)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7j)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7l)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7n)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7p)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7r)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7t)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7v)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7x)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7z)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7B)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7D)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7F)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7H)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7J)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7L)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7N)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7P)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7R)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7T)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7V)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7X)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at7Z)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at81)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at83)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at85)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at87)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at89)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8b)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8d)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8f)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at8h)
                                   _ -> Nothing }}
