src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a28rz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28sh
                      p_a28ry = double g_a28rx
                      (g_a28rx, gpart_a28sh) = Genome.Split.split gpart_a28sg
                      p_a28rw = double g_a28rv
                      (g_a28rv, gpart_a28sg) = Genome.Split.split gpart_a28sf
                      p_a28ru = double g_a28rt
                      (g_a28rt, gpart_a28sf) = Genome.Split.split gpart_a28se
                      p_a28rs = double g_a28rr
                      (g_a28rr, gpart_a28se) = Genome.Split.split gpart_a28sd
                      p_a28rq = double g_a28rp
                      (g_a28rp, gpart_a28sd) = Genome.Split.split gpart_a28sc
                      p_a28ro = double g_a28rn
                      (g_a28rn, gpart_a28sc) = Genome.Split.split gpart_a28sb
                      p_a28rm = Functions.belowten' g_a28rl
                      (g_a28rl, gpart_a28sb) = Genome.Split.split gpart_a28sa
                      p_a28rk = double g_a28rj
                      (g_a28rj, gpart_a28sa) = Genome.Split.split gpart_a28s9
                      p_a28ri = Functions.belowten' g_a28rh
                      (g_a28rh, gpart_a28s9) = Genome.Split.split gpart_a28s8
                      p_a28rg = double g_a28rf
                      (g_a28rf, gpart_a28s8) = Genome.Split.split gpart_a28s7
                      p_a28re = double g_a28rd
                      (g_a28rd, gpart_a28s7) = Genome.Split.split gpart_a28s6
                      p_a28rc = double g_a28rb
                      (g_a28rb, gpart_a28s6) = Genome.Split.split gpart_a28s5
                      p_a28ra = Functions.belowten' g_a28r9
                      (g_a28r9, gpart_a28s5) = Genome.Split.split gpart_a28s4
                      p_a28r8 = double g_a28r7
                      (g_a28r7, gpart_a28s4) = Genome.Split.split gpart_a28s3
                      p_a28r6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28r5
                      (g_a28r5, gpart_a28s3) = Genome.Split.split gpart_a28s2
                      p_a28r4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28r3
                      (g_a28r3, gpart_a28s2) = Genome.Split.split gpart_a28s1
                      p_a28r2 = Functions.belowten' g_a28r1
                      (g_a28r1, gpart_a28s1) = Genome.Split.split gpart_a28s0
                      p_a28r0 = double g_a28qZ
                      (g_a28qZ, gpart_a28s0) = Genome.Split.split gpart_a28rZ
                      p_a28qY = double g_a28qX
                      (g_a28qX, gpart_a28rZ) = Genome.Split.split gpart_a28rY
                      p_a28qW = double g_a28qV
                      (g_a28qV, gpart_a28rY) = Genome.Split.split gpart_a28rX
                      p_a28qU = Functions.belowten' g_a28qT
                      (g_a28qT, gpart_a28rX) = Genome.Split.split gpart_a28rW
                      p_a28qS = double g_a28qR
                      (g_a28qR, gpart_a28rW) = Genome.Split.split gpart_a28rV
                      p_a28qQ = Functions.belowten' g_a28qP
                      (g_a28qP, gpart_a28rV) = Genome.Split.split gpart_a28rU
                      p_a28qO = double g_a28qN
                      (g_a28qN, gpart_a28rU) = Genome.Split.split gpart_a28rT
                      p_a28qM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qL
                      (g_a28qL, gpart_a28rT) = Genome.Split.split gpart_a28rS
                      p_a28qK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qJ
                      (g_a28qJ, gpart_a28rS) = Genome.Split.split gpart_a28rR
                      p_a28qI = double g_a28qH
                      (g_a28qH, gpart_a28rR) = Genome.Split.split gpart_a28rQ
                      p_a28qG = Functions.belowten' g_a28qF
                      (g_a28qF, gpart_a28rQ) = Genome.Split.split gpart_a28rP
                      p_a28qE = double g_a28qD
                      (g_a28qD, gpart_a28rP) = Genome.Split.split gpart_a28rO
                      p_a28qC = Functions.belowten' g_a28qB
                      (g_a28qB, gpart_a28rO) = Genome.Split.split gpart_a28rN
                      p_a28qA = double g_a28qz
                      (g_a28qz, gpart_a28rN) = Genome.Split.split gpart_a28rM
                      p_a28qy = Functions.belowten' g_a28qx
                      (g_a28qx, gpart_a28rM) = Genome.Split.split gpart_a28rL
                      p_a28qw = double g_a28qv
                      (g_a28qv, gpart_a28rL) = Genome.Split.split gpart_a28rK
                      p_a28qu = double g_a28qt
                      (g_a28qt, gpart_a28rK) = Genome.Split.split gpart_a28rJ
                      p_a28qs = Functions.belowten' g_a28qr
                      (g_a28qr, gpart_a28rJ) = Genome.Split.split gpart_a28rI
                      p_a28qq = double g_a28qp
                      (g_a28qp, gpart_a28rI) = Genome.Split.split gpart_a28rH
                      p_a28qo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qn
                      (g_a28qn, gpart_a28rH) = Genome.Split.split gpart_a28rG
                      p_a28qm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28ql
                      (g_a28ql, gpart_a28rG) = Genome.Split.split gpart_a28rF
                      p_a28qk = double g_a28qj
                      (g_a28qj, gpart_a28rF) = Genome.Split.split gpart_a28rE
                      p_a28qi = double g_a28qh
                      (g_a28qh, gpart_a28rE) = Genome.Split.split gpart_a28rD
                      p_a28qg = double g_a28qf
                      (g_a28qf, gpart_a28rD) = Genome.Split.split gpart_a28rC
                      p_a28qe = double g_a28qd
                      (g_a28qd, gpart_a28rC) = Genome.Split.split gpart_a28rB
                      p_a28qc = double g_a28qb
                      (g_a28qb, gpart_a28rB) = Genome.Split.split genome_a28rz
                    in  \ x_a28si
                          -> let
                               c_PTB_a28sl
                                 = ((Data.Fixed.Vector.toVector x_a28si) Data.Vector.Unboxed.! 0)
                               c_MiRs_a28sj
                                 = ((Data.Fixed.Vector.toVector x_a28si) Data.Vector.Unboxed.! 2)
                               c_NPTB_a28sq
                                 = ((Data.Fixed.Vector.toVector x_a28si) Data.Vector.Unboxed.! 1)
                               c_RESTc_a28sm
                                 = ((Data.Fixed.Vector.toVector x_a28si) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a28sE
                                 = ((Data.Fixed.Vector.toVector x_a28si) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a28qk / (1 + ((c_MiRs_a28sj / p_a28qq) ** p_a28qs)))
                                    + (negate (p_a28rq * c_PTB_a28sl))),
                                   ((p_a28qu
                                     / (1
                                        + ((((c_RESTc_a28sm / p_a28qw) ** p_a28qy)
                                            + ((c_MiRs_a28sj / p_a28qA) ** p_a28qC))
                                           + ((c_PTB_a28sl / p_a28qE) ** p_a28qG))))
                                    + (negate (p_a28rs * c_NPTB_a28sq))),
                                   ((p_a28qI
                                     * ((p_a28qW + ((p_a28qg / p_a28qK) ** p_a28qM))
                                        / (((1 + p_a28qW) + ((p_a28qg / p_a28qK) ** p_a28qM))
                                           + (((c_NPTB_a28sq / p_a28qO) ** p_a28qQ)
                                              + ((c_RESTc_a28sm / p_a28qS) ** p_a28qU)))))
                                    + (negate (p_a28ru * c_MiRs_a28sj))),
                                   ((p_a28qY
                                     * ((p_a28rc + ((c_PTB_a28sl / p_a28r0) ** p_a28r2))
                                        / (((1 + p_a28rc) + ((c_PTB_a28sl / p_a28r0) ** p_a28r2))
                                           + (((p_a28qc / p_a28r4) ** p_a28r6)
                                              + ((c_MiRs_a28sj / p_a28r8) ** p_a28ra)))))
                                    + (negate (p_a28rw * c_RESTc_a28sm))),
                                   ((p_a28re
                                     * ((p_a28ro + ((c_MiRs_a28sj / p_a28rg) ** p_a28ri))
                                        / (((1 + p_a28ro) + ((c_MiRs_a28sj / p_a28rg) ** p_a28ri))
                                           + ((c_RESTc_a28sm / p_a28rk) ** p_a28rm))))
                                    + (negate (p_a28ry * c_EndoNeuroTFs_a28sE)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518823",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518824",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518825",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518826",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518827",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518828",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518829",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518830",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518834",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518836",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518842",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518844",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518858",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518860",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518866",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518868",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518878",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518880",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679518907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679518908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a28rz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28tl
                            p_a28ry = double g_a28rx
                            (g_a28rx, gpart_a28tl) = Genome.Split.split gpart_a28tk
                            p_a28rw = double g_a28rv
                            (g_a28rv, gpart_a28tk) = Genome.Split.split gpart_a28tj
                            p_a28ru = double g_a28rt
                            (g_a28rt, gpart_a28tj) = Genome.Split.split gpart_a28ti
                            p_a28rs = double g_a28rr
                            (g_a28rr, gpart_a28ti) = Genome.Split.split gpart_a28th
                            p_a28rq = double g_a28rp
                            (g_a28rp, gpart_a28th) = Genome.Split.split gpart_a28tg
                            p_a28ro = double g_a28rn
                            (g_a28rn, gpart_a28tg) = Genome.Split.split gpart_a28tf
                            p_a28rm = Functions.belowten' g_a28rl
                            (g_a28rl, gpart_a28tf) = Genome.Split.split gpart_a28te
                            p_a28rk = double g_a28rj
                            (g_a28rj, gpart_a28te) = Genome.Split.split gpart_a28td
                            p_a28ri = Functions.belowten' g_a28rh
                            (g_a28rh, gpart_a28td) = Genome.Split.split gpart_a28tc
                            p_a28rg = double g_a28rf
                            (g_a28rf, gpart_a28tc) = Genome.Split.split gpart_a28tb
                            p_a28re = double g_a28rd
                            (g_a28rd, gpart_a28tb) = Genome.Split.split gpart_a28ta
                            p_a28rc = double g_a28rb
                            (g_a28rb, gpart_a28ta) = Genome.Split.split gpart_a28t9
                            p_a28ra = Functions.belowten' g_a28r9
                            (g_a28r9, gpart_a28t9) = Genome.Split.split gpart_a28t8
                            p_a28r8 = double g_a28r7
                            (g_a28r7, gpart_a28t8) = Genome.Split.split gpart_a28t7
                            p_a28r6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28r5
                            (g_a28r5, gpart_a28t7) = Genome.Split.split gpart_a28t6
                            p_a28r4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28r3
                            (g_a28r3, gpart_a28t6) = Genome.Split.split gpart_a28t5
                            p_a28r2 = Functions.belowten' g_a28r1
                            (g_a28r1, gpart_a28t5) = Genome.Split.split gpart_a28t4
                            p_a28r0 = double g_a28qZ
                            (g_a28qZ, gpart_a28t4) = Genome.Split.split gpart_a28t3
                            p_a28qY = double g_a28qX
                            (g_a28qX, gpart_a28t3) = Genome.Split.split gpart_a28t2
                            p_a28qW = double g_a28qV
                            (g_a28qV, gpart_a28t2) = Genome.Split.split gpart_a28t1
                            p_a28qU = Functions.belowten' g_a28qT
                            (g_a28qT, gpart_a28t1) = Genome.Split.split gpart_a28t0
                            p_a28qS = double g_a28qR
                            (g_a28qR, gpart_a28t0) = Genome.Split.split gpart_a28sZ
                            p_a28qQ = Functions.belowten' g_a28qP
                            (g_a28qP, gpart_a28sZ) = Genome.Split.split gpart_a28sY
                            p_a28qO = double g_a28qN
                            (g_a28qN, gpart_a28sY) = Genome.Split.split gpart_a28sX
                            p_a28qM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qL
                            (g_a28qL, gpart_a28sX) = Genome.Split.split gpart_a28sW
                            p_a28qK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qJ
                            (g_a28qJ, gpart_a28sW) = Genome.Split.split gpart_a28sV
                            p_a28qI = double g_a28qH
                            (g_a28qH, gpart_a28sV) = Genome.Split.split gpart_a28sU
                            p_a28qG = Functions.belowten' g_a28qF
                            (g_a28qF, gpart_a28sU) = Genome.Split.split gpart_a28sT
                            p_a28qE = double g_a28qD
                            (g_a28qD, gpart_a28sT) = Genome.Split.split gpart_a28sS
                            p_a28qC = Functions.belowten' g_a28qB
                            (g_a28qB, gpart_a28sS) = Genome.Split.split gpart_a28sR
                            p_a28qA = double g_a28qz
                            (g_a28qz, gpart_a28sR) = Genome.Split.split gpart_a28sQ
                            p_a28qy = Functions.belowten' g_a28qx
                            (g_a28qx, gpart_a28sQ) = Genome.Split.split gpart_a28sP
                            p_a28qw = double g_a28qv
                            (g_a28qv, gpart_a28sP) = Genome.Split.split gpart_a28sO
                            p_a28qu = double g_a28qt
                            (g_a28qt, gpart_a28sO) = Genome.Split.split gpart_a28sN
                            p_a28qs = Functions.belowten' g_a28qr
                            (g_a28qr, gpart_a28sN) = Genome.Split.split gpart_a28sM
                            p_a28qq = double g_a28qp
                            (g_a28qp, gpart_a28sM) = Genome.Split.split gpart_a28sL
                            p_a28qo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28qn
                            (g_a28qn, gpart_a28sL) = Genome.Split.split gpart_a28sK
                            p_a28qm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28ql
                            (g_a28ql, gpart_a28sK) = Genome.Split.split gpart_a28sJ
                            p_a28qk = double g_a28qj
                            (g_a28qj, gpart_a28sJ) = Genome.Split.split gpart_a28sI
                            p_a28qi = double g_a28qh
                            (g_a28qh, gpart_a28sI) = Genome.Split.split gpart_a28sH
                            p_a28qg = double g_a28qf
                            (g_a28qf, gpart_a28sH) = Genome.Split.split gpart_a28sG
                            p_a28qe = double g_a28qd
                            (g_a28qd, gpart_a28sG) = Genome.Split.split gpart_a28sF
                            p_a28qc = double g_a28qb
                            (g_a28qb, gpart_a28sF) = Genome.Split.split genome_a28rz
                          in
                            \ desc_a28rA
                              -> case desc_a28rA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qc)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qe)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qg)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qi)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qk)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qm)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qo)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qq)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qs)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qu)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qw)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qy)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qA)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qC)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qE)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qG)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qI)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qK)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qM)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qO)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qQ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qS)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qU)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qW)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28qY)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28r0)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28r2)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28r4)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28r6)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28r8)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ra)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rc)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28re)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rg)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ri)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rk)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rm)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ro)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rs)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ru)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28rw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ry)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a28vT
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28wB
                      p_a28vS = double g_a28vR
                      (g_a28vR, gpart_a28wB) = Genome.Split.split gpart_a28wA
                      p_a28vQ = double g_a28vP
                      (g_a28vP, gpart_a28wA) = Genome.Split.split gpart_a28wz
                      p_a28vO = double g_a28vN
                      (g_a28vN, gpart_a28wz) = Genome.Split.split gpart_a28wy
                      p_a28vM = double g_a28vL
                      (g_a28vL, gpart_a28wy) = Genome.Split.split gpart_a28wx
                      p_a28vK = double g_a28vJ
                      (g_a28vJ, gpart_a28wx) = Genome.Split.split gpart_a28ww
                      p_a28vI = double g_a28vH
                      (g_a28vH, gpart_a28ww) = Genome.Split.split gpart_a28wv
                      p_a28vG = Functions.belowten' g_a28vF
                      (g_a28vF, gpart_a28wv) = Genome.Split.split gpart_a28wu
                      p_a28vE = double g_a28vD
                      (g_a28vD, gpart_a28wu) = Genome.Split.split gpart_a28wt
                      p_a28vC = Functions.belowten' g_a28vB
                      (g_a28vB, gpart_a28wt) = Genome.Split.split gpart_a28ws
                      p_a28vA = double g_a28vz
                      (g_a28vz, gpart_a28ws) = Genome.Split.split gpart_a28wr
                      p_a28vy = double g_a28vx
                      (g_a28vx, gpart_a28wr) = Genome.Split.split gpart_a28wq
                      p_a28vw = double g_a28vv
                      (g_a28vv, gpart_a28wq) = Genome.Split.split gpart_a28wp
                      p_a28vu = Functions.belowten' g_a28vt
                      (g_a28vt, gpart_a28wp) = Genome.Split.split gpart_a28wo
                      p_a28vs = double g_a28vr
                      (g_a28vr, gpart_a28wo) = Genome.Split.split gpart_a28wn
                      p_a28vq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28vp
                      (g_a28vp, gpart_a28wn) = Genome.Split.split gpart_a28wm
                      p_a28vo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28vn
                      (g_a28vn, gpart_a28wm) = Genome.Split.split gpart_a28wl
                      p_a28vm = Functions.belowten' g_a28vl
                      (g_a28vl, gpart_a28wl) = Genome.Split.split gpart_a28wk
                      p_a28vk = double g_a28vj
                      (g_a28vj, gpart_a28wk) = Genome.Split.split gpart_a28wj
                      p_a28vi = double g_a28vh
                      (g_a28vh, gpart_a28wj) = Genome.Split.split gpart_a28wi
                      p_a28vg = double g_a28vf
                      (g_a28vf, gpart_a28wi) = Genome.Split.split gpart_a28wh
                      p_a28ve = Functions.belowten' g_a28vd
                      (g_a28vd, gpart_a28wh) = Genome.Split.split gpart_a28wg
                      p_a28vc = double g_a28vb
                      (g_a28vb, gpart_a28wg) = Genome.Split.split gpart_a28wf
                      p_a28va = Functions.belowten' g_a28v9
                      (g_a28v9, gpart_a28wf) = Genome.Split.split gpart_a28we
                      p_a28v8 = double g_a28v7
                      (g_a28v7, gpart_a28we) = Genome.Split.split gpart_a28wd
                      p_a28v6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28v5
                      (g_a28v5, gpart_a28wd) = Genome.Split.split gpart_a28wc
                      p_a28v4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28v3
                      (g_a28v3, gpart_a28wc) = Genome.Split.split gpart_a28wb
                      p_a28v2 = double g_a28v1
                      (g_a28v1, gpart_a28wb) = Genome.Split.split gpart_a28wa
                      p_a28v0 = Functions.belowten' g_a28uZ
                      (g_a28uZ, gpart_a28wa) = Genome.Split.split gpart_a28w9
                      p_a28uY = double g_a28uX
                      (g_a28uX, gpart_a28w9) = Genome.Split.split gpart_a28w8
                      p_a28uW = Functions.belowten' g_a28uV
                      (g_a28uV, gpart_a28w8) = Genome.Split.split gpart_a28w7
                      p_a28uU = double g_a28uT
                      (g_a28uT, gpart_a28w7) = Genome.Split.split gpart_a28w6
                      p_a28uS = Functions.belowten' g_a28uR
                      (g_a28uR, gpart_a28w6) = Genome.Split.split gpart_a28w5
                      p_a28uQ = double g_a28uP
                      (g_a28uP, gpart_a28w5) = Genome.Split.split gpart_a28w4
                      p_a28uO = double g_a28uN
                      (g_a28uN, gpart_a28w4) = Genome.Split.split gpart_a28w3
                      p_a28uM = Functions.belowten' g_a28uL
                      (g_a28uL, gpart_a28w3) = Genome.Split.split gpart_a28w2
                      p_a28uK = double g_a28uJ
                      (g_a28uJ, gpart_a28w2) = Genome.Split.split gpart_a28w1
                      p_a28uI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28uH
                      (g_a28uH, gpart_a28w1) = Genome.Split.split gpart_a28w0
                      p_a28uG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28uF
                      (g_a28uF, gpart_a28w0) = Genome.Split.split gpart_a28vZ
                      p_a28uE = double g_a28uD
                      (g_a28uD, gpart_a28vZ) = Genome.Split.split gpart_a28vY
                      p_a28uC = double g_a28uB
                      (g_a28uB, gpart_a28vY) = Genome.Split.split gpart_a28vX
                      p_a28uA = double g_a28uz
                      (g_a28uz, gpart_a28vX) = Genome.Split.split gpart_a28vW
                      p_a28uy = double g_a28ux
                      (g_a28ux, gpart_a28vW) = Genome.Split.split gpart_a28vV
                      p_a28uw = double g_a28uv
                      (g_a28uv, gpart_a28vV) = Genome.Split.split genome_a28vT
                    in  \ x_a28wC
                          -> let
                               c_PTB_a28wF
                                 = ((Data.Fixed.Vector.toVector x_a28wC) Data.Vector.Unboxed.! 0)
                               c_MiRs_a28wD
                                 = ((Data.Fixed.Vector.toVector x_a28wC) Data.Vector.Unboxed.! 2)
                               c_NPTB_a28wK
                                 = ((Data.Fixed.Vector.toVector x_a28wC) Data.Vector.Unboxed.! 1)
                               c_RESTc_a28wG
                                 = ((Data.Fixed.Vector.toVector x_a28wC) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a28wY
                                 = ((Data.Fixed.Vector.toVector x_a28wC) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a28uE / (1 + ((c_MiRs_a28wD / p_a28uK) ** p_a28uM)))
                                    + (negate (p_a28vK * c_PTB_a28wF))),
                                   ((p_a28uO
                                     / (1
                                        + ((((c_RESTc_a28wG / p_a28uQ) ** p_a28uS)
                                            + ((c_MiRs_a28wD / p_a28uU) ** p_a28uW))
                                           + ((c_PTB_a28wF / p_a28uY) ** p_a28v0))))
                                    + (negate (p_a28vM * c_NPTB_a28wK))),
                                   ((p_a28v2
                                     * (p_a28vg
                                        / ((1 + p_a28vg)
                                           + (((c_NPTB_a28wK / p_a28v8) ** p_a28va)
                                              + ((c_RESTc_a28wG / p_a28vc) ** p_a28ve)))))
                                    + (negate (p_a28vO * c_MiRs_a28wD))),
                                   ((p_a28vi
                                     * ((p_a28vw + ((c_PTB_a28wF / p_a28vk) ** p_a28vm))
                                        / (((1 + p_a28vw) + ((c_PTB_a28wF / p_a28vk) ** p_a28vm))
                                           + (((p_a28uw / p_a28vo) ** p_a28vq)
                                              + ((c_MiRs_a28wD / p_a28vs) ** p_a28vu)))))
                                    + (negate (p_a28vQ * c_RESTc_a28wG))),
                                   ((p_a28vy
                                     * ((p_a28vI + ((c_MiRs_a28wD / p_a28vA) ** p_a28vC))
                                        / (((1 + p_a28vI) + ((c_MiRs_a28wD / p_a28vA) ** p_a28vC))
                                           + ((c_RESTc_a28wG / p_a28vE) ** p_a28vG))))
                                    + (negate (p_a28vS * c_EndoNeuroTFs_a28wY)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519102",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519104",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519108",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519126",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519128",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519146",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519148",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519162",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519164",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a28vT
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28xF
                            p_a28vS = double g_a28vR
                            (g_a28vR, gpart_a28xF) = Genome.Split.split gpart_a28xE
                            p_a28vQ = double g_a28vP
                            (g_a28vP, gpart_a28xE) = Genome.Split.split gpart_a28xD
                            p_a28vO = double g_a28vN
                            (g_a28vN, gpart_a28xD) = Genome.Split.split gpart_a28xC
                            p_a28vM = double g_a28vL
                            (g_a28vL, gpart_a28xC) = Genome.Split.split gpart_a28xB
                            p_a28vK = double g_a28vJ
                            (g_a28vJ, gpart_a28xB) = Genome.Split.split gpart_a28xA
                            p_a28vI = double g_a28vH
                            (g_a28vH, gpart_a28xA) = Genome.Split.split gpart_a28xz
                            p_a28vG = Functions.belowten' g_a28vF
                            (g_a28vF, gpart_a28xz) = Genome.Split.split gpart_a28xy
                            p_a28vE = double g_a28vD
                            (g_a28vD, gpart_a28xy) = Genome.Split.split gpart_a28xx
                            p_a28vC = Functions.belowten' g_a28vB
                            (g_a28vB, gpart_a28xx) = Genome.Split.split gpart_a28xw
                            p_a28vA = double g_a28vz
                            (g_a28vz, gpart_a28xw) = Genome.Split.split gpart_a28xv
                            p_a28vy = double g_a28vx
                            (g_a28vx, gpart_a28xv) = Genome.Split.split gpart_a28xu
                            p_a28vw = double g_a28vv
                            (g_a28vv, gpart_a28xu) = Genome.Split.split gpart_a28xt
                            p_a28vu = Functions.belowten' g_a28vt
                            (g_a28vt, gpart_a28xt) = Genome.Split.split gpart_a28xs
                            p_a28vs = double g_a28vr
                            (g_a28vr, gpart_a28xs) = Genome.Split.split gpart_a28xr
                            p_a28vq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28vp
                            (g_a28vp, gpart_a28xr) = Genome.Split.split gpart_a28xq
                            p_a28vo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28vn
                            (g_a28vn, gpart_a28xq) = Genome.Split.split gpart_a28xp
                            p_a28vm = Functions.belowten' g_a28vl
                            (g_a28vl, gpart_a28xp) = Genome.Split.split gpart_a28xo
                            p_a28vk = double g_a28vj
                            (g_a28vj, gpart_a28xo) = Genome.Split.split gpart_a28xn
                            p_a28vi = double g_a28vh
                            (g_a28vh, gpart_a28xn) = Genome.Split.split gpart_a28xm
                            p_a28vg = double g_a28vf
                            (g_a28vf, gpart_a28xm) = Genome.Split.split gpart_a28xl
                            p_a28ve = Functions.belowten' g_a28vd
                            (g_a28vd, gpart_a28xl) = Genome.Split.split gpart_a28xk
                            p_a28vc = double g_a28vb
                            (g_a28vb, gpart_a28xk) = Genome.Split.split gpart_a28xj
                            p_a28va = Functions.belowten' g_a28v9
                            (g_a28v9, gpart_a28xj) = Genome.Split.split gpart_a28xi
                            p_a28v8 = double g_a28v7
                            (g_a28v7, gpart_a28xi) = Genome.Split.split gpart_a28xh
                            p_a28v6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28v5
                            (g_a28v5, gpart_a28xh) = Genome.Split.split gpart_a28xg
                            p_a28v4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28v3
                            (g_a28v3, gpart_a28xg) = Genome.Split.split gpart_a28xf
                            p_a28v2 = double g_a28v1
                            (g_a28v1, gpart_a28xf) = Genome.Split.split gpart_a28xe
                            p_a28v0 = Functions.belowten' g_a28uZ
                            (g_a28uZ, gpart_a28xe) = Genome.Split.split gpart_a28xd
                            p_a28uY = double g_a28uX
                            (g_a28uX, gpart_a28xd) = Genome.Split.split gpart_a28xc
                            p_a28uW = Functions.belowten' g_a28uV
                            (g_a28uV, gpart_a28xc) = Genome.Split.split gpart_a28xb
                            p_a28uU = double g_a28uT
                            (g_a28uT, gpart_a28xb) = Genome.Split.split gpart_a28xa
                            p_a28uS = Functions.belowten' g_a28uR
                            (g_a28uR, gpart_a28xa) = Genome.Split.split gpart_a28x9
                            p_a28uQ = double g_a28uP
                            (g_a28uP, gpart_a28x9) = Genome.Split.split gpart_a28x8
                            p_a28uO = double g_a28uN
                            (g_a28uN, gpart_a28x8) = Genome.Split.split gpart_a28x7
                            p_a28uM = Functions.belowten' g_a28uL
                            (g_a28uL, gpart_a28x7) = Genome.Split.split gpart_a28x6
                            p_a28uK = double g_a28uJ
                            (g_a28uJ, gpart_a28x6) = Genome.Split.split gpart_a28x5
                            p_a28uI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28uH
                            (g_a28uH, gpart_a28x5) = Genome.Split.split gpart_a28x4
                            p_a28uG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28uF
                            (g_a28uF, gpart_a28x4) = Genome.Split.split gpart_a28x3
                            p_a28uE = double g_a28uD
                            (g_a28uD, gpart_a28x3) = Genome.Split.split gpart_a28x2
                            p_a28uC = double g_a28uB
                            (g_a28uB, gpart_a28x2) = Genome.Split.split gpart_a28x1
                            p_a28uA = double g_a28uz
                            (g_a28uz, gpart_a28x1) = Genome.Split.split gpart_a28x0
                            p_a28uy = double g_a28ux
                            (g_a28ux, gpart_a28x0) = Genome.Split.split gpart_a28wZ
                            p_a28uw = double g_a28uv
                            (g_a28uv, gpart_a28wZ) = Genome.Split.split genome_a28vT
                          in
                            \ desc_a28vU
                              -> case desc_a28vU of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uw)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uy)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uA)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uC)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uE)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uG)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uI)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uK)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uM)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uO)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uQ)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uS)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uU)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uW)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28uY)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28v0)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28v2)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28v4)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28v6)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28v8)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28va)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vc)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ve)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vg)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vi)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vk)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vm)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vo)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vq)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vs)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vu)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vw)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vy)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vA)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vC)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vE)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vG)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vI)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vK)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vM)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vO)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vQ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28vS)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a28Ad
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28AV
                      p_a28Ac = double g_a28Ab
                      (g_a28Ab, gpart_a28AV) = Genome.Split.split gpart_a28AU
                      p_a28Aa = double g_a28A9
                      (g_a28A9, gpart_a28AU) = Genome.Split.split gpart_a28AT
                      p_a28A8 = double g_a28A7
                      (g_a28A7, gpart_a28AT) = Genome.Split.split gpart_a28AS
                      p_a28A6 = double g_a28A5
                      (g_a28A5, gpart_a28AS) = Genome.Split.split gpart_a28AR
                      p_a28A4 = double g_a28A3
                      (g_a28A3, gpart_a28AR) = Genome.Split.split gpart_a28AQ
                      p_a28A2 = double g_a28A1
                      (g_a28A1, gpart_a28AQ) = Genome.Split.split gpart_a28AP
                      p_a28A0 = Functions.belowten' g_a28zZ
                      (g_a28zZ, gpart_a28AP) = Genome.Split.split gpart_a28AO
                      p_a28zY = double g_a28zX
                      (g_a28zX, gpart_a28AO) = Genome.Split.split gpart_a28AN
                      p_a28zW = Functions.belowten' g_a28zV
                      (g_a28zV, gpart_a28AN) = Genome.Split.split gpart_a28AM
                      p_a28zU = double g_a28zT
                      (g_a28zT, gpart_a28AM) = Genome.Split.split gpart_a28AL
                      p_a28zS = double g_a28zR
                      (g_a28zR, gpart_a28AL) = Genome.Split.split gpart_a28AK
                      p_a28zQ = double g_a28zP
                      (g_a28zP, gpart_a28AK) = Genome.Split.split gpart_a28AJ
                      p_a28zO = Functions.belowten' g_a28zN
                      (g_a28zN, gpart_a28AJ) = Genome.Split.split gpart_a28AI
                      p_a28zM = double g_a28zL
                      (g_a28zL, gpart_a28AI) = Genome.Split.split gpart_a28AH
                      p_a28zK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zJ
                      (g_a28zJ, gpart_a28AH) = Genome.Split.split gpart_a28AG
                      p_a28zI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zH
                      (g_a28zH, gpart_a28AG) = Genome.Split.split gpart_a28AF
                      p_a28zG = Functions.belowten' g_a28zF
                      (g_a28zF, gpart_a28AF) = Genome.Split.split gpart_a28AE
                      p_a28zE = double g_a28zD
                      (g_a28zD, gpart_a28AE) = Genome.Split.split gpart_a28AD
                      p_a28zC = double g_a28zB
                      (g_a28zB, gpart_a28AD) = Genome.Split.split gpart_a28AC
                      p_a28zA = double g_a28zz
                      (g_a28zz, gpart_a28AC) = Genome.Split.split gpart_a28AB
                      p_a28zy = Functions.belowten' g_a28zx
                      (g_a28zx, gpart_a28AB) = Genome.Split.split gpart_a28AA
                      p_a28zw = double g_a28zv
                      (g_a28zv, gpart_a28AA) = Genome.Split.split gpart_a28Az
                      p_a28zu = Functions.belowten' g_a28zt
                      (g_a28zt, gpart_a28Az) = Genome.Split.split gpart_a28Ay
                      p_a28zs = double g_a28zr
                      (g_a28zr, gpart_a28Ay) = Genome.Split.split gpart_a28Ax
                      p_a28zq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zp
                      (g_a28zp, gpart_a28Ax) = Genome.Split.split gpart_a28Aw
                      p_a28zo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zn
                      (g_a28zn, gpart_a28Aw) = Genome.Split.split gpart_a28Av
                      p_a28zm = double g_a28zl
                      (g_a28zl, gpart_a28Av) = Genome.Split.split gpart_a28Au
                      p_a28zk = Functions.belowten' g_a28zj
                      (g_a28zj, gpart_a28Au) = Genome.Split.split gpart_a28At
                      p_a28zi = double g_a28zh
                      (g_a28zh, gpart_a28At) = Genome.Split.split gpart_a28As
                      p_a28zg = Functions.belowten' g_a28zf
                      (g_a28zf, gpart_a28As) = Genome.Split.split gpart_a28Ar
                      p_a28ze = double g_a28zd
                      (g_a28zd, gpart_a28Ar) = Genome.Split.split gpart_a28Aq
                      p_a28zc = Functions.belowten' g_a28zb
                      (g_a28zb, gpart_a28Aq) = Genome.Split.split gpart_a28Ap
                      p_a28za = double g_a28z9
                      (g_a28z9, gpart_a28Ap) = Genome.Split.split gpart_a28Ao
                      p_a28z8 = double g_a28z7
                      (g_a28z7, gpart_a28Ao) = Genome.Split.split gpart_a28An
                      p_a28z6 = Functions.belowten' g_a28z5
                      (g_a28z5, gpart_a28An) = Genome.Split.split gpart_a28Am
                      p_a28z4 = double g_a28z3
                      (g_a28z3, gpart_a28Am) = Genome.Split.split gpart_a28Al
                      p_a28z2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28z1
                      (g_a28z1, gpart_a28Al) = Genome.Split.split gpart_a28Ak
                      p_a28z0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28yZ
                      (g_a28yZ, gpart_a28Ak) = Genome.Split.split gpart_a28Aj
                      p_a28yY = double g_a28yX
                      (g_a28yX, gpart_a28Aj) = Genome.Split.split gpart_a28Ai
                      p_a28yW = double g_a28yV
                      (g_a28yV, gpart_a28Ai) = Genome.Split.split gpart_a28Ah
                      p_a28yU = double g_a28yT
                      (g_a28yT, gpart_a28Ah) = Genome.Split.split gpart_a28Ag
                      p_a28yS = double g_a28yR
                      (g_a28yR, gpart_a28Ag) = Genome.Split.split gpart_a28Af
                      p_a28yQ = double g_a28yP
                      (g_a28yP, gpart_a28Af) = Genome.Split.split genome_a28Ad
                    in  \ x_a28AW
                          -> let
                               c_PTB_a28AZ
                                 = ((Data.Fixed.Vector.toVector x_a28AW) Data.Vector.Unboxed.! 0)
                               c_MiRs_a28AX
                                 = ((Data.Fixed.Vector.toVector x_a28AW) Data.Vector.Unboxed.! 2)
                               c_NPTB_a28B4
                                 = ((Data.Fixed.Vector.toVector x_a28AW) Data.Vector.Unboxed.! 1)
                               c_RESTc_a28B0
                                 = ((Data.Fixed.Vector.toVector x_a28AW) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a28Bi
                                 = ((Data.Fixed.Vector.toVector x_a28AW) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a28yY / (1 + ((c_MiRs_a28AX / p_a28z4) ** p_a28z6)))
                                    + (negate (p_a28A4 * c_PTB_a28AZ))),
                                   ((p_a28z8
                                     / (1
                                        + ((((c_RESTc_a28B0 / p_a28za) ** p_a28zc)
                                            + ((c_MiRs_a28AX / p_a28ze) ** p_a28zg))
                                           + ((c_PTB_a28AZ / p_a28zi) ** p_a28zk))))
                                    + (negate (p_a28A6 * c_NPTB_a28B4))),
                                   ((p_a28zm
                                     * (p_a28zA
                                        / ((1 + p_a28zA)
                                           + (((c_NPTB_a28B4 / p_a28zs) ** p_a28zu)
                                              + ((c_RESTc_a28B0 / p_a28zw) ** p_a28zy)))))
                                    + (negate (p_a28A8 * c_MiRs_a28AX))),
                                   ((p_a28zC
                                     * ((p_a28zQ + ((c_PTB_a28AZ / p_a28zE) ** p_a28zG))
                                        / (((1 + p_a28zQ) + ((c_PTB_a28AZ / p_a28zE) ** p_a28zG))
                                           + ((c_MiRs_a28AX / p_a28zM) ** p_a28zO))))
                                    + (negate (p_a28Aa * c_RESTc_a28B0))),
                                   ((p_a28zS
                                     * ((p_a28A2 + ((c_MiRs_a28AX / p_a28zU) ** p_a28zW))
                                        / (((1 + p_a28A2) + ((c_MiRs_a28AX / p_a28zU) ** p_a28zW))
                                           + ((c_RESTc_a28B0 / p_a28zY) ** p_a28A0))))
                                    + (negate (p_a28Ac * c_EndoNeuroTFs_a28Bi)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519370",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519372",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519394",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519396",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519416",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a28Ad
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28BZ
                            p_a28Ac = double g_a28Ab
                            (g_a28Ab, gpart_a28BZ) = Genome.Split.split gpart_a28BY
                            p_a28Aa = double g_a28A9
                            (g_a28A9, gpart_a28BY) = Genome.Split.split gpart_a28BX
                            p_a28A8 = double g_a28A7
                            (g_a28A7, gpart_a28BX) = Genome.Split.split gpart_a28BW
                            p_a28A6 = double g_a28A5
                            (g_a28A5, gpart_a28BW) = Genome.Split.split gpart_a28BV
                            p_a28A4 = double g_a28A3
                            (g_a28A3, gpart_a28BV) = Genome.Split.split gpart_a28BU
                            p_a28A2 = double g_a28A1
                            (g_a28A1, gpart_a28BU) = Genome.Split.split gpart_a28BT
                            p_a28A0 = Functions.belowten' g_a28zZ
                            (g_a28zZ, gpart_a28BT) = Genome.Split.split gpart_a28BS
                            p_a28zY = double g_a28zX
                            (g_a28zX, gpart_a28BS) = Genome.Split.split gpart_a28BR
                            p_a28zW = Functions.belowten' g_a28zV
                            (g_a28zV, gpart_a28BR) = Genome.Split.split gpart_a28BQ
                            p_a28zU = double g_a28zT
                            (g_a28zT, gpart_a28BQ) = Genome.Split.split gpart_a28BP
                            p_a28zS = double g_a28zR
                            (g_a28zR, gpart_a28BP) = Genome.Split.split gpart_a28BO
                            p_a28zQ = double g_a28zP
                            (g_a28zP, gpart_a28BO) = Genome.Split.split gpart_a28BN
                            p_a28zO = Functions.belowten' g_a28zN
                            (g_a28zN, gpart_a28BN) = Genome.Split.split gpart_a28BM
                            p_a28zM = double g_a28zL
                            (g_a28zL, gpart_a28BM) = Genome.Split.split gpart_a28BL
                            p_a28zK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zJ
                            (g_a28zJ, gpart_a28BL) = Genome.Split.split gpart_a28BK
                            p_a28zI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zH
                            (g_a28zH, gpart_a28BK) = Genome.Split.split gpart_a28BJ
                            p_a28zG = Functions.belowten' g_a28zF
                            (g_a28zF, gpart_a28BJ) = Genome.Split.split gpart_a28BI
                            p_a28zE = double g_a28zD
                            (g_a28zD, gpart_a28BI) = Genome.Split.split gpart_a28BH
                            p_a28zC = double g_a28zB
                            (g_a28zB, gpart_a28BH) = Genome.Split.split gpart_a28BG
                            p_a28zA = double g_a28zz
                            (g_a28zz, gpart_a28BG) = Genome.Split.split gpart_a28BF
                            p_a28zy = Functions.belowten' g_a28zx
                            (g_a28zx, gpart_a28BF) = Genome.Split.split gpart_a28BE
                            p_a28zw = double g_a28zv
                            (g_a28zv, gpart_a28BE) = Genome.Split.split gpart_a28BD
                            p_a28zu = Functions.belowten' g_a28zt
                            (g_a28zt, gpart_a28BD) = Genome.Split.split gpart_a28BC
                            p_a28zs = double g_a28zr
                            (g_a28zr, gpart_a28BC) = Genome.Split.split gpart_a28BB
                            p_a28zq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zp
                            (g_a28zp, gpart_a28BB) = Genome.Split.split gpart_a28BA
                            p_a28zo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28zn
                            (g_a28zn, gpart_a28BA) = Genome.Split.split gpart_a28Bz
                            p_a28zm = double g_a28zl
                            (g_a28zl, gpart_a28Bz) = Genome.Split.split gpart_a28By
                            p_a28zk = Functions.belowten' g_a28zj
                            (g_a28zj, gpart_a28By) = Genome.Split.split gpart_a28Bx
                            p_a28zi = double g_a28zh
                            (g_a28zh, gpart_a28Bx) = Genome.Split.split gpart_a28Bw
                            p_a28zg = Functions.belowten' g_a28zf
                            (g_a28zf, gpart_a28Bw) = Genome.Split.split gpart_a28Bv
                            p_a28ze = double g_a28zd
                            (g_a28zd, gpart_a28Bv) = Genome.Split.split gpart_a28Bu
                            p_a28zc = Functions.belowten' g_a28zb
                            (g_a28zb, gpart_a28Bu) = Genome.Split.split gpart_a28Bt
                            p_a28za = double g_a28z9
                            (g_a28z9, gpart_a28Bt) = Genome.Split.split gpart_a28Bs
                            p_a28z8 = double g_a28z7
                            (g_a28z7, gpart_a28Bs) = Genome.Split.split gpart_a28Br
                            p_a28z6 = Functions.belowten' g_a28z5
                            (g_a28z5, gpart_a28Br) = Genome.Split.split gpart_a28Bq
                            p_a28z4 = double g_a28z3
                            (g_a28z3, gpart_a28Bq) = Genome.Split.split gpart_a28Bp
                            p_a28z2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28z1
                            (g_a28z1, gpart_a28Bp) = Genome.Split.split gpart_a28Bo
                            p_a28z0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28yZ
                            (g_a28yZ, gpart_a28Bo) = Genome.Split.split gpart_a28Bn
                            p_a28yY = double g_a28yX
                            (g_a28yX, gpart_a28Bn) = Genome.Split.split gpart_a28Bm
                            p_a28yW = double g_a28yV
                            (g_a28yV, gpart_a28Bm) = Genome.Split.split gpart_a28Bl
                            p_a28yU = double g_a28yT
                            (g_a28yT, gpart_a28Bl) = Genome.Split.split gpart_a28Bk
                            p_a28yS = double g_a28yR
                            (g_a28yR, gpart_a28Bk) = Genome.Split.split gpart_a28Bj
                            p_a28yQ = double g_a28yP
                            (g_a28yP, gpart_a28Bj) = Genome.Split.split genome_a28Ad
                          in
                            \ desc_a28Ae
                              -> case desc_a28Ae of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28yQ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28yS)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28yU)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28yW)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28yY)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28z0)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28z2)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28z4)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28z6)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28z8)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28za)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zc)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28ze)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zg)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zi)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zk)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zm)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zo)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zq)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zs)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zu)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zw)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zy)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zA)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zC)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zE)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zG)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zI)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zK)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zM)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zO)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zQ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zS)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zU)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28zY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28A0)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28A2)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28A4)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28A6)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28A8)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Aa)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ac)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a28Ex
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28Ff
                      p_a28Ew = double g_a28Ev
                      (g_a28Ev, gpart_a28Ff) = Genome.Split.split gpart_a28Fe
                      p_a28Eu = double g_a28Et
                      (g_a28Et, gpart_a28Fe) = Genome.Split.split gpart_a28Fd
                      p_a28Es = double g_a28Er
                      (g_a28Er, gpart_a28Fd) = Genome.Split.split gpart_a28Fc
                      p_a28Eq = double g_a28Ep
                      (g_a28Ep, gpart_a28Fc) = Genome.Split.split gpart_a28Fb
                      p_a28Eo = double g_a28En
                      (g_a28En, gpart_a28Fb) = Genome.Split.split gpart_a28Fa
                      p_a28Em = double g_a28El
                      (g_a28El, gpart_a28Fa) = Genome.Split.split gpart_a28F9
                      p_a28Ek = Functions.belowten' g_a28Ej
                      (g_a28Ej, gpart_a28F9) = Genome.Split.split gpart_a28F8
                      p_a28Ei = double g_a28Eh
                      (g_a28Eh, gpart_a28F8) = Genome.Split.split gpart_a28F7
                      p_a28Eg = Functions.belowten' g_a28Ef
                      (g_a28Ef, gpart_a28F7) = Genome.Split.split gpart_a28F6
                      p_a28Ee = double g_a28Ed
                      (g_a28Ed, gpart_a28F6) = Genome.Split.split gpart_a28F5
                      p_a28Ec = double g_a28Eb
                      (g_a28Eb, gpart_a28F5) = Genome.Split.split gpart_a28F4
                      p_a28Ea = double g_a28E9
                      (g_a28E9, gpart_a28F4) = Genome.Split.split gpart_a28F3
                      p_a28E8 = Functions.belowten' g_a28E7
                      (g_a28E7, gpart_a28F3) = Genome.Split.split gpart_a28F2
                      p_a28E6 = double g_a28E5
                      (g_a28E5, gpart_a28F2) = Genome.Split.split gpart_a28F1
                      p_a28E4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28E3
                      (g_a28E3, gpart_a28F1) = Genome.Split.split gpart_a28F0
                      p_a28E2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28E1
                      (g_a28E1, gpart_a28F0) = Genome.Split.split gpart_a28EZ
                      p_a28E0 = Functions.belowten' g_a28DZ
                      (g_a28DZ, gpart_a28EZ) = Genome.Split.split gpart_a28EY
                      p_a28DY = double g_a28DX
                      (g_a28DX, gpart_a28EY) = Genome.Split.split gpart_a28EX
                      p_a28DW = double g_a28DV
                      (g_a28DV, gpart_a28EX) = Genome.Split.split gpart_a28EW
                      p_a28DU = double g_a28DT
                      (g_a28DT, gpart_a28EW) = Genome.Split.split gpart_a28EV
                      p_a28DS = Functions.belowten' g_a28DR
                      (g_a28DR, gpart_a28EV) = Genome.Split.split gpart_a28EU
                      p_a28DQ = double g_a28DP
                      (g_a28DP, gpart_a28EU) = Genome.Split.split gpart_a28ET
                      p_a28DO = Functions.belowten' g_a28DN
                      (g_a28DN, gpart_a28ET) = Genome.Split.split gpart_a28ES
                      p_a28DM = double g_a28DL
                      (g_a28DL, gpart_a28ES) = Genome.Split.split gpart_a28ER
                      p_a28DK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28DJ
                      (g_a28DJ, gpart_a28ER) = Genome.Split.split gpart_a28EQ
                      p_a28DI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28DH
                      (g_a28DH, gpart_a28EQ) = Genome.Split.split gpart_a28EP
                      p_a28DG = double g_a28DF
                      (g_a28DF, gpart_a28EP) = Genome.Split.split gpart_a28EO
                      p_a28DE = Functions.belowten' g_a28DD
                      (g_a28DD, gpart_a28EO) = Genome.Split.split gpart_a28EN
                      p_a28DC = double g_a28DB
                      (g_a28DB, gpart_a28EN) = Genome.Split.split gpart_a28EM
                      p_a28DA = Functions.belowten' g_a28Dz
                      (g_a28Dz, gpart_a28EM) = Genome.Split.split gpart_a28EL
                      p_a28Dy = double g_a28Dx
                      (g_a28Dx, gpart_a28EL) = Genome.Split.split gpart_a28EK
                      p_a28Dw = Functions.belowten' g_a28Dv
                      (g_a28Dv, gpart_a28EK) = Genome.Split.split gpart_a28EJ
                      p_a28Du = double g_a28Dt
                      (g_a28Dt, gpart_a28EJ) = Genome.Split.split gpart_a28EI
                      p_a28Ds = double g_a28Dr
                      (g_a28Dr, gpart_a28EI) = Genome.Split.split gpart_a28EH
                      p_a28Dq = Functions.belowten' g_a28Dp
                      (g_a28Dp, gpart_a28EH) = Genome.Split.split gpart_a28EG
                      p_a28Do = double g_a28Dn
                      (g_a28Dn, gpart_a28EG) = Genome.Split.split gpart_a28EF
                      p_a28Dm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28Dl
                      (g_a28Dl, gpart_a28EF) = Genome.Split.split gpart_a28EE
                      p_a28Dk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28Dj
                      (g_a28Dj, gpart_a28EE) = Genome.Split.split gpart_a28ED
                      p_a28Di = double g_a28Dh
                      (g_a28Dh, gpart_a28ED) = Genome.Split.split gpart_a28EC
                      p_a28Dg = double g_a28Df
                      (g_a28Df, gpart_a28EC) = Genome.Split.split gpart_a28EB
                      p_a28De = double g_a28Dd
                      (g_a28Dd, gpart_a28EB) = Genome.Split.split gpart_a28EA
                      p_a28Dc = double g_a28Db
                      (g_a28Db, gpart_a28EA) = Genome.Split.split gpart_a28Ez
                      p_a28Da = double g_a28D9
                      (g_a28D9, gpart_a28Ez) = Genome.Split.split genome_a28Ex
                    in  \ x_a28Fg
                          -> let
                               c_PTB_a28Fj
                                 = ((Data.Fixed.Vector.toVector x_a28Fg) Data.Vector.Unboxed.! 0)
                               c_MiRs_a28Fh
                                 = ((Data.Fixed.Vector.toVector x_a28Fg) Data.Vector.Unboxed.! 2)
                               c_NPTB_a28Fo
                                 = ((Data.Fixed.Vector.toVector x_a28Fg) Data.Vector.Unboxed.! 1)
                               c_RESTc_a28Fk
                                 = ((Data.Fixed.Vector.toVector x_a28Fg) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a28FC
                                 = ((Data.Fixed.Vector.toVector x_a28Fg) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a28Di
                                     / (1
                                        + (((p_a28Da / p_a28Dk) ** p_a28Dm)
                                           + ((c_MiRs_a28Fh / p_a28Do) ** p_a28Dq))))
                                    + (negate (p_a28Eo * c_PTB_a28Fj))),
                                   ((p_a28Ds
                                     / (1
                                        + ((((c_RESTc_a28Fk / p_a28Du) ** p_a28Dw)
                                            + ((c_MiRs_a28Fh / p_a28Dy) ** p_a28DA))
                                           + ((c_PTB_a28Fj / p_a28DC) ** p_a28DE))))
                                    + (negate (p_a28Eq * c_NPTB_a28Fo))),
                                   ((p_a28DG
                                     * (p_a28DU
                                        / ((1 + p_a28DU)
                                           + (((c_NPTB_a28Fo / p_a28DM) ** p_a28DO)
                                              + ((c_RESTc_a28Fk / p_a28DQ) ** p_a28DS)))))
                                    + (negate (p_a28Es * c_MiRs_a28Fh))),
                                   ((p_a28DW
                                     * ((p_a28Ea + ((c_PTB_a28Fj / p_a28DY) ** p_a28E0))
                                        / (((1 + p_a28Ea) + ((c_PTB_a28Fj / p_a28DY) ** p_a28E0))
                                           + ((c_MiRs_a28Fh / p_a28E6) ** p_a28E8))))
                                    + (negate (p_a28Eu * c_RESTc_a28Fk))),
                                   ((p_a28Ec
                                     * ((p_a28Em + ((c_MiRs_a28Fh / p_a28Ee) ** p_a28Eg))
                                        / (((1 + p_a28Em) + ((c_MiRs_a28Fh / p_a28Ee) ** p_a28Eg))
                                           + ((c_RESTc_a28Fk / p_a28Ei) ** p_a28Ek))))
                                    + (negate (p_a28Ew * c_EndoNeuroTFs_a28FC)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519638",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519640",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519648",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519650",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519662",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519664",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519668",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519670",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519682",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519684",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519700",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519702",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679519711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679519712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a28Ex
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a28Gj
                            p_a28Ew = double g_a28Ev
                            (g_a28Ev, gpart_a28Gj) = Genome.Split.split gpart_a28Gi
                            p_a28Eu = double g_a28Et
                            (g_a28Et, gpart_a28Gi) = Genome.Split.split gpart_a28Gh
                            p_a28Es = double g_a28Er
                            (g_a28Er, gpart_a28Gh) = Genome.Split.split gpart_a28Gg
                            p_a28Eq = double g_a28Ep
                            (g_a28Ep, gpart_a28Gg) = Genome.Split.split gpart_a28Gf
                            p_a28Eo = double g_a28En
                            (g_a28En, gpart_a28Gf) = Genome.Split.split gpart_a28Ge
                            p_a28Em = double g_a28El
                            (g_a28El, gpart_a28Ge) = Genome.Split.split gpart_a28Gd
                            p_a28Ek = Functions.belowten' g_a28Ej
                            (g_a28Ej, gpart_a28Gd) = Genome.Split.split gpart_a28Gc
                            p_a28Ei = double g_a28Eh
                            (g_a28Eh, gpart_a28Gc) = Genome.Split.split gpart_a28Gb
                            p_a28Eg = Functions.belowten' g_a28Ef
                            (g_a28Ef, gpart_a28Gb) = Genome.Split.split gpart_a28Ga
                            p_a28Ee = double g_a28Ed
                            (g_a28Ed, gpart_a28Ga) = Genome.Split.split gpart_a28G9
                            p_a28Ec = double g_a28Eb
                            (g_a28Eb, gpart_a28G9) = Genome.Split.split gpart_a28G8
                            p_a28Ea = double g_a28E9
                            (g_a28E9, gpart_a28G8) = Genome.Split.split gpart_a28G7
                            p_a28E8 = Functions.belowten' g_a28E7
                            (g_a28E7, gpart_a28G7) = Genome.Split.split gpart_a28G6
                            p_a28E6 = double g_a28E5
                            (g_a28E5, gpart_a28G6) = Genome.Split.split gpart_a28G5
                            p_a28E4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28E3
                            (g_a28E3, gpart_a28G5) = Genome.Split.split gpart_a28G4
                            p_a28E2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28E1
                            (g_a28E1, gpart_a28G4) = Genome.Split.split gpart_a28G3
                            p_a28E0 = Functions.belowten' g_a28DZ
                            (g_a28DZ, gpart_a28G3) = Genome.Split.split gpart_a28G2
                            p_a28DY = double g_a28DX
                            (g_a28DX, gpart_a28G2) = Genome.Split.split gpart_a28G1
                            p_a28DW = double g_a28DV
                            (g_a28DV, gpart_a28G1) = Genome.Split.split gpart_a28G0
                            p_a28DU = double g_a28DT
                            (g_a28DT, gpart_a28G0) = Genome.Split.split gpart_a28FZ
                            p_a28DS = Functions.belowten' g_a28DR
                            (g_a28DR, gpart_a28FZ) = Genome.Split.split gpart_a28FY
                            p_a28DQ = double g_a28DP
                            (g_a28DP, gpart_a28FY) = Genome.Split.split gpart_a28FX
                            p_a28DO = Functions.belowten' g_a28DN
                            (g_a28DN, gpart_a28FX) = Genome.Split.split gpart_a28FW
                            p_a28DM = double g_a28DL
                            (g_a28DL, gpart_a28FW) = Genome.Split.split gpart_a28FV
                            p_a28DK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28DJ
                            (g_a28DJ, gpart_a28FV) = Genome.Split.split gpart_a28FU
                            p_a28DI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28DH
                            (g_a28DH, gpart_a28FU) = Genome.Split.split gpart_a28FT
                            p_a28DG = double g_a28DF
                            (g_a28DF, gpart_a28FT) = Genome.Split.split gpart_a28FS
                            p_a28DE = Functions.belowten' g_a28DD
                            (g_a28DD, gpart_a28FS) = Genome.Split.split gpart_a28FR
                            p_a28DC = double g_a28DB
                            (g_a28DB, gpart_a28FR) = Genome.Split.split gpart_a28FQ
                            p_a28DA = Functions.belowten' g_a28Dz
                            (g_a28Dz, gpart_a28FQ) = Genome.Split.split gpart_a28FP
                            p_a28Dy = double g_a28Dx
                            (g_a28Dx, gpart_a28FP) = Genome.Split.split gpart_a28FO
                            p_a28Dw = Functions.belowten' g_a28Dv
                            (g_a28Dv, gpart_a28FO) = Genome.Split.split gpart_a28FN
                            p_a28Du = double g_a28Dt
                            (g_a28Dt, gpart_a28FN) = Genome.Split.split gpart_a28FM
                            p_a28Ds = double g_a28Dr
                            (g_a28Dr, gpart_a28FM) = Genome.Split.split gpart_a28FL
                            p_a28Dq = Functions.belowten' g_a28Dp
                            (g_a28Dp, gpart_a28FL) = Genome.Split.split gpart_a28FK
                            p_a28Do = double g_a28Dn
                            (g_a28Dn, gpart_a28FK) = Genome.Split.split gpart_a28FJ
                            p_a28Dm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28Dl
                            (g_a28Dl, gpart_a28FJ) = Genome.Split.split gpart_a28FI
                            p_a28Dk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a28Dj
                            (g_a28Dj, gpart_a28FI) = Genome.Split.split gpart_a28FH
                            p_a28Di = double g_a28Dh
                            (g_a28Dh, gpart_a28FH) = Genome.Split.split gpart_a28FG
                            p_a28Dg = double g_a28Df
                            (g_a28Df, gpart_a28FG) = Genome.Split.split gpart_a28FF
                            p_a28De = double g_a28Dd
                            (g_a28Dd, gpart_a28FF) = Genome.Split.split gpart_a28FE
                            p_a28Dc = double g_a28Db
                            (g_a28Db, gpart_a28FE) = Genome.Split.split gpart_a28FD
                            p_a28Da = double g_a28D9
                            (g_a28D9, gpart_a28FD) = Genome.Split.split genome_a28Ex
                          in
                            \ desc_a28Ey
                              -> case desc_a28Ey of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Da)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dc)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28De)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dg)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Di)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dk)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dm)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Do)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dq)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ds)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Du)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dw)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Dy)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DA)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DC)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DE)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DG)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DI)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DK)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DM)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DO)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DQ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DS)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DU)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DW)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28DY)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28E0)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28E2)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28E4)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28E6)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28E8)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ea)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ec)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ee)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Eg)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ei)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ek)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Em)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Eo)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Eq)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Es)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Eu)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a28Ew)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVP
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                      (g_asV3, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUU = Functions.belowten' g_asUT
                      (g_asUT, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUQ = Functions.belowten' g_asUP
                      (g_asUP, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                      (g_asUN, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                      (g_asUL, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                      (g_asUJ, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUI = Functions.belowten' g_asUH
                      (g_asUH, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                      (g_asUF, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUD
                      (g_asUD, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUB
                      (g_asUB, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUA = Functions.belowten' g_asUz
                      (g_asUz, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                      (g_asUt, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUs = Functions.belowten' g_asUr
                      (g_asUr, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                      (g_asUp, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUo = Functions.belowten' g_asUn
                      (g_asUn, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                      (g_asUl, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUj
                      (g_asUj, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUh
                      (g_asUh, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUe = Functions.belowten' g_asUd
                      (g_asUd, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUa = Functions.belowten' g_asU9
                      (g_asU9, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                      (g_asU7, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asU6 = Functions.belowten' g_asU5
                      (g_asU5, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                      (g_asU3, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU0 = Functions.belowten' g_asTZ
                      (g_asTZ, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asTW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTV
                      (g_asTV, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asTU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTT
                      (g_asTT, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                      (g_asTR, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                      (g_asTN, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                      (g_asTL, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                      (g_asTJ, gpart_asV9) = Genome.Split.split genome_asV7
                    in
                      [Reaction
                         (\ x_asVQ
                            -> let c_MiRs_asVR = ((toVector x_asVQ) Data.Vector.Unboxed.! 2)
                               in (p_asTS / (1 + ((c_MiRs_asVR / p_asTY) ** p_asU0))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVS
                            -> let
                                 c_MiRs_asVU = ((toVector x_asVS) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asVT = ((toVector x_asVS) Data.Vector.Unboxed.! 3)
                                 c_PTB_asVV = ((toVector x_asVS) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asU2
                                  / (1
                                     + ((((c_RESTc_asVT / p_asU4) ** p_asU6)
                                         + ((c_MiRs_asVU / p_asU8) ** p_asUa))
                                        + ((c_PTB_asVV / p_asUc) ** p_asUe)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVW
                            -> let
                                 c_RESTc_asVY = ((toVector x_asVW) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asVX = ((toVector x_asVW) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUg
                                  * ((p_asUu + ((p_asTO / p_asUi) ** p_asUk))
                                     / (((1 + p_asUu) + ((p_asTO / p_asUi) ** p_asUk))
                                        + (((c_NPTB_asVX / p_asUm) ** p_asUo)
                                           + ((c_RESTc_asVY / p_asUq) ** p_asUs))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVZ
                            -> let
                                 c_MiRs_asW2 = ((toVector x_asVZ) Data.Vector.Unboxed.! 2)
                                 c_PTB_asW0 = ((toVector x_asVZ) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUw
                                  * ((p_asUK + ((c_PTB_asW0 / p_asUy) ** p_asUA))
                                     / (((1 + p_asUK) + ((c_PTB_asW0 / p_asUy) ** p_asUA))
                                        + (((p_asTK / p_asUC) ** p_asUE)
                                           + ((c_MiRs_asW2 / p_asUG) ** p_asUI))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asW3
                            -> let
                                 c_RESTc_asW6 = ((toVector x_asW3) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asW4 = ((toVector x_asW3) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asUM
                                  * ((p_asUW + ((c_MiRs_asW4 / p_asUO) ** p_asUQ))
                                     / (((1 + p_asUW) + ((c_MiRs_asW4 / p_asUO) ** p_asUQ))
                                        + ((c_RESTc_asW6 / p_asUS) ** p_asUU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW7
                            -> let c_PTB_asW8 = ((toVector x_asW7) Data.Vector.Unboxed.! 0)
                               in (p_asUY * c_PTB_asW8))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW9
                            -> let c_NPTB_asWa = ((toVector x_asW9) Data.Vector.Unboxed.! 1)
                               in (p_asV0 * c_NPTB_asWa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWb
                            -> let c_MiRs_asWc = ((toVector x_asWb) Data.Vector.Unboxed.! 2)
                               in (p_asV2 * c_MiRs_asWc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWd
                            -> let c_RESTc_asWe = ((toVector x_asWd) Data.Vector.Unboxed.! 3)
                               in (p_asV4 * c_RESTc_asWe))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWf
                            -> let
                                 c_EndoNeuroTFs_asWg = ((toVector x_asWf) Data.Vector.Unboxed.! 4)
                               in (p_asV6 * c_EndoNeuroTFs_asWg))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX2
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                            (g_asV3, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUU = Functions.belowten' g_asUT
                            (g_asUT, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUQ = Functions.belowten' g_asUP
                            (g_asUP, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                            (g_asUN, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                            (g_asUL, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                            (g_asUJ, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUI = Functions.belowten' g_asUH
                            (g_asUH, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                            (g_asUF, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUD
                            (g_asUD, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUB
                            (g_asUB, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUA = Functions.belowten' g_asUz
                            (g_asUz, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                            (g_asUt, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUs = Functions.belowten' g_asUr
                            (g_asUr, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                            (g_asUp, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUo = Functions.belowten' g_asUn
                            (g_asUn, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUm = code-0.1.0.0:Genome.FixedList.Functions.double g_asUl
                            (g_asUl, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUj
                            (g_asUj, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUh
                            (g_asUh, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUe = Functions.belowten' g_asUd
                            (g_asUd, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUa = Functions.belowten' g_asU9
                            (g_asU9, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                            (g_asU7, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asU6 = Functions.belowten' g_asU5
                            (g_asU5, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                            (g_asU3, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asU0 = Functions.belowten' g_asTZ
                            (g_asTZ, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asTW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTV
                            (g_asTV, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asTU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTT
                            (g_asTT, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                            (g_asTR, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                            (g_asTN, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asTM = code-0.1.0.0:Genome.FixedList.Functions.double g_asTL
                            (g_asTL, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asTK = code-0.1.0.0:Genome.FixedList.Functions.double g_asTJ
                            (g_asTJ, gpart_asWm) = Genome.Split.split genome_asV7
                          in
                            \ desc_asV8
                              -> case desc_asV8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZ7
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZP
                      p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                      (g_asZ5, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                      (g_asZ3, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                      (g_asZ1, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                      (g_asYZ, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                      (g_asYX, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                      (g_asYV, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYU = Functions.belowten' g_asYT
                      (g_asYT, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                      (g_asYR, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYQ = Functions.belowten' g_asYP
                      (g_asYP, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                      (g_asYN, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                      (g_asYL, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYI = Functions.belowten' g_asYH
                      (g_asYH, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYD
                      (g_asYD, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYB
                      (g_asYB, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYA = Functions.belowten' g_asYz
                      (g_asYz, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                      (g_asYv, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYs = Functions.belowten' g_asYr
                      (g_asYr, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYo = Functions.belowten' g_asYn
                      (g_asYn, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                      (g_asYj, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYh
                      (g_asYh, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                      (g_asYf, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYe = Functions.belowten' g_asYd
                      (g_asYd, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYa = Functions.belowten' g_asY9
                      (g_asY9, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                      (g_asY7, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asY6 = Functions.belowten' g_asY5
                      (g_asY5, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                      (g_asY3, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                      (g_asY1, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asY0 = Functions.belowten' g_asXZ
                      (g_asXZ, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                      (g_asXX, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asXW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXV
                      (g_asXV, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asXU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXT
                      (g_asXT, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                      (g_asXN, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                      (g_asXL, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                      (g_asXJ, gpart_asZ9) = Genome.Split.split genome_asZ7
                    in
                      [Reaction
                         (\ x_asZQ
                            -> let c_MiRs_asZR = ((toVector x_asZQ) Data.Vector.Unboxed.! 2)
                               in (p_asXS / (1 + ((c_MiRs_asZR / p_asXY) ** p_asY0))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZS
                            -> let
                                 c_MiRs_asZU = ((toVector x_asZS) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asZT = ((toVector x_asZS) Data.Vector.Unboxed.! 3)
                                 c_PTB_asZV = ((toVector x_asZS) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY2
                                  / (1
                                     + ((((c_RESTc_asZT / p_asY4) ** p_asY6)
                                         + ((c_MiRs_asZU / p_asY8) ** p_asYa))
                                        + ((c_PTB_asZV / p_asYc) ** p_asYe)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZW
                            -> let
                                 c_RESTc_asZY = ((toVector x_asZW) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asZX = ((toVector x_asZW) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYg
                                  * (p_asYu
                                     / ((1 + p_asYu)
                                        + (((c_NPTB_asZX / p_asYm) ** p_asYo)
                                           + ((c_RESTc_asZY / p_asYq) ** p_asYs))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZZ
                            -> let
                                 c_MiRs_at02 = ((toVector x_asZZ) Data.Vector.Unboxed.! 2)
                                 c_PTB_at00 = ((toVector x_asZZ) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYw
                                  * ((p_asYK + ((c_PTB_at00 / p_asYy) ** p_asYA))
                                     / (((1 + p_asYK) + ((c_PTB_at00 / p_asYy) ** p_asYA))
                                        + (((p_asXK / p_asYC) ** p_asYE)
                                           + ((c_MiRs_at02 / p_asYG) ** p_asYI))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at03
                            -> let
                                 c_RESTc_at06 = ((toVector x_at03) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at04 = ((toVector x_at03) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYM
                                  * ((p_asYW + ((c_MiRs_at04 / p_asYO) ** p_asYQ))
                                     / (((1 + p_asYW) + ((c_MiRs_at04 / p_asYO) ** p_asYQ))
                                        + ((c_RESTc_at06 / p_asYS) ** p_asYU)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at07
                            -> let c_PTB_at08 = ((toVector x_at07) Data.Vector.Unboxed.! 0)
                               in (p_asYY * c_PTB_at08))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at09
                            -> let c_NPTB_at0a = ((toVector x_at09) Data.Vector.Unboxed.! 1)
                               in (p_asZ0 * c_NPTB_at0a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0b
                            -> let c_MiRs_at0c = ((toVector x_at0b) Data.Vector.Unboxed.! 2)
                               in (p_asZ2 * c_MiRs_at0c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0d
                            -> let c_RESTc_at0e = ((toVector x_at0d) Data.Vector.Unboxed.! 3)
                               in (p_asZ4 * c_RESTc_at0e))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0f
                            -> let
                                 c_EndoNeuroTFs_at0g = ((toVector x_at0f) Data.Vector.Unboxed.! 4)
                               in (p_asZ6 * c_EndoNeuroTFs_at0g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121200",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121202",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZ7
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0X
                            p_asZ6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ5
                            (g_asZ5, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asZ4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ3
                            (g_asZ3, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asZ2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ1
                            (g_asZ1, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asZ0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asYZ
                            (g_asYZ, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYY = code-0.1.0.0:Genome.FixedList.Functions.double g_asYX
                            (g_asYX, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYW = code-0.1.0.0:Genome.FixedList.Functions.double g_asYV
                            (g_asYV, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYU = Functions.belowten' g_asYT
                            (g_asYT, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYS = code-0.1.0.0:Genome.FixedList.Functions.double g_asYR
                            (g_asYR, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYQ = Functions.belowten' g_asYP
                            (g_asYP, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYO = code-0.1.0.0:Genome.FixedList.Functions.double g_asYN
                            (g_asYN, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYM = code-0.1.0.0:Genome.FixedList.Functions.double g_asYL
                            (g_asYL, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYI = Functions.belowten' g_asYH
                            (g_asYH, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYD
                            (g_asYD, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYB
                            (g_asYB, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYA = Functions.belowten' g_asYz
                            (g_asYz, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                            (g_asYv, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYs = Functions.belowten' g_asYr
                            (g_asYr, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYo = Functions.belowten' g_asYn
                            (g_asYn, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                            (g_asYj, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYh
                            (g_asYh, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYg = code-0.1.0.0:Genome.FixedList.Functions.double g_asYf
                            (g_asYf, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYe = Functions.belowten' g_asYd
                            (g_asYd, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYa = Functions.belowten' g_asY9
                            (g_asY9, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asY8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY7
                            (g_asY7, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asY6 = Functions.belowten' g_asY5
                            (g_asY5, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asY4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY3
                            (g_asY3, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asY2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY1
                            (g_asY1, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asY0 = Functions.belowten' g_asXZ
                            (g_asXZ, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asXY = code-0.1.0.0:Genome.FixedList.Functions.double g_asXX
                            (g_asXX, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asXW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXV
                            (g_asXV, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asXU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXT
                            (g_asXT, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asXO = code-0.1.0.0:Genome.FixedList.Functions.double g_asXN
                            (g_asXN, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                            (g_asXL, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asXK = code-0.1.0.0:Genome.FixedList.Functions.double g_asXJ
                            (g_asXJ, gpart_at0h) = Genome.Split.split genome_asZ7
                          in
                            \ desc_asZ8
                              -> case desc_asZ8 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYM)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYO)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYQ)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYS)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYU)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYW)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYY)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ0)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ2)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ4)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ6)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at32
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3K
                      p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                      (g_at30, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                      (g_at2Y, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                      (g_at2W, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                      (g_at2U, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                      (g_at2S, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                      (g_at2Q, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2P = Functions.belowten' g_at2O
                      (g_at2O, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2L = Functions.belowten' g_at2K
                      (g_at2K, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                      (g_at2E, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2D = Functions.belowten' g_at2C
                      (g_at2C, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                      (g_at2A, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                      (g_at2y, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2w
                      (g_at2w, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2v = Functions.belowten' g_at2u
                      (g_at2u, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                      (g_at2s, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                      (g_at2q, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                      (g_at2o, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2n = Functions.belowten' g_at2m
                      (g_at2m, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                      (g_at2k, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2j = Functions.belowten' g_at2i
                      (g_at2i, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                      (g_at2g, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2e
                      (g_at2e, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2d
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2c
                      (g_at2c, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at29 = Functions.belowten' g_at28
                      (g_at28, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                      (g_at26, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at25 = Functions.belowten' g_at24
                      (g_at24, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at21 = Functions.belowten' g_at20
                      (g_at20, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                      (g_at1W, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at1V = Functions.belowten' g_at1U
                      (g_at1U, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                      (g_at1S, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at1R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Q
                      (g_at1Q, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at1P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1O
                      (g_at1O, gpart_at39) = Genome.Split.split gpart_at38
                      p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                      (g_at1M, gpart_at38) = Genome.Split.split gpart_at37
                      p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                      (g_at1K, gpart_at37) = Genome.Split.split gpart_at36
                      p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                      (g_at1I, gpart_at36) = Genome.Split.split gpart_at35
                      p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                      (g_at1G, gpart_at35) = Genome.Split.split gpart_at34
                      p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                      (g_at1E, gpart_at34) = Genome.Split.split genome_at32
                    in
                      [Reaction
                         (\ x_at3L
                            -> let c_MiRs_at3M = ((toVector x_at3L) Data.Vector.Unboxed.! 2)
                               in (p_at1N / (1 + ((c_MiRs_at3M / p_at1T) ** p_at1V))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3N
                            -> let
                                 c_MiRs_at3P = ((toVector x_at3N) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3O = ((toVector x_at3N) Data.Vector.Unboxed.! 3)
                                 c_PTB_at3Q = ((toVector x_at3N) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1X
                                  / (1
                                     + ((((c_RESTc_at3O / p_at1Z) ** p_at21)
                                         + ((c_MiRs_at3P / p_at23) ** p_at25))
                                        + ((c_PTB_at3Q / p_at27) ** p_at29)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3R
                            -> let
                                 c_RESTc_at3T = ((toVector x_at3R) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at3S = ((toVector x_at3R) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at2b
                                  * (p_at2p
                                     / ((1 + p_at2p)
                                        + (((c_NPTB_at3S / p_at2h) ** p_at2j)
                                           + ((c_RESTc_at3T / p_at2l) ** p_at2n))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3U
                            -> let
                                 c_MiRs_at3X = ((toVector x_at3U) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3V = ((toVector x_at3U) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2r
                                  * ((p_at2F + ((c_PTB_at3V / p_at2t) ** p_at2v))
                                     / (((1 + p_at2F) + ((c_PTB_at3V / p_at2t) ** p_at2v))
                                        + ((c_MiRs_at3X / p_at2B) ** p_at2D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3Y
                            -> let
                                 c_RESTc_at41 = ((toVector x_at3Y) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3Z = ((toVector x_at3Y) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2H
                                  * ((p_at2R + ((c_MiRs_at3Z / p_at2J) ** p_at2L))
                                     / (((1 + p_at2R) + ((c_MiRs_at3Z / p_at2J) ** p_at2L))
                                        + ((c_RESTc_at41 / p_at2N) ** p_at2P)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at42
                            -> let c_PTB_at43 = ((toVector x_at42) Data.Vector.Unboxed.! 0)
                               in (p_at2T * c_PTB_at43))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at44
                            -> let c_NPTB_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 1)
                               in (p_at2V * c_NPTB_at45))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at46
                            -> let c_MiRs_at47 = ((toVector x_at46) Data.Vector.Unboxed.! 2)
                               in (p_at2X * c_MiRs_at47))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at48
                            -> let c_RESTc_at49 = ((toVector x_at48) Data.Vector.Unboxed.! 3)
                               in (p_at2Z * c_RESTc_at49))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4a
                            -> let
                                 c_EndoNeuroTFs_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 4)
                               in (p_at31 * c_EndoNeuroTFs_at4b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121381",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121383",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121442",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121443",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121444",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121445",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121446",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121447",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121448",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121449",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121450",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121451",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121452",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121453",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121454",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121455",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at32
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4S
                            p_at31 = code-0.1.0.0:Genome.FixedList.Functions.double g_at30
                            (g_at30, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at2Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Y
                            (g_at2Y, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2X = code-0.1.0.0:Genome.FixedList.Functions.double g_at2W
                            (g_at2W, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2V = code-0.1.0.0:Genome.FixedList.Functions.double g_at2U
                            (g_at2U, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2T = code-0.1.0.0:Genome.FixedList.Functions.double g_at2S
                            (g_at2S, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2R = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Q
                            (g_at2Q, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2P = Functions.belowten' g_at2O
                            (g_at2O, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2L = Functions.belowten' g_at2K
                            (g_at2K, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                            (g_at2E, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2D = Functions.belowten' g_at2C
                            (g_at2C, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2B = code-0.1.0.0:Genome.FixedList.Functions.double g_at2A
                            (g_at2A, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2y
                            (g_at2y, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2w
                            (g_at2w, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2v = Functions.belowten' g_at2u
                            (g_at2u, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                            (g_at2s, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                            (g_at2q, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2p = code-0.1.0.0:Genome.FixedList.Functions.double g_at2o
                            (g_at2o, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2n = Functions.belowten' g_at2m
                            (g_at2m, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2l = code-0.1.0.0:Genome.FixedList.Functions.double g_at2k
                            (g_at2k, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2j = Functions.belowten' g_at2i
                            (g_at2i, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2h = code-0.1.0.0:Genome.FixedList.Functions.double g_at2g
                            (g_at2g, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2e
                            (g_at2e, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2d
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2c
                            (g_at2c, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at29 = Functions.belowten' g_at28
                            (g_at28, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                            (g_at26, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at25 = Functions.belowten' g_at24
                            (g_at24, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at21 = Functions.belowten' g_at20
                            (g_at20, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                            (g_at1W, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at1V = Functions.belowten' g_at1U
                            (g_at1U, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                            (g_at1S, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Q
                            (g_at1Q, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at1P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1O
                            (g_at1O, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                            (g_at1M, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at1L = code-0.1.0.0:Genome.FixedList.Functions.double g_at1K
                            (g_at1K, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                            (g_at1I, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                            (g_at1G, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                            (g_at1E, gpart_at4c) = Genome.Split.split genome_at32
                          in
                            \ desc_at33
                              -> case desc_at33 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1F)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1N)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1P)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1R)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1T)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1V)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2P)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2R)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2T)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2V)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2X)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Z)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at31)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6X
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7F
                      p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                      (g_at6V, gpart_at7F) = Genome.Split.split gpart_at7E
                      p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                      (g_at6T, gpart_at7E) = Genome.Split.split gpart_at7D
                      p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                      (g_at6R, gpart_at7D) = Genome.Split.split gpart_at7C
                      p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                      (g_at6P, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                      (g_at6N, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                      (g_at6L, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6K = Functions.belowten' g_at6J
                      (g_at6J, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                      (g_at6H, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6G = Functions.belowten' g_at6F
                      (g_at6F, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                      (g_at6D, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                      (g_at6B, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                      (g_at6z, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6y = Functions.belowten' g_at6x
                      (g_at6x, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                      (g_at6v, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6t
                      (g_at6t, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6r
                      (g_at6r, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6q = Functions.belowten' g_at6p
                      (g_at6p, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                      (g_at6n, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                      (g_at6l, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                      (g_at6j, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6i = Functions.belowten' g_at6h
                      (g_at6h, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                      (g_at6f, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6e = Functions.belowten' g_at6d
                      (g_at6d, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                      (g_at6b, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                      (g_at69, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at68
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                      (g_at67, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                      (g_at65, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at64 = Functions.belowten' g_at63
                      (g_at63, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                      (g_at61, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at60 = Functions.belowten' g_at5Z
                      (g_at5Z, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                      (g_at5X, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at5W = Functions.belowten' g_at5V
                      (g_at5V, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                      (g_at5T, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                      (g_at5R, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5Q = Functions.belowten' g_at5P
                      (g_at5P, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                      (g_at5N, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                      (g_at5L, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5J
                      (g_at5J, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                      (g_at5F, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                      (g_at5z, gpart_at6Z) = Genome.Split.split genome_at6X
                    in
                      [Reaction
                         (\ x_at7G
                            -> let c_MiRs_at7H = ((toVector x_at7G) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5I
                                  / (1
                                     + (((p_at5A / p_at5K) ** p_at5M)
                                        + ((c_MiRs_at7H / p_at5O) ** p_at5Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7I
                            -> let
                                 c_MiRs_at7K = ((toVector x_at7I) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7J = ((toVector x_at7I) Data.Vector.Unboxed.! 3)
                                 c_PTB_at7L = ((toVector x_at7I) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5S
                                  / (1
                                     + ((((c_RESTc_at7J / p_at5U) ** p_at5W)
                                         + ((c_MiRs_at7K / p_at5Y) ** p_at60))
                                        + ((c_PTB_at7L / p_at62) ** p_at64)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7M
                            -> let
                                 c_RESTc_at7O = ((toVector x_at7M) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at7N = ((toVector x_at7M) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at66
                                  * (p_at6k
                                     / ((1 + p_at6k)
                                        + (((c_NPTB_at7N / p_at6c) ** p_at6e)
                                           + ((c_RESTc_at7O / p_at6g) ** p_at6i))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7P
                            -> let
                                 c_MiRs_at7S = ((toVector x_at7P) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7Q = ((toVector x_at7P) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6m
                                  * ((p_at6A + ((c_PTB_at7Q / p_at6o) ** p_at6q))
                                     / (((1 + p_at6A) + ((c_PTB_at7Q / p_at6o) ** p_at6q))
                                        + ((c_MiRs_at7S / p_at6w) ** p_at6y)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7T
                            -> let
                                 c_RESTc_at7W = ((toVector x_at7T) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7U = ((toVector x_at7T) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6C
                                  * ((p_at6M + ((c_MiRs_at7U / p_at6E) ** p_at6G))
                                     / (((1 + p_at6M) + ((c_MiRs_at7U / p_at6E) ** p_at6G))
                                        + ((c_RESTc_at7W / p_at6I) ** p_at6K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7X
                            -> let c_PTB_at7Y = ((toVector x_at7X) Data.Vector.Unboxed.! 0)
                               in (p_at6O * c_PTB_at7Y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7Z
                            -> let c_NPTB_at80 = ((toVector x_at7Z) Data.Vector.Unboxed.! 1)
                               in (p_at6Q * c_NPTB_at80))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at81
                            -> let c_MiRs_at82 = ((toVector x_at81) Data.Vector.Unboxed.! 2)
                               in (p_at6S * c_MiRs_at82))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at83
                            -> let c_RESTc_at84 = ((toVector x_at83) Data.Vector.Unboxed.! 3)
                               in (p_at6U * c_RESTc_at84))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at85
                            -> let
                                 c_EndoNeuroTFs_at86 = ((toVector x_at85) Data.Vector.Unboxed.! 4)
                               in (p_at6W * c_EndoNeuroTFs_at86))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121631",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121632",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121633",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121634",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121635",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121636",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121637",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121638",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121639",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121640",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121641",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121642",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121643",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121644",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121645",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121646",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121647",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121648",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121649",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121650",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121651",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121652",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121653",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121654",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121655",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121656",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121657",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121658",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121659",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121660",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121661",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121662",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121663",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121664",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121665",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121666",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121667",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121668",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121669",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121670",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121671",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121672",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121673",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121674",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121675",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121676",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121677",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121678",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121679",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121680",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121681",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121682",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121683",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121684",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121685",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121686",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121687",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121688",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6X
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8N
                            p_at6W = code-0.1.0.0:Genome.FixedList.Functions.double g_at6V
                            (g_at6V, gpart_at8N) = Genome.Split.split gpart_at8M
                            p_at6U = code-0.1.0.0:Genome.FixedList.Functions.double g_at6T
                            (g_at6T, gpart_at8M) = Genome.Split.split gpart_at8L
                            p_at6S = code-0.1.0.0:Genome.FixedList.Functions.double g_at6R
                            (g_at6R, gpart_at8L) = Genome.Split.split gpart_at8K
                            p_at6Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at6P
                            (g_at6P, gpart_at8K) = Genome.Split.split gpart_at8J
                            p_at6O = code-0.1.0.0:Genome.FixedList.Functions.double g_at6N
                            (g_at6N, gpart_at8J) = Genome.Split.split gpart_at8I
                            p_at6M = code-0.1.0.0:Genome.FixedList.Functions.double g_at6L
                            (g_at6L, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6K = Functions.belowten' g_at6J
                            (g_at6J, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6I = code-0.1.0.0:Genome.FixedList.Functions.double g_at6H
                            (g_at6H, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6G = Functions.belowten' g_at6F
                            (g_at6F, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6E = code-0.1.0.0:Genome.FixedList.Functions.double g_at6D
                            (g_at6D, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6C = code-0.1.0.0:Genome.FixedList.Functions.double g_at6B
                            (g_at6B, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6A = code-0.1.0.0:Genome.FixedList.Functions.double g_at6z
                            (g_at6z, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6y = Functions.belowten' g_at6x
                            (g_at6x, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6w = code-0.1.0.0:Genome.FixedList.Functions.double g_at6v
                            (g_at6v, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6t
                            (g_at6t, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6r
                            (g_at6r, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6q = Functions.belowten' g_at6p
                            (g_at6p, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6o = code-0.1.0.0:Genome.FixedList.Functions.double g_at6n
                            (g_at6n, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6m = code-0.1.0.0:Genome.FixedList.Functions.double g_at6l
                            (g_at6l, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6k = code-0.1.0.0:Genome.FixedList.Functions.double g_at6j
                            (g_at6j, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6i = Functions.belowten' g_at6h
                            (g_at6h, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6g = code-0.1.0.0:Genome.FixedList.Functions.double g_at6f
                            (g_at6f, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6e = Functions.belowten' g_at6d
                            (g_at6d, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6c = code-0.1.0.0:Genome.FixedList.Functions.double g_at6b
                            (g_at6b, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at69
                            (g_at69, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at68
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at67
                            (g_at67, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at66 = code-0.1.0.0:Genome.FixedList.Functions.double g_at65
                            (g_at65, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at64 = Functions.belowten' g_at63
                            (g_at63, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at62 = code-0.1.0.0:Genome.FixedList.Functions.double g_at61
                            (g_at61, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at60 = Functions.belowten' g_at5Z
                            (g_at5Z, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at5Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at5X
                            (g_at5X, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at5W = Functions.belowten' g_at5V
                            (g_at5V, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at5U = code-0.1.0.0:Genome.FixedList.Functions.double g_at5T
                            (g_at5T, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at5S = code-0.1.0.0:Genome.FixedList.Functions.double g_at5R
                            (g_at5R, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5Q = Functions.belowten' g_at5P
                            (g_at5P, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                            (g_at5N, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at5M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5L
                            (g_at5L, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5J
                            (g_at5J, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at5G = code-0.1.0.0:Genome.FixedList.Functions.double g_at5F
                            (g_at5F, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at89) = Genome.Split.split gpart_at88
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at88) = Genome.Split.split gpart_at87
                            p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                            (g_at5z, gpart_at87) = Genome.Split.split genome_at6X
                          in
                            \ desc_at6Y
                              -> case desc_at6Y of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5S)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5U)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at60)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at62)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at64)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at66)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at68)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6a)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6c)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6e)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6g)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6i)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6k)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6m)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6o)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6q)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6s)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6C)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6E)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6G)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6I)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6K)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6M)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6O)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Q)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6S)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6U)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6W)
                                   _ -> Nothing }}
