src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a210G
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a211k
                      p_a210F = double g_a210E
                      (g_a210E, gpart_a211k) = Genome.Split.split gpart_a211j
                      p_a210D = double g_a210C
                      (g_a210C, gpart_a211j) = Genome.Split.split gpart_a211i
                      p_a210B = double g_a210A
                      (g_a210A, gpart_a211i) = Genome.Split.split gpart_a211h
                      p_a210z = double g_a210y
                      (g_a210y, gpart_a211h) = Genome.Split.split gpart_a211g
                      p_a210x = double g_a210w
                      (g_a210w, gpart_a211g) = Genome.Split.split gpart_a211f
                      p_a210v = Functions.belowten' g_a210u
                      (g_a210u, gpart_a211f) = Genome.Split.split gpart_a211e
                      p_a210t = double g_a210s
                      (g_a210s, gpart_a211e) = Genome.Split.split gpart_a211d
                      p_a210r = double g_a210q
                      (g_a210q, gpart_a211d) = Genome.Split.split gpart_a211c
                      p_a210p = double g_a210o
                      (g_a210o, gpart_a211c) = Genome.Split.split gpart_a211b
                      p_a210n = Functions.belowten' g_a210m
                      (g_a210m, gpart_a211b) = Genome.Split.split gpart_a211a
                      p_a210l = double g_a210k
                      (g_a210k, gpart_a211a) = Genome.Split.split gpart_a2119
                      p_a210j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210i
                      (g_a210i, gpart_a2119) = Genome.Split.split gpart_a2118
                      p_a210h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210g
                      (g_a210g, gpart_a2118) = Genome.Split.split gpart_a2117
                      p_a210f = Functions.belowten' g_a210e
                      (g_a210e, gpart_a2117) = Genome.Split.split gpart_a2116
                      p_a210d = double g_a210c
                      (g_a210c, gpart_a2116) = Genome.Split.split gpart_a2115
                      p_a210b = double g_a210a
                      (g_a210a, gpart_a2115) = Genome.Split.split gpart_a2114
                      p_a2109 = double g_a2108
                      (g_a2108, gpart_a2114) = Genome.Split.split gpart_a2113
                      p_a2107 = Functions.belowten' g_a2106
                      (g_a2106, gpart_a2113) = Genome.Split.split gpart_a2112
                      p_a2105 = double g_a2104
                      (g_a2104, gpart_a2112) = Genome.Split.split gpart_a2111
                      p_a2103
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2102
                      (g_a2102, gpart_a2111) = Genome.Split.split gpart_a2110
                      p_a2101
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2100
                      (g_a2100, gpart_a2110) = Genome.Split.split gpart_a210Z
                      p_a20ZZ = double g_a20ZY
                      (g_a20ZY, gpart_a210Z) = Genome.Split.split gpart_a210Y
                      p_a20ZX = Functions.belowten' g_a20ZW
                      (g_a20ZW, gpart_a210Y) = Genome.Split.split gpart_a210X
                      p_a20ZV = double g_a20ZU
                      (g_a20ZU, gpart_a210X) = Genome.Split.split gpart_a210W
                      p_a20ZT = Functions.belowten' g_a20ZS
                      (g_a20ZS, gpart_a210W) = Genome.Split.split gpart_a210V
                      p_a20ZR = double g_a20ZQ
                      (g_a20ZQ, gpart_a210V) = Genome.Split.split gpart_a210U
                      p_a20ZP = double g_a20ZO
                      (g_a20ZO, gpart_a210U) = Genome.Split.split gpart_a210T
                      p_a20ZN = double g_a20ZM
                      (g_a20ZM, gpart_a210T) = Genome.Split.split gpart_a210S
                      p_a20ZL = Functions.belowten' g_a20ZK
                      (g_a20ZK, gpart_a210S) = Genome.Split.split gpart_a210R
                      p_a20ZJ = double g_a20ZI
                      (g_a20ZI, gpart_a210R) = Genome.Split.split gpart_a210Q
                      p_a20ZH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20ZG
                      (g_a20ZG, gpart_a210Q) = Genome.Split.split gpart_a210P
                      p_a20ZF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20ZE
                      (g_a20ZE, gpart_a210P) = Genome.Split.split gpart_a210O
                      p_a20ZD = Functions.belowten' g_a20ZC
                      (g_a20ZC, gpart_a210O) = Genome.Split.split gpart_a210N
                      p_a20ZB = double g_a20ZA
                      (g_a20ZA, gpart_a210N) = Genome.Split.split gpart_a210M
                      p_a20Zz = double g_a20Zy
                      (g_a20Zy, gpart_a210M) = Genome.Split.split gpart_a210L
                      p_a20Zx = double g_a20Zw
                      (g_a20Zw, gpart_a210L) = Genome.Split.split gpart_a210K
                      p_a20Zv = double g_a20Zu
                      (g_a20Zu, gpart_a210K) = Genome.Split.split gpart_a210J
                      p_a20Zt = double g_a20Zs
                      (g_a20Zs, gpart_a210J) = Genome.Split.split gpart_a210I
                      p_a20Zr = double g_a20Zq
                      (g_a20Zq, gpart_a210I) = Genome.Split.split genome_a210G
                    in  \ x_a211l
                          -> let
                               c_PTB_a211q
                                 = ((Data.Fixed.Vector.toVector x_a211l) Data.Vector.Unboxed.! 0)
                               c_MiRs_a211o
                                 = ((Data.Fixed.Vector.toVector x_a211l) Data.Vector.Unboxed.! 2)
                               c_NPTB_a211m
                                 = ((Data.Fixed.Vector.toVector x_a211l) Data.Vector.Unboxed.! 1)
                               c_RESTc_a211v
                                 = ((Data.Fixed.Vector.toVector x_a211l) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a211F
                                 = ((Data.Fixed.Vector.toVector x_a211l) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a20Zz
                                     * ((p_a20ZN + ((c_NPTB_a211m / p_a20ZB) ** p_a20ZD))
                                        / (((1 + p_a20ZN) + ((c_NPTB_a211m / p_a20ZB) ** p_a20ZD))
                                           + ((c_MiRs_a211o / p_a20ZJ) ** p_a20ZL))))
                                    + (negate (p_a210x * c_PTB_a211q))),
                                   ((p_a20ZP
                                     / (1
                                        + (((c_MiRs_a211o / p_a20ZR) ** p_a20ZT)
                                           + ((c_PTB_a211q / p_a20ZV) ** p_a20ZX))))
                                    + (negate (p_a210z * c_NPTB_a211m))),
                                   ((p_a20ZZ
                                     * ((p_a2109 + ((p_a20Zv / p_a2101) ** p_a2103))
                                        / (((1 + p_a2109) + ((p_a20Zv / p_a2101) ** p_a2103))
                                           + ((c_RESTc_a211v / p_a2105) ** p_a2107))))
                                    + (negate (p_a210B * c_MiRs_a211o))),
                                   ((p_a210b
                                     * ((p_a210p + ((c_PTB_a211q / p_a210d) ** p_a210f))
                                        / (((1 + p_a210p) + ((c_PTB_a211q / p_a210d) ** p_a210f))
                                           + (((p_a20Zr / p_a210h) ** p_a210j)
                                              + ((c_MiRs_a211o / p_a210l) ** p_a210n)))))
                                    + (negate (p_a210D * c_RESTc_a211v))),
                                   ((p_a210r / (1 + ((c_RESTc_a211v / p_a210t) ** p_a210v)))
                                    + (negate (p_a210F * c_EndoNeuroTFs_a211F)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490271",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490273",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490293",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490295",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490309",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490311",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a210G
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a212i
                            p_a210F = double g_a210E
                            (g_a210E, gpart_a212i) = Genome.Split.split gpart_a212h
                            p_a210D = double g_a210C
                            (g_a210C, gpart_a212h) = Genome.Split.split gpart_a212g
                            p_a210B = double g_a210A
                            (g_a210A, gpart_a212g) = Genome.Split.split gpart_a212f
                            p_a210z = double g_a210y
                            (g_a210y, gpart_a212f) = Genome.Split.split gpart_a212e
                            p_a210x = double g_a210w
                            (g_a210w, gpart_a212e) = Genome.Split.split gpart_a212d
                            p_a210v = Functions.belowten' g_a210u
                            (g_a210u, gpart_a212d) = Genome.Split.split gpart_a212c
                            p_a210t = double g_a210s
                            (g_a210s, gpart_a212c) = Genome.Split.split gpart_a212b
                            p_a210r = double g_a210q
                            (g_a210q, gpart_a212b) = Genome.Split.split gpart_a212a
                            p_a210p = double g_a210o
                            (g_a210o, gpart_a212a) = Genome.Split.split gpart_a2129
                            p_a210n = Functions.belowten' g_a210m
                            (g_a210m, gpart_a2129) = Genome.Split.split gpart_a2128
                            p_a210l = double g_a210k
                            (g_a210k, gpart_a2128) = Genome.Split.split gpart_a2127
                            p_a210j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210i
                            (g_a210i, gpart_a2127) = Genome.Split.split gpart_a2126
                            p_a210h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a210g
                            (g_a210g, gpart_a2126) = Genome.Split.split gpart_a2125
                            p_a210f = Functions.belowten' g_a210e
                            (g_a210e, gpart_a2125) = Genome.Split.split gpart_a2124
                            p_a210d = double g_a210c
                            (g_a210c, gpart_a2124) = Genome.Split.split gpart_a2123
                            p_a210b = double g_a210a
                            (g_a210a, gpart_a2123) = Genome.Split.split gpart_a2122
                            p_a2109 = double g_a2108
                            (g_a2108, gpart_a2122) = Genome.Split.split gpart_a2121
                            p_a2107 = Functions.belowten' g_a2106
                            (g_a2106, gpart_a2121) = Genome.Split.split gpart_a2120
                            p_a2105 = double g_a2104
                            (g_a2104, gpart_a2120) = Genome.Split.split gpart_a211Z
                            p_a2103
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2102
                            (g_a2102, gpart_a211Z) = Genome.Split.split gpart_a211Y
                            p_a2101
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2100
                            (g_a2100, gpart_a211Y) = Genome.Split.split gpart_a211X
                            p_a20ZZ = double g_a20ZY
                            (g_a20ZY, gpart_a211X) = Genome.Split.split gpart_a211W
                            p_a20ZX = Functions.belowten' g_a20ZW
                            (g_a20ZW, gpart_a211W) = Genome.Split.split gpart_a211V
                            p_a20ZV = double g_a20ZU
                            (g_a20ZU, gpart_a211V) = Genome.Split.split gpart_a211U
                            p_a20ZT = Functions.belowten' g_a20ZS
                            (g_a20ZS, gpart_a211U) = Genome.Split.split gpart_a211T
                            p_a20ZR = double g_a20ZQ
                            (g_a20ZQ, gpart_a211T) = Genome.Split.split gpart_a211S
                            p_a20ZP = double g_a20ZO
                            (g_a20ZO, gpart_a211S) = Genome.Split.split gpart_a211R
                            p_a20ZN = double g_a20ZM
                            (g_a20ZM, gpart_a211R) = Genome.Split.split gpart_a211Q
                            p_a20ZL = Functions.belowten' g_a20ZK
                            (g_a20ZK, gpart_a211Q) = Genome.Split.split gpart_a211P
                            p_a20ZJ = double g_a20ZI
                            (g_a20ZI, gpart_a211P) = Genome.Split.split gpart_a211O
                            p_a20ZH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20ZG
                            (g_a20ZG, gpart_a211O) = Genome.Split.split gpart_a211N
                            p_a20ZF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a20ZE
                            (g_a20ZE, gpart_a211N) = Genome.Split.split gpart_a211M
                            p_a20ZD = Functions.belowten' g_a20ZC
                            (g_a20ZC, gpart_a211M) = Genome.Split.split gpart_a211L
                            p_a20ZB = double g_a20ZA
                            (g_a20ZA, gpart_a211L) = Genome.Split.split gpart_a211K
                            p_a20Zz = double g_a20Zy
                            (g_a20Zy, gpart_a211K) = Genome.Split.split gpart_a211J
                            p_a20Zx = double g_a20Zw
                            (g_a20Zw, gpart_a211J) = Genome.Split.split gpart_a211I
                            p_a20Zv = double g_a20Zu
                            (g_a20Zu, gpart_a211I) = Genome.Split.split gpart_a211H
                            p_a20Zt = double g_a20Zs
                            (g_a20Zs, gpart_a211H) = Genome.Split.split gpart_a211G
                            p_a20Zr = double g_a20Zq
                            (g_a20Zq, gpart_a211G) = Genome.Split.split genome_a210G
                          in
                            \ desc_a210H
                              -> case desc_a210H of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Zr)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Zt)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Zv)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Zx)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20Zz)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZB)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZD)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZF)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZH)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZJ)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZL)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZN)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZP)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZR)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZT)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZV)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZX)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a20ZZ)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2101)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2103)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2105)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2107)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2109)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210b)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210d)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210f)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210h)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210j)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210l)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210n)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210p)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210r)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210t)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210v)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210x)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210z)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210B)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210D)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a210F)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a214I
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a215m
                      p_a214H = double g_a214G
                      (g_a214G, gpart_a215m) = Genome.Split.split gpart_a215l
                      p_a214F = double g_a214E
                      (g_a214E, gpart_a215l) = Genome.Split.split gpart_a215k
                      p_a214D = double g_a214C
                      (g_a214C, gpart_a215k) = Genome.Split.split gpart_a215j
                      p_a214B = double g_a214A
                      (g_a214A, gpart_a215j) = Genome.Split.split gpart_a215i
                      p_a214z = double g_a214y
                      (g_a214y, gpart_a215i) = Genome.Split.split gpart_a215h
                      p_a214x = Functions.belowten' g_a214w
                      (g_a214w, gpart_a215h) = Genome.Split.split gpart_a215g
                      p_a214v = double g_a214u
                      (g_a214u, gpart_a215g) = Genome.Split.split gpart_a215f
                      p_a214t = double g_a214s
                      (g_a214s, gpart_a215f) = Genome.Split.split gpart_a215e
                      p_a214r = double g_a214q
                      (g_a214q, gpart_a215e) = Genome.Split.split gpart_a215d
                      p_a214p = Functions.belowten' g_a214o
                      (g_a214o, gpart_a215d) = Genome.Split.split gpart_a215c
                      p_a214n = double g_a214m
                      (g_a214m, gpart_a215c) = Genome.Split.split gpart_a215b
                      p_a214l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214k
                      (g_a214k, gpart_a215b) = Genome.Split.split gpart_a215a
                      p_a214j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214i
                      (g_a214i, gpart_a215a) = Genome.Split.split gpart_a2159
                      p_a214h = Functions.belowten' g_a214g
                      (g_a214g, gpart_a2159) = Genome.Split.split gpart_a2158
                      p_a214f = double g_a214e
                      (g_a214e, gpart_a2158) = Genome.Split.split gpart_a2157
                      p_a214d = double g_a214c
                      (g_a214c, gpart_a2157) = Genome.Split.split gpart_a2156
                      p_a214b = double g_a214a
                      (g_a214a, gpart_a2156) = Genome.Split.split gpart_a2155
                      p_a2149 = Functions.belowten' g_a2148
                      (g_a2148, gpart_a2155) = Genome.Split.split gpart_a2154
                      p_a2147 = double g_a2146
                      (g_a2146, gpart_a2154) = Genome.Split.split gpart_a2153
                      p_a2145
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2144
                      (g_a2144, gpart_a2153) = Genome.Split.split gpart_a2152
                      p_a2143
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2142
                      (g_a2142, gpart_a2152) = Genome.Split.split gpart_a2151
                      p_a2141 = double g_a2140
                      (g_a2140, gpart_a2151) = Genome.Split.split gpart_a2150
                      p_a213Z = Functions.belowten' g_a213Y
                      (g_a213Y, gpart_a2150) = Genome.Split.split gpart_a214Z
                      p_a213X = double g_a213W
                      (g_a213W, gpart_a214Z) = Genome.Split.split gpart_a214Y
                      p_a213V = Functions.belowten' g_a213U
                      (g_a213U, gpart_a214Y) = Genome.Split.split gpart_a214X
                      p_a213T = double g_a213S
                      (g_a213S, gpart_a214X) = Genome.Split.split gpart_a214W
                      p_a213R = double g_a213Q
                      (g_a213Q, gpart_a214W) = Genome.Split.split gpart_a214V
                      p_a213P = double g_a213O
                      (g_a213O, gpart_a214V) = Genome.Split.split gpart_a214U
                      p_a213N = Functions.belowten' g_a213M
                      (g_a213M, gpart_a214U) = Genome.Split.split gpart_a214T
                      p_a213L = double g_a213K
                      (g_a213K, gpart_a214T) = Genome.Split.split gpart_a214S
                      p_a213J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213I
                      (g_a213I, gpart_a214S) = Genome.Split.split gpart_a214R
                      p_a213H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213G
                      (g_a213G, gpart_a214R) = Genome.Split.split gpart_a214Q
                      p_a213F = Functions.belowten' g_a213E
                      (g_a213E, gpart_a214Q) = Genome.Split.split gpart_a214P
                      p_a213D = double g_a213C
                      (g_a213C, gpart_a214P) = Genome.Split.split gpart_a214O
                      p_a213B = double g_a213A
                      (g_a213A, gpart_a214O) = Genome.Split.split gpart_a214N
                      p_a213z = double g_a213y
                      (g_a213y, gpart_a214N) = Genome.Split.split gpart_a214M
                      p_a213x = double g_a213w
                      (g_a213w, gpart_a214M) = Genome.Split.split gpart_a214L
                      p_a213v = double g_a213u
                      (g_a213u, gpart_a214L) = Genome.Split.split gpart_a214K
                      p_a213t = double g_a213s
                      (g_a213s, gpart_a214K) = Genome.Split.split genome_a214I
                    in  \ x_a215n
                          -> let
                               c_PTB_a215s
                                 = ((Data.Fixed.Vector.toVector x_a215n) Data.Vector.Unboxed.! 0)
                               c_MiRs_a215q
                                 = ((Data.Fixed.Vector.toVector x_a215n) Data.Vector.Unboxed.! 2)
                               c_NPTB_a215o
                                 = ((Data.Fixed.Vector.toVector x_a215n) Data.Vector.Unboxed.! 1)
                               c_RESTc_a215x
                                 = ((Data.Fixed.Vector.toVector x_a215n) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a215H
                                 = ((Data.Fixed.Vector.toVector x_a215n) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a213B
                                     * ((p_a213P + ((c_NPTB_a215o / p_a213D) ** p_a213F))
                                        / (((1 + p_a213P) + ((c_NPTB_a215o / p_a213D) ** p_a213F))
                                           + ((c_MiRs_a215q / p_a213L) ** p_a213N))))
                                    + (negate (p_a214z * c_PTB_a215s))),
                                   ((p_a213R
                                     / (1
                                        + (((c_MiRs_a215q / p_a213T) ** p_a213V)
                                           + ((c_PTB_a215s / p_a213X) ** p_a213Z))))
                                    + (negate (p_a214B * c_NPTB_a215o))),
                                   ((p_a2141
                                     * (p_a214b
                                        / ((1 + p_a214b) + ((c_RESTc_a215x / p_a2147) ** p_a2149))))
                                    + (negate (p_a214D * c_MiRs_a215q))),
                                   ((p_a214d
                                     * ((p_a214r + ((c_PTB_a215s / p_a214f) ** p_a214h))
                                        / (((1 + p_a214r) + ((c_PTB_a215s / p_a214f) ** p_a214h))
                                           + (((p_a213t / p_a214j) ** p_a214l)
                                              + ((c_MiRs_a215q / p_a214n) ** p_a214p)))))
                                    + (negate (p_a214F * c_RESTc_a215x))),
                                   ((p_a214t / (1 + ((c_RESTc_a215x / p_a214v) ** p_a214x)))
                                    + (negate (p_a214H * c_EndoNeuroTFs_a215H)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490507",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490509",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490521",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490523",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490531",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490533",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490543",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490545",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490559",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490561",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a214I
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a216k
                            p_a214H = double g_a214G
                            (g_a214G, gpart_a216k) = Genome.Split.split gpart_a216j
                            p_a214F = double g_a214E
                            (g_a214E, gpart_a216j) = Genome.Split.split gpart_a216i
                            p_a214D = double g_a214C
                            (g_a214C, gpart_a216i) = Genome.Split.split gpart_a216h
                            p_a214B = double g_a214A
                            (g_a214A, gpart_a216h) = Genome.Split.split gpart_a216g
                            p_a214z = double g_a214y
                            (g_a214y, gpart_a216g) = Genome.Split.split gpart_a216f
                            p_a214x = Functions.belowten' g_a214w
                            (g_a214w, gpart_a216f) = Genome.Split.split gpart_a216e
                            p_a214v = double g_a214u
                            (g_a214u, gpart_a216e) = Genome.Split.split gpart_a216d
                            p_a214t = double g_a214s
                            (g_a214s, gpart_a216d) = Genome.Split.split gpart_a216c
                            p_a214r = double g_a214q
                            (g_a214q, gpart_a216c) = Genome.Split.split gpart_a216b
                            p_a214p = Functions.belowten' g_a214o
                            (g_a214o, gpart_a216b) = Genome.Split.split gpart_a216a
                            p_a214n = double g_a214m
                            (g_a214m, gpart_a216a) = Genome.Split.split gpart_a2169
                            p_a214l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214k
                            (g_a214k, gpart_a2169) = Genome.Split.split gpart_a2168
                            p_a214j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a214i
                            (g_a214i, gpart_a2168) = Genome.Split.split gpart_a2167
                            p_a214h = Functions.belowten' g_a214g
                            (g_a214g, gpart_a2167) = Genome.Split.split gpart_a2166
                            p_a214f = double g_a214e
                            (g_a214e, gpart_a2166) = Genome.Split.split gpart_a2165
                            p_a214d = double g_a214c
                            (g_a214c, gpart_a2165) = Genome.Split.split gpart_a2164
                            p_a214b = double g_a214a
                            (g_a214a, gpart_a2164) = Genome.Split.split gpart_a2163
                            p_a2149 = Functions.belowten' g_a2148
                            (g_a2148, gpart_a2163) = Genome.Split.split gpart_a2162
                            p_a2147 = double g_a2146
                            (g_a2146, gpart_a2162) = Genome.Split.split gpart_a2161
                            p_a2145
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2144
                            (g_a2144, gpart_a2161) = Genome.Split.split gpart_a2160
                            p_a2143
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2142
                            (g_a2142, gpart_a2160) = Genome.Split.split gpart_a215Z
                            p_a2141 = double g_a2140
                            (g_a2140, gpart_a215Z) = Genome.Split.split gpart_a215Y
                            p_a213Z = Functions.belowten' g_a213Y
                            (g_a213Y, gpart_a215Y) = Genome.Split.split gpart_a215X
                            p_a213X = double g_a213W
                            (g_a213W, gpart_a215X) = Genome.Split.split gpart_a215W
                            p_a213V = Functions.belowten' g_a213U
                            (g_a213U, gpart_a215W) = Genome.Split.split gpart_a215V
                            p_a213T = double g_a213S
                            (g_a213S, gpart_a215V) = Genome.Split.split gpart_a215U
                            p_a213R = double g_a213Q
                            (g_a213Q, gpart_a215U) = Genome.Split.split gpart_a215T
                            p_a213P = double g_a213O
                            (g_a213O, gpart_a215T) = Genome.Split.split gpart_a215S
                            p_a213N = Functions.belowten' g_a213M
                            (g_a213M, gpart_a215S) = Genome.Split.split gpart_a215R
                            p_a213L = double g_a213K
                            (g_a213K, gpart_a215R) = Genome.Split.split gpart_a215Q
                            p_a213J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213I
                            (g_a213I, gpart_a215Q) = Genome.Split.split gpart_a215P
                            p_a213H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a213G
                            (g_a213G, gpart_a215P) = Genome.Split.split gpart_a215O
                            p_a213F = Functions.belowten' g_a213E
                            (g_a213E, gpart_a215O) = Genome.Split.split gpart_a215N
                            p_a213D = double g_a213C
                            (g_a213C, gpart_a215N) = Genome.Split.split gpart_a215M
                            p_a213B = double g_a213A
                            (g_a213A, gpart_a215M) = Genome.Split.split gpart_a215L
                            p_a213z = double g_a213y
                            (g_a213y, gpart_a215L) = Genome.Split.split gpart_a215K
                            p_a213x = double g_a213w
                            (g_a213w, gpart_a215K) = Genome.Split.split gpart_a215J
                            p_a213v = double g_a213u
                            (g_a213u, gpart_a215J) = Genome.Split.split gpart_a215I
                            p_a213t = double g_a213s
                            (g_a213s, gpart_a215I) = Genome.Split.split genome_a214I
                          in
                            \ desc_a214J
                              -> case desc_a214J of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213t)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213v)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213x)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213z)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213B)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213D)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213F)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213H)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213J)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213L)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213N)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213P)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213R)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213T)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213V)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213X)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a213Z)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2141)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2143)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2145)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2147)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2149)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214b)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214d)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214f)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214h)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214j)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214l)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214n)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214p)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214r)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214t)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214v)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214x)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214z)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214B)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214D)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214F)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a214H)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a218K
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a219o
                      p_a218J = double g_a218I
                      (g_a218I, gpart_a219o) = Genome.Split.split gpart_a219n
                      p_a218H = double g_a218G
                      (g_a218G, gpart_a219n) = Genome.Split.split gpart_a219m
                      p_a218F = double g_a218E
                      (g_a218E, gpart_a219m) = Genome.Split.split gpart_a219l
                      p_a218D = double g_a218C
                      (g_a218C, gpart_a219l) = Genome.Split.split gpart_a219k
                      p_a218B = double g_a218A
                      (g_a218A, gpart_a219k) = Genome.Split.split gpart_a219j
                      p_a218z = Functions.belowten' g_a218y
                      (g_a218y, gpart_a219j) = Genome.Split.split gpart_a219i
                      p_a218x = double g_a218w
                      (g_a218w, gpart_a219i) = Genome.Split.split gpart_a219h
                      p_a218v = double g_a218u
                      (g_a218u, gpart_a219h) = Genome.Split.split gpart_a219g
                      p_a218t = double g_a218s
                      (g_a218s, gpart_a219g) = Genome.Split.split gpart_a219f
                      p_a218r = Functions.belowten' g_a218q
                      (g_a218q, gpart_a219f) = Genome.Split.split gpart_a219e
                      p_a218p = double g_a218o
                      (g_a218o, gpart_a219e) = Genome.Split.split gpart_a219d
                      p_a218n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218m
                      (g_a218m, gpart_a219d) = Genome.Split.split gpart_a219c
                      p_a218l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218k
                      (g_a218k, gpart_a219c) = Genome.Split.split gpart_a219b
                      p_a218j = Functions.belowten' g_a218i
                      (g_a218i, gpart_a219b) = Genome.Split.split gpart_a219a
                      p_a218h = double g_a218g
                      (g_a218g, gpart_a219a) = Genome.Split.split gpart_a2199
                      p_a218f = double g_a218e
                      (g_a218e, gpart_a2199) = Genome.Split.split gpart_a2198
                      p_a218d = double g_a218c
                      (g_a218c, gpart_a2198) = Genome.Split.split gpart_a2197
                      p_a218b = Functions.belowten' g_a218a
                      (g_a218a, gpart_a2197) = Genome.Split.split gpart_a2196
                      p_a2189 = double g_a2188
                      (g_a2188, gpart_a2196) = Genome.Split.split gpart_a2195
                      p_a2187
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2186
                      (g_a2186, gpart_a2195) = Genome.Split.split gpart_a2194
                      p_a2185
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2184
                      (g_a2184, gpart_a2194) = Genome.Split.split gpart_a2193
                      p_a2183 = double g_a2182
                      (g_a2182, gpart_a2193) = Genome.Split.split gpart_a2192
                      p_a2181 = Functions.belowten' g_a2180
                      (g_a2180, gpart_a2192) = Genome.Split.split gpart_a2191
                      p_a217Z = double g_a217Y
                      (g_a217Y, gpart_a2191) = Genome.Split.split gpart_a2190
                      p_a217X = Functions.belowten' g_a217W
                      (g_a217W, gpart_a2190) = Genome.Split.split gpart_a218Z
                      p_a217V = double g_a217U
                      (g_a217U, gpart_a218Z) = Genome.Split.split gpart_a218Y
                      p_a217T = double g_a217S
                      (g_a217S, gpart_a218Y) = Genome.Split.split gpart_a218X
                      p_a217R = double g_a217Q
                      (g_a217Q, gpart_a218X) = Genome.Split.split gpart_a218W
                      p_a217P = Functions.belowten' g_a217O
                      (g_a217O, gpart_a218W) = Genome.Split.split gpart_a218V
                      p_a217N = double g_a217M
                      (g_a217M, gpart_a218V) = Genome.Split.split gpart_a218U
                      p_a217L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217K
                      (g_a217K, gpart_a218U) = Genome.Split.split gpart_a218T
                      p_a217J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217I
                      (g_a217I, gpart_a218T) = Genome.Split.split gpart_a218S
                      p_a217H = Functions.belowten' g_a217G
                      (g_a217G, gpart_a218S) = Genome.Split.split gpart_a218R
                      p_a217F = double g_a217E
                      (g_a217E, gpart_a218R) = Genome.Split.split gpart_a218Q
                      p_a217D = double g_a217C
                      (g_a217C, gpart_a218Q) = Genome.Split.split gpart_a218P
                      p_a217B = double g_a217A
                      (g_a217A, gpart_a218P) = Genome.Split.split gpart_a218O
                      p_a217z = double g_a217y
                      (g_a217y, gpart_a218O) = Genome.Split.split gpart_a218N
                      p_a217x = double g_a217w
                      (g_a217w, gpart_a218N) = Genome.Split.split gpart_a218M
                      p_a217v = double g_a217u
                      (g_a217u, gpart_a218M) = Genome.Split.split genome_a218K
                    in  \ x_a219p
                          -> let
                               c_PTB_a219u
                                 = ((Data.Fixed.Vector.toVector x_a219p) Data.Vector.Unboxed.! 0)
                               c_MiRs_a219s
                                 = ((Data.Fixed.Vector.toVector x_a219p) Data.Vector.Unboxed.! 2)
                               c_NPTB_a219q
                                 = ((Data.Fixed.Vector.toVector x_a219p) Data.Vector.Unboxed.! 1)
                               c_RESTc_a219z
                                 = ((Data.Fixed.Vector.toVector x_a219p) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a219J
                                 = ((Data.Fixed.Vector.toVector x_a219p) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a217D
                                     * ((p_a217R + ((c_NPTB_a219q / p_a217F) ** p_a217H))
                                        / (((1 + p_a217R) + ((c_NPTB_a219q / p_a217F) ** p_a217H))
                                           + ((c_MiRs_a219s / p_a217N) ** p_a217P))))
                                    + (negate (p_a218B * c_PTB_a219u))),
                                   ((p_a217T
                                     / (1
                                        + (((c_MiRs_a219s / p_a217V) ** p_a217X)
                                           + ((c_PTB_a219u / p_a217Z) ** p_a2181))))
                                    + (negate (p_a218D * c_NPTB_a219q))),
                                   ((p_a2183
                                     * (p_a218d
                                        / ((1 + p_a218d) + ((c_RESTc_a219z / p_a2189) ** p_a218b))))
                                    + (negate (p_a218F * c_MiRs_a219s))),
                                   ((p_a218f
                                     * ((p_a218t + ((c_PTB_a219u / p_a218h) ** p_a218j))
                                        / (((1 + p_a218t) + ((c_PTB_a219u / p_a218h) ** p_a218j))
                                           + ((c_MiRs_a219s / p_a218p) ** p_a218r))))
                                    + (negate (p_a218H * c_RESTc_a219z))),
                                   ((p_a218v / (1 + ((c_RESTc_a219z / p_a218x) ** p_a218z)))
                                    + (negate (p_a218J * c_EndoNeuroTFs_a219J)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490771",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490773",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490785",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490793",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490795",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490809",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490811",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a218K
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21am
                            p_a218J = double g_a218I
                            (g_a218I, gpart_a21am) = Genome.Split.split gpart_a21al
                            p_a218H = double g_a218G
                            (g_a218G, gpart_a21al) = Genome.Split.split gpart_a21ak
                            p_a218F = double g_a218E
                            (g_a218E, gpart_a21ak) = Genome.Split.split gpart_a21aj
                            p_a218D = double g_a218C
                            (g_a218C, gpart_a21aj) = Genome.Split.split gpart_a21ai
                            p_a218B = double g_a218A
                            (g_a218A, gpart_a21ai) = Genome.Split.split gpart_a21ah
                            p_a218z = Functions.belowten' g_a218y
                            (g_a218y, gpart_a21ah) = Genome.Split.split gpart_a21ag
                            p_a218x = double g_a218w
                            (g_a218w, gpart_a21ag) = Genome.Split.split gpart_a21af
                            p_a218v = double g_a218u
                            (g_a218u, gpart_a21af) = Genome.Split.split gpart_a21ae
                            p_a218t = double g_a218s
                            (g_a218s, gpart_a21ae) = Genome.Split.split gpart_a21ad
                            p_a218r = Functions.belowten' g_a218q
                            (g_a218q, gpart_a21ad) = Genome.Split.split gpart_a21ac
                            p_a218p = double g_a218o
                            (g_a218o, gpart_a21ac) = Genome.Split.split gpart_a21ab
                            p_a218n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218m
                            (g_a218m, gpart_a21ab) = Genome.Split.split gpart_a21aa
                            p_a218l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a218k
                            (g_a218k, gpart_a21aa) = Genome.Split.split gpart_a21a9
                            p_a218j = Functions.belowten' g_a218i
                            (g_a218i, gpart_a21a9) = Genome.Split.split gpart_a21a8
                            p_a218h = double g_a218g
                            (g_a218g, gpart_a21a8) = Genome.Split.split gpart_a21a7
                            p_a218f = double g_a218e
                            (g_a218e, gpart_a21a7) = Genome.Split.split gpart_a21a6
                            p_a218d = double g_a218c
                            (g_a218c, gpart_a21a6) = Genome.Split.split gpart_a21a5
                            p_a218b = Functions.belowten' g_a218a
                            (g_a218a, gpart_a21a5) = Genome.Split.split gpart_a21a4
                            p_a2189 = double g_a2188
                            (g_a2188, gpart_a21a4) = Genome.Split.split gpart_a21a3
                            p_a2187
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2186
                            (g_a2186, gpart_a21a3) = Genome.Split.split gpart_a21a2
                            p_a2185
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2184
                            (g_a2184, gpart_a21a2) = Genome.Split.split gpart_a21a1
                            p_a2183 = double g_a2182
                            (g_a2182, gpart_a21a1) = Genome.Split.split gpart_a21a0
                            p_a2181 = Functions.belowten' g_a2180
                            (g_a2180, gpart_a21a0) = Genome.Split.split gpart_a219Z
                            p_a217Z = double g_a217Y
                            (g_a217Y, gpart_a219Z) = Genome.Split.split gpart_a219Y
                            p_a217X = Functions.belowten' g_a217W
                            (g_a217W, gpart_a219Y) = Genome.Split.split gpart_a219X
                            p_a217V = double g_a217U
                            (g_a217U, gpart_a219X) = Genome.Split.split gpart_a219W
                            p_a217T = double g_a217S
                            (g_a217S, gpart_a219W) = Genome.Split.split gpart_a219V
                            p_a217R = double g_a217Q
                            (g_a217Q, gpart_a219V) = Genome.Split.split gpart_a219U
                            p_a217P = Functions.belowten' g_a217O
                            (g_a217O, gpart_a219U) = Genome.Split.split gpart_a219T
                            p_a217N = double g_a217M
                            (g_a217M, gpart_a219T) = Genome.Split.split gpart_a219S
                            p_a217L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217K
                            (g_a217K, gpart_a219S) = Genome.Split.split gpart_a219R
                            p_a217J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217I
                            (g_a217I, gpart_a219R) = Genome.Split.split gpart_a219Q
                            p_a217H = Functions.belowten' g_a217G
                            (g_a217G, gpart_a219Q) = Genome.Split.split gpart_a219P
                            p_a217F = double g_a217E
                            (g_a217E, gpart_a219P) = Genome.Split.split gpart_a219O
                            p_a217D = double g_a217C
                            (g_a217C, gpart_a219O) = Genome.Split.split gpart_a219N
                            p_a217B = double g_a217A
                            (g_a217A, gpart_a219N) = Genome.Split.split gpart_a219M
                            p_a217z = double g_a217y
                            (g_a217y, gpart_a219M) = Genome.Split.split gpart_a219L
                            p_a217x = double g_a217w
                            (g_a217w, gpart_a219L) = Genome.Split.split gpart_a219K
                            p_a217v = double g_a217u
                            (g_a217u, gpart_a219K) = Genome.Split.split genome_a218K
                          in
                            \ desc_a218L
                              -> case desc_a218L of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217v)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217x)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217z)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217B)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217D)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217F)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217H)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217J)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217L)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217N)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217P)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217R)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217T)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217V)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217X)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217Z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2181)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2183)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2185)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2187)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2189)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218b)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218d)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218f)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218h)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218j)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218l)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218n)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218p)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218r)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218t)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218v)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218x)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218z)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218B)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218D)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218F)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218H)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218J)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a21cM
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21dq
                      p_a21cL = double g_a21cK
                      (g_a21cK, gpart_a21dq) = Genome.Split.split gpart_a21dp
                      p_a21cJ = double g_a21cI
                      (g_a21cI, gpart_a21dp) = Genome.Split.split gpart_a21do
                      p_a21cH = double g_a21cG
                      (g_a21cG, gpart_a21do) = Genome.Split.split gpart_a21dn
                      p_a21cF = double g_a21cE
                      (g_a21cE, gpart_a21dn) = Genome.Split.split gpart_a21dm
                      p_a21cD = double g_a21cC
                      (g_a21cC, gpart_a21dm) = Genome.Split.split gpart_a21dl
                      p_a21cB = Functions.belowten' g_a21cA
                      (g_a21cA, gpart_a21dl) = Genome.Split.split gpart_a21dk
                      p_a21cz = double g_a21cy
                      (g_a21cy, gpart_a21dk) = Genome.Split.split gpart_a21dj
                      p_a21cx = double g_a21cw
                      (g_a21cw, gpart_a21dj) = Genome.Split.split gpart_a21di
                      p_a21cv = double g_a21cu
                      (g_a21cu, gpart_a21di) = Genome.Split.split gpart_a21dh
                      p_a21ct = Functions.belowten' g_a21cs
                      (g_a21cs, gpart_a21dh) = Genome.Split.split gpart_a21dg
                      p_a21cr = double g_a21cq
                      (g_a21cq, gpart_a21dg) = Genome.Split.split gpart_a21df
                      p_a21cp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21co
                      (g_a21co, gpart_a21df) = Genome.Split.split gpart_a21de
                      p_a21cn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21cm
                      (g_a21cm, gpart_a21de) = Genome.Split.split gpart_a21dd
                      p_a21cl = Functions.belowten' g_a21ck
                      (g_a21ck, gpart_a21dd) = Genome.Split.split gpart_a21dc
                      p_a21cj = double g_a21ci
                      (g_a21ci, gpart_a21dc) = Genome.Split.split gpart_a21db
                      p_a21ch = double g_a21cg
                      (g_a21cg, gpart_a21db) = Genome.Split.split gpart_a21da
                      p_a21cf = double g_a21ce
                      (g_a21ce, gpart_a21da) = Genome.Split.split gpart_a21d9
                      p_a21cd = Functions.belowten' g_a21cc
                      (g_a21cc, gpart_a21d9) = Genome.Split.split gpart_a21d8
                      p_a21cb = double g_a21ca
                      (g_a21ca, gpart_a21d8) = Genome.Split.split gpart_a21d7
                      p_a21c9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c8
                      (g_a21c8, gpart_a21d7) = Genome.Split.split gpart_a21d6
                      p_a21c7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c6
                      (g_a21c6, gpart_a21d6) = Genome.Split.split gpart_a21d5
                      p_a21c5 = double g_a21c4
                      (g_a21c4, gpart_a21d5) = Genome.Split.split gpart_a21d4
                      p_a21c3 = Functions.belowten' g_a21c2
                      (g_a21c2, gpart_a21d4) = Genome.Split.split gpart_a21d3
                      p_a21c1 = double g_a21c0
                      (g_a21c0, gpart_a21d3) = Genome.Split.split gpart_a21d2
                      p_a21bZ = Functions.belowten' g_a21bY
                      (g_a21bY, gpart_a21d2) = Genome.Split.split gpart_a21d1
                      p_a21bX = double g_a21bW
                      (g_a21bW, gpart_a21d1) = Genome.Split.split gpart_a21d0
                      p_a21bV = double g_a21bU
                      (g_a21bU, gpart_a21d0) = Genome.Split.split gpart_a21cZ
                      p_a21bT = double g_a21bS
                      (g_a21bS, gpart_a21cZ) = Genome.Split.split gpart_a21cY
                      p_a21bR = Functions.belowten' g_a21bQ
                      (g_a21bQ, gpart_a21cY) = Genome.Split.split gpart_a21cX
                      p_a21bP = double g_a21bO
                      (g_a21bO, gpart_a21cX) = Genome.Split.split gpart_a21cW
                      p_a21bN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bM
                      (g_a21bM, gpart_a21cW) = Genome.Split.split gpart_a21cV
                      p_a21bL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bK
                      (g_a21bK, gpart_a21cV) = Genome.Split.split gpart_a21cU
                      p_a21bJ = Functions.belowten' g_a21bI
                      (g_a21bI, gpart_a21cU) = Genome.Split.split gpart_a21cT
                      p_a21bH = double g_a21bG
                      (g_a21bG, gpart_a21cT) = Genome.Split.split gpart_a21cS
                      p_a21bF = double g_a21bE
                      (g_a21bE, gpart_a21cS) = Genome.Split.split gpart_a21cR
                      p_a21bD = double g_a21bC
                      (g_a21bC, gpart_a21cR) = Genome.Split.split gpart_a21cQ
                      p_a21bB = double g_a21bA
                      (g_a21bA, gpart_a21cQ) = Genome.Split.split gpart_a21cP
                      p_a21bz = double g_a21by
                      (g_a21by, gpart_a21cP) = Genome.Split.split gpart_a21cO
                      p_a21bx = double g_a21bw
                      (g_a21bw, gpart_a21cO) = Genome.Split.split genome_a21cM
                    in  \ x_a21dr
                          -> let
                               c_PTB_a21dw
                                 = ((Data.Fixed.Vector.toVector x_a21dr) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21du
                                 = ((Data.Fixed.Vector.toVector x_a21dr) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21ds
                                 = ((Data.Fixed.Vector.toVector x_a21dr) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21dB
                                 = ((Data.Fixed.Vector.toVector x_a21dr) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21dL
                                 = ((Data.Fixed.Vector.toVector x_a21dr) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21bF
                                     * ((p_a21bT + ((c_NPTB_a21ds / p_a21bH) ** p_a21bJ))
                                        / (((1 + p_a21bT) + ((c_NPTB_a21ds / p_a21bH) ** p_a21bJ))
                                           + (((p_a21bx / p_a21bL) ** p_a21bN)
                                              + ((c_MiRs_a21du / p_a21bP) ** p_a21bR)))))
                                    + (negate (p_a21cD * c_PTB_a21dw))),
                                   ((p_a21bV
                                     / (1
                                        + (((c_MiRs_a21du / p_a21bX) ** p_a21bZ)
                                           + ((c_PTB_a21dw / p_a21c1) ** p_a21c3))))
                                    + (negate (p_a21cF * c_NPTB_a21ds))),
                                   ((p_a21c5
                                     * (p_a21cf
                                        / ((1 + p_a21cf) + ((c_RESTc_a21dB / p_a21cb) ** p_a21cd))))
                                    + (negate (p_a21cH * c_MiRs_a21du))),
                                   ((p_a21ch
                                     * ((p_a21cv + ((c_PTB_a21dw / p_a21cj) ** p_a21cl))
                                        / (((1 + p_a21cv) + ((c_PTB_a21dw / p_a21cj) ** p_a21cl))
                                           + ((c_MiRs_a21du / p_a21cr) ** p_a21ct))))
                                    + (negate (p_a21cJ * c_RESTc_a21dB))),
                                   ((p_a21cx / (1 + ((c_RESTc_a21dB / p_a21cz) ** p_a21cB)))
                                    + (negate (p_a21cL * c_EndoNeuroTFs_a21dL)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491006",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491007",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491008",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491009",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491010",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491011",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491012",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491013",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491014",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491015",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491016",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491017",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491018",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491019",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491020",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491021",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491022",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491023",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491024",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491025",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491026",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491027",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491028",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491029",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491030",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491031",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491032",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491033",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491034",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491035",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491036",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491037",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491038",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491039",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491040",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491041",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491042",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491043",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491044",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491045",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491046",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491047",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491048",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491049",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491050",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491051",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491052",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491053",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491054",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491055",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491059",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491061",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491067",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491069",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21cM
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21eo
                            p_a21cL = double g_a21cK
                            (g_a21cK, gpart_a21eo) = Genome.Split.split gpart_a21en
                            p_a21cJ = double g_a21cI
                            (g_a21cI, gpart_a21en) = Genome.Split.split gpart_a21em
                            p_a21cH = double g_a21cG
                            (g_a21cG, gpart_a21em) = Genome.Split.split gpart_a21el
                            p_a21cF = double g_a21cE
                            (g_a21cE, gpart_a21el) = Genome.Split.split gpart_a21ek
                            p_a21cD = double g_a21cC
                            (g_a21cC, gpart_a21ek) = Genome.Split.split gpart_a21ej
                            p_a21cB = Functions.belowten' g_a21cA
                            (g_a21cA, gpart_a21ej) = Genome.Split.split gpart_a21ei
                            p_a21cz = double g_a21cy
                            (g_a21cy, gpart_a21ei) = Genome.Split.split gpart_a21eh
                            p_a21cx = double g_a21cw
                            (g_a21cw, gpart_a21eh) = Genome.Split.split gpart_a21eg
                            p_a21cv = double g_a21cu
                            (g_a21cu, gpart_a21eg) = Genome.Split.split gpart_a21ef
                            p_a21ct = Functions.belowten' g_a21cs
                            (g_a21cs, gpart_a21ef) = Genome.Split.split gpart_a21ee
                            p_a21cr = double g_a21cq
                            (g_a21cq, gpart_a21ee) = Genome.Split.split gpart_a21ed
                            p_a21cp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21co
                            (g_a21co, gpart_a21ed) = Genome.Split.split gpart_a21ec
                            p_a21cn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21cm
                            (g_a21cm, gpart_a21ec) = Genome.Split.split gpart_a21eb
                            p_a21cl = Functions.belowten' g_a21ck
                            (g_a21ck, gpart_a21eb) = Genome.Split.split gpart_a21ea
                            p_a21cj = double g_a21ci
                            (g_a21ci, gpart_a21ea) = Genome.Split.split gpart_a21e9
                            p_a21ch = double g_a21cg
                            (g_a21cg, gpart_a21e9) = Genome.Split.split gpart_a21e8
                            p_a21cf = double g_a21ce
                            (g_a21ce, gpart_a21e8) = Genome.Split.split gpart_a21e7
                            p_a21cd = Functions.belowten' g_a21cc
                            (g_a21cc, gpart_a21e7) = Genome.Split.split gpart_a21e6
                            p_a21cb = double g_a21ca
                            (g_a21ca, gpart_a21e6) = Genome.Split.split gpart_a21e5
                            p_a21c9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c8
                            (g_a21c8, gpart_a21e5) = Genome.Split.split gpart_a21e4
                            p_a21c7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c6
                            (g_a21c6, gpart_a21e4) = Genome.Split.split gpart_a21e3
                            p_a21c5 = double g_a21c4
                            (g_a21c4, gpart_a21e3) = Genome.Split.split gpart_a21e2
                            p_a21c3 = Functions.belowten' g_a21c2
                            (g_a21c2, gpart_a21e2) = Genome.Split.split gpart_a21e1
                            p_a21c1 = double g_a21c0
                            (g_a21c0, gpart_a21e1) = Genome.Split.split gpart_a21e0
                            p_a21bZ = Functions.belowten' g_a21bY
                            (g_a21bY, gpart_a21e0) = Genome.Split.split gpart_a21dZ
                            p_a21bX = double g_a21bW
                            (g_a21bW, gpart_a21dZ) = Genome.Split.split gpart_a21dY
                            p_a21bV = double g_a21bU
                            (g_a21bU, gpart_a21dY) = Genome.Split.split gpart_a21dX
                            p_a21bT = double g_a21bS
                            (g_a21bS, gpart_a21dX) = Genome.Split.split gpart_a21dW
                            p_a21bR = Functions.belowten' g_a21bQ
                            (g_a21bQ, gpart_a21dW) = Genome.Split.split gpart_a21dV
                            p_a21bP = double g_a21bO
                            (g_a21bO, gpart_a21dV) = Genome.Split.split gpart_a21dU
                            p_a21bN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bM
                            (g_a21bM, gpart_a21dU) = Genome.Split.split gpart_a21dT
                            p_a21bL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bK
                            (g_a21bK, gpart_a21dT) = Genome.Split.split gpart_a21dS
                            p_a21bJ = Functions.belowten' g_a21bI
                            (g_a21bI, gpart_a21dS) = Genome.Split.split gpart_a21dR
                            p_a21bH = double g_a21bG
                            (g_a21bG, gpart_a21dR) = Genome.Split.split gpart_a21dQ
                            p_a21bF = double g_a21bE
                            (g_a21bE, gpart_a21dQ) = Genome.Split.split gpart_a21dP
                            p_a21bD = double g_a21bC
                            (g_a21bC, gpart_a21dP) = Genome.Split.split gpart_a21dO
                            p_a21bB = double g_a21bA
                            (g_a21bA, gpart_a21dO) = Genome.Split.split gpart_a21dN
                            p_a21bz = double g_a21by
                            (g_a21by, gpart_a21dN) = Genome.Split.split gpart_a21dM
                            p_a21bx = double g_a21bw
                            (g_a21bw, gpart_a21dM) = Genome.Split.split genome_a21cM
                          in
                            \ desc_a21cN
                              -> case desc_a21cN of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bx)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bz)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bB)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bD)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bF)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bH)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bJ)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bL)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bN)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bP)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bR)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bT)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bV)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bX)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bZ)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c1)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c3)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c5)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c7)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c9)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cb)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cd)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cf)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ch)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cj)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cl)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cn)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cp)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cr)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ct)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cv)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cx)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cz)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cB)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cD)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cF)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cH)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cJ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cL)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUK
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVo
                      p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                      (g_asUI, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                      (g_asUG, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                      (g_asUE, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                      (g_asUA, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUz = Functions.belowten' g_asUy
                      (g_asUy, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asUr = Functions.belowten' g_asUq
                      (g_asUq, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asUl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                      (g_asUk, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asUj = Functions.belowten' g_asUi
                      (g_asUi, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asV8) = Genome.Split.split gpart_asV7
                      p_asUb = Functions.belowten' g_asUa
                      (g_asUa, gpart_asV7) = Genome.Split.split gpart_asV6
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asV6) = Genome.Split.split gpart_asV5
                      p_asU7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU6
                      (g_asU6, gpart_asV5) = Genome.Split.split gpart_asV4
                      p_asU5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                      (g_asU4, gpart_asV4) = Genome.Split.split gpart_asV3
                      p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                      (g_asU2, gpart_asV3) = Genome.Split.split gpart_asV2
                      p_asU1 = Functions.belowten' g_asU0
                      (g_asU0, gpart_asV2) = Genome.Split.split gpart_asV1
                      p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                      (g_asTY, gpart_asV1) = Genome.Split.split gpart_asV0
                      p_asTX = Functions.belowten' g_asTW
                      (g_asTW, gpart_asV0) = Genome.Split.split gpart_asUZ
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asUZ) = Genome.Split.split gpart_asUY
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asUY) = Genome.Split.split gpart_asUX
                      p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                      (g_asTQ, gpart_asUX) = Genome.Split.split gpart_asUW
                      p_asTP = Functions.belowten' g_asTO
                      (g_asTO, gpart_asUW) = Genome.Split.split gpart_asUV
                      p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                      (g_asTM, gpart_asUV) = Genome.Split.split gpart_asUU
                      p_asTL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                      (g_asTK, gpart_asUU) = Genome.Split.split gpart_asUT
                      p_asTJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTI
                      (g_asTI, gpart_asUT) = Genome.Split.split gpart_asUS
                      p_asTH = Functions.belowten' g_asTG
                      (g_asTG, gpart_asUS) = Genome.Split.split gpart_asUR
                      p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                      (g_asTE, gpart_asUR) = Genome.Split.split gpart_asUQ
                      p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                      (g_asTC, gpart_asUQ) = Genome.Split.split gpart_asUP
                      p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                      (g_asTA, gpart_asUP) = Genome.Split.split gpart_asUO
                      p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                      (g_asTy, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                      (g_asTw, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                      (g_asTu, gpart_asUM) = Genome.Split.split genome_asUK
                    in
                      [Reaction
                         (\ x_asVp
                            -> let
                                 c_MiRs_asVs = ((toVector x_asVp) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVq = ((toVector x_asVp) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asTD
                                  * ((p_asTR + ((c_NPTB_asVq / p_asTF) ** p_asTH))
                                     / (((1 + p_asTR) + ((c_NPTB_asVq / p_asTF) ** p_asTH))
                                        + ((c_MiRs_asVs / p_asTN) ** p_asTP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVt
                            -> let
                                 c_MiRs_asVu = ((toVector x_asVt) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVv = ((toVector x_asVt) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTT
                                  / (1
                                     + (((c_MiRs_asVu / p_asTV) ** p_asTX)
                                        + ((c_PTB_asVv / p_asTZ) ** p_asU1)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVw
                            -> let c_RESTc_asVx = ((toVector x_asVw) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asU3
                                  * ((p_asUd + ((p_asTz / p_asU5) ** p_asU7))
                                     / (((1 + p_asUd) + ((p_asTz / p_asU5) ** p_asU7))
                                        + ((c_RESTc_asVx / p_asU9) ** p_asUb)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVy
                            -> let
                                 c_MiRs_asVB = ((toVector x_asVy) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVz = ((toVector x_asVy) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUf
                                  * ((p_asUt + ((c_PTB_asVz / p_asUh) ** p_asUj))
                                     / (((1 + p_asUt) + ((c_PTB_asVz / p_asUh) ** p_asUj))
                                        + (((p_asTv / p_asUl) ** p_asUn)
                                           + ((c_MiRs_asVB / p_asUp) ** p_asUr))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVC
                            -> let c_RESTc_asVD = ((toVector x_asVC) Data.Vector.Unboxed.! 3)
                               in (p_asUv / (1 + ((c_RESTc_asVD / p_asUx) ** p_asUz))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVE
                            -> let c_PTB_asVF = ((toVector x_asVE) Data.Vector.Unboxed.! 0)
                               in (p_asUB * c_PTB_asVF))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVG
                            -> let c_NPTB_asVH = ((toVector x_asVG) Data.Vector.Unboxed.! 1)
                               in (p_asUD * c_NPTB_asVH))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVI
                            -> let c_MiRs_asVJ = ((toVector x_asVI) Data.Vector.Unboxed.! 2)
                               in (p_asUF * c_MiRs_asVJ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVK
                            -> let c_RESTc_asVL = ((toVector x_asVK) Data.Vector.Unboxed.! 3)
                               in (p_asUH * c_RESTc_asVL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVM
                            -> let
                                 c_EndoNeuroTFs_asVN = ((toVector x_asVM) Data.Vector.Unboxed.! 4)
                               in (p_asUJ * c_EndoNeuroTFs_asVN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120879",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120881",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUK
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWv
                            p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                            (g_asUI, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                            (g_asUG, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                            (g_asUE, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                            (g_asUA, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asUz = Functions.belowten' g_asUy
                            (g_asUy, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asUr = Functions.belowten' g_asUq
                            (g_asUq, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asUl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                            (g_asUk, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asUj = Functions.belowten' g_asUi
                            (g_asUi, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asWg) = Genome.Split.split gpart_asWf
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWf) = Genome.Split.split gpart_asWe
                            p_asUb = Functions.belowten' g_asUa
                            (g_asUa, gpart_asWe) = Genome.Split.split gpart_asWd
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWd) = Genome.Split.split gpart_asWc
                            p_asU7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU6
                            (g_asU6, gpart_asWc) = Genome.Split.split gpart_asWb
                            p_asU5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                            (g_asU4, gpart_asWb) = Genome.Split.split gpart_asWa
                            p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                            (g_asU2, gpart_asWa) = Genome.Split.split gpart_asW9
                            p_asU1 = Functions.belowten' g_asU0
                            (g_asU0, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                            (g_asTY, gpart_asW8) = Genome.Split.split gpart_asW7
                            p_asTX = Functions.belowten' g_asTW
                            (g_asTW, gpart_asW7) = Genome.Split.split gpart_asW6
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asW6) = Genome.Split.split gpart_asW5
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asW5) = Genome.Split.split gpart_asW4
                            p_asTR = code-0.1.0.0:Genome.FixedList.Functions.double g_asTQ
                            (g_asTQ, gpart_asW4) = Genome.Split.split gpart_asW3
                            p_asTP = Functions.belowten' g_asTO
                            (g_asTO, gpart_asW3) = Genome.Split.split gpart_asW2
                            p_asTN = code-0.1.0.0:Genome.FixedList.Functions.double g_asTM
                            (g_asTM, gpart_asW2) = Genome.Split.split gpart_asW1
                            p_asTL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTK
                            (g_asTK, gpart_asW1) = Genome.Split.split gpart_asW0
                            p_asTJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTI
                            (g_asTI, gpart_asW0) = Genome.Split.split gpart_asVZ
                            p_asTH = Functions.belowten' g_asTG
                            (g_asTG, gpart_asVZ) = Genome.Split.split gpart_asVY
                            p_asTF = code-0.1.0.0:Genome.FixedList.Functions.double g_asTE
                            (g_asTE, gpart_asVY) = Genome.Split.split gpart_asVX
                            p_asTD = code-0.1.0.0:Genome.FixedList.Functions.double g_asTC
                            (g_asTC, gpart_asVX) = Genome.Split.split gpart_asVW
                            p_asTB = code-0.1.0.0:Genome.FixedList.Functions.double g_asTA
                            (g_asTA, gpart_asVW) = Genome.Split.split gpart_asVV
                            p_asTz = code-0.1.0.0:Genome.FixedList.Functions.double g_asTy
                            (g_asTy, gpart_asVV) = Genome.Split.split gpart_asVU
                            p_asTx = code-0.1.0.0:Genome.FixedList.Functions.double g_asTw
                            (g_asTw, gpart_asVU) = Genome.Split.split gpart_asVT
                            p_asTv = code-0.1.0.0:Genome.FixedList.Functions.double g_asTu
                            (g_asTu, gpart_asVT) = Genome.Split.split genome_asUK
                          in
                            \ desc_asUL
                              -> case desc_asUL of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTv)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTx)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTz)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTB)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTD)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTF)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTH)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTJ)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTL)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTN)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTP)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTR)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZ6
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asYh = Functions.belowten' g_asYg
                      (g_asYg, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                      (g_asYe, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asY9 = Functions.belowten' g_asY8
                      (g_asY8, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asY5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY4
                      (g_asY4, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asY3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY2
                      (g_asY2, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asY1 = Functions.belowten' g_asY0
                      (g_asY0, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                      (g_asXY, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asXV = code-0.1.0.0:Genome.FixedList.Functions.double g_asXU
                      (g_asXU, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asXT = Functions.belowten' g_asXS
                      (g_asXS, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                      (g_asXQ, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asXP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                      (g_asXO, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asXN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXM
                      (g_asXM, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXJ = Functions.belowten' g_asXI
                      (g_asXI, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXF = Functions.belowten' g_asXE
                      (g_asXE, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYG) = Genome.Split.split gpart_asYF
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYF) = Genome.Split.split gpart_asYE
                      p_asXx = Functions.belowten' g_asXw
                      (g_asXw, gpart_asYE) = Genome.Split.split gpart_asYD
                      p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                      (g_asXu, gpart_asYD) = Genome.Split.split gpart_asYC
                      p_asXt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                      (g_asXs, gpart_asYC) = Genome.Split.split gpart_asYB
                      p_asXr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                      (g_asXq, gpart_asYB) = Genome.Split.split gpart_asYA
                      p_asXp = Functions.belowten' g_asXo
                      (g_asXo, gpart_asYA) = Genome.Split.split gpart_asYz
                      p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                      (g_asXm, gpart_asYz) = Genome.Split.split gpart_asYy
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asYy) = Genome.Split.split gpart_asYx
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asYx) = Genome.Split.split gpart_asYw
                      p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                      (g_asXg, gpart_asYw) = Genome.Split.split gpart_asYv
                      p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                      (g_asXe, gpart_asYv) = Genome.Split.split gpart_asYu
                      p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                      (g_asXc, gpart_asYu) = Genome.Split.split genome_asYs
                    in
                      [Reaction
                         (\ x_asZ7
                            -> let
                                 c_MiRs_asZa = ((toVector x_asZ7) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZ8 = ((toVector x_asZ7) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asXl
                                  * ((p_asXz + ((c_NPTB_asZ8 / p_asXn) ** p_asXp))
                                     / (((1 + p_asXz) + ((c_NPTB_asZ8 / p_asXn) ** p_asXp))
                                        + ((c_MiRs_asZa / p_asXv) ** p_asXx)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZb
                            -> let
                                 c_MiRs_asZc = ((toVector x_asZb) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZd = ((toVector x_asZb) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXB
                                  / (1
                                     + (((c_MiRs_asZc / p_asXD) ** p_asXF)
                                        + ((c_PTB_asZd / p_asXH) ** p_asXJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZe
                            -> let c_RESTc_asZf = ((toVector x_asZe) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asXL
                                  * (p_asXV
                                     / ((1 + p_asXV) + ((c_RESTc_asZf / p_asXR) ** p_asXT)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZg
                            -> let
                                 c_MiRs_asZj = ((toVector x_asZg) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZh = ((toVector x_asZg) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXX
                                  * ((p_asYb + ((c_PTB_asZh / p_asXZ) ** p_asY1))
                                     / (((1 + p_asYb) + ((c_PTB_asZh / p_asXZ) ** p_asY1))
                                        + (((p_asXd / p_asY3) ** p_asY5)
                                           + ((c_MiRs_asZj / p_asY7) ** p_asY9))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZk
                            -> let c_RESTc_asZl = ((toVector x_asZk) Data.Vector.Unboxed.! 3)
                               in (p_asYd / (1 + ((c_RESTc_asZl / p_asYf) ** p_asYh))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZm
                            -> let c_PTB_asZn = ((toVector x_asZm) Data.Vector.Unboxed.! 0)
                               in (p_asYj * c_PTB_asZn))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZo
                            -> let c_NPTB_asZp = ((toVector x_asZo) Data.Vector.Unboxed.! 1)
                               in (p_asYl * c_NPTB_asZp))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZq
                            -> let c_MiRs_asZr = ((toVector x_asZq) Data.Vector.Unboxed.! 2)
                               in (p_asYn * c_MiRs_asZr))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZs
                            -> let c_RESTc_asZt = ((toVector x_asZs) Data.Vector.Unboxed.! 3)
                               in (p_asYp * c_RESTc_asZt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZu
                            -> let
                                 c_EndoNeuroTFs_asZv = ((toVector x_asZu) Data.Vector.Unboxed.! 4)
                               in (p_asYr * c_EndoNeuroTFs_asZv))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at08
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at08) = Genome.Split.split gpart_at07
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at07) = Genome.Split.split gpart_at06
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at06) = Genome.Split.split gpart_at05
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at05) = Genome.Split.split gpart_at04
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at04) = Genome.Split.split gpart_at03
                            p_asYh = Functions.belowten' g_asYg
                            (g_asYg, gpart_at03) = Genome.Split.split gpart_at02
                            p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                            (g_asYe, gpart_at02) = Genome.Split.split gpart_at01
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at01) = Genome.Split.split gpart_at00
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asY9 = Functions.belowten' g_asY8
                            (g_asY8, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asY5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY4
                            (g_asY4, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asY3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY2
                            (g_asY2, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asY1 = Functions.belowten' g_asY0
                            (g_asY0, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                            (g_asXY, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXV = code-0.1.0.0:Genome.FixedList.Functions.double g_asXU
                            (g_asXU, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXT = Functions.belowten' g_asXS
                            (g_asXS, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                            (g_asXQ, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXO
                            (g_asXO, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXM
                            (g_asXM, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXJ = Functions.belowten' g_asXI
                            (g_asXI, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXF = Functions.belowten' g_asXE
                            (g_asXE, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXx = Functions.belowten' g_asXw
                            (g_asXw, gpart_asZG) = Genome.Split.split gpart_asZF
                            p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                            (g_asXu, gpart_asZF) = Genome.Split.split gpart_asZE
                            p_asXt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXs
                            (g_asXs, gpart_asZE) = Genome.Split.split gpart_asZD
                            p_asXr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                            (g_asXq, gpart_asZD) = Genome.Split.split gpart_asZC
                            p_asXp = Functions.belowten' g_asXo
                            (g_asXo, gpart_asZC) = Genome.Split.split gpart_asZB
                            p_asXn = code-0.1.0.0:Genome.FixedList.Functions.double g_asXm
                            (g_asXm, gpart_asZB) = Genome.Split.split gpart_asZA
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZA) = Genome.Split.split gpart_asZz
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZz) = Genome.Split.split gpart_asZy
                            p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                            (g_asXg, gpart_asZy) = Genome.Split.split gpart_asZx
                            p_asXf = code-0.1.0.0:Genome.FixedList.Functions.double g_asXe
                            (g_asXe, gpart_asZx) = Genome.Split.split gpart_asZw
                            p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                            (g_asXc, gpart_asZw) = Genome.Split.split genome_asYs
                          in
                            \ desc_asYt
                              -> case desc_asYt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at25
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2J
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1U = Functions.belowten' g_at1T
                      (g_at1T, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                      (g_at1N, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1M = Functions.belowten' g_at1L
                      (g_at1L, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                      (g_at1H, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1F
                      (g_at1F, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1E = Functions.belowten' g_at1D
                      (g_at1D, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                      (g_at1z, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1w = Functions.belowten' g_at1v
                      (g_at1v, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                      (g_at1t, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1s
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1r
                      (g_at1r, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                      (g_at1p, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                      (g_at1n, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1m = Functions.belowten' g_at1l
                      (g_at1l, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1i = Functions.belowten' g_at1h
                      (g_at1h, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at1a = Functions.belowten' g_at19
                      (g_at19, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                      (g_at17, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at16
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at15
                      (g_at15, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at14
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at13
                      (g_at13, gpart_at2e) = Genome.Split.split gpart_at2d
                      p_at12 = Functions.belowten' g_at11
                      (g_at11, gpart_at2d) = Genome.Split.split gpart_at2c
                      p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                      (g_at0Z, gpart_at2c) = Genome.Split.split gpart_at2b
                      p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                      (g_at0X, gpart_at2b) = Genome.Split.split gpart_at2a
                      p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                      (g_at0V, gpart_at2a) = Genome.Split.split gpart_at29
                      p_at0U = code-0.1.0.0:Genome.FixedList.Functions.double g_at0T
                      (g_at0T, gpart_at29) = Genome.Split.split gpart_at28
                      p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                      (g_at0R, gpart_at28) = Genome.Split.split gpart_at27
                      p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                      (g_at0P, gpart_at27) = Genome.Split.split genome_at25
                    in
                      [Reaction
                         (\ x_at2K
                            -> let
                                 c_MiRs_at2N = ((toVector x_at2K) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at2L = ((toVector x_at2K) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at0Y
                                  * ((p_at1c + ((c_NPTB_at2L / p_at10) ** p_at12))
                                     / (((1 + p_at1c) + ((c_NPTB_at2L / p_at10) ** p_at12))
                                        + ((c_MiRs_at2N / p_at18) ** p_at1a)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2O
                            -> let
                                 c_MiRs_at2P = ((toVector x_at2O) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2Q = ((toVector x_at2O) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1e
                                  / (1
                                     + (((c_MiRs_at2P / p_at1g) ** p_at1i)
                                        + ((c_PTB_at2Q / p_at1k) ** p_at1m)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2R
                            -> let c_RESTc_at2S = ((toVector x_at2R) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1o
                                  * (p_at1y
                                     / ((1 + p_at1y) + ((c_RESTc_at2S / p_at1u) ** p_at1w)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2T
                            -> let
                                 c_MiRs_at2W = ((toVector x_at2T) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2U = ((toVector x_at2T) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1A
                                  * ((p_at1O + ((c_PTB_at2U / p_at1C) ** p_at1E))
                                     / (((1 + p_at1O) + ((c_PTB_at2U / p_at1C) ** p_at1E))
                                        + ((c_MiRs_at2W / p_at1K) ** p_at1M)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2X
                            -> let c_RESTc_at2Y = ((toVector x_at2X) Data.Vector.Unboxed.! 3)
                               in (p_at1Q / (1 + ((c_RESTc_at2Y / p_at1S) ** p_at1U))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2Z
                            -> let c_PTB_at30 = ((toVector x_at2Z) Data.Vector.Unboxed.! 0)
                               in (p_at1W * c_PTB_at30))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at31
                            -> let c_NPTB_at32 = ((toVector x_at31) Data.Vector.Unboxed.! 1)
                               in (p_at1Y * c_NPTB_at32))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at33
                            -> let c_MiRs_at34 = ((toVector x_at33) Data.Vector.Unboxed.! 2)
                               in (p_at20 * c_MiRs_at34))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at35
                            -> let c_RESTc_at36 = ((toVector x_at35) Data.Vector.Unboxed.! 3)
                               in (p_at22 * c_RESTc_at36))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at37
                            -> let
                                 c_EndoNeuroTFs_at38 = ((toVector x_at37) Data.Vector.Unboxed.! 4)
                               in (p_at24 * c_EndoNeuroTFs_at38))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121319",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121320",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121321",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121322",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121323",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121324",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121325",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121326",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121327",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121328",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121329",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121330",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121331",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121332",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121333",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121334",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at25
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3L
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1U = Functions.belowten' g_at1T
                            (g_at1T, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1O = code-0.1.0.0:Genome.FixedList.Functions.double g_at1N
                            (g_at1N, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1M = Functions.belowten' g_at1L
                            (g_at1L, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                            (g_at1H, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1F
                            (g_at1F, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1E = Functions.belowten' g_at1D
                            (g_at1D, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1A = code-0.1.0.0:Genome.FixedList.Functions.double g_at1z
                            (g_at1z, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1w = Functions.belowten' g_at1v
                            (g_at1v, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                            (g_at1t, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1s
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1r
                            (g_at1r, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                            (g_at1p, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                            (g_at1n, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at1m = Functions.belowten' g_at1l
                            (g_at1l, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1i = Functions.belowten' g_at1h
                            (g_at1h, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at1a = Functions.belowten' g_at19
                            (g_at19, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                            (g_at17, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at16
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at15
                            (g_at15, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at14
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at13
                            (g_at13, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at12 = Functions.belowten' g_at11
                            (g_at11, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at10 = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Z
                            (g_at0Z, gpart_at3e) = Genome.Split.split gpart_at3d
                            p_at0Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at0X
                            (g_at0X, gpart_at3d) = Genome.Split.split gpart_at3c
                            p_at0W = code-0.1.0.0:Genome.FixedList.Functions.double g_at0V
                            (g_at0V, gpart_at3c) = Genome.Split.split gpart_at3b
                            p_at0U = code-0.1.0.0:Genome.FixedList.Functions.double g_at0T
                            (g_at0T, gpart_at3b) = Genome.Split.split gpart_at3a
                            p_at0S = code-0.1.0.0:Genome.FixedList.Functions.double g_at0R
                            (g_at0R, gpart_at3a) = Genome.Split.split gpart_at39
                            p_at0Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at0P
                            (g_at0P, gpart_at39) = Genome.Split.split genome_at25
                          in
                            \ desc_at26
                              -> case desc_at26 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Q)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0S)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0U)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0W)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Y)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at10)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at12)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at14)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5I
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6m
                      p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                      (g_at5G, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                      (g_at5y, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5x = Functions.belowten' g_at5w
                      (g_at5w, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                      (g_at5u, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at5r = code-0.1.0.0:Genome.FixedList.Functions.double g_at5q
                      (g_at5q, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at5p = Functions.belowten' g_at5o
                      (g_at5o, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                      (g_at5m, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at5l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                      (g_at5k, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at5j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5i
                      (g_at5i, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at5h = Functions.belowten' g_at5g
                      (g_at5g, gpart_at69) = Genome.Split.split gpart_at68
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at68) = Genome.Split.split gpart_at67
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at67) = Genome.Split.split gpart_at66
                      p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                      (g_at5a, gpart_at66) = Genome.Split.split gpart_at65
                      p_at59 = Functions.belowten' g_at58
                      (g_at58, gpart_at65) = Genome.Split.split gpart_at64
                      p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                      (g_at56, gpart_at64) = Genome.Split.split gpart_at63
                      p_at55
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                      (g_at54, gpart_at63) = Genome.Split.split gpart_at62
                      p_at53
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                      (g_at52, gpart_at62) = Genome.Split.split gpart_at61
                      p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                      (g_at50, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4Z = Functions.belowten' g_at4Y
                      (g_at4Y, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4V = Functions.belowten' g_at4U
                      (g_at4U, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at4N = Functions.belowten' g_at4M
                      (g_at4M, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at4J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                      (g_at4I, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at4H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4G
                      (g_at4G, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at4F = Functions.belowten' g_at4E
                      (g_at4E, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                      (g_at4A, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4x = code-0.1.0.0:Genome.FixedList.Functions.double g_at4w
                      (g_at4w, gpart_at5M) = Genome.Split.split gpart_at5L
                      p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                      (g_at4u, gpart_at5L) = Genome.Split.split gpart_at5K
                      p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                      (g_at4s, gpart_at5K) = Genome.Split.split genome_at5I
                    in
                      [Reaction
                         (\ x_at6n
                            -> let
                                 c_MiRs_at6q = ((toVector x_at6n) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at6o = ((toVector x_at6n) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at4B
                                  * ((p_at4P + ((c_NPTB_at6o / p_at4D) ** p_at4F))
                                     / (((1 + p_at4P) + ((c_NPTB_at6o / p_at4D) ** p_at4F))
                                        + (((p_at4t / p_at4H) ** p_at4J)
                                           + ((c_MiRs_at6q / p_at4L) ** p_at4N))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6r
                            -> let
                                 c_MiRs_at6s = ((toVector x_at6r) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6t = ((toVector x_at6r) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4R
                                  / (1
                                     + (((c_MiRs_at6s / p_at4T) ** p_at4V)
                                        + ((c_PTB_at6t / p_at4X) ** p_at4Z)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6u
                            -> let c_RESTc_at6v = ((toVector x_at6u) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at51
                                  * (p_at5b
                                     / ((1 + p_at5b) + ((c_RESTc_at6v / p_at57) ** p_at59)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6w
                            -> let
                                 c_MiRs_at6z = ((toVector x_at6w) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6x = ((toVector x_at6w) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5d
                                  * ((p_at5r + ((c_PTB_at6x / p_at5f) ** p_at5h))
                                     / (((1 + p_at5r) + ((c_PTB_at6x / p_at5f) ** p_at5h))
                                        + ((c_MiRs_at6z / p_at5n) ** p_at5p)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6A
                            -> let c_RESTc_at6B = ((toVector x_at6A) Data.Vector.Unboxed.! 3)
                               in (p_at5t / (1 + ((c_RESTc_at6B / p_at5v) ** p_at5x))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6C
                            -> let c_PTB_at6D = ((toVector x_at6C) Data.Vector.Unboxed.! 0)
                               in (p_at5z * c_PTB_at6D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6E
                            -> let c_NPTB_at6F = ((toVector x_at6E) Data.Vector.Unboxed.! 1)
                               in (p_at5B * c_NPTB_at6F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6G
                            -> let c_MiRs_at6H = ((toVector x_at6G) Data.Vector.Unboxed.! 2)
                               in (p_at5D * c_MiRs_at6H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6I
                            -> let c_RESTc_at6J = ((toVector x_at6I) Data.Vector.Unboxed.! 3)
                               in (p_at5F * c_RESTc_at6J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6K
                            -> let
                                 c_EndoNeuroTFs_at6L = ((toVector x_at6K) Data.Vector.Unboxed.! 4)
                               in (p_at5H * c_EndoNeuroTFs_at6L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [NPTB] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5I
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7o
                            p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                            (g_at5G, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                            (g_at5y, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at5x = Functions.belowten' g_at5w
                            (g_at5w, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                            (g_at5u, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at5r = code-0.1.0.0:Genome.FixedList.Functions.double g_at5q
                            (g_at5q, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at5p = Functions.belowten' g_at5o
                            (g_at5o, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                            (g_at5m, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at5l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                            (g_at5k, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at5j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5i
                            (g_at5i, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at5h = Functions.belowten' g_at5g
                            (g_at5g, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at79) = Genome.Split.split gpart_at78
                            p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                            (g_at5a, gpart_at78) = Genome.Split.split gpart_at77
                            p_at59 = Functions.belowten' g_at58
                            (g_at58, gpart_at77) = Genome.Split.split gpart_at76
                            p_at57 = code-0.1.0.0:Genome.FixedList.Functions.double g_at56
                            (g_at56, gpart_at76) = Genome.Split.split gpart_at75
                            p_at55
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                            (g_at54, gpart_at75) = Genome.Split.split gpart_at74
                            p_at53
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                            (g_at52, gpart_at74) = Genome.Split.split gpart_at73
                            p_at51 = code-0.1.0.0:Genome.FixedList.Functions.double g_at50
                            (g_at50, gpart_at73) = Genome.Split.split gpart_at72
                            p_at4Z = Functions.belowten' g_at4Y
                            (g_at4Y, gpart_at72) = Genome.Split.split gpart_at71
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at71) = Genome.Split.split gpart_at70
                            p_at4V = Functions.belowten' g_at4U
                            (g_at4U, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at4N = Functions.belowten' g_at4M
                            (g_at4M, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at4J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                            (g_at4I, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at4H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4G
                            (g_at4G, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at4F = Functions.belowten' g_at4E
                            (g_at4E, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                            (g_at4A, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4x = code-0.1.0.0:Genome.FixedList.Functions.double g_at4w
                            (g_at4w, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4v = code-0.1.0.0:Genome.FixedList.Functions.double g_at4u
                            (g_at4u, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4t = code-0.1.0.0:Genome.FixedList.Functions.double g_at4s
                            (g_at4s, gpart_at6M) = Genome.Split.split genome_at5I
                          in
                            \ desc_at5J
                              -> case desc_at5J of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Activation coef [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Activation hill [NPTB] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   _ -> Nothing }}
