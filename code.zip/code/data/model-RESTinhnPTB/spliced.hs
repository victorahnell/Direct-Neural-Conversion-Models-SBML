src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zbi
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZbV
                      p_a1Zbh = double g_a1Zbg
                      (g_a1Zbg, gpart_a1ZbV) = Genome.Split.split gpart_a1ZbU
                      p_a1Zbf = double g_a1Zbe
                      (g_a1Zbe, gpart_a1ZbU) = Genome.Split.split gpart_a1ZbT
                      p_a1Zbd = double g_a1Zbc
                      (g_a1Zbc, gpart_a1ZbT) = Genome.Split.split gpart_a1ZbS
                      p_a1Zbb = double g_a1Zba
                      (g_a1Zba, gpart_a1ZbS) = Genome.Split.split gpart_a1ZbR
                      p_a1Zb9 = double g_a1Zb8
                      (g_a1Zb8, gpart_a1ZbR) = Genome.Split.split gpart_a1ZbQ
                      p_a1Zb7 = Functions.belowten' g_a1Zb6
                      (g_a1Zb6, gpart_a1ZbQ) = Genome.Split.split gpart_a1ZbP
                      p_a1Zb5 = double g_a1Zb4
                      (g_a1Zb4, gpart_a1ZbP) = Genome.Split.split gpart_a1ZbO
                      p_a1Zb3 = double g_a1Zb2
                      (g_a1Zb2, gpart_a1ZbO) = Genome.Split.split gpart_a1ZbN
                      p_a1Zb1 = double g_a1Zb0
                      (g_a1Zb0, gpart_a1ZbN) = Genome.Split.split gpart_a1ZbM
                      p_a1ZaZ = Functions.belowten' g_a1ZaY
                      (g_a1ZaY, gpart_a1ZbM) = Genome.Split.split gpart_a1ZbL
                      p_a1ZaX = double g_a1ZaW
                      (g_a1ZaW, gpart_a1ZbL) = Genome.Split.split gpart_a1ZbK
                      p_a1ZaV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaU
                      (g_a1ZaU, gpart_a1ZbK) = Genome.Split.split gpart_a1ZbJ
                      p_a1ZaT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaS
                      (g_a1ZaS, gpart_a1ZbJ) = Genome.Split.split gpart_a1ZbI
                      p_a1ZaR = Functions.belowten' g_a1ZaQ
                      (g_a1ZaQ, gpart_a1ZbI) = Genome.Split.split gpart_a1ZbH
                      p_a1ZaP = double g_a1ZaO
                      (g_a1ZaO, gpart_a1ZbH) = Genome.Split.split gpart_a1ZbG
                      p_a1ZaN = double g_a1ZaM
                      (g_a1ZaM, gpart_a1ZbG) = Genome.Split.split gpart_a1ZbF
                      p_a1ZaL = double g_a1ZaK
                      (g_a1ZaK, gpart_a1ZbF) = Genome.Split.split gpart_a1ZbE
                      p_a1ZaJ = Functions.belowten' g_a1ZaI
                      (g_a1ZaI, gpart_a1ZbE) = Genome.Split.split gpart_a1ZbD
                      p_a1ZaH = double g_a1ZaG
                      (g_a1ZaG, gpart_a1ZbD) = Genome.Split.split gpart_a1ZbC
                      p_a1ZaF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaE
                      (g_a1ZaE, gpart_a1ZbC) = Genome.Split.split gpart_a1ZbB
                      p_a1ZaD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaC
                      (g_a1ZaC, gpart_a1ZbB) = Genome.Split.split gpart_a1ZbA
                      p_a1ZaB = double g_a1ZaA
                      (g_a1ZaA, gpart_a1ZbA) = Genome.Split.split gpart_a1Zbz
                      p_a1Zaz = Functions.belowten' g_a1Zay
                      (g_a1Zay, gpart_a1Zbz) = Genome.Split.split gpart_a1Zby
                      p_a1Zax = double g_a1Zaw
                      (g_a1Zaw, gpart_a1Zby) = Genome.Split.split gpart_a1Zbx
                      p_a1Zav = Functions.belowten' g_a1Zau
                      (g_a1Zau, gpart_a1Zbx) = Genome.Split.split gpart_a1Zbw
                      p_a1Zat = double g_a1Zas
                      (g_a1Zas, gpart_a1Zbw) = Genome.Split.split gpart_a1Zbv
                      p_a1Zar = Functions.belowten' g_a1Zaq
                      (g_a1Zaq, gpart_a1Zbv) = Genome.Split.split gpart_a1Zbu
                      p_a1Zap = double g_a1Zao
                      (g_a1Zao, gpart_a1Zbu) = Genome.Split.split gpart_a1Zbt
                      p_a1Zan = double g_a1Zam
                      (g_a1Zam, gpart_a1Zbt) = Genome.Split.split gpart_a1Zbs
                      p_a1Zal = Functions.belowten' g_a1Zak
                      (g_a1Zak, gpart_a1Zbs) = Genome.Split.split gpart_a1Zbr
                      p_a1Zaj = double g_a1Zai
                      (g_a1Zai, gpart_a1Zbr) = Genome.Split.split gpart_a1Zbq
                      p_a1Zah
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zag
                      (g_a1Zag, gpart_a1Zbq) = Genome.Split.split gpart_a1Zbp
                      p_a1Zaf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zae
                      (g_a1Zae, gpart_a1Zbp) = Genome.Split.split gpart_a1Zbo
                      p_a1Zad = double g_a1Zac
                      (g_a1Zac, gpart_a1Zbo) = Genome.Split.split gpart_a1Zbn
                      p_a1Zab = double g_a1Zaa
                      (g_a1Zaa, gpart_a1Zbn) = Genome.Split.split gpart_a1Zbm
                      p_a1Za9 = double g_a1Za8
                      (g_a1Za8, gpart_a1Zbm) = Genome.Split.split gpart_a1Zbl
                      p_a1Za7 = double g_a1Za6
                      (g_a1Za6, gpart_a1Zbl) = Genome.Split.split gpart_a1Zbk
                      p_a1Za5 = double g_a1Za4
                      (g_a1Za4, gpart_a1Zbk) = Genome.Split.split genome_a1Zbi
                    in  \ x_a1ZbW
                          -> let
                               c_PTB_a1ZbZ
                                 = ((Data.Fixed.Vector.toVector x_a1ZbW) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZbX
                                 = ((Data.Fixed.Vector.toVector x_a1ZbW) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zc4
                                 = ((Data.Fixed.Vector.toVector x_a1ZbW) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zc0
                                 = ((Data.Fixed.Vector.toVector x_a1ZbW) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zcf
                                 = ((Data.Fixed.Vector.toVector x_a1ZbW) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zad / (1 + ((c_MiRs_a1ZbX / p_a1Zaj) ** p_a1Zal)))
                                    + (negate (p_a1Zb9 * c_PTB_a1ZbZ))),
                                   ((p_a1Zan
                                     / (1
                                        + ((((c_RESTc_a1Zc0 / p_a1Zap) ** p_a1Zar)
                                            + ((c_MiRs_a1ZbX / p_a1Zat) ** p_a1Zav))
                                           + ((c_PTB_a1ZbZ / p_a1Zax) ** p_a1Zaz))))
                                    + (negate (p_a1Zbb * c_NPTB_a1Zc4))),
                                   ((p_a1ZaB
                                     * ((p_a1ZaL + ((p_a1Za9 / p_a1ZaD) ** p_a1ZaF))
                                        / (((1 + p_a1ZaL) + ((p_a1Za9 / p_a1ZaD) ** p_a1ZaF))
                                           + ((c_RESTc_a1Zc0 / p_a1ZaH) ** p_a1ZaJ))))
                                    + (negate (p_a1Zbd * c_MiRs_a1ZbX))),
                                   ((p_a1ZaN
                                     * ((p_a1Zb1 + ((c_PTB_a1ZbZ / p_a1ZaP) ** p_a1ZaR))
                                        / (((1 + p_a1Zb1) + ((c_PTB_a1ZbZ / p_a1ZaP) ** p_a1ZaR))
                                           + (((p_a1Za5 / p_a1ZaT) ** p_a1ZaV)
                                              + ((c_MiRs_a1ZbX / p_a1ZaX) ** p_a1ZaZ)))))
                                    + (negate (p_a1Zbf * c_RESTc_a1Zc0))),
                                   ((p_a1Zb3 / (1 + ((c_RESTc_a1Zc0 / p_a1Zb5) ** p_a1Zb7)))
                                    + (negate (p_a1Zbh * c_EndoNeuroTFs_a1Zcf)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483239",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483241",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483245",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483263",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483265",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483279",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483281",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zbi
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZcR
                            p_a1Zbh = double g_a1Zbg
                            (g_a1Zbg, gpart_a1ZcR) = Genome.Split.split gpart_a1ZcQ
                            p_a1Zbf = double g_a1Zbe
                            (g_a1Zbe, gpart_a1ZcQ) = Genome.Split.split gpart_a1ZcP
                            p_a1Zbd = double g_a1Zbc
                            (g_a1Zbc, gpart_a1ZcP) = Genome.Split.split gpart_a1ZcO
                            p_a1Zbb = double g_a1Zba
                            (g_a1Zba, gpart_a1ZcO) = Genome.Split.split gpart_a1ZcN
                            p_a1Zb9 = double g_a1Zb8
                            (g_a1Zb8, gpart_a1ZcN) = Genome.Split.split gpart_a1ZcM
                            p_a1Zb7 = Functions.belowten' g_a1Zb6
                            (g_a1Zb6, gpart_a1ZcM) = Genome.Split.split gpart_a1ZcL
                            p_a1Zb5 = double g_a1Zb4
                            (g_a1Zb4, gpart_a1ZcL) = Genome.Split.split gpart_a1ZcK
                            p_a1Zb3 = double g_a1Zb2
                            (g_a1Zb2, gpart_a1ZcK) = Genome.Split.split gpart_a1ZcJ
                            p_a1Zb1 = double g_a1Zb0
                            (g_a1Zb0, gpart_a1ZcJ) = Genome.Split.split gpart_a1ZcI
                            p_a1ZaZ = Functions.belowten' g_a1ZaY
                            (g_a1ZaY, gpart_a1ZcI) = Genome.Split.split gpart_a1ZcH
                            p_a1ZaX = double g_a1ZaW
                            (g_a1ZaW, gpart_a1ZcH) = Genome.Split.split gpart_a1ZcG
                            p_a1ZaV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaU
                            (g_a1ZaU, gpart_a1ZcG) = Genome.Split.split gpart_a1ZcF
                            p_a1ZaT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaS
                            (g_a1ZaS, gpart_a1ZcF) = Genome.Split.split gpart_a1ZcE
                            p_a1ZaR = Functions.belowten' g_a1ZaQ
                            (g_a1ZaQ, gpart_a1ZcE) = Genome.Split.split gpart_a1ZcD
                            p_a1ZaP = double g_a1ZaO
                            (g_a1ZaO, gpart_a1ZcD) = Genome.Split.split gpart_a1ZcC
                            p_a1ZaN = double g_a1ZaM
                            (g_a1ZaM, gpart_a1ZcC) = Genome.Split.split gpart_a1ZcB
                            p_a1ZaL = double g_a1ZaK
                            (g_a1ZaK, gpart_a1ZcB) = Genome.Split.split gpart_a1ZcA
                            p_a1ZaJ = Functions.belowten' g_a1ZaI
                            (g_a1ZaI, gpart_a1ZcA) = Genome.Split.split gpart_a1Zcz
                            p_a1ZaH = double g_a1ZaG
                            (g_a1ZaG, gpart_a1Zcz) = Genome.Split.split gpart_a1Zcy
                            p_a1ZaF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaE
                            (g_a1ZaE, gpart_a1Zcy) = Genome.Split.split gpart_a1Zcx
                            p_a1ZaD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZaC
                            (g_a1ZaC, gpart_a1Zcx) = Genome.Split.split gpart_a1Zcw
                            p_a1ZaB = double g_a1ZaA
                            (g_a1ZaA, gpart_a1Zcw) = Genome.Split.split gpart_a1Zcv
                            p_a1Zaz = Functions.belowten' g_a1Zay
                            (g_a1Zay, gpart_a1Zcv) = Genome.Split.split gpart_a1Zcu
                            p_a1Zax = double g_a1Zaw
                            (g_a1Zaw, gpart_a1Zcu) = Genome.Split.split gpart_a1Zct
                            p_a1Zav = Functions.belowten' g_a1Zau
                            (g_a1Zau, gpart_a1Zct) = Genome.Split.split gpart_a1Zcs
                            p_a1Zat = double g_a1Zas
                            (g_a1Zas, gpart_a1Zcs) = Genome.Split.split gpart_a1Zcr
                            p_a1Zar = Functions.belowten' g_a1Zaq
                            (g_a1Zaq, gpart_a1Zcr) = Genome.Split.split gpart_a1Zcq
                            p_a1Zap = double g_a1Zao
                            (g_a1Zao, gpart_a1Zcq) = Genome.Split.split gpart_a1Zcp
                            p_a1Zan = double g_a1Zam
                            (g_a1Zam, gpart_a1Zcp) = Genome.Split.split gpart_a1Zco
                            p_a1Zal = Functions.belowten' g_a1Zak
                            (g_a1Zak, gpart_a1Zco) = Genome.Split.split gpart_a1Zcn
                            p_a1Zaj = double g_a1Zai
                            (g_a1Zai, gpart_a1Zcn) = Genome.Split.split gpart_a1Zcm
                            p_a1Zah
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zag
                            (g_a1Zag, gpart_a1Zcm) = Genome.Split.split gpart_a1Zcl
                            p_a1Zaf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zae
                            (g_a1Zae, gpart_a1Zcl) = Genome.Split.split gpart_a1Zck
                            p_a1Zad = double g_a1Zac
                            (g_a1Zac, gpart_a1Zck) = Genome.Split.split gpart_a1Zcj
                            p_a1Zab = double g_a1Zaa
                            (g_a1Zaa, gpart_a1Zcj) = Genome.Split.split gpart_a1Zci
                            p_a1Za9 = double g_a1Za8
                            (g_a1Za8, gpart_a1Zci) = Genome.Split.split gpart_a1Zch
                            p_a1Za7 = double g_a1Za6
                            (g_a1Za6, gpart_a1Zch) = Genome.Split.split gpart_a1Zcg
                            p_a1Za5 = double g_a1Za4
                            (g_a1Za4, gpart_a1Zcg) = Genome.Split.split genome_a1Zbi
                          in
                            \ desc_a1Zbj
                              -> case desc_a1Zbj of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za5)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za7)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za9)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zab)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zad)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaf)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zah)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaj)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zal)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zan)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zap)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zar)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zat)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zav)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zax)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaB)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaD)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaR)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaT)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaV)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaX)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaZ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zb1)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zb3)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zb5)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zb7)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zb9)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zbb)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zbd)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zbf)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zbh)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zff
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZfS
                      p_a1Zfe = double g_a1Zfd
                      (g_a1Zfd, gpart_a1ZfS) = Genome.Split.split gpart_a1ZfR
                      p_a1Zfc = double g_a1Zfb
                      (g_a1Zfb, gpart_a1ZfR) = Genome.Split.split gpart_a1ZfQ
                      p_a1Zfa = double g_a1Zf9
                      (g_a1Zf9, gpart_a1ZfQ) = Genome.Split.split gpart_a1ZfP
                      p_a1Zf8 = double g_a1Zf7
                      (g_a1Zf7, gpart_a1ZfP) = Genome.Split.split gpart_a1ZfO
                      p_a1Zf6 = double g_a1Zf5
                      (g_a1Zf5, gpart_a1ZfO) = Genome.Split.split gpart_a1ZfN
                      p_a1Zf4 = Functions.belowten' g_a1Zf3
                      (g_a1Zf3, gpart_a1ZfN) = Genome.Split.split gpart_a1ZfM
                      p_a1Zf2 = double g_a1Zf1
                      (g_a1Zf1, gpart_a1ZfM) = Genome.Split.split gpart_a1ZfL
                      p_a1Zf0 = double g_a1ZeZ
                      (g_a1ZeZ, gpart_a1ZfL) = Genome.Split.split gpart_a1ZfK
                      p_a1ZeY = double g_a1ZeX
                      (g_a1ZeX, gpart_a1ZfK) = Genome.Split.split gpart_a1ZfJ
                      p_a1ZeW = Functions.belowten' g_a1ZeV
                      (g_a1ZeV, gpart_a1ZfJ) = Genome.Split.split gpart_a1ZfI
                      p_a1ZeU = double g_a1ZeT
                      (g_a1ZeT, gpart_a1ZfI) = Genome.Split.split gpart_a1ZfH
                      p_a1ZeS
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeR
                      (g_a1ZeR, gpart_a1ZfH) = Genome.Split.split gpart_a1ZfG
                      p_a1ZeQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeP
                      (g_a1ZeP, gpart_a1ZfG) = Genome.Split.split gpart_a1ZfF
                      p_a1ZeO = Functions.belowten' g_a1ZeN
                      (g_a1ZeN, gpart_a1ZfF) = Genome.Split.split gpart_a1ZfE
                      p_a1ZeM = double g_a1ZeL
                      (g_a1ZeL, gpart_a1ZfE) = Genome.Split.split gpart_a1ZfD
                      p_a1ZeK = double g_a1ZeJ
                      (g_a1ZeJ, gpart_a1ZfD) = Genome.Split.split gpart_a1ZfC
                      p_a1ZeI = double g_a1ZeH
                      (g_a1ZeH, gpart_a1ZfC) = Genome.Split.split gpart_a1ZfB
                      p_a1ZeG = Functions.belowten' g_a1ZeF
                      (g_a1ZeF, gpart_a1ZfB) = Genome.Split.split gpart_a1ZfA
                      p_a1ZeE = double g_a1ZeD
                      (g_a1ZeD, gpart_a1ZfA) = Genome.Split.split gpart_a1Zfz
                      p_a1ZeC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeB
                      (g_a1ZeB, gpart_a1Zfz) = Genome.Split.split gpart_a1Zfy
                      p_a1ZeA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zez
                      (g_a1Zez, gpart_a1Zfy) = Genome.Split.split gpart_a1Zfx
                      p_a1Zey = double g_a1Zex
                      (g_a1Zex, gpart_a1Zfx) = Genome.Split.split gpart_a1Zfw
                      p_a1Zew = Functions.belowten' g_a1Zev
                      (g_a1Zev, gpart_a1Zfw) = Genome.Split.split gpart_a1Zfv
                      p_a1Zeu = double g_a1Zet
                      (g_a1Zet, gpart_a1Zfv) = Genome.Split.split gpart_a1Zfu
                      p_a1Zes = Functions.belowten' g_a1Zer
                      (g_a1Zer, gpart_a1Zfu) = Genome.Split.split gpart_a1Zft
                      p_a1Zeq = double g_a1Zep
                      (g_a1Zep, gpart_a1Zft) = Genome.Split.split gpart_a1Zfs
                      p_a1Zeo = Functions.belowten' g_a1Zen
                      (g_a1Zen, gpart_a1Zfs) = Genome.Split.split gpart_a1Zfr
                      p_a1Zem = double g_a1Zel
                      (g_a1Zel, gpart_a1Zfr) = Genome.Split.split gpart_a1Zfq
                      p_a1Zek = double g_a1Zej
                      (g_a1Zej, gpart_a1Zfq) = Genome.Split.split gpart_a1Zfp
                      p_a1Zei = Functions.belowten' g_a1Zeh
                      (g_a1Zeh, gpart_a1Zfp) = Genome.Split.split gpart_a1Zfo
                      p_a1Zeg = double g_a1Zef
                      (g_a1Zef, gpart_a1Zfo) = Genome.Split.split gpart_a1Zfn
                      p_a1Zee
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zed
                      (g_a1Zed, gpart_a1Zfn) = Genome.Split.split gpart_a1Zfm
                      p_a1Zec
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zeb
                      (g_a1Zeb, gpart_a1Zfm) = Genome.Split.split gpart_a1Zfl
                      p_a1Zea = double g_a1Ze9
                      (g_a1Ze9, gpart_a1Zfl) = Genome.Split.split gpart_a1Zfk
                      p_a1Ze8 = double g_a1Ze7
                      (g_a1Ze7, gpart_a1Zfk) = Genome.Split.split gpart_a1Zfj
                      p_a1Ze6 = double g_a1Ze5
                      (g_a1Ze5, gpart_a1Zfj) = Genome.Split.split gpart_a1Zfi
                      p_a1Ze4 = double g_a1Ze3
                      (g_a1Ze3, gpart_a1Zfi) = Genome.Split.split gpart_a1Zfh
                      p_a1Ze2 = double g_a1Ze1
                      (g_a1Ze1, gpart_a1Zfh) = Genome.Split.split genome_a1Zff
                    in  \ x_a1ZfT
                          -> let
                               c_PTB_a1ZfW
                                 = ((Data.Fixed.Vector.toVector x_a1ZfT) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZfU
                                 = ((Data.Fixed.Vector.toVector x_a1ZfT) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zg1
                                 = ((Data.Fixed.Vector.toVector x_a1ZfT) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZfX
                                 = ((Data.Fixed.Vector.toVector x_a1ZfT) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zgc
                                 = ((Data.Fixed.Vector.toVector x_a1ZfT) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zea / (1 + ((c_MiRs_a1ZfU / p_a1Zeg) ** p_a1Zei)))
                                    + (negate (p_a1Zf6 * c_PTB_a1ZfW))),
                                   ((p_a1Zek
                                     / (1
                                        + ((((c_RESTc_a1ZfX / p_a1Zem) ** p_a1Zeo)
                                            + ((c_MiRs_a1ZfU / p_a1Zeq) ** p_a1Zes))
                                           + ((c_PTB_a1ZfW / p_a1Zeu) ** p_a1Zew))))
                                    + (negate (p_a1Zf8 * c_NPTB_a1Zg1))),
                                   ((p_a1Zey
                                     * (p_a1ZeI
                                        / ((1 + p_a1ZeI) + ((c_RESTc_a1ZfX / p_a1ZeE) ** p_a1ZeG))))
                                    + (negate (p_a1Zfa * c_MiRs_a1ZfU))),
                                   ((p_a1ZeK
                                     * ((p_a1ZeY + ((c_PTB_a1ZfW / p_a1ZeM) ** p_a1ZeO))
                                        / (((1 + p_a1ZeY) + ((c_PTB_a1ZfW / p_a1ZeM) ** p_a1ZeO))
                                           + (((p_a1Ze2 / p_a1ZeQ) ** p_a1ZeS)
                                              + ((c_MiRs_a1ZfU / p_a1ZeU) ** p_a1ZeW)))))
                                    + (negate (p_a1Zfc * c_RESTc_a1ZfX))),
                                   ((p_a1Zf0 / (1 + ((c_RESTc_a1ZfX / p_a1Zf2) ** p_a1Zf4)))
                                    + (negate (p_a1Zfe * c_EndoNeuroTFs_a1Zgc)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483484",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483486",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483508",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483510",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483524",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483526",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zff
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZgO
                            p_a1Zfe = double g_a1Zfd
                            (g_a1Zfd, gpart_a1ZgO) = Genome.Split.split gpart_a1ZgN
                            p_a1Zfc = double g_a1Zfb
                            (g_a1Zfb, gpart_a1ZgN) = Genome.Split.split gpart_a1ZgM
                            p_a1Zfa = double g_a1Zf9
                            (g_a1Zf9, gpart_a1ZgM) = Genome.Split.split gpart_a1ZgL
                            p_a1Zf8 = double g_a1Zf7
                            (g_a1Zf7, gpart_a1ZgL) = Genome.Split.split gpart_a1ZgK
                            p_a1Zf6 = double g_a1Zf5
                            (g_a1Zf5, gpart_a1ZgK) = Genome.Split.split gpart_a1ZgJ
                            p_a1Zf4 = Functions.belowten' g_a1Zf3
                            (g_a1Zf3, gpart_a1ZgJ) = Genome.Split.split gpart_a1ZgI
                            p_a1Zf2 = double g_a1Zf1
                            (g_a1Zf1, gpart_a1ZgI) = Genome.Split.split gpart_a1ZgH
                            p_a1Zf0 = double g_a1ZeZ
                            (g_a1ZeZ, gpart_a1ZgH) = Genome.Split.split gpart_a1ZgG
                            p_a1ZeY = double g_a1ZeX
                            (g_a1ZeX, gpart_a1ZgG) = Genome.Split.split gpart_a1ZgF
                            p_a1ZeW = Functions.belowten' g_a1ZeV
                            (g_a1ZeV, gpart_a1ZgF) = Genome.Split.split gpart_a1ZgE
                            p_a1ZeU = double g_a1ZeT
                            (g_a1ZeT, gpart_a1ZgE) = Genome.Split.split gpart_a1ZgD
                            p_a1ZeS
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeR
                            (g_a1ZeR, gpart_a1ZgD) = Genome.Split.split gpart_a1ZgC
                            p_a1ZeQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeP
                            (g_a1ZeP, gpart_a1ZgC) = Genome.Split.split gpart_a1ZgB
                            p_a1ZeO = Functions.belowten' g_a1ZeN
                            (g_a1ZeN, gpart_a1ZgB) = Genome.Split.split gpart_a1ZgA
                            p_a1ZeM = double g_a1ZeL
                            (g_a1ZeL, gpart_a1ZgA) = Genome.Split.split gpart_a1Zgz
                            p_a1ZeK = double g_a1ZeJ
                            (g_a1ZeJ, gpart_a1Zgz) = Genome.Split.split gpart_a1Zgy
                            p_a1ZeI = double g_a1ZeH
                            (g_a1ZeH, gpart_a1Zgy) = Genome.Split.split gpart_a1Zgx
                            p_a1ZeG = Functions.belowten' g_a1ZeF
                            (g_a1ZeF, gpart_a1Zgx) = Genome.Split.split gpart_a1Zgw
                            p_a1ZeE = double g_a1ZeD
                            (g_a1ZeD, gpart_a1Zgw) = Genome.Split.split gpart_a1Zgv
                            p_a1ZeC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZeB
                            (g_a1ZeB, gpart_a1Zgv) = Genome.Split.split gpart_a1Zgu
                            p_a1ZeA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zez
                            (g_a1Zez, gpart_a1Zgu) = Genome.Split.split gpart_a1Zgt
                            p_a1Zey = double g_a1Zex
                            (g_a1Zex, gpart_a1Zgt) = Genome.Split.split gpart_a1Zgs
                            p_a1Zew = Functions.belowten' g_a1Zev
                            (g_a1Zev, gpart_a1Zgs) = Genome.Split.split gpart_a1Zgr
                            p_a1Zeu = double g_a1Zet
                            (g_a1Zet, gpart_a1Zgr) = Genome.Split.split gpart_a1Zgq
                            p_a1Zes = Functions.belowten' g_a1Zer
                            (g_a1Zer, gpart_a1Zgq) = Genome.Split.split gpart_a1Zgp
                            p_a1Zeq = double g_a1Zep
                            (g_a1Zep, gpart_a1Zgp) = Genome.Split.split gpart_a1Zgo
                            p_a1Zeo = Functions.belowten' g_a1Zen
                            (g_a1Zen, gpart_a1Zgo) = Genome.Split.split gpart_a1Zgn
                            p_a1Zem = double g_a1Zel
                            (g_a1Zel, gpart_a1Zgn) = Genome.Split.split gpart_a1Zgm
                            p_a1Zek = double g_a1Zej
                            (g_a1Zej, gpart_a1Zgm) = Genome.Split.split gpart_a1Zgl
                            p_a1Zei = Functions.belowten' g_a1Zeh
                            (g_a1Zeh, gpart_a1Zgl) = Genome.Split.split gpart_a1Zgk
                            p_a1Zeg = double g_a1Zef
                            (g_a1Zef, gpart_a1Zgk) = Genome.Split.split gpart_a1Zgj
                            p_a1Zee
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zed
                            (g_a1Zed, gpart_a1Zgj) = Genome.Split.split gpart_a1Zgi
                            p_a1Zec
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zeb
                            (g_a1Zeb, gpart_a1Zgi) = Genome.Split.split gpart_a1Zgh
                            p_a1Zea = double g_a1Ze9
                            (g_a1Ze9, gpart_a1Zgh) = Genome.Split.split gpart_a1Zgg
                            p_a1Ze8 = double g_a1Ze7
                            (g_a1Ze7, gpart_a1Zgg) = Genome.Split.split gpart_a1Zgf
                            p_a1Ze6 = double g_a1Ze5
                            (g_a1Ze5, gpart_a1Zgf) = Genome.Split.split gpart_a1Zge
                            p_a1Ze4 = double g_a1Ze3
                            (g_a1Ze3, gpart_a1Zge) = Genome.Split.split gpart_a1Zgd
                            p_a1Ze2 = double g_a1Ze1
                            (g_a1Ze1, gpart_a1Zgd) = Genome.Split.split genome_a1Zff
                          in
                            \ desc_a1Zfg
                              -> case desc_a1Zfg of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze2)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze4)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze6)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze8)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zea)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zec)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zee)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zei)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zek)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zem)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeo)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeq)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zes)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeu)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zew)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zey)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeA)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeC)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeE)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeG)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeI)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeK)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeM)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeO)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeQ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeS)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeU)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeW)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeY)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zf0)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zf2)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zf4)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zf6)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zf8)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfa)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfc)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfe)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zjc
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZjP
                      p_a1Zjb = double g_a1Zja
                      (g_a1Zja, gpart_a1ZjP) = Genome.Split.split gpart_a1ZjO
                      p_a1Zj9 = double g_a1Zj8
                      (g_a1Zj8, gpart_a1ZjO) = Genome.Split.split gpart_a1ZjN
                      p_a1Zj7 = double g_a1Zj6
                      (g_a1Zj6, gpart_a1ZjN) = Genome.Split.split gpart_a1ZjM
                      p_a1Zj5 = double g_a1Zj4
                      (g_a1Zj4, gpart_a1ZjM) = Genome.Split.split gpart_a1ZjL
                      p_a1Zj3 = double g_a1Zj2
                      (g_a1Zj2, gpart_a1ZjL) = Genome.Split.split gpart_a1ZjK
                      p_a1Zj1 = Functions.belowten' g_a1Zj0
                      (g_a1Zj0, gpart_a1ZjK) = Genome.Split.split gpart_a1ZjJ
                      p_a1ZiZ = double g_a1ZiY
                      (g_a1ZiY, gpart_a1ZjJ) = Genome.Split.split gpart_a1ZjI
                      p_a1ZiX = double g_a1ZiW
                      (g_a1ZiW, gpart_a1ZjI) = Genome.Split.split gpart_a1ZjH
                      p_a1ZiV = double g_a1ZiU
                      (g_a1ZiU, gpart_a1ZjH) = Genome.Split.split gpart_a1ZjG
                      p_a1ZiT = Functions.belowten' g_a1ZiS
                      (g_a1ZiS, gpart_a1ZjG) = Genome.Split.split gpart_a1ZjF
                      p_a1ZiR = double g_a1ZiQ
                      (g_a1ZiQ, gpart_a1ZjF) = Genome.Split.split gpart_a1ZjE
                      p_a1ZiP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZiO
                      (g_a1ZiO, gpart_a1ZjE) = Genome.Split.split gpart_a1ZjD
                      p_a1ZiN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZiM
                      (g_a1ZiM, gpart_a1ZjD) = Genome.Split.split gpart_a1ZjC
                      p_a1ZiL = Functions.belowten' g_a1ZiK
                      (g_a1ZiK, gpart_a1ZjC) = Genome.Split.split gpart_a1ZjB
                      p_a1ZiJ = double g_a1ZiI
                      (g_a1ZiI, gpart_a1ZjB) = Genome.Split.split gpart_a1ZjA
                      p_a1ZiH = double g_a1ZiG
                      (g_a1ZiG, gpart_a1ZjA) = Genome.Split.split gpart_a1Zjz
                      p_a1ZiF = double g_a1ZiE
                      (g_a1ZiE, gpart_a1Zjz) = Genome.Split.split gpart_a1Zjy
                      p_a1ZiD = Functions.belowten' g_a1ZiC
                      (g_a1ZiC, gpart_a1Zjy) = Genome.Split.split gpart_a1Zjx
                      p_a1ZiB = double g_a1ZiA
                      (g_a1ZiA, gpart_a1Zjx) = Genome.Split.split gpart_a1Zjw
                      p_a1Ziz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ziy
                      (g_a1Ziy, gpart_a1Zjw) = Genome.Split.split gpart_a1Zjv
                      p_a1Zix
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ziw
                      (g_a1Ziw, gpart_a1Zjv) = Genome.Split.split gpart_a1Zju
                      p_a1Ziv = double g_a1Ziu
                      (g_a1Ziu, gpart_a1Zju) = Genome.Split.split gpart_a1Zjt
                      p_a1Zit = Functions.belowten' g_a1Zis
                      (g_a1Zis, gpart_a1Zjt) = Genome.Split.split gpart_a1Zjs
                      p_a1Zir = double g_a1Ziq
                      (g_a1Ziq, gpart_a1Zjs) = Genome.Split.split gpart_a1Zjr
                      p_a1Zip = Functions.belowten' g_a1Zio
                      (g_a1Zio, gpart_a1Zjr) = Genome.Split.split gpart_a1Zjq
                      p_a1Zin = double g_a1Zim
                      (g_a1Zim, gpart_a1Zjq) = Genome.Split.split gpart_a1Zjp
                      p_a1Zil = Functions.belowten' g_a1Zik
                      (g_a1Zik, gpart_a1Zjp) = Genome.Split.split gpart_a1Zjo
                      p_a1Zij = double g_a1Zii
                      (g_a1Zii, gpart_a1Zjo) = Genome.Split.split gpart_a1Zjn
                      p_a1Zih = double g_a1Zig
                      (g_a1Zig, gpart_a1Zjn) = Genome.Split.split gpart_a1Zjm
                      p_a1Zif = Functions.belowten' g_a1Zie
                      (g_a1Zie, gpart_a1Zjm) = Genome.Split.split gpart_a1Zjl
                      p_a1Zid = double g_a1Zic
                      (g_a1Zic, gpart_a1Zjl) = Genome.Split.split gpart_a1Zjk
                      p_a1Zib
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zia
                      (g_a1Zia, gpart_a1Zjk) = Genome.Split.split gpart_a1Zjj
                      p_a1Zi9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zi8
                      (g_a1Zi8, gpart_a1Zjj) = Genome.Split.split gpart_a1Zji
                      p_a1Zi7 = double g_a1Zi6
                      (g_a1Zi6, gpart_a1Zji) = Genome.Split.split gpart_a1Zjh
                      p_a1Zi5 = double g_a1Zi4
                      (g_a1Zi4, gpart_a1Zjh) = Genome.Split.split gpart_a1Zjg
                      p_a1Zi3 = double g_a1Zi2
                      (g_a1Zi2, gpart_a1Zjg) = Genome.Split.split gpart_a1Zjf
                      p_a1Zi1 = double g_a1Zi0
                      (g_a1Zi0, gpart_a1Zjf) = Genome.Split.split gpart_a1Zje
                      p_a1ZhZ = double g_a1ZhY
                      (g_a1ZhY, gpart_a1Zje) = Genome.Split.split genome_a1Zjc
                    in  \ x_a1ZjQ
                          -> let
                               c_PTB_a1ZjT
                                 = ((Data.Fixed.Vector.toVector x_a1ZjQ) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZjR
                                 = ((Data.Fixed.Vector.toVector x_a1ZjQ) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZjY
                                 = ((Data.Fixed.Vector.toVector x_a1ZjQ) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZjU
                                 = ((Data.Fixed.Vector.toVector x_a1ZjQ) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zk9
                                 = ((Data.Fixed.Vector.toVector x_a1ZjQ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zi7 / (1 + ((c_MiRs_a1ZjR / p_a1Zid) ** p_a1Zif)))
                                    + (negate (p_a1Zj3 * c_PTB_a1ZjT))),
                                   ((p_a1Zih
                                     / (1
                                        + ((((c_RESTc_a1ZjU / p_a1Zij) ** p_a1Zil)
                                            + ((c_MiRs_a1ZjR / p_a1Zin) ** p_a1Zip))
                                           + ((c_PTB_a1ZjT / p_a1Zir) ** p_a1Zit))))
                                    + (negate (p_a1Zj5 * c_NPTB_a1ZjY))),
                                   ((p_a1Ziv
                                     * (p_a1ZiF
                                        / ((1 + p_a1ZiF) + ((c_RESTc_a1ZjU / p_a1ZiB) ** p_a1ZiD))))
                                    + (negate (p_a1Zj7 * c_MiRs_a1ZjR))),
                                   ((p_a1ZiH
                                     * ((p_a1ZiV + ((c_PTB_a1ZjT / p_a1ZiJ) ** p_a1ZiL))
                                        / (((1 + p_a1ZiV) + ((c_PTB_a1ZjT / p_a1ZiJ) ** p_a1ZiL))
                                           + ((c_MiRs_a1ZjR / p_a1ZiR) ** p_a1ZiT))))
                                    + (negate (p_a1Zj9 * c_RESTc_a1ZjU))),
                                   ((p_a1ZiX / (1 + ((c_RESTc_a1ZjU / p_a1ZiZ) ** p_a1Zj1)))
                                    + (negate (p_a1Zjb * c_EndoNeuroTFs_a1Zk9)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483719",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483729",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483731",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483733",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483735",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483753",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483755",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483763",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483765",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483769",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483771",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483783",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483785",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zjc
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZkL
                            p_a1Zjb = double g_a1Zja
                            (g_a1Zja, gpart_a1ZkL) = Genome.Split.split gpart_a1ZkK
                            p_a1Zj9 = double g_a1Zj8
                            (g_a1Zj8, gpart_a1ZkK) = Genome.Split.split gpart_a1ZkJ
                            p_a1Zj7 = double g_a1Zj6
                            (g_a1Zj6, gpart_a1ZkJ) = Genome.Split.split gpart_a1ZkI
                            p_a1Zj5 = double g_a1Zj4
                            (g_a1Zj4, gpart_a1ZkI) = Genome.Split.split gpart_a1ZkH
                            p_a1Zj3 = double g_a1Zj2
                            (g_a1Zj2, gpart_a1ZkH) = Genome.Split.split gpart_a1ZkG
                            p_a1Zj1 = Functions.belowten' g_a1Zj0
                            (g_a1Zj0, gpart_a1ZkG) = Genome.Split.split gpart_a1ZkF
                            p_a1ZiZ = double g_a1ZiY
                            (g_a1ZiY, gpart_a1ZkF) = Genome.Split.split gpart_a1ZkE
                            p_a1ZiX = double g_a1ZiW
                            (g_a1ZiW, gpart_a1ZkE) = Genome.Split.split gpart_a1ZkD
                            p_a1ZiV = double g_a1ZiU
                            (g_a1ZiU, gpart_a1ZkD) = Genome.Split.split gpart_a1ZkC
                            p_a1ZiT = Functions.belowten' g_a1ZiS
                            (g_a1ZiS, gpart_a1ZkC) = Genome.Split.split gpart_a1ZkB
                            p_a1ZiR = double g_a1ZiQ
                            (g_a1ZiQ, gpart_a1ZkB) = Genome.Split.split gpart_a1ZkA
                            p_a1ZiP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZiO
                            (g_a1ZiO, gpart_a1ZkA) = Genome.Split.split gpart_a1Zkz
                            p_a1ZiN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZiM
                            (g_a1ZiM, gpart_a1Zkz) = Genome.Split.split gpart_a1Zky
                            p_a1ZiL = Functions.belowten' g_a1ZiK
                            (g_a1ZiK, gpart_a1Zky) = Genome.Split.split gpart_a1Zkx
                            p_a1ZiJ = double g_a1ZiI
                            (g_a1ZiI, gpart_a1Zkx) = Genome.Split.split gpart_a1Zkw
                            p_a1ZiH = double g_a1ZiG
                            (g_a1ZiG, gpart_a1Zkw) = Genome.Split.split gpart_a1Zkv
                            p_a1ZiF = double g_a1ZiE
                            (g_a1ZiE, gpart_a1Zkv) = Genome.Split.split gpart_a1Zku
                            p_a1ZiD = Functions.belowten' g_a1ZiC
                            (g_a1ZiC, gpart_a1Zku) = Genome.Split.split gpart_a1Zkt
                            p_a1ZiB = double g_a1ZiA
                            (g_a1ZiA, gpart_a1Zkt) = Genome.Split.split gpart_a1Zks
                            p_a1Ziz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ziy
                            (g_a1Ziy, gpart_a1Zks) = Genome.Split.split gpart_a1Zkr
                            p_a1Zix
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ziw
                            (g_a1Ziw, gpart_a1Zkr) = Genome.Split.split gpart_a1Zkq
                            p_a1Ziv = double g_a1Ziu
                            (g_a1Ziu, gpart_a1Zkq) = Genome.Split.split gpart_a1Zkp
                            p_a1Zit = Functions.belowten' g_a1Zis
                            (g_a1Zis, gpart_a1Zkp) = Genome.Split.split gpart_a1Zko
                            p_a1Zir = double g_a1Ziq
                            (g_a1Ziq, gpart_a1Zko) = Genome.Split.split gpart_a1Zkn
                            p_a1Zip = Functions.belowten' g_a1Zio
                            (g_a1Zio, gpart_a1Zkn) = Genome.Split.split gpart_a1Zkm
                            p_a1Zin = double g_a1Zim
                            (g_a1Zim, gpart_a1Zkm) = Genome.Split.split gpart_a1Zkl
                            p_a1Zil = Functions.belowten' g_a1Zik
                            (g_a1Zik, gpart_a1Zkl) = Genome.Split.split gpart_a1Zkk
                            p_a1Zij = double g_a1Zii
                            (g_a1Zii, gpart_a1Zkk) = Genome.Split.split gpart_a1Zkj
                            p_a1Zih = double g_a1Zig
                            (g_a1Zig, gpart_a1Zkj) = Genome.Split.split gpart_a1Zki
                            p_a1Zif = Functions.belowten' g_a1Zie
                            (g_a1Zie, gpart_a1Zki) = Genome.Split.split gpart_a1Zkh
                            p_a1Zid = double g_a1Zic
                            (g_a1Zic, gpart_a1Zkh) = Genome.Split.split gpart_a1Zkg
                            p_a1Zib
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zia
                            (g_a1Zia, gpart_a1Zkg) = Genome.Split.split gpart_a1Zkf
                            p_a1Zi9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zi8
                            (g_a1Zi8, gpart_a1Zkf) = Genome.Split.split gpart_a1Zke
                            p_a1Zi7 = double g_a1Zi6
                            (g_a1Zi6, gpart_a1Zke) = Genome.Split.split gpart_a1Zkd
                            p_a1Zi5 = double g_a1Zi4
                            (g_a1Zi4, gpart_a1Zkd) = Genome.Split.split gpart_a1Zkc
                            p_a1Zi3 = double g_a1Zi2
                            (g_a1Zi2, gpart_a1Zkc) = Genome.Split.split gpart_a1Zkb
                            p_a1Zi1 = double g_a1Zi0
                            (g_a1Zi0, gpart_a1Zkb) = Genome.Split.split gpart_a1Zka
                            p_a1ZhZ = double g_a1ZhY
                            (g_a1ZhY, gpart_a1Zka) = Genome.Split.split genome_a1Zjc
                          in
                            \ desc_a1Zjd
                              -> case desc_a1Zjd of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhZ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi1)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi3)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi5)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi7)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi9)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zib)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zid)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zif)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zih)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zij)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zil)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zin)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zip)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zir)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zit)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ziv)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zix)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ziz)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiB)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiD)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiF)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiH)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiJ)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiL)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiN)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiP)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiR)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiT)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiV)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiX)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiZ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zj1)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zj3)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zj5)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zj7)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zj9)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjb)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zn9
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZnM
                      p_a1Zn8 = double g_a1Zn7
                      (g_a1Zn7, gpart_a1ZnM) = Genome.Split.split gpart_a1ZnL
                      p_a1Zn6 = double g_a1Zn5
                      (g_a1Zn5, gpart_a1ZnL) = Genome.Split.split gpart_a1ZnK
                      p_a1Zn4 = double g_a1Zn3
                      (g_a1Zn3, gpart_a1ZnK) = Genome.Split.split gpart_a1ZnJ
                      p_a1Zn2 = double g_a1Zn1
                      (g_a1Zn1, gpart_a1ZnJ) = Genome.Split.split gpart_a1ZnI
                      p_a1Zn0 = double g_a1ZmZ
                      (g_a1ZmZ, gpart_a1ZnI) = Genome.Split.split gpart_a1ZnH
                      p_a1ZmY = Functions.belowten' g_a1ZmX
                      (g_a1ZmX, gpart_a1ZnH) = Genome.Split.split gpart_a1ZnG
                      p_a1ZmW = double g_a1ZmV
                      (g_a1ZmV, gpart_a1ZnG) = Genome.Split.split gpart_a1ZnF
                      p_a1ZmU = double g_a1ZmT
                      (g_a1ZmT, gpart_a1ZnF) = Genome.Split.split gpart_a1ZnE
                      p_a1ZmS = double g_a1ZmR
                      (g_a1ZmR, gpart_a1ZnE) = Genome.Split.split gpart_a1ZnD
                      p_a1ZmQ = Functions.belowten' g_a1ZmP
                      (g_a1ZmP, gpart_a1ZnD) = Genome.Split.split gpart_a1ZnC
                      p_a1ZmO = double g_a1ZmN
                      (g_a1ZmN, gpart_a1ZnC) = Genome.Split.split gpart_a1ZnB
                      p_a1ZmM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmL
                      (g_a1ZmL, gpart_a1ZnB) = Genome.Split.split gpart_a1ZnA
                      p_a1ZmK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmJ
                      (g_a1ZmJ, gpart_a1ZnA) = Genome.Split.split gpart_a1Znz
                      p_a1ZmI = Functions.belowten' g_a1ZmH
                      (g_a1ZmH, gpart_a1Znz) = Genome.Split.split gpart_a1Zny
                      p_a1ZmG = double g_a1ZmF
                      (g_a1ZmF, gpart_a1Zny) = Genome.Split.split gpart_a1Znx
                      p_a1ZmE = double g_a1ZmD
                      (g_a1ZmD, gpart_a1Znx) = Genome.Split.split gpart_a1Znw
                      p_a1ZmC = double g_a1ZmB
                      (g_a1ZmB, gpart_a1Znw) = Genome.Split.split gpart_a1Znv
                      p_a1ZmA = Functions.belowten' g_a1Zmz
                      (g_a1Zmz, gpart_a1Znv) = Genome.Split.split gpart_a1Znu
                      p_a1Zmy = double g_a1Zmx
                      (g_a1Zmx, gpart_a1Znu) = Genome.Split.split gpart_a1Znt
                      p_a1Zmw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmv
                      (g_a1Zmv, gpart_a1Znt) = Genome.Split.split gpart_a1Zns
                      p_a1Zmu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmt
                      (g_a1Zmt, gpart_a1Zns) = Genome.Split.split gpart_a1Znr
                      p_a1Zms = double g_a1Zmr
                      (g_a1Zmr, gpart_a1Znr) = Genome.Split.split gpart_a1Znq
                      p_a1Zmq = Functions.belowten' g_a1Zmp
                      (g_a1Zmp, gpart_a1Znq) = Genome.Split.split gpart_a1Znp
                      p_a1Zmo = double g_a1Zmn
                      (g_a1Zmn, gpart_a1Znp) = Genome.Split.split gpart_a1Zno
                      p_a1Zmm = Functions.belowten' g_a1Zml
                      (g_a1Zml, gpart_a1Zno) = Genome.Split.split gpart_a1Znn
                      p_a1Zmk = double g_a1Zmj
                      (g_a1Zmj, gpart_a1Znn) = Genome.Split.split gpart_a1Znm
                      p_a1Zmi = Functions.belowten' g_a1Zmh
                      (g_a1Zmh, gpart_a1Znm) = Genome.Split.split gpart_a1Znl
                      p_a1Zmg = double g_a1Zmf
                      (g_a1Zmf, gpart_a1Znl) = Genome.Split.split gpart_a1Znk
                      p_a1Zme = double g_a1Zmd
                      (g_a1Zmd, gpart_a1Znk) = Genome.Split.split gpart_a1Znj
                      p_a1Zmc = Functions.belowten' g_a1Zmb
                      (g_a1Zmb, gpart_a1Znj) = Genome.Split.split gpart_a1Zni
                      p_a1Zma = double g_a1Zm9
                      (g_a1Zm9, gpart_a1Zni) = Genome.Split.split gpart_a1Znh
                      p_a1Zm8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm7
                      (g_a1Zm7, gpart_a1Znh) = Genome.Split.split gpart_a1Zng
                      p_a1Zm6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm5
                      (g_a1Zm5, gpart_a1Zng) = Genome.Split.split gpart_a1Znf
                      p_a1Zm4 = double g_a1Zm3
                      (g_a1Zm3, gpart_a1Znf) = Genome.Split.split gpart_a1Zne
                      p_a1Zm2 = double g_a1Zm1
                      (g_a1Zm1, gpart_a1Zne) = Genome.Split.split gpart_a1Znd
                      p_a1Zm0 = double g_a1ZlZ
                      (g_a1ZlZ, gpart_a1Znd) = Genome.Split.split gpart_a1Znc
                      p_a1ZlY = double g_a1ZlX
                      (g_a1ZlX, gpart_a1Znc) = Genome.Split.split gpart_a1Znb
                      p_a1ZlW = double g_a1ZlV
                      (g_a1ZlV, gpart_a1Znb) = Genome.Split.split genome_a1Zn9
                    in  \ x_a1ZnN
                          -> let
                               c_PTB_a1ZnQ
                                 = ((Data.Fixed.Vector.toVector x_a1ZnN) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1ZnO
                                 = ((Data.Fixed.Vector.toVector x_a1ZnN) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1ZnV
                                 = ((Data.Fixed.Vector.toVector x_a1ZnN) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1ZnR
                                 = ((Data.Fixed.Vector.toVector x_a1ZnN) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zo6
                                 = ((Data.Fixed.Vector.toVector x_a1ZnN) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zm4
                                     / (1
                                        + (((p_a1ZlW / p_a1Zm6) ** p_a1Zm8)
                                           + ((c_MiRs_a1ZnO / p_a1Zma) ** p_a1Zmc))))
                                    + (negate (p_a1Zn0 * c_PTB_a1ZnQ))),
                                   ((p_a1Zme
                                     / (1
                                        + ((((c_RESTc_a1ZnR / p_a1Zmg) ** p_a1Zmi)
                                            + ((c_MiRs_a1ZnO / p_a1Zmk) ** p_a1Zmm))
                                           + ((c_PTB_a1ZnQ / p_a1Zmo) ** p_a1Zmq))))
                                    + (negate (p_a1Zn2 * c_NPTB_a1ZnV))),
                                   ((p_a1Zms
                                     * (p_a1ZmC
                                        / ((1 + p_a1ZmC) + ((c_RESTc_a1ZnR / p_a1Zmy) ** p_a1ZmA))))
                                    + (negate (p_a1Zn4 * c_MiRs_a1ZnO))),
                                   ((p_a1ZmE
                                     * ((p_a1ZmS + ((c_PTB_a1ZnQ / p_a1ZmG) ** p_a1ZmI))
                                        / (((1 + p_a1ZmS) + ((c_PTB_a1ZnQ / p_a1ZmG) ** p_a1ZmI))
                                           + ((c_MiRs_a1ZnO / p_a1ZmO) ** p_a1ZmQ))))
                                    + (negate (p_a1Zn6 * c_RESTc_a1ZnR))),
                                   ((p_a1ZmU / (1 + ((c_RESTc_a1ZnR / p_a1ZmW) ** p_a1ZmY)))
                                    + (negate (p_a1Zn8 * c_EndoNeuroTFs_a1Zo6)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483974",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483976",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483998",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484000",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484014",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484016",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zn9
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZoI
                            p_a1Zn8 = double g_a1Zn7
                            (g_a1Zn7, gpart_a1ZoI) = Genome.Split.split gpart_a1ZoH
                            p_a1Zn6 = double g_a1Zn5
                            (g_a1Zn5, gpart_a1ZoH) = Genome.Split.split gpart_a1ZoG
                            p_a1Zn4 = double g_a1Zn3
                            (g_a1Zn3, gpart_a1ZoG) = Genome.Split.split gpart_a1ZoF
                            p_a1Zn2 = double g_a1Zn1
                            (g_a1Zn1, gpart_a1ZoF) = Genome.Split.split gpart_a1ZoE
                            p_a1Zn0 = double g_a1ZmZ
                            (g_a1ZmZ, gpart_a1ZoE) = Genome.Split.split gpart_a1ZoD
                            p_a1ZmY = Functions.belowten' g_a1ZmX
                            (g_a1ZmX, gpart_a1ZoD) = Genome.Split.split gpart_a1ZoC
                            p_a1ZmW = double g_a1ZmV
                            (g_a1ZmV, gpart_a1ZoC) = Genome.Split.split gpart_a1ZoB
                            p_a1ZmU = double g_a1ZmT
                            (g_a1ZmT, gpart_a1ZoB) = Genome.Split.split gpart_a1ZoA
                            p_a1ZmS = double g_a1ZmR
                            (g_a1ZmR, gpart_a1ZoA) = Genome.Split.split gpart_a1Zoz
                            p_a1ZmQ = Functions.belowten' g_a1ZmP
                            (g_a1ZmP, gpart_a1Zoz) = Genome.Split.split gpart_a1Zoy
                            p_a1ZmO = double g_a1ZmN
                            (g_a1ZmN, gpart_a1Zoy) = Genome.Split.split gpart_a1Zox
                            p_a1ZmM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmL
                            (g_a1ZmL, gpart_a1Zox) = Genome.Split.split gpart_a1Zow
                            p_a1ZmK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZmJ
                            (g_a1ZmJ, gpart_a1Zow) = Genome.Split.split gpart_a1Zov
                            p_a1ZmI = Functions.belowten' g_a1ZmH
                            (g_a1ZmH, gpart_a1Zov) = Genome.Split.split gpart_a1Zou
                            p_a1ZmG = double g_a1ZmF
                            (g_a1ZmF, gpart_a1Zou) = Genome.Split.split gpart_a1Zot
                            p_a1ZmE = double g_a1ZmD
                            (g_a1ZmD, gpart_a1Zot) = Genome.Split.split gpart_a1Zos
                            p_a1ZmC = double g_a1ZmB
                            (g_a1ZmB, gpart_a1Zos) = Genome.Split.split gpart_a1Zor
                            p_a1ZmA = Functions.belowten' g_a1Zmz
                            (g_a1Zmz, gpart_a1Zor) = Genome.Split.split gpart_a1Zoq
                            p_a1Zmy = double g_a1Zmx
                            (g_a1Zmx, gpart_a1Zoq) = Genome.Split.split gpart_a1Zop
                            p_a1Zmw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmv
                            (g_a1Zmv, gpart_a1Zop) = Genome.Split.split gpart_a1Zoo
                            p_a1Zmu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmt
                            (g_a1Zmt, gpart_a1Zoo) = Genome.Split.split gpart_a1Zon
                            p_a1Zms = double g_a1Zmr
                            (g_a1Zmr, gpart_a1Zon) = Genome.Split.split gpart_a1Zom
                            p_a1Zmq = Functions.belowten' g_a1Zmp
                            (g_a1Zmp, gpart_a1Zom) = Genome.Split.split gpart_a1Zol
                            p_a1Zmo = double g_a1Zmn
                            (g_a1Zmn, gpart_a1Zol) = Genome.Split.split gpart_a1Zok
                            p_a1Zmm = Functions.belowten' g_a1Zml
                            (g_a1Zml, gpart_a1Zok) = Genome.Split.split gpart_a1Zoj
                            p_a1Zmk = double g_a1Zmj
                            (g_a1Zmj, gpart_a1Zoj) = Genome.Split.split gpart_a1Zoi
                            p_a1Zmi = Functions.belowten' g_a1Zmh
                            (g_a1Zmh, gpart_a1Zoi) = Genome.Split.split gpart_a1Zoh
                            p_a1Zmg = double g_a1Zmf
                            (g_a1Zmf, gpart_a1Zoh) = Genome.Split.split gpart_a1Zog
                            p_a1Zme = double g_a1Zmd
                            (g_a1Zmd, gpart_a1Zog) = Genome.Split.split gpart_a1Zof
                            p_a1Zmc = Functions.belowten' g_a1Zmb
                            (g_a1Zmb, gpart_a1Zof) = Genome.Split.split gpart_a1Zoe
                            p_a1Zma = double g_a1Zm9
                            (g_a1Zm9, gpart_a1Zoe) = Genome.Split.split gpart_a1Zod
                            p_a1Zm8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm7
                            (g_a1Zm7, gpart_a1Zod) = Genome.Split.split gpart_a1Zoc
                            p_a1Zm6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm5
                            (g_a1Zm5, gpart_a1Zoc) = Genome.Split.split gpart_a1Zob
                            p_a1Zm4 = double g_a1Zm3
                            (g_a1Zm3, gpart_a1Zob) = Genome.Split.split gpart_a1Zoa
                            p_a1Zm2 = double g_a1Zm1
                            (g_a1Zm1, gpart_a1Zoa) = Genome.Split.split gpart_a1Zo9
                            p_a1Zm0 = double g_a1ZlZ
                            (g_a1ZlZ, gpart_a1Zo9) = Genome.Split.split gpart_a1Zo8
                            p_a1ZlY = double g_a1ZlX
                            (g_a1ZlX, gpart_a1Zo8) = Genome.Split.split gpart_a1Zo7
                            p_a1ZlW = double g_a1ZlV
                            (g_a1ZlV, gpart_a1Zo7) = Genome.Split.split genome_a1Zn9
                          in
                            \ desc_a1Zna
                              -> case desc_a1Zna of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlW)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlY)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm0)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm2)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm4)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm6)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm8)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zma)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmc)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zme)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmg)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmi)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmk)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmm)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmo)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmq)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zms)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmu)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmw)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmy)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmA)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmC)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmE)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmG)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmI)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmK)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmM)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmO)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmQ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmS)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmU)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmW)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZmY)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn0)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn2)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn4)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn6)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zn8)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV1
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVE
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                      (g_asUX, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                      (g_asUT, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUQ = Functions.belowten' g_asUP
                      (g_asUP, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                      (g_asUN, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                      (g_asUL, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                      (g_asUJ, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUI = Functions.belowten' g_asUH
                      (g_asUH, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                      (g_asUF, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUD
                      (g_asUD, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUB
                      (g_asUB, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUA = Functions.belowten' g_asUz
                      (g_asUz, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                      (g_asUv, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                      (g_asUt, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUs = Functions.belowten' g_asUr
                      (g_asUr, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                      (g_asUp, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                      (g_asUn, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUl
                      (g_asUl, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asUi = Functions.belowten' g_asUh
                      (g_asUh, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asUe = Functions.belowten' g_asUd
                      (g_asUd, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asUa = Functions.belowten' g_asU9
                      (g_asU9, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                      (g_asU7, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asU4 = Functions.belowten' g_asU3
                      (g_asU3, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asVa) = Genome.Split.split gpart_asV9
                      p_asU0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTZ
                      (g_asTZ, gpart_asV9) = Genome.Split.split gpart_asV8
                      p_asTY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTX
                      (g_asTX, gpart_asV8) = Genome.Split.split gpart_asV7
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asV7) = Genome.Split.split gpart_asV6
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asV6) = Genome.Split.split gpart_asV5
                      p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                      (g_asTR, gpart_asV5) = Genome.Split.split gpart_asV4
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asV4) = Genome.Split.split gpart_asV3
                      p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                      (g_asTN, gpart_asV3) = Genome.Split.split genome_asV1
                    in
                      [Reaction
                         (\ x_asVF
                            -> let c_MiRs_asVG = ((toVector x_asVF) Data.Vector.Unboxed.! 2)
                               in (p_asTW / (1 + ((c_MiRs_asVG / p_asU2) ** p_asU4))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVH
                            -> let
                                 c_MiRs_asVJ = ((toVector x_asVH) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asVI = ((toVector x_asVH) Data.Vector.Unboxed.! 3)
                                 c_PTB_asVK = ((toVector x_asVH) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asU6
                                  / (1
                                     + ((((c_RESTc_asVI / p_asU8) ** p_asUa)
                                         + ((c_MiRs_asVJ / p_asUc) ** p_asUe))
                                        + ((c_PTB_asVK / p_asUg) ** p_asUi)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVL
                            -> let c_RESTc_asVM = ((toVector x_asVL) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUk
                                  * ((p_asUu + ((p_asTS / p_asUm) ** p_asUo))
                                     / (((1 + p_asUu) + ((p_asTS / p_asUm) ** p_asUo))
                                        + ((c_RESTc_asVM / p_asUq) ** p_asUs)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVN
                            -> let
                                 c_MiRs_asVQ = ((toVector x_asVN) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVO = ((toVector x_asVN) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUw
                                  * ((p_asUK + ((c_PTB_asVO / p_asUy) ** p_asUA))
                                     / (((1 + p_asUK) + ((c_PTB_asVO / p_asUy) ** p_asUA))
                                        + (((p_asTO / p_asUC) ** p_asUE)
                                           + ((c_MiRs_asVQ / p_asUG) ** p_asUI))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVR
                            -> let c_RESTc_asVS = ((toVector x_asVR) Data.Vector.Unboxed.! 3)
                               in (p_asUM / (1 + ((c_RESTc_asVS / p_asUO) ** p_asUQ))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asVT
                            -> let c_PTB_asVU = ((toVector x_asVT) Data.Vector.Unboxed.! 0)
                               in (p_asUS * c_PTB_asVU))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVV
                            -> let c_NPTB_asVW = ((toVector x_asVV) Data.Vector.Unboxed.! 1)
                               in (p_asUU * c_NPTB_asVW))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asVX
                            -> let c_MiRs_asVY = ((toVector x_asVX) Data.Vector.Unboxed.! 2)
                               in (p_asUW * c_MiRs_asVY))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asVZ
                            -> let c_RESTc_asW0 = ((toVector x_asVZ) Data.Vector.Unboxed.! 3)
                               in (p_asUY * c_RESTc_asW0))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asW1
                            -> let
                                 c_EndoNeuroTFs_asW2 = ((toVector x_asW1) Data.Vector.Unboxed.! 4)
                               in (p_asV0 * c_EndoNeuroTFs_asW2))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV1
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWJ
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUY = code-0.1.0.0:Genome.FixedList.Functions.double g_asUX
                            (g_asUX, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUU = code-0.1.0.0:Genome.FixedList.Functions.double g_asUT
                            (g_asUT, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUQ = Functions.belowten' g_asUP
                            (g_asUP, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                            (g_asUN, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUM = code-0.1.0.0:Genome.FixedList.Functions.double g_asUL
                            (g_asUL, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                            (g_asUJ, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUI = Functions.belowten' g_asUH
                            (g_asUH, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUG = code-0.1.0.0:Genome.FixedList.Functions.double g_asUF
                            (g_asUF, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUD
                            (g_asUD, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUB
                            (g_asUB, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUA = Functions.belowten' g_asUz
                            (g_asUz, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUw = code-0.1.0.0:Genome.FixedList.Functions.double g_asUv
                            (g_asUv, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                            (g_asUt, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asUs = Functions.belowten' g_asUr
                            (g_asUr, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                            (g_asUp, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asUo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                            (g_asUn, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asUm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUl
                            (g_asUl, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asUi = Functions.belowten' g_asUh
                            (g_asUh, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asUe = Functions.belowten' g_asUd
                            (g_asUd, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asUa = Functions.belowten' g_asU9
                            (g_asU9, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                            (g_asU7, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asU4 = Functions.belowten' g_asU3
                            (g_asU3, gpart_asWg) = Genome.Split.split gpart_asWf
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asWf) = Genome.Split.split gpart_asWe
                            p_asU0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTZ
                            (g_asTZ, gpart_asWe) = Genome.Split.split gpart_asWd
                            p_asTY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTX
                            (g_asTX, gpart_asWd) = Genome.Split.split gpart_asWc
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asWc) = Genome.Split.split gpart_asWb
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asWb) = Genome.Split.split gpart_asWa
                            p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                            (g_asTR, gpart_asWa) = Genome.Split.split gpart_asW9
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asW9) = Genome.Split.split gpart_asW8
                            p_asTO = code-0.1.0.0:Genome.FixedList.Functions.double g_asTN
                            (g_asTN, gpart_asW8) = Genome.Split.split genome_asV1
                          in
                            \ desc_asV2
                              -> case desc_asV2 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYE
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZh
                      p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                      (g_asYC, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asYz = code-0.1.0.0:Genome.FixedList.Functions.double g_asYy
                      (g_asYy, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                      (g_asYu, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asYt = Functions.belowten' g_asYs
                      (g_asYs, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asYl = Functions.belowten' g_asYk
                      (g_asYk, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                      (g_asYi, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asYh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                      (g_asYg, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asYf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                      (g_asYe, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asYd = Functions.belowten' g_asYc
                      (g_asYc, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asY5 = Functions.belowten' g_asY4
                      (g_asY4, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asY1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY0
                      (g_asY0, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXY
                      (g_asXY, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asXV = Functions.belowten' g_asXU
                      (g_asXU, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asXR = Functions.belowten' g_asXQ
                      (g_asXQ, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asXN = Functions.belowten' g_asXM
                      (g_asXM, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asXH = Functions.belowten' g_asXG
                      (g_asXG, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asYN) = Genome.Split.split gpart_asYM
                      p_asXD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXC
                      (g_asXC, gpart_asYM) = Genome.Split.split gpart_asYL
                      p_asXB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXA
                      (g_asXA, gpart_asYL) = Genome.Split.split gpart_asYK
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYK) = Genome.Split.split gpart_asYJ
                      p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                      (g_asXw, gpart_asYJ) = Genome.Split.split gpart_asYI
                      p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                      (g_asXu, gpart_asYI) = Genome.Split.split gpart_asYH
                      p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                      (g_asXs, gpart_asYH) = Genome.Split.split gpart_asYG
                      p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                      (g_asXq, gpart_asYG) = Genome.Split.split genome_asYE
                    in
                      [Reaction
                         (\ x_asZi
                            -> let c_MiRs_asZj = ((toVector x_asZi) Data.Vector.Unboxed.! 2)
                               in (p_asXz / (1 + ((c_MiRs_asZj / p_asXF) ** p_asXH))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZk
                            -> let
                                 c_MiRs_asZm = ((toVector x_asZk) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asZl = ((toVector x_asZk) Data.Vector.Unboxed.! 3)
                                 c_PTB_asZn = ((toVector x_asZk) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXJ
                                  / (1
                                     + ((((c_RESTc_asZl / p_asXL) ** p_asXN)
                                         + ((c_MiRs_asZm / p_asXP) ** p_asXR))
                                        + ((c_PTB_asZn / p_asXT) ** p_asXV)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZo
                            -> let c_RESTc_asZp = ((toVector x_asZo) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asXX
                                  * (p_asY7
                                     / ((1 + p_asY7) + ((c_RESTc_asZp / p_asY3) ** p_asY5)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZq
                            -> let
                                 c_MiRs_asZt = ((toVector x_asZq) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZr = ((toVector x_asZq) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY9
                                  * ((p_asYn + ((c_PTB_asZr / p_asYb) ** p_asYd))
                                     / (((1 + p_asYn) + ((c_PTB_asZr / p_asYb) ** p_asYd))
                                        + (((p_asXr / p_asYf) ** p_asYh)
                                           + ((c_MiRs_asZt / p_asYj) ** p_asYl))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZu
                            -> let c_RESTc_asZv = ((toVector x_asZu) Data.Vector.Unboxed.! 3)
                               in (p_asYp / (1 + ((c_RESTc_asZv / p_asYr) ** p_asYt))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZw
                            -> let c_PTB_asZx = ((toVector x_asZw) Data.Vector.Unboxed.! 0)
                               in (p_asYv * c_PTB_asZx))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZy
                            -> let c_NPTB_asZz = ((toVector x_asZy) Data.Vector.Unboxed.! 1)
                               in (p_asYx * c_NPTB_asZz))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZA
                            -> let c_MiRs_asZB = ((toVector x_asZA) Data.Vector.Unboxed.! 2)
                               in (p_asYz * c_MiRs_asZB))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZC
                            -> let c_RESTc_asZD = ((toVector x_asZC) Data.Vector.Unboxed.! 3)
                               in (p_asYB * c_RESTc_asZD))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZE
                            -> let
                                 c_EndoNeuroTFs_asZF = ((toVector x_asZE) Data.Vector.Unboxed.! 4)
                               in (p_asYD * c_EndoNeuroTFs_asZF))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYE
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0h
                            p_asYD = code-0.1.0.0:Genome.FixedList.Functions.double g_asYC
                            (g_asYC, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asYz = code-0.1.0.0:Genome.FixedList.Functions.double g_asYy
                            (g_asYy, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                            (g_asYu, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asYt = Functions.belowten' g_asYs
                            (g_asYs, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at09) = Genome.Split.split gpart_at08
                            p_asYl = Functions.belowten' g_asYk
                            (g_asYk, gpart_at08) = Genome.Split.split gpart_at07
                            p_asYj = code-0.1.0.0:Genome.FixedList.Functions.double g_asYi
                            (g_asYi, gpart_at07) = Genome.Split.split gpart_at06
                            p_asYh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                            (g_asYg, gpart_at06) = Genome.Split.split gpart_at05
                            p_asYf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                            (g_asYe, gpart_at05) = Genome.Split.split gpart_at04
                            p_asYd = Functions.belowten' g_asYc
                            (g_asYc, gpart_at04) = Genome.Split.split gpart_at03
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at03) = Genome.Split.split gpart_at02
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at02) = Genome.Split.split gpart_at01
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_at01) = Genome.Split.split gpart_at00
                            p_asY5 = Functions.belowten' g_asY4
                            (g_asY4, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asY1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY0
                            (g_asY0, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asXZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXY
                            (g_asXY, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asXV = Functions.belowten' g_asXU
                            (g_asXU, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asXR = Functions.belowten' g_asXQ
                            (g_asXQ, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXN = Functions.belowten' g_asXM
                            (g_asXM, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXH = Functions.belowten' g_asXG
                            (g_asXG, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_asZN) = Genome.Split.split gpart_asZM
                            p_asXD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXC
                            (g_asXC, gpart_asZM) = Genome.Split.split gpart_asZL
                            p_asXB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXA
                            (g_asXA, gpart_asZL) = Genome.Split.split gpart_asZK
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZK) = Genome.Split.split gpart_asZJ
                            p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                            (g_asXw, gpart_asZJ) = Genome.Split.split gpart_asZI
                            p_asXv = code-0.1.0.0:Genome.FixedList.Functions.double g_asXu
                            (g_asXu, gpart_asZI) = Genome.Split.split gpart_asZH
                            p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                            (g_asXs, gpart_asZH) = Genome.Split.split gpart_asZG
                            p_asXr = code-0.1.0.0:Genome.FixedList.Functions.double g_asXq
                            (g_asXq, gpart_asZG) = Genome.Split.split genome_asYE
                          in
                            \ desc_asYF
                              -> case desc_asYF of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2c
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2P
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at29 = code-0.1.0.0:Genome.FixedList.Functions.double g_at28
                      (g_at28, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                      (g_at26, gpart_at2N) = Genome.Split.split gpart_at2M
                      p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                      (g_at24, gpart_at2M) = Genome.Split.split gpart_at2L
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at2L) = Genome.Split.split gpart_at2K
                      p_at21 = Functions.belowten' g_at20
                      (g_at20, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                      (g_at1Y, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                      (g_at1W, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at1V = code-0.1.0.0:Genome.FixedList.Functions.double g_at1U
                      (g_at1U, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1T = Functions.belowten' g_at1S
                      (g_at1S, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                      (g_at1Q, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1O
                      (g_at1O, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1M
                      (g_at1M, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1L = Functions.belowten' g_at1K
                      (g_at1K, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                      (g_at1I, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                      (g_at1G, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                      (g_at1E, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1D = Functions.belowten' g_at1C
                      (g_at1C, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1B = code-0.1.0.0:Genome.FixedList.Functions.double g_at1A
                      (g_at1A, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1y
                      (g_at1y, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1w
                      (g_at1w, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                      (g_at1u, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1t = Functions.belowten' g_at1s
                      (g_at1s, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                      (g_at1q, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1p = Functions.belowten' g_at1o
                      (g_at1o, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                      (g_at1m, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1l = Functions.belowten' g_at1k
                      (g_at1k, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                      (g_at1g, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at1f = Functions.belowten' g_at1e
                      (g_at1e, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                      (g_at1c, gpart_at2l) = Genome.Split.split gpart_at2k
                      p_at1b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1a
                      (g_at1a, gpart_at2k) = Genome.Split.split gpart_at2j
                      p_at19
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at18
                      (g_at18, gpart_at2j) = Genome.Split.split gpart_at2i
                      p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                      (g_at16, gpart_at2i) = Genome.Split.split gpart_at2h
                      p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                      (g_at14, gpart_at2h) = Genome.Split.split gpart_at2g
                      p_at13 = code-0.1.0.0:Genome.FixedList.Functions.double g_at12
                      (g_at12, gpart_at2g) = Genome.Split.split gpart_at2f
                      p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                      (g_at10, gpart_at2f) = Genome.Split.split gpart_at2e
                      p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                      (g_at0Y, gpart_at2e) = Genome.Split.split genome_at2c
                    in
                      [Reaction
                         (\ x_at2Q
                            -> let c_MiRs_at2R = ((toVector x_at2Q) Data.Vector.Unboxed.! 2)
                               in (p_at17 / (1 + ((c_MiRs_at2R / p_at1d) ** p_at1f))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2S
                            -> let
                                 c_MiRs_at2U = ((toVector x_at2S) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at2T = ((toVector x_at2S) Data.Vector.Unboxed.! 3)
                                 c_PTB_at2V = ((toVector x_at2S) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1h
                                  / (1
                                     + ((((c_RESTc_at2T / p_at1j) ** p_at1l)
                                         + ((c_MiRs_at2U / p_at1n) ** p_at1p))
                                        + ((c_PTB_at2V / p_at1r) ** p_at1t)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at2W
                            -> let c_RESTc_at2X = ((toVector x_at2W) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1v
                                  * (p_at1F
                                     / ((1 + p_at1F) + ((c_RESTc_at2X / p_at1B) ** p_at1D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at2Y
                            -> let
                                 c_MiRs_at31 = ((toVector x_at2Y) Data.Vector.Unboxed.! 2)
                                 c_PTB_at2Z = ((toVector x_at2Y) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1H
                                  * ((p_at1V + ((c_PTB_at2Z / p_at1J) ** p_at1L))
                                     / (((1 + p_at1V) + ((c_PTB_at2Z / p_at1J) ** p_at1L))
                                        + ((c_MiRs_at31 / p_at1R) ** p_at1T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at32
                            -> let c_RESTc_at33 = ((toVector x_at32) Data.Vector.Unboxed.! 3)
                               in (p_at1X / (1 + ((c_RESTc_at33 / p_at1Z) ** p_at21))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at34
                            -> let c_PTB_at35 = ((toVector x_at34) Data.Vector.Unboxed.! 0)
                               in (p_at23 * c_PTB_at35))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at36
                            -> let c_NPTB_at37 = ((toVector x_at36) Data.Vector.Unboxed.! 1)
                               in (p_at25 * c_NPTB_at37))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at38
                            -> let c_MiRs_at39 = ((toVector x_at38) Data.Vector.Unboxed.! 2)
                               in (p_at27 * c_MiRs_at39))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3a
                            -> let c_RESTc_at3b = ((toVector x_at3a) Data.Vector.Unboxed.! 3)
                               in (p_at29 * c_RESTc_at3b))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3c
                            -> let
                                 c_EndoNeuroTFs_at3d = ((toVector x_at3c) Data.Vector.Unboxed.! 4)
                               in (p_at2b * c_EndoNeuroTFs_at3d))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121355",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121363",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121365",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121379",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121381",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2c
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3P
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at29 = code-0.1.0.0:Genome.FixedList.Functions.double g_at28
                            (g_at28, gpart_at3O) = Genome.Split.split gpart_at3N
                            p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                            (g_at26, gpart_at3N) = Genome.Split.split gpart_at3M
                            p_at25 = code-0.1.0.0:Genome.FixedList.Functions.double g_at24
                            (g_at24, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at21 = Functions.belowten' g_at20
                            (g_at20, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Y
                            (g_at1Y, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                            (g_at1W, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1V = code-0.1.0.0:Genome.FixedList.Functions.double g_at1U
                            (g_at1U, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1T = Functions.belowten' g_at1S
                            (g_at1S, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1R = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Q
                            (g_at1Q, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1O
                            (g_at1O, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1M
                            (g_at1M, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1L = Functions.belowten' g_at1K
                            (g_at1K, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                            (g_at1I, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1H = code-0.1.0.0:Genome.FixedList.Functions.double g_at1G
                            (g_at1G, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1F = code-0.1.0.0:Genome.FixedList.Functions.double g_at1E
                            (g_at1E, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1D = Functions.belowten' g_at1C
                            (g_at1C, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1B = code-0.1.0.0:Genome.FixedList.Functions.double g_at1A
                            (g_at1A, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1y
                            (g_at1y, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1w
                            (g_at1w, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                            (g_at1u, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1t = Functions.belowten' g_at1s
                            (g_at1s, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1r = code-0.1.0.0:Genome.FixedList.Functions.double g_at1q
                            (g_at1q, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1p = Functions.belowten' g_at1o
                            (g_at1o, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1n = code-0.1.0.0:Genome.FixedList.Functions.double g_at1m
                            (g_at1m, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at1l = Functions.belowten' g_at1k
                            (g_at1k, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                            (g_at1g, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at1f = Functions.belowten' g_at1e
                            (g_at1e, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                            (g_at1c, gpart_at3l) = Genome.Split.split gpart_at3k
                            p_at1b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1a
                            (g_at1a, gpart_at3k) = Genome.Split.split gpart_at3j
                            p_at19
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at18
                            (g_at18, gpart_at3j) = Genome.Split.split gpart_at3i
                            p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                            (g_at16, gpart_at3i) = Genome.Split.split gpart_at3h
                            p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                            (g_at14, gpart_at3h) = Genome.Split.split gpart_at3g
                            p_at13 = code-0.1.0.0:Genome.FixedList.Functions.double g_at12
                            (g_at12, gpart_at3g) = Genome.Split.split gpart_at3f
                            p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                            (g_at10, gpart_at3f) = Genome.Split.split gpart_at3e
                            p_at0Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Y
                            (g_at0Y, gpart_at3e) = Genome.Split.split genome_at2c
                          in
                            \ desc_at2d
                              -> case desc_at2d of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1n)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1p)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1r)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1t)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1v)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1x)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1z)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1B)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1D)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1F)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1N)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1P)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1R)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1T)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1V)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5K
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6n
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                      (g_at5G, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5z = Functions.belowten' g_at5y
                      (g_at5y, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                      (g_at5u, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at5r = Functions.belowten' g_at5q
                      (g_at5q, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                      (g_at5o, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at5n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5m
                      (g_at5m, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at5l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                      (g_at5k, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at5j = Functions.belowten' g_at5i
                      (g_at5i, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at69) = Genome.Split.split gpart_at68
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at68) = Genome.Split.split gpart_at67
                      p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                      (g_at5c, gpart_at67) = Genome.Split.split gpart_at66
                      p_at5b = Functions.belowten' g_at5a
                      (g_at5a, gpart_at66) = Genome.Split.split gpart_at65
                      p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                      (g_at58, gpart_at65) = Genome.Split.split gpart_at64
                      p_at57
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at56
                      (g_at56, gpart_at64) = Genome.Split.split gpart_at63
                      p_at55
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                      (g_at54, gpart_at63) = Genome.Split.split gpart_at62
                      p_at53 = code-0.1.0.0:Genome.FixedList.Functions.double g_at52
                      (g_at52, gpart_at62) = Genome.Split.split gpart_at61
                      p_at51 = Functions.belowten' g_at50
                      (g_at50, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                      (g_at4Y, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4X = Functions.belowten' g_at4W
                      (g_at4W, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                      (g_at4U, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4T = Functions.belowten' g_at4S
                      (g_at4S, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at4N = Functions.belowten' g_at4M
                      (g_at4M, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5T) = Genome.Split.split gpart_at5S
                      p_at4J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                      (g_at4I, gpart_at5S) = Genome.Split.split gpart_at5R
                      p_at4H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4G
                      (g_at4G, gpart_at5R) = Genome.Split.split gpart_at5Q
                      p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                      (g_at4E, gpart_at5Q) = Genome.Split.split gpart_at5P
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5P) = Genome.Split.split gpart_at5O
                      p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                      (g_at4A, gpart_at5O) = Genome.Split.split gpart_at5N
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5N) = Genome.Split.split gpart_at5M
                      p_at4x = code-0.1.0.0:Genome.FixedList.Functions.double g_at4w
                      (g_at4w, gpart_at5M) = Genome.Split.split genome_at5K
                    in
                      [Reaction
                         (\ x_at6o
                            -> let c_MiRs_at6p = ((toVector x_at6o) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4F
                                  / (1
                                     + (((p_at4x / p_at4H) ** p_at4J)
                                        + ((c_MiRs_at6p / p_at4L) ** p_at4N)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6q
                            -> let
                                 c_MiRs_at6s = ((toVector x_at6q) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at6r = ((toVector x_at6q) Data.Vector.Unboxed.! 3)
                                 c_PTB_at6t = ((toVector x_at6q) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4P
                                  / (1
                                     + ((((c_RESTc_at6r / p_at4R) ** p_at4T)
                                         + ((c_MiRs_at6s / p_at4V) ** p_at4X))
                                        + ((c_PTB_at6t / p_at4Z) ** p_at51)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6u
                            -> let c_RESTc_at6v = ((toVector x_at6u) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at53
                                  * (p_at5d
                                     / ((1 + p_at5d) + ((c_RESTc_at6v / p_at59) ** p_at5b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6w
                            -> let
                                 c_MiRs_at6z = ((toVector x_at6w) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6x = ((toVector x_at6w) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5f
                                  * ((p_at5t + ((c_PTB_at6x / p_at5h) ** p_at5j))
                                     / (((1 + p_at5t) + ((c_PTB_at6x / p_at5h) ** p_at5j))
                                        + ((c_MiRs_at6z / p_at5p) ** p_at5r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6A
                            -> let c_RESTc_at6B = ((toVector x_at6A) Data.Vector.Unboxed.! 3)
                               in (p_at5v / (1 + ((c_RESTc_at6B / p_at5x) ** p_at5z))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6C
                            -> let c_PTB_at6D = ((toVector x_at6C) Data.Vector.Unboxed.! 0)
                               in (p_at5B * c_PTB_at6D))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6E
                            -> let c_NPTB_at6F = ((toVector x_at6E) Data.Vector.Unboxed.! 1)
                               in (p_at5D * c_NPTB_at6F))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6G
                            -> let c_MiRs_at6H = ((toVector x_at6G) Data.Vector.Unboxed.! 2)
                               in (p_at5F * c_MiRs_at6H))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6I
                            -> let c_RESTc_at6J = ((toVector x_at6I) Data.Vector.Unboxed.! 3)
                               in (p_at5H * c_RESTc_at6J))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6K
                            -> let
                                 c_EndoNeuroTFs_at6L = ((toVector x_at6K) Data.Vector.Unboxed.! 4)
                               in (p_at5J * c_EndoNeuroTFs_at6L))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5K
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7n
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                            (g_at5G, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at5z = Functions.belowten' g_at5y
                            (g_at5y, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                            (g_at5u, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at5r = Functions.belowten' g_at5q
                            (g_at5q, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                            (g_at5o, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at5n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5m
                            (g_at5m, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at5l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                            (g_at5k, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at5j = Functions.belowten' g_at5i
                            (g_at5i, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at79) = Genome.Split.split gpart_at78
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at78) = Genome.Split.split gpart_at77
                            p_at5d = code-0.1.0.0:Genome.FixedList.Functions.double g_at5c
                            (g_at5c, gpart_at77) = Genome.Split.split gpart_at76
                            p_at5b = Functions.belowten' g_at5a
                            (g_at5a, gpart_at76) = Genome.Split.split gpart_at75
                            p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                            (g_at58, gpart_at75) = Genome.Split.split gpart_at74
                            p_at57
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at56
                            (g_at56, gpart_at74) = Genome.Split.split gpart_at73
                            p_at55
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at54
                            (g_at54, gpart_at73) = Genome.Split.split gpart_at72
                            p_at53 = code-0.1.0.0:Genome.FixedList.Functions.double g_at52
                            (g_at52, gpart_at72) = Genome.Split.split gpart_at71
                            p_at51 = Functions.belowten' g_at50
                            (g_at50, gpart_at71) = Genome.Split.split gpart_at70
                            p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                            (g_at4Y, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at4X = Functions.belowten' g_at4W
                            (g_at4W, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                            (g_at4U, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at4T = Functions.belowten' g_at4S
                            (g_at4S, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at4N = Functions.belowten' g_at4M
                            (g_at4M, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6T) = Genome.Split.split gpart_at6S
                            p_at4J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4I
                            (g_at4I, gpart_at6S) = Genome.Split.split gpart_at6R
                            p_at4H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4G
                            (g_at4G, gpart_at6R) = Genome.Split.split gpart_at6Q
                            p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                            (g_at4E, gpart_at6Q) = Genome.Split.split gpart_at6P
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6P) = Genome.Split.split gpart_at6O
                            p_at4B = code-0.1.0.0:Genome.FixedList.Functions.double g_at4A
                            (g_at4A, gpart_at6O) = Genome.Split.split gpart_at6N
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6N) = Genome.Split.split gpart_at6M
                            p_at4x = code-0.1.0.0:Genome.FixedList.Functions.double g_at4w
                            (g_at4w, gpart_at6M) = Genome.Split.split genome_at5K
                          in
                            \ desc_at5L
                              -> case desc_at5L of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Inhibition coef [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Inhibition hill [RESTc] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   _ -> Nothing }}
