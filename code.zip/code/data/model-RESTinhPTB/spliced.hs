src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1ZaI
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zbl
                      p_a1ZaH = double g_a1ZaG
                      (g_a1ZaG, gpart_a1Zbl) = Genome.Split.split gpart_a1Zbk
                      p_a1ZaF = double g_a1ZaE
                      (g_a1ZaE, gpart_a1Zbk) = Genome.Split.split gpart_a1Zbj
                      p_a1ZaD = double g_a1ZaC
                      (g_a1ZaC, gpart_a1Zbj) = Genome.Split.split gpart_a1Zbi
                      p_a1ZaB = double g_a1ZaA
                      (g_a1ZaA, gpart_a1Zbi) = Genome.Split.split gpart_a1Zbh
                      p_a1Zaz = double g_a1Zay
                      (g_a1Zay, gpart_a1Zbh) = Genome.Split.split gpart_a1Zbg
                      p_a1Zax = Functions.belowten' g_a1Zaw
                      (g_a1Zaw, gpart_a1Zbg) = Genome.Split.split gpart_a1Zbf
                      p_a1Zav = double g_a1Zau
                      (g_a1Zau, gpart_a1Zbf) = Genome.Split.split gpart_a1Zbe
                      p_a1Zat = double g_a1Zas
                      (g_a1Zas, gpart_a1Zbe) = Genome.Split.split gpart_a1Zbd
                      p_a1Zar = double g_a1Zaq
                      (g_a1Zaq, gpart_a1Zbd) = Genome.Split.split gpart_a1Zbc
                      p_a1Zap = Functions.belowten' g_a1Zao
                      (g_a1Zao, gpart_a1Zbc) = Genome.Split.split gpart_a1Zbb
                      p_a1Zan = double g_a1Zam
                      (g_a1Zam, gpart_a1Zbb) = Genome.Split.split gpart_a1Zba
                      p_a1Zal
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zak
                      (g_a1Zak, gpart_a1Zba) = Genome.Split.split gpart_a1Zb9
                      p_a1Zaj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zai
                      (g_a1Zai, gpart_a1Zb9) = Genome.Split.split gpart_a1Zb8
                      p_a1Zah = Functions.belowten' g_a1Zag
                      (g_a1Zag, gpart_a1Zb8) = Genome.Split.split gpart_a1Zb7
                      p_a1Zaf = double g_a1Zae
                      (g_a1Zae, gpart_a1Zb7) = Genome.Split.split gpart_a1Zb6
                      p_a1Zad = double g_a1Zac
                      (g_a1Zac, gpart_a1Zb6) = Genome.Split.split gpart_a1Zb5
                      p_a1Zab = double g_a1Zaa
                      (g_a1Zaa, gpart_a1Zb5) = Genome.Split.split gpart_a1Zb4
                      p_a1Za9 = Functions.belowten' g_a1Za8
                      (g_a1Za8, gpart_a1Zb4) = Genome.Split.split gpart_a1Zb3
                      p_a1Za7 = double g_a1Za6
                      (g_a1Za6, gpart_a1Zb3) = Genome.Split.split gpart_a1Zb2
                      p_a1Za5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Za4
                      (g_a1Za4, gpart_a1Zb2) = Genome.Split.split gpart_a1Zb1
                      p_a1Za3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Za2
                      (g_a1Za2, gpart_a1Zb1) = Genome.Split.split gpart_a1Zb0
                      p_a1Za1 = double g_a1Za0
                      (g_a1Za0, gpart_a1Zb0) = Genome.Split.split gpart_a1ZaZ
                      p_a1Z9Z = Functions.belowten' g_a1Z9Y
                      (g_a1Z9Y, gpart_a1ZaZ) = Genome.Split.split gpart_a1ZaY
                      p_a1Z9X = double g_a1Z9W
                      (g_a1Z9W, gpart_a1ZaY) = Genome.Split.split gpart_a1ZaX
                      p_a1Z9V = Functions.belowten' g_a1Z9U
                      (g_a1Z9U, gpart_a1ZaX) = Genome.Split.split gpart_a1ZaW
                      p_a1Z9T = double g_a1Z9S
                      (g_a1Z9S, gpart_a1ZaW) = Genome.Split.split gpart_a1ZaV
                      p_a1Z9R = double g_a1Z9Q
                      (g_a1Z9Q, gpart_a1ZaV) = Genome.Split.split gpart_a1ZaU
                      p_a1Z9P = Functions.belowten' g_a1Z9O
                      (g_a1Z9O, gpart_a1ZaU) = Genome.Split.split gpart_a1ZaT
                      p_a1Z9N = double g_a1Z9M
                      (g_a1Z9M, gpart_a1ZaT) = Genome.Split.split gpart_a1ZaS
                      p_a1Z9L = Functions.belowten' g_a1Z9K
                      (g_a1Z9K, gpart_a1ZaS) = Genome.Split.split gpart_a1ZaR
                      p_a1Z9J = double g_a1Z9I
                      (g_a1Z9I, gpart_a1ZaR) = Genome.Split.split gpart_a1ZaQ
                      p_a1Z9H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9G
                      (g_a1Z9G, gpart_a1ZaQ) = Genome.Split.split gpart_a1ZaP
                      p_a1Z9F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9E
                      (g_a1Z9E, gpart_a1ZaP) = Genome.Split.split gpart_a1ZaO
                      p_a1Z9D = double g_a1Z9C
                      (g_a1Z9C, gpart_a1ZaO) = Genome.Split.split gpart_a1ZaN
                      p_a1Z9B = double g_a1Z9A
                      (g_a1Z9A, gpart_a1ZaN) = Genome.Split.split gpart_a1ZaM
                      p_a1Z9z = double g_a1Z9y
                      (g_a1Z9y, gpart_a1ZaM) = Genome.Split.split gpart_a1ZaL
                      p_a1Z9x = double g_a1Z9w
                      (g_a1Z9w, gpart_a1ZaL) = Genome.Split.split gpart_a1ZaK
                      p_a1Z9v = double g_a1Z9u
                      (g_a1Z9u, gpart_a1ZaK) = Genome.Split.split genome_a1ZaI
                    in  \ x_a1Zbm
                          -> let
                               c_PTB_a1Zbq
                                 = ((Data.Fixed.Vector.toVector x_a1Zbm) Data.Vector.Unboxed.! 0)
                               c_RESTc_a1Zbn
                                 = ((Data.Fixed.Vector.toVector x_a1Zbm) Data.Vector.Unboxed.! 3)
                               c_MiRs_a1Zbo
                                 = ((Data.Fixed.Vector.toVector x_a1Zbm) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zbu
                                 = ((Data.Fixed.Vector.toVector x_a1Zbm) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a1ZbF
                                 = ((Data.Fixed.Vector.toVector x_a1Zbm) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Z9D
                                     / (1
                                        + (((c_RESTc_a1Zbn / p_a1Z9J) ** p_a1Z9L)
                                           + ((c_MiRs_a1Zbo / p_a1Z9N) ** p_a1Z9P))))
                                    + (negate (p_a1Zaz * c_PTB_a1Zbq))),
                                   ((p_a1Z9R
                                     / (1
                                        + (((c_MiRs_a1Zbo / p_a1Z9T) ** p_a1Z9V)
                                           + ((c_PTB_a1Zbq / p_a1Z9X) ** p_a1Z9Z))))
                                    + (negate (p_a1ZaB * c_NPTB_a1Zbu))),
                                   ((p_a1Za1
                                     * ((p_a1Zab + ((p_a1Z9z / p_a1Za3) ** p_a1Za5))
                                        / (((1 + p_a1Zab) + ((p_a1Z9z / p_a1Za3) ** p_a1Za5))
                                           + ((c_RESTc_a1Zbn / p_a1Za7) ** p_a1Za9))))
                                    + (negate (p_a1ZaD * c_MiRs_a1Zbo))),
                                   ((p_a1Zad
                                     * ((p_a1Zar + ((c_PTB_a1Zbq / p_a1Zaf) ** p_a1Zah))
                                        / (((1 + p_a1Zar) + ((c_PTB_a1Zbq / p_a1Zaf) ** p_a1Zah))
                                           + (((p_a1Z9v / p_a1Zaj) ** p_a1Zal)
                                              + ((c_MiRs_a1Zbo / p_a1Zan) ** p_a1Zap)))))
                                    + (negate (p_a1ZaF * c_RESTc_a1Zbn))),
                                   ((p_a1Zat / (1 + ((c_RESTc_a1Zbn / p_a1Zav) ** p_a1Zax)))
                                    + (negate (p_a1ZaH * c_EndoNeuroTFs_a1ZbF)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483203",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483205",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483227",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483229",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483230",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483231",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483232",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483233",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483243",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483245",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483247",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483265",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483267",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZaI
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zch
                            p_a1ZaH = double g_a1ZaG
                            (g_a1ZaG, gpart_a1Zch) = Genome.Split.split gpart_a1Zcg
                            p_a1ZaF = double g_a1ZaE
                            (g_a1ZaE, gpart_a1Zcg) = Genome.Split.split gpart_a1Zcf
                            p_a1ZaD = double g_a1ZaC
                            (g_a1ZaC, gpart_a1Zcf) = Genome.Split.split gpart_a1Zce
                            p_a1ZaB = double g_a1ZaA
                            (g_a1ZaA, gpart_a1Zce) = Genome.Split.split gpart_a1Zcd
                            p_a1Zaz = double g_a1Zay
                            (g_a1Zay, gpart_a1Zcd) = Genome.Split.split gpart_a1Zcc
                            p_a1Zax = Functions.belowten' g_a1Zaw
                            (g_a1Zaw, gpart_a1Zcc) = Genome.Split.split gpart_a1Zcb
                            p_a1Zav = double g_a1Zau
                            (g_a1Zau, gpart_a1Zcb) = Genome.Split.split gpart_a1Zca
                            p_a1Zat = double g_a1Zas
                            (g_a1Zas, gpart_a1Zca) = Genome.Split.split gpart_a1Zc9
                            p_a1Zar = double g_a1Zaq
                            (g_a1Zaq, gpart_a1Zc9) = Genome.Split.split gpart_a1Zc8
                            p_a1Zap = Functions.belowten' g_a1Zao
                            (g_a1Zao, gpart_a1Zc8) = Genome.Split.split gpart_a1Zc7
                            p_a1Zan = double g_a1Zam
                            (g_a1Zam, gpart_a1Zc7) = Genome.Split.split gpart_a1Zc6
                            p_a1Zal
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zak
                            (g_a1Zak, gpart_a1Zc6) = Genome.Split.split gpart_a1Zc5
                            p_a1Zaj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zai
                            (g_a1Zai, gpart_a1Zc5) = Genome.Split.split gpart_a1Zc4
                            p_a1Zah = Functions.belowten' g_a1Zag
                            (g_a1Zag, gpart_a1Zc4) = Genome.Split.split gpart_a1Zc3
                            p_a1Zaf = double g_a1Zae
                            (g_a1Zae, gpart_a1Zc3) = Genome.Split.split gpart_a1Zc2
                            p_a1Zad = double g_a1Zac
                            (g_a1Zac, gpart_a1Zc2) = Genome.Split.split gpart_a1Zc1
                            p_a1Zab = double g_a1Zaa
                            (g_a1Zaa, gpart_a1Zc1) = Genome.Split.split gpart_a1Zc0
                            p_a1Za9 = Functions.belowten' g_a1Za8
                            (g_a1Za8, gpart_a1Zc0) = Genome.Split.split gpart_a1ZbZ
                            p_a1Za7 = double g_a1Za6
                            (g_a1Za6, gpart_a1ZbZ) = Genome.Split.split gpart_a1ZbY
                            p_a1Za5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Za4
                            (g_a1Za4, gpart_a1ZbY) = Genome.Split.split gpart_a1ZbX
                            p_a1Za3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Za2
                            (g_a1Za2, gpart_a1ZbX) = Genome.Split.split gpart_a1ZbW
                            p_a1Za1 = double g_a1Za0
                            (g_a1Za0, gpart_a1ZbW) = Genome.Split.split gpart_a1ZbV
                            p_a1Z9Z = Functions.belowten' g_a1Z9Y
                            (g_a1Z9Y, gpart_a1ZbV) = Genome.Split.split gpart_a1ZbU
                            p_a1Z9X = double g_a1Z9W
                            (g_a1Z9W, gpart_a1ZbU) = Genome.Split.split gpart_a1ZbT
                            p_a1Z9V = Functions.belowten' g_a1Z9U
                            (g_a1Z9U, gpart_a1ZbT) = Genome.Split.split gpart_a1ZbS
                            p_a1Z9T = double g_a1Z9S
                            (g_a1Z9S, gpart_a1ZbS) = Genome.Split.split gpart_a1ZbR
                            p_a1Z9R = double g_a1Z9Q
                            (g_a1Z9Q, gpart_a1ZbR) = Genome.Split.split gpart_a1ZbQ
                            p_a1Z9P = Functions.belowten' g_a1Z9O
                            (g_a1Z9O, gpart_a1ZbQ) = Genome.Split.split gpart_a1ZbP
                            p_a1Z9N = double g_a1Z9M
                            (g_a1Z9M, gpart_a1ZbP) = Genome.Split.split gpart_a1ZbO
                            p_a1Z9L = Functions.belowten' g_a1Z9K
                            (g_a1Z9K, gpart_a1ZbO) = Genome.Split.split gpart_a1ZbN
                            p_a1Z9J = double g_a1Z9I
                            (g_a1Z9I, gpart_a1ZbN) = Genome.Split.split gpart_a1ZbM
                            p_a1Z9H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9G
                            (g_a1Z9G, gpart_a1ZbM) = Genome.Split.split gpart_a1ZbL
                            p_a1Z9F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Z9E
                            (g_a1Z9E, gpart_a1ZbL) = Genome.Split.split gpart_a1ZbK
                            p_a1Z9D = double g_a1Z9C
                            (g_a1Z9C, gpart_a1ZbK) = Genome.Split.split gpart_a1ZbJ
                            p_a1Z9B = double g_a1Z9A
                            (g_a1Z9A, gpart_a1ZbJ) = Genome.Split.split gpart_a1ZbI
                            p_a1Z9z = double g_a1Z9y
                            (g_a1Z9y, gpart_a1ZbI) = Genome.Split.split gpart_a1ZbH
                            p_a1Z9x = double g_a1Z9w
                            (g_a1Z9w, gpart_a1ZbH) = Genome.Split.split gpart_a1ZbG
                            p_a1Z9v = double g_a1Z9u
                            (g_a1Z9u, gpart_a1ZbG) = Genome.Split.split genome_a1ZaI
                          in
                            \ desc_a1ZaJ
                              -> case desc_a1ZaJ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9v)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9x)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9z)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9B)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9D)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9F)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9H)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9J)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9L)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9N)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9P)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9R)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9T)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9V)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9X)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Z9Z)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za1)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za3)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za5)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za7)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Za9)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zab)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zad)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaf)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zah)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaj)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zal)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zan)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zap)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zar)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zat)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zav)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zax)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zaz)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaB)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaD)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaF)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZaH)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1ZeF
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zfi
                      p_a1ZeE = double g_a1ZeD
                      (g_a1ZeD, gpart_a1Zfi) = Genome.Split.split gpart_a1Zfh
                      p_a1ZeC = double g_a1ZeB
                      (g_a1ZeB, gpart_a1Zfh) = Genome.Split.split gpart_a1Zfg
                      p_a1ZeA = double g_a1Zez
                      (g_a1Zez, gpart_a1Zfg) = Genome.Split.split gpart_a1Zff
                      p_a1Zey = double g_a1Zex
                      (g_a1Zex, gpart_a1Zff) = Genome.Split.split gpart_a1Zfe
                      p_a1Zew = double g_a1Zev
                      (g_a1Zev, gpart_a1Zfe) = Genome.Split.split gpart_a1Zfd
                      p_a1Zeu = Functions.belowten' g_a1Zet
                      (g_a1Zet, gpart_a1Zfd) = Genome.Split.split gpart_a1Zfc
                      p_a1Zes = double g_a1Zer
                      (g_a1Zer, gpart_a1Zfc) = Genome.Split.split gpart_a1Zfb
                      p_a1Zeq = double g_a1Zep
                      (g_a1Zep, gpart_a1Zfb) = Genome.Split.split gpart_a1Zfa
                      p_a1Zeo = double g_a1Zen
                      (g_a1Zen, gpart_a1Zfa) = Genome.Split.split gpart_a1Zf9
                      p_a1Zem = Functions.belowten' g_a1Zel
                      (g_a1Zel, gpart_a1Zf9) = Genome.Split.split gpart_a1Zf8
                      p_a1Zek = double g_a1Zej
                      (g_a1Zej, gpart_a1Zf8) = Genome.Split.split gpart_a1Zf7
                      p_a1Zei
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zeh
                      (g_a1Zeh, gpart_a1Zf7) = Genome.Split.split gpart_a1Zf6
                      p_a1Zeg
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zef
                      (g_a1Zef, gpart_a1Zf6) = Genome.Split.split gpart_a1Zf5
                      p_a1Zee = Functions.belowten' g_a1Zed
                      (g_a1Zed, gpart_a1Zf5) = Genome.Split.split gpart_a1Zf4
                      p_a1Zec = double g_a1Zeb
                      (g_a1Zeb, gpart_a1Zf4) = Genome.Split.split gpart_a1Zf3
                      p_a1Zea = double g_a1Ze9
                      (g_a1Ze9, gpart_a1Zf3) = Genome.Split.split gpart_a1Zf2
                      p_a1Ze8 = double g_a1Ze7
                      (g_a1Ze7, gpart_a1Zf2) = Genome.Split.split gpart_a1Zf1
                      p_a1Ze6 = Functions.belowten' g_a1Ze5
                      (g_a1Ze5, gpart_a1Zf1) = Genome.Split.split gpart_a1Zf0
                      p_a1Ze4 = double g_a1Ze3
                      (g_a1Ze3, gpart_a1Zf0) = Genome.Split.split gpart_a1ZeZ
                      p_a1Ze2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ze1
                      (g_a1Ze1, gpart_a1ZeZ) = Genome.Split.split gpart_a1ZeY
                      p_a1Ze0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdZ
                      (g_a1ZdZ, gpart_a1ZeY) = Genome.Split.split gpart_a1ZeX
                      p_a1ZdY = double g_a1ZdX
                      (g_a1ZdX, gpart_a1ZeX) = Genome.Split.split gpart_a1ZeW
                      p_a1ZdW = Functions.belowten' g_a1ZdV
                      (g_a1ZdV, gpart_a1ZeW) = Genome.Split.split gpart_a1ZeV
                      p_a1ZdU = double g_a1ZdT
                      (g_a1ZdT, gpart_a1ZeV) = Genome.Split.split gpart_a1ZeU
                      p_a1ZdS = Functions.belowten' g_a1ZdR
                      (g_a1ZdR, gpart_a1ZeU) = Genome.Split.split gpart_a1ZeT
                      p_a1ZdQ = double g_a1ZdP
                      (g_a1ZdP, gpart_a1ZeT) = Genome.Split.split gpart_a1ZeS
                      p_a1ZdO = double g_a1ZdN
                      (g_a1ZdN, gpart_a1ZeS) = Genome.Split.split gpart_a1ZeR
                      p_a1ZdM = Functions.belowten' g_a1ZdL
                      (g_a1ZdL, gpart_a1ZeR) = Genome.Split.split gpart_a1ZeQ
                      p_a1ZdK = double g_a1ZdJ
                      (g_a1ZdJ, gpart_a1ZeQ) = Genome.Split.split gpart_a1ZeP
                      p_a1ZdI = Functions.belowten' g_a1ZdH
                      (g_a1ZdH, gpart_a1ZeP) = Genome.Split.split gpart_a1ZeO
                      p_a1ZdG = double g_a1ZdF
                      (g_a1ZdF, gpart_a1ZeO) = Genome.Split.split gpart_a1ZeN
                      p_a1ZdE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdD
                      (g_a1ZdD, gpart_a1ZeN) = Genome.Split.split gpart_a1ZeM
                      p_a1ZdC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdB
                      (g_a1ZdB, gpart_a1ZeM) = Genome.Split.split gpart_a1ZeL
                      p_a1ZdA = double g_a1Zdz
                      (g_a1Zdz, gpart_a1ZeL) = Genome.Split.split gpart_a1ZeK
                      p_a1Zdy = double g_a1Zdx
                      (g_a1Zdx, gpart_a1ZeK) = Genome.Split.split gpart_a1ZeJ
                      p_a1Zdw = double g_a1Zdv
                      (g_a1Zdv, gpart_a1ZeJ) = Genome.Split.split gpart_a1ZeI
                      p_a1Zdu = double g_a1Zdt
                      (g_a1Zdt, gpart_a1ZeI) = Genome.Split.split gpart_a1ZeH
                      p_a1Zds = double g_a1Zdr
                      (g_a1Zdr, gpart_a1ZeH) = Genome.Split.split genome_a1ZeF
                    in  \ x_a1Zfj
                          -> let
                               c_PTB_a1Zfn
                                 = ((Data.Fixed.Vector.toVector x_a1Zfj) Data.Vector.Unboxed.! 0)
                               c_RESTc_a1Zfk
                                 = ((Data.Fixed.Vector.toVector x_a1Zfj) Data.Vector.Unboxed.! 3)
                               c_MiRs_a1Zfl
                                 = ((Data.Fixed.Vector.toVector x_a1Zfj) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zfr
                                 = ((Data.Fixed.Vector.toVector x_a1Zfj) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a1ZfC
                                 = ((Data.Fixed.Vector.toVector x_a1Zfj) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1ZdA
                                     / (1
                                        + (((c_RESTc_a1Zfk / p_a1ZdG) ** p_a1ZdI)
                                           + ((c_MiRs_a1Zfl / p_a1ZdK) ** p_a1ZdM))))
                                    + (negate (p_a1Zew * c_PTB_a1Zfn))),
                                   ((p_a1ZdO
                                     / (1
                                        + (((c_MiRs_a1Zfl / p_a1ZdQ) ** p_a1ZdS)
                                           + ((c_PTB_a1Zfn / p_a1ZdU) ** p_a1ZdW))))
                                    + (negate (p_a1Zey * c_NPTB_a1Zfr))),
                                   ((p_a1ZdY
                                     * (p_a1Ze8
                                        / ((1 + p_a1Ze8) + ((c_RESTc_a1Zfk / p_a1Ze4) ** p_a1Ze6))))
                                    + (negate (p_a1ZeA * c_MiRs_a1Zfl))),
                                   ((p_a1Zea
                                     * ((p_a1Zeo + ((c_PTB_a1Zfn / p_a1Zec) ** p_a1Zee))
                                        / (((1 + p_a1Zeo) + ((c_PTB_a1Zfn / p_a1Zec) ** p_a1Zee))
                                           + (((p_a1Zds / p_a1Zeg) ** p_a1Zei)
                                              + ((c_MiRs_a1Zfl / p_a1Zek) ** p_a1Zem)))))
                                    + (negate (p_a1ZeC * c_RESTc_a1Zfk))),
                                   ((p_a1Zeq / (1 + ((c_RESTc_a1Zfk / p_a1Zes) ** p_a1Zeu)))
                                    + (negate (p_a1ZeE * c_EndoNeuroTFs_a1ZfC)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483448",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483450",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483472",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483474",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483480",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483482",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483488",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483490",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZeF
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zge
                            p_a1ZeE = double g_a1ZeD
                            (g_a1ZeD, gpart_a1Zge) = Genome.Split.split gpart_a1Zgd
                            p_a1ZeC = double g_a1ZeB
                            (g_a1ZeB, gpart_a1Zgd) = Genome.Split.split gpart_a1Zgc
                            p_a1ZeA = double g_a1Zez
                            (g_a1Zez, gpart_a1Zgc) = Genome.Split.split gpart_a1Zgb
                            p_a1Zey = double g_a1Zex
                            (g_a1Zex, gpart_a1Zgb) = Genome.Split.split gpart_a1Zga
                            p_a1Zew = double g_a1Zev
                            (g_a1Zev, gpart_a1Zga) = Genome.Split.split gpart_a1Zg9
                            p_a1Zeu = Functions.belowten' g_a1Zet
                            (g_a1Zet, gpart_a1Zg9) = Genome.Split.split gpart_a1Zg8
                            p_a1Zes = double g_a1Zer
                            (g_a1Zer, gpart_a1Zg8) = Genome.Split.split gpart_a1Zg7
                            p_a1Zeq = double g_a1Zep
                            (g_a1Zep, gpart_a1Zg7) = Genome.Split.split gpart_a1Zg6
                            p_a1Zeo = double g_a1Zen
                            (g_a1Zen, gpart_a1Zg6) = Genome.Split.split gpart_a1Zg5
                            p_a1Zem = Functions.belowten' g_a1Zel
                            (g_a1Zel, gpart_a1Zg5) = Genome.Split.split gpart_a1Zg4
                            p_a1Zek = double g_a1Zej
                            (g_a1Zej, gpart_a1Zg4) = Genome.Split.split gpart_a1Zg3
                            p_a1Zei
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zeh
                            (g_a1Zeh, gpart_a1Zg3) = Genome.Split.split gpart_a1Zg2
                            p_a1Zeg
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zef
                            (g_a1Zef, gpart_a1Zg2) = Genome.Split.split gpart_a1Zg1
                            p_a1Zee = Functions.belowten' g_a1Zed
                            (g_a1Zed, gpart_a1Zg1) = Genome.Split.split gpart_a1Zg0
                            p_a1Zec = double g_a1Zeb
                            (g_a1Zeb, gpart_a1Zg0) = Genome.Split.split gpart_a1ZfZ
                            p_a1Zea = double g_a1Ze9
                            (g_a1Ze9, gpart_a1ZfZ) = Genome.Split.split gpart_a1ZfY
                            p_a1Ze8 = double g_a1Ze7
                            (g_a1Ze7, gpart_a1ZfY) = Genome.Split.split gpart_a1ZfX
                            p_a1Ze6 = Functions.belowten' g_a1Ze5
                            (g_a1Ze5, gpart_a1ZfX) = Genome.Split.split gpart_a1ZfW
                            p_a1Ze4 = double g_a1Ze3
                            (g_a1Ze3, gpart_a1ZfW) = Genome.Split.split gpart_a1ZfV
                            p_a1Ze2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Ze1
                            (g_a1Ze1, gpart_a1ZfV) = Genome.Split.split gpart_a1ZfU
                            p_a1Ze0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdZ
                            (g_a1ZdZ, gpart_a1ZfU) = Genome.Split.split gpart_a1ZfT
                            p_a1ZdY = double g_a1ZdX
                            (g_a1ZdX, gpart_a1ZfT) = Genome.Split.split gpart_a1ZfS
                            p_a1ZdW = Functions.belowten' g_a1ZdV
                            (g_a1ZdV, gpart_a1ZfS) = Genome.Split.split gpart_a1ZfR
                            p_a1ZdU = double g_a1ZdT
                            (g_a1ZdT, gpart_a1ZfR) = Genome.Split.split gpart_a1ZfQ
                            p_a1ZdS = Functions.belowten' g_a1ZdR
                            (g_a1ZdR, gpart_a1ZfQ) = Genome.Split.split gpart_a1ZfP
                            p_a1ZdQ = double g_a1ZdP
                            (g_a1ZdP, gpart_a1ZfP) = Genome.Split.split gpart_a1ZfO
                            p_a1ZdO = double g_a1ZdN
                            (g_a1ZdN, gpart_a1ZfO) = Genome.Split.split gpart_a1ZfN
                            p_a1ZdM = Functions.belowten' g_a1ZdL
                            (g_a1ZdL, gpart_a1ZfN) = Genome.Split.split gpart_a1ZfM
                            p_a1ZdK = double g_a1ZdJ
                            (g_a1ZdJ, gpart_a1ZfM) = Genome.Split.split gpart_a1ZfL
                            p_a1ZdI = Functions.belowten' g_a1ZdH
                            (g_a1ZdH, gpart_a1ZfL) = Genome.Split.split gpart_a1ZfK
                            p_a1ZdG = double g_a1ZdF
                            (g_a1ZdF, gpart_a1ZfK) = Genome.Split.split gpart_a1ZfJ
                            p_a1ZdE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdD
                            (g_a1ZdD, gpart_a1ZfJ) = Genome.Split.split gpart_a1ZfI
                            p_a1ZdC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZdB
                            (g_a1ZdB, gpart_a1ZfI) = Genome.Split.split gpart_a1ZfH
                            p_a1ZdA = double g_a1Zdz
                            (g_a1Zdz, gpart_a1ZfH) = Genome.Split.split gpart_a1ZfG
                            p_a1Zdy = double g_a1Zdx
                            (g_a1Zdx, gpart_a1ZfG) = Genome.Split.split gpart_a1ZfF
                            p_a1Zdw = double g_a1Zdv
                            (g_a1Zdv, gpart_a1ZfF) = Genome.Split.split gpart_a1ZfE
                            p_a1Zdu = double g_a1Zdt
                            (g_a1Zdt, gpart_a1ZfE) = Genome.Split.split gpart_a1ZfD
                            p_a1Zds = double g_a1Zdr
                            (g_a1Zdr, gpart_a1ZfD) = Genome.Split.split genome_a1ZeF
                          in
                            \ desc_a1ZeG
                              -> case desc_a1ZeG of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zds)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdu)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdw)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zdy)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdA)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdC)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdE)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdG)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdI)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdK)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdM)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdO)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdQ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdS)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdU)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdW)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZdY)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze0)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze2)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze4)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze6)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ze8)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zea)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zec)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zee)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeg)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zei)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zek)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zem)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeo)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeq)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zes)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zeu)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zew)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zey)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeA)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeC)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZeE)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1ZiC
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zjf
                      p_a1ZiB = double g_a1ZiA
                      (g_a1ZiA, gpart_a1Zjf) = Genome.Split.split gpart_a1Zje
                      p_a1Ziz = double g_a1Ziy
                      (g_a1Ziy, gpart_a1Zje) = Genome.Split.split gpart_a1Zjd
                      p_a1Zix = double g_a1Ziw
                      (g_a1Ziw, gpart_a1Zjd) = Genome.Split.split gpart_a1Zjc
                      p_a1Ziv = double g_a1Ziu
                      (g_a1Ziu, gpart_a1Zjc) = Genome.Split.split gpart_a1Zjb
                      p_a1Zit = double g_a1Zis
                      (g_a1Zis, gpart_a1Zjb) = Genome.Split.split gpart_a1Zja
                      p_a1Zir = Functions.belowten' g_a1Ziq
                      (g_a1Ziq, gpart_a1Zja) = Genome.Split.split gpart_a1Zj9
                      p_a1Zip = double g_a1Zio
                      (g_a1Zio, gpart_a1Zj9) = Genome.Split.split gpart_a1Zj8
                      p_a1Zin = double g_a1Zim
                      (g_a1Zim, gpart_a1Zj8) = Genome.Split.split gpart_a1Zj7
                      p_a1Zil = double g_a1Zik
                      (g_a1Zik, gpart_a1Zj7) = Genome.Split.split gpart_a1Zj6
                      p_a1Zij = Functions.belowten' g_a1Zii
                      (g_a1Zii, gpart_a1Zj6) = Genome.Split.split gpart_a1Zj5
                      p_a1Zih = double g_a1Zig
                      (g_a1Zig, gpart_a1Zj5) = Genome.Split.split gpart_a1Zj4
                      p_a1Zif
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zie
                      (g_a1Zie, gpart_a1Zj4) = Genome.Split.split gpart_a1Zj3
                      p_a1Zid
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zic
                      (g_a1Zic, gpart_a1Zj3) = Genome.Split.split gpart_a1Zj2
                      p_a1Zib = Functions.belowten' g_a1Zia
                      (g_a1Zia, gpart_a1Zj2) = Genome.Split.split gpart_a1Zj1
                      p_a1Zi9 = double g_a1Zi8
                      (g_a1Zi8, gpart_a1Zj1) = Genome.Split.split gpart_a1Zj0
                      p_a1Zi7 = double g_a1Zi6
                      (g_a1Zi6, gpart_a1Zj0) = Genome.Split.split gpart_a1ZiZ
                      p_a1Zi5 = double g_a1Zi4
                      (g_a1Zi4, gpart_a1ZiZ) = Genome.Split.split gpart_a1ZiY
                      p_a1Zi3 = Functions.belowten' g_a1Zi2
                      (g_a1Zi2, gpart_a1ZiY) = Genome.Split.split gpart_a1ZiX
                      p_a1Zi1 = double g_a1Zi0
                      (g_a1Zi0, gpart_a1ZiX) = Genome.Split.split gpart_a1ZiW
                      p_a1ZhZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhY
                      (g_a1ZhY, gpart_a1ZiW) = Genome.Split.split gpart_a1ZiV
                      p_a1ZhX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhW
                      (g_a1ZhW, gpart_a1ZiV) = Genome.Split.split gpart_a1ZiU
                      p_a1ZhV = double g_a1ZhU
                      (g_a1ZhU, gpart_a1ZiU) = Genome.Split.split gpart_a1ZiT
                      p_a1ZhT = Functions.belowten' g_a1ZhS
                      (g_a1ZhS, gpart_a1ZiT) = Genome.Split.split gpart_a1ZiS
                      p_a1ZhR = double g_a1ZhQ
                      (g_a1ZhQ, gpart_a1ZiS) = Genome.Split.split gpart_a1ZiR
                      p_a1ZhP = Functions.belowten' g_a1ZhO
                      (g_a1ZhO, gpart_a1ZiR) = Genome.Split.split gpart_a1ZiQ
                      p_a1ZhN = double g_a1ZhM
                      (g_a1ZhM, gpart_a1ZiQ) = Genome.Split.split gpart_a1ZiP
                      p_a1ZhL = double g_a1ZhK
                      (g_a1ZhK, gpart_a1ZiP) = Genome.Split.split gpart_a1ZiO
                      p_a1ZhJ = Functions.belowten' g_a1ZhI
                      (g_a1ZhI, gpart_a1ZiO) = Genome.Split.split gpart_a1ZiN
                      p_a1ZhH = double g_a1ZhG
                      (g_a1ZhG, gpart_a1ZiN) = Genome.Split.split gpart_a1ZiM
                      p_a1ZhF = Functions.belowten' g_a1ZhE
                      (g_a1ZhE, gpart_a1ZiM) = Genome.Split.split gpart_a1ZiL
                      p_a1ZhD = double g_a1ZhC
                      (g_a1ZhC, gpart_a1ZiL) = Genome.Split.split gpart_a1ZiK
                      p_a1ZhB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhA
                      (g_a1ZhA, gpart_a1ZiK) = Genome.Split.split gpart_a1ZiJ
                      p_a1Zhz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhy
                      (g_a1Zhy, gpart_a1ZiJ) = Genome.Split.split gpart_a1ZiI
                      p_a1Zhx = double g_a1Zhw
                      (g_a1Zhw, gpart_a1ZiI) = Genome.Split.split gpart_a1ZiH
                      p_a1Zhv = double g_a1Zhu
                      (g_a1Zhu, gpart_a1ZiH) = Genome.Split.split gpart_a1ZiG
                      p_a1Zht = double g_a1Zhs
                      (g_a1Zhs, gpart_a1ZiG) = Genome.Split.split gpart_a1ZiF
                      p_a1Zhr = double g_a1Zhq
                      (g_a1Zhq, gpart_a1ZiF) = Genome.Split.split gpart_a1ZiE
                      p_a1Zhp = double g_a1Zho
                      (g_a1Zho, gpart_a1ZiE) = Genome.Split.split genome_a1ZiC
                    in  \ x_a1Zjg
                          -> let
                               c_PTB_a1Zjk
                                 = ((Data.Fixed.Vector.toVector x_a1Zjg) Data.Vector.Unboxed.! 0)
                               c_RESTc_a1Zjh
                                 = ((Data.Fixed.Vector.toVector x_a1Zjg) Data.Vector.Unboxed.! 3)
                               c_MiRs_a1Zji
                                 = ((Data.Fixed.Vector.toVector x_a1Zjg) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zjo
                                 = ((Data.Fixed.Vector.toVector x_a1Zjg) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a1Zjz
                                 = ((Data.Fixed.Vector.toVector x_a1Zjg) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zhx
                                     / (1
                                        + (((c_RESTc_a1Zjh / p_a1ZhD) ** p_a1ZhF)
                                           + ((c_MiRs_a1Zji / p_a1ZhH) ** p_a1ZhJ))))
                                    + (negate (p_a1Zit * c_PTB_a1Zjk))),
                                   ((p_a1ZhL
                                     / (1
                                        + (((c_MiRs_a1Zji / p_a1ZhN) ** p_a1ZhP)
                                           + ((c_PTB_a1Zjk / p_a1ZhR) ** p_a1ZhT))))
                                    + (negate (p_a1Ziv * c_NPTB_a1Zjo))),
                                   ((p_a1ZhV
                                     * (p_a1Zi5
                                        / ((1 + p_a1Zi5) + ((c_RESTc_a1Zjh / p_a1Zi1) ** p_a1Zi3))))
                                    + (negate (p_a1Zix * c_MiRs_a1Zji))),
                                   ((p_a1Zi7
                                     * ((p_a1Zil + ((c_PTB_a1Zjk / p_a1Zi9) ** p_a1Zib))
                                        / (((1 + p_a1Zil) + ((c_PTB_a1Zjk / p_a1Zi9) ** p_a1Zib))
                                           + ((c_MiRs_a1Zji / p_a1Zih) ** p_a1Zij))))
                                    + (negate (p_a1Ziz * c_RESTc_a1Zjh))),
                                   ((p_a1Zin / (1 + ((c_RESTc_a1Zjh / p_a1Zip) ** p_a1Zir)))
                                    + (negate (p_a1ZiB * c_EndoNeuroTFs_a1Zjz)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483693",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483695",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483708",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483709",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483710",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483711",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483712",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483713",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483714",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483715",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483716",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483717",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483718",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483719",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483720",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483721",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483722",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483723",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483724",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483725",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483726",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483727",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483728",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483729",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483730",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483731",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483732",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483733",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483734",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483735",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483736",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483737",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483738",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483739",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483740",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483741",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483742",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483743",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483744",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483745",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483746",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483747",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483748",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483749",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483750",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483751",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1ZiC
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zkb
                            p_a1ZiB = double g_a1ZiA
                            (g_a1ZiA, gpart_a1Zkb) = Genome.Split.split gpart_a1Zka
                            p_a1Ziz = double g_a1Ziy
                            (g_a1Ziy, gpart_a1Zka) = Genome.Split.split gpart_a1Zk9
                            p_a1Zix = double g_a1Ziw
                            (g_a1Ziw, gpart_a1Zk9) = Genome.Split.split gpart_a1Zk8
                            p_a1Ziv = double g_a1Ziu
                            (g_a1Ziu, gpart_a1Zk8) = Genome.Split.split gpart_a1Zk7
                            p_a1Zit = double g_a1Zis
                            (g_a1Zis, gpart_a1Zk7) = Genome.Split.split gpart_a1Zk6
                            p_a1Zir = Functions.belowten' g_a1Ziq
                            (g_a1Ziq, gpart_a1Zk6) = Genome.Split.split gpart_a1Zk5
                            p_a1Zip = double g_a1Zio
                            (g_a1Zio, gpart_a1Zk5) = Genome.Split.split gpart_a1Zk4
                            p_a1Zin = double g_a1Zim
                            (g_a1Zim, gpart_a1Zk4) = Genome.Split.split gpart_a1Zk3
                            p_a1Zil = double g_a1Zik
                            (g_a1Zik, gpart_a1Zk3) = Genome.Split.split gpart_a1Zk2
                            p_a1Zij = Functions.belowten' g_a1Zii
                            (g_a1Zii, gpart_a1Zk2) = Genome.Split.split gpart_a1Zk1
                            p_a1Zih = double g_a1Zig
                            (g_a1Zig, gpart_a1Zk1) = Genome.Split.split gpart_a1Zk0
                            p_a1Zif
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zie
                            (g_a1Zie, gpart_a1Zk0) = Genome.Split.split gpart_a1ZjZ
                            p_a1Zid
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zic
                            (g_a1Zic, gpart_a1ZjZ) = Genome.Split.split gpart_a1ZjY
                            p_a1Zib = Functions.belowten' g_a1Zia
                            (g_a1Zia, gpart_a1ZjY) = Genome.Split.split gpart_a1ZjX
                            p_a1Zi9 = double g_a1Zi8
                            (g_a1Zi8, gpart_a1ZjX) = Genome.Split.split gpart_a1ZjW
                            p_a1Zi7 = double g_a1Zi6
                            (g_a1Zi6, gpart_a1ZjW) = Genome.Split.split gpart_a1ZjV
                            p_a1Zi5 = double g_a1Zi4
                            (g_a1Zi4, gpart_a1ZjV) = Genome.Split.split gpart_a1ZjU
                            p_a1Zi3 = Functions.belowten' g_a1Zi2
                            (g_a1Zi2, gpart_a1ZjU) = Genome.Split.split gpart_a1ZjT
                            p_a1Zi1 = double g_a1Zi0
                            (g_a1Zi0, gpart_a1ZjT) = Genome.Split.split gpart_a1ZjS
                            p_a1ZhZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhY
                            (g_a1ZhY, gpart_a1ZjS) = Genome.Split.split gpart_a1ZjR
                            p_a1ZhX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhW
                            (g_a1ZhW, gpart_a1ZjR) = Genome.Split.split gpart_a1ZjQ
                            p_a1ZhV = double g_a1ZhU
                            (g_a1ZhU, gpart_a1ZjQ) = Genome.Split.split gpart_a1ZjP
                            p_a1ZhT = Functions.belowten' g_a1ZhS
                            (g_a1ZhS, gpart_a1ZjP) = Genome.Split.split gpart_a1ZjO
                            p_a1ZhR = double g_a1ZhQ
                            (g_a1ZhQ, gpart_a1ZjO) = Genome.Split.split gpart_a1ZjN
                            p_a1ZhP = Functions.belowten' g_a1ZhO
                            (g_a1ZhO, gpart_a1ZjN) = Genome.Split.split gpart_a1ZjM
                            p_a1ZhN = double g_a1ZhM
                            (g_a1ZhM, gpart_a1ZjM) = Genome.Split.split gpart_a1ZjL
                            p_a1ZhL = double g_a1ZhK
                            (g_a1ZhK, gpart_a1ZjL) = Genome.Split.split gpart_a1ZjK
                            p_a1ZhJ = Functions.belowten' g_a1ZhI
                            (g_a1ZhI, gpart_a1ZjK) = Genome.Split.split gpart_a1ZjJ
                            p_a1ZhH = double g_a1ZhG
                            (g_a1ZhG, gpart_a1ZjJ) = Genome.Split.split gpart_a1ZjI
                            p_a1ZhF = Functions.belowten' g_a1ZhE
                            (g_a1ZhE, gpart_a1ZjI) = Genome.Split.split gpart_a1ZjH
                            p_a1ZhD = double g_a1ZhC
                            (g_a1ZhC, gpart_a1ZjH) = Genome.Split.split gpart_a1ZjG
                            p_a1ZhB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZhA
                            (g_a1ZhA, gpart_a1ZjG) = Genome.Split.split gpart_a1ZjF
                            p_a1Zhz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zhy
                            (g_a1Zhy, gpart_a1ZjF) = Genome.Split.split gpart_a1ZjE
                            p_a1Zhx = double g_a1Zhw
                            (g_a1Zhw, gpart_a1ZjE) = Genome.Split.split gpart_a1ZjD
                            p_a1Zhv = double g_a1Zhu
                            (g_a1Zhu, gpart_a1ZjD) = Genome.Split.split gpart_a1ZjC
                            p_a1Zht = double g_a1Zhs
                            (g_a1Zhs, gpart_a1ZjC) = Genome.Split.split gpart_a1ZjB
                            p_a1Zhr = double g_a1Zhq
                            (g_a1Zhq, gpart_a1ZjB) = Genome.Split.split gpart_a1ZjA
                            p_a1Zhp = double g_a1Zho
                            (g_a1Zho, gpart_a1ZjA) = Genome.Split.split genome_a1ZiC
                          in
                            \ desc_a1ZiD
                              -> case desc_a1ZiD of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhp)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhr)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zht)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhv)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhx)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zhz)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhB)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhD)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhF)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhH)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhJ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhL)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhN)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhP)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhR)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhT)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhV)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhX)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZhZ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi1)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi3)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi5)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi7)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zi9)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zib)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zid)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zif)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zih)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zij)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zil)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zin)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zip)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zir)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zit)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ziv)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zix)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Ziz)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZiB)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zmz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Znc
                      p_a1Zmy = double g_a1Zmx
                      (g_a1Zmx, gpart_a1Znc) = Genome.Split.split gpart_a1Znb
                      p_a1Zmw = double g_a1Zmv
                      (g_a1Zmv, gpart_a1Znb) = Genome.Split.split gpart_a1Zna
                      p_a1Zmu = double g_a1Zmt
                      (g_a1Zmt, gpart_a1Zna) = Genome.Split.split gpart_a1Zn9
                      p_a1Zms = double g_a1Zmr
                      (g_a1Zmr, gpart_a1Zn9) = Genome.Split.split gpart_a1Zn8
                      p_a1Zmq = double g_a1Zmp
                      (g_a1Zmp, gpart_a1Zn8) = Genome.Split.split gpart_a1Zn7
                      p_a1Zmo = Functions.belowten' g_a1Zmn
                      (g_a1Zmn, gpart_a1Zn7) = Genome.Split.split gpart_a1Zn6
                      p_a1Zmm = double g_a1Zml
                      (g_a1Zml, gpart_a1Zn6) = Genome.Split.split gpart_a1Zn5
                      p_a1Zmk = double g_a1Zmj
                      (g_a1Zmj, gpart_a1Zn5) = Genome.Split.split gpart_a1Zn4
                      p_a1Zmi = double g_a1Zmh
                      (g_a1Zmh, gpart_a1Zn4) = Genome.Split.split gpart_a1Zn3
                      p_a1Zmg = Functions.belowten' g_a1Zmf
                      (g_a1Zmf, gpart_a1Zn3) = Genome.Split.split gpart_a1Zn2
                      p_a1Zme = double g_a1Zmd
                      (g_a1Zmd, gpart_a1Zn2) = Genome.Split.split gpart_a1Zn1
                      p_a1Zmc
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmb
                      (g_a1Zmb, gpart_a1Zn1) = Genome.Split.split gpart_a1Zn0
                      p_a1Zma
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm9
                      (g_a1Zm9, gpart_a1Zn0) = Genome.Split.split gpart_a1ZmZ
                      p_a1Zm8 = Functions.belowten' g_a1Zm7
                      (g_a1Zm7, gpart_a1ZmZ) = Genome.Split.split gpart_a1ZmY
                      p_a1Zm6 = double g_a1Zm5
                      (g_a1Zm5, gpart_a1ZmY) = Genome.Split.split gpart_a1ZmX
                      p_a1Zm4 = double g_a1Zm3
                      (g_a1Zm3, gpart_a1ZmX) = Genome.Split.split gpart_a1ZmW
                      p_a1Zm2 = double g_a1Zm1
                      (g_a1Zm1, gpart_a1ZmW) = Genome.Split.split gpart_a1ZmV
                      p_a1Zm0 = Functions.belowten' g_a1ZlZ
                      (g_a1ZlZ, gpart_a1ZmV) = Genome.Split.split gpart_a1ZmU
                      p_a1ZlY = double g_a1ZlX
                      (g_a1ZlX, gpart_a1ZmU) = Genome.Split.split gpart_a1ZmT
                      p_a1ZlW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlV
                      (g_a1ZlV, gpart_a1ZmT) = Genome.Split.split gpart_a1ZmS
                      p_a1ZlU
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlT
                      (g_a1ZlT, gpart_a1ZmS) = Genome.Split.split gpart_a1ZmR
                      p_a1ZlS = double g_a1ZlR
                      (g_a1ZlR, gpart_a1ZmR) = Genome.Split.split gpart_a1ZmQ
                      p_a1ZlQ = Functions.belowten' g_a1ZlP
                      (g_a1ZlP, gpart_a1ZmQ) = Genome.Split.split gpart_a1ZmP
                      p_a1ZlO = double g_a1ZlN
                      (g_a1ZlN, gpart_a1ZmP) = Genome.Split.split gpart_a1ZmO
                      p_a1ZlM = Functions.belowten' g_a1ZlL
                      (g_a1ZlL, gpart_a1ZmO) = Genome.Split.split gpart_a1ZmN
                      p_a1ZlK = double g_a1ZlJ
                      (g_a1ZlJ, gpart_a1ZmN) = Genome.Split.split gpart_a1ZmM
                      p_a1ZlI = double g_a1ZlH
                      (g_a1ZlH, gpart_a1ZmM) = Genome.Split.split gpart_a1ZmL
                      p_a1ZlG = Functions.belowten' g_a1ZlF
                      (g_a1ZlF, gpart_a1ZmL) = Genome.Split.split gpart_a1ZmK
                      p_a1ZlE = double g_a1ZlD
                      (g_a1ZlD, gpart_a1ZmK) = Genome.Split.split gpart_a1ZmJ
                      p_a1ZlC = Functions.belowten' g_a1ZlB
                      (g_a1ZlB, gpart_a1ZmJ) = Genome.Split.split gpart_a1ZmI
                      p_a1ZlA = double g_a1Zlz
                      (g_a1Zlz, gpart_a1ZmI) = Genome.Split.split gpart_a1ZmH
                      p_a1Zly
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlx
                      (g_a1Zlx, gpart_a1ZmH) = Genome.Split.split gpart_a1ZmG
                      p_a1Zlw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlv
                      (g_a1Zlv, gpart_a1ZmG) = Genome.Split.split gpart_a1ZmF
                      p_a1Zlu = double g_a1Zlt
                      (g_a1Zlt, gpart_a1ZmF) = Genome.Split.split gpart_a1ZmE
                      p_a1Zls = double g_a1Zlr
                      (g_a1Zlr, gpart_a1ZmE) = Genome.Split.split gpart_a1ZmD
                      p_a1Zlq = double g_a1Zlp
                      (g_a1Zlp, gpart_a1ZmD) = Genome.Split.split gpart_a1ZmC
                      p_a1Zlo = double g_a1Zln
                      (g_a1Zln, gpart_a1ZmC) = Genome.Split.split gpart_a1ZmB
                      p_a1Zlm = double g_a1Zll
                      (g_a1Zll, gpart_a1ZmB) = Genome.Split.split genome_a1Zmz
                    in  \ x_a1Znd
                          -> let
                               c_PTB_a1Znh
                                 = ((Data.Fixed.Vector.toVector x_a1Znd) Data.Vector.Unboxed.! 0)
                               c_RESTc_a1Zne
                                 = ((Data.Fixed.Vector.toVector x_a1Znd) Data.Vector.Unboxed.! 3)
                               c_MiRs_a1Znf
                                 = ((Data.Fixed.Vector.toVector x_a1Znd) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Znl
                                 = ((Data.Fixed.Vector.toVector x_a1Znd) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a1Znw
                                 = ((Data.Fixed.Vector.toVector x_a1Znd) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zlu
                                     / (1
                                        + ((((p_a1Zlm / p_a1Zlw) ** p_a1Zly)
                                            + ((c_RESTc_a1Zne / p_a1ZlA) ** p_a1ZlC))
                                           + ((c_MiRs_a1Znf / p_a1ZlE) ** p_a1ZlG))))
                                    + (negate (p_a1Zmq * c_PTB_a1Znh))),
                                   ((p_a1ZlI
                                     / (1
                                        + (((c_MiRs_a1Znf / p_a1ZlK) ** p_a1ZlM)
                                           + ((c_PTB_a1Znh / p_a1ZlO) ** p_a1ZlQ))))
                                    + (negate (p_a1Zms * c_NPTB_a1Znl))),
                                   ((p_a1ZlS
                                     * (p_a1Zm2
                                        / ((1 + p_a1Zm2) + ((c_RESTc_a1Zne / p_a1ZlY) ** p_a1Zm0))))
                                    + (negate (p_a1Zmu * c_MiRs_a1Znf))),
                                   ((p_a1Zm4
                                     * ((p_a1Zmi + ((c_PTB_a1Znh / p_a1Zm6) ** p_a1Zm8))
                                        / (((1 + p_a1Zmi) + ((c_PTB_a1Znh / p_a1Zm6) ** p_a1Zm8))
                                           + ((c_MiRs_a1Znf / p_a1Zme) ** p_a1Zmg))))
                                    + (negate (p_a1Zmw * c_RESTc_a1Zne))),
                                   ((p_a1Zmk / (1 + ((c_RESTc_a1Zne / p_a1Zmm) ** p_a1Zmo)))
                                    + (negate (p_a1Zmy * c_EndoNeuroTFs_a1Znw)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483938",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483962",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483964",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483978",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483980",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zmz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zo8
                            p_a1Zmy = double g_a1Zmx
                            (g_a1Zmx, gpart_a1Zo8) = Genome.Split.split gpart_a1Zo7
                            p_a1Zmw = double g_a1Zmv
                            (g_a1Zmv, gpart_a1Zo7) = Genome.Split.split gpart_a1Zo6
                            p_a1Zmu = double g_a1Zmt
                            (g_a1Zmt, gpart_a1Zo6) = Genome.Split.split gpart_a1Zo5
                            p_a1Zms = double g_a1Zmr
                            (g_a1Zmr, gpart_a1Zo5) = Genome.Split.split gpart_a1Zo4
                            p_a1Zmq = double g_a1Zmp
                            (g_a1Zmp, gpart_a1Zo4) = Genome.Split.split gpart_a1Zo3
                            p_a1Zmo = Functions.belowten' g_a1Zmn
                            (g_a1Zmn, gpart_a1Zo3) = Genome.Split.split gpart_a1Zo2
                            p_a1Zmm = double g_a1Zml
                            (g_a1Zml, gpart_a1Zo2) = Genome.Split.split gpart_a1Zo1
                            p_a1Zmk = double g_a1Zmj
                            (g_a1Zmj, gpart_a1Zo1) = Genome.Split.split gpart_a1Zo0
                            p_a1Zmi = double g_a1Zmh
                            (g_a1Zmh, gpart_a1Zo0) = Genome.Split.split gpart_a1ZnZ
                            p_a1Zmg = Functions.belowten' g_a1Zmf
                            (g_a1Zmf, gpart_a1ZnZ) = Genome.Split.split gpart_a1ZnY
                            p_a1Zme = double g_a1Zmd
                            (g_a1Zmd, gpart_a1ZnY) = Genome.Split.split gpart_a1ZnX
                            p_a1Zmc
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zmb
                            (g_a1Zmb, gpart_a1ZnX) = Genome.Split.split gpart_a1ZnW
                            p_a1Zma
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zm9
                            (g_a1Zm9, gpart_a1ZnW) = Genome.Split.split gpart_a1ZnV
                            p_a1Zm8 = Functions.belowten' g_a1Zm7
                            (g_a1Zm7, gpart_a1ZnV) = Genome.Split.split gpart_a1ZnU
                            p_a1Zm6 = double g_a1Zm5
                            (g_a1Zm5, gpart_a1ZnU) = Genome.Split.split gpart_a1ZnT
                            p_a1Zm4 = double g_a1Zm3
                            (g_a1Zm3, gpart_a1ZnT) = Genome.Split.split gpart_a1ZnS
                            p_a1Zm2 = double g_a1Zm1
                            (g_a1Zm1, gpart_a1ZnS) = Genome.Split.split gpart_a1ZnR
                            p_a1Zm0 = Functions.belowten' g_a1ZlZ
                            (g_a1ZlZ, gpart_a1ZnR) = Genome.Split.split gpart_a1ZnQ
                            p_a1ZlY = double g_a1ZlX
                            (g_a1ZlX, gpart_a1ZnQ) = Genome.Split.split gpart_a1ZnP
                            p_a1ZlW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlV
                            (g_a1ZlV, gpart_a1ZnP) = Genome.Split.split gpart_a1ZnO
                            p_a1ZlU
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZlT
                            (g_a1ZlT, gpart_a1ZnO) = Genome.Split.split gpart_a1ZnN
                            p_a1ZlS = double g_a1ZlR
                            (g_a1ZlR, gpart_a1ZnN) = Genome.Split.split gpart_a1ZnM
                            p_a1ZlQ = Functions.belowten' g_a1ZlP
                            (g_a1ZlP, gpart_a1ZnM) = Genome.Split.split gpart_a1ZnL
                            p_a1ZlO = double g_a1ZlN
                            (g_a1ZlN, gpart_a1ZnL) = Genome.Split.split gpart_a1ZnK
                            p_a1ZlM = Functions.belowten' g_a1ZlL
                            (g_a1ZlL, gpart_a1ZnK) = Genome.Split.split gpart_a1ZnJ
                            p_a1ZlK = double g_a1ZlJ
                            (g_a1ZlJ, gpart_a1ZnJ) = Genome.Split.split gpart_a1ZnI
                            p_a1ZlI = double g_a1ZlH
                            (g_a1ZlH, gpart_a1ZnI) = Genome.Split.split gpart_a1ZnH
                            p_a1ZlG = Functions.belowten' g_a1ZlF
                            (g_a1ZlF, gpart_a1ZnH) = Genome.Split.split gpart_a1ZnG
                            p_a1ZlE = double g_a1ZlD
                            (g_a1ZlD, gpart_a1ZnG) = Genome.Split.split gpart_a1ZnF
                            p_a1ZlC = Functions.belowten' g_a1ZlB
                            (g_a1ZlB, gpart_a1ZnF) = Genome.Split.split gpart_a1ZnE
                            p_a1ZlA = double g_a1Zlz
                            (g_a1Zlz, gpart_a1ZnE) = Genome.Split.split gpart_a1ZnD
                            p_a1Zly
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlx
                            (g_a1Zlx, gpart_a1ZnD) = Genome.Split.split gpart_a1ZnC
                            p_a1Zlw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zlv
                            (g_a1Zlv, gpart_a1ZnC) = Genome.Split.split gpart_a1ZnB
                            p_a1Zlu = double g_a1Zlt
                            (g_a1Zlt, gpart_a1ZnB) = Genome.Split.split gpart_a1ZnA
                            p_a1Zls = double g_a1Zlr
                            (g_a1Zlr, gpart_a1ZnA) = Genome.Split.split gpart_a1Znz
                            p_a1Zlq = double g_a1Zlp
                            (g_a1Zlp, gpart_a1Znz) = Genome.Split.split gpart_a1Zny
                            p_a1Zlo = double g_a1Zln
                            (g_a1Zln, gpart_a1Zny) = Genome.Split.split gpart_a1Znx
                            p_a1Zlm = double g_a1Zll
                            (g_a1Zll, gpart_a1Znx) = Genome.Split.split genome_a1Zmz
                          in
                            \ desc_a1ZmA
                              -> case desc_a1ZmA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlm)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlo)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlq)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zls)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlu)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zlw)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zly)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlA)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlC)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlE)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlG)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlI)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlK)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlM)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlO)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlQ)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlS)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlU)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlW)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZlY)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm0)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm2)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm4)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm6)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zm8)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zma)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmc)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zme)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmg)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmi)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmk)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmm)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmo)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zms)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmu)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zmy)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asUb
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asUO
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asUO) = Genome.Split.split gpart_asUN
                      p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                      (g_asU7, gpart_asUN) = Genome.Split.split gpart_asUM
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asUM) = Genome.Split.split gpart_asUL
                      p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                      (g_asU3, gpart_asUL) = Genome.Split.split gpart_asUK
                      p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                      (g_asU1, gpart_asUK) = Genome.Split.split gpart_asUJ
                      p_asU0 = Functions.belowten' g_asTZ
                      (g_asTZ, gpart_asUJ) = Genome.Split.split gpart_asUI
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asUI) = Genome.Split.split gpart_asUH
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asUH) = Genome.Split.split gpart_asUG
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asUG) = Genome.Split.split gpart_asUF
                      p_asTS = Functions.belowten' g_asTR
                      (g_asTR, gpart_asUF) = Genome.Split.split gpart_asUE
                      p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                      (g_asTP, gpart_asUE) = Genome.Split.split gpart_asUD
                      p_asTO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTN
                      (g_asTN, gpart_asUD) = Genome.Split.split gpart_asUC
                      p_asTM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTL
                      (g_asTL, gpart_asUC) = Genome.Split.split gpart_asUB
                      p_asTK = Functions.belowten' g_asTJ
                      (g_asTJ, gpart_asUB) = Genome.Split.split gpart_asUA
                      p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                      (g_asTH, gpart_asUA) = Genome.Split.split gpart_asUz
                      p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                      (g_asTF, gpart_asUz) = Genome.Split.split gpart_asUy
                      p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                      (g_asTD, gpart_asUy) = Genome.Split.split gpart_asUx
                      p_asTC = Functions.belowten' g_asTB
                      (g_asTB, gpart_asUx) = Genome.Split.split gpart_asUw
                      p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                      (g_asTz, gpart_asUw) = Genome.Split.split gpart_asUv
                      p_asTy
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                      (g_asTx, gpart_asUv) = Genome.Split.split gpart_asUu
                      p_asTw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTv
                      (g_asTv, gpart_asUu) = Genome.Split.split gpart_asUt
                      p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                      (g_asTt, gpart_asUt) = Genome.Split.split gpart_asUs
                      p_asTs = Functions.belowten' g_asTr
                      (g_asTr, gpart_asUs) = Genome.Split.split gpart_asUr
                      p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                      (g_asTp, gpart_asUr) = Genome.Split.split gpart_asUq
                      p_asTo = Functions.belowten' g_asTn
                      (g_asTn, gpart_asUq) = Genome.Split.split gpart_asUp
                      p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                      (g_asTl, gpart_asUp) = Genome.Split.split gpart_asUo
                      p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                      (g_asTj, gpart_asUo) = Genome.Split.split gpart_asUn
                      p_asTi = Functions.belowten' g_asTh
                      (g_asTh, gpart_asUn) = Genome.Split.split gpart_asUm
                      p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                      (g_asTf, gpart_asUm) = Genome.Split.split gpart_asUl
                      p_asTe = Functions.belowten' g_asTd
                      (g_asTd, gpart_asUl) = Genome.Split.split gpart_asUk
                      p_asTc = code-0.1.0.0:Genome.FixedList.Functions.double g_asTb
                      (g_asTb, gpart_asUk) = Genome.Split.split gpart_asUj
                      p_asTa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT9
                      (g_asT9, gpart_asUj) = Genome.Split.split gpart_asUi
                      p_asT8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                      (g_asT7, gpart_asUi) = Genome.Split.split gpart_asUh
                      p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                      (g_asT5, gpart_asUh) = Genome.Split.split gpart_asUg
                      p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                      (g_asT3, gpart_asUg) = Genome.Split.split gpart_asUf
                      p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                      (g_asT1, gpart_asUf) = Genome.Split.split gpart_asUe
                      p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                      (g_asSZ, gpart_asUe) = Genome.Split.split gpart_asUd
                      p_asSY = code-0.1.0.0:Genome.FixedList.Functions.double g_asSX
                      (g_asSX, gpart_asUd) = Genome.Split.split genome_asUb
                    in
                      [Reaction
                         (\ x_asUP
                            -> let
                                 c_RESTc_asUQ = ((toVector x_asUP) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asUR = ((toVector x_asUP) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asT6
                                  / (1
                                     + (((c_RESTc_asUQ / p_asTc) ** p_asTe)
                                        + ((c_MiRs_asUR / p_asTg) ** p_asTi)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asUS
                            -> let
                                 c_MiRs_asUT = ((toVector x_asUS) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUU = ((toVector x_asUS) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTk
                                  / (1
                                     + (((c_MiRs_asUT / p_asTm) ** p_asTo)
                                        + ((c_PTB_asUU / p_asTq) ** p_asTs)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asUV
                            -> let c_RESTc_asUW = ((toVector x_asUV) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asTu
                                  * ((p_asTE + ((p_asT2 / p_asTw) ** p_asTy))
                                     / (((1 + p_asTE) + ((p_asT2 / p_asTw) ** p_asTy))
                                        + ((c_RESTc_asUW / p_asTA) ** p_asTC)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asUX
                            -> let
                                 c_MiRs_asV0 = ((toVector x_asUX) Data.Vector.Unboxed.! 2)
                                 c_PTB_asUY = ((toVector x_asUX) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asTG
                                  * ((p_asTU + ((c_PTB_asUY / p_asTI) ** p_asTK))
                                     / (((1 + p_asTU) + ((c_PTB_asUY / p_asTI) ** p_asTK))
                                        + (((p_asSY / p_asTM) ** p_asTO)
                                           + ((c_MiRs_asV0 / p_asTQ) ** p_asTS))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asV1
                            -> let c_RESTc_asV2 = ((toVector x_asV1) Data.Vector.Unboxed.! 3)
                               in (p_asTW / (1 + ((c_RESTc_asV2 / p_asTY) ** p_asU0))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asV3
                            -> let c_PTB_asV4 = ((toVector x_asV3) Data.Vector.Unboxed.! 0)
                               in (p_asU2 * c_PTB_asV4))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asV5
                            -> let c_NPTB_asV6 = ((toVector x_asV5) Data.Vector.Unboxed.! 1)
                               in (p_asU4 * c_NPTB_asV6))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asV7
                            -> let c_MiRs_asV8 = ((toVector x_asV7) Data.Vector.Unboxed.! 2)
                               in (p_asU6 * c_MiRs_asV8))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asV9
                            -> let c_RESTc_asVa = ((toVector x_asV9) Data.Vector.Unboxed.! 3)
                               in (p_asU8 * c_RESTc_asVa))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asVb
                            -> let
                                 c_EndoNeuroTFs_asVc = ((toVector x_asVb) Data.Vector.Unboxed.! 4)
                               in (p_asUa * c_EndoNeuroTFs_asVc))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120831",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120832",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120833",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120834",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120835",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120836",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120837",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120838",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120839",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120840",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120841",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120842",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120843",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120844",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120845",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120846",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120847",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120848",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120849",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120850",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120851",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120852",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120853",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120854",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120855",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120856",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120857",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120858",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120859",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120860",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120861",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120862",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120863",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120864",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120865",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120866",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120867",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120868",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120869",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120870",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120871",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120872",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120873",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120874",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120875",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120876",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120877",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120878",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120879",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120880",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120881",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120882",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120883",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120884",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120885",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120886",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asUb
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVT
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asVT) = Genome.Split.split gpart_asVS
                            p_asU8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU7
                            (g_asU7, gpart_asVS) = Genome.Split.split gpart_asVR
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asVR) = Genome.Split.split gpart_asVQ
                            p_asU4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU3
                            (g_asU3, gpart_asVQ) = Genome.Split.split gpart_asVP
                            p_asU2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU1
                            (g_asU1, gpart_asVP) = Genome.Split.split gpart_asVO
                            p_asU0 = Functions.belowten' g_asTZ
                            (g_asTZ, gpart_asVO) = Genome.Split.split gpart_asVN
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asVN) = Genome.Split.split gpart_asVM
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asVM) = Genome.Split.split gpart_asVL
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asVL) = Genome.Split.split gpart_asVK
                            p_asTS = Functions.belowten' g_asTR
                            (g_asTR, gpart_asVK) = Genome.Split.split gpart_asVJ
                            p_asTQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTP
                            (g_asTP, gpart_asVJ) = Genome.Split.split gpart_asVI
                            p_asTO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTN
                            (g_asTN, gpart_asVI) = Genome.Split.split gpart_asVH
                            p_asTM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTL
                            (g_asTL, gpart_asVH) = Genome.Split.split gpart_asVG
                            p_asTK = Functions.belowten' g_asTJ
                            (g_asTJ, gpart_asVG) = Genome.Split.split gpart_asVF
                            p_asTI = code-0.1.0.0:Genome.FixedList.Functions.double g_asTH
                            (g_asTH, gpart_asVF) = Genome.Split.split gpart_asVE
                            p_asTG = code-0.1.0.0:Genome.FixedList.Functions.double g_asTF
                            (g_asTF, gpart_asVE) = Genome.Split.split gpart_asVD
                            p_asTE = code-0.1.0.0:Genome.FixedList.Functions.double g_asTD
                            (g_asTD, gpart_asVD) = Genome.Split.split gpart_asVC
                            p_asTC = Functions.belowten' g_asTB
                            (g_asTB, gpart_asVC) = Genome.Split.split gpart_asVB
                            p_asTA = code-0.1.0.0:Genome.FixedList.Functions.double g_asTz
                            (g_asTz, gpart_asVB) = Genome.Split.split gpart_asVA
                            p_asTy
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTx
                            (g_asTx, gpart_asVA) = Genome.Split.split gpart_asVz
                            p_asTw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asTv
                            (g_asTv, gpart_asVz) = Genome.Split.split gpart_asVy
                            p_asTu = code-0.1.0.0:Genome.FixedList.Functions.double g_asTt
                            (g_asTt, gpart_asVy) = Genome.Split.split gpart_asVx
                            p_asTs = Functions.belowten' g_asTr
                            (g_asTr, gpart_asVx) = Genome.Split.split gpart_asVw
                            p_asTq = code-0.1.0.0:Genome.FixedList.Functions.double g_asTp
                            (g_asTp, gpart_asVw) = Genome.Split.split gpart_asVv
                            p_asTo = Functions.belowten' g_asTn
                            (g_asTn, gpart_asVv) = Genome.Split.split gpart_asVu
                            p_asTm = code-0.1.0.0:Genome.FixedList.Functions.double g_asTl
                            (g_asTl, gpart_asVu) = Genome.Split.split gpart_asVt
                            p_asTk = code-0.1.0.0:Genome.FixedList.Functions.double g_asTj
                            (g_asTj, gpart_asVt) = Genome.Split.split gpart_asVs
                            p_asTi = Functions.belowten' g_asTh
                            (g_asTh, gpart_asVs) = Genome.Split.split gpart_asVr
                            p_asTg = code-0.1.0.0:Genome.FixedList.Functions.double g_asTf
                            (g_asTf, gpart_asVr) = Genome.Split.split gpart_asVq
                            p_asTe = Functions.belowten' g_asTd
                            (g_asTd, gpart_asVq) = Genome.Split.split gpart_asVp
                            p_asTc = code-0.1.0.0:Genome.FixedList.Functions.double g_asTb
                            (g_asTb, gpart_asVp) = Genome.Split.split gpart_asVo
                            p_asTa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT9
                            (g_asT9, gpart_asVo) = Genome.Split.split gpart_asVn
                            p_asT8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asT7
                            (g_asT7, gpart_asVn) = Genome.Split.split gpart_asVm
                            p_asT6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT5
                            (g_asT5, gpart_asVm) = Genome.Split.split gpart_asVl
                            p_asT4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT3
                            (g_asT3, gpart_asVl) = Genome.Split.split gpart_asVk
                            p_asT2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asT1
                            (g_asT1, gpart_asVk) = Genome.Split.split gpart_asVj
                            p_asT0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asSZ
                            (g_asSZ, gpart_asVj) = Genome.Split.split gpart_asVi
                            p_asSY = code-0.1.0.0:Genome.FixedList.Functions.double g_asSX
                            (g_asSX, gpart_asVi) = Genome.Split.split genome_asUb
                          in
                            \ desc_asUc
                              -> case desc_asUc of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asSY)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT0)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT2)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT4)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT6)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asT8)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTa)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTc)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTe)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTg)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTi)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTk)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTm)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTo)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTq)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTs)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTu)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTw)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTy)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTA)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTC)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTE)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTG)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTI)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTK)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTM)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTO)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTQ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asXO
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asYr
                      p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                      (g_asXM, gpart_asYr) = Genome.Split.split gpart_asYq
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asYq) = Genome.Split.split gpart_asYp
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYp) = Genome.Split.split gpart_asYo
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asYo) = Genome.Split.split gpart_asYn
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asYn) = Genome.Split.split gpart_asYm
                      p_asXD = Functions.belowten' g_asXC
                      (g_asXC, gpart_asYm) = Genome.Split.split gpart_asYl
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYl) = Genome.Split.split gpart_asYk
                      p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                      (g_asXy, gpart_asYk) = Genome.Split.split gpart_asYj
                      p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                      (g_asXw, gpart_asYj) = Genome.Split.split gpart_asYi
                      p_asXv = Functions.belowten' g_asXu
                      (g_asXu, gpart_asYi) = Genome.Split.split gpart_asYh
                      p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                      (g_asXs, gpart_asYh) = Genome.Split.split gpart_asYg
                      p_asXr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                      (g_asXq, gpart_asYg) = Genome.Split.split gpart_asYf
                      p_asXp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXo
                      (g_asXo, gpart_asYf) = Genome.Split.split gpart_asYe
                      p_asXn = Functions.belowten' g_asXm
                      (g_asXm, gpart_asYe) = Genome.Split.split gpart_asYd
                      p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                      (g_asXk, gpart_asYd) = Genome.Split.split gpart_asYc
                      p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                      (g_asXi, gpart_asYc) = Genome.Split.split gpart_asYb
                      p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                      (g_asXg, gpart_asYb) = Genome.Split.split gpart_asYa
                      p_asXf = Functions.belowten' g_asXe
                      (g_asXe, gpart_asYa) = Genome.Split.split gpart_asY9
                      p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                      (g_asXc, gpart_asY9) = Genome.Split.split gpart_asY8
                      p_asXb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                      (g_asXa, gpart_asY8) = Genome.Split.split gpart_asY7
                      p_asX9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX8
                      (g_asX8, gpart_asY7) = Genome.Split.split gpart_asY6
                      p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                      (g_asX6, gpart_asY6) = Genome.Split.split gpart_asY5
                      p_asX5 = Functions.belowten' g_asX4
                      (g_asX4, gpart_asY5) = Genome.Split.split gpart_asY4
                      p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                      (g_asX2, gpart_asY4) = Genome.Split.split gpart_asY3
                      p_asX1 = Functions.belowten' g_asX0
                      (g_asX0, gpart_asY3) = Genome.Split.split gpart_asY2
                      p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                      (g_asWY, gpart_asY2) = Genome.Split.split gpart_asY1
                      p_asWX = code-0.1.0.0:Genome.FixedList.Functions.double g_asWW
                      (g_asWW, gpart_asY1) = Genome.Split.split gpart_asY0
                      p_asWV = Functions.belowten' g_asWU
                      (g_asWU, gpart_asY0) = Genome.Split.split gpart_asXZ
                      p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                      (g_asWS, gpart_asXZ) = Genome.Split.split gpart_asXY
                      p_asWR = Functions.belowten' g_asWQ
                      (g_asWQ, gpart_asXY) = Genome.Split.split gpart_asXX
                      p_asWP = code-0.1.0.0:Genome.FixedList.Functions.double g_asWO
                      (g_asWO, gpart_asXX) = Genome.Split.split gpart_asXW
                      p_asWN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWM
                      (g_asWM, gpart_asXW) = Genome.Split.split gpart_asXV
                      p_asWL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWK
                      (g_asWK, gpart_asXV) = Genome.Split.split gpart_asXU
                      p_asWJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWI
                      (g_asWI, gpart_asXU) = Genome.Split.split gpart_asXT
                      p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                      (g_asWG, gpart_asXT) = Genome.Split.split gpart_asXS
                      p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                      (g_asWE, gpart_asXS) = Genome.Split.split gpart_asXR
                      p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                      (g_asWC, gpart_asXR) = Genome.Split.split gpart_asXQ
                      p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                      (g_asWA, gpart_asXQ) = Genome.Split.split genome_asXO
                    in
                      [Reaction
                         (\ x_asYs
                            -> let
                                 c_RESTc_asYt = ((toVector x_asYs) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asYu = ((toVector x_asYs) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asWJ
                                  / (1
                                     + (((c_RESTc_asYt / p_asWP) ** p_asWR)
                                        + ((c_MiRs_asYu / p_asWT) ** p_asWV)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYv
                            -> let
                                 c_MiRs_asYw = ((toVector x_asYv) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYx = ((toVector x_asYv) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asWX
                                  / (1
                                     + (((c_MiRs_asYw / p_asWZ) ** p_asX1)
                                        + ((c_PTB_asYx / p_asX3) ** p_asX5)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asYy
                            -> let c_RESTc_asYz = ((toVector x_asYy) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asX7
                                  * (p_asXh
                                     / ((1 + p_asXh) + ((c_RESTc_asYz / p_asXd) ** p_asXf)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asYA
                            -> let
                                 c_MiRs_asYD = ((toVector x_asYA) Data.Vector.Unboxed.! 2)
                                 c_PTB_asYB = ((toVector x_asYA) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXj
                                  * ((p_asXx + ((c_PTB_asYB / p_asXl) ** p_asXn))
                                     / (((1 + p_asXx) + ((c_PTB_asYB / p_asXl) ** p_asXn))
                                        + (((p_asWB / p_asXp) ** p_asXr)
                                           + ((c_MiRs_asYD / p_asXt) ** p_asXv))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asYE
                            -> let c_RESTc_asYF = ((toVector x_asYE) Data.Vector.Unboxed.! 3)
                               in (p_asXz / (1 + ((c_RESTc_asYF / p_asXB) ** p_asXD))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asYG
                            -> let c_PTB_asYH = ((toVector x_asYG) Data.Vector.Unboxed.! 0)
                               in (p_asXF * c_PTB_asYH))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asYI
                            -> let c_NPTB_asYJ = ((toVector x_asYI) Data.Vector.Unboxed.! 1)
                               in (p_asXH * c_NPTB_asYJ))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asYK
                            -> let c_MiRs_asYL = ((toVector x_asYK) Data.Vector.Unboxed.! 2)
                               in (p_asXJ * c_MiRs_asYL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asYM
                            -> let c_RESTc_asYN = ((toVector x_asYM) Data.Vector.Unboxed.! 3)
                               in (p_asXL * c_RESTc_asYN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asYO
                            -> let
                                 c_EndoNeuroTFs_asYP = ((toVector x_asYO) Data.Vector.Unboxed.! 4)
                               in (p_asXN * c_EndoNeuroTFs_asYP))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121056",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121057",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121058",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121059",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121060",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121061",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121062",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121063",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121064",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121065",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121066",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121067",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121068",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121069",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121070",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121071",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121072",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121073",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121074",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121075",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121091",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121093",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121107",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121109",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121113",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121115",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asXO
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZr
                            p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                            (g_asXM, gpart_asZr) = Genome.Split.split gpart_asZq
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_asZq) = Genome.Split.split gpart_asZp
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZp) = Genome.Split.split gpart_asZo
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_asZo) = Genome.Split.split gpart_asZn
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_asZn) = Genome.Split.split gpart_asZm
                            p_asXD = Functions.belowten' g_asXC
                            (g_asXC, gpart_asZm) = Genome.Split.split gpart_asZl
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZl) = Genome.Split.split gpart_asZk
                            p_asXz = code-0.1.0.0:Genome.FixedList.Functions.double g_asXy
                            (g_asXy, gpart_asZk) = Genome.Split.split gpart_asZj
                            p_asXx = code-0.1.0.0:Genome.FixedList.Functions.double g_asXw
                            (g_asXw, gpart_asZj) = Genome.Split.split gpart_asZi
                            p_asXv = Functions.belowten' g_asXu
                            (g_asXu, gpart_asZi) = Genome.Split.split gpart_asZh
                            p_asXt = code-0.1.0.0:Genome.FixedList.Functions.double g_asXs
                            (g_asXs, gpart_asZh) = Genome.Split.split gpart_asZg
                            p_asXr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXq
                            (g_asXq, gpart_asZg) = Genome.Split.split gpart_asZf
                            p_asXp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXo
                            (g_asXo, gpart_asZf) = Genome.Split.split gpart_asZe
                            p_asXn = Functions.belowten' g_asXm
                            (g_asXm, gpart_asZe) = Genome.Split.split gpart_asZd
                            p_asXl = code-0.1.0.0:Genome.FixedList.Functions.double g_asXk
                            (g_asXk, gpart_asZd) = Genome.Split.split gpart_asZc
                            p_asXj = code-0.1.0.0:Genome.FixedList.Functions.double g_asXi
                            (g_asXi, gpart_asZc) = Genome.Split.split gpart_asZb
                            p_asXh = code-0.1.0.0:Genome.FixedList.Functions.double g_asXg
                            (g_asXg, gpart_asZb) = Genome.Split.split gpart_asZa
                            p_asXf = Functions.belowten' g_asXe
                            (g_asXe, gpart_asZa) = Genome.Split.split gpart_asZ9
                            p_asXd = code-0.1.0.0:Genome.FixedList.Functions.double g_asXc
                            (g_asXc, gpart_asZ9) = Genome.Split.split gpart_asZ8
                            p_asXb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXa
                            (g_asXa, gpart_asZ8) = Genome.Split.split gpart_asZ7
                            p_asX9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asX8
                            (g_asX8, gpart_asZ7) = Genome.Split.split gpart_asZ6
                            p_asX7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX6
                            (g_asX6, gpart_asZ6) = Genome.Split.split gpart_asZ5
                            p_asX5 = Functions.belowten' g_asX4
                            (g_asX4, gpart_asZ5) = Genome.Split.split gpart_asZ4
                            p_asX3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asX2
                            (g_asX2, gpart_asZ4) = Genome.Split.split gpart_asZ3
                            p_asX1 = Functions.belowten' g_asX0
                            (g_asX0, gpart_asZ3) = Genome.Split.split gpart_asZ2
                            p_asWZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWY
                            (g_asWY, gpart_asZ2) = Genome.Split.split gpart_asZ1
                            p_asWX = code-0.1.0.0:Genome.FixedList.Functions.double g_asWW
                            (g_asWW, gpart_asZ1) = Genome.Split.split gpart_asZ0
                            p_asWV = Functions.belowten' g_asWU
                            (g_asWU, gpart_asZ0) = Genome.Split.split gpart_asYZ
                            p_asWT = code-0.1.0.0:Genome.FixedList.Functions.double g_asWS
                            (g_asWS, gpart_asYZ) = Genome.Split.split gpart_asYY
                            p_asWR = Functions.belowten' g_asWQ
                            (g_asWQ, gpart_asYY) = Genome.Split.split gpart_asYX
                            p_asWP = code-0.1.0.0:Genome.FixedList.Functions.double g_asWO
                            (g_asWO, gpart_asYX) = Genome.Split.split gpart_asYW
                            p_asWN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWM
                            (g_asWM, gpart_asYW) = Genome.Split.split gpart_asYV
                            p_asWL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asWK
                            (g_asWK, gpart_asYV) = Genome.Split.split gpart_asYU
                            p_asWJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asWI
                            (g_asWI, gpart_asYU) = Genome.Split.split gpart_asYT
                            p_asWH = code-0.1.0.0:Genome.FixedList.Functions.double g_asWG
                            (g_asWG, gpart_asYT) = Genome.Split.split gpart_asYS
                            p_asWF = code-0.1.0.0:Genome.FixedList.Functions.double g_asWE
                            (g_asWE, gpart_asYS) = Genome.Split.split gpart_asYR
                            p_asWD = code-0.1.0.0:Genome.FixedList.Functions.double g_asWC
                            (g_asWC, gpart_asYR) = Genome.Split.split gpart_asYQ
                            p_asWB = code-0.1.0.0:Genome.FixedList.Functions.double g_asWA
                            (g_asWA, gpart_asYQ) = Genome.Split.split genome_asXO
                          in
                            \ desc_asXP
                              -> case desc_asXP of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWB)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWD)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWF)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWH)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWJ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWL)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWN)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWP)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWR)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWT)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWV)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWX)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asWZ)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX1)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX3)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX5)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX7)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asX9)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXb)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXd)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXf)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXh)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXj)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXl)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXn)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXp)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXr)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXt)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXv)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXx)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXz)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at1m
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1Z
                      p_at1l = code-0.1.0.0:Genome.FixedList.Functions.double g_at1k
                      (g_at1k, gpart_at1Z) = Genome.Split.split gpart_at1Y
                      p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                      (g_at1i, gpart_at1Y) = Genome.Split.split gpart_at1X
                      p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                      (g_at1g, gpart_at1X) = Genome.Split.split gpart_at1W
                      p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                      (g_at1e, gpart_at1W) = Genome.Split.split gpart_at1V
                      p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                      (g_at1c, gpart_at1V) = Genome.Split.split gpart_at1U
                      p_at1b = Functions.belowten' g_at1a
                      (g_at1a, gpart_at1U) = Genome.Split.split gpart_at1T
                      p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                      (g_at18, gpart_at1T) = Genome.Split.split gpart_at1S
                      p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                      (g_at16, gpart_at1S) = Genome.Split.split gpart_at1R
                      p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                      (g_at14, gpart_at1R) = Genome.Split.split gpart_at1Q
                      p_at13 = Functions.belowten' g_at12
                      (g_at12, gpart_at1Q) = Genome.Split.split gpart_at1P
                      p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                      (g_at10, gpart_at1P) = Genome.Split.split gpart_at1O
                      p_at0Z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Y
                      (g_at0Y, gpart_at1O) = Genome.Split.split gpart_at1N
                      p_at0X
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0W
                      (g_at0W, gpart_at1N) = Genome.Split.split gpart_at1M
                      p_at0V = Functions.belowten' g_at0U
                      (g_at0U, gpart_at1M) = Genome.Split.split gpart_at1L
                      p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                      (g_at0S, gpart_at1L) = Genome.Split.split gpart_at1K
                      p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                      (g_at0Q, gpart_at1K) = Genome.Split.split gpart_at1J
                      p_at0P = code-0.1.0.0:Genome.FixedList.Functions.double g_at0O
                      (g_at0O, gpart_at1J) = Genome.Split.split gpart_at1I
                      p_at0N = Functions.belowten' g_at0M
                      (g_at0M, gpart_at1I) = Genome.Split.split gpart_at1H
                      p_at0L = code-0.1.0.0:Genome.FixedList.Functions.double g_at0K
                      (g_at0K, gpart_at1H) = Genome.Split.split gpart_at1G
                      p_at0J
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                      (g_at0I, gpart_at1G) = Genome.Split.split gpart_at1F
                      p_at0H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0G
                      (g_at0G, gpart_at1F) = Genome.Split.split gpart_at1E
                      p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                      (g_at0E, gpart_at1E) = Genome.Split.split gpart_at1D
                      p_at0D = Functions.belowten' g_at0C
                      (g_at0C, gpart_at1D) = Genome.Split.split gpart_at1C
                      p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                      (g_at0A, gpart_at1C) = Genome.Split.split gpart_at1B
                      p_at0z = Functions.belowten' g_at0y
                      (g_at0y, gpart_at1B) = Genome.Split.split gpart_at1A
                      p_at0x = code-0.1.0.0:Genome.FixedList.Functions.double g_at0w
                      (g_at0w, gpart_at1A) = Genome.Split.split gpart_at1z
                      p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                      (g_at0u, gpart_at1z) = Genome.Split.split gpart_at1y
                      p_at0t = Functions.belowten' g_at0s
                      (g_at0s, gpart_at1y) = Genome.Split.split gpart_at1x
                      p_at0r = code-0.1.0.0:Genome.FixedList.Functions.double g_at0q
                      (g_at0q, gpart_at1x) = Genome.Split.split gpart_at1w
                      p_at0p = Functions.belowten' g_at0o
                      (g_at0o, gpart_at1w) = Genome.Split.split gpart_at1v
                      p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                      (g_at0m, gpart_at1v) = Genome.Split.split gpart_at1u
                      p_at0l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0k
                      (g_at0k, gpart_at1u) = Genome.Split.split gpart_at1t
                      p_at0j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0i
                      (g_at0i, gpart_at1t) = Genome.Split.split gpart_at1s
                      p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                      (g_at0g, gpart_at1s) = Genome.Split.split gpart_at1r
                      p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                      (g_at0e, gpart_at1r) = Genome.Split.split gpart_at1q
                      p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                      (g_at0c, gpart_at1q) = Genome.Split.split gpart_at1p
                      p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                      (g_at0a, gpart_at1p) = Genome.Split.split gpart_at1o
                      p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                      (g_at08, gpart_at1o) = Genome.Split.split genome_at1m
                    in
                      [Reaction
                         (\ x_at20
                            -> let
                                 c_RESTc_at21 = ((toVector x_at20) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at22 = ((toVector x_at20) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at0h
                                  / (1
                                     + (((c_RESTc_at21 / p_at0n) ** p_at0p)
                                        + ((c_MiRs_at22 / p_at0r) ** p_at0t)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at23
                            -> let
                                 c_MiRs_at24 = ((toVector x_at23) Data.Vector.Unboxed.! 2)
                                 c_PTB_at25 = ((toVector x_at23) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0v
                                  / (1
                                     + (((c_MiRs_at24 / p_at0x) ** p_at0z)
                                        + ((c_PTB_at25 / p_at0B) ** p_at0D)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at26
                            -> let c_RESTc_at27 = ((toVector x_at26) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at0F
                                  * (p_at0P
                                     / ((1 + p_at0P) + ((c_RESTc_at27 / p_at0L) ** p_at0N)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at28
                            -> let
                                 c_MiRs_at2b = ((toVector x_at28) Data.Vector.Unboxed.! 2)
                                 c_PTB_at29 = ((toVector x_at28) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at0R
                                  * ((p_at15 + ((c_PTB_at29 / p_at0T) ** p_at0V))
                                     / (((1 + p_at15) + ((c_PTB_at29 / p_at0T) ** p_at0V))
                                        + ((c_MiRs_at2b / p_at11) ** p_at13)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at2c
                            -> let c_RESTc_at2d = ((toVector x_at2c) Data.Vector.Unboxed.! 3)
                               in (p_at17 / (1 + ((c_RESTc_at2d / p_at19) ** p_at1b))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at2e
                            -> let c_PTB_at2f = ((toVector x_at2e) Data.Vector.Unboxed.! 0)
                               in (p_at1d * c_PTB_at2f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2g
                            -> let c_NPTB_at2h = ((toVector x_at2g) Data.Vector.Unboxed.! 1)
                               in (p_at1f * c_NPTB_at2h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at2i
                            -> let c_MiRs_at2j = ((toVector x_at2i) Data.Vector.Unboxed.! 2)
                               in (p_at1h * c_MiRs_at2j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at2k
                            -> let c_RESTc_at2l = ((toVector x_at2k) Data.Vector.Unboxed.! 3)
                               in (p_at1j * c_RESTc_at2l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at2m
                            -> let
                                 c_EndoNeuroTFs_at2n = ((toVector x_at2m) Data.Vector.Unboxed.! 4)
                               in (p_at1l * c_EndoNeuroTFs_at2n))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121285",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121287",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121289",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121311",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121313",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121317",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121319",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121327",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121329",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121333",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121335",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at1m
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2Z
                            p_at1l = code-0.1.0.0:Genome.FixedList.Functions.double g_at1k
                            (g_at1k, gpart_at2Z) = Genome.Split.split gpart_at2Y
                            p_at1j = code-0.1.0.0:Genome.FixedList.Functions.double g_at1i
                            (g_at1i, gpart_at2Y) = Genome.Split.split gpart_at2X
                            p_at1h = code-0.1.0.0:Genome.FixedList.Functions.double g_at1g
                            (g_at1g, gpart_at2X) = Genome.Split.split gpart_at2W
                            p_at1f = code-0.1.0.0:Genome.FixedList.Functions.double g_at1e
                            (g_at1e, gpart_at2W) = Genome.Split.split gpart_at2V
                            p_at1d = code-0.1.0.0:Genome.FixedList.Functions.double g_at1c
                            (g_at1c, gpart_at2V) = Genome.Split.split gpart_at2U
                            p_at1b = Functions.belowten' g_at1a
                            (g_at1a, gpart_at2U) = Genome.Split.split gpart_at2T
                            p_at19 = code-0.1.0.0:Genome.FixedList.Functions.double g_at18
                            (g_at18, gpart_at2T) = Genome.Split.split gpart_at2S
                            p_at17 = code-0.1.0.0:Genome.FixedList.Functions.double g_at16
                            (g_at16, gpart_at2S) = Genome.Split.split gpart_at2R
                            p_at15 = code-0.1.0.0:Genome.FixedList.Functions.double g_at14
                            (g_at14, gpart_at2R) = Genome.Split.split gpart_at2Q
                            p_at13 = Functions.belowten' g_at12
                            (g_at12, gpart_at2Q) = Genome.Split.split gpart_at2P
                            p_at11 = code-0.1.0.0:Genome.FixedList.Functions.double g_at10
                            (g_at10, gpart_at2P) = Genome.Split.split gpart_at2O
                            p_at0Z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0Y
                            (g_at0Y, gpart_at2O) = Genome.Split.split gpart_at2N
                            p_at0X
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0W
                            (g_at0W, gpart_at2N) = Genome.Split.split gpart_at2M
                            p_at0V = Functions.belowten' g_at0U
                            (g_at0U, gpart_at2M) = Genome.Split.split gpart_at2L
                            p_at0T = code-0.1.0.0:Genome.FixedList.Functions.double g_at0S
                            (g_at0S, gpart_at2L) = Genome.Split.split gpart_at2K
                            p_at0R = code-0.1.0.0:Genome.FixedList.Functions.double g_at0Q
                            (g_at0Q, gpart_at2K) = Genome.Split.split gpart_at2J
                            p_at0P = code-0.1.0.0:Genome.FixedList.Functions.double g_at0O
                            (g_at0O, gpart_at2J) = Genome.Split.split gpart_at2I
                            p_at0N = Functions.belowten' g_at0M
                            (g_at0M, gpart_at2I) = Genome.Split.split gpart_at2H
                            p_at0L = code-0.1.0.0:Genome.FixedList.Functions.double g_at0K
                            (g_at0K, gpart_at2H) = Genome.Split.split gpart_at2G
                            p_at0J
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0I
                            (g_at0I, gpart_at2G) = Genome.Split.split gpart_at2F
                            p_at0H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0G
                            (g_at0G, gpart_at2F) = Genome.Split.split gpart_at2E
                            p_at0F = code-0.1.0.0:Genome.FixedList.Functions.double g_at0E
                            (g_at0E, gpart_at2E) = Genome.Split.split gpart_at2D
                            p_at0D = Functions.belowten' g_at0C
                            (g_at0C, gpart_at2D) = Genome.Split.split gpart_at2C
                            p_at0B = code-0.1.0.0:Genome.FixedList.Functions.double g_at0A
                            (g_at0A, gpart_at2C) = Genome.Split.split gpart_at2B
                            p_at0z = Functions.belowten' g_at0y
                            (g_at0y, gpart_at2B) = Genome.Split.split gpart_at2A
                            p_at0x = code-0.1.0.0:Genome.FixedList.Functions.double g_at0w
                            (g_at0w, gpart_at2A) = Genome.Split.split gpart_at2z
                            p_at0v = code-0.1.0.0:Genome.FixedList.Functions.double g_at0u
                            (g_at0u, gpart_at2z) = Genome.Split.split gpart_at2y
                            p_at0t = Functions.belowten' g_at0s
                            (g_at0s, gpart_at2y) = Genome.Split.split gpart_at2x
                            p_at0r = code-0.1.0.0:Genome.FixedList.Functions.double g_at0q
                            (g_at0q, gpart_at2x) = Genome.Split.split gpart_at2w
                            p_at0p = Functions.belowten' g_at0o
                            (g_at0o, gpart_at2w) = Genome.Split.split gpart_at2v
                            p_at0n = code-0.1.0.0:Genome.FixedList.Functions.double g_at0m
                            (g_at0m, gpart_at2v) = Genome.Split.split gpart_at2u
                            p_at0l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0k
                            (g_at0k, gpart_at2u) = Genome.Split.split gpart_at2t
                            p_at0j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at0i
                            (g_at0i, gpart_at2t) = Genome.Split.split gpart_at2s
                            p_at0h = code-0.1.0.0:Genome.FixedList.Functions.double g_at0g
                            (g_at0g, gpart_at2s) = Genome.Split.split gpart_at2r
                            p_at0f = code-0.1.0.0:Genome.FixedList.Functions.double g_at0e
                            (g_at0e, gpart_at2r) = Genome.Split.split gpart_at2q
                            p_at0d = code-0.1.0.0:Genome.FixedList.Functions.double g_at0c
                            (g_at0c, gpart_at2q) = Genome.Split.split gpart_at2p
                            p_at0b = code-0.1.0.0:Genome.FixedList.Functions.double g_at0a
                            (g_at0a, gpart_at2p) = Genome.Split.split gpart_at2o
                            p_at09 = code-0.1.0.0:Genome.FixedList.Functions.double g_at08
                            (g_at08, gpart_at2o) = Genome.Split.split genome_at1m
                          in
                            \ desc_at1n
                              -> case desc_at1n of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at09)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0b)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0d)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0f)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0h)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0j)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0l)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0n)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0p)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0r)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0t)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0v)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0x)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0z)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0B)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0D)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0F)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0H)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0J)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0L)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0N)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0P)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0R)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0T)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0V)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0X)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at0Z)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at11)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at13)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at15)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at17)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at19)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1b)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1d)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1f)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1h)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1j)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1l)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at4U
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at5x
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at5x) = Genome.Split.split gpart_at5w
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at5w) = Genome.Split.split gpart_at5v
                      p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                      (g_at4O, gpart_at5v) = Genome.Split.split gpart_at5u
                      p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                      (g_at4M, gpart_at5u) = Genome.Split.split gpart_at5t
                      p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                      (g_at4K, gpart_at5t) = Genome.Split.split gpart_at5s
                      p_at4J = Functions.belowten' g_at4I
                      (g_at4I, gpart_at5s) = Genome.Split.split gpart_at5r
                      p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                      (g_at4G, gpart_at5r) = Genome.Split.split gpart_at5q
                      p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                      (g_at4E, gpart_at5q) = Genome.Split.split gpart_at5p
                      p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                      (g_at4C, gpart_at5p) = Genome.Split.split gpart_at5o
                      p_at4B = Functions.belowten' g_at4A
                      (g_at4A, gpart_at5o) = Genome.Split.split gpart_at5n
                      p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                      (g_at4y, gpart_at5n) = Genome.Split.split gpart_at5m
                      p_at4x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4w
                      (g_at4w, gpart_at5m) = Genome.Split.split gpart_at5l
                      p_at4v
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4u
                      (g_at4u, gpart_at5l) = Genome.Split.split gpart_at5k
                      p_at4t = Functions.belowten' g_at4s
                      (g_at4s, gpart_at5k) = Genome.Split.split gpart_at5j
                      p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                      (g_at4q, gpart_at5j) = Genome.Split.split gpart_at5i
                      p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                      (g_at4o, gpart_at5i) = Genome.Split.split gpart_at5h
                      p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                      (g_at4m, gpart_at5h) = Genome.Split.split gpart_at5g
                      p_at4l = Functions.belowten' g_at4k
                      (g_at4k, gpart_at5g) = Genome.Split.split gpart_at5f
                      p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                      (g_at4i, gpart_at5f) = Genome.Split.split gpart_at5e
                      p_at4h
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                      (g_at4g, gpart_at5e) = Genome.Split.split gpart_at5d
                      p_at4f
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4e
                      (g_at4e, gpart_at5d) = Genome.Split.split gpart_at5c
                      p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                      (g_at4c, gpart_at5c) = Genome.Split.split gpart_at5b
                      p_at4b = Functions.belowten' g_at4a
                      (g_at4a, gpart_at5b) = Genome.Split.split gpart_at5a
                      p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                      (g_at48, gpart_at5a) = Genome.Split.split gpart_at59
                      p_at47 = Functions.belowten' g_at46
                      (g_at46, gpart_at59) = Genome.Split.split gpart_at58
                      p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                      (g_at44, gpart_at58) = Genome.Split.split gpart_at57
                      p_at43 = code-0.1.0.0:Genome.FixedList.Functions.double g_at42
                      (g_at42, gpart_at57) = Genome.Split.split gpart_at56
                      p_at41 = Functions.belowten' g_at40
                      (g_at40, gpart_at56) = Genome.Split.split gpart_at55
                      p_at3Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Y
                      (g_at3Y, gpart_at55) = Genome.Split.split gpart_at54
                      p_at3X = Functions.belowten' g_at3W
                      (g_at3W, gpart_at54) = Genome.Split.split gpart_at53
                      p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                      (g_at3U, gpart_at53) = Genome.Split.split gpart_at52
                      p_at3T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3S
                      (g_at3S, gpart_at52) = Genome.Split.split gpart_at51
                      p_at3R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3Q
                      (g_at3Q, gpart_at51) = Genome.Split.split gpart_at50
                      p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                      (g_at3O, gpart_at50) = Genome.Split.split gpart_at4Z
                      p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                      (g_at3M, gpart_at4Z) = Genome.Split.split gpart_at4Y
                      p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                      (g_at3K, gpart_at4Y) = Genome.Split.split gpart_at4X
                      p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                      (g_at3I, gpart_at4X) = Genome.Split.split gpart_at4W
                      p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                      (g_at3G, gpart_at4W) = Genome.Split.split genome_at4U
                    in
                      [Reaction
                         (\ x_at5y
                            -> let
                                 c_RESTc_at5z = ((toVector x_at5y) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at5A = ((toVector x_at5y) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at3P
                                  / (1
                                     + ((((p_at3H / p_at3R) ** p_at3T)
                                         + ((c_RESTc_at5z / p_at3V) ** p_at3X))
                                        + ((c_MiRs_at5A / p_at3Z) ** p_at41)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5B
                            -> let
                                 c_MiRs_at5C = ((toVector x_at5B) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5D = ((toVector x_at5B) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at43
                                  / (1
                                     + (((c_MiRs_at5C / p_at45) ** p_at47)
                                        + ((c_PTB_at5D / p_at49) ** p_at4b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at5E
                            -> let c_RESTc_at5F = ((toVector x_at5E) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at4d
                                  * (p_at4n
                                     / ((1 + p_at4n) + ((c_RESTc_at5F / p_at4j) ** p_at4l)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at5G
                            -> let
                                 c_MiRs_at5J = ((toVector x_at5G) Data.Vector.Unboxed.! 2)
                                 c_PTB_at5H = ((toVector x_at5G) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4p
                                  * ((p_at4D + ((c_PTB_at5H / p_at4r) ** p_at4t))
                                     / (((1 + p_at4D) + ((c_PTB_at5H / p_at4r) ** p_at4t))
                                        + ((c_MiRs_at5J / p_at4z) ** p_at4B)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at5K
                            -> let c_RESTc_at5L = ((toVector x_at5K) Data.Vector.Unboxed.! 3)
                               in (p_at4F / (1 + ((c_RESTc_at5L / p_at4H) ** p_at4J))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at5M
                            -> let c_PTB_at5N = ((toVector x_at5M) Data.Vector.Unboxed.! 0)
                               in (p_at4L * c_PTB_at5N))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at5O
                            -> let c_NPTB_at5P = ((toVector x_at5O) Data.Vector.Unboxed.! 1)
                               in (p_at4N * c_NPTB_at5P))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at5Q
                            -> let c_MiRs_at5R = ((toVector x_at5Q) Data.Vector.Unboxed.! 2)
                               in (p_at4P * c_MiRs_at5R))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at5S
                            -> let c_RESTc_at5T = ((toVector x_at5S) Data.Vector.Unboxed.! 3)
                               in (p_at4R * c_RESTc_at5T))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at5U
                            -> let
                                 c_EndoNeuroTFs_at5V = ((toVector x_at5U) Data.Vector.Unboxed.! 4)
                               in (p_at4T * c_EndoNeuroTFs_at5V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121496",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121497",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121498",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121499",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121500",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121501",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121502",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121503",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121504",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121505",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121506",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121507",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121508",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121509",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121510",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121511",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121512",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121513",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121514",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121515",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121516",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121517",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121518",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121519",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121520",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121521",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121522",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121523",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121524",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121525",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121526",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121527",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121528",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121529",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121530",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121531",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121532",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121533",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121534",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121535",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121536",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121537",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121538",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121539",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121540",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121541",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121542",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121543",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121544",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121545",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121546",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121547",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121548",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121549",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121550",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121551",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121552",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121553",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121554",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121555",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121556",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121557",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121558",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121559",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121560",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121561",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121562",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121563",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121564",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121565",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121566",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121567",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at4U
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6x
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at6x) = Genome.Split.split gpart_at6w
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at6w) = Genome.Split.split gpart_at6v
                            p_at4P = code-0.1.0.0:Genome.FixedList.Functions.double g_at4O
                            (g_at4O, gpart_at6v) = Genome.Split.split gpart_at6u
                            p_at4N = code-0.1.0.0:Genome.FixedList.Functions.double g_at4M
                            (g_at4M, gpart_at6u) = Genome.Split.split gpart_at6t
                            p_at4L = code-0.1.0.0:Genome.FixedList.Functions.double g_at4K
                            (g_at4K, gpart_at6t) = Genome.Split.split gpart_at6s
                            p_at4J = Functions.belowten' g_at4I
                            (g_at4I, gpart_at6s) = Genome.Split.split gpart_at6r
                            p_at4H = code-0.1.0.0:Genome.FixedList.Functions.double g_at4G
                            (g_at4G, gpart_at6r) = Genome.Split.split gpart_at6q
                            p_at4F = code-0.1.0.0:Genome.FixedList.Functions.double g_at4E
                            (g_at4E, gpart_at6q) = Genome.Split.split gpart_at6p
                            p_at4D = code-0.1.0.0:Genome.FixedList.Functions.double g_at4C
                            (g_at4C, gpart_at6p) = Genome.Split.split gpart_at6o
                            p_at4B = Functions.belowten' g_at4A
                            (g_at4A, gpart_at6o) = Genome.Split.split gpart_at6n
                            p_at4z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4y
                            (g_at4y, gpart_at6n) = Genome.Split.split gpart_at6m
                            p_at4x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4w
                            (g_at4w, gpart_at6m) = Genome.Split.split gpart_at6l
                            p_at4v
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4u
                            (g_at4u, gpart_at6l) = Genome.Split.split gpart_at6k
                            p_at4t = Functions.belowten' g_at4s
                            (g_at4s, gpart_at6k) = Genome.Split.split gpart_at6j
                            p_at4r = code-0.1.0.0:Genome.FixedList.Functions.double g_at4q
                            (g_at4q, gpart_at6j) = Genome.Split.split gpart_at6i
                            p_at4p = code-0.1.0.0:Genome.FixedList.Functions.double g_at4o
                            (g_at4o, gpart_at6i) = Genome.Split.split gpart_at6h
                            p_at4n = code-0.1.0.0:Genome.FixedList.Functions.double g_at4m
                            (g_at4m, gpart_at6h) = Genome.Split.split gpart_at6g
                            p_at4l = Functions.belowten' g_at4k
                            (g_at4k, gpart_at6g) = Genome.Split.split gpart_at6f
                            p_at4j = code-0.1.0.0:Genome.FixedList.Functions.double g_at4i
                            (g_at4i, gpart_at6f) = Genome.Split.split gpart_at6e
                            p_at4h
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4g
                            (g_at4g, gpart_at6e) = Genome.Split.split gpart_at6d
                            p_at4f
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4e
                            (g_at4e, gpart_at6d) = Genome.Split.split gpart_at6c
                            p_at4d = code-0.1.0.0:Genome.FixedList.Functions.double g_at4c
                            (g_at4c, gpart_at6c) = Genome.Split.split gpart_at6b
                            p_at4b = Functions.belowten' g_at4a
                            (g_at4a, gpart_at6b) = Genome.Split.split gpart_at6a
                            p_at49 = code-0.1.0.0:Genome.FixedList.Functions.double g_at48
                            (g_at48, gpart_at6a) = Genome.Split.split gpart_at69
                            p_at47 = Functions.belowten' g_at46
                            (g_at46, gpart_at69) = Genome.Split.split gpart_at68
                            p_at45 = code-0.1.0.0:Genome.FixedList.Functions.double g_at44
                            (g_at44, gpart_at68) = Genome.Split.split gpart_at67
                            p_at43 = code-0.1.0.0:Genome.FixedList.Functions.double g_at42
                            (g_at42, gpart_at67) = Genome.Split.split gpart_at66
                            p_at41 = Functions.belowten' g_at40
                            (g_at40, gpart_at66) = Genome.Split.split gpart_at65
                            p_at3Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at3Y
                            (g_at3Y, gpart_at65) = Genome.Split.split gpart_at64
                            p_at3X = Functions.belowten' g_at3W
                            (g_at3W, gpart_at64) = Genome.Split.split gpart_at63
                            p_at3V = code-0.1.0.0:Genome.FixedList.Functions.double g_at3U
                            (g_at3U, gpart_at63) = Genome.Split.split gpart_at62
                            p_at3T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3S
                            (g_at3S, gpart_at62) = Genome.Split.split gpart_at61
                            p_at3R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at3Q
                            (g_at3Q, gpart_at61) = Genome.Split.split gpart_at60
                            p_at3P = code-0.1.0.0:Genome.FixedList.Functions.double g_at3O
                            (g_at3O, gpart_at60) = Genome.Split.split gpart_at5Z
                            p_at3N = code-0.1.0.0:Genome.FixedList.Functions.double g_at3M
                            (g_at3M, gpart_at5Z) = Genome.Split.split gpart_at5Y
                            p_at3L = code-0.1.0.0:Genome.FixedList.Functions.double g_at3K
                            (g_at3K, gpart_at5Y) = Genome.Split.split gpart_at5X
                            p_at3J = code-0.1.0.0:Genome.FixedList.Functions.double g_at3I
                            (g_at3I, gpart_at5X) = Genome.Split.split gpart_at5W
                            p_at3H = code-0.1.0.0:Genome.FixedList.Functions.double g_at3G
                            (g_at3G, gpart_at5W) = Genome.Split.split genome_at4U
                          in
                            \ desc_at4V
                              -> case desc_at4V of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3H)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3J)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3L)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3N)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3P)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3R)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3T)
                                   "Inhibition coef [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3V)
                                   "Inhibition hill [RESTc] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3X)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3Z)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at41)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at43)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at45)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at47)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at49)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4b)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4d)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4f)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4h)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4j)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4l)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4n)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4p)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4r)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4t)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4v)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4x)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4z)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4B)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4D)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4F)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4H)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4J)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4L)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4N)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4P)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   _ -> Nothing }}
