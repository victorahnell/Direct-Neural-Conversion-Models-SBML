src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24Q9
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24QP
                      p_a24Q8 = double g_a24Q7
                      (g_a24Q7, gpart_a24QP) = Genome.Split.split gpart_a24QO
                      p_a24Q6 = double g_a24Q5
                      (g_a24Q5, gpart_a24QO) = Genome.Split.split gpart_a24QN
                      p_a24Q4 = double g_a24Q3
                      (g_a24Q3, gpart_a24QN) = Genome.Split.split gpart_a24QM
                      p_a24Q2 = double g_a24Q1
                      (g_a24Q1, gpart_a24QM) = Genome.Split.split gpart_a24QL
                      p_a24Q0 = double g_a24PZ
                      (g_a24PZ, gpart_a24QL) = Genome.Split.split gpart_a24QK
                      p_a24PY = double g_a24PX
                      (g_a24PX, gpart_a24QK) = Genome.Split.split gpart_a24QJ
                      p_a24PW = Functions.belowten' g_a24PV
                      (g_a24PV, gpart_a24QJ) = Genome.Split.split gpart_a24QI
                      p_a24PU = double g_a24PT
                      (g_a24PT, gpart_a24QI) = Genome.Split.split gpart_a24QH
                      p_a24PS = Functions.belowten' g_a24PR
                      (g_a24PR, gpart_a24QH) = Genome.Split.split gpart_a24QG
                      p_a24PQ = double g_a24PP
                      (g_a24PP, gpart_a24QG) = Genome.Split.split gpart_a24QF
                      p_a24PO = double g_a24PN
                      (g_a24PN, gpart_a24QF) = Genome.Split.split gpart_a24QE
                      p_a24PM = double g_a24PL
                      (g_a24PL, gpart_a24QE) = Genome.Split.split gpart_a24QD
                      p_a24PK = Functions.belowten' g_a24PJ
                      (g_a24PJ, gpart_a24QD) = Genome.Split.split gpart_a24QC
                      p_a24PI = double g_a24PH
                      (g_a24PH, gpart_a24QC) = Genome.Split.split gpart_a24QB
                      p_a24PG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24PF
                      (g_a24PF, gpart_a24QB) = Genome.Split.split gpart_a24QA
                      p_a24PE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24PD
                      (g_a24PD, gpart_a24QA) = Genome.Split.split gpart_a24Qz
                      p_a24PC = Functions.belowten' g_a24PB
                      (g_a24PB, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                      p_a24PA = double g_a24Pz
                      (g_a24Pz, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                      p_a24Py = double g_a24Px
                      (g_a24Px, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                      p_a24Pw = double g_a24Pv
                      (g_a24Pv, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                      p_a24Pu = Functions.belowten' g_a24Pt
                      (g_a24Pt, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                      p_a24Ps = double g_a24Pr
                      (g_a24Pr, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                      p_a24Pq = Functions.belowten' g_a24Pp
                      (g_a24Pp, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                      p_a24Po = double g_a24Pn
                      (g_a24Pn, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                      p_a24Pm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Pl
                      (g_a24Pl, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                      p_a24Pk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Pj
                      (g_a24Pj, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                      p_a24Pi = double g_a24Ph
                      (g_a24Ph, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                      p_a24Pg = Functions.belowten' g_a24Pf
                      (g_a24Pf, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                      p_a24Pe = double g_a24Pd
                      (g_a24Pd, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                      p_a24Pc = Functions.belowten' g_a24Pb
                      (g_a24Pb, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                      p_a24Pa = double g_a24P9
                      (g_a24P9, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                      p_a24P8 = double g_a24P7
                      (g_a24P7, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                      p_a24P6 = Functions.belowten' g_a24P5
                      (g_a24P5, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                      p_a24P4 = double g_a24P3
                      (g_a24P3, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                      p_a24P2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24P1
                      (g_a24P1, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                      p_a24P0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OZ
                      (g_a24OZ, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                      p_a24OY = double g_a24OX
                      (g_a24OX, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                      p_a24OW = double g_a24OV
                      (g_a24OV, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                      p_a24OU = double g_a24OT
                      (g_a24OT, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                      p_a24OS = double g_a24OR
                      (g_a24OR, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                      p_a24OQ = double g_a24OP
                      (g_a24OP, gpart_a24Qb) = Genome.Split.split genome_a24Q9
                    in  \ x_a24QQ
                          -> let
                               c_PTB_a24QT
                                 = ((Data.Fixed.Vector.toVector x_a24QQ) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24QR
                                 = ((Data.Fixed.Vector.toVector x_a24QQ) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24QX
                                 = ((Data.Fixed.Vector.toVector x_a24QQ) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24QZ
                                 = ((Data.Fixed.Vector.toVector x_a24QQ) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Rb
                                 = ((Data.Fixed.Vector.toVector x_a24QQ) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24OY / (1 + ((c_MiRs_a24QR / p_a24P4) ** p_a24P6)))
                                    + (negate (p_a24Q0 * c_PTB_a24QT))),
                                   ((p_a24P8
                                     / (1
                                        + (((c_MiRs_a24QR / p_a24Pa) ** p_a24Pc)
                                           + ((c_PTB_a24QT / p_a24Pe) ** p_a24Pg))))
                                    + (negate (p_a24Q2 * c_NPTB_a24QX))),
                                   ((p_a24Pi
                                     * ((p_a24Pw + ((p_a24OU / p_a24Pk) ** p_a24Pm))
                                        / (((1 + p_a24Pw) + ((p_a24OU / p_a24Pk) ** p_a24Pm))
                                           + (((c_NPTB_a24QX / p_a24Po) ** p_a24Pq)
                                              + ((c_RESTc_a24QZ / p_a24Ps) ** p_a24Pu)))))
                                    + (negate (p_a24Q4 * c_MiRs_a24QR))),
                                   ((p_a24Py
                                     * ((p_a24PM + ((c_PTB_a24QT / p_a24PA) ** p_a24PC))
                                        / (((1 + p_a24PM) + ((c_PTB_a24QT / p_a24PA) ** p_a24PC))
                                           + (((p_a24OQ / p_a24PE) ** p_a24PG)
                                              + ((c_MiRs_a24QR / p_a24PI) ** p_a24PK)))))
                                    + (negate (p_a24Q6 * c_RESTc_a24QZ))),
                                   ((p_a24PO
                                     * ((p_a24PY + ((c_MiRs_a24QR / p_a24PQ) ** p_a24PS))
                                        / (((1 + p_a24PY) + ((c_MiRs_a24QR / p_a24PQ) ** p_a24PS))
                                           + ((c_RESTc_a24QZ / p_a24PU) ** p_a24PW))))
                                    + (negate (p_a24Q8 * c_EndoNeuroTFs_a24Rb)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504986",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504988",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505000",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505002",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505006",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505008",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505020",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505022",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505026",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505028",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505036",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505038",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Q9
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24RQ
                            p_a24Q8 = double g_a24Q7
                            (g_a24Q7, gpart_a24RQ) = Genome.Split.split gpart_a24RP
                            p_a24Q6 = double g_a24Q5
                            (g_a24Q5, gpart_a24RP) = Genome.Split.split gpart_a24RO
                            p_a24Q4 = double g_a24Q3
                            (g_a24Q3, gpart_a24RO) = Genome.Split.split gpart_a24RN
                            p_a24Q2 = double g_a24Q1
                            (g_a24Q1, gpart_a24RN) = Genome.Split.split gpart_a24RM
                            p_a24Q0 = double g_a24PZ
                            (g_a24PZ, gpart_a24RM) = Genome.Split.split gpart_a24RL
                            p_a24PY = double g_a24PX
                            (g_a24PX, gpart_a24RL) = Genome.Split.split gpart_a24RK
                            p_a24PW = Functions.belowten' g_a24PV
                            (g_a24PV, gpart_a24RK) = Genome.Split.split gpart_a24RJ
                            p_a24PU = double g_a24PT
                            (g_a24PT, gpart_a24RJ) = Genome.Split.split gpart_a24RI
                            p_a24PS = Functions.belowten' g_a24PR
                            (g_a24PR, gpart_a24RI) = Genome.Split.split gpart_a24RH
                            p_a24PQ = double g_a24PP
                            (g_a24PP, gpart_a24RH) = Genome.Split.split gpart_a24RG
                            p_a24PO = double g_a24PN
                            (g_a24PN, gpart_a24RG) = Genome.Split.split gpart_a24RF
                            p_a24PM = double g_a24PL
                            (g_a24PL, gpart_a24RF) = Genome.Split.split gpart_a24RE
                            p_a24PK = Functions.belowten' g_a24PJ
                            (g_a24PJ, gpart_a24RE) = Genome.Split.split gpart_a24RD
                            p_a24PI = double g_a24PH
                            (g_a24PH, gpart_a24RD) = Genome.Split.split gpart_a24RC
                            p_a24PG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24PF
                            (g_a24PF, gpart_a24RC) = Genome.Split.split gpart_a24RB
                            p_a24PE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24PD
                            (g_a24PD, gpart_a24RB) = Genome.Split.split gpart_a24RA
                            p_a24PC = Functions.belowten' g_a24PB
                            (g_a24PB, gpart_a24RA) = Genome.Split.split gpart_a24Rz
                            p_a24PA = double g_a24Pz
                            (g_a24Pz, gpart_a24Rz) = Genome.Split.split gpart_a24Ry
                            p_a24Py = double g_a24Px
                            (g_a24Px, gpart_a24Ry) = Genome.Split.split gpart_a24Rx
                            p_a24Pw = double g_a24Pv
                            (g_a24Pv, gpart_a24Rx) = Genome.Split.split gpart_a24Rw
                            p_a24Pu = Functions.belowten' g_a24Pt
                            (g_a24Pt, gpart_a24Rw) = Genome.Split.split gpart_a24Rv
                            p_a24Ps = double g_a24Pr
                            (g_a24Pr, gpart_a24Rv) = Genome.Split.split gpart_a24Ru
                            p_a24Pq = Functions.belowten' g_a24Pp
                            (g_a24Pp, gpart_a24Ru) = Genome.Split.split gpart_a24Rt
                            p_a24Po = double g_a24Pn
                            (g_a24Pn, gpart_a24Rt) = Genome.Split.split gpart_a24Rs
                            p_a24Pm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Pl
                            (g_a24Pl, gpart_a24Rs) = Genome.Split.split gpart_a24Rr
                            p_a24Pk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Pj
                            (g_a24Pj, gpart_a24Rr) = Genome.Split.split gpart_a24Rq
                            p_a24Pi = double g_a24Ph
                            (g_a24Ph, gpart_a24Rq) = Genome.Split.split gpart_a24Rp
                            p_a24Pg = Functions.belowten' g_a24Pf
                            (g_a24Pf, gpart_a24Rp) = Genome.Split.split gpart_a24Ro
                            p_a24Pe = double g_a24Pd
                            (g_a24Pd, gpart_a24Ro) = Genome.Split.split gpart_a24Rn
                            p_a24Pc = Functions.belowten' g_a24Pb
                            (g_a24Pb, gpart_a24Rn) = Genome.Split.split gpart_a24Rm
                            p_a24Pa = double g_a24P9
                            (g_a24P9, gpart_a24Rm) = Genome.Split.split gpart_a24Rl
                            p_a24P8 = double g_a24P7
                            (g_a24P7, gpart_a24Rl) = Genome.Split.split gpart_a24Rk
                            p_a24P6 = Functions.belowten' g_a24P5
                            (g_a24P5, gpart_a24Rk) = Genome.Split.split gpart_a24Rj
                            p_a24P4 = double g_a24P3
                            (g_a24P3, gpart_a24Rj) = Genome.Split.split gpart_a24Ri
                            p_a24P2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24P1
                            (g_a24P1, gpart_a24Ri) = Genome.Split.split gpart_a24Rh
                            p_a24P0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OZ
                            (g_a24OZ, gpart_a24Rh) = Genome.Split.split gpart_a24Rg
                            p_a24OY = double g_a24OX
                            (g_a24OX, gpart_a24Rg) = Genome.Split.split gpart_a24Rf
                            p_a24OW = double g_a24OV
                            (g_a24OV, gpart_a24Rf) = Genome.Split.split gpart_a24Re
                            p_a24OU = double g_a24OT
                            (g_a24OT, gpart_a24Re) = Genome.Split.split gpart_a24Rd
                            p_a24OS = double g_a24OR
                            (g_a24OR, gpart_a24Rd) = Genome.Split.split gpart_a24Rc
                            p_a24OQ = double g_a24OP
                            (g_a24OP, gpart_a24Rc) = Genome.Split.split genome_a24Q9
                          in
                            \ desc_a24Qa
                              -> case desc_a24Qa of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OQ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OS)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OU)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OW)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OY)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P0)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P2)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P4)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P6)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P8)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pa)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pc)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pe)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pg)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pi)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pk)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pm)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Po)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pq)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ps)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pu)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Pw)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Py)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PA)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PC)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PE)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PG)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PI)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PK)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PM)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PO)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PQ)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PS)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PU)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PW)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24PY)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q0)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q2)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q4)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q6)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Q8)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24Uk
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24V0
                      p_a24Uj = double g_a24Ui
                      (g_a24Ui, gpart_a24V0) = Genome.Split.split gpart_a24UZ
                      p_a24Uh = double g_a24Ug
                      (g_a24Ug, gpart_a24UZ) = Genome.Split.split gpart_a24UY
                      p_a24Uf = double g_a24Ue
                      (g_a24Ue, gpart_a24UY) = Genome.Split.split gpart_a24UX
                      p_a24Ud = double g_a24Uc
                      (g_a24Uc, gpart_a24UX) = Genome.Split.split gpart_a24UW
                      p_a24Ub = double g_a24Ua
                      (g_a24Ua, gpart_a24UW) = Genome.Split.split gpart_a24UV
                      p_a24U9 = double g_a24U8
                      (g_a24U8, gpart_a24UV) = Genome.Split.split gpart_a24UU
                      p_a24U7 = Functions.belowten' g_a24U6
                      (g_a24U6, gpart_a24UU) = Genome.Split.split gpart_a24UT
                      p_a24U5 = double g_a24U4
                      (g_a24U4, gpart_a24UT) = Genome.Split.split gpart_a24US
                      p_a24U3 = Functions.belowten' g_a24U2
                      (g_a24U2, gpart_a24US) = Genome.Split.split gpart_a24UR
                      p_a24U1 = double g_a24U0
                      (g_a24U0, gpart_a24UR) = Genome.Split.split gpart_a24UQ
                      p_a24TZ = double g_a24TY
                      (g_a24TY, gpart_a24UQ) = Genome.Split.split gpart_a24UP
                      p_a24TX = double g_a24TW
                      (g_a24TW, gpart_a24UP) = Genome.Split.split gpart_a24UO
                      p_a24TV = Functions.belowten' g_a24TU
                      (g_a24TU, gpart_a24UO) = Genome.Split.split gpart_a24UN
                      p_a24TT = double g_a24TS
                      (g_a24TS, gpart_a24UN) = Genome.Split.split gpart_a24UM
                      p_a24TR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24TQ
                      (g_a24TQ, gpart_a24UM) = Genome.Split.split gpart_a24UL
                      p_a24TP
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24TO
                      (g_a24TO, gpart_a24UL) = Genome.Split.split gpart_a24UK
                      p_a24TN = Functions.belowten' g_a24TM
                      (g_a24TM, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                      p_a24TL = double g_a24TK
                      (g_a24TK, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                      p_a24TJ = double g_a24TI
                      (g_a24TI, gpart_a24UI) = Genome.Split.split gpart_a24UH
                      p_a24TH = double g_a24TG
                      (g_a24TG, gpart_a24UH) = Genome.Split.split gpart_a24UG
                      p_a24TF = Functions.belowten' g_a24TE
                      (g_a24TE, gpart_a24UG) = Genome.Split.split gpart_a24UF
                      p_a24TD = double g_a24TC
                      (g_a24TC, gpart_a24UF) = Genome.Split.split gpart_a24UE
                      p_a24TB = Functions.belowten' g_a24TA
                      (g_a24TA, gpart_a24UE) = Genome.Split.split gpart_a24UD
                      p_a24Tz = double g_a24Ty
                      (g_a24Ty, gpart_a24UD) = Genome.Split.split gpart_a24UC
                      p_a24Tx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tw
                      (g_a24Tw, gpart_a24UC) = Genome.Split.split gpart_a24UB
                      p_a24Tv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tu
                      (g_a24Tu, gpart_a24UB) = Genome.Split.split gpart_a24UA
                      p_a24Tt = double g_a24Ts
                      (g_a24Ts, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                      p_a24Tr = Functions.belowten' g_a24Tq
                      (g_a24Tq, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                      p_a24Tp = double g_a24To
                      (g_a24To, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                      p_a24Tn = Functions.belowten' g_a24Tm
                      (g_a24Tm, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                      p_a24Tl = double g_a24Tk
                      (g_a24Tk, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                      p_a24Tj = double g_a24Ti
                      (g_a24Ti, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                      p_a24Th = Functions.belowten' g_a24Tg
                      (g_a24Tg, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                      p_a24Tf = double g_a24Te
                      (g_a24Te, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                      p_a24Td
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tc
                      (g_a24Tc, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                      p_a24Tb
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ta
                      (g_a24Ta, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                      p_a24T9 = double g_a24T8
                      (g_a24T8, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                      p_a24T7 = double g_a24T6
                      (g_a24T6, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                      p_a24T5 = double g_a24T4
                      (g_a24T4, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                      p_a24T3 = double g_a24T2
                      (g_a24T2, gpart_a24Un) = Genome.Split.split gpart_a24Um
                      p_a24T1 = double g_a24T0
                      (g_a24T0, gpart_a24Um) = Genome.Split.split genome_a24Uk
                    in  \ x_a24V1
                          -> let
                               c_PTB_a24V4
                                 = ((Data.Fixed.Vector.toVector x_a24V1) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24V2
                                 = ((Data.Fixed.Vector.toVector x_a24V1) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24V8
                                 = ((Data.Fixed.Vector.toVector x_a24V1) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Va
                                 = ((Data.Fixed.Vector.toVector x_a24V1) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Vm
                                 = ((Data.Fixed.Vector.toVector x_a24V1) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24T9 / (1 + ((c_MiRs_a24V2 / p_a24Tf) ** p_a24Th)))
                                    + (negate (p_a24Ub * c_PTB_a24V4))),
                                   ((p_a24Tj
                                     / (1
                                        + (((c_MiRs_a24V2 / p_a24Tl) ** p_a24Tn)
                                           + ((c_PTB_a24V4 / p_a24Tp) ** p_a24Tr))))
                                    + (negate (p_a24Ud * c_NPTB_a24V8))),
                                   ((p_a24Tt
                                     * (p_a24TH
                                        / ((1 + p_a24TH)
                                           + (((c_NPTB_a24V8 / p_a24Tz) ** p_a24TB)
                                              + ((c_RESTc_a24Va / p_a24TD) ** p_a24TF)))))
                                    + (negate (p_a24Uf * c_MiRs_a24V2))),
                                   ((p_a24TJ
                                     * ((p_a24TX + ((c_PTB_a24V4 / p_a24TL) ** p_a24TN))
                                        / (((1 + p_a24TX) + ((c_PTB_a24V4 / p_a24TL) ** p_a24TN))
                                           + (((p_a24T1 / p_a24TP) ** p_a24TR)
                                              + ((c_MiRs_a24V2 / p_a24TT) ** p_a24TV)))))
                                    + (negate (p_a24Uh * c_RESTc_a24Va))),
                                   ((p_a24TZ
                                     * ((p_a24U9 + ((c_MiRs_a24V2 / p_a24U1) ** p_a24U3))
                                        / (((1 + p_a24U9) + ((c_MiRs_a24V2 / p_a24U1) ** p_a24U3))
                                           + ((c_RESTc_a24Va / p_a24U5) ** p_a24U7))))
                                    + (negate (p_a24Uj * c_EndoNeuroTFs_a24Vm)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505234",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505235",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505236",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505237",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505238",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505239",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505240",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505241",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505242",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505243",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505244",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505245",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505246",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505247",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505248",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505249",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505250",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505251",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505252",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505253",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505254",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505255",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505256",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505257",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505258",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505259",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505260",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505261",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505262",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505263",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505264",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505265",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505266",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505267",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505268",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505269",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505270",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505271",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505272",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505273",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505274",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505275",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505276",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505277",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505278",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505279",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505280",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505281",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505282",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505283",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505284",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505285",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505287",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505297",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505299",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Uk
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24W1
                            p_a24Uj = double g_a24Ui
                            (g_a24Ui, gpart_a24W1) = Genome.Split.split gpart_a24W0
                            p_a24Uh = double g_a24Ug
                            (g_a24Ug, gpart_a24W0) = Genome.Split.split gpart_a24VZ
                            p_a24Uf = double g_a24Ue
                            (g_a24Ue, gpart_a24VZ) = Genome.Split.split gpart_a24VY
                            p_a24Ud = double g_a24Uc
                            (g_a24Uc, gpart_a24VY) = Genome.Split.split gpart_a24VX
                            p_a24Ub = double g_a24Ua
                            (g_a24Ua, gpart_a24VX) = Genome.Split.split gpart_a24VW
                            p_a24U9 = double g_a24U8
                            (g_a24U8, gpart_a24VW) = Genome.Split.split gpart_a24VV
                            p_a24U7 = Functions.belowten' g_a24U6
                            (g_a24U6, gpart_a24VV) = Genome.Split.split gpart_a24VU
                            p_a24U5 = double g_a24U4
                            (g_a24U4, gpart_a24VU) = Genome.Split.split gpart_a24VT
                            p_a24U3 = Functions.belowten' g_a24U2
                            (g_a24U2, gpart_a24VT) = Genome.Split.split gpart_a24VS
                            p_a24U1 = double g_a24U0
                            (g_a24U0, gpart_a24VS) = Genome.Split.split gpart_a24VR
                            p_a24TZ = double g_a24TY
                            (g_a24TY, gpart_a24VR) = Genome.Split.split gpart_a24VQ
                            p_a24TX = double g_a24TW
                            (g_a24TW, gpart_a24VQ) = Genome.Split.split gpart_a24VP
                            p_a24TV = Functions.belowten' g_a24TU
                            (g_a24TU, gpart_a24VP) = Genome.Split.split gpart_a24VO
                            p_a24TT = double g_a24TS
                            (g_a24TS, gpart_a24VO) = Genome.Split.split gpart_a24VN
                            p_a24TR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24TQ
                            (g_a24TQ, gpart_a24VN) = Genome.Split.split gpart_a24VM
                            p_a24TP
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24TO
                            (g_a24TO, gpart_a24VM) = Genome.Split.split gpart_a24VL
                            p_a24TN = Functions.belowten' g_a24TM
                            (g_a24TM, gpart_a24VL) = Genome.Split.split gpart_a24VK
                            p_a24TL = double g_a24TK
                            (g_a24TK, gpart_a24VK) = Genome.Split.split gpart_a24VJ
                            p_a24TJ = double g_a24TI
                            (g_a24TI, gpart_a24VJ) = Genome.Split.split gpart_a24VI
                            p_a24TH = double g_a24TG
                            (g_a24TG, gpart_a24VI) = Genome.Split.split gpart_a24VH
                            p_a24TF = Functions.belowten' g_a24TE
                            (g_a24TE, gpart_a24VH) = Genome.Split.split gpart_a24VG
                            p_a24TD = double g_a24TC
                            (g_a24TC, gpart_a24VG) = Genome.Split.split gpart_a24VF
                            p_a24TB = Functions.belowten' g_a24TA
                            (g_a24TA, gpart_a24VF) = Genome.Split.split gpart_a24VE
                            p_a24Tz = double g_a24Ty
                            (g_a24Ty, gpart_a24VE) = Genome.Split.split gpart_a24VD
                            p_a24Tx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tw
                            (g_a24Tw, gpart_a24VD) = Genome.Split.split gpart_a24VC
                            p_a24Tv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tu
                            (g_a24Tu, gpart_a24VC) = Genome.Split.split gpart_a24VB
                            p_a24Tt = double g_a24Ts
                            (g_a24Ts, gpart_a24VB) = Genome.Split.split gpart_a24VA
                            p_a24Tr = Functions.belowten' g_a24Tq
                            (g_a24Tq, gpart_a24VA) = Genome.Split.split gpart_a24Vz
                            p_a24Tp = double g_a24To
                            (g_a24To, gpart_a24Vz) = Genome.Split.split gpart_a24Vy
                            p_a24Tn = Functions.belowten' g_a24Tm
                            (g_a24Tm, gpart_a24Vy) = Genome.Split.split gpart_a24Vx
                            p_a24Tl = double g_a24Tk
                            (g_a24Tk, gpart_a24Vx) = Genome.Split.split gpart_a24Vw
                            p_a24Tj = double g_a24Ti
                            (g_a24Ti, gpart_a24Vw) = Genome.Split.split gpart_a24Vv
                            p_a24Th = Functions.belowten' g_a24Tg
                            (g_a24Tg, gpart_a24Vv) = Genome.Split.split gpart_a24Vu
                            p_a24Tf = double g_a24Te
                            (g_a24Te, gpart_a24Vu) = Genome.Split.split gpart_a24Vt
                            p_a24Td
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Tc
                            (g_a24Tc, gpart_a24Vt) = Genome.Split.split gpart_a24Vs
                            p_a24Tb
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Ta
                            (g_a24Ta, gpart_a24Vs) = Genome.Split.split gpart_a24Vr
                            p_a24T9 = double g_a24T8
                            (g_a24T8, gpart_a24Vr) = Genome.Split.split gpart_a24Vq
                            p_a24T7 = double g_a24T6
                            (g_a24T6, gpart_a24Vq) = Genome.Split.split gpart_a24Vp
                            p_a24T5 = double g_a24T4
                            (g_a24T4, gpart_a24Vp) = Genome.Split.split gpart_a24Vo
                            p_a24T3 = double g_a24T2
                            (g_a24T2, gpart_a24Vo) = Genome.Split.split gpart_a24Vn
                            p_a24T1 = double g_a24T0
                            (g_a24T0, gpart_a24Vn) = Genome.Split.split genome_a24Uk
                          in
                            \ desc_a24Ul
                              -> case desc_a24Ul of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T1)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T3)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T5)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T7)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T9)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tb)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Td)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tf)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Th)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tj)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tl)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tn)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tp)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tr)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tt)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tv)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tx)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tz)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TB)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TD)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TF)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TH)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TJ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TL)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TN)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TP)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TR)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TT)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TV)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TX)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24TZ)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24U1)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24U3)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24U5)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24U7)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24U9)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ub)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ud)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uf)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uh)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Uj)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24Yv
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Zb
                      p_a24Yu = double g_a24Yt
                      (g_a24Yt, gpart_a24Zb) = Genome.Split.split gpart_a24Za
                      p_a24Ys = double g_a24Yr
                      (g_a24Yr, gpart_a24Za) = Genome.Split.split gpart_a24Z9
                      p_a24Yq = double g_a24Yp
                      (g_a24Yp, gpart_a24Z9) = Genome.Split.split gpart_a24Z8
                      p_a24Yo = double g_a24Yn
                      (g_a24Yn, gpart_a24Z8) = Genome.Split.split gpart_a24Z7
                      p_a24Ym = double g_a24Yl
                      (g_a24Yl, gpart_a24Z7) = Genome.Split.split gpart_a24Z6
                      p_a24Yk = double g_a24Yj
                      (g_a24Yj, gpart_a24Z6) = Genome.Split.split gpart_a24Z5
                      p_a24Yi = Functions.belowten' g_a24Yh
                      (g_a24Yh, gpart_a24Z5) = Genome.Split.split gpart_a24Z4
                      p_a24Yg = double g_a24Yf
                      (g_a24Yf, gpart_a24Z4) = Genome.Split.split gpart_a24Z3
                      p_a24Ye = Functions.belowten' g_a24Yd
                      (g_a24Yd, gpart_a24Z3) = Genome.Split.split gpart_a24Z2
                      p_a24Yc = double g_a24Yb
                      (g_a24Yb, gpart_a24Z2) = Genome.Split.split gpart_a24Z1
                      p_a24Ya = double g_a24Y9
                      (g_a24Y9, gpart_a24Z1) = Genome.Split.split gpart_a24Z0
                      p_a24Y8 = double g_a24Y7
                      (g_a24Y7, gpart_a24Z0) = Genome.Split.split gpart_a24YZ
                      p_a24Y6 = Functions.belowten' g_a24Y5
                      (g_a24Y5, gpart_a24YZ) = Genome.Split.split gpart_a24YY
                      p_a24Y4 = double g_a24Y3
                      (g_a24Y3, gpart_a24YY) = Genome.Split.split gpart_a24YX
                      p_a24Y2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Y1
                      (g_a24Y1, gpart_a24YX) = Genome.Split.split gpart_a24YW
                      p_a24Y0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XZ
                      (g_a24XZ, gpart_a24YW) = Genome.Split.split gpart_a24YV
                      p_a24XY = Functions.belowten' g_a24XX
                      (g_a24XX, gpart_a24YV) = Genome.Split.split gpart_a24YU
                      p_a24XW = double g_a24XV
                      (g_a24XV, gpart_a24YU) = Genome.Split.split gpart_a24YT
                      p_a24XU = double g_a24XT
                      (g_a24XT, gpart_a24YT) = Genome.Split.split gpart_a24YS
                      p_a24XS = double g_a24XR
                      (g_a24XR, gpart_a24YS) = Genome.Split.split gpart_a24YR
                      p_a24XQ = Functions.belowten' g_a24XP
                      (g_a24XP, gpart_a24YR) = Genome.Split.split gpart_a24YQ
                      p_a24XO = double g_a24XN
                      (g_a24XN, gpart_a24YQ) = Genome.Split.split gpart_a24YP
                      p_a24XM = Functions.belowten' g_a24XL
                      (g_a24XL, gpart_a24YP) = Genome.Split.split gpart_a24YO
                      p_a24XK = double g_a24XJ
                      (g_a24XJ, gpart_a24YO) = Genome.Split.split gpart_a24YN
                      p_a24XI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XH
                      (g_a24XH, gpart_a24YN) = Genome.Split.split gpart_a24YM
                      p_a24XG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XF
                      (g_a24XF, gpart_a24YM) = Genome.Split.split gpart_a24YL
                      p_a24XE = double g_a24XD
                      (g_a24XD, gpart_a24YL) = Genome.Split.split gpart_a24YK
                      p_a24XC = Functions.belowten' g_a24XB
                      (g_a24XB, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                      p_a24XA = double g_a24Xz
                      (g_a24Xz, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                      p_a24Xy = Functions.belowten' g_a24Xx
                      (g_a24Xx, gpart_a24YI) = Genome.Split.split gpart_a24YH
                      p_a24Xw = double g_a24Xv
                      (g_a24Xv, gpart_a24YH) = Genome.Split.split gpart_a24YG
                      p_a24Xu = double g_a24Xt
                      (g_a24Xt, gpart_a24YG) = Genome.Split.split gpart_a24YF
                      p_a24Xs = Functions.belowten' g_a24Xr
                      (g_a24Xr, gpart_a24YF) = Genome.Split.split gpart_a24YE
                      p_a24Xq = double g_a24Xp
                      (g_a24Xp, gpart_a24YE) = Genome.Split.split gpart_a24YD
                      p_a24Xo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xn
                      (g_a24Xn, gpart_a24YD) = Genome.Split.split gpart_a24YC
                      p_a24Xm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xl
                      (g_a24Xl, gpart_a24YC) = Genome.Split.split gpart_a24YB
                      p_a24Xk = double g_a24Xj
                      (g_a24Xj, gpart_a24YB) = Genome.Split.split gpart_a24YA
                      p_a24Xi = double g_a24Xh
                      (g_a24Xh, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                      p_a24Xg = double g_a24Xf
                      (g_a24Xf, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                      p_a24Xe = double g_a24Xd
                      (g_a24Xd, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                      p_a24Xc = double g_a24Xb
                      (g_a24Xb, gpart_a24Yx) = Genome.Split.split genome_a24Yv
                    in  \ x_a24Zc
                          -> let
                               c_PTB_a24Zf
                                 = ((Data.Fixed.Vector.toVector x_a24Zc) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Zd
                                 = ((Data.Fixed.Vector.toVector x_a24Zc) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Zj
                                 = ((Data.Fixed.Vector.toVector x_a24Zc) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Zl
                                 = ((Data.Fixed.Vector.toVector x_a24Zc) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Zx
                                 = ((Data.Fixed.Vector.toVector x_a24Zc) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Xk / (1 + ((c_MiRs_a24Zd / p_a24Xq) ** p_a24Xs)))
                                    + (negate (p_a24Ym * c_PTB_a24Zf))),
                                   ((p_a24Xu
                                     / (1
                                        + (((c_MiRs_a24Zd / p_a24Xw) ** p_a24Xy)
                                           + ((c_PTB_a24Zf / p_a24XA) ** p_a24XC))))
                                    + (negate (p_a24Yo * c_NPTB_a24Zj))),
                                   ((p_a24XE
                                     * (p_a24XS
                                        / ((1 + p_a24XS)
                                           + (((c_NPTB_a24Zj / p_a24XK) ** p_a24XM)
                                              + ((c_RESTc_a24Zl / p_a24XO) ** p_a24XQ)))))
                                    + (negate (p_a24Yq * c_MiRs_a24Zd))),
                                   ((p_a24XU
                                     * ((p_a24Y8 + ((c_PTB_a24Zf / p_a24XW) ** p_a24XY))
                                        / (((1 + p_a24Y8) + ((c_PTB_a24Zf / p_a24XW) ** p_a24XY))
                                           + ((c_MiRs_a24Zd / p_a24Y4) ** p_a24Y6))))
                                    + (negate (p_a24Ys * c_RESTc_a24Zl))),
                                   ((p_a24Ya
                                     * ((p_a24Yk + ((c_MiRs_a24Zd / p_a24Yc) ** p_a24Ye))
                                        / (((1 + p_a24Yk) + ((c_MiRs_a24Zd / p_a24Yc) ** p_a24Ye))
                                           + ((c_RESTc_a24Zl / p_a24Yg) ** p_a24Yi))))
                                    + (negate (p_a24Yu * c_EndoNeuroTFs_a24Zx)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505504",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505506",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505520",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505522",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505524",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505526",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505536",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505538",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505544",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505546",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Yv
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a250c
                            p_a24Yu = double g_a24Yt
                            (g_a24Yt, gpart_a250c) = Genome.Split.split gpart_a250b
                            p_a24Ys = double g_a24Yr
                            (g_a24Yr, gpart_a250b) = Genome.Split.split gpart_a250a
                            p_a24Yq = double g_a24Yp
                            (g_a24Yp, gpart_a250a) = Genome.Split.split gpart_a2509
                            p_a24Yo = double g_a24Yn
                            (g_a24Yn, gpart_a2509) = Genome.Split.split gpart_a2508
                            p_a24Ym = double g_a24Yl
                            (g_a24Yl, gpart_a2508) = Genome.Split.split gpart_a2507
                            p_a24Yk = double g_a24Yj
                            (g_a24Yj, gpart_a2507) = Genome.Split.split gpart_a2506
                            p_a24Yi = Functions.belowten' g_a24Yh
                            (g_a24Yh, gpart_a2506) = Genome.Split.split gpart_a2505
                            p_a24Yg = double g_a24Yf
                            (g_a24Yf, gpart_a2505) = Genome.Split.split gpart_a2504
                            p_a24Ye = Functions.belowten' g_a24Yd
                            (g_a24Yd, gpart_a2504) = Genome.Split.split gpart_a2503
                            p_a24Yc = double g_a24Yb
                            (g_a24Yb, gpart_a2503) = Genome.Split.split gpart_a2502
                            p_a24Ya = double g_a24Y9
                            (g_a24Y9, gpart_a2502) = Genome.Split.split gpart_a2501
                            p_a24Y8 = double g_a24Y7
                            (g_a24Y7, gpart_a2501) = Genome.Split.split gpart_a2500
                            p_a24Y6 = Functions.belowten' g_a24Y5
                            (g_a24Y5, gpart_a2500) = Genome.Split.split gpart_a24ZZ
                            p_a24Y4 = double g_a24Y3
                            (g_a24Y3, gpart_a24ZZ) = Genome.Split.split gpart_a24ZY
                            p_a24Y2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Y1
                            (g_a24Y1, gpart_a24ZY) = Genome.Split.split gpart_a24ZX
                            p_a24Y0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XZ
                            (g_a24XZ, gpart_a24ZX) = Genome.Split.split gpart_a24ZW
                            p_a24XY = Functions.belowten' g_a24XX
                            (g_a24XX, gpart_a24ZW) = Genome.Split.split gpart_a24ZV
                            p_a24XW = double g_a24XV
                            (g_a24XV, gpart_a24ZV) = Genome.Split.split gpart_a24ZU
                            p_a24XU = double g_a24XT
                            (g_a24XT, gpart_a24ZU) = Genome.Split.split gpart_a24ZT
                            p_a24XS = double g_a24XR
                            (g_a24XR, gpart_a24ZT) = Genome.Split.split gpart_a24ZS
                            p_a24XQ = Functions.belowten' g_a24XP
                            (g_a24XP, gpart_a24ZS) = Genome.Split.split gpart_a24ZR
                            p_a24XO = double g_a24XN
                            (g_a24XN, gpart_a24ZR) = Genome.Split.split gpart_a24ZQ
                            p_a24XM = Functions.belowten' g_a24XL
                            (g_a24XL, gpart_a24ZQ) = Genome.Split.split gpart_a24ZP
                            p_a24XK = double g_a24XJ
                            (g_a24XJ, gpart_a24ZP) = Genome.Split.split gpart_a24ZO
                            p_a24XI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XH
                            (g_a24XH, gpart_a24ZO) = Genome.Split.split gpart_a24ZN
                            p_a24XG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24XF
                            (g_a24XF, gpart_a24ZN) = Genome.Split.split gpart_a24ZM
                            p_a24XE = double g_a24XD
                            (g_a24XD, gpart_a24ZM) = Genome.Split.split gpart_a24ZL
                            p_a24XC = Functions.belowten' g_a24XB
                            (g_a24XB, gpart_a24ZL) = Genome.Split.split gpart_a24ZK
                            p_a24XA = double g_a24Xz
                            (g_a24Xz, gpart_a24ZK) = Genome.Split.split gpart_a24ZJ
                            p_a24Xy = Functions.belowten' g_a24Xx
                            (g_a24Xx, gpart_a24ZJ) = Genome.Split.split gpart_a24ZI
                            p_a24Xw = double g_a24Xv
                            (g_a24Xv, gpart_a24ZI) = Genome.Split.split gpart_a24ZH
                            p_a24Xu = double g_a24Xt
                            (g_a24Xt, gpart_a24ZH) = Genome.Split.split gpart_a24ZG
                            p_a24Xs = Functions.belowten' g_a24Xr
                            (g_a24Xr, gpart_a24ZG) = Genome.Split.split gpart_a24ZF
                            p_a24Xq = double g_a24Xp
                            (g_a24Xp, gpart_a24ZF) = Genome.Split.split gpart_a24ZE
                            p_a24Xo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xn
                            (g_a24Xn, gpart_a24ZE) = Genome.Split.split gpart_a24ZD
                            p_a24Xm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Xl
                            (g_a24Xl, gpart_a24ZD) = Genome.Split.split gpart_a24ZC
                            p_a24Xk = double g_a24Xj
                            (g_a24Xj, gpart_a24ZC) = Genome.Split.split gpart_a24ZB
                            p_a24Xi = double g_a24Xh
                            (g_a24Xh, gpart_a24ZB) = Genome.Split.split gpart_a24ZA
                            p_a24Xg = double g_a24Xf
                            (g_a24Xf, gpart_a24ZA) = Genome.Split.split gpart_a24Zz
                            p_a24Xe = double g_a24Xd
                            (g_a24Xd, gpart_a24Zz) = Genome.Split.split gpart_a24Zy
                            p_a24Xc = double g_a24Xb
                            (g_a24Xb, gpart_a24Zy) = Genome.Split.split genome_a24Yv
                          in
                            \ desc_a24Yw
                              -> case desc_a24Yw of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xc)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xe)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xg)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xi)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xk)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xm)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xo)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xq)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xs)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xu)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xw)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xy)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XA)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XC)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XE)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XG)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XI)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XK)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XM)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XO)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XQ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XS)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XU)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XW)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24XY)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y0)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y2)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y4)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y6)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Y8)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ya)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yc)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ye)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yg)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yi)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yk)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ym)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yo)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yq)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ys)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Yu)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a252G
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a253m
                      p_a252F = double g_a252E
                      (g_a252E, gpart_a253m) = Genome.Split.split gpart_a253l
                      p_a252D = double g_a252C
                      (g_a252C, gpart_a253l) = Genome.Split.split gpart_a253k
                      p_a252B = double g_a252A
                      (g_a252A, gpart_a253k) = Genome.Split.split gpart_a253j
                      p_a252z = double g_a252y
                      (g_a252y, gpart_a253j) = Genome.Split.split gpart_a253i
                      p_a252x = double g_a252w
                      (g_a252w, gpart_a253i) = Genome.Split.split gpart_a253h
                      p_a252v = double g_a252u
                      (g_a252u, gpart_a253h) = Genome.Split.split gpart_a253g
                      p_a252t = Functions.belowten' g_a252s
                      (g_a252s, gpart_a253g) = Genome.Split.split gpart_a253f
                      p_a252r = double g_a252q
                      (g_a252q, gpart_a253f) = Genome.Split.split gpart_a253e
                      p_a252p = Functions.belowten' g_a252o
                      (g_a252o, gpart_a253e) = Genome.Split.split gpart_a253d
                      p_a252n = double g_a252m
                      (g_a252m, gpart_a253d) = Genome.Split.split gpart_a253c
                      p_a252l = double g_a252k
                      (g_a252k, gpart_a253c) = Genome.Split.split gpart_a253b
                      p_a252j = double g_a252i
                      (g_a252i, gpart_a253b) = Genome.Split.split gpart_a253a
                      p_a252h = Functions.belowten' g_a252g
                      (g_a252g, gpart_a253a) = Genome.Split.split gpart_a2539
                      p_a252f = double g_a252e
                      (g_a252e, gpart_a2539) = Genome.Split.split gpart_a2538
                      p_a252d
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a252c
                      (g_a252c, gpart_a2538) = Genome.Split.split gpart_a2537
                      p_a252b
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a252a
                      (g_a252a, gpart_a2537) = Genome.Split.split gpart_a2536
                      p_a2529 = Functions.belowten' g_a2528
                      (g_a2528, gpart_a2536) = Genome.Split.split gpart_a2535
                      p_a2527 = double g_a2526
                      (g_a2526, gpart_a2535) = Genome.Split.split gpart_a2534
                      p_a2525 = double g_a2524
                      (g_a2524, gpart_a2534) = Genome.Split.split gpart_a2533
                      p_a2523 = double g_a2522
                      (g_a2522, gpart_a2533) = Genome.Split.split gpart_a2532
                      p_a2521 = Functions.belowten' g_a2520
                      (g_a2520, gpart_a2532) = Genome.Split.split gpart_a2531
                      p_a251Z = double g_a251Y
                      (g_a251Y, gpart_a2531) = Genome.Split.split gpart_a2530
                      p_a251X = Functions.belowten' g_a251W
                      (g_a251W, gpart_a2530) = Genome.Split.split gpart_a252Z
                      p_a251V = double g_a251U
                      (g_a251U, gpart_a252Z) = Genome.Split.split gpart_a252Y
                      p_a251T
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251S
                      (g_a251S, gpart_a252Y) = Genome.Split.split gpart_a252X
                      p_a251R
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251Q
                      (g_a251Q, gpart_a252X) = Genome.Split.split gpart_a252W
                      p_a251P = double g_a251O
                      (g_a251O, gpart_a252W) = Genome.Split.split gpart_a252V
                      p_a251N = Functions.belowten' g_a251M
                      (g_a251M, gpart_a252V) = Genome.Split.split gpart_a252U
                      p_a251L = double g_a251K
                      (g_a251K, gpart_a252U) = Genome.Split.split gpart_a252T
                      p_a251J = Functions.belowten' g_a251I
                      (g_a251I, gpart_a252T) = Genome.Split.split gpart_a252S
                      p_a251H = double g_a251G
                      (g_a251G, gpart_a252S) = Genome.Split.split gpart_a252R
                      p_a251F = double g_a251E
                      (g_a251E, gpart_a252R) = Genome.Split.split gpart_a252Q
                      p_a251D = Functions.belowten' g_a251C
                      (g_a251C, gpart_a252Q) = Genome.Split.split gpart_a252P
                      p_a251B = double g_a251A
                      (g_a251A, gpart_a252P) = Genome.Split.split gpart_a252O
                      p_a251z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251y
                      (g_a251y, gpart_a252O) = Genome.Split.split gpart_a252N
                      p_a251x
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251w
                      (g_a251w, gpart_a252N) = Genome.Split.split gpart_a252M
                      p_a251v = double g_a251u
                      (g_a251u, gpart_a252M) = Genome.Split.split gpart_a252L
                      p_a251t = double g_a251s
                      (g_a251s, gpart_a252L) = Genome.Split.split gpart_a252K
                      p_a251r = double g_a251q
                      (g_a251q, gpart_a252K) = Genome.Split.split gpart_a252J
                      p_a251p = double g_a251o
                      (g_a251o, gpart_a252J) = Genome.Split.split gpart_a252I
                      p_a251n = double g_a251m
                      (g_a251m, gpart_a252I) = Genome.Split.split genome_a252G
                    in  \ x_a253n
                          -> let
                               c_PTB_a253q
                                 = ((Data.Fixed.Vector.toVector x_a253n) Data.Vector.Unboxed.! 0)
                               c_MiRs_a253o
                                 = ((Data.Fixed.Vector.toVector x_a253n) Data.Vector.Unboxed.! 2)
                               c_NPTB_a253u
                                 = ((Data.Fixed.Vector.toVector x_a253n) Data.Vector.Unboxed.! 1)
                               c_RESTc_a253w
                                 = ((Data.Fixed.Vector.toVector x_a253n) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a253I
                                 = ((Data.Fixed.Vector.toVector x_a253n) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a251v
                                     / (1
                                        + (((p_a251n / p_a251x) ** p_a251z)
                                           + ((c_MiRs_a253o / p_a251B) ** p_a251D))))
                                    + (negate (p_a252x * c_PTB_a253q))),
                                   ((p_a251F
                                     / (1
                                        + (((c_MiRs_a253o / p_a251H) ** p_a251J)
                                           + ((c_PTB_a253q / p_a251L) ** p_a251N))))
                                    + (negate (p_a252z * c_NPTB_a253u))),
                                   ((p_a251P
                                     * (p_a2523
                                        / ((1 + p_a2523)
                                           + (((c_NPTB_a253u / p_a251V) ** p_a251X)
                                              + ((c_RESTc_a253w / p_a251Z) ** p_a2521)))))
                                    + (negate (p_a252B * c_MiRs_a253o))),
                                   ((p_a2525
                                     * ((p_a252j + ((c_PTB_a253q / p_a2527) ** p_a2529))
                                        / (((1 + p_a252j) + ((c_PTB_a253q / p_a2527) ** p_a2529))
                                           + ((c_MiRs_a253o / p_a252f) ** p_a252h))))
                                    + (negate (p_a252D * c_RESTc_a253w))),
                                   ((p_a252l
                                     * ((p_a252v + ((c_MiRs_a253o / p_a252n) ** p_a252p))
                                        / (((1 + p_a252v) + ((c_MiRs_a253o / p_a252n) ** p_a252p))
                                           + ((c_RESTc_a253w / p_a252r) ** p_a252t))))
                                    + (negate (p_a252F * c_EndoNeuroTFs_a253I)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505752",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505753",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505754",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505755",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505756",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505757",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505758",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505759",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505760",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505761",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505762",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505763",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505764",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505765",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505766",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505767",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505768",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505769",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505770",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505771",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505772",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505773",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505774",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505775",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505776",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505777",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505778",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505779",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505780",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505781",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505782",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505783",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505784",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505785",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505786",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505787",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505788",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505789",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505790",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505791",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505792",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505793",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505794",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505795",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505803",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505805",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505807",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505809",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505827",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505829",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a252G
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a254n
                            p_a252F = double g_a252E
                            (g_a252E, gpart_a254n) = Genome.Split.split gpart_a254m
                            p_a252D = double g_a252C
                            (g_a252C, gpart_a254m) = Genome.Split.split gpart_a254l
                            p_a252B = double g_a252A
                            (g_a252A, gpart_a254l) = Genome.Split.split gpart_a254k
                            p_a252z = double g_a252y
                            (g_a252y, gpart_a254k) = Genome.Split.split gpart_a254j
                            p_a252x = double g_a252w
                            (g_a252w, gpart_a254j) = Genome.Split.split gpart_a254i
                            p_a252v = double g_a252u
                            (g_a252u, gpart_a254i) = Genome.Split.split gpart_a254h
                            p_a252t = Functions.belowten' g_a252s
                            (g_a252s, gpart_a254h) = Genome.Split.split gpart_a254g
                            p_a252r = double g_a252q
                            (g_a252q, gpart_a254g) = Genome.Split.split gpart_a254f
                            p_a252p = Functions.belowten' g_a252o
                            (g_a252o, gpart_a254f) = Genome.Split.split gpart_a254e
                            p_a252n = double g_a252m
                            (g_a252m, gpart_a254e) = Genome.Split.split gpart_a254d
                            p_a252l = double g_a252k
                            (g_a252k, gpart_a254d) = Genome.Split.split gpart_a254c
                            p_a252j = double g_a252i
                            (g_a252i, gpart_a254c) = Genome.Split.split gpart_a254b
                            p_a252h = Functions.belowten' g_a252g
                            (g_a252g, gpart_a254b) = Genome.Split.split gpart_a254a
                            p_a252f = double g_a252e
                            (g_a252e, gpart_a254a) = Genome.Split.split gpart_a2549
                            p_a252d
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a252c
                            (g_a252c, gpart_a2549) = Genome.Split.split gpart_a2548
                            p_a252b
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a252a
                            (g_a252a, gpart_a2548) = Genome.Split.split gpart_a2547
                            p_a2529 = Functions.belowten' g_a2528
                            (g_a2528, gpart_a2547) = Genome.Split.split gpart_a2546
                            p_a2527 = double g_a2526
                            (g_a2526, gpart_a2546) = Genome.Split.split gpart_a2545
                            p_a2525 = double g_a2524
                            (g_a2524, gpart_a2545) = Genome.Split.split gpart_a2544
                            p_a2523 = double g_a2522
                            (g_a2522, gpart_a2544) = Genome.Split.split gpart_a2543
                            p_a2521 = Functions.belowten' g_a2520
                            (g_a2520, gpart_a2543) = Genome.Split.split gpart_a2542
                            p_a251Z = double g_a251Y
                            (g_a251Y, gpart_a2542) = Genome.Split.split gpart_a2541
                            p_a251X = Functions.belowten' g_a251W
                            (g_a251W, gpart_a2541) = Genome.Split.split gpart_a2540
                            p_a251V = double g_a251U
                            (g_a251U, gpart_a2540) = Genome.Split.split gpart_a253Z
                            p_a251T
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251S
                            (g_a251S, gpart_a253Z) = Genome.Split.split gpart_a253Y
                            p_a251R
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251Q
                            (g_a251Q, gpart_a253Y) = Genome.Split.split gpart_a253X
                            p_a251P = double g_a251O
                            (g_a251O, gpart_a253X) = Genome.Split.split gpart_a253W
                            p_a251N = Functions.belowten' g_a251M
                            (g_a251M, gpart_a253W) = Genome.Split.split gpart_a253V
                            p_a251L = double g_a251K
                            (g_a251K, gpart_a253V) = Genome.Split.split gpart_a253U
                            p_a251J = Functions.belowten' g_a251I
                            (g_a251I, gpart_a253U) = Genome.Split.split gpart_a253T
                            p_a251H = double g_a251G
                            (g_a251G, gpart_a253T) = Genome.Split.split gpart_a253S
                            p_a251F = double g_a251E
                            (g_a251E, gpart_a253S) = Genome.Split.split gpart_a253R
                            p_a251D = Functions.belowten' g_a251C
                            (g_a251C, gpart_a253R) = Genome.Split.split gpart_a253Q
                            p_a251B = double g_a251A
                            (g_a251A, gpart_a253Q) = Genome.Split.split gpart_a253P
                            p_a251z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251y
                            (g_a251y, gpart_a253P) = Genome.Split.split gpart_a253O
                            p_a251x
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251w
                            (g_a251w, gpart_a253O) = Genome.Split.split gpart_a253N
                            p_a251v = double g_a251u
                            (g_a251u, gpart_a253N) = Genome.Split.split gpart_a253M
                            p_a251t = double g_a251s
                            (g_a251s, gpart_a253M) = Genome.Split.split gpart_a253L
                            p_a251r = double g_a251q
                            (g_a251q, gpart_a253L) = Genome.Split.split gpart_a253K
                            p_a251p = double g_a251o
                            (g_a251o, gpart_a253K) = Genome.Split.split gpart_a253J
                            p_a251n = double g_a251m
                            (g_a251m, gpart_a253J) = Genome.Split.split genome_a252G
                          in
                            \ desc_a252H
                              -> case desc_a252H of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251n)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251p)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251r)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251t)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251v)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251x)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251z)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251B)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251D)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251F)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251H)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251J)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251L)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251N)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251P)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251R)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251T)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251V)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251X)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251Z)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2521)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2523)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2525)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2527)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2529)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252b)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252d)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252f)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252h)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252j)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252l)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252n)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252p)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252r)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252t)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252v)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252x)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252z)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252B)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252D)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a252F)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVb
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVR
                      p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                      (g_asV9, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                      (g_asV7, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                      (g_asV5, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                      (g_asV3, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                      (g_asV1, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                      (g_asUZ, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUY = Functions.belowten' g_asUX
                      (g_asUX, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                      (g_asUV, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUU = Functions.belowten' g_asUT
                      (g_asUT, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                      (g_asUR, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUP
                      (g_asUP, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                      (g_asUN, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUM = Functions.belowten' g_asUL
                      (g_asUL, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                      (g_asUJ, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUH
                      (g_asUH, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUF
                      (g_asUF, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUE = Functions.belowten' g_asUD
                      (g_asUD, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                      (g_asUB, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                      (g_asUz, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                      (g_asUx, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUw = Functions.belowten' g_asUv
                      (g_asUv, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                      (g_asUt, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUs = Functions.belowten' g_asUr
                      (g_asUr, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                      (g_asUp, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUo
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                      (g_asUn, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUl
                      (g_asUl, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                      (g_asUj, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUi = Functions.belowten' g_asUh
                      (g_asUh, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                      (g_asUf, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUe = Functions.belowten' g_asUd
                      (g_asUd, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                      (g_asUb, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                      (g_asU9, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asU8 = Functions.belowten' g_asU7
                      (g_asU7, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                      (g_asU5, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asU4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU3
                      (g_asU3, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU1
                      (g_asU1, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                      (g_asTZ, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                      (g_asTX, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                      (g_asTV, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                      (g_asTT, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                      (g_asTR, gpart_asVd) = Genome.Split.split genome_asVb
                    in
                      [Reaction
                         (\ x_asVS
                            -> let c_MiRs_asVT = ((toVector x_asVS) Data.Vector.Unboxed.! 2)
                               in (p_asU0 / (1 + ((c_MiRs_asVT / p_asU6) ** p_asU8))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVU
                            -> let
                                 c_MiRs_asVV = ((toVector x_asVU) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVW = ((toVector x_asVU) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUa
                                  / (1
                                     + (((c_MiRs_asVV / p_asUc) ** p_asUe)
                                        + ((c_PTB_asVW / p_asUg) ** p_asUi)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVX
                            -> let
                                 c_RESTc_asVZ = ((toVector x_asVX) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asVY = ((toVector x_asVX) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asUk
                                  * ((p_asUy + ((p_asTW / p_asUm) ** p_asUo))
                                     / (((1 + p_asUy) + ((p_asTW / p_asUm) ** p_asUo))
                                        + (((c_NPTB_asVY / p_asUq) ** p_asUs)
                                           + ((c_RESTc_asVZ / p_asUu) ** p_asUw))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asW0
                            -> let
                                 c_MiRs_asW3 = ((toVector x_asW0) Data.Vector.Unboxed.! 2)
                                 c_PTB_asW1 = ((toVector x_asW0) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUA
                                  * ((p_asUO + ((c_PTB_asW1 / p_asUC) ** p_asUE))
                                     / (((1 + p_asUO) + ((c_PTB_asW1 / p_asUC) ** p_asUE))
                                        + (((p_asTS / p_asUG) ** p_asUI)
                                           + ((c_MiRs_asW3 / p_asUK) ** p_asUM))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asW4
                            -> let
                                 c_RESTc_asW7 = ((toVector x_asW4) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asW5 = ((toVector x_asW4) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asUQ
                                  * ((p_asV0 + ((c_MiRs_asW5 / p_asUS) ** p_asUU))
                                     / (((1 + p_asV0) + ((c_MiRs_asW5 / p_asUS) ** p_asUU))
                                        + ((c_RESTc_asW7 / p_asUW) ** p_asUY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW8
                            -> let c_PTB_asW9 = ((toVector x_asW8) Data.Vector.Unboxed.! 0)
                               in (p_asV2 * c_PTB_asW9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWa
                            -> let c_NPTB_asWb = ((toVector x_asWa) Data.Vector.Unboxed.! 1)
                               in (p_asV4 * c_NPTB_asWb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWc
                            -> let c_MiRs_asWd = ((toVector x_asWc) Data.Vector.Unboxed.! 2)
                               in (p_asV6 * c_MiRs_asWd))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWe
                            -> let c_RESTc_asWf = ((toVector x_asWe) Data.Vector.Unboxed.! 3)
                               in (p_asV8 * c_RESTc_asWf))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWg
                            -> let
                                 c_EndoNeuroTFs_asWh = ((toVector x_asWg) Data.Vector.Unboxed.! 4)
                               in (p_asVa * c_EndoNeuroTFs_asWh))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120887",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120888",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120889",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120890",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120891",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120892",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120893",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120894",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120895",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120896",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120897",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120898",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120899",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120900",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120901",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120902",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120903",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120904",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120905",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120906",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120907",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120908",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120918",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120922",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120938",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120942",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120960",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120962",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVb
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asX1
                            p_asVa = code-0.1.0.0:Genome.FixedList.Functions.double g_asV9
                            (g_asV9, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asV8 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV7
                            (g_asV7, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asV6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV5
                            (g_asV5, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asV4 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV3
                            (g_asV3, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asV2 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV1
                            (g_asV1, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asV0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asUZ
                            (g_asUZ, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUY = Functions.belowten' g_asUX
                            (g_asUX, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUW = code-0.1.0.0:Genome.FixedList.Functions.double g_asUV
                            (g_asUV, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUU = Functions.belowten' g_asUT
                            (g_asUT, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUS = code-0.1.0.0:Genome.FixedList.Functions.double g_asUR
                            (g_asUR, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUP
                            (g_asUP, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUO = code-0.1.0.0:Genome.FixedList.Functions.double g_asUN
                            (g_asUN, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUM = Functions.belowten' g_asUL
                            (g_asUL, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUK = code-0.1.0.0:Genome.FixedList.Functions.double g_asUJ
                            (g_asUJ, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUH
                            (g_asUH, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUF
                            (g_asUF, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUE = Functions.belowten' g_asUD
                            (g_asUD, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUC = code-0.1.0.0:Genome.FixedList.Functions.double g_asUB
                            (g_asUB, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUA = code-0.1.0.0:Genome.FixedList.Functions.double g_asUz
                            (g_asUz, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUy = code-0.1.0.0:Genome.FixedList.Functions.double g_asUx
                            (g_asUx, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUw = Functions.belowten' g_asUv
                            (g_asUv, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUu = code-0.1.0.0:Genome.FixedList.Functions.double g_asUt
                            (g_asUt, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUs = Functions.belowten' g_asUr
                            (g_asUr, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUq = code-0.1.0.0:Genome.FixedList.Functions.double g_asUp
                            (g_asUp, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUo
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUn
                            (g_asUn, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUl
                            (g_asUl, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUk = code-0.1.0.0:Genome.FixedList.Functions.double g_asUj
                            (g_asUj, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUi = Functions.belowten' g_asUh
                            (g_asUh, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUg = code-0.1.0.0:Genome.FixedList.Functions.double g_asUf
                            (g_asUf, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUe = Functions.belowten' g_asUd
                            (g_asUd, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUc = code-0.1.0.0:Genome.FixedList.Functions.double g_asUb
                            (g_asUb, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUa = code-0.1.0.0:Genome.FixedList.Functions.double g_asU9
                            (g_asU9, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asU8 = Functions.belowten' g_asU7
                            (g_asU7, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asU6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU5
                            (g_asU5, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asU4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU3
                            (g_asU3, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asU2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU1
                            (g_asU1, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asU0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asTZ
                            (g_asTZ, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asTY = code-0.1.0.0:Genome.FixedList.Functions.double g_asTX
                            (g_asTX, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asTW = code-0.1.0.0:Genome.FixedList.Functions.double g_asTV
                            (g_asTV, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asTU = code-0.1.0.0:Genome.FixedList.Functions.double g_asTT
                            (g_asTT, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asTS = code-0.1.0.0:Genome.FixedList.Functions.double g_asTR
                            (g_asTR, gpart_asWn) = Genome.Split.split genome_asVb
                          in
                            \ desc_asVc
                              -> case desc_asVc of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTS)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTU)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTW)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTY)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU0)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU2)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU4)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU6)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU8)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUa)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUc)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUe)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUg)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUi)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUk)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUm)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUo)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUq)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUs)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUu)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUw)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUy)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUA)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUC)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUE)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUG)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUI)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUK)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUM)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUO)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUQ)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUS)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUU)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUW)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUY)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV0)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV2)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV4)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV6)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV8)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVa)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZ2
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZI
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYT = code-0.1.0.0:Genome.FixedList.Functions.double g_asYS
                      (g_asYS, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                      (g_asYQ, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYP = Functions.belowten' g_asYO
                      (g_asYO, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYL = Functions.belowten' g_asYK
                      (g_asYK, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                      (g_asYE, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYD = Functions.belowten' g_asYC
                      (g_asYC, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                      (g_asYy, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYw
                      (g_asYw, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYv = Functions.belowten' g_asYu
                      (g_asYu, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                      (g_asYs, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYn = Functions.belowten' g_asYm
                      (g_asYm, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYj = Functions.belowten' g_asYi
                      (g_asYi, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                      (g_asYe, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYc
                      (g_asYc, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asY9 = Functions.belowten' g_asY8
                      (g_asY8, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asY5 = Functions.belowten' g_asY4
                      (g_asY4, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                      (g_asY0, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asXZ = Functions.belowten' g_asXY
                      (g_asXY, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                      (g_asXW, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asXV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXU
                      (g_asXU, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asXT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXS
                      (g_asXS, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                      (g_asXQ, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                      (g_asXM, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                      (g_asXK, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asZ4) = Genome.Split.split genome_asZ2
                    in
                      [Reaction
                         (\ x_asZJ
                            -> let c_MiRs_asZK = ((toVector x_asZJ) Data.Vector.Unboxed.! 2)
                               in (p_asXR / (1 + ((c_MiRs_asZK / p_asXX) ** p_asXZ))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZL
                            -> let
                                 c_MiRs_asZM = ((toVector x_asZL) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZN = ((toVector x_asZL) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asY1
                                  / (1
                                     + (((c_MiRs_asZM / p_asY3) ** p_asY5)
                                        + ((c_PTB_asZN / p_asY7) ** p_asY9)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZO
                            -> let
                                 c_RESTc_asZQ = ((toVector x_asZO) Data.Vector.Unboxed.! 3)
                                 c_NPTB_asZP = ((toVector x_asZO) Data.Vector.Unboxed.! 1)
                               in
                                 (p_asYb
                                  * (p_asYp
                                     / ((1 + p_asYp)
                                        + (((c_NPTB_asZP / p_asYh) ** p_asYj)
                                           + ((c_RESTc_asZQ / p_asYl) ** p_asYn))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZR
                            -> let
                                 c_MiRs_asZU = ((toVector x_asZR) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZS = ((toVector x_asZR) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYr
                                  * ((p_asYF + ((c_PTB_asZS / p_asYt) ** p_asYv))
                                     / (((1 + p_asYF) + ((c_PTB_asZS / p_asYt) ** p_asYv))
                                        + (((p_asXJ / p_asYx) ** p_asYz)
                                           + ((c_MiRs_asZU / p_asYB) ** p_asYD))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZV
                            -> let
                                 c_RESTc_asZY = ((toVector x_asZV) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZW = ((toVector x_asZV) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYH
                                  * ((p_asYR + ((c_MiRs_asZW / p_asYJ) ** p_asYL))
                                     / (((1 + p_asYR) + ((c_MiRs_asZW / p_asYJ) ** p_asYL))
                                        + ((c_RESTc_asZY / p_asYN) ** p_asYP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZZ
                            -> let c_PTB_at00 = ((toVector x_asZZ) Data.Vector.Unboxed.! 0)
                               in (p_asYT * c_PTB_at00))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at01
                            -> let c_NPTB_at02 = ((toVector x_at01) Data.Vector.Unboxed.! 1)
                               in (p_asYV * c_NPTB_at02))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at03
                            -> let c_MiRs_at04 = ((toVector x_at03) Data.Vector.Unboxed.! 2)
                               in (p_asYX * c_MiRs_at04))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at05
                            -> let c_RESTc_at06 = ((toVector x_at05) Data.Vector.Unboxed.! 3)
                               in (p_asYZ * c_RESTc_at06))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at07
                            -> let
                                 c_EndoNeuroTFs_at08 = ((toVector x_at07) Data.Vector.Unboxed.! 4)
                               in (p_asZ1 * c_EndoNeuroTFs_at08))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZ2
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0N
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYT = code-0.1.0.0:Genome.FixedList.Functions.double g_asYS
                            (g_asYS, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYR = code-0.1.0.0:Genome.FixedList.Functions.double g_asYQ
                            (g_asYQ, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYP = Functions.belowten' g_asYO
                            (g_asYO, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYL = Functions.belowten' g_asYK
                            (g_asYK, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                            (g_asYE, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYD = Functions.belowten' g_asYC
                            (g_asYC, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                            (g_asYy, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYw
                            (g_asYw, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asYv = Functions.belowten' g_asYu
                            (g_asYu, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                            (g_asYs, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYn = Functions.belowten' g_asYm
                            (g_asYm, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYj = Functions.belowten' g_asYi
                            (g_asYi, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asYf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                            (g_asYe, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asYd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYc
                            (g_asYc, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asY9 = Functions.belowten' g_asY8
                            (g_asY8, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asY5 = Functions.belowten' g_asY4
                            (g_asY4, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asY1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY0
                            (g_asY0, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asXZ = Functions.belowten' g_asXY
                            (g_asXY, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asXX = code-0.1.0.0:Genome.FixedList.Functions.double g_asXW
                            (g_asXW, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asXV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXU
                            (g_asXU, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asXT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXS
                            (g_asXS, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asXR = code-0.1.0.0:Genome.FixedList.Functions.double g_asXQ
                            (g_asXQ, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asXN = code-0.1.0.0:Genome.FixedList.Functions.double g_asXM
                            (g_asXM, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asXL = code-0.1.0.0:Genome.FixedList.Functions.double g_asXK
                            (g_asXK, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_at09) = Genome.Split.split genome_asZ2
                          in
                            \ desc_asZ3
                              -> case desc_asZ3 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2O
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3u
                      p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                      (g_at2M, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                      (g_at2K, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                      (g_at2I, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                      (g_at2G, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                      (g_at2E, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                      (g_at2C, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2B = Functions.belowten' g_at2A
                      (g_at2A, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                      (g_at2y, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2x = Functions.belowten' g_at2w
                      (g_at2w, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                      (g_at2u, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                      (g_at2s, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                      (g_at2q, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at2p = Functions.belowten' g_at2o
                      (g_at2o, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                      (g_at2m, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at2l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2k
                      (g_at2k, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at2j
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2i
                      (g_at2i, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at2h = Functions.belowten' g_at2g
                      (g_at2g, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                      (g_at2e, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                      (g_at2c, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                      (g_at2a, gpart_at3b) = Genome.Split.split gpart_at3a
                      p_at29 = Functions.belowten' g_at28
                      (g_at28, gpart_at3a) = Genome.Split.split gpart_at39
                      p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                      (g_at26, gpart_at39) = Genome.Split.split gpart_at38
                      p_at25 = Functions.belowten' g_at24
                      (g_at24, gpart_at38) = Genome.Split.split gpart_at37
                      p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                      (g_at22, gpart_at37) = Genome.Split.split gpart_at36
                      p_at21
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at20
                      (g_at20, gpart_at36) = Genome.Split.split gpart_at35
                      p_at1Z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Y
                      (g_at1Y, gpart_at35) = Genome.Split.split gpart_at34
                      p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                      (g_at1W, gpart_at34) = Genome.Split.split gpart_at33
                      p_at1V = Functions.belowten' g_at1U
                      (g_at1U, gpart_at33) = Genome.Split.split gpart_at32
                      p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                      (g_at1S, gpart_at32) = Genome.Split.split gpart_at31
                      p_at1R = Functions.belowten' g_at1Q
                      (g_at1Q, gpart_at31) = Genome.Split.split gpart_at30
                      p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                      (g_at1O, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                      (g_at1M, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at1L = Functions.belowten' g_at1K
                      (g_at1K, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                      (g_at1I, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at1H
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1G
                      (g_at1G, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at1F
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1E
                      (g_at1E, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                      (g_at1C, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at1B = code-0.1.0.0:Genome.FixedList.Functions.double g_at1A
                      (g_at1A, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                      (g_at1y, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                      (g_at1w, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                      (g_at1u, gpart_at2Q) = Genome.Split.split genome_at2O
                    in
                      [Reaction
                         (\ x_at3v
                            -> let c_MiRs_at3w = ((toVector x_at3v) Data.Vector.Unboxed.! 2)
                               in (p_at1D / (1 + ((c_MiRs_at3w / p_at1J) ** p_at1L))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3x
                            -> let
                                 c_MiRs_at3y = ((toVector x_at3x) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3z = ((toVector x_at3x) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1N
                                  / (1
                                     + (((c_MiRs_at3y / p_at1P) ** p_at1R)
                                        + ((c_PTB_at3z / p_at1T) ** p_at1V)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3A
                            -> let
                                 c_RESTc_at3C = ((toVector x_at3A) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at3B = ((toVector x_at3A) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at1X
                                  * (p_at2b
                                     / ((1 + p_at2b)
                                        + (((c_NPTB_at3B / p_at23) ** p_at25)
                                           + ((c_RESTc_at3C / p_at27) ** p_at29))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3D
                            -> let
                                 c_MiRs_at3G = ((toVector x_at3D) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3E = ((toVector x_at3D) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2d
                                  * ((p_at2r + ((c_PTB_at3E / p_at2f) ** p_at2h))
                                     / (((1 + p_at2r) + ((c_PTB_at3E / p_at2f) ** p_at2h))
                                        + ((c_MiRs_at3G / p_at2n) ** p_at2p)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3H
                            -> let
                                 c_RESTc_at3K = ((toVector x_at3H) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3I = ((toVector x_at3H) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2t
                                  * ((p_at2D + ((c_MiRs_at3I / p_at2v) ** p_at2x))
                                     / (((1 + p_at2D) + ((c_MiRs_at3I / p_at2v) ** p_at2x))
                                        + ((c_RESTc_at3K / p_at2z) ** p_at2B)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3L
                            -> let c_PTB_at3M = ((toVector x_at3L) Data.Vector.Unboxed.! 0)
                               in (p_at2F * c_PTB_at3M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3N
                            -> let c_NPTB_at3O = ((toVector x_at3N) Data.Vector.Unboxed.! 1)
                               in (p_at2H * c_NPTB_at3O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3P
                            -> let c_MiRs_at3Q = ((toVector x_at3P) Data.Vector.Unboxed.! 2)
                               in (p_at2J * c_MiRs_at3Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3R
                            -> let c_RESTc_at3S = ((toVector x_at3R) Data.Vector.Unboxed.! 3)
                               in (p_at2L * c_RESTc_at3S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3T
                            -> let
                                 c_EndoNeuroTFs_at3U = ((toVector x_at3T) Data.Vector.Unboxed.! 4)
                               in (p_at2N * c_EndoNeuroTFs_at3U))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121371",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121373",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121377",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121379",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121391",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121393",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121395",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121411",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121413",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121424",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121425",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121426",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121427",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121428",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121429",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121430",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121431",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121432",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121433",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121434",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121435",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121436",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121437",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121438",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121439",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121440",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121441",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2O
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4z
                            p_at2N = code-0.1.0.0:Genome.FixedList.Functions.double g_at2M
                            (g_at2M, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2L = code-0.1.0.0:Genome.FixedList.Functions.double g_at2K
                            (g_at2K, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2J = code-0.1.0.0:Genome.FixedList.Functions.double g_at2I
                            (g_at2I, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2H = code-0.1.0.0:Genome.FixedList.Functions.double g_at2G
                            (g_at2G, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2F = code-0.1.0.0:Genome.FixedList.Functions.double g_at2E
                            (g_at2E, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2D = code-0.1.0.0:Genome.FixedList.Functions.double g_at2C
                            (g_at2C, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2B = Functions.belowten' g_at2A
                            (g_at2A, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2z = code-0.1.0.0:Genome.FixedList.Functions.double g_at2y
                            (g_at2y, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2x = Functions.belowten' g_at2w
                            (g_at2w, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at2v = code-0.1.0.0:Genome.FixedList.Functions.double g_at2u
                            (g_at2u, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at2t = code-0.1.0.0:Genome.FixedList.Functions.double g_at2s
                            (g_at2s, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at2r = code-0.1.0.0:Genome.FixedList.Functions.double g_at2q
                            (g_at2q, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at2p = Functions.belowten' g_at2o
                            (g_at2o, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at2n = code-0.1.0.0:Genome.FixedList.Functions.double g_at2m
                            (g_at2m, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at2l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2k
                            (g_at2k, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at2j
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2i
                            (g_at2i, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at2h = Functions.belowten' g_at2g
                            (g_at2g, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at2f = code-0.1.0.0:Genome.FixedList.Functions.double g_at2e
                            (g_at2e, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at2d = code-0.1.0.0:Genome.FixedList.Functions.double g_at2c
                            (g_at2c, gpart_at4h) = Genome.Split.split gpart_at4g
                            p_at2b = code-0.1.0.0:Genome.FixedList.Functions.double g_at2a
                            (g_at2a, gpart_at4g) = Genome.Split.split gpart_at4f
                            p_at29 = Functions.belowten' g_at28
                            (g_at28, gpart_at4f) = Genome.Split.split gpart_at4e
                            p_at27 = code-0.1.0.0:Genome.FixedList.Functions.double g_at26
                            (g_at26, gpart_at4e) = Genome.Split.split gpart_at4d
                            p_at25 = Functions.belowten' g_at24
                            (g_at24, gpart_at4d) = Genome.Split.split gpart_at4c
                            p_at23 = code-0.1.0.0:Genome.FixedList.Functions.double g_at22
                            (g_at22, gpart_at4c) = Genome.Split.split gpart_at4b
                            p_at21
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at20
                            (g_at20, gpart_at4b) = Genome.Split.split gpart_at4a
                            p_at1Z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Y
                            (g_at1Y, gpart_at4a) = Genome.Split.split gpart_at49
                            p_at1X = code-0.1.0.0:Genome.FixedList.Functions.double g_at1W
                            (g_at1W, gpart_at49) = Genome.Split.split gpart_at48
                            p_at1V = Functions.belowten' g_at1U
                            (g_at1U, gpart_at48) = Genome.Split.split gpart_at47
                            p_at1T = code-0.1.0.0:Genome.FixedList.Functions.double g_at1S
                            (g_at1S, gpart_at47) = Genome.Split.split gpart_at46
                            p_at1R = Functions.belowten' g_at1Q
                            (g_at1Q, gpart_at46) = Genome.Split.split gpart_at45
                            p_at1P = code-0.1.0.0:Genome.FixedList.Functions.double g_at1O
                            (g_at1O, gpart_at45) = Genome.Split.split gpart_at44
                            p_at1N = code-0.1.0.0:Genome.FixedList.Functions.double g_at1M
                            (g_at1M, gpart_at44) = Genome.Split.split gpart_at43
                            p_at1L = Functions.belowten' g_at1K
                            (g_at1K, gpart_at43) = Genome.Split.split gpart_at42
                            p_at1J = code-0.1.0.0:Genome.FixedList.Functions.double g_at1I
                            (g_at1I, gpart_at42) = Genome.Split.split gpart_at41
                            p_at1H
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1G
                            (g_at1G, gpart_at41) = Genome.Split.split gpart_at40
                            p_at1F
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1E
                            (g_at1E, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at1D = code-0.1.0.0:Genome.FixedList.Functions.double g_at1C
                            (g_at1C, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at1B = code-0.1.0.0:Genome.FixedList.Functions.double g_at1A
                            (g_at1A, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at1z = code-0.1.0.0:Genome.FixedList.Functions.double g_at1y
                            (g_at1y, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at1x = code-0.1.0.0:Genome.FixedList.Functions.double g_at1w
                            (g_at1w, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at1v = code-0.1.0.0:Genome.FixedList.Functions.double g_at1u
                            (g_at1u, gpart_at3V) = Genome.Split.split genome_at2O
                          in
                            \ desc_at2P
                              -> case desc_at2P of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1v)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1x)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1z)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1B)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1D)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1F)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1H)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1J)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1L)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1N)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1P)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1R)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1T)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1V)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1X)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Z)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at21)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at23)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at25)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at27)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at29)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2b)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2d)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2f)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2h)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2j)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2l)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2n)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2p)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2r)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2t)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2v)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2x)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2z)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2B)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2D)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2F)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2H)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2J)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2L)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2N)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6A
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7g
                      p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                      (g_at6y, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                      (g_at6s, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                      (g_at6q, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at6n = Functions.belowten' g_at6m
                      (g_at6m, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at79) = Genome.Split.split gpart_at78
                      p_at6j = Functions.belowten' g_at6i
                      (g_at6i, gpart_at78) = Genome.Split.split gpart_at77
                      p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                      (g_at6g, gpart_at77) = Genome.Split.split gpart_at76
                      p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                      (g_at6e, gpart_at76) = Genome.Split.split gpart_at75
                      p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                      (g_at6c, gpart_at75) = Genome.Split.split gpart_at74
                      p_at6b = Functions.belowten' g_at6a
                      (g_at6a, gpart_at74) = Genome.Split.split gpart_at73
                      p_at69 = code-0.1.0.0:Genome.FixedList.Functions.double g_at68
                      (g_at68, gpart_at73) = Genome.Split.split gpart_at72
                      p_at67
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                      (g_at66, gpart_at72) = Genome.Split.split gpart_at71
                      p_at65
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at64
                      (g_at64, gpart_at71) = Genome.Split.split gpart_at70
                      p_at63 = Functions.belowten' g_at62
                      (g_at62, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                      (g_at60, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at6Y) = Genome.Split.split gpart_at6X
                      p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                      (g_at5W, gpart_at6X) = Genome.Split.split gpart_at6W
                      p_at5V = Functions.belowten' g_at5U
                      (g_at5U, gpart_at6W) = Genome.Split.split gpart_at6V
                      p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                      (g_at5S, gpart_at6V) = Genome.Split.split gpart_at6U
                      p_at5R = Functions.belowten' g_at5Q
                      (g_at5Q, gpart_at6U) = Genome.Split.split gpart_at6T
                      p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                      (g_at5O, gpart_at6T) = Genome.Split.split gpart_at6S
                      p_at5N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                      (g_at5M, gpart_at6S) = Genome.Split.split gpart_at6R
                      p_at5L
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5K
                      (g_at5K, gpart_at6R) = Genome.Split.split gpart_at6Q
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6Q) = Genome.Split.split gpart_at6P
                      p_at5H = Functions.belowten' g_at5G
                      (g_at5G, gpart_at6P) = Genome.Split.split gpart_at6O
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6O) = Genome.Split.split gpart_at6N
                      p_at5D = Functions.belowten' g_at5C
                      (g_at5C, gpart_at6N) = Genome.Split.split gpart_at6M
                      p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                      (g_at5A, gpart_at6M) = Genome.Split.split gpart_at6L
                      p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                      (g_at5y, gpart_at6L) = Genome.Split.split gpart_at6K
                      p_at5x = Functions.belowten' g_at5w
                      (g_at5w, gpart_at6K) = Genome.Split.split gpart_at6J
                      p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                      (g_at5u, gpart_at6J) = Genome.Split.split gpart_at6I
                      p_at5t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5s
                      (g_at5s, gpart_at6I) = Genome.Split.split gpart_at6H
                      p_at5r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                      (g_at5q, gpart_at6H) = Genome.Split.split gpart_at6G
                      p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                      (g_at5o, gpart_at6G) = Genome.Split.split gpart_at6F
                      p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                      (g_at5m, gpart_at6F) = Genome.Split.split gpart_at6E
                      p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                      (g_at5k, gpart_at6E) = Genome.Split.split gpart_at6D
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at6D) = Genome.Split.split gpart_at6C
                      p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                      (g_at5g, gpart_at6C) = Genome.Split.split genome_at6A
                    in
                      [Reaction
                         (\ x_at7h
                            -> let c_MiRs_at7i = ((toVector x_at7h) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5p
                                  / (1
                                     + (((p_at5h / p_at5r) ** p_at5t)
                                        + ((c_MiRs_at7i / p_at5v) ** p_at5x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7j
                            -> let
                                 c_MiRs_at7k = ((toVector x_at7j) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7l = ((toVector x_at7j) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5z
                                  / (1
                                     + (((c_MiRs_at7k / p_at5B) ** p_at5D)
                                        + ((c_PTB_at7l / p_at5F) ** p_at5H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7m
                            -> let
                                 c_RESTc_at7o = ((toVector x_at7m) Data.Vector.Unboxed.! 3)
                                 c_NPTB_at7n = ((toVector x_at7m) Data.Vector.Unboxed.! 1)
                               in
                                 (p_at5J
                                  * (p_at5X
                                     / ((1 + p_at5X)
                                        + (((c_NPTB_at7n / p_at5P) ** p_at5R)
                                           + ((c_RESTc_at7o / p_at5T) ** p_at5V))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7p
                            -> let
                                 c_MiRs_at7s = ((toVector x_at7p) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7q = ((toVector x_at7p) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5Z
                                  * ((p_at6d + ((c_PTB_at7q / p_at61) ** p_at63))
                                     / (((1 + p_at6d) + ((c_PTB_at7q / p_at61) ** p_at63))
                                        + ((c_MiRs_at7s / p_at69) ** p_at6b)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7t
                            -> let
                                 c_RESTc_at7w = ((toVector x_at7t) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7u = ((toVector x_at7t) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6f
                                  * ((p_at6p + ((c_MiRs_at7u / p_at6h) ** p_at6j))
                                     / (((1 + p_at6p) + ((c_MiRs_at7u / p_at6h) ** p_at6j))
                                        + ((c_RESTc_at7w / p_at6l) ** p_at6n)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7x
                            -> let c_PTB_at7y = ((toVector x_at7x) Data.Vector.Unboxed.! 0)
                               in (p_at6r * c_PTB_at7y))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7z
                            -> let c_NPTB_at7A = ((toVector x_at7z) Data.Vector.Unboxed.! 1)
                               in (p_at6t * c_NPTB_at7A))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7B
                            -> let c_MiRs_at7C = ((toVector x_at7B) Data.Vector.Unboxed.! 2)
                               in (p_at6v * c_MiRs_at7C))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at7D
                            -> let c_RESTc_at7E = ((toVector x_at7D) Data.Vector.Unboxed.! 3)
                               in (p_at6x * c_RESTc_at7E))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at7F
                            -> let
                                 c_EndoNeuroTFs_at7G = ((toVector x_at7F) Data.Vector.Unboxed.! 4)
                               in (p_at6z * c_EndoNeuroTFs_at7G))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6A
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8l
                            p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                            (g_at6y, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                            (g_at6s, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at6r = code-0.1.0.0:Genome.FixedList.Functions.double g_at6q
                            (g_at6q, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at6n = Functions.belowten' g_at6m
                            (g_at6m, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at6j = Functions.belowten' g_at6i
                            (g_at6i, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at6h = code-0.1.0.0:Genome.FixedList.Functions.double g_at6g
                            (g_at6g, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                            (g_at6e, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at6d = code-0.1.0.0:Genome.FixedList.Functions.double g_at6c
                            (g_at6c, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at6b = Functions.belowten' g_at6a
                            (g_at6a, gpart_at89) = Genome.Split.split gpart_at88
                            p_at69 = code-0.1.0.0:Genome.FixedList.Functions.double g_at68
                            (g_at68, gpart_at88) = Genome.Split.split gpart_at87
                            p_at67
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                            (g_at66, gpart_at87) = Genome.Split.split gpart_at86
                            p_at65
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at64
                            (g_at64, gpart_at86) = Genome.Split.split gpart_at85
                            p_at63 = Functions.belowten' g_at62
                            (g_at62, gpart_at85) = Genome.Split.split gpart_at84
                            p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                            (g_at60, gpart_at84) = Genome.Split.split gpart_at83
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at83) = Genome.Split.split gpart_at82
                            p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                            (g_at5W, gpart_at82) = Genome.Split.split gpart_at81
                            p_at5V = Functions.belowten' g_at5U
                            (g_at5U, gpart_at81) = Genome.Split.split gpart_at80
                            p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                            (g_at5S, gpart_at80) = Genome.Split.split gpart_at7Z
                            p_at5R = Functions.belowten' g_at5Q
                            (g_at5Q, gpart_at7Z) = Genome.Split.split gpart_at7Y
                            p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                            (g_at5O, gpart_at7Y) = Genome.Split.split gpart_at7X
                            p_at5N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                            (g_at5M, gpart_at7X) = Genome.Split.split gpart_at7W
                            p_at5L
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5K
                            (g_at5K, gpart_at7W) = Genome.Split.split gpart_at7V
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at7V) = Genome.Split.split gpart_at7U
                            p_at5H = Functions.belowten' g_at5G
                            (g_at5G, gpart_at7U) = Genome.Split.split gpart_at7T
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7T) = Genome.Split.split gpart_at7S
                            p_at5D = Functions.belowten' g_at5C
                            (g_at5C, gpart_at7S) = Genome.Split.split gpart_at7R
                            p_at5B = code-0.1.0.0:Genome.FixedList.Functions.double g_at5A
                            (g_at5A, gpart_at7R) = Genome.Split.split gpart_at7Q
                            p_at5z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5y
                            (g_at5y, gpart_at7Q) = Genome.Split.split gpart_at7P
                            p_at5x = Functions.belowten' g_at5w
                            (g_at5w, gpart_at7P) = Genome.Split.split gpart_at7O
                            p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                            (g_at5u, gpart_at7O) = Genome.Split.split gpart_at7N
                            p_at5t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5s
                            (g_at5s, gpart_at7N) = Genome.Split.split gpart_at7M
                            p_at5r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5q
                            (g_at5q, gpart_at7M) = Genome.Split.split gpart_at7L
                            p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                            (g_at5o, gpart_at7L) = Genome.Split.split gpart_at7K
                            p_at5n = code-0.1.0.0:Genome.FixedList.Functions.double g_at5m
                            (g_at5m, gpart_at7K) = Genome.Split.split gpart_at7J
                            p_at5l = code-0.1.0.0:Genome.FixedList.Functions.double g_at5k
                            (g_at5k, gpart_at7J) = Genome.Split.split gpart_at7I
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5h = code-0.1.0.0:Genome.FixedList.Functions.double g_at5g
                            (g_at5g, gpart_at7H) = Genome.Split.split genome_at6A
                          in
                            \ desc_at6B
                              -> case desc_at6B of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Inhibition coef [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Inhibition hill [NPTB] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   _ -> Nothing }}
