src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a218t
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a2197
                      p_a218s = double g_a218r
                      (g_a218r, gpart_a2197) = Genome.Split.split gpart_a2196
                      p_a218q = double g_a218p
                      (g_a218p, gpart_a2196) = Genome.Split.split gpart_a2195
                      p_a218o = double g_a218n
                      (g_a218n, gpart_a2195) = Genome.Split.split gpart_a2194
                      p_a218m = double g_a218l
                      (g_a218l, gpart_a2194) = Genome.Split.split gpart_a2193
                      p_a218k = double g_a218j
                      (g_a218j, gpart_a2193) = Genome.Split.split gpart_a2192
                      p_a218i = double g_a218h
                      (g_a218h, gpart_a2192) = Genome.Split.split gpart_a2191
                      p_a218g = Functions.belowten' g_a218f
                      (g_a218f, gpart_a2191) = Genome.Split.split gpart_a2190
                      p_a218e = double g_a218d
                      (g_a218d, gpart_a2190) = Genome.Split.split gpart_a218Z
                      p_a218c = Functions.belowten' g_a218b
                      (g_a218b, gpart_a218Z) = Genome.Split.split gpart_a218Y
                      p_a218a = double g_a2189
                      (g_a2189, gpart_a218Y) = Genome.Split.split gpart_a218X
                      p_a2188 = double g_a2187
                      (g_a2187, gpart_a218X) = Genome.Split.split gpart_a218W
                      p_a2186 = double g_a2185
                      (g_a2185, gpart_a218W) = Genome.Split.split gpart_a218V
                      p_a2184 = Functions.belowten' g_a2183
                      (g_a2183, gpart_a218V) = Genome.Split.split gpart_a218U
                      p_a2182 = double g_a2181
                      (g_a2181, gpart_a218U) = Genome.Split.split gpart_a218T
                      p_a2180
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217Z
                      (g_a217Z, gpart_a218T) = Genome.Split.split gpart_a218S
                      p_a217Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217X
                      (g_a217X, gpart_a218S) = Genome.Split.split gpart_a218R
                      p_a217W = Functions.belowten' g_a217V
                      (g_a217V, gpart_a218R) = Genome.Split.split gpart_a218Q
                      p_a217U = double g_a217T
                      (g_a217T, gpart_a218Q) = Genome.Split.split gpart_a218P
                      p_a217S = double g_a217R
                      (g_a217R, gpart_a218P) = Genome.Split.split gpart_a218O
                      p_a217Q = double g_a217P
                      (g_a217P, gpart_a218O) = Genome.Split.split gpart_a218N
                      p_a217O = Functions.belowten' g_a217N
                      (g_a217N, gpart_a218N) = Genome.Split.split gpart_a218M
                      p_a217M = double g_a217L
                      (g_a217L, gpart_a218M) = Genome.Split.split gpart_a218L
                      p_a217K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217J
                      (g_a217J, gpart_a218L) = Genome.Split.split gpart_a218K
                      p_a217I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217H
                      (g_a217H, gpart_a218K) = Genome.Split.split gpart_a218J
                      p_a217G = double g_a217F
                      (g_a217F, gpart_a218J) = Genome.Split.split gpart_a218I
                      p_a217E = Functions.belowten' g_a217D
                      (g_a217D, gpart_a218I) = Genome.Split.split gpart_a218H
                      p_a217C = double g_a217B
                      (g_a217B, gpart_a218H) = Genome.Split.split gpart_a218G
                      p_a217A = Functions.belowten' g_a217z
                      (g_a217z, gpart_a218G) = Genome.Split.split gpart_a218F
                      p_a217y = double g_a217x
                      (g_a217x, gpart_a218F) = Genome.Split.split gpart_a218E
                      p_a217w = double g_a217v
                      (g_a217v, gpart_a218E) = Genome.Split.split gpart_a218D
                      p_a217u = Functions.belowten' g_a217t
                      (g_a217t, gpart_a218D) = Genome.Split.split gpart_a218C
                      p_a217s = double g_a217r
                      (g_a217r, gpart_a218C) = Genome.Split.split gpart_a218B
                      p_a217q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217p
                      (g_a217p, gpart_a218B) = Genome.Split.split gpart_a218A
                      p_a217o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217n
                      (g_a217n, gpart_a218A) = Genome.Split.split gpart_a218z
                      p_a217m = double g_a217l
                      (g_a217l, gpart_a218z) = Genome.Split.split gpart_a218y
                      p_a217k = double g_a217j
                      (g_a217j, gpart_a218y) = Genome.Split.split gpart_a218x
                      p_a217i = double g_a217h
                      (g_a217h, gpart_a218x) = Genome.Split.split gpart_a218w
                      p_a217g = double g_a217f
                      (g_a217f, gpart_a218w) = Genome.Split.split gpart_a218v
                      p_a217e = double g_a217d
                      (g_a217d, gpart_a218v) = Genome.Split.split genome_a218t
                    in  \ x_a2198
                          -> let
                               c_PTB_a219b
                                 = ((Data.Fixed.Vector.toVector x_a2198) Data.Vector.Unboxed.! 0)
                               c_MiRs_a2199
                                 = ((Data.Fixed.Vector.toVector x_a2198) Data.Vector.Unboxed.! 2)
                               c_NPTB_a219f
                                 = ((Data.Fixed.Vector.toVector x_a2198) Data.Vector.Unboxed.! 1)
                               c_RESTc_a219g
                                 = ((Data.Fixed.Vector.toVector x_a2198) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a219s
                                 = ((Data.Fixed.Vector.toVector x_a2198) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a217m / (1 + ((c_MiRs_a2199 / p_a217s) ** p_a217u)))
                                    + (negate (p_a218k * c_PTB_a219b))),
                                   ((p_a217w
                                     / (1
                                        + (((c_MiRs_a2199 / p_a217y) ** p_a217A)
                                           + ((c_PTB_a219b / p_a217C) ** p_a217E))))
                                    + (negate (p_a218m * c_NPTB_a219f))),
                                   ((p_a217G
                                     * ((p_a217Q + ((p_a217i / p_a217I) ** p_a217K))
                                        / (((1 + p_a217Q) + ((p_a217i / p_a217I) ** p_a217K))
                                           + ((c_RESTc_a219g / p_a217M) ** p_a217O))))
                                    + (negate (p_a218o * c_MiRs_a2199))),
                                   ((p_a217S
                                     * ((p_a2186 + ((c_PTB_a219b / p_a217U) ** p_a217W))
                                        / (((1 + p_a2186) + ((c_PTB_a219b / p_a217U) ** p_a217W))
                                           + (((p_a217e / p_a217Y) ** p_a2180)
                                              + ((c_MiRs_a2199 / p_a2182) ** p_a2184)))))
                                    + (negate (p_a218q * c_RESTc_a219g))),
                                   ((p_a2188
                                     * ((p_a218i + ((c_MiRs_a2199 / p_a218a) ** p_a218c))
                                        / (((1 + p_a218i) + ((c_MiRs_a2199 / p_a218a) ** p_a218c))
                                           + ((c_RESTc_a219g / p_a218e) ** p_a218g))))
                                    + (negate (p_a218s * c_EndoNeuroTFs_a219s)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490740",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490742",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490750",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490752",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490770",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490771",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490772",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490773",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490774",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490775",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490776",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490777",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490778",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490779",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490780",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490781",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490782",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490783",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490784",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490785",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490786",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490787",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490788",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490789",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490790",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490791",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490792",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490793",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490794",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490795",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490796",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490797",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490798",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490799",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490800",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490801",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490802",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490803",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490804",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490805",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490806",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490807",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490808",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490809",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490810",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490811",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490812",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490813",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490814",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490815",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490816",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a218t
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21a5
                            p_a218s = double g_a218r
                            (g_a218r, gpart_a21a5) = Genome.Split.split gpart_a21a4
                            p_a218q = double g_a218p
                            (g_a218p, gpart_a21a4) = Genome.Split.split gpart_a21a3
                            p_a218o = double g_a218n
                            (g_a218n, gpart_a21a3) = Genome.Split.split gpart_a21a2
                            p_a218m = double g_a218l
                            (g_a218l, gpart_a21a2) = Genome.Split.split gpart_a21a1
                            p_a218k = double g_a218j
                            (g_a218j, gpart_a21a1) = Genome.Split.split gpart_a21a0
                            p_a218i = double g_a218h
                            (g_a218h, gpart_a21a0) = Genome.Split.split gpart_a219Z
                            p_a218g = Functions.belowten' g_a218f
                            (g_a218f, gpart_a219Z) = Genome.Split.split gpart_a219Y
                            p_a218e = double g_a218d
                            (g_a218d, gpart_a219Y) = Genome.Split.split gpart_a219X
                            p_a218c = Functions.belowten' g_a218b
                            (g_a218b, gpart_a219X) = Genome.Split.split gpart_a219W
                            p_a218a = double g_a2189
                            (g_a2189, gpart_a219W) = Genome.Split.split gpart_a219V
                            p_a2188 = double g_a2187
                            (g_a2187, gpart_a219V) = Genome.Split.split gpart_a219U
                            p_a2186 = double g_a2185
                            (g_a2185, gpart_a219U) = Genome.Split.split gpart_a219T
                            p_a2184 = Functions.belowten' g_a2183
                            (g_a2183, gpart_a219T) = Genome.Split.split gpart_a219S
                            p_a2182 = double g_a2181
                            (g_a2181, gpart_a219S) = Genome.Split.split gpart_a219R
                            p_a2180
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217Z
                            (g_a217Z, gpart_a219R) = Genome.Split.split gpart_a219Q
                            p_a217Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217X
                            (g_a217X, gpart_a219Q) = Genome.Split.split gpart_a219P
                            p_a217W = Functions.belowten' g_a217V
                            (g_a217V, gpart_a219P) = Genome.Split.split gpart_a219O
                            p_a217U = double g_a217T
                            (g_a217T, gpart_a219O) = Genome.Split.split gpart_a219N
                            p_a217S = double g_a217R
                            (g_a217R, gpart_a219N) = Genome.Split.split gpart_a219M
                            p_a217Q = double g_a217P
                            (g_a217P, gpart_a219M) = Genome.Split.split gpart_a219L
                            p_a217O = Functions.belowten' g_a217N
                            (g_a217N, gpart_a219L) = Genome.Split.split gpart_a219K
                            p_a217M = double g_a217L
                            (g_a217L, gpart_a219K) = Genome.Split.split gpart_a219J
                            p_a217K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217J
                            (g_a217J, gpart_a219J) = Genome.Split.split gpart_a219I
                            p_a217I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217H
                            (g_a217H, gpart_a219I) = Genome.Split.split gpart_a219H
                            p_a217G = double g_a217F
                            (g_a217F, gpart_a219H) = Genome.Split.split gpart_a219G
                            p_a217E = Functions.belowten' g_a217D
                            (g_a217D, gpart_a219G) = Genome.Split.split gpart_a219F
                            p_a217C = double g_a217B
                            (g_a217B, gpart_a219F) = Genome.Split.split gpart_a219E
                            p_a217A = Functions.belowten' g_a217z
                            (g_a217z, gpart_a219E) = Genome.Split.split gpart_a219D
                            p_a217y = double g_a217x
                            (g_a217x, gpart_a219D) = Genome.Split.split gpart_a219C
                            p_a217w = double g_a217v
                            (g_a217v, gpart_a219C) = Genome.Split.split gpart_a219B
                            p_a217u = Functions.belowten' g_a217t
                            (g_a217t, gpart_a219B) = Genome.Split.split gpart_a219A
                            p_a217s = double g_a217r
                            (g_a217r, gpart_a219A) = Genome.Split.split gpart_a219z
                            p_a217q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217p
                            (g_a217p, gpart_a219z) = Genome.Split.split gpart_a219y
                            p_a217o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a217n
                            (g_a217n, gpart_a219y) = Genome.Split.split gpart_a219x
                            p_a217m = double g_a217l
                            (g_a217l, gpart_a219x) = Genome.Split.split gpart_a219w
                            p_a217k = double g_a217j
                            (g_a217j, gpart_a219w) = Genome.Split.split gpart_a219v
                            p_a217i = double g_a217h
                            (g_a217h, gpart_a219v) = Genome.Split.split gpart_a219u
                            p_a217g = double g_a217f
                            (g_a217f, gpart_a219u) = Genome.Split.split gpart_a219t
                            p_a217e = double g_a217d
                            (g_a217d, gpart_a219t) = Genome.Split.split genome_a218t
                          in
                            \ desc_a218u
                              -> case desc_a218u of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217e)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217g)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217i)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217k)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217m)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217o)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217s)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217u)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217w)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217A)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217C)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217E)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217G)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217I)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217K)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217M)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217O)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217Q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217S)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217U)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217W)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a217Y)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2180)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2182)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2184)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2186)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2188)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218a)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218c)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218e)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218g)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218i)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218k)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218m)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218o)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a218s)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a21cv
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21d9
                      p_a21cu = double g_a21ct
                      (g_a21ct, gpart_a21d9) = Genome.Split.split gpart_a21d8
                      p_a21cs = double g_a21cr
                      (g_a21cr, gpart_a21d8) = Genome.Split.split gpart_a21d7
                      p_a21cq = double g_a21cp
                      (g_a21cp, gpart_a21d7) = Genome.Split.split gpart_a21d6
                      p_a21co = double g_a21cn
                      (g_a21cn, gpart_a21d6) = Genome.Split.split gpart_a21d5
                      p_a21cm = double g_a21cl
                      (g_a21cl, gpart_a21d5) = Genome.Split.split gpart_a21d4
                      p_a21ck = double g_a21cj
                      (g_a21cj, gpart_a21d4) = Genome.Split.split gpart_a21d3
                      p_a21ci = Functions.belowten' g_a21ch
                      (g_a21ch, gpart_a21d3) = Genome.Split.split gpart_a21d2
                      p_a21cg = double g_a21cf
                      (g_a21cf, gpart_a21d2) = Genome.Split.split gpart_a21d1
                      p_a21ce = Functions.belowten' g_a21cd
                      (g_a21cd, gpart_a21d1) = Genome.Split.split gpart_a21d0
                      p_a21cc = double g_a21cb
                      (g_a21cb, gpart_a21d0) = Genome.Split.split gpart_a21cZ
                      p_a21ca = double g_a21c9
                      (g_a21c9, gpart_a21cZ) = Genome.Split.split gpart_a21cY
                      p_a21c8 = double g_a21c7
                      (g_a21c7, gpart_a21cY) = Genome.Split.split gpart_a21cX
                      p_a21c6 = Functions.belowten' g_a21c5
                      (g_a21c5, gpart_a21cX) = Genome.Split.split gpart_a21cW
                      p_a21c4 = double g_a21c3
                      (g_a21c3, gpart_a21cW) = Genome.Split.split gpart_a21cV
                      p_a21c2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c1
                      (g_a21c1, gpart_a21cV) = Genome.Split.split gpart_a21cU
                      p_a21c0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bZ
                      (g_a21bZ, gpart_a21cU) = Genome.Split.split gpart_a21cT
                      p_a21bY = Functions.belowten' g_a21bX
                      (g_a21bX, gpart_a21cT) = Genome.Split.split gpart_a21cS
                      p_a21bW = double g_a21bV
                      (g_a21bV, gpart_a21cS) = Genome.Split.split gpart_a21cR
                      p_a21bU = double g_a21bT
                      (g_a21bT, gpart_a21cR) = Genome.Split.split gpart_a21cQ
                      p_a21bS = double g_a21bR
                      (g_a21bR, gpart_a21cQ) = Genome.Split.split gpart_a21cP
                      p_a21bQ = Functions.belowten' g_a21bP
                      (g_a21bP, gpart_a21cP) = Genome.Split.split gpart_a21cO
                      p_a21bO = double g_a21bN
                      (g_a21bN, gpart_a21cO) = Genome.Split.split gpart_a21cN
                      p_a21bM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bL
                      (g_a21bL, gpart_a21cN) = Genome.Split.split gpart_a21cM
                      p_a21bK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bJ
                      (g_a21bJ, gpart_a21cM) = Genome.Split.split gpart_a21cL
                      p_a21bI = double g_a21bH
                      (g_a21bH, gpart_a21cL) = Genome.Split.split gpart_a21cK
                      p_a21bG = Functions.belowten' g_a21bF
                      (g_a21bF, gpart_a21cK) = Genome.Split.split gpart_a21cJ
                      p_a21bE = double g_a21bD
                      (g_a21bD, gpart_a21cJ) = Genome.Split.split gpart_a21cI
                      p_a21bC = Functions.belowten' g_a21bB
                      (g_a21bB, gpart_a21cI) = Genome.Split.split gpart_a21cH
                      p_a21bA = double g_a21bz
                      (g_a21bz, gpart_a21cH) = Genome.Split.split gpart_a21cG
                      p_a21by = double g_a21bx
                      (g_a21bx, gpart_a21cG) = Genome.Split.split gpart_a21cF
                      p_a21bw = Functions.belowten' g_a21bv
                      (g_a21bv, gpart_a21cF) = Genome.Split.split gpart_a21cE
                      p_a21bu = double g_a21bt
                      (g_a21bt, gpart_a21cE) = Genome.Split.split gpart_a21cD
                      p_a21bs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21br
                      (g_a21br, gpart_a21cD) = Genome.Split.split gpart_a21cC
                      p_a21bq
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bp
                      (g_a21bp, gpart_a21cC) = Genome.Split.split gpart_a21cB
                      p_a21bo = double g_a21bn
                      (g_a21bn, gpart_a21cB) = Genome.Split.split gpart_a21cA
                      p_a21bm = double g_a21bl
                      (g_a21bl, gpart_a21cA) = Genome.Split.split gpart_a21cz
                      p_a21bk = double g_a21bj
                      (g_a21bj, gpart_a21cz) = Genome.Split.split gpart_a21cy
                      p_a21bi = double g_a21bh
                      (g_a21bh, gpart_a21cy) = Genome.Split.split gpart_a21cx
                      p_a21bg = double g_a21bf
                      (g_a21bf, gpart_a21cx) = Genome.Split.split genome_a21cv
                    in  \ x_a21da
                          -> let
                               c_PTB_a21dd
                                 = ((Data.Fixed.Vector.toVector x_a21da) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21db
                                 = ((Data.Fixed.Vector.toVector x_a21da) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21dh
                                 = ((Data.Fixed.Vector.toVector x_a21da) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21di
                                 = ((Data.Fixed.Vector.toVector x_a21da) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21du
                                 = ((Data.Fixed.Vector.toVector x_a21da) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21bo / (1 + ((c_MiRs_a21db / p_a21bu) ** p_a21bw)))
                                    + (negate (p_a21cm * c_PTB_a21dd))),
                                   ((p_a21by
                                     / (1
                                        + (((c_MiRs_a21db / p_a21bA) ** p_a21bC)
                                           + ((c_PTB_a21dd / p_a21bE) ** p_a21bG))))
                                    + (negate (p_a21co * c_NPTB_a21dh))),
                                   ((p_a21bI
                                     * (p_a21bS
                                        / ((1 + p_a21bS) + ((c_RESTc_a21di / p_a21bO) ** p_a21bQ))))
                                    + (negate (p_a21cq * c_MiRs_a21db))),
                                   ((p_a21bU
                                     * ((p_a21c8 + ((c_PTB_a21dd / p_a21bW) ** p_a21bY))
                                        / (((1 + p_a21c8) + ((c_PTB_a21dd / p_a21bW) ** p_a21bY))
                                           + (((p_a21bg / p_a21c0) ** p_a21c2)
                                              + ((c_MiRs_a21db / p_a21c4) ** p_a21c6)))))
                                    + (negate (p_a21cs * c_RESTc_a21di))),
                                   ((p_a21ca
                                     * ((p_a21ck + ((c_MiRs_a21db / p_a21cc) ** p_a21ce))
                                        / (((1 + p_a21ck) + ((c_MiRs_a21db / p_a21cc) ** p_a21ce))
                                           + ((c_RESTc_a21di / p_a21cg) ** p_a21ci))))
                                    + (negate (p_a21cu * c_EndoNeuroTFs_a21du)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490991",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490992",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490993",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490994",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490995",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490996",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490997",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679490998",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679490999",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491000",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491001",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491002",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491003",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491004",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491005",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491006",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491007",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491008",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491009",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491010",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491011",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491012",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491013",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491014",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491015",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491016",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491017",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491018",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491019",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491020",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491021",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491022",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491023",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491024",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491025",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491026",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491027",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491028",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491029",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491030",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491031",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491032",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491033",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491034",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491035",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491036",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491037",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491038",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491039",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491040",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491052",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491054",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21cv
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21e7
                            p_a21cu = double g_a21ct
                            (g_a21ct, gpart_a21e7) = Genome.Split.split gpart_a21e6
                            p_a21cs = double g_a21cr
                            (g_a21cr, gpart_a21e6) = Genome.Split.split gpart_a21e5
                            p_a21cq = double g_a21cp
                            (g_a21cp, gpart_a21e5) = Genome.Split.split gpart_a21e4
                            p_a21co = double g_a21cn
                            (g_a21cn, gpart_a21e4) = Genome.Split.split gpart_a21e3
                            p_a21cm = double g_a21cl
                            (g_a21cl, gpart_a21e3) = Genome.Split.split gpart_a21e2
                            p_a21ck = double g_a21cj
                            (g_a21cj, gpart_a21e2) = Genome.Split.split gpart_a21e1
                            p_a21ci = Functions.belowten' g_a21ch
                            (g_a21ch, gpart_a21e1) = Genome.Split.split gpart_a21e0
                            p_a21cg = double g_a21cf
                            (g_a21cf, gpart_a21e0) = Genome.Split.split gpart_a21dZ
                            p_a21ce = Functions.belowten' g_a21cd
                            (g_a21cd, gpart_a21dZ) = Genome.Split.split gpart_a21dY
                            p_a21cc = double g_a21cb
                            (g_a21cb, gpart_a21dY) = Genome.Split.split gpart_a21dX
                            p_a21ca = double g_a21c9
                            (g_a21c9, gpart_a21dX) = Genome.Split.split gpart_a21dW
                            p_a21c8 = double g_a21c7
                            (g_a21c7, gpart_a21dW) = Genome.Split.split gpart_a21dV
                            p_a21c6 = Functions.belowten' g_a21c5
                            (g_a21c5, gpart_a21dV) = Genome.Split.split gpart_a21dU
                            p_a21c4 = double g_a21c3
                            (g_a21c3, gpart_a21dU) = Genome.Split.split gpart_a21dT
                            p_a21c2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21c1
                            (g_a21c1, gpart_a21dT) = Genome.Split.split gpart_a21dS
                            p_a21c0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bZ
                            (g_a21bZ, gpart_a21dS) = Genome.Split.split gpart_a21dR
                            p_a21bY = Functions.belowten' g_a21bX
                            (g_a21bX, gpart_a21dR) = Genome.Split.split gpart_a21dQ
                            p_a21bW = double g_a21bV
                            (g_a21bV, gpart_a21dQ) = Genome.Split.split gpart_a21dP
                            p_a21bU = double g_a21bT
                            (g_a21bT, gpart_a21dP) = Genome.Split.split gpart_a21dO
                            p_a21bS = double g_a21bR
                            (g_a21bR, gpart_a21dO) = Genome.Split.split gpart_a21dN
                            p_a21bQ = Functions.belowten' g_a21bP
                            (g_a21bP, gpart_a21dN) = Genome.Split.split gpart_a21dM
                            p_a21bO = double g_a21bN
                            (g_a21bN, gpart_a21dM) = Genome.Split.split gpart_a21dL
                            p_a21bM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bL
                            (g_a21bL, gpart_a21dL) = Genome.Split.split gpart_a21dK
                            p_a21bK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bJ
                            (g_a21bJ, gpart_a21dK) = Genome.Split.split gpart_a21dJ
                            p_a21bI = double g_a21bH
                            (g_a21bH, gpart_a21dJ) = Genome.Split.split gpart_a21dI
                            p_a21bG = Functions.belowten' g_a21bF
                            (g_a21bF, gpart_a21dI) = Genome.Split.split gpart_a21dH
                            p_a21bE = double g_a21bD
                            (g_a21bD, gpart_a21dH) = Genome.Split.split gpart_a21dG
                            p_a21bC = Functions.belowten' g_a21bB
                            (g_a21bB, gpart_a21dG) = Genome.Split.split gpart_a21dF
                            p_a21bA = double g_a21bz
                            (g_a21bz, gpart_a21dF) = Genome.Split.split gpart_a21dE
                            p_a21by = double g_a21bx
                            (g_a21bx, gpart_a21dE) = Genome.Split.split gpart_a21dD
                            p_a21bw = Functions.belowten' g_a21bv
                            (g_a21bv, gpart_a21dD) = Genome.Split.split gpart_a21dC
                            p_a21bu = double g_a21bt
                            (g_a21bt, gpart_a21dC) = Genome.Split.split gpart_a21dB
                            p_a21bs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21br
                            (g_a21br, gpart_a21dB) = Genome.Split.split gpart_a21dA
                            p_a21bq
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21bp
                            (g_a21bp, gpart_a21dA) = Genome.Split.split gpart_a21dz
                            p_a21bo = double g_a21bn
                            (g_a21bn, gpart_a21dz) = Genome.Split.split gpart_a21dy
                            p_a21bm = double g_a21bl
                            (g_a21bl, gpart_a21dy) = Genome.Split.split gpart_a21dx
                            p_a21bk = double g_a21bj
                            (g_a21bj, gpart_a21dx) = Genome.Split.split gpart_a21dw
                            p_a21bi = double g_a21bh
                            (g_a21bh, gpart_a21dw) = Genome.Split.split gpart_a21dv
                            p_a21bg = double g_a21bf
                            (g_a21bf, gpart_a21dv) = Genome.Split.split genome_a21cv
                          in
                            \ desc_a21cw
                              -> case desc_a21cw of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bg)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bi)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bk)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bm)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bo)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bq)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bs)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bu)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bw)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21by)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bA)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bC)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bE)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bG)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bI)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bK)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bM)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bO)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bQ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bS)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bU)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bW)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21bY)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c0)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c2)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c4)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c6)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21c8)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ca)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cc)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ce)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cg)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ci)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ck)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cm)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21co)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cq)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cs)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21cu)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a21gx
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21hb
                      p_a21gw = double g_a21gv
                      (g_a21gv, gpart_a21hb) = Genome.Split.split gpart_a21ha
                      p_a21gu = double g_a21gt
                      (g_a21gt, gpart_a21ha) = Genome.Split.split gpart_a21h9
                      p_a21gs = double g_a21gr
                      (g_a21gr, gpart_a21h9) = Genome.Split.split gpart_a21h8
                      p_a21gq = double g_a21gp
                      (g_a21gp, gpart_a21h8) = Genome.Split.split gpart_a21h7
                      p_a21go = double g_a21gn
                      (g_a21gn, gpart_a21h7) = Genome.Split.split gpart_a21h6
                      p_a21gm = double g_a21gl
                      (g_a21gl, gpart_a21h6) = Genome.Split.split gpart_a21h5
                      p_a21gk = Functions.belowten' g_a21gj
                      (g_a21gj, gpart_a21h5) = Genome.Split.split gpart_a21h4
                      p_a21gi = double g_a21gh
                      (g_a21gh, gpart_a21h4) = Genome.Split.split gpart_a21h3
                      p_a21gg = Functions.belowten' g_a21gf
                      (g_a21gf, gpart_a21h3) = Genome.Split.split gpart_a21h2
                      p_a21ge = double g_a21gd
                      (g_a21gd, gpart_a21h2) = Genome.Split.split gpart_a21h1
                      p_a21gc = double g_a21gb
                      (g_a21gb, gpart_a21h1) = Genome.Split.split gpart_a21h0
                      p_a21ga = double g_a21g9
                      (g_a21g9, gpart_a21h0) = Genome.Split.split gpart_a21gZ
                      p_a21g8 = Functions.belowten' g_a21g7
                      (g_a21g7, gpart_a21gZ) = Genome.Split.split gpart_a21gY
                      p_a21g6 = double g_a21g5
                      (g_a21g5, gpart_a21gY) = Genome.Split.split gpart_a21gX
                      p_a21g4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21g3
                      (g_a21g3, gpart_a21gX) = Genome.Split.split gpart_a21gW
                      p_a21g2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21g1
                      (g_a21g1, gpart_a21gW) = Genome.Split.split gpart_a21gV
                      p_a21g0 = Functions.belowten' g_a21fZ
                      (g_a21fZ, gpart_a21gV) = Genome.Split.split gpart_a21gU
                      p_a21fY = double g_a21fX
                      (g_a21fX, gpart_a21gU) = Genome.Split.split gpart_a21gT
                      p_a21fW = double g_a21fV
                      (g_a21fV, gpart_a21gT) = Genome.Split.split gpart_a21gS
                      p_a21fU = double g_a21fT
                      (g_a21fT, gpart_a21gS) = Genome.Split.split gpart_a21gR
                      p_a21fS = Functions.belowten' g_a21fR
                      (g_a21fR, gpart_a21gR) = Genome.Split.split gpart_a21gQ
                      p_a21fQ = double g_a21fP
                      (g_a21fP, gpart_a21gQ) = Genome.Split.split gpart_a21gP
                      p_a21fO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fN
                      (g_a21fN, gpart_a21gP) = Genome.Split.split gpart_a21gO
                      p_a21fM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fL
                      (g_a21fL, gpart_a21gO) = Genome.Split.split gpart_a21gN
                      p_a21fK = double g_a21fJ
                      (g_a21fJ, gpart_a21gN) = Genome.Split.split gpart_a21gM
                      p_a21fI = Functions.belowten' g_a21fH
                      (g_a21fH, gpart_a21gM) = Genome.Split.split gpart_a21gL
                      p_a21fG = double g_a21fF
                      (g_a21fF, gpart_a21gL) = Genome.Split.split gpart_a21gK
                      p_a21fE = Functions.belowten' g_a21fD
                      (g_a21fD, gpart_a21gK) = Genome.Split.split gpart_a21gJ
                      p_a21fC = double g_a21fB
                      (g_a21fB, gpart_a21gJ) = Genome.Split.split gpart_a21gI
                      p_a21fA = double g_a21fz
                      (g_a21fz, gpart_a21gI) = Genome.Split.split gpart_a21gH
                      p_a21fy = Functions.belowten' g_a21fx
                      (g_a21fx, gpart_a21gH) = Genome.Split.split gpart_a21gG
                      p_a21fw = double g_a21fv
                      (g_a21fv, gpart_a21gG) = Genome.Split.split gpart_a21gF
                      p_a21fu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21ft
                      (g_a21ft, gpart_a21gF) = Genome.Split.split gpart_a21gE
                      p_a21fs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fr
                      (g_a21fr, gpart_a21gE) = Genome.Split.split gpart_a21gD
                      p_a21fq = double g_a21fp
                      (g_a21fp, gpart_a21gD) = Genome.Split.split gpart_a21gC
                      p_a21fo = double g_a21fn
                      (g_a21fn, gpart_a21gC) = Genome.Split.split gpart_a21gB
                      p_a21fm = double g_a21fl
                      (g_a21fl, gpart_a21gB) = Genome.Split.split gpart_a21gA
                      p_a21fk = double g_a21fj
                      (g_a21fj, gpart_a21gA) = Genome.Split.split gpart_a21gz
                      p_a21fi = double g_a21fh
                      (g_a21fh, gpart_a21gz) = Genome.Split.split genome_a21gx
                    in  \ x_a21hc
                          -> let
                               c_PTB_a21hf
                                 = ((Data.Fixed.Vector.toVector x_a21hc) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21hd
                                 = ((Data.Fixed.Vector.toVector x_a21hc) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21hj
                                 = ((Data.Fixed.Vector.toVector x_a21hc) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21hk
                                 = ((Data.Fixed.Vector.toVector x_a21hc) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21hw
                                 = ((Data.Fixed.Vector.toVector x_a21hc) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21fq / (1 + ((c_MiRs_a21hd / p_a21fw) ** p_a21fy)))
                                    + (negate (p_a21go * c_PTB_a21hf))),
                                   ((p_a21fA
                                     / (1
                                        + (((c_MiRs_a21hd / p_a21fC) ** p_a21fE)
                                           + ((c_PTB_a21hf / p_a21fG) ** p_a21fI))))
                                    + (negate (p_a21gq * c_NPTB_a21hj))),
                                   ((p_a21fK
                                     * (p_a21fU
                                        / ((1 + p_a21fU) + ((c_RESTc_a21hk / p_a21fQ) ** p_a21fS))))
                                    + (negate (p_a21gs * c_MiRs_a21hd))),
                                   ((p_a21fW
                                     * ((p_a21ga + ((c_PTB_a21hf / p_a21fY) ** p_a21g0))
                                        / (((1 + p_a21ga) + ((c_PTB_a21hf / p_a21fY) ** p_a21g0))
                                           + ((c_MiRs_a21hd / p_a21g6) ** p_a21g8))))
                                    + (negate (p_a21gu * c_RESTc_a21hk))),
                                   ((p_a21gc
                                     * ((p_a21gm + ((c_MiRs_a21hd / p_a21ge) ** p_a21gg))
                                        / (((1 + p_a21gm) + ((c_MiRs_a21hd / p_a21ge) ** p_a21gg))
                                           + ((c_RESTc_a21hk / p_a21gi) ** p_a21gk))))
                                    + (negate (p_a21gw * c_EndoNeuroTFs_a21hw)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491250",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491251",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491252",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491253",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491254",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491255",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491256",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491257",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491258",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491259",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491260",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491261",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491262",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491263",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491264",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491265",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491266",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491267",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491268",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491269",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491270",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491271",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491272",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491273",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491274",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491275",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491276",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491277",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491278",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491279",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491280",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491281",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491282",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491283",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491284",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491285",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491286",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491287",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491288",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491289",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491290",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491291",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491292",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491293",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491294",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491295",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491296",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491297",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491298",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491299",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491300",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491301",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491302",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491303",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491304",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491305",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491306",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491307",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491308",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491309",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491310",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491311",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491312",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491313",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491314",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491315",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491316",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21gx
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21i9
                            p_a21gw = double g_a21gv
                            (g_a21gv, gpart_a21i9) = Genome.Split.split gpart_a21i8
                            p_a21gu = double g_a21gt
                            (g_a21gt, gpart_a21i8) = Genome.Split.split gpart_a21i7
                            p_a21gs = double g_a21gr
                            (g_a21gr, gpart_a21i7) = Genome.Split.split gpart_a21i6
                            p_a21gq = double g_a21gp
                            (g_a21gp, gpart_a21i6) = Genome.Split.split gpart_a21i5
                            p_a21go = double g_a21gn
                            (g_a21gn, gpart_a21i5) = Genome.Split.split gpart_a21i4
                            p_a21gm = double g_a21gl
                            (g_a21gl, gpart_a21i4) = Genome.Split.split gpart_a21i3
                            p_a21gk = Functions.belowten' g_a21gj
                            (g_a21gj, gpart_a21i3) = Genome.Split.split gpart_a21i2
                            p_a21gi = double g_a21gh
                            (g_a21gh, gpart_a21i2) = Genome.Split.split gpart_a21i1
                            p_a21gg = Functions.belowten' g_a21gf
                            (g_a21gf, gpart_a21i1) = Genome.Split.split gpart_a21i0
                            p_a21ge = double g_a21gd
                            (g_a21gd, gpart_a21i0) = Genome.Split.split gpart_a21hZ
                            p_a21gc = double g_a21gb
                            (g_a21gb, gpart_a21hZ) = Genome.Split.split gpart_a21hY
                            p_a21ga = double g_a21g9
                            (g_a21g9, gpart_a21hY) = Genome.Split.split gpart_a21hX
                            p_a21g8 = Functions.belowten' g_a21g7
                            (g_a21g7, gpart_a21hX) = Genome.Split.split gpart_a21hW
                            p_a21g6 = double g_a21g5
                            (g_a21g5, gpart_a21hW) = Genome.Split.split gpart_a21hV
                            p_a21g4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21g3
                            (g_a21g3, gpart_a21hV) = Genome.Split.split gpart_a21hU
                            p_a21g2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21g1
                            (g_a21g1, gpart_a21hU) = Genome.Split.split gpart_a21hT
                            p_a21g0 = Functions.belowten' g_a21fZ
                            (g_a21fZ, gpart_a21hT) = Genome.Split.split gpart_a21hS
                            p_a21fY = double g_a21fX
                            (g_a21fX, gpart_a21hS) = Genome.Split.split gpart_a21hR
                            p_a21fW = double g_a21fV
                            (g_a21fV, gpart_a21hR) = Genome.Split.split gpart_a21hQ
                            p_a21fU = double g_a21fT
                            (g_a21fT, gpart_a21hQ) = Genome.Split.split gpart_a21hP
                            p_a21fS = Functions.belowten' g_a21fR
                            (g_a21fR, gpart_a21hP) = Genome.Split.split gpart_a21hO
                            p_a21fQ = double g_a21fP
                            (g_a21fP, gpart_a21hO) = Genome.Split.split gpart_a21hN
                            p_a21fO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fN
                            (g_a21fN, gpart_a21hN) = Genome.Split.split gpart_a21hM
                            p_a21fM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fL
                            (g_a21fL, gpart_a21hM) = Genome.Split.split gpart_a21hL
                            p_a21fK = double g_a21fJ
                            (g_a21fJ, gpart_a21hL) = Genome.Split.split gpart_a21hK
                            p_a21fI = Functions.belowten' g_a21fH
                            (g_a21fH, gpart_a21hK) = Genome.Split.split gpart_a21hJ
                            p_a21fG = double g_a21fF
                            (g_a21fF, gpart_a21hJ) = Genome.Split.split gpart_a21hI
                            p_a21fE = Functions.belowten' g_a21fD
                            (g_a21fD, gpart_a21hI) = Genome.Split.split gpart_a21hH
                            p_a21fC = double g_a21fB
                            (g_a21fB, gpart_a21hH) = Genome.Split.split gpart_a21hG
                            p_a21fA = double g_a21fz
                            (g_a21fz, gpart_a21hG) = Genome.Split.split gpart_a21hF
                            p_a21fy = Functions.belowten' g_a21fx
                            (g_a21fx, gpart_a21hF) = Genome.Split.split gpart_a21hE
                            p_a21fw = double g_a21fv
                            (g_a21fv, gpart_a21hE) = Genome.Split.split gpart_a21hD
                            p_a21fu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21ft
                            (g_a21ft, gpart_a21hD) = Genome.Split.split gpart_a21hC
                            p_a21fs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21fr
                            (g_a21fr, gpart_a21hC) = Genome.Split.split gpart_a21hB
                            p_a21fq = double g_a21fp
                            (g_a21fp, gpart_a21hB) = Genome.Split.split gpart_a21hA
                            p_a21fo = double g_a21fn
                            (g_a21fn, gpart_a21hA) = Genome.Split.split gpart_a21hz
                            p_a21fm = double g_a21fl
                            (g_a21fl, gpart_a21hz) = Genome.Split.split gpart_a21hy
                            p_a21fk = double g_a21fj
                            (g_a21fj, gpart_a21hy) = Genome.Split.split gpart_a21hx
                            p_a21fi = double g_a21fh
                            (g_a21fh, gpart_a21hx) = Genome.Split.split genome_a21gx
                          in
                            \ desc_a21gy
                              -> case desc_a21gy of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fi)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fk)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fm)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fo)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fq)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fs)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fu)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fw)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fy)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fA)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fC)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fE)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fG)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fI)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fK)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fM)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fO)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fQ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fS)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fU)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fW)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21fY)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g0)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g2)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g4)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g6)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21g8)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ga)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gc)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ge)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gg)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gi)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gk)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gm)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21go)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gq)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gs)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gu)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21gw)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a21kz
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21ld
                      p_a21ky = double g_a21kx
                      (g_a21kx, gpart_a21ld) = Genome.Split.split gpart_a21lc
                      p_a21kw = double g_a21kv
                      (g_a21kv, gpart_a21lc) = Genome.Split.split gpart_a21lb
                      p_a21ku = double g_a21kt
                      (g_a21kt, gpart_a21lb) = Genome.Split.split gpart_a21la
                      p_a21ks = double g_a21kr
                      (g_a21kr, gpart_a21la) = Genome.Split.split gpart_a21l9
                      p_a21kq = double g_a21kp
                      (g_a21kp, gpart_a21l9) = Genome.Split.split gpart_a21l8
                      p_a21ko = double g_a21kn
                      (g_a21kn, gpart_a21l8) = Genome.Split.split gpart_a21l7
                      p_a21km = Functions.belowten' g_a21kl
                      (g_a21kl, gpart_a21l7) = Genome.Split.split gpart_a21l6
                      p_a21kk = double g_a21kj
                      (g_a21kj, gpart_a21l6) = Genome.Split.split gpart_a21l5
                      p_a21ki = Functions.belowten' g_a21kh
                      (g_a21kh, gpart_a21l5) = Genome.Split.split gpart_a21l4
                      p_a21kg = double g_a21kf
                      (g_a21kf, gpart_a21l4) = Genome.Split.split gpart_a21l3
                      p_a21ke = double g_a21kd
                      (g_a21kd, gpart_a21l3) = Genome.Split.split gpart_a21l2
                      p_a21kc = double g_a21kb
                      (g_a21kb, gpart_a21l2) = Genome.Split.split gpart_a21l1
                      p_a21ka = Functions.belowten' g_a21k9
                      (g_a21k9, gpart_a21l1) = Genome.Split.split gpart_a21l0
                      p_a21k8 = double g_a21k7
                      (g_a21k7, gpart_a21l0) = Genome.Split.split gpart_a21kZ
                      p_a21k6
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21k5
                      (g_a21k5, gpart_a21kZ) = Genome.Split.split gpart_a21kY
                      p_a21k4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21k3
                      (g_a21k3, gpart_a21kY) = Genome.Split.split gpart_a21kX
                      p_a21k2 = Functions.belowten' g_a21k1
                      (g_a21k1, gpart_a21kX) = Genome.Split.split gpart_a21kW
                      p_a21k0 = double g_a21jZ
                      (g_a21jZ, gpart_a21kW) = Genome.Split.split gpart_a21kV
                      p_a21jY = double g_a21jX
                      (g_a21jX, gpart_a21kV) = Genome.Split.split gpart_a21kU
                      p_a21jW = double g_a21jV
                      (g_a21jV, gpart_a21kU) = Genome.Split.split gpart_a21kT
                      p_a21jU = Functions.belowten' g_a21jT
                      (g_a21jT, gpart_a21kT) = Genome.Split.split gpart_a21kS
                      p_a21jS = double g_a21jR
                      (g_a21jR, gpart_a21kS) = Genome.Split.split gpart_a21kR
                      p_a21jQ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jP
                      (g_a21jP, gpart_a21kR) = Genome.Split.split gpart_a21kQ
                      p_a21jO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jN
                      (g_a21jN, gpart_a21kQ) = Genome.Split.split gpart_a21kP
                      p_a21jM = double g_a21jL
                      (g_a21jL, gpart_a21kP) = Genome.Split.split gpart_a21kO
                      p_a21jK = Functions.belowten' g_a21jJ
                      (g_a21jJ, gpart_a21kO) = Genome.Split.split gpart_a21kN
                      p_a21jI = double g_a21jH
                      (g_a21jH, gpart_a21kN) = Genome.Split.split gpart_a21kM
                      p_a21jG = Functions.belowten' g_a21jF
                      (g_a21jF, gpart_a21kM) = Genome.Split.split gpart_a21kL
                      p_a21jE = double g_a21jD
                      (g_a21jD, gpart_a21kL) = Genome.Split.split gpart_a21kK
                      p_a21jC = double g_a21jB
                      (g_a21jB, gpart_a21kK) = Genome.Split.split gpart_a21kJ
                      p_a21jA = Functions.belowten' g_a21jz
                      (g_a21jz, gpart_a21kJ) = Genome.Split.split gpart_a21kI
                      p_a21jy = double g_a21jx
                      (g_a21jx, gpart_a21kI) = Genome.Split.split gpart_a21kH
                      p_a21jw
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jv
                      (g_a21jv, gpart_a21kH) = Genome.Split.split gpart_a21kG
                      p_a21ju
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jt
                      (g_a21jt, gpart_a21kG) = Genome.Split.split gpart_a21kF
                      p_a21js = double g_a21jr
                      (g_a21jr, gpart_a21kF) = Genome.Split.split gpart_a21kE
                      p_a21jq = double g_a21jp
                      (g_a21jp, gpart_a21kE) = Genome.Split.split gpart_a21kD
                      p_a21jo = double g_a21jn
                      (g_a21jn, gpart_a21kD) = Genome.Split.split gpart_a21kC
                      p_a21jm = double g_a21jl
                      (g_a21jl, gpart_a21kC) = Genome.Split.split gpart_a21kB
                      p_a21jk = double g_a21jj
                      (g_a21jj, gpart_a21kB) = Genome.Split.split genome_a21kz
                    in  \ x_a21le
                          -> let
                               c_PTB_a21lh
                                 = ((Data.Fixed.Vector.toVector x_a21le) Data.Vector.Unboxed.! 0)
                               c_MiRs_a21lf
                                 = ((Data.Fixed.Vector.toVector x_a21le) Data.Vector.Unboxed.! 2)
                               c_NPTB_a21ll
                                 = ((Data.Fixed.Vector.toVector x_a21le) Data.Vector.Unboxed.! 1)
                               c_RESTc_a21lm
                                 = ((Data.Fixed.Vector.toVector x_a21le) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a21ly
                                 = ((Data.Fixed.Vector.toVector x_a21le) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a21js
                                     / (1
                                        + (((p_a21jk / p_a21ju) ** p_a21jw)
                                           + ((c_MiRs_a21lf / p_a21jy) ** p_a21jA))))
                                    + (negate (p_a21kq * c_PTB_a21lh))),
                                   ((p_a21jC
                                     / (1
                                        + (((c_MiRs_a21lf / p_a21jE) ** p_a21jG)
                                           + ((c_PTB_a21lh / p_a21jI) ** p_a21jK))))
                                    + (negate (p_a21ks * c_NPTB_a21ll))),
                                   ((p_a21jM
                                     * (p_a21jW
                                        / ((1 + p_a21jW) + ((c_RESTc_a21lm / p_a21jS) ** p_a21jU))))
                                    + (negate (p_a21ku * c_MiRs_a21lf))),
                                   ((p_a21jY
                                     * ((p_a21kc + ((c_PTB_a21lh / p_a21k0) ** p_a21k2))
                                        / (((1 + p_a21kc) + ((c_PTB_a21lh / p_a21k0) ** p_a21k2))
                                           + ((c_MiRs_a21lf / p_a21k8) ** p_a21ka))))
                                    + (negate (p_a21kw * c_RESTc_a21lm))),
                                   ((p_a21ke
                                     * ((p_a21ko + ((c_MiRs_a21lf / p_a21kg) ** p_a21ki))
                                        / (((1 + p_a21ko) + ((c_MiRs_a21lf / p_a21kg) ** p_a21ki))
                                           + ((c_RESTc_a21lm / p_a21kk) ** p_a21km))))
                                    + (negate (p_a21ky * c_EndoNeuroTFs_a21ly)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491500",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491502",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491511",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491512",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491513",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491514",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491515",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491516",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491517",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491518",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491519",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491520",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491521",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491522",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491523",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491524",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491525",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491526",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491527",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491528",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491529",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491530",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491531",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491532",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491533",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491534",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491535",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491536",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491537",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491538",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491539",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491540",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491541",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491542",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491543",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491544",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491545",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491546",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491547",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491548",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491549",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491550",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679491565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679491566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a21kz
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a21mb
                            p_a21ky = double g_a21kx
                            (g_a21kx, gpart_a21mb) = Genome.Split.split gpart_a21ma
                            p_a21kw = double g_a21kv
                            (g_a21kv, gpart_a21ma) = Genome.Split.split gpart_a21m9
                            p_a21ku = double g_a21kt
                            (g_a21kt, gpart_a21m9) = Genome.Split.split gpart_a21m8
                            p_a21ks = double g_a21kr
                            (g_a21kr, gpart_a21m8) = Genome.Split.split gpart_a21m7
                            p_a21kq = double g_a21kp
                            (g_a21kp, gpart_a21m7) = Genome.Split.split gpart_a21m6
                            p_a21ko = double g_a21kn
                            (g_a21kn, gpart_a21m6) = Genome.Split.split gpart_a21m5
                            p_a21km = Functions.belowten' g_a21kl
                            (g_a21kl, gpart_a21m5) = Genome.Split.split gpart_a21m4
                            p_a21kk = double g_a21kj
                            (g_a21kj, gpart_a21m4) = Genome.Split.split gpart_a21m3
                            p_a21ki = Functions.belowten' g_a21kh
                            (g_a21kh, gpart_a21m3) = Genome.Split.split gpart_a21m2
                            p_a21kg = double g_a21kf
                            (g_a21kf, gpart_a21m2) = Genome.Split.split gpart_a21m1
                            p_a21ke = double g_a21kd
                            (g_a21kd, gpart_a21m1) = Genome.Split.split gpart_a21m0
                            p_a21kc = double g_a21kb
                            (g_a21kb, gpart_a21m0) = Genome.Split.split gpart_a21lZ
                            p_a21ka = Functions.belowten' g_a21k9
                            (g_a21k9, gpart_a21lZ) = Genome.Split.split gpart_a21lY
                            p_a21k8 = double g_a21k7
                            (g_a21k7, gpart_a21lY) = Genome.Split.split gpart_a21lX
                            p_a21k6
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21k5
                            (g_a21k5, gpart_a21lX) = Genome.Split.split gpart_a21lW
                            p_a21k4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21k3
                            (g_a21k3, gpart_a21lW) = Genome.Split.split gpart_a21lV
                            p_a21k2 = Functions.belowten' g_a21k1
                            (g_a21k1, gpart_a21lV) = Genome.Split.split gpart_a21lU
                            p_a21k0 = double g_a21jZ
                            (g_a21jZ, gpart_a21lU) = Genome.Split.split gpart_a21lT
                            p_a21jY = double g_a21jX
                            (g_a21jX, gpart_a21lT) = Genome.Split.split gpart_a21lS
                            p_a21jW = double g_a21jV
                            (g_a21jV, gpart_a21lS) = Genome.Split.split gpart_a21lR
                            p_a21jU = Functions.belowten' g_a21jT
                            (g_a21jT, gpart_a21lR) = Genome.Split.split gpart_a21lQ
                            p_a21jS = double g_a21jR
                            (g_a21jR, gpart_a21lQ) = Genome.Split.split gpart_a21lP
                            p_a21jQ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jP
                            (g_a21jP, gpart_a21lP) = Genome.Split.split gpart_a21lO
                            p_a21jO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jN
                            (g_a21jN, gpart_a21lO) = Genome.Split.split gpart_a21lN
                            p_a21jM = double g_a21jL
                            (g_a21jL, gpart_a21lN) = Genome.Split.split gpart_a21lM
                            p_a21jK = Functions.belowten' g_a21jJ
                            (g_a21jJ, gpart_a21lM) = Genome.Split.split gpart_a21lL
                            p_a21jI = double g_a21jH
                            (g_a21jH, gpart_a21lL) = Genome.Split.split gpart_a21lK
                            p_a21jG = Functions.belowten' g_a21jF
                            (g_a21jF, gpart_a21lK) = Genome.Split.split gpart_a21lJ
                            p_a21jE = double g_a21jD
                            (g_a21jD, gpart_a21lJ) = Genome.Split.split gpart_a21lI
                            p_a21jC = double g_a21jB
                            (g_a21jB, gpart_a21lI) = Genome.Split.split gpart_a21lH
                            p_a21jA = Functions.belowten' g_a21jz
                            (g_a21jz, gpart_a21lH) = Genome.Split.split gpart_a21lG
                            p_a21jy = double g_a21jx
                            (g_a21jx, gpart_a21lG) = Genome.Split.split gpart_a21lF
                            p_a21jw
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jv
                            (g_a21jv, gpart_a21lF) = Genome.Split.split gpart_a21lE
                            p_a21ju
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a21jt
                            (g_a21jt, gpart_a21lE) = Genome.Split.split gpart_a21lD
                            p_a21js = double g_a21jr
                            (g_a21jr, gpart_a21lD) = Genome.Split.split gpart_a21lC
                            p_a21jq = double g_a21jp
                            (g_a21jp, gpart_a21lC) = Genome.Split.split gpart_a21lB
                            p_a21jo = double g_a21jn
                            (g_a21jn, gpart_a21lB) = Genome.Split.split gpart_a21lA
                            p_a21jm = double g_a21jl
                            (g_a21jl, gpart_a21lA) = Genome.Split.split gpart_a21lz
                            p_a21jk = double g_a21jj
                            (g_a21jj, gpart_a21lz) = Genome.Split.split genome_a21kz
                          in
                            \ desc_a21kA
                              -> case desc_a21kA of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jk)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jm)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jo)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jq)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21js)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ju)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jw)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jy)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jA)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jC)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jE)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jG)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jI)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jK)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jM)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jO)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jQ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jS)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jU)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jW)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21jY)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21k0)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21k2)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21k4)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21k6)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21k8)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ka)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21kc)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ke)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21kg)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ki)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21kk)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21km)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ko)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21kq)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ks)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ku)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21kw)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a21ky)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVM
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                      (g_asUY, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                      (g_asUW, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUV = Functions.belowten' g_asUU
                      (g_asUU, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUR = Functions.belowten' g_asUQ
                      (g_asUQ, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                      (g_asUO, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                      (g_asUM, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                      (g_asUK, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUJ = Functions.belowten' g_asUI
                      (g_asUI, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                      (g_asUG, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                      (g_asUE, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUC
                      (g_asUC, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUB = Functions.belowten' g_asUA
                      (g_asUA, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUt = Functions.belowten' g_asUs
                      (g_asUs, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                      (g_asUq, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                      (g_asUo, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                      (g_asUk, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUj = Functions.belowten' g_asUi
                      (g_asUi, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUf = Functions.belowten' g_asUe
                      (g_asUe, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asU9 = Functions.belowten' g_asU8
                      (g_asU8, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                      (g_asU6, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asU5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                      (g_asU4, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asU3
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                      (g_asU2, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                      (g_asU0, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                      (g_asTY, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                      (g_asTS, gpart_asVa) = Genome.Split.split genome_asV8
                    in
                      [Reaction
                         (\ x_asVN
                            -> let c_MiRs_asVO = ((toVector x_asVN) Data.Vector.Unboxed.! 2)
                               in (p_asU1 / (1 + ((c_MiRs_asVO / p_asU7) ** p_asU9))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVP
                            -> let
                                 c_MiRs_asVQ = ((toVector x_asVP) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVR = ((toVector x_asVP) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUb
                                  / (1
                                     + (((c_MiRs_asVQ / p_asUd) ** p_asUf)
                                        + ((c_PTB_asVR / p_asUh) ** p_asUj)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVS
                            -> let c_RESTc_asVT = ((toVector x_asVS) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUl
                                  * ((p_asUv + ((p_asTX / p_asUn) ** p_asUp))
                                     / (((1 + p_asUv) + ((p_asTX / p_asUn) ** p_asUp))
                                        + ((c_RESTc_asVT / p_asUr) ** p_asUt)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVU
                            -> let
                                 c_MiRs_asVX = ((toVector x_asVU) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVV = ((toVector x_asVU) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUx
                                  * ((p_asUL + ((c_PTB_asVV / p_asUz) ** p_asUB))
                                     / (((1 + p_asUL) + ((c_PTB_asVV / p_asUz) ** p_asUB))
                                        + (((p_asTT / p_asUD) ** p_asUF)
                                           + ((c_MiRs_asVX / p_asUH) ** p_asUJ))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVY
                            -> let
                                 c_RESTc_asW1 = ((toVector x_asVY) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asVZ = ((toVector x_asVY) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asUN
                                  * ((p_asUX + ((c_MiRs_asVZ / p_asUP) ** p_asUR))
                                     / (((1 + p_asUX) + ((c_MiRs_asVZ / p_asUP) ** p_asUR))
                                        + ((c_RESTc_asW1 / p_asUT) ** p_asUV)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW2
                            -> let c_PTB_asW3 = ((toVector x_asW2) Data.Vector.Unboxed.! 0)
                               in (p_asUZ * c_PTB_asW3))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW4
                            -> let c_NPTB_asW5 = ((toVector x_asW4) Data.Vector.Unboxed.! 1)
                               in (p_asV1 * c_NPTB_asW5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asW6
                            -> let c_MiRs_asW7 = ((toVector x_asW6) Data.Vector.Unboxed.! 2)
                               in (p_asV3 * c_MiRs_asW7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asW8
                            -> let c_RESTc_asW9 = ((toVector x_asW8) Data.Vector.Unboxed.! 3)
                               in (p_asV5 * c_RESTc_asW9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWa
                            -> let
                                 c_EndoNeuroTFs_asWb = ((toVector x_asWa) Data.Vector.Unboxed.! 4)
                               in (p_asV7 * c_EndoNeuroTFs_asWb))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWT
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                            (g_asUY, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUX = code-0.1.0.0:Genome.FixedList.Functions.double g_asUW
                            (g_asUW, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUV = Functions.belowten' g_asUU
                            (g_asUU, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUR = Functions.belowten' g_asUQ
                            (g_asUQ, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                            (g_asUO, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                            (g_asUM, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                            (g_asUK, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUJ = Functions.belowten' g_asUI
                            (g_asUI, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUH = code-0.1.0.0:Genome.FixedList.Functions.double g_asUG
                            (g_asUG, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                            (g_asUE, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUC
                            (g_asUC, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUB = Functions.belowten' g_asUA
                            (g_asUA, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUt = Functions.belowten' g_asUs
                            (g_asUs, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUr = code-0.1.0.0:Genome.FixedList.Functions.double g_asUq
                            (g_asUq, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                            (g_asUo, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUl = code-0.1.0.0:Genome.FixedList.Functions.double g_asUk
                            (g_asUk, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUj = Functions.belowten' g_asUi
                            (g_asUi, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asUf = Functions.belowten' g_asUe
                            (g_asUe, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asU9 = Functions.belowten' g_asU8
                            (g_asU8, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                            (g_asU6, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asU5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                            (g_asU4, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asU3
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU2
                            (g_asU2, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                            (g_asU0, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                            (g_asTY, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asTT = code-0.1.0.0:Genome.FixedList.Functions.double g_asTS
                            (g_asTS, gpart_asWh) = Genome.Split.split genome_asV8
                          in
                            \ desc_asV9
                              -> case desc_asV9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTT)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYQ
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZu
                      p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                      (g_asYO, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                      (g_asYE, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asYD = Functions.belowten' g_asYC
                      (g_asYC, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYz = Functions.belowten' g_asYy
                      (g_asYy, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                      (g_asYu, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                      (g_asYs, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYr = Functions.belowten' g_asYq
                      (g_asYq, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYm
                      (g_asYm, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asYl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYk
                      (g_asYk, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asYj = Functions.belowten' g_asYi
                      (g_asYi, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                      (g_asYe, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asYb = Functions.belowten' g_asYa
                      (g_asYa, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asY7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY6
                      (g_asY6, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asY5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY4
                      (g_asY4, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asY1 = Functions.belowten' g_asY0
                      (g_asY0, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                      (g_asXY, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asXX = Functions.belowten' g_asXW
                      (g_asXW, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asXV = code-0.1.0.0:Genome.FixedList.Functions.double g_asXU
                      (g_asXU, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                      (g_asXS, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asXR = Functions.belowten' g_asXQ
                      (g_asXQ, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                      (g_asXO, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asXN
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXM
                      (g_asXM, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXK
                      (g_asXK, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                      (g_asXI, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                      (g_asXG, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                      (g_asXE, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                      (g_asXC, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                      (g_asXA, gpart_asYS) = Genome.Split.split genome_asYQ
                    in
                      [Reaction
                         (\ x_asZv
                            -> let c_MiRs_asZw = ((toVector x_asZv) Data.Vector.Unboxed.! 2)
                               in (p_asXJ / (1 + ((c_MiRs_asZw / p_asXP) ** p_asXR))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZx
                            -> let
                                 c_MiRs_asZy = ((toVector x_asZx) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZz = ((toVector x_asZx) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXT
                                  / (1
                                     + (((c_MiRs_asZy / p_asXV) ** p_asXX)
                                        + ((c_PTB_asZz / p_asXZ) ** p_asY1)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZA
                            -> let c_RESTc_asZB = ((toVector x_asZA) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asY3
                                  * (p_asYd
                                     / ((1 + p_asYd) + ((c_RESTc_asZB / p_asY9) ** p_asYb)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZC
                            -> let
                                 c_MiRs_asZF = ((toVector x_asZC) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZD = ((toVector x_asZC) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYf
                                  * ((p_asYt + ((c_PTB_asZD / p_asYh) ** p_asYj))
                                     / (((1 + p_asYt) + ((c_PTB_asZD / p_asYh) ** p_asYj))
                                        + (((p_asXB / p_asYl) ** p_asYn)
                                           + ((c_MiRs_asZF / p_asYp) ** p_asYr))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZG
                            -> let
                                 c_RESTc_asZJ = ((toVector x_asZG) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asZH = ((toVector x_asZG) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asYv
                                  * ((p_asYF + ((c_MiRs_asZH / p_asYx) ** p_asYz))
                                     / (((1 + p_asYF) + ((c_MiRs_asZH / p_asYx) ** p_asYz))
                                        + ((c_RESTc_asZJ / p_asYB) ** p_asYD)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZK
                            -> let c_PTB_asZL = ((toVector x_asZK) Data.Vector.Unboxed.! 0)
                               in (p_asYH * c_PTB_asZL))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZM
                            -> let c_NPTB_asZN = ((toVector x_asZM) Data.Vector.Unboxed.! 1)
                               in (p_asYJ * c_NPTB_asZN))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZO
                            -> let c_MiRs_asZP = ((toVector x_asZO) Data.Vector.Unboxed.! 2)
                               in (p_asYL * c_MiRs_asZP))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZQ
                            -> let c_RESTc_asZR = ((toVector x_asZQ) Data.Vector.Unboxed.! 3)
                               in (p_asYN * c_RESTc_asZR))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZS
                            -> let
                                 c_EndoNeuroTFs_asZT = ((toVector x_asZS) Data.Vector.Unboxed.! 4)
                               in (p_asYP * c_EndoNeuroTFs_asZT))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121129",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121131",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYQ
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0w
                            p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                            (g_asYO, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at0u) = Genome.Split.split gpart_at0t
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0t) = Genome.Split.split gpart_at0s
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0s) = Genome.Split.split gpart_at0r
                            p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                            (g_asYE, gpart_at0r) = Genome.Split.split gpart_at0q
                            p_asYD = Functions.belowten' g_asYC
                            (g_asYC, gpart_at0q) = Genome.Split.split gpart_at0p
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0p) = Genome.Split.split gpart_at0o
                            p_asYz = Functions.belowten' g_asYy
                            (g_asYy, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                            (g_asYu, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                            (g_asYs, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asYr = Functions.belowten' g_asYq
                            (g_asYq, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asYn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYm
                            (g_asYm, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asYl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYk
                            (g_asYk, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asYj = Functions.belowten' g_asYi
                            (g_asYi, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asYf = code-0.1.0.0:Genome.FixedList.Functions.double g_asYe
                            (g_asYe, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asYb = Functions.belowten' g_asYa
                            (g_asYa, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asY7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY6
                            (g_asY6, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asY5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY4
                            (g_asY4, gpart_at09) = Genome.Split.split gpart_at08
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at08) = Genome.Split.split gpart_at07
                            p_asY1 = Functions.belowten' g_asY0
                            (g_asY0, gpart_at07) = Genome.Split.split gpart_at06
                            p_asXZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXY
                            (g_asXY, gpart_at06) = Genome.Split.split gpart_at05
                            p_asXX = Functions.belowten' g_asXW
                            (g_asXW, gpart_at05) = Genome.Split.split gpart_at04
                            p_asXV = code-0.1.0.0:Genome.FixedList.Functions.double g_asXU
                            (g_asXU, gpart_at04) = Genome.Split.split gpart_at03
                            p_asXT = code-0.1.0.0:Genome.FixedList.Functions.double g_asXS
                            (g_asXS, gpart_at03) = Genome.Split.split gpart_at02
                            p_asXR = Functions.belowten' g_asXQ
                            (g_asXQ, gpart_at02) = Genome.Split.split gpart_at01
                            p_asXP = code-0.1.0.0:Genome.FixedList.Functions.double g_asXO
                            (g_asXO, gpart_at01) = Genome.Split.split gpart_at00
                            p_asXN
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXM
                            (g_asXM, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asXL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXK
                            (g_asXK, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asXJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXI
                            (g_asXI, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asXH = code-0.1.0.0:Genome.FixedList.Functions.double g_asXG
                            (g_asXG, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asXF = code-0.1.0.0:Genome.FixedList.Functions.double g_asXE
                            (g_asXE, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asXD = code-0.1.0.0:Genome.FixedList.Functions.double g_asXC
                            (g_asXC, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXB = code-0.1.0.0:Genome.FixedList.Functions.double g_asXA
                            (g_asXA, gpart_asZU) = Genome.Split.split genome_asYQ
                          in
                            \ desc_asYR
                              -> case desc_asYR of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXB)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXD)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXF)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXH)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXJ)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXL)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXN)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXP)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXR)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXT)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXV)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXX)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXZ)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY1)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2t
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at37
                      p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                      (g_at2r, gpart_at37) = Genome.Split.split gpart_at36
                      p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                      (g_at2p, gpart_at36) = Genome.Split.split gpart_at35
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at35) = Genome.Split.split gpart_at34
                      p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                      (g_at2l, gpart_at34) = Genome.Split.split gpart_at33
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at33) = Genome.Split.split gpart_at32
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at32) = Genome.Split.split gpart_at31
                      p_at2g = Functions.belowten' g_at2f
                      (g_at2f, gpart_at31) = Genome.Split.split gpart_at30
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at30) = Genome.Split.split gpart_at2Z
                      p_at2c = Functions.belowten' g_at2b
                      (g_at2b, gpart_at2Z) = Genome.Split.split gpart_at2Y
                      p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                      (g_at29, gpart_at2Y) = Genome.Split.split gpart_at2X
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at2X) = Genome.Split.split gpart_at2W
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at24 = Functions.belowten' g_at23
                      (g_at23, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at20
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                      (g_at1Z, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at1Y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                      (g_at1X, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at1W = Functions.belowten' g_at1V
                      (g_at1V, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at2Q) = Genome.Split.split gpart_at2P
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at1O = Functions.belowten' g_at1N
                      (g_at1N, gpart_at2N) = Genome.Split.split gpart_at2M
                      p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                      (g_at1L, gpart_at2M) = Genome.Split.split gpart_at2L
                      p_at1K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1J
                      (g_at1J, gpart_at2L) = Genome.Split.split gpart_at2K
                      p_at1I
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                      (g_at1H, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                      (g_at1F, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at1E = Functions.belowten' g_at1D
                      (g_at1D, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                      (g_at1B, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1A = Functions.belowten' g_at1z
                      (g_at1z, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                      (g_at1v, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1u = Functions.belowten' g_at1t
                      (g_at1t, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                      (g_at1r, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                      (g_at1p, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1n
                      (g_at1n, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                      (g_at1l, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1i = code-0.1.0.0:Genome.FixedList.Functions.double g_at1h
                      (g_at1h, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                      (g_at1f, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at2v) = Genome.Split.split genome_at2t
                    in
                      [Reaction
                         (\ x_at38
                            -> let c_MiRs_at39 = ((toVector x_at38) Data.Vector.Unboxed.! 2)
                               in (p_at1m / (1 + ((c_MiRs_at39 / p_at1s) ** p_at1u))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3a
                            -> let
                                 c_MiRs_at3b = ((toVector x_at3a) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3c = ((toVector x_at3a) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1w
                                  / (1
                                     + (((c_MiRs_at3b / p_at1y) ** p_at1A)
                                        + ((c_PTB_at3c / p_at1C) ** p_at1E)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3d
                            -> let c_RESTc_at3e = ((toVector x_at3d) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1G
                                  * (p_at1Q
                                     / ((1 + p_at1Q) + ((c_RESTc_at3e / p_at1M) ** p_at1O)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3f
                            -> let
                                 c_MiRs_at3i = ((toVector x_at3f) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3g = ((toVector x_at3f) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1S
                                  * ((p_at26 + ((c_PTB_at3g / p_at1U) ** p_at1W))
                                     / (((1 + p_at26) + ((c_PTB_at3g / p_at1U) ** p_at1W))
                                        + ((c_MiRs_at3i / p_at22) ** p_at24)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at3j
                            -> let
                                 c_RESTc_at3m = ((toVector x_at3j) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at3k = ((toVector x_at3j) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at28
                                  * ((p_at2i + ((c_MiRs_at3k / p_at2a) ** p_at2c))
                                     / (((1 + p_at2i) + ((c_MiRs_at3k / p_at2a) ** p_at2c))
                                        + ((c_RESTc_at3m / p_at2e) ** p_at2g)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3n
                            -> let c_PTB_at3o = ((toVector x_at3n) Data.Vector.Unboxed.! 0)
                               in (p_at2k * c_PTB_at3o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3p
                            -> let c_NPTB_at3q = ((toVector x_at3p) Data.Vector.Unboxed.! 1)
                               in (p_at2m * c_NPTB_at3q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3r
                            -> let c_MiRs_at3s = ((toVector x_at3r) Data.Vector.Unboxed.! 2)
                               in (p_at2o * c_MiRs_at3s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3t
                            -> let c_RESTc_at3u = ((toVector x_at3t) Data.Vector.Unboxed.! 3)
                               in (p_at2q * c_RESTc_at3u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3v
                            -> let
                                 c_EndoNeuroTFs_at3w = ((toVector x_at3v) Data.Vector.Unboxed.! 4)
                               in (p_at2s * c_EndoNeuroTFs_at3w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2t
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at49
                            p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                            (g_at2r, gpart_at49) = Genome.Split.split gpart_at48
                            p_at2q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2p
                            (g_at2p, gpart_at48) = Genome.Split.split gpart_at47
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at47) = Genome.Split.split gpart_at46
                            p_at2m = code-0.1.0.0:Genome.FixedList.Functions.double g_at2l
                            (g_at2l, gpart_at46) = Genome.Split.split gpart_at45
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at45) = Genome.Split.split gpart_at44
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at44) = Genome.Split.split gpart_at43
                            p_at2g = Functions.belowten' g_at2f
                            (g_at2f, gpart_at43) = Genome.Split.split gpart_at42
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at42) = Genome.Split.split gpart_at41
                            p_at2c = Functions.belowten' g_at2b
                            (g_at2b, gpart_at41) = Genome.Split.split gpart_at40
                            p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                            (g_at29, gpart_at40) = Genome.Split.split gpart_at3Z
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at3Z) = Genome.Split.split gpart_at3Y
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at3Y) = Genome.Split.split gpart_at3X
                            p_at24 = Functions.belowten' g_at23
                            (g_at23, gpart_at3X) = Genome.Split.split gpart_at3W
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at20
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                            (g_at1Z, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at1Y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1X
                            (g_at1X, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at1W = Functions.belowten' g_at1V
                            (g_at1V, gpart_at3T) = Genome.Split.split gpart_at3S
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at3S) = Genome.Split.split gpart_at3R
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at3Q) = Genome.Split.split gpart_at3P
                            p_at1O = Functions.belowten' g_at1N
                            (g_at1N, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                            (g_at1L, gpart_at3O) = Genome.Split.split gpart_at3N
                            p_at1K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1J
                            (g_at1J, gpart_at3N) = Genome.Split.split gpart_at3M
                            p_at1I
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1H
                            (g_at1H, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at1G = code-0.1.0.0:Genome.FixedList.Functions.double g_at1F
                            (g_at1F, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at1E = Functions.belowten' g_at1D
                            (g_at1D, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1C = code-0.1.0.0:Genome.FixedList.Functions.double g_at1B
                            (g_at1B, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1A = Functions.belowten' g_at1z
                            (g_at1z, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1w = code-0.1.0.0:Genome.FixedList.Functions.double g_at1v
                            (g_at1v, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1u = Functions.belowten' g_at1t
                            (g_at1t, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1s = code-0.1.0.0:Genome.FixedList.Functions.double g_at1r
                            (g_at1r, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1p
                            (g_at1p, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1n
                            (g_at1n, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1m = code-0.1.0.0:Genome.FixedList.Functions.double g_at1l
                            (g_at1l, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1i = code-0.1.0.0:Genome.FixedList.Functions.double g_at1h
                            (g_at1h, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1g = code-0.1.0.0:Genome.FixedList.Functions.double g_at1f
                            (g_at1f, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at3x) = Genome.Split.split genome_at2t
                          in
                            \ desc_at2u
                              -> case desc_at2u of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at66
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6K
                      p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                      (g_at64, gpart_at6K) = Genome.Split.split gpart_at6J
                      p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                      (g_at62, gpart_at6J) = Genome.Split.split gpart_at6I
                      p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                      (g_at60, gpart_at6I) = Genome.Split.split gpart_at6H
                      p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                      (g_at5Y, gpart_at6H) = Genome.Split.split gpart_at6G
                      p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                      (g_at5W, gpart_at6G) = Genome.Split.split gpart_at6F
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at6F) = Genome.Split.split gpart_at6E
                      p_at5T = Functions.belowten' g_at5S
                      (g_at5S, gpart_at6E) = Genome.Split.split gpart_at6D
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at6D) = Genome.Split.split gpart_at6C
                      p_at5P = Functions.belowten' g_at5O
                      (g_at5O, gpart_at6C) = Genome.Split.split gpart_at6B
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at6B) = Genome.Split.split gpart_at6A
                      p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                      (g_at5K, gpart_at6A) = Genome.Split.split gpart_at6z
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at6z) = Genome.Split.split gpart_at6y
                      p_at5H = Functions.belowten' g_at5G
                      (g_at5G, gpart_at6y) = Genome.Split.split gpart_at6x
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6x) = Genome.Split.split gpart_at6w
                      p_at5D
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5C
                      (g_at5C, gpart_at6w) = Genome.Split.split gpart_at6v
                      p_at5B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5A
                      (g_at5A, gpart_at6v) = Genome.Split.split gpart_at6u
                      p_at5z = Functions.belowten' g_at5y
                      (g_at5y, gpart_at6u) = Genome.Split.split gpart_at6t
                      p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                      (g_at5w, gpart_at6t) = Genome.Split.split gpart_at6s
                      p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                      (g_at5u, gpart_at6s) = Genome.Split.split gpart_at6r
                      p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                      (g_at5s, gpart_at6r) = Genome.Split.split gpart_at6q
                      p_at5r = Functions.belowten' g_at5q
                      (g_at5q, gpart_at6q) = Genome.Split.split gpart_at6p
                      p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                      (g_at5o, gpart_at6p) = Genome.Split.split gpart_at6o
                      p_at5n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5m
                      (g_at5m, gpart_at6o) = Genome.Split.split gpart_at6n
                      p_at5l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                      (g_at5k, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                      (g_at5i, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5h = Functions.belowten' g_at5g
                      (g_at5g, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                      (g_at5e, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5d = Functions.belowten' g_at5c
                      (g_at5c, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                      (g_at5a, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                      (g_at58, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at57 = Functions.belowten' g_at56
                      (g_at56, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                      (g_at54, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at53
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                      (g_at52, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at51
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at50
                      (g_at50, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                      (g_at4Y, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                      (g_at4W, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                      (g_at4U, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                      (g_at4S, gpart_at69) = Genome.Split.split gpart_at68
                      p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                      (g_at4Q, gpart_at68) = Genome.Split.split genome_at66
                    in
                      [Reaction
                         (\ x_at6L
                            -> let c_MiRs_at6M = ((toVector x_at6L) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4Z
                                  / (1
                                     + (((p_at4R / p_at51) ** p_at53)
                                        + ((c_MiRs_at6M / p_at55) ** p_at57)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6N
                            -> let
                                 c_MiRs_at6O = ((toVector x_at6N) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6P = ((toVector x_at6N) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at59
                                  / (1
                                     + (((c_MiRs_at6O / p_at5b) ** p_at5d)
                                        + ((c_PTB_at6P / p_at5f) ** p_at5h)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6Q
                            -> let c_RESTc_at6R = ((toVector x_at6Q) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5j
                                  * (p_at5t
                                     / ((1 + p_at5t) + ((c_RESTc_at6R / p_at5p) ** p_at5r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6S
                            -> let
                                 c_MiRs_at6V = ((toVector x_at6S) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6T = ((toVector x_at6S) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5v
                                  * ((p_at5J + ((c_PTB_at6T / p_at5x) ** p_at5z))
                                     / (((1 + p_at5J) + ((c_PTB_at6T / p_at5x) ** p_at5z))
                                        + ((c_MiRs_at6V / p_at5F) ** p_at5H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6W
                            -> let
                                 c_RESTc_at6Z = ((toVector x_at6W) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at6X = ((toVector x_at6W) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5L
                                  * ((p_at5V + ((c_MiRs_at6X / p_at5N) ** p_at5P))
                                     / (((1 + p_at5V) + ((c_MiRs_at6X / p_at5N) ** p_at5P))
                                        + ((c_RESTc_at6Z / p_at5R) ** p_at5T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at70
                            -> let c_PTB_at71 = ((toVector x_at70) Data.Vector.Unboxed.! 0)
                               in (p_at5X * c_PTB_at71))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at72
                            -> let c_NPTB_at73 = ((toVector x_at72) Data.Vector.Unboxed.! 1)
                               in (p_at5Z * c_NPTB_at73))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at74
                            -> let c_MiRs_at75 = ((toVector x_at74) Data.Vector.Unboxed.! 2)
                               in (p_at61 * c_MiRs_at75))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at76
                            -> let c_RESTc_at77 = ((toVector x_at76) Data.Vector.Unboxed.! 3)
                               in (p_at63 * c_RESTc_at77))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at78
                            -> let
                                 c_EndoNeuroTFs_at79 = ((toVector x_at78) Data.Vector.Unboxed.! 4)
                               in (p_at65 * c_EndoNeuroTFs_at79))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121568",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121569",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121570",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121571",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121572",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121573",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121574",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121575",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121576",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121577",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121578",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121579",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121580",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121581",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121582",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121583",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121584",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121585",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121586",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121587",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121588",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121589",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121590",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121591",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121592",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121593",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121594",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121595",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121596",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121597",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121598",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121599",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121600",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121601",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121602",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121603",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121615",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at66
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7M
                            p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                            (g_at64, gpart_at7M) = Genome.Split.split gpart_at7L
                            p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                            (g_at62, gpart_at7L) = Genome.Split.split gpart_at7K
                            p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                            (g_at60, gpart_at7K) = Genome.Split.split gpart_at7J
                            p_at5Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Y
                            (g_at5Y, gpart_at7J) = Genome.Split.split gpart_at7I
                            p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                            (g_at5W, gpart_at7I) = Genome.Split.split gpart_at7H
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at7H) = Genome.Split.split gpart_at7G
                            p_at5T = Functions.belowten' g_at5S
                            (g_at5S, gpart_at7G) = Genome.Split.split gpart_at7F
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at7F) = Genome.Split.split gpart_at7E
                            p_at5P = Functions.belowten' g_at5O
                            (g_at5O, gpart_at7E) = Genome.Split.split gpart_at7D
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at7D) = Genome.Split.split gpart_at7C
                            p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                            (g_at5K, gpart_at7C) = Genome.Split.split gpart_at7B
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at7B) = Genome.Split.split gpart_at7A
                            p_at5H = Functions.belowten' g_at5G
                            (g_at5G, gpart_at7A) = Genome.Split.split gpart_at7z
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at7z) = Genome.Split.split gpart_at7y
                            p_at5D
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5C
                            (g_at5C, gpart_at7y) = Genome.Split.split gpart_at7x
                            p_at5B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5A
                            (g_at5A, gpart_at7x) = Genome.Split.split gpart_at7w
                            p_at5z = Functions.belowten' g_at5y
                            (g_at5y, gpart_at7w) = Genome.Split.split gpart_at7v
                            p_at5x = code-0.1.0.0:Genome.FixedList.Functions.double g_at5w
                            (g_at5w, gpart_at7v) = Genome.Split.split gpart_at7u
                            p_at5v = code-0.1.0.0:Genome.FixedList.Functions.double g_at5u
                            (g_at5u, gpart_at7u) = Genome.Split.split gpart_at7t
                            p_at5t = code-0.1.0.0:Genome.FixedList.Functions.double g_at5s
                            (g_at5s, gpart_at7t) = Genome.Split.split gpart_at7s
                            p_at5r = Functions.belowten' g_at5q
                            (g_at5q, gpart_at7s) = Genome.Split.split gpart_at7r
                            p_at5p = code-0.1.0.0:Genome.FixedList.Functions.double g_at5o
                            (g_at5o, gpart_at7r) = Genome.Split.split gpart_at7q
                            p_at5n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5m
                            (g_at5m, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at5l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5k
                            (g_at5k, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at5j = code-0.1.0.0:Genome.FixedList.Functions.double g_at5i
                            (g_at5i, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5h = Functions.belowten' g_at5g
                            (g_at5g, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5f = code-0.1.0.0:Genome.FixedList.Functions.double g_at5e
                            (g_at5e, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5d = Functions.belowten' g_at5c
                            (g_at5c, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5b = code-0.1.0.0:Genome.FixedList.Functions.double g_at5a
                            (g_at5a, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at59 = code-0.1.0.0:Genome.FixedList.Functions.double g_at58
                            (g_at58, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at57 = Functions.belowten' g_at56
                            (g_at56, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at55 = code-0.1.0.0:Genome.FixedList.Functions.double g_at54
                            (g_at54, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at53
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at52
                            (g_at52, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at51
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at50
                            (g_at50, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at4Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Y
                            (g_at4Y, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at4X = code-0.1.0.0:Genome.FixedList.Functions.double g_at4W
                            (g_at4W, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at4V = code-0.1.0.0:Genome.FixedList.Functions.double g_at4U
                            (g_at4U, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at4T = code-0.1.0.0:Genome.FixedList.Functions.double g_at4S
                            (g_at4S, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at4R = code-0.1.0.0:Genome.FixedList.Functions.double g_at4Q
                            (g_at4Q, gpart_at7a) = Genome.Split.split genome_at66
                          in
                            \ desc_at67
                              -> case desc_at67 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4R)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4T)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4V)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4X)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Z)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at51)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at53)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at55)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at57)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at59)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5b)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5d)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5f)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5h)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5j)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5l)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5n)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5p)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5r)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5t)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5v)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5x)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5z)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5B)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   _ -> Nothing }}
