src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a24P5
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24PL
                      p_a24P4 = double g_a24P3
                      (g_a24P3, gpart_a24PL) = Genome.Split.split gpart_a24PK
                      p_a24P2 = double g_a24P1
                      (g_a24P1, gpart_a24PK) = Genome.Split.split gpart_a24PJ
                      p_a24P0 = double g_a24OZ
                      (g_a24OZ, gpart_a24PJ) = Genome.Split.split gpart_a24PI
                      p_a24OY = double g_a24OX
                      (g_a24OX, gpart_a24PI) = Genome.Split.split gpart_a24PH
                      p_a24OW = double g_a24OV
                      (g_a24OV, gpart_a24PH) = Genome.Split.split gpart_a24PG
                      p_a24OU = double g_a24OT
                      (g_a24OT, gpart_a24PG) = Genome.Split.split gpart_a24PF
                      p_a24OS = Functions.belowten' g_a24OR
                      (g_a24OR, gpart_a24PF) = Genome.Split.split gpart_a24PE
                      p_a24OQ = double g_a24OP
                      (g_a24OP, gpart_a24PE) = Genome.Split.split gpart_a24PD
                      p_a24OO = Functions.belowten' g_a24ON
                      (g_a24ON, gpart_a24PD) = Genome.Split.split gpart_a24PC
                      p_a24OM = double g_a24OL
                      (g_a24OL, gpart_a24PC) = Genome.Split.split gpart_a24PB
                      p_a24OK = double g_a24OJ
                      (g_a24OJ, gpart_a24PB) = Genome.Split.split gpart_a24PA
                      p_a24OI = double g_a24OH
                      (g_a24OH, gpart_a24PA) = Genome.Split.split gpart_a24Pz
                      p_a24OG = Functions.belowten' g_a24OF
                      (g_a24OF, gpart_a24Pz) = Genome.Split.split gpart_a24Py
                      p_a24OE = double g_a24OD
                      (g_a24OD, gpart_a24Py) = Genome.Split.split gpart_a24Px
                      p_a24OC
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OB
                      (g_a24OB, gpart_a24Px) = Genome.Split.split gpart_a24Pw
                      p_a24OA
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oz
                      (g_a24Oz, gpart_a24Pw) = Genome.Split.split gpart_a24Pv
                      p_a24Oy = Functions.belowten' g_a24Ox
                      (g_a24Ox, gpart_a24Pv) = Genome.Split.split gpart_a24Pu
                      p_a24Ow = double g_a24Ov
                      (g_a24Ov, gpart_a24Pu) = Genome.Split.split gpart_a24Pt
                      p_a24Ou = double g_a24Ot
                      (g_a24Ot, gpart_a24Pt) = Genome.Split.split gpart_a24Ps
                      p_a24Os = double g_a24Or
                      (g_a24Or, gpart_a24Ps) = Genome.Split.split gpart_a24Pr
                      p_a24Oq = Functions.belowten' g_a24Op
                      (g_a24Op, gpart_a24Pr) = Genome.Split.split gpart_a24Pq
                      p_a24Oo = double g_a24On
                      (g_a24On, gpart_a24Pq) = Genome.Split.split gpart_a24Pp
                      p_a24Om = Functions.belowten' g_a24Ol
                      (g_a24Ol, gpart_a24Pp) = Genome.Split.split gpart_a24Po
                      p_a24Ok = double g_a24Oj
                      (g_a24Oj, gpart_a24Po) = Genome.Split.split gpart_a24Pn
                      p_a24Oi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oh
                      (g_a24Oh, gpart_a24Pn) = Genome.Split.split gpart_a24Pm
                      p_a24Og
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                      (g_a24Of, gpart_a24Pm) = Genome.Split.split gpart_a24Pl
                      p_a24Oe = double g_a24Od
                      (g_a24Od, gpart_a24Pl) = Genome.Split.split gpart_a24Pk
                      p_a24Oc = Functions.belowten' g_a24Ob
                      (g_a24Ob, gpart_a24Pk) = Genome.Split.split gpart_a24Pj
                      p_a24Oa = double g_a24O9
                      (g_a24O9, gpart_a24Pj) = Genome.Split.split gpart_a24Pi
                      p_a24O8 = Functions.belowten' g_a24O7
                      (g_a24O7, gpart_a24Pi) = Genome.Split.split gpart_a24Ph
                      p_a24O6 = double g_a24O5
                      (g_a24O5, gpart_a24Ph) = Genome.Split.split gpart_a24Pg
                      p_a24O4 = double g_a24O3
                      (g_a24O3, gpart_a24Pg) = Genome.Split.split gpart_a24Pf
                      p_a24O2 = Functions.belowten' g_a24O1
                      (g_a24O1, gpart_a24Pf) = Genome.Split.split gpart_a24Pe
                      p_a24O0 = double g_a24NZ
                      (g_a24NZ, gpart_a24Pe) = Genome.Split.split gpart_a24Pd
                      p_a24NY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NX
                      (g_a24NX, gpart_a24Pd) = Genome.Split.split gpart_a24Pc
                      p_a24NW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NV
                      (g_a24NV, gpart_a24Pc) = Genome.Split.split gpart_a24Pb
                      p_a24NU = double g_a24NT
                      (g_a24NT, gpart_a24Pb) = Genome.Split.split gpart_a24Pa
                      p_a24NS = double g_a24NR
                      (g_a24NR, gpart_a24Pa) = Genome.Split.split gpart_a24P9
                      p_a24NQ = double g_a24NP
                      (g_a24NP, gpart_a24P9) = Genome.Split.split gpart_a24P8
                      p_a24NO = double g_a24NN
                      (g_a24NN, gpart_a24P8) = Genome.Split.split gpart_a24P7
                      p_a24NM = double g_a24NL
                      (g_a24NL, gpart_a24P7) = Genome.Split.split genome_a24P5
                    in  \ x_a24PM
                          -> let
                               c_PTB_a24PP
                                 = ((Data.Fixed.Vector.toVector x_a24PM) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24PN
                                 = ((Data.Fixed.Vector.toVector x_a24PM) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24PT
                                 = ((Data.Fixed.Vector.toVector x_a24PM) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24PW
                                 = ((Data.Fixed.Vector.toVector x_a24PM) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Q8
                                 = ((Data.Fixed.Vector.toVector x_a24PM) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24NU / (1 + ((c_MiRs_a24PN / p_a24O0) ** p_a24O2)))
                                    + (negate (p_a24OW * c_PTB_a24PP))),
                                   ((p_a24O4
                                     / (1
                                        + (((c_MiRs_a24PN / p_a24O6) ** p_a24O8)
                                           + ((c_PTB_a24PP / p_a24Oa) ** p_a24Oc))))
                                    + (negate (p_a24OY * c_NPTB_a24PT))),
                                   ((p_a24Oe
                                     * ((p_a24Os
                                         + (((p_a24NQ / p_a24Og) ** p_a24Oi)
                                            + ((c_PTB_a24PP / p_a24Ok) ** p_a24Om)))
                                        / (((1 + p_a24Os)
                                            + (((p_a24NQ / p_a24Og) ** p_a24Oi)
                                               + ((c_PTB_a24PP / p_a24Ok) ** p_a24Om)))
                                           + ((c_RESTc_a24PW / p_a24Oo) ** p_a24Oq))))
                                    + (negate (p_a24P0 * c_MiRs_a24PN))),
                                   ((p_a24Ou
                                     * ((p_a24OI + ((c_PTB_a24PP / p_a24Ow) ** p_a24Oy))
                                        / (((1 + p_a24OI) + ((c_PTB_a24PP / p_a24Ow) ** p_a24Oy))
                                           + (((p_a24NM / p_a24OA) ** p_a24OC)
                                              + ((c_MiRs_a24PN / p_a24OE) ** p_a24OG)))))
                                    + (negate (p_a24P2 * c_RESTc_a24PW))),
                                   ((p_a24OK
                                     * ((p_a24OU + ((c_MiRs_a24PN / p_a24OM) ** p_a24OO))
                                        / (((1 + p_a24OU) + ((c_MiRs_a24PN / p_a24OM) ** p_a24OO))
                                           + ((c_RESTc_a24PW / p_a24OQ) ** p_a24OS))))
                                    + (negate (p_a24P4 * c_EndoNeuroTFs_a24Q8)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504909",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504910",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504911",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504912",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504913",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504914",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504915",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504916",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504917",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504918",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504919",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504920",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504921",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504922",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504923",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504924",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504925",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504926",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504927",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504928",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504929",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504930",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504931",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504932",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504933",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504934",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504935",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504936",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504937",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504938",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504939",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504940",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504941",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504942",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504943",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504944",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504945",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504946",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504947",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504948",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504949",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504950",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504951",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504952",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504953",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504954",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504955",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504956",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504957",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504958",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504959",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504960",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504961",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504962",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504963",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504964",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504965",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504966",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504967",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504968",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504969",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504970",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504971",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504972",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504973",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504974",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504975",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504976",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504977",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504978",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504979",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504980",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504981",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504982",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504983",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504984",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504985",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504986",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504987",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504988",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679504989",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679504990",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24P5
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24QN
                            p_a24P4 = double g_a24P3
                            (g_a24P3, gpart_a24QN) = Genome.Split.split gpart_a24QM
                            p_a24P2 = double g_a24P1
                            (g_a24P1, gpart_a24QM) = Genome.Split.split gpart_a24QL
                            p_a24P0 = double g_a24OZ
                            (g_a24OZ, gpart_a24QL) = Genome.Split.split gpart_a24QK
                            p_a24OY = double g_a24OX
                            (g_a24OX, gpart_a24QK) = Genome.Split.split gpart_a24QJ
                            p_a24OW = double g_a24OV
                            (g_a24OV, gpart_a24QJ) = Genome.Split.split gpart_a24QI
                            p_a24OU = double g_a24OT
                            (g_a24OT, gpart_a24QI) = Genome.Split.split gpart_a24QH
                            p_a24OS = Functions.belowten' g_a24OR
                            (g_a24OR, gpart_a24QH) = Genome.Split.split gpart_a24QG
                            p_a24OQ = double g_a24OP
                            (g_a24OP, gpart_a24QG) = Genome.Split.split gpart_a24QF
                            p_a24OO = Functions.belowten' g_a24ON
                            (g_a24ON, gpart_a24QF) = Genome.Split.split gpart_a24QE
                            p_a24OM = double g_a24OL
                            (g_a24OL, gpart_a24QE) = Genome.Split.split gpart_a24QD
                            p_a24OK = double g_a24OJ
                            (g_a24OJ, gpart_a24QD) = Genome.Split.split gpart_a24QC
                            p_a24OI = double g_a24OH
                            (g_a24OH, gpart_a24QC) = Genome.Split.split gpart_a24QB
                            p_a24OG = Functions.belowten' g_a24OF
                            (g_a24OF, gpart_a24QB) = Genome.Split.split gpart_a24QA
                            p_a24OE = double g_a24OD
                            (g_a24OD, gpart_a24QA) = Genome.Split.split gpart_a24Qz
                            p_a24OC
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24OB
                            (g_a24OB, gpart_a24Qz) = Genome.Split.split gpart_a24Qy
                            p_a24OA
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oz
                            (g_a24Oz, gpart_a24Qy) = Genome.Split.split gpart_a24Qx
                            p_a24Oy = Functions.belowten' g_a24Ox
                            (g_a24Ox, gpart_a24Qx) = Genome.Split.split gpart_a24Qw
                            p_a24Ow = double g_a24Ov
                            (g_a24Ov, gpart_a24Qw) = Genome.Split.split gpart_a24Qv
                            p_a24Ou = double g_a24Ot
                            (g_a24Ot, gpart_a24Qv) = Genome.Split.split gpart_a24Qu
                            p_a24Os = double g_a24Or
                            (g_a24Or, gpart_a24Qu) = Genome.Split.split gpart_a24Qt
                            p_a24Oq = Functions.belowten' g_a24Op
                            (g_a24Op, gpart_a24Qt) = Genome.Split.split gpart_a24Qs
                            p_a24Oo = double g_a24On
                            (g_a24On, gpart_a24Qs) = Genome.Split.split gpart_a24Qr
                            p_a24Om = Functions.belowten' g_a24Ol
                            (g_a24Ol, gpart_a24Qr) = Genome.Split.split gpart_a24Qq
                            p_a24Ok = double g_a24Oj
                            (g_a24Oj, gpart_a24Qq) = Genome.Split.split gpart_a24Qp
                            p_a24Oi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Oh
                            (g_a24Oh, gpart_a24Qp) = Genome.Split.split gpart_a24Qo
                            p_a24Og
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Of
                            (g_a24Of, gpart_a24Qo) = Genome.Split.split gpart_a24Qn
                            p_a24Oe = double g_a24Od
                            (g_a24Od, gpart_a24Qn) = Genome.Split.split gpart_a24Qm
                            p_a24Oc = Functions.belowten' g_a24Ob
                            (g_a24Ob, gpart_a24Qm) = Genome.Split.split gpart_a24Ql
                            p_a24Oa = double g_a24O9
                            (g_a24O9, gpart_a24Ql) = Genome.Split.split gpart_a24Qk
                            p_a24O8 = Functions.belowten' g_a24O7
                            (g_a24O7, gpart_a24Qk) = Genome.Split.split gpart_a24Qj
                            p_a24O6 = double g_a24O5
                            (g_a24O5, gpart_a24Qj) = Genome.Split.split gpart_a24Qi
                            p_a24O4 = double g_a24O3
                            (g_a24O3, gpart_a24Qi) = Genome.Split.split gpart_a24Qh
                            p_a24O2 = Functions.belowten' g_a24O1
                            (g_a24O1, gpart_a24Qh) = Genome.Split.split gpart_a24Qg
                            p_a24O0 = double g_a24NZ
                            (g_a24NZ, gpart_a24Qg) = Genome.Split.split gpart_a24Qf
                            p_a24NY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NX
                            (g_a24NX, gpart_a24Qf) = Genome.Split.split gpart_a24Qe
                            p_a24NW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24NV
                            (g_a24NV, gpart_a24Qe) = Genome.Split.split gpart_a24Qd
                            p_a24NU = double g_a24NT
                            (g_a24NT, gpart_a24Qd) = Genome.Split.split gpart_a24Qc
                            p_a24NS = double g_a24NR
                            (g_a24NR, gpart_a24Qc) = Genome.Split.split gpart_a24Qb
                            p_a24NQ = double g_a24NP
                            (g_a24NP, gpart_a24Qb) = Genome.Split.split gpart_a24Qa
                            p_a24NO = double g_a24NN
                            (g_a24NN, gpart_a24Qa) = Genome.Split.split gpart_a24Q9
                            p_a24NM = double g_a24NL
                            (g_a24NL, gpart_a24Q9) = Genome.Split.split genome_a24P5
                          in
                            \ desc_a24P6
                              -> case desc_a24P6 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NM)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NO)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NQ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NS)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NU)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NW)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24NY)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O0)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O2)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O4)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O6)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24O8)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oa)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oc)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oe)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Og)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oi)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ok)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Om)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oo)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oq)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Os)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ou)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ow)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Oy)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OA)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OC)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OE)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OG)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OI)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OK)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OM)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OO)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OQ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OS)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OU)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OW)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24OY)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P0)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P2)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24P4)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a24Th
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24TX
                      p_a24Tg = double g_a24Tf
                      (g_a24Tf, gpart_a24TX) = Genome.Split.split gpart_a24TW
                      p_a24Te = double g_a24Td
                      (g_a24Td, gpart_a24TW) = Genome.Split.split gpart_a24TV
                      p_a24Tc = double g_a24Tb
                      (g_a24Tb, gpart_a24TV) = Genome.Split.split gpart_a24TU
                      p_a24Ta = double g_a24T9
                      (g_a24T9, gpart_a24TU) = Genome.Split.split gpart_a24TT
                      p_a24T8 = double g_a24T7
                      (g_a24T7, gpart_a24TT) = Genome.Split.split gpart_a24TS
                      p_a24T6 = double g_a24T5
                      (g_a24T5, gpart_a24TS) = Genome.Split.split gpart_a24TR
                      p_a24T4 = Functions.belowten' g_a24T3
                      (g_a24T3, gpart_a24TR) = Genome.Split.split gpart_a24TQ
                      p_a24T2 = double g_a24T1
                      (g_a24T1, gpart_a24TQ) = Genome.Split.split gpart_a24TP
                      p_a24T0 = Functions.belowten' g_a24SZ
                      (g_a24SZ, gpart_a24TP) = Genome.Split.split gpart_a24TO
                      p_a24SY = double g_a24SX
                      (g_a24SX, gpart_a24TO) = Genome.Split.split gpart_a24TN
                      p_a24SW = double g_a24SV
                      (g_a24SV, gpart_a24TN) = Genome.Split.split gpart_a24TM
                      p_a24SU = double g_a24ST
                      (g_a24ST, gpart_a24TM) = Genome.Split.split gpart_a24TL
                      p_a24SS = Functions.belowten' g_a24SR
                      (g_a24SR, gpart_a24TL) = Genome.Split.split gpart_a24TK
                      p_a24SQ = double g_a24SP
                      (g_a24SP, gpart_a24TK) = Genome.Split.split gpart_a24TJ
                      p_a24SO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SN
                      (g_a24SN, gpart_a24TJ) = Genome.Split.split gpart_a24TI
                      p_a24SM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SL
                      (g_a24SL, gpart_a24TI) = Genome.Split.split gpart_a24TH
                      p_a24SK = Functions.belowten' g_a24SJ
                      (g_a24SJ, gpart_a24TH) = Genome.Split.split gpart_a24TG
                      p_a24SI = double g_a24SH
                      (g_a24SH, gpart_a24TG) = Genome.Split.split gpart_a24TF
                      p_a24SG = double g_a24SF
                      (g_a24SF, gpart_a24TF) = Genome.Split.split gpart_a24TE
                      p_a24SE = double g_a24SD
                      (g_a24SD, gpart_a24TE) = Genome.Split.split gpart_a24TD
                      p_a24SC = Functions.belowten' g_a24SB
                      (g_a24SB, gpart_a24TD) = Genome.Split.split gpart_a24TC
                      p_a24SA = double g_a24Sz
                      (g_a24Sz, gpart_a24TC) = Genome.Split.split gpart_a24TB
                      p_a24Sy = Functions.belowten' g_a24Sx
                      (g_a24Sx, gpart_a24TB) = Genome.Split.split gpart_a24TA
                      p_a24Sw = double g_a24Sv
                      (g_a24Sv, gpart_a24TA) = Genome.Split.split gpart_a24Tz
                      p_a24Su
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24St
                      (g_a24St, gpart_a24Tz) = Genome.Split.split gpart_a24Ty
                      p_a24Ss
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                      (g_a24Sr, gpart_a24Ty) = Genome.Split.split gpart_a24Tx
                      p_a24Sq = double g_a24Sp
                      (g_a24Sp, gpart_a24Tx) = Genome.Split.split gpart_a24Tw
                      p_a24So = Functions.belowten' g_a24Sn
                      (g_a24Sn, gpart_a24Tw) = Genome.Split.split gpart_a24Tv
                      p_a24Sm = double g_a24Sl
                      (g_a24Sl, gpart_a24Tv) = Genome.Split.split gpart_a24Tu
                      p_a24Sk = Functions.belowten' g_a24Sj
                      (g_a24Sj, gpart_a24Tu) = Genome.Split.split gpart_a24Tt
                      p_a24Si = double g_a24Sh
                      (g_a24Sh, gpart_a24Tt) = Genome.Split.split gpart_a24Ts
                      p_a24Sg = double g_a24Sf
                      (g_a24Sf, gpart_a24Ts) = Genome.Split.split gpart_a24Tr
                      p_a24Se = Functions.belowten' g_a24Sd
                      (g_a24Sd, gpart_a24Tr) = Genome.Split.split gpart_a24Tq
                      p_a24Sc = double g_a24Sb
                      (g_a24Sb, gpart_a24Tq) = Genome.Split.split gpart_a24Tp
                      p_a24Sa
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S9
                      (g_a24S9, gpart_a24Tp) = Genome.Split.split gpart_a24To
                      p_a24S8
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S7
                      (g_a24S7, gpart_a24To) = Genome.Split.split gpart_a24Tn
                      p_a24S6 = double g_a24S5
                      (g_a24S5, gpart_a24Tn) = Genome.Split.split gpart_a24Tm
                      p_a24S4 = double g_a24S3
                      (g_a24S3, gpart_a24Tm) = Genome.Split.split gpart_a24Tl
                      p_a24S2 = double g_a24S1
                      (g_a24S1, gpart_a24Tl) = Genome.Split.split gpart_a24Tk
                      p_a24S0 = double g_a24RZ
                      (g_a24RZ, gpart_a24Tk) = Genome.Split.split gpart_a24Tj
                      p_a24RY = double g_a24RX
                      (g_a24RX, gpart_a24Tj) = Genome.Split.split genome_a24Th
                    in  \ x_a24TY
                          -> let
                               c_PTB_a24U1
                                 = ((Data.Fixed.Vector.toVector x_a24TY) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24TZ
                                 = ((Data.Fixed.Vector.toVector x_a24TY) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24U5
                                 = ((Data.Fixed.Vector.toVector x_a24TY) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24U8
                                 = ((Data.Fixed.Vector.toVector x_a24TY) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Uk
                                 = ((Data.Fixed.Vector.toVector x_a24TY) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24S6 / (1 + ((c_MiRs_a24TZ / p_a24Sc) ** p_a24Se)))
                                    + (negate (p_a24T8 * c_PTB_a24U1))),
                                   ((p_a24Sg
                                     / (1
                                        + (((c_MiRs_a24TZ / p_a24Si) ** p_a24Sk)
                                           + ((c_PTB_a24U1 / p_a24Sm) ** p_a24So))))
                                    + (negate (p_a24Ta * c_NPTB_a24U5))),
                                   ((p_a24Sq
                                     * ((p_a24SE + ((c_PTB_a24U1 / p_a24Sw) ** p_a24Sy))
                                        / (((1 + p_a24SE) + ((c_PTB_a24U1 / p_a24Sw) ** p_a24Sy))
                                           + ((c_RESTc_a24U8 / p_a24SA) ** p_a24SC))))
                                    + (negate (p_a24Tc * c_MiRs_a24TZ))),
                                   ((p_a24SG
                                     * ((p_a24SU + ((c_PTB_a24U1 / p_a24SI) ** p_a24SK))
                                        / (((1 + p_a24SU) + ((c_PTB_a24U1 / p_a24SI) ** p_a24SK))
                                           + (((p_a24RY / p_a24SM) ** p_a24SO)
                                              + ((c_MiRs_a24TZ / p_a24SQ) ** p_a24SS)))))
                                    + (negate (p_a24Te * c_RESTc_a24U8))),
                                   ((p_a24SW
                                     * ((p_a24T6 + ((c_MiRs_a24TZ / p_a24SY) ** p_a24T0))
                                        / (((1 + p_a24T6) + ((c_MiRs_a24TZ / p_a24SY) ** p_a24T0))
                                           + ((c_RESTc_a24U8 / p_a24T2) ** p_a24T4))))
                                    + (negate (p_a24Tg * c_EndoNeuroTFs_a24Uk)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505180",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505182",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505191",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505192",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505193",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505194",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505195",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505196",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505197",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505198",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505199",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505200",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505201",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505202",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505203",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505204",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505205",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505206",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505207",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505208",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505209",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505210",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505211",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505212",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505213",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505214",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505215",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505216",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505217",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505218",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505219",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505220",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505221",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505222",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505223",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505224",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505225",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505226",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505227",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505228",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505229",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505230",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505231",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505232",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505233",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505234",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505235",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505236",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505237",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505238",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505239",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505240",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505241",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505242",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505243",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505244",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505245",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505246",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505247",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505248",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505249",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505250",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Th
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24UZ
                            p_a24Tg = double g_a24Tf
                            (g_a24Tf, gpart_a24UZ) = Genome.Split.split gpart_a24UY
                            p_a24Te = double g_a24Td
                            (g_a24Td, gpart_a24UY) = Genome.Split.split gpart_a24UX
                            p_a24Tc = double g_a24Tb
                            (g_a24Tb, gpart_a24UX) = Genome.Split.split gpart_a24UW
                            p_a24Ta = double g_a24T9
                            (g_a24T9, gpart_a24UW) = Genome.Split.split gpart_a24UV
                            p_a24T8 = double g_a24T7
                            (g_a24T7, gpart_a24UV) = Genome.Split.split gpart_a24UU
                            p_a24T6 = double g_a24T5
                            (g_a24T5, gpart_a24UU) = Genome.Split.split gpart_a24UT
                            p_a24T4 = Functions.belowten' g_a24T3
                            (g_a24T3, gpart_a24UT) = Genome.Split.split gpart_a24US
                            p_a24T2 = double g_a24T1
                            (g_a24T1, gpart_a24US) = Genome.Split.split gpart_a24UR
                            p_a24T0 = Functions.belowten' g_a24SZ
                            (g_a24SZ, gpart_a24UR) = Genome.Split.split gpart_a24UQ
                            p_a24SY = double g_a24SX
                            (g_a24SX, gpart_a24UQ) = Genome.Split.split gpart_a24UP
                            p_a24SW = double g_a24SV
                            (g_a24SV, gpart_a24UP) = Genome.Split.split gpart_a24UO
                            p_a24SU = double g_a24ST
                            (g_a24ST, gpart_a24UO) = Genome.Split.split gpart_a24UN
                            p_a24SS = Functions.belowten' g_a24SR
                            (g_a24SR, gpart_a24UN) = Genome.Split.split gpart_a24UM
                            p_a24SQ = double g_a24SP
                            (g_a24SP, gpart_a24UM) = Genome.Split.split gpart_a24UL
                            p_a24SO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SN
                            (g_a24SN, gpart_a24UL) = Genome.Split.split gpart_a24UK
                            p_a24SM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24SL
                            (g_a24SL, gpart_a24UK) = Genome.Split.split gpart_a24UJ
                            p_a24SK = Functions.belowten' g_a24SJ
                            (g_a24SJ, gpart_a24UJ) = Genome.Split.split gpart_a24UI
                            p_a24SI = double g_a24SH
                            (g_a24SH, gpart_a24UI) = Genome.Split.split gpart_a24UH
                            p_a24SG = double g_a24SF
                            (g_a24SF, gpart_a24UH) = Genome.Split.split gpart_a24UG
                            p_a24SE = double g_a24SD
                            (g_a24SD, gpart_a24UG) = Genome.Split.split gpart_a24UF
                            p_a24SC = Functions.belowten' g_a24SB
                            (g_a24SB, gpart_a24UF) = Genome.Split.split gpart_a24UE
                            p_a24SA = double g_a24Sz
                            (g_a24Sz, gpart_a24UE) = Genome.Split.split gpart_a24UD
                            p_a24Sy = Functions.belowten' g_a24Sx
                            (g_a24Sx, gpart_a24UD) = Genome.Split.split gpart_a24UC
                            p_a24Sw = double g_a24Sv
                            (g_a24Sv, gpart_a24UC) = Genome.Split.split gpart_a24UB
                            p_a24Su
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24St
                            (g_a24St, gpart_a24UB) = Genome.Split.split gpart_a24UA
                            p_a24Ss
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Sr
                            (g_a24Sr, gpart_a24UA) = Genome.Split.split gpart_a24Uz
                            p_a24Sq = double g_a24Sp
                            (g_a24Sp, gpart_a24Uz) = Genome.Split.split gpart_a24Uy
                            p_a24So = Functions.belowten' g_a24Sn
                            (g_a24Sn, gpart_a24Uy) = Genome.Split.split gpart_a24Ux
                            p_a24Sm = double g_a24Sl
                            (g_a24Sl, gpart_a24Ux) = Genome.Split.split gpart_a24Uw
                            p_a24Sk = Functions.belowten' g_a24Sj
                            (g_a24Sj, gpart_a24Uw) = Genome.Split.split gpart_a24Uv
                            p_a24Si = double g_a24Sh
                            (g_a24Sh, gpart_a24Uv) = Genome.Split.split gpart_a24Uu
                            p_a24Sg = double g_a24Sf
                            (g_a24Sf, gpart_a24Uu) = Genome.Split.split gpart_a24Ut
                            p_a24Se = Functions.belowten' g_a24Sd
                            (g_a24Sd, gpart_a24Ut) = Genome.Split.split gpart_a24Us
                            p_a24Sc = double g_a24Sb
                            (g_a24Sb, gpart_a24Us) = Genome.Split.split gpart_a24Ur
                            p_a24Sa
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S9
                            (g_a24S9, gpart_a24Ur) = Genome.Split.split gpart_a24Uq
                            p_a24S8
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24S7
                            (g_a24S7, gpart_a24Uq) = Genome.Split.split gpart_a24Up
                            p_a24S6 = double g_a24S5
                            (g_a24S5, gpart_a24Up) = Genome.Split.split gpart_a24Uo
                            p_a24S4 = double g_a24S3
                            (g_a24S3, gpart_a24Uo) = Genome.Split.split gpart_a24Un
                            p_a24S2 = double g_a24S1
                            (g_a24S1, gpart_a24Un) = Genome.Split.split gpart_a24Um
                            p_a24S0 = double g_a24RZ
                            (g_a24RZ, gpart_a24Um) = Genome.Split.split gpart_a24Ul
                            p_a24RY = double g_a24RX
                            (g_a24RX, gpart_a24Ul) = Genome.Split.split genome_a24Th
                          in
                            \ desc_a24Ti
                              -> case desc_a24Ti of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24RY)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S0)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S2)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S4)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S6)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24S8)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sa)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sc)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Se)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sg)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Si)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sk)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sm)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24So)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sq)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ss)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Su)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sw)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Sy)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SA)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SC)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SE)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SG)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SI)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SK)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SM)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SO)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SQ)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SS)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SU)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SW)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24SY)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T0)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T2)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T4)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T6)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24T8)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ta)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tc)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Te)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Tg)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a24Xt
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Y9
                      p_a24Xs = double g_a24Xr
                      (g_a24Xr, gpart_a24Y9) = Genome.Split.split gpart_a24Y8
                      p_a24Xq = double g_a24Xp
                      (g_a24Xp, gpart_a24Y8) = Genome.Split.split gpart_a24Y7
                      p_a24Xo = double g_a24Xn
                      (g_a24Xn, gpart_a24Y7) = Genome.Split.split gpart_a24Y6
                      p_a24Xm = double g_a24Xl
                      (g_a24Xl, gpart_a24Y6) = Genome.Split.split gpart_a24Y5
                      p_a24Xk = double g_a24Xj
                      (g_a24Xj, gpart_a24Y5) = Genome.Split.split gpart_a24Y4
                      p_a24Xi = double g_a24Xh
                      (g_a24Xh, gpart_a24Y4) = Genome.Split.split gpart_a24Y3
                      p_a24Xg = Functions.belowten' g_a24Xf
                      (g_a24Xf, gpart_a24Y3) = Genome.Split.split gpart_a24Y2
                      p_a24Xe = double g_a24Xd
                      (g_a24Xd, gpart_a24Y2) = Genome.Split.split gpart_a24Y1
                      p_a24Xc = Functions.belowten' g_a24Xb
                      (g_a24Xb, gpart_a24Y1) = Genome.Split.split gpart_a24Y0
                      p_a24Xa = double g_a24X9
                      (g_a24X9, gpart_a24Y0) = Genome.Split.split gpart_a24XZ
                      p_a24X8 = double g_a24X7
                      (g_a24X7, gpart_a24XZ) = Genome.Split.split gpart_a24XY
                      p_a24X6 = double g_a24X5
                      (g_a24X5, gpart_a24XY) = Genome.Split.split gpart_a24XX
                      p_a24X4 = Functions.belowten' g_a24X3
                      (g_a24X3, gpart_a24XX) = Genome.Split.split gpart_a24XW
                      p_a24X2 = double g_a24X1
                      (g_a24X1, gpart_a24XW) = Genome.Split.split gpart_a24XV
                      p_a24X0
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WZ
                      (g_a24WZ, gpart_a24XV) = Genome.Split.split gpart_a24XU
                      p_a24WY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WX
                      (g_a24WX, gpart_a24XU) = Genome.Split.split gpart_a24XT
                      p_a24WW = Functions.belowten' g_a24WV
                      (g_a24WV, gpart_a24XT) = Genome.Split.split gpart_a24XS
                      p_a24WU = double g_a24WT
                      (g_a24WT, gpart_a24XS) = Genome.Split.split gpart_a24XR
                      p_a24WS = double g_a24WR
                      (g_a24WR, gpart_a24XR) = Genome.Split.split gpart_a24XQ
                      p_a24WQ = double g_a24WP
                      (g_a24WP, gpart_a24XQ) = Genome.Split.split gpart_a24XP
                      p_a24WO = Functions.belowten' g_a24WN
                      (g_a24WN, gpart_a24XP) = Genome.Split.split gpart_a24XO
                      p_a24WM = double g_a24WL
                      (g_a24WL, gpart_a24XO) = Genome.Split.split gpart_a24XN
                      p_a24WK = Functions.belowten' g_a24WJ
                      (g_a24WJ, gpart_a24XN) = Genome.Split.split gpart_a24XM
                      p_a24WI = double g_a24WH
                      (g_a24WH, gpart_a24XM) = Genome.Split.split gpart_a24XL
                      p_a24WG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WF
                      (g_a24WF, gpart_a24XL) = Genome.Split.split gpart_a24XK
                      p_a24WE
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                      (g_a24WD, gpart_a24XK) = Genome.Split.split gpart_a24XJ
                      p_a24WC = double g_a24WB
                      (g_a24WB, gpart_a24XJ) = Genome.Split.split gpart_a24XI
                      p_a24WA = Functions.belowten' g_a24Wz
                      (g_a24Wz, gpart_a24XI) = Genome.Split.split gpart_a24XH
                      p_a24Wy = double g_a24Wx
                      (g_a24Wx, gpart_a24XH) = Genome.Split.split gpart_a24XG
                      p_a24Ww = Functions.belowten' g_a24Wv
                      (g_a24Wv, gpart_a24XG) = Genome.Split.split gpart_a24XF
                      p_a24Wu = double g_a24Wt
                      (g_a24Wt, gpart_a24XF) = Genome.Split.split gpart_a24XE
                      p_a24Ws = double g_a24Wr
                      (g_a24Wr, gpart_a24XE) = Genome.Split.split gpart_a24XD
                      p_a24Wq = Functions.belowten' g_a24Wp
                      (g_a24Wp, gpart_a24XD) = Genome.Split.split gpart_a24XC
                      p_a24Wo = double g_a24Wn
                      (g_a24Wn, gpart_a24XC) = Genome.Split.split gpart_a24XB
                      p_a24Wm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wl
                      (g_a24Wl, gpart_a24XB) = Genome.Split.split gpart_a24XA
                      p_a24Wk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                      (g_a24Wj, gpart_a24XA) = Genome.Split.split gpart_a24Xz
                      p_a24Wi = double g_a24Wh
                      (g_a24Wh, gpart_a24Xz) = Genome.Split.split gpart_a24Xy
                      p_a24Wg = double g_a24Wf
                      (g_a24Wf, gpart_a24Xy) = Genome.Split.split gpart_a24Xx
                      p_a24We = double g_a24Wd
                      (g_a24Wd, gpart_a24Xx) = Genome.Split.split gpart_a24Xw
                      p_a24Wc = double g_a24Wb
                      (g_a24Wb, gpart_a24Xw) = Genome.Split.split gpart_a24Xv
                      p_a24Wa = double g_a24W9
                      (g_a24W9, gpart_a24Xv) = Genome.Split.split genome_a24Xt
                    in  \ x_a24Ya
                          -> let
                               c_PTB_a24Yd
                                 = ((Data.Fixed.Vector.toVector x_a24Ya) Data.Vector.Unboxed.! 0)
                               c_MiRs_a24Yb
                                 = ((Data.Fixed.Vector.toVector x_a24Ya) Data.Vector.Unboxed.! 2)
                               c_NPTB_a24Yh
                                 = ((Data.Fixed.Vector.toVector x_a24Ya) Data.Vector.Unboxed.! 1)
                               c_RESTc_a24Yk
                                 = ((Data.Fixed.Vector.toVector x_a24Ya) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a24Yw
                                 = ((Data.Fixed.Vector.toVector x_a24Ya) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a24Wi / (1 + ((c_MiRs_a24Yb / p_a24Wo) ** p_a24Wq)))
                                    + (negate (p_a24Xk * c_PTB_a24Yd))),
                                   ((p_a24Ws
                                     / (1
                                        + (((c_MiRs_a24Yb / p_a24Wu) ** p_a24Ww)
                                           + ((c_PTB_a24Yd / p_a24Wy) ** p_a24WA))))
                                    + (negate (p_a24Xm * c_NPTB_a24Yh))),
                                   ((p_a24WC
                                     * ((p_a24WQ + ((c_PTB_a24Yd / p_a24WI) ** p_a24WK))
                                        / (((1 + p_a24WQ) + ((c_PTB_a24Yd / p_a24WI) ** p_a24WK))
                                           + ((c_RESTc_a24Yk / p_a24WM) ** p_a24WO))))
                                    + (negate (p_a24Xo * c_MiRs_a24Yb))),
                                   ((p_a24WS
                                     * ((p_a24X6 + ((c_PTB_a24Yd / p_a24WU) ** p_a24WW))
                                        / (((1 + p_a24X6) + ((c_PTB_a24Yd / p_a24WU) ** p_a24WW))
                                           + ((c_MiRs_a24Yb / p_a24X2) ** p_a24X4))))
                                    + (negate (p_a24Xq * c_RESTc_a24Yk))),
                                   ((p_a24X8
                                     * ((p_a24Xi + ((c_MiRs_a24Yb / p_a24Xa) ** p_a24Xc))
                                        / (((1 + p_a24Xi) + ((c_MiRs_a24Yb / p_a24Xa) ** p_a24Xc))
                                           + ((c_RESTc_a24Yk / p_a24Xe) ** p_a24Xg))))
                                    + (negate (p_a24Xs * c_EndoNeuroTFs_a24Yw)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505440",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505442",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505460",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505462",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505469",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505470",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505471",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505472",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505473",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505474",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505475",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505476",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505477",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505478",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505479",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505480",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505481",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505482",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505483",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505484",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505485",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505486",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505487",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505488",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505489",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505490",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505491",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505492",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505493",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505494",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505495",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505496",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505497",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505498",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505499",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505500",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505501",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505502",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505503",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505504",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505505",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505506",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505507",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505508",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505509",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505510",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a24Xt
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a24Zb
                            p_a24Xs = double g_a24Xr
                            (g_a24Xr, gpart_a24Zb) = Genome.Split.split gpart_a24Za
                            p_a24Xq = double g_a24Xp
                            (g_a24Xp, gpart_a24Za) = Genome.Split.split gpart_a24Z9
                            p_a24Xo = double g_a24Xn
                            (g_a24Xn, gpart_a24Z9) = Genome.Split.split gpart_a24Z8
                            p_a24Xm = double g_a24Xl
                            (g_a24Xl, gpart_a24Z8) = Genome.Split.split gpart_a24Z7
                            p_a24Xk = double g_a24Xj
                            (g_a24Xj, gpart_a24Z7) = Genome.Split.split gpart_a24Z6
                            p_a24Xi = double g_a24Xh
                            (g_a24Xh, gpart_a24Z6) = Genome.Split.split gpart_a24Z5
                            p_a24Xg = Functions.belowten' g_a24Xf
                            (g_a24Xf, gpart_a24Z5) = Genome.Split.split gpart_a24Z4
                            p_a24Xe = double g_a24Xd
                            (g_a24Xd, gpart_a24Z4) = Genome.Split.split gpart_a24Z3
                            p_a24Xc = Functions.belowten' g_a24Xb
                            (g_a24Xb, gpart_a24Z3) = Genome.Split.split gpart_a24Z2
                            p_a24Xa = double g_a24X9
                            (g_a24X9, gpart_a24Z2) = Genome.Split.split gpart_a24Z1
                            p_a24X8 = double g_a24X7
                            (g_a24X7, gpart_a24Z1) = Genome.Split.split gpart_a24Z0
                            p_a24X6 = double g_a24X5
                            (g_a24X5, gpart_a24Z0) = Genome.Split.split gpart_a24YZ
                            p_a24X4 = Functions.belowten' g_a24X3
                            (g_a24X3, gpart_a24YZ) = Genome.Split.split gpart_a24YY
                            p_a24X2 = double g_a24X1
                            (g_a24X1, gpart_a24YY) = Genome.Split.split gpart_a24YX
                            p_a24X0
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WZ
                            (g_a24WZ, gpart_a24YX) = Genome.Split.split gpart_a24YW
                            p_a24WY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WX
                            (g_a24WX, gpart_a24YW) = Genome.Split.split gpart_a24YV
                            p_a24WW = Functions.belowten' g_a24WV
                            (g_a24WV, gpart_a24YV) = Genome.Split.split gpart_a24YU
                            p_a24WU = double g_a24WT
                            (g_a24WT, gpart_a24YU) = Genome.Split.split gpart_a24YT
                            p_a24WS = double g_a24WR
                            (g_a24WR, gpart_a24YT) = Genome.Split.split gpart_a24YS
                            p_a24WQ = double g_a24WP
                            (g_a24WP, gpart_a24YS) = Genome.Split.split gpart_a24YR
                            p_a24WO = Functions.belowten' g_a24WN
                            (g_a24WN, gpart_a24YR) = Genome.Split.split gpart_a24YQ
                            p_a24WM = double g_a24WL
                            (g_a24WL, gpart_a24YQ) = Genome.Split.split gpart_a24YP
                            p_a24WK = Functions.belowten' g_a24WJ
                            (g_a24WJ, gpart_a24YP) = Genome.Split.split gpart_a24YO
                            p_a24WI = double g_a24WH
                            (g_a24WH, gpart_a24YO) = Genome.Split.split gpart_a24YN
                            p_a24WG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WF
                            (g_a24WF, gpart_a24YN) = Genome.Split.split gpart_a24YM
                            p_a24WE
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24WD
                            (g_a24WD, gpart_a24YM) = Genome.Split.split gpart_a24YL
                            p_a24WC = double g_a24WB
                            (g_a24WB, gpart_a24YL) = Genome.Split.split gpart_a24YK
                            p_a24WA = Functions.belowten' g_a24Wz
                            (g_a24Wz, gpart_a24YK) = Genome.Split.split gpart_a24YJ
                            p_a24Wy = double g_a24Wx
                            (g_a24Wx, gpart_a24YJ) = Genome.Split.split gpart_a24YI
                            p_a24Ww = Functions.belowten' g_a24Wv
                            (g_a24Wv, gpart_a24YI) = Genome.Split.split gpart_a24YH
                            p_a24Wu = double g_a24Wt
                            (g_a24Wt, gpart_a24YH) = Genome.Split.split gpart_a24YG
                            p_a24Ws = double g_a24Wr
                            (g_a24Wr, gpart_a24YG) = Genome.Split.split gpart_a24YF
                            p_a24Wq = Functions.belowten' g_a24Wp
                            (g_a24Wp, gpart_a24YF) = Genome.Split.split gpart_a24YE
                            p_a24Wo = double g_a24Wn
                            (g_a24Wn, gpart_a24YE) = Genome.Split.split gpart_a24YD
                            p_a24Wm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wl
                            (g_a24Wl, gpart_a24YD) = Genome.Split.split gpart_a24YC
                            p_a24Wk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a24Wj
                            (g_a24Wj, gpart_a24YC) = Genome.Split.split gpart_a24YB
                            p_a24Wi = double g_a24Wh
                            (g_a24Wh, gpart_a24YB) = Genome.Split.split gpart_a24YA
                            p_a24Wg = double g_a24Wf
                            (g_a24Wf, gpart_a24YA) = Genome.Split.split gpart_a24Yz
                            p_a24We = double g_a24Wd
                            (g_a24Wd, gpart_a24Yz) = Genome.Split.split gpart_a24Yy
                            p_a24Wc = double g_a24Wb
                            (g_a24Wb, gpart_a24Yy) = Genome.Split.split gpart_a24Yx
                            p_a24Wa = double g_a24W9
                            (g_a24W9, gpart_a24Yx) = Genome.Split.split genome_a24Xt
                          in
                            \ desc_a24Xu
                              -> case desc_a24Xu of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wa)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wc)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24We)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wg)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wi)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wk)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wm)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wo)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wq)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ws)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wu)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Ww)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Wy)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WA)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WC)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WE)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WG)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WI)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WK)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WM)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WO)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WQ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WS)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WU)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WW)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24WY)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X0)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X2)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X4)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X6)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24X8)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xa)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xc)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xe)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xg)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xi)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xk)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xm)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xo)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xq)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a24Xs)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a251F
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a252l
                      p_a251E = double g_a251D
                      (g_a251D, gpart_a252l) = Genome.Split.split gpart_a252k
                      p_a251C = double g_a251B
                      (g_a251B, gpart_a252k) = Genome.Split.split gpart_a252j
                      p_a251A = double g_a251z
                      (g_a251z, gpart_a252j) = Genome.Split.split gpart_a252i
                      p_a251y = double g_a251x
                      (g_a251x, gpart_a252i) = Genome.Split.split gpart_a252h
                      p_a251w = double g_a251v
                      (g_a251v, gpart_a252h) = Genome.Split.split gpart_a252g
                      p_a251u = double g_a251t
                      (g_a251t, gpart_a252g) = Genome.Split.split gpart_a252f
                      p_a251s = Functions.belowten' g_a251r
                      (g_a251r, gpart_a252f) = Genome.Split.split gpart_a252e
                      p_a251q = double g_a251p
                      (g_a251p, gpart_a252e) = Genome.Split.split gpart_a252d
                      p_a251o = Functions.belowten' g_a251n
                      (g_a251n, gpart_a252d) = Genome.Split.split gpart_a252c
                      p_a251m = double g_a251l
                      (g_a251l, gpart_a252c) = Genome.Split.split gpart_a252b
                      p_a251k = double g_a251j
                      (g_a251j, gpart_a252b) = Genome.Split.split gpart_a252a
                      p_a251i = double g_a251h
                      (g_a251h, gpart_a252a) = Genome.Split.split gpart_a2529
                      p_a251g = Functions.belowten' g_a251f
                      (g_a251f, gpart_a2529) = Genome.Split.split gpart_a2528
                      p_a251e = double g_a251d
                      (g_a251d, gpart_a2528) = Genome.Split.split gpart_a2527
                      p_a251c
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251b
                      (g_a251b, gpart_a2527) = Genome.Split.split gpart_a2526
                      p_a251a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2519
                      (g_a2519, gpart_a2526) = Genome.Split.split gpart_a2525
                      p_a2518 = Functions.belowten' g_a2517
                      (g_a2517, gpart_a2525) = Genome.Split.split gpart_a2524
                      p_a2516 = double g_a2515
                      (g_a2515, gpart_a2524) = Genome.Split.split gpart_a2523
                      p_a2514 = double g_a2513
                      (g_a2513, gpart_a2523) = Genome.Split.split gpart_a2522
                      p_a2512 = double g_a2511
                      (g_a2511, gpart_a2522) = Genome.Split.split gpart_a2521
                      p_a2510 = Functions.belowten' g_a250Z
                      (g_a250Z, gpart_a2521) = Genome.Split.split gpart_a2520
                      p_a250Y = double g_a250X
                      (g_a250X, gpart_a2520) = Genome.Split.split gpart_a251Z
                      p_a250W = Functions.belowten' g_a250V
                      (g_a250V, gpart_a251Z) = Genome.Split.split gpart_a251Y
                      p_a250U = double g_a250T
                      (g_a250T, gpart_a251Y) = Genome.Split.split gpart_a251X
                      p_a250S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250R
                      (g_a250R, gpart_a251X) = Genome.Split.split gpart_a251W
                      p_a250Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                      (g_a250P, gpart_a251W) = Genome.Split.split gpart_a251V
                      p_a250O = double g_a250N
                      (g_a250N, gpart_a251V) = Genome.Split.split gpart_a251U
                      p_a250M = Functions.belowten' g_a250L
                      (g_a250L, gpart_a251U) = Genome.Split.split gpart_a251T
                      p_a250K = double g_a250J
                      (g_a250J, gpart_a251T) = Genome.Split.split gpart_a251S
                      p_a250I = Functions.belowten' g_a250H
                      (g_a250H, gpart_a251S) = Genome.Split.split gpart_a251R
                      p_a250G = double g_a250F
                      (g_a250F, gpart_a251R) = Genome.Split.split gpart_a251Q
                      p_a250E = double g_a250D
                      (g_a250D, gpart_a251Q) = Genome.Split.split gpart_a251P
                      p_a250C = Functions.belowten' g_a250B
                      (g_a250B, gpart_a251P) = Genome.Split.split gpart_a251O
                      p_a250A = double g_a250z
                      (g_a250z, gpart_a251O) = Genome.Split.split gpart_a251N
                      p_a250y
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250x
                      (g_a250x, gpart_a251N) = Genome.Split.split gpart_a251M
                      p_a250w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250v
                      (g_a250v, gpart_a251M) = Genome.Split.split gpart_a251L
                      p_a250u = double g_a250t
                      (g_a250t, gpart_a251L) = Genome.Split.split gpart_a251K
                      p_a250s = double g_a250r
                      (g_a250r, gpart_a251K) = Genome.Split.split gpart_a251J
                      p_a250q = double g_a250p
                      (g_a250p, gpart_a251J) = Genome.Split.split gpart_a251I
                      p_a250o = double g_a250n
                      (g_a250n, gpart_a251I) = Genome.Split.split gpart_a251H
                      p_a250m = double g_a250l
                      (g_a250l, gpart_a251H) = Genome.Split.split genome_a251F
                    in  \ x_a252m
                          -> let
                               c_PTB_a252p
                                 = ((Data.Fixed.Vector.toVector x_a252m) Data.Vector.Unboxed.! 0)
                               c_MiRs_a252n
                                 = ((Data.Fixed.Vector.toVector x_a252m) Data.Vector.Unboxed.! 2)
                               c_NPTB_a252t
                                 = ((Data.Fixed.Vector.toVector x_a252m) Data.Vector.Unboxed.! 1)
                               c_RESTc_a252w
                                 = ((Data.Fixed.Vector.toVector x_a252m) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a252I
                                 = ((Data.Fixed.Vector.toVector x_a252m) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a250u
                                     / (1
                                        + (((p_a250m / p_a250w) ** p_a250y)
                                           + ((c_MiRs_a252n / p_a250A) ** p_a250C))))
                                    + (negate (p_a251w * c_PTB_a252p))),
                                   ((p_a250E
                                     / (1
                                        + (((c_MiRs_a252n / p_a250G) ** p_a250I)
                                           + ((c_PTB_a252p / p_a250K) ** p_a250M))))
                                    + (negate (p_a251y * c_NPTB_a252t))),
                                   ((p_a250O
                                     * ((p_a2512 + ((c_PTB_a252p / p_a250U) ** p_a250W))
                                        / (((1 + p_a2512) + ((c_PTB_a252p / p_a250U) ** p_a250W))
                                           + ((c_RESTc_a252w / p_a250Y) ** p_a2510))))
                                    + (negate (p_a251A * c_MiRs_a252n))),
                                   ((p_a2514
                                     * ((p_a251i + ((c_PTB_a252p / p_a2516) ** p_a2518))
                                        / (((1 + p_a251i) + ((c_PTB_a252p / p_a2516) ** p_a2518))
                                           + ((c_MiRs_a252n / p_a251e) ** p_a251g))))
                                    + (negate (p_a251C * c_RESTc_a252w))),
                                   ((p_a251k
                                     * ((p_a251u + ((c_MiRs_a252n / p_a251m) ** p_a251o))
                                        / (((1 + p_a251u) + ((c_MiRs_a252n / p_a251m) ** p_a251o))
                                           + ((c_RESTc_a252w / p_a251q) ** p_a251s))))
                                    + (negate (p_a251E * c_EndoNeuroTFs_a252I)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505689",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505690",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505691",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505692",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505693",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505694",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505695",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505696",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505697",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505698",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505699",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505700",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505701",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505702",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505703",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505704",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505705",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505706",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505707",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505708",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505709",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505710",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505711",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505712",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505713",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505714",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505715",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505716",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505717",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505718",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505719",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505720",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505721",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505722",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505723",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505724",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505725",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505726",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505727",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505728",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505729",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505730",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505731",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505732",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505733",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505734",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505735",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505736",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505737",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505738",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505739",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505740",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505741",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505742",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505743",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505744",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505745",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505746",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505747",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505748",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505749",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505750",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505751",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505752",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505753",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505754",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505755",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505756",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505757",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505758",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505759",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505760",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505761",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505762",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505763",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505764",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505765",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505766",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505767",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505768",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679505769",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679505770",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a251F
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a253n
                            p_a251E = double g_a251D
                            (g_a251D, gpart_a253n) = Genome.Split.split gpart_a253m
                            p_a251C = double g_a251B
                            (g_a251B, gpart_a253m) = Genome.Split.split gpart_a253l
                            p_a251A = double g_a251z
                            (g_a251z, gpart_a253l) = Genome.Split.split gpart_a253k
                            p_a251y = double g_a251x
                            (g_a251x, gpart_a253k) = Genome.Split.split gpart_a253j
                            p_a251w = double g_a251v
                            (g_a251v, gpart_a253j) = Genome.Split.split gpart_a253i
                            p_a251u = double g_a251t
                            (g_a251t, gpart_a253i) = Genome.Split.split gpart_a253h
                            p_a251s = Functions.belowten' g_a251r
                            (g_a251r, gpart_a253h) = Genome.Split.split gpart_a253g
                            p_a251q = double g_a251p
                            (g_a251p, gpart_a253g) = Genome.Split.split gpart_a253f
                            p_a251o = Functions.belowten' g_a251n
                            (g_a251n, gpart_a253f) = Genome.Split.split gpart_a253e
                            p_a251m = double g_a251l
                            (g_a251l, gpart_a253e) = Genome.Split.split gpart_a253d
                            p_a251k = double g_a251j
                            (g_a251j, gpart_a253d) = Genome.Split.split gpart_a253c
                            p_a251i = double g_a251h
                            (g_a251h, gpart_a253c) = Genome.Split.split gpart_a253b
                            p_a251g = Functions.belowten' g_a251f
                            (g_a251f, gpart_a253b) = Genome.Split.split gpart_a253a
                            p_a251e = double g_a251d
                            (g_a251d, gpart_a253a) = Genome.Split.split gpart_a2539
                            p_a251c
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a251b
                            (g_a251b, gpart_a2539) = Genome.Split.split gpart_a2538
                            p_a251a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a2519
                            (g_a2519, gpart_a2538) = Genome.Split.split gpart_a2537
                            p_a2518 = Functions.belowten' g_a2517
                            (g_a2517, gpart_a2537) = Genome.Split.split gpart_a2536
                            p_a2516 = double g_a2515
                            (g_a2515, gpart_a2536) = Genome.Split.split gpart_a2535
                            p_a2514 = double g_a2513
                            (g_a2513, gpart_a2535) = Genome.Split.split gpart_a2534
                            p_a2512 = double g_a2511
                            (g_a2511, gpart_a2534) = Genome.Split.split gpart_a2533
                            p_a2510 = Functions.belowten' g_a250Z
                            (g_a250Z, gpart_a2533) = Genome.Split.split gpart_a2532
                            p_a250Y = double g_a250X
                            (g_a250X, gpart_a2532) = Genome.Split.split gpart_a2531
                            p_a250W = Functions.belowten' g_a250V
                            (g_a250V, gpart_a2531) = Genome.Split.split gpart_a2530
                            p_a250U = double g_a250T
                            (g_a250T, gpart_a2530) = Genome.Split.split gpart_a252Z
                            p_a250S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250R
                            (g_a250R, gpart_a252Z) = Genome.Split.split gpart_a252Y
                            p_a250Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250P
                            (g_a250P, gpart_a252Y) = Genome.Split.split gpart_a252X
                            p_a250O = double g_a250N
                            (g_a250N, gpart_a252X) = Genome.Split.split gpart_a252W
                            p_a250M = Functions.belowten' g_a250L
                            (g_a250L, gpart_a252W) = Genome.Split.split gpart_a252V
                            p_a250K = double g_a250J
                            (g_a250J, gpart_a252V) = Genome.Split.split gpart_a252U
                            p_a250I = Functions.belowten' g_a250H
                            (g_a250H, gpart_a252U) = Genome.Split.split gpart_a252T
                            p_a250G = double g_a250F
                            (g_a250F, gpart_a252T) = Genome.Split.split gpart_a252S
                            p_a250E = double g_a250D
                            (g_a250D, gpart_a252S) = Genome.Split.split gpart_a252R
                            p_a250C = Functions.belowten' g_a250B
                            (g_a250B, gpart_a252R) = Genome.Split.split gpart_a252Q
                            p_a250A = double g_a250z
                            (g_a250z, gpart_a252Q) = Genome.Split.split gpart_a252P
                            p_a250y
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250x
                            (g_a250x, gpart_a252P) = Genome.Split.split gpart_a252O
                            p_a250w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a250v
                            (g_a250v, gpart_a252O) = Genome.Split.split gpart_a252N
                            p_a250u = double g_a250t
                            (g_a250t, gpart_a252N) = Genome.Split.split gpart_a252M
                            p_a250s = double g_a250r
                            (g_a250r, gpart_a252M) = Genome.Split.split gpart_a252L
                            p_a250q = double g_a250p
                            (g_a250p, gpart_a252L) = Genome.Split.split gpart_a252K
                            p_a250o = double g_a250n
                            (g_a250n, gpart_a252K) = Genome.Split.split gpart_a252J
                            p_a250m = double g_a250l
                            (g_a250l, gpart_a252J) = Genome.Split.split genome_a251F
                          in
                            \ desc_a251G
                              -> case desc_a251G of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250m)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250o)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250q)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250s)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250u)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250w)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250y)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250A)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250C)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250E)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250G)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250I)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250K)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250M)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250O)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Q)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250S)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250U)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250W)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a250Y)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2510)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2512)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2514)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2516)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a2518)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251a)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251c)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251e)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251g)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251i)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251k)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251m)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251o)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251q)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251s)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251u)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251w)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251y)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251A)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251C)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a251E)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVu
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWa
                      p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                      (g_asVs, gpart_asWa) = Genome.Split.split gpart_asW9
                      p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                      (g_asVq, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                      (g_asVo, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                      (g_asVm, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                      (g_asVk, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                      (g_asVi, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asVh = Functions.belowten' g_asVg
                      (g_asVg, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asVf = code-0.1.0.0:Genome.FixedList.Functions.double g_asVe
                      (g_asVe, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asVd = Functions.belowten' g_asVc
                      (g_asVc, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                      (g_asVa, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                      (g_asV8, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asV5 = Functions.belowten' g_asV4
                      (g_asV4, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asV1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV0
                      (g_asV0, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                      (g_asUY, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUX = Functions.belowten' g_asUW
                      (g_asUW, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                      (g_asUU, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUP = Functions.belowten' g_asUO
                      (g_asUO, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                      (g_asUM, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUL = Functions.belowten' g_asUK
                      (g_asUK, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                      (g_asUI, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                      (g_asUG, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                      (g_asUE, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                      (g_asUC, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUB = Functions.belowten' g_asUA
                      (g_asUA, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUx = Functions.belowten' g_asUw
                      (g_asUw, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUr = Functions.belowten' g_asUq
                      (g_asUq, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                      (g_asUk, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                      (g_asUi, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVw) = Genome.Split.split genome_asVu
                    in
                      [Reaction
                         (\ x_asWb
                            -> let c_MiRs_asWc = ((toVector x_asWb) Data.Vector.Unboxed.! 2)
                               in (p_asUj / (1 + ((c_MiRs_asWc / p_asUp) ** p_asUr))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWd
                            -> let
                                 c_MiRs_asWe = ((toVector x_asWd) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWf = ((toVector x_asWd) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUt
                                  / (1
                                     + (((c_MiRs_asWe / p_asUv) ** p_asUx)
                                        + ((c_PTB_asWf / p_asUz) ** p_asUB)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWg
                            -> let
                                 c_RESTc_asWj = ((toVector x_asWg) Data.Vector.Unboxed.! 3)
                                 c_PTB_asWh = ((toVector x_asWg) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUD
                                  * ((p_asUR
                                      + (((p_asUf / p_asUF) ** p_asUH)
                                         + ((c_PTB_asWh / p_asUJ) ** p_asUL)))
                                     / (((1 + p_asUR)
                                         + (((p_asUf / p_asUF) ** p_asUH)
                                            + ((c_PTB_asWh / p_asUJ) ** p_asUL)))
                                        + ((c_RESTc_asWj / p_asUN) ** p_asUP)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWk
                            -> let
                                 c_MiRs_asWn = ((toVector x_asWk) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWl = ((toVector x_asWk) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUT
                                  * ((p_asV7 + ((c_PTB_asWl / p_asUV) ** p_asUX))
                                     / (((1 + p_asV7) + ((c_PTB_asWl / p_asUV) ** p_asUX))
                                        + (((p_asUb / p_asUZ) ** p_asV1)
                                           + ((c_MiRs_asWn / p_asV3) ** p_asV5))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWo
                            -> let
                                 c_RESTc_asWr = ((toVector x_asWo) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWp = ((toVector x_asWo) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asV9
                                  * ((p_asVj + ((c_MiRs_asWp / p_asVb) ** p_asVd))
                                     / (((1 + p_asVj) + ((c_MiRs_asWp / p_asVb) ** p_asVd))
                                        + ((c_RESTc_asWr / p_asVf) ** p_asVh)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWs
                            -> let c_PTB_asWt = ((toVector x_asWs) Data.Vector.Unboxed.! 0)
                               in (p_asVl * c_PTB_asWt))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWu
                            -> let c_NPTB_asWv = ((toVector x_asWu) Data.Vector.Unboxed.! 1)
                               in (p_asVn * c_NPTB_asWv))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWw
                            -> let c_MiRs_asWx = ((toVector x_asWw) Data.Vector.Unboxed.! 2)
                               in (p_asVp * c_MiRs_asWx))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWy
                            -> let c_RESTc_asWz = ((toVector x_asWy) Data.Vector.Unboxed.! 3)
                               in (p_asVr * c_RESTc_asWz))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWA
                            -> let
                                 c_EndoNeuroTFs_asWB = ((toVector x_asWA) Data.Vector.Unboxed.! 4)
                               in (p_asVt * c_EndoNeuroTFs_asWB))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120986",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120987",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVu
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXl
                            p_asVt = code-0.1.0.0:Genome.FixedList.Functions.double g_asVs
                            (g_asVs, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                            (g_asVq, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                            (g_asVo, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                            (g_asVm, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                            (g_asVk, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                            (g_asVi, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asVh = Functions.belowten' g_asVg
                            (g_asVg, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asVf = code-0.1.0.0:Genome.FixedList.Functions.double g_asVe
                            (g_asVe, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asVd = Functions.belowten' g_asVc
                            (g_asVc, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asVb = code-0.1.0.0:Genome.FixedList.Functions.double g_asVa
                            (g_asVa, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                            (g_asV8, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asV5 = Functions.belowten' g_asV4
                            (g_asV4, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asV1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asV0
                            (g_asV0, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                            (g_asUY, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUX = Functions.belowten' g_asUW
                            (g_asUW, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                            (g_asUU, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUP = Functions.belowten' g_asUO
                            (g_asUO, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                            (g_asUM, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUL = Functions.belowten' g_asUK
                            (g_asUK, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                            (g_asUI, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                            (g_asUG, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                            (g_asUE, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUD = code-0.1.0.0:Genome.FixedList.Functions.double g_asUC
                            (g_asUC, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUB = Functions.belowten' g_asUA
                            (g_asUA, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUx = Functions.belowten' g_asUw
                            (g_asUw, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUr = Functions.belowten' g_asUq
                            (g_asUq, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                            (g_asUk, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                            (g_asUi, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWH) = Genome.Split.split genome_asVu
                          in
                            \ desc_asVv
                              -> case desc_asVv of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV9)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVb)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVh)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVj)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVl)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVn)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVp)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVr)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVt)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at02
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at02) = Genome.Split.split gpart_at01
                      p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                      (g_asZi, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                      (g_asZe, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                      (g_asZa, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asZ9 = Functions.belowten' g_asZ8
                      (g_asZ8, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                      (g_asZ6, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asZ5 = Functions.belowten' g_asZ4
                      (g_asZ4, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                      (g_asYY, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYX = Functions.belowten' g_asYW
                      (g_asYW, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                      (g_asYU, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                      (g_asYS, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYQ
                      (g_asYQ, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYP = Functions.belowten' g_asYO
                      (g_asYO, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                      (g_asYI, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYH = Functions.belowten' g_asYG
                      (g_asYG, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                      (g_asYE, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYD = Functions.belowten' g_asYC
                      (g_asYC, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYz
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                      (g_asYy, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYx
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYw
                      (g_asYw, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                      (g_asYu, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYt = Functions.belowten' g_asYs
                      (g_asYs, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYp = Functions.belowten' g_asYo
                      (g_asYo, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                      (g_asYm, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYj = Functions.belowten' g_asYi
                      (g_asYi, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                      (g_asYg, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                      (g_asYe, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asYd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYc
                      (g_asYc, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asZq) = Genome.Split.split gpart_asZp
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asZp) = Genome.Split.split gpart_asZo
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asZo) = Genome.Split.split genome_asZm
                    in
                      [Reaction
                         (\ x_at03
                            -> let c_MiRs_at04 = ((toVector x_at03) Data.Vector.Unboxed.! 2)
                               in (p_asYb / (1 + ((c_MiRs_at04 / p_asYh) ** p_asYj))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at05
                            -> let
                                 c_MiRs_at06 = ((toVector x_at05) Data.Vector.Unboxed.! 2)
                                 c_PTB_at07 = ((toVector x_at05) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYl
                                  / (1
                                     + (((c_MiRs_at06 / p_asYn) ** p_asYp)
                                        + ((c_PTB_at07 / p_asYr) ** p_asYt)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at08
                            -> let
                                 c_RESTc_at0b = ((toVector x_at08) Data.Vector.Unboxed.! 3)
                                 c_PTB_at09 = ((toVector x_at08) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYv
                                  * ((p_asYJ + ((c_PTB_at09 / p_asYB) ** p_asYD))
                                     / (((1 + p_asYJ) + ((c_PTB_at09 / p_asYB) ** p_asYD))
                                        + ((c_RESTc_at0b / p_asYF) ** p_asYH)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0c
                            -> let
                                 c_MiRs_at0f = ((toVector x_at0c) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0d = ((toVector x_at0c) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYL
                                  * ((p_asYZ + ((c_PTB_at0d / p_asYN) ** p_asYP))
                                     / (((1 + p_asYZ) + ((c_PTB_at0d / p_asYN) ** p_asYP))
                                        + (((p_asY3 / p_asYR) ** p_asYT)
                                           + ((c_MiRs_at0f / p_asYV) ** p_asYX))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0g
                            -> let
                                 c_RESTc_at0j = ((toVector x_at0g) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0h = ((toVector x_at0g) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZ1
                                  * ((p_asZb + ((c_MiRs_at0h / p_asZ3) ** p_asZ5))
                                     / (((1 + p_asZb) + ((c_MiRs_at0h / p_asZ3) ** p_asZ5))
                                        + ((c_RESTc_at0j / p_asZ7) ** p_asZ9)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0k
                            -> let c_PTB_at0l = ((toVector x_at0k) Data.Vector.Unboxed.! 0)
                               in (p_asZd * c_PTB_at0l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0m
                            -> let c_NPTB_at0n = ((toVector x_at0m) Data.Vector.Unboxed.! 1)
                               in (p_asZf * c_NPTB_at0n))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0o
                            -> let c_MiRs_at0p = ((toVector x_at0o) Data.Vector.Unboxed.! 2)
                               in (p_asZh * c_MiRs_at0p))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0q
                            -> let c_RESTc_at0r = ((toVector x_at0q) Data.Vector.Unboxed.! 3)
                               in (p_asZj * c_RESTc_at0r))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0s
                            -> let
                                 c_EndoNeuroTFs_at0t = ((toVector x_at0s) Data.Vector.Unboxed.! 4)
                               in (p_asZl * c_EndoNeuroTFs_at0t))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at18
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at18) = Genome.Split.split gpart_at17
                            p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                            (g_asZi, gpart_at17) = Genome.Split.split gpart_at16
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                            (g_asZe, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at14) = Genome.Split.split gpart_at13
                            p_asZb = code-0.1.0.0:Genome.FixedList.Functions.double g_asZa
                            (g_asZa, gpart_at13) = Genome.Split.split gpart_at12
                            p_asZ9 = Functions.belowten' g_asZ8
                            (g_asZ8, gpart_at12) = Genome.Split.split gpart_at11
                            p_asZ7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ6
                            (g_asZ6, gpart_at11) = Genome.Split.split gpart_at10
                            p_asZ5 = Functions.belowten' g_asZ4
                            (g_asZ4, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYY
                            (g_asYY, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYX = Functions.belowten' g_asYW
                            (g_asYW, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYV = code-0.1.0.0:Genome.FixedList.Functions.double g_asYU
                            (g_asYU, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                            (g_asYS, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYQ
                            (g_asYQ, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYP = Functions.belowten' g_asYO
                            (g_asYO, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asYI
                            (g_asYI, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYH = Functions.belowten' g_asYG
                            (g_asYG, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYF = code-0.1.0.0:Genome.FixedList.Functions.double g_asYE
                            (g_asYE, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYD = Functions.belowten' g_asYC
                            (g_asYC, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYz
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYy
                            (g_asYy, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYx
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYw
                            (g_asYw, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYv = code-0.1.0.0:Genome.FixedList.Functions.double g_asYu
                            (g_asYu, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYt = Functions.belowten' g_asYs
                            (g_asYs, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYp = Functions.belowten' g_asYo
                            (g_asYo, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYn = code-0.1.0.0:Genome.FixedList.Functions.double g_asYm
                            (g_asYm, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYj = Functions.belowten' g_asYi
                            (g_asYi, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYh = code-0.1.0.0:Genome.FixedList.Functions.double g_asYg
                            (g_asYg, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asYf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYe
                            (g_asYe, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asYd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYc
                            (g_asYc, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at0x) = Genome.Split.split gpart_at0w
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_at0w) = Genome.Split.split gpart_at0v
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_at0v) = Genome.Split.split gpart_at0u
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at0u) = Genome.Split.split genome_asZm
                          in
                            \ desc_asZn
                              -> case desc_asZn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at39
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3P
                      p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                      (g_at37, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                      (g_at33, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                      (g_at31, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                      (g_at2X, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2W = Functions.belowten' g_at2V
                      (g_at2V, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                      (g_at2T, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2S = Functions.belowten' g_at2R
                      (g_at2R, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                      (g_at2P, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                      (g_at2L, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2K = Functions.belowten' g_at2J
                      (g_at2J, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                      (g_at2H, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2G
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2F
                      (g_at2F, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2E
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2D
                      (g_at2D, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2C = Functions.belowten' g_at2B
                      (g_at2B, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                      (g_at2z, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                      (g_at2v, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2u = Functions.belowten' g_at2t
                      (g_at2t, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                      (g_at2r, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2q = Functions.belowten' g_at2p
                      (g_at2p, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2m
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                      (g_at2l, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2k
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2j
                      (g_at2j, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at2g = Functions.belowten' g_at2f
                      (g_at2f, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at2c = Functions.belowten' g_at2b
                      (g_at2b, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                      (g_at29, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                      (g_at27, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at26 = Functions.belowten' g_at25
                      (g_at25, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at22
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at21
                      (g_at21, gpart_at3h) = Genome.Split.split gpart_at3g
                      p_at20
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                      (g_at1Z, gpart_at3g) = Genome.Split.split gpart_at3f
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at3f) = Genome.Split.split gpart_at3e
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at3e) = Genome.Split.split gpart_at3d
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at3d) = Genome.Split.split gpart_at3c
                      p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                      (g_at1R, gpart_at3c) = Genome.Split.split gpart_at3b
                      p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                      (g_at1P, gpart_at3b) = Genome.Split.split genome_at39
                    in
                      [Reaction
                         (\ x_at3Q
                            -> let c_MiRs_at3R = ((toVector x_at3Q) Data.Vector.Unboxed.! 2)
                               in (p_at1Y / (1 + ((c_MiRs_at3R / p_at24) ** p_at26))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3S
                            -> let
                                 c_MiRs_at3T = ((toVector x_at3S) Data.Vector.Unboxed.! 2)
                                 c_PTB_at3U = ((toVector x_at3S) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at28
                                  / (1
                                     + (((c_MiRs_at3T / p_at2a) ** p_at2c)
                                        + ((c_PTB_at3U / p_at2e) ** p_at2g)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at3V
                            -> let
                                 c_RESTc_at3Y = ((toVector x_at3V) Data.Vector.Unboxed.! 3)
                                 c_PTB_at3W = ((toVector x_at3V) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2i
                                  * ((p_at2w + ((c_PTB_at3W / p_at2o) ** p_at2q))
                                     / (((1 + p_at2w) + ((c_PTB_at3W / p_at2o) ** p_at2q))
                                        + ((c_RESTc_at3Y / p_at2s) ** p_at2u)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at3Z
                            -> let
                                 c_MiRs_at42 = ((toVector x_at3Z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at40 = ((toVector x_at3Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2y
                                  * ((p_at2M + ((c_PTB_at40 / p_at2A) ** p_at2C))
                                     / (((1 + p_at2M) + ((c_PTB_at40 / p_at2A) ** p_at2C))
                                        + ((c_MiRs_at42 / p_at2I) ** p_at2K)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at43
                            -> let
                                 c_RESTc_at46 = ((toVector x_at43) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at44 = ((toVector x_at43) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2O
                                  * ((p_at2Y + ((c_MiRs_at44 / p_at2Q) ** p_at2S))
                                     / (((1 + p_at2Y) + ((c_MiRs_at44 / p_at2Q) ** p_at2S))
                                        + ((c_RESTc_at46 / p_at2U) ** p_at2W)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at47
                            -> let c_PTB_at48 = ((toVector x_at47) Data.Vector.Unboxed.! 0)
                               in (p_at30 * c_PTB_at48))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at49
                            -> let c_NPTB_at4a = ((toVector x_at49) Data.Vector.Unboxed.! 1)
                               in (p_at32 * c_NPTB_at4a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4b
                            -> let c_MiRs_at4c = ((toVector x_at4b) Data.Vector.Unboxed.! 2)
                               in (p_at34 * c_MiRs_at4c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4d
                            -> let c_RESTc_at4e = ((toVector x_at4d) Data.Vector.Unboxed.! 3)
                               in (p_at36 * c_RESTc_at4e))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4f
                            -> let
                                 c_EndoNeuroTFs_at4g = ((toVector x_at4f) Data.Vector.Unboxed.! 4)
                               in (p_at38 * c_EndoNeuroTFs_at4g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at39
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at4V
                            p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                            (g_at37, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                            (g_at33, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at32 = code-0.1.0.0:Genome.FixedList.Functions.double g_at31
                            (g_at31, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2X
                            (g_at2X, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2W = Functions.belowten' g_at2V
                            (g_at2V, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                            (g_at2T, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2S = Functions.belowten' g_at2R
                            (g_at2R, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at2P
                            (g_at2P, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2M = code-0.1.0.0:Genome.FixedList.Functions.double g_at2L
                            (g_at2L, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2K = Functions.belowten' g_at2J
                            (g_at2J, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2I = code-0.1.0.0:Genome.FixedList.Functions.double g_at2H
                            (g_at2H, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2G
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2F
                            (g_at2F, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2E
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2D
                            (g_at2D, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2C = Functions.belowten' g_at2B
                            (g_at2B, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2A = code-0.1.0.0:Genome.FixedList.Functions.double g_at2z
                            (g_at2z, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2w = code-0.1.0.0:Genome.FixedList.Functions.double g_at2v
                            (g_at2v, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2u = Functions.belowten' g_at2t
                            (g_at2t, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                            (g_at2r, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2q = Functions.belowten' g_at2p
                            (g_at2p, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2m
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2l
                            (g_at2l, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2k
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2j
                            (g_at2j, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at2g = Functions.belowten' g_at2f
                            (g_at2f, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at2c = Functions.belowten' g_at2b
                            (g_at2b, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                            (g_at29, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at28 = code-0.1.0.0:Genome.FixedList.Functions.double g_at27
                            (g_at27, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at26 = Functions.belowten' g_at25
                            (g_at25, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at4o) = Genome.Split.split gpart_at4n
                            p_at22
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at21
                            (g_at21, gpart_at4n) = Genome.Split.split gpart_at4m
                            p_at20
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1Z
                            (g_at1Z, gpart_at4m) = Genome.Split.split gpart_at4l
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at4l) = Genome.Split.split gpart_at4k
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at4k) = Genome.Split.split gpart_at4j
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at4j) = Genome.Split.split gpart_at4i
                            p_at1S = code-0.1.0.0:Genome.FixedList.Functions.double g_at1R
                            (g_at1R, gpart_at4i) = Genome.Split.split gpart_at4h
                            p_at1Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1P
                            (g_at1P, gpart_at4h) = Genome.Split.split genome_at39
                          in
                            \ desc_at3a
                              -> case desc_at3a of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at6W
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7C
                      p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                      (g_at6U, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                      (g_at6S, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                      (g_at6Q, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                      (g_at6O, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                      (g_at6M, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                      (g_at6K, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6J = Functions.belowten' g_at6I
                      (g_at6I, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6H = code-0.1.0.0:Genome.FixedList.Functions.double g_at6G
                      (g_at6G, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6F = Functions.belowten' g_at6E
                      (g_at6E, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                      (g_at6C, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                      (g_at6A, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                      (g_at6y, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6x = Functions.belowten' g_at6w
                      (g_at6w, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6t
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                      (g_at6s, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6r
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6q
                      (g_at6q, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6p = Functions.belowten' g_at6o
                      (g_at6o, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                      (g_at6m, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                      (g_at6k, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at6h = Functions.belowten' g_at6g
                      (g_at6g, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                      (g_at6e, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at6d = Functions.belowten' g_at6c
                      (g_at6c, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                      (g_at6a, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at69
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                      (g_at68, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at67
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                      (g_at66, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                      (g_at64, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at63 = Functions.belowten' g_at62
                      (g_at62, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                      (g_at60, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at5Z = Functions.belowten' g_at5Y
                      (g_at5Y, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                      (g_at5W, gpart_at78) = Genome.Split.split gpart_at77
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at77) = Genome.Split.split gpart_at76
                      p_at5T = Functions.belowten' g_at5S
                      (g_at5S, gpart_at76) = Genome.Split.split gpart_at75
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at75) = Genome.Split.split gpart_at74
                      p_at5P
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                      (g_at5O, gpart_at74) = Genome.Split.split gpart_at73
                      p_at5N
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                      (g_at5M, gpart_at73) = Genome.Split.split gpart_at72
                      p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                      (g_at5K, gpart_at72) = Genome.Split.split gpart_at71
                      p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                      (g_at5I, gpart_at71) = Genome.Split.split gpart_at70
                      p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                      (g_at5G, gpart_at70) = Genome.Split.split gpart_at6Z
                      p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                      (g_at5E, gpart_at6Z) = Genome.Split.split gpart_at6Y
                      p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                      (g_at5C, gpart_at6Y) = Genome.Split.split genome_at6W
                    in
                      [Reaction
                         (\ x_at7D
                            -> let c_MiRs_at7E = ((toVector x_at7D) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at5L
                                  / (1
                                     + (((p_at5D / p_at5N) ** p_at5P)
                                        + ((c_MiRs_at7E / p_at5R) ** p_at5T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7F
                            -> let
                                 c_MiRs_at7G = ((toVector x_at7F) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7H = ((toVector x_at7F) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5V
                                  / (1
                                     + (((c_MiRs_at7G / p_at5X) ** p_at5Z)
                                        + ((c_PTB_at7H / p_at61) ** p_at63)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7I
                            -> let
                                 c_RESTc_at7L = ((toVector x_at7I) Data.Vector.Unboxed.! 3)
                                 c_PTB_at7J = ((toVector x_at7I) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at65
                                  * ((p_at6j + ((c_PTB_at7J / p_at6b) ** p_at6d))
                                     / (((1 + p_at6j) + ((c_PTB_at7J / p_at6b) ** p_at6d))
                                        + ((c_RESTc_at7L / p_at6f) ** p_at6h)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7M
                            -> let
                                 c_MiRs_at7P = ((toVector x_at7M) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7N = ((toVector x_at7M) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6l
                                  * ((p_at6z + ((c_PTB_at7N / p_at6n) ** p_at6p))
                                     / (((1 + p_at6z) + ((c_PTB_at7N / p_at6n) ** p_at6p))
                                        + ((c_MiRs_at7P / p_at6v) ** p_at6x)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at7Q
                            -> let
                                 c_RESTc_at7T = ((toVector x_at7Q) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at7R = ((toVector x_at7Q) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6B
                                  * ((p_at6L + ((c_MiRs_at7R / p_at6D) ** p_at6F))
                                     / (((1 + p_at6L) + ((c_MiRs_at7R / p_at6D) ** p_at6F))
                                        + ((c_RESTc_at7T / p_at6H) ** p_at6J)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at7U
                            -> let c_PTB_at7V = ((toVector x_at7U) Data.Vector.Unboxed.! 0)
                               in (p_at6N * c_PTB_at7V))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7W
                            -> let c_NPTB_at7X = ((toVector x_at7W) Data.Vector.Unboxed.! 1)
                               in (p_at6P * c_NPTB_at7X))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at7Y
                            -> let c_MiRs_at7Z = ((toVector x_at7Y) Data.Vector.Unboxed.! 2)
                               in (p_at6R * c_MiRs_at7Z))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at80
                            -> let c_RESTc_at81 = ((toVector x_at80) Data.Vector.Unboxed.! 3)
                               in (p_at6T * c_RESTc_at81))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at82
                            -> let
                                 c_EndoNeuroTFs_at83 = ((toVector x_at82) Data.Vector.Unboxed.! 4)
                               in (p_at6V * c_EndoNeuroTFs_at83))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121619",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121621",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at6W
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8I
                            p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                            (g_at6U, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6T = code-0.1.0.0:Genome.FixedList.Functions.double g_at6S
                            (g_at6S, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                            (g_at6Q, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6P = code-0.1.0.0:Genome.FixedList.Functions.double g_at6O
                            (g_at6O, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                            (g_at6M, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                            (g_at6K, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6J = Functions.belowten' g_at6I
                            (g_at6I, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6H = code-0.1.0.0:Genome.FixedList.Functions.double g_at6G
                            (g_at6G, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6F = Functions.belowten' g_at6E
                            (g_at6E, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6D = code-0.1.0.0:Genome.FixedList.Functions.double g_at6C
                            (g_at6C, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6B = code-0.1.0.0:Genome.FixedList.Functions.double g_at6A
                            (g_at6A, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6y
                            (g_at6y, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6x = Functions.belowten' g_at6w
                            (g_at6w, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6t
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6s
                            (g_at6s, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6r
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6q
                            (g_at6q, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6p = Functions.belowten' g_at6o
                            (g_at6o, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at6n = code-0.1.0.0:Genome.FixedList.Functions.double g_at6m
                            (g_at6m, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at6l = code-0.1.0.0:Genome.FixedList.Functions.double g_at6k
                            (g_at6k, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at6h = Functions.belowten' g_at6g
                            (g_at6g, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                            (g_at6e, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at6d = Functions.belowten' g_at6c
                            (g_at6c, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                            (g_at6a, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at69
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at68
                            (g_at68, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at67
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at66
                            (g_at66, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at65 = code-0.1.0.0:Genome.FixedList.Functions.double g_at64
                            (g_at64, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at63 = Functions.belowten' g_at62
                            (g_at62, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at61 = code-0.1.0.0:Genome.FixedList.Functions.double g_at60
                            (g_at60, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5Z = Functions.belowten' g_at5Y
                            (g_at5Y, gpart_at8f) = Genome.Split.split gpart_at8e
                            p_at5X = code-0.1.0.0:Genome.FixedList.Functions.double g_at5W
                            (g_at5W, gpart_at8e) = Genome.Split.split gpart_at8d
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at8d) = Genome.Split.split gpart_at8c
                            p_at5T = Functions.belowten' g_at5S
                            (g_at5S, gpart_at8c) = Genome.Split.split gpart_at8b
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at8b) = Genome.Split.split gpart_at8a
                            p_at5P
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5O
                            (g_at5O, gpart_at8a) = Genome.Split.split gpart_at89
                            p_at5N
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5M
                            (g_at5M, gpart_at89) = Genome.Split.split gpart_at88
                            p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                            (g_at5K, gpart_at88) = Genome.Split.split gpart_at87
                            p_at5J = code-0.1.0.0:Genome.FixedList.Functions.double g_at5I
                            (g_at5I, gpart_at87) = Genome.Split.split gpart_at86
                            p_at5H = code-0.1.0.0:Genome.FixedList.Functions.double g_at5G
                            (g_at5G, gpart_at86) = Genome.Split.split gpart_at85
                            p_at5F = code-0.1.0.0:Genome.FixedList.Functions.double g_at5E
                            (g_at5E, gpart_at85) = Genome.Split.split gpart_at84
                            p_at5D = code-0.1.0.0:Genome.FixedList.Functions.double g_at5C
                            (g_at5C, gpart_at84) = Genome.Split.split genome_at6W
                          in
                            \ desc_at6X
                              -> case desc_at6X of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5D)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5F)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5H)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5J)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Activation coef [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Activation hill [PTB] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   _ -> Nothing }}
