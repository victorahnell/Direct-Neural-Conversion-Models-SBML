src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a1Zgv
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zh8
                      p_a1Zgu = double g_a1Zgt
                      (g_a1Zgt, gpart_a1Zh8) = Genome.Split.split gpart_a1Zh7
                      p_a1Zgs = double g_a1Zgr
                      (g_a1Zgr, gpart_a1Zh7) = Genome.Split.split gpart_a1Zh6
                      p_a1Zgq = double g_a1Zgp
                      (g_a1Zgp, gpart_a1Zh6) = Genome.Split.split gpart_a1Zh5
                      p_a1Zgo = double g_a1Zgn
                      (g_a1Zgn, gpart_a1Zh5) = Genome.Split.split gpart_a1Zh4
                      p_a1Zgm = double g_a1Zgl
                      (g_a1Zgl, gpart_a1Zh4) = Genome.Split.split gpart_a1Zh3
                      p_a1Zgk = Functions.belowten' g_a1Zgj
                      (g_a1Zgj, gpart_a1Zh3) = Genome.Split.split gpart_a1Zh2
                      p_a1Zgi = double g_a1Zgh
                      (g_a1Zgh, gpart_a1Zh2) = Genome.Split.split gpart_a1Zh1
                      p_a1Zgg = double g_a1Zgf
                      (g_a1Zgf, gpart_a1Zh1) = Genome.Split.split gpart_a1Zh0
                      p_a1Zge = double g_a1Zgd
                      (g_a1Zgd, gpart_a1Zh0) = Genome.Split.split gpart_a1ZgZ
                      p_a1Zgc = Functions.belowten' g_a1Zgb
                      (g_a1Zgb, gpart_a1ZgZ) = Genome.Split.split gpart_a1ZgY
                      p_a1Zga = double g_a1Zg9
                      (g_a1Zg9, gpart_a1ZgY) = Genome.Split.split gpart_a1ZgX
                      p_a1Zg8 = Functions.belowten' g_a1Zg7
                      (g_a1Zg7, gpart_a1ZgX) = Genome.Split.split gpart_a1ZgW
                      p_a1Zg6 = double g_a1Zg5
                      (g_a1Zg5, gpart_a1ZgW) = Genome.Split.split gpart_a1ZgV
                      p_a1Zg4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zg3
                      (g_a1Zg3, gpart_a1ZgV) = Genome.Split.split gpart_a1ZgU
                      p_a1Zg2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zg1
                      (g_a1Zg1, gpart_a1ZgU) = Genome.Split.split gpart_a1ZgT
                      p_a1Zg0 = Functions.belowten' g_a1ZfZ
                      (g_a1ZfZ, gpart_a1ZgT) = Genome.Split.split gpart_a1ZgS
                      p_a1ZfY = double g_a1ZfX
                      (g_a1ZfX, gpart_a1ZgS) = Genome.Split.split gpart_a1ZgR
                      p_a1ZfW = double g_a1ZfV
                      (g_a1ZfV, gpart_a1ZgR) = Genome.Split.split gpart_a1ZgQ
                      p_a1ZfU = double g_a1ZfT
                      (g_a1ZfT, gpart_a1ZgQ) = Genome.Split.split gpart_a1ZgP
                      p_a1ZfS = Functions.belowten' g_a1ZfR
                      (g_a1ZfR, gpart_a1ZgP) = Genome.Split.split gpart_a1ZgO
                      p_a1ZfQ = double g_a1ZfP
                      (g_a1ZfP, gpart_a1ZgO) = Genome.Split.split gpart_a1ZgN
                      p_a1ZfO
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfN
                      (g_a1ZfN, gpart_a1ZgN) = Genome.Split.split gpart_a1ZgM
                      p_a1ZfM
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfL
                      (g_a1ZfL, gpart_a1ZgM) = Genome.Split.split gpart_a1ZgL
                      p_a1ZfK = double g_a1ZfJ
                      (g_a1ZfJ, gpart_a1ZgL) = Genome.Split.split gpart_a1ZgK
                      p_a1ZfI = Functions.belowten' g_a1ZfH
                      (g_a1ZfH, gpart_a1ZgK) = Genome.Split.split gpart_a1ZgJ
                      p_a1ZfG = double g_a1ZfF
                      (g_a1ZfF, gpart_a1ZgJ) = Genome.Split.split gpart_a1ZgI
                      p_a1ZfE = Functions.belowten' g_a1ZfD
                      (g_a1ZfD, gpart_a1ZgI) = Genome.Split.split gpart_a1ZgH
                      p_a1ZfC = double g_a1ZfB
                      (g_a1ZfB, gpart_a1ZgH) = Genome.Split.split gpart_a1ZgG
                      p_a1ZfA = double g_a1Zfz
                      (g_a1Zfz, gpart_a1ZgG) = Genome.Split.split gpart_a1ZgF
                      p_a1Zfy = Functions.belowten' g_a1Zfx
                      (g_a1Zfx, gpart_a1ZgF) = Genome.Split.split gpart_a1ZgE
                      p_a1Zfw = double g_a1Zfv
                      (g_a1Zfv, gpart_a1ZgE) = Genome.Split.split gpart_a1ZgD
                      p_a1Zfu
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zft
                      (g_a1Zft, gpart_a1ZgD) = Genome.Split.split gpart_a1ZgC
                      p_a1Zfs
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zfr
                      (g_a1Zfr, gpart_a1ZgC) = Genome.Split.split gpart_a1ZgB
                      p_a1Zfq = double g_a1Zfp
                      (g_a1Zfp, gpart_a1ZgB) = Genome.Split.split gpart_a1ZgA
                      p_a1Zfo = double g_a1Zfn
                      (g_a1Zfn, gpart_a1ZgA) = Genome.Split.split gpart_a1Zgz
                      p_a1Zfm = double g_a1Zfl
                      (g_a1Zfl, gpart_a1Zgz) = Genome.Split.split gpart_a1Zgy
                      p_a1Zfk = double g_a1Zfj
                      (g_a1Zfj, gpart_a1Zgy) = Genome.Split.split gpart_a1Zgx
                      p_a1Zfi = double g_a1Zfh
                      (g_a1Zfh, gpart_a1Zgx) = Genome.Split.split genome_a1Zgv
                    in  \ x_a1Zh9
                          -> let
                               c_PTB_a1Zhc
                                 = ((Data.Fixed.Vector.toVector x_a1Zh9) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Zha
                                 = ((Data.Fixed.Vector.toVector x_a1Zh9) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zhg
                                 = ((Data.Fixed.Vector.toVector x_a1Zh9) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zhh
                                 = ((Data.Fixed.Vector.toVector x_a1Zh9) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zhs
                                 = ((Data.Fixed.Vector.toVector x_a1Zh9) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zfq / (1 + ((c_MiRs_a1Zha / p_a1Zfw) ** p_a1Zfy)))
                                    + (negate (p_a1Zgm * c_PTB_a1Zhc))),
                                   ((p_a1ZfA
                                     / (1
                                        + (((c_MiRs_a1Zha / p_a1ZfC) ** p_a1ZfE)
                                           + ((c_PTB_a1Zhc / p_a1ZfG) ** p_a1ZfI))))
                                    + (negate (p_a1Zgo * c_NPTB_a1Zhg))),
                                   ((p_a1ZfK
                                     * ((p_a1ZfU + ((p_a1Zfm / p_a1ZfM) ** p_a1ZfO))
                                        / (((1 + p_a1ZfU) + ((p_a1Zfm / p_a1ZfM) ** p_a1ZfO))
                                           + ((c_RESTc_a1Zhh / p_a1ZfQ) ** p_a1ZfS))))
                                    + (negate (p_a1Zgq * c_MiRs_a1Zha))),
                                   ((p_a1ZfW
                                     * ((p_a1Zge + ((c_PTB_a1Zhc / p_a1ZfY) ** p_a1Zg0))
                                        / (((1 + p_a1Zge) + ((c_PTB_a1Zhc / p_a1ZfY) ** p_a1Zg0))
                                           + ((((p_a1Zfi / p_a1Zg2) ** p_a1Zg4)
                                               + ((c_NPTB_a1Zhg / p_a1Zg6) ** p_a1Zg8))
                                              + ((c_MiRs_a1Zha / p_a1Zga) ** p_a1Zgc)))))
                                    + (negate (p_a1Zgs * c_RESTc_a1Zhh))),
                                   ((p_a1Zgg / (1 + ((c_RESTc_a1Zhh / p_a1Zgi) ** p_a1Zgk)))
                                    + (negate (p_a1Zgu * c_EndoNeuroTFs_a1Zhs)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483551",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483552",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483553",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483554",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483562",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483564",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483566",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483568",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483582",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483584",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483586",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483588",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483598",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483600",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483602",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483604",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zgv
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zi4
                            p_a1Zgu = double g_a1Zgt
                            (g_a1Zgt, gpart_a1Zi4) = Genome.Split.split gpart_a1Zi3
                            p_a1Zgs = double g_a1Zgr
                            (g_a1Zgr, gpart_a1Zi3) = Genome.Split.split gpart_a1Zi2
                            p_a1Zgq = double g_a1Zgp
                            (g_a1Zgp, gpart_a1Zi2) = Genome.Split.split gpart_a1Zi1
                            p_a1Zgo = double g_a1Zgn
                            (g_a1Zgn, gpart_a1Zi1) = Genome.Split.split gpart_a1Zi0
                            p_a1Zgm = double g_a1Zgl
                            (g_a1Zgl, gpart_a1Zi0) = Genome.Split.split gpart_a1ZhZ
                            p_a1Zgk = Functions.belowten' g_a1Zgj
                            (g_a1Zgj, gpart_a1ZhZ) = Genome.Split.split gpart_a1ZhY
                            p_a1Zgi = double g_a1Zgh
                            (g_a1Zgh, gpart_a1ZhY) = Genome.Split.split gpart_a1ZhX
                            p_a1Zgg = double g_a1Zgf
                            (g_a1Zgf, gpart_a1ZhX) = Genome.Split.split gpart_a1ZhW
                            p_a1Zge = double g_a1Zgd
                            (g_a1Zgd, gpart_a1ZhW) = Genome.Split.split gpart_a1ZhV
                            p_a1Zgc = Functions.belowten' g_a1Zgb
                            (g_a1Zgb, gpart_a1ZhV) = Genome.Split.split gpart_a1ZhU
                            p_a1Zga = double g_a1Zg9
                            (g_a1Zg9, gpart_a1ZhU) = Genome.Split.split gpart_a1ZhT
                            p_a1Zg8 = Functions.belowten' g_a1Zg7
                            (g_a1Zg7, gpart_a1ZhT) = Genome.Split.split gpart_a1ZhS
                            p_a1Zg6 = double g_a1Zg5
                            (g_a1Zg5, gpart_a1ZhS) = Genome.Split.split gpart_a1ZhR
                            p_a1Zg4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zg3
                            (g_a1Zg3, gpart_a1ZhR) = Genome.Split.split gpart_a1ZhQ
                            p_a1Zg2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zg1
                            (g_a1Zg1, gpart_a1ZhQ) = Genome.Split.split gpart_a1ZhP
                            p_a1Zg0 = Functions.belowten' g_a1ZfZ
                            (g_a1ZfZ, gpart_a1ZhP) = Genome.Split.split gpart_a1ZhO
                            p_a1ZfY = double g_a1ZfX
                            (g_a1ZfX, gpart_a1ZhO) = Genome.Split.split gpart_a1ZhN
                            p_a1ZfW = double g_a1ZfV
                            (g_a1ZfV, gpart_a1ZhN) = Genome.Split.split gpart_a1ZhM
                            p_a1ZfU = double g_a1ZfT
                            (g_a1ZfT, gpart_a1ZhM) = Genome.Split.split gpart_a1ZhL
                            p_a1ZfS = Functions.belowten' g_a1ZfR
                            (g_a1ZfR, gpart_a1ZhL) = Genome.Split.split gpart_a1ZhK
                            p_a1ZfQ = double g_a1ZfP
                            (g_a1ZfP, gpart_a1ZhK) = Genome.Split.split gpart_a1ZhJ
                            p_a1ZfO
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfN
                            (g_a1ZfN, gpart_a1ZhJ) = Genome.Split.split gpart_a1ZhI
                            p_a1ZfM
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZfL
                            (g_a1ZfL, gpart_a1ZhI) = Genome.Split.split gpart_a1ZhH
                            p_a1ZfK = double g_a1ZfJ
                            (g_a1ZfJ, gpart_a1ZhH) = Genome.Split.split gpart_a1ZhG
                            p_a1ZfI = Functions.belowten' g_a1ZfH
                            (g_a1ZfH, gpart_a1ZhG) = Genome.Split.split gpart_a1ZhF
                            p_a1ZfG = double g_a1ZfF
                            (g_a1ZfF, gpart_a1ZhF) = Genome.Split.split gpart_a1ZhE
                            p_a1ZfE = Functions.belowten' g_a1ZfD
                            (g_a1ZfD, gpart_a1ZhE) = Genome.Split.split gpart_a1ZhD
                            p_a1ZfC = double g_a1ZfB
                            (g_a1ZfB, gpart_a1ZhD) = Genome.Split.split gpart_a1ZhC
                            p_a1ZfA = double g_a1Zfz
                            (g_a1Zfz, gpart_a1ZhC) = Genome.Split.split gpart_a1ZhB
                            p_a1Zfy = Functions.belowten' g_a1Zfx
                            (g_a1Zfx, gpart_a1ZhB) = Genome.Split.split gpart_a1ZhA
                            p_a1Zfw = double g_a1Zfv
                            (g_a1Zfv, gpart_a1ZhA) = Genome.Split.split gpart_a1Zhz
                            p_a1Zfu
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zft
                            (g_a1Zft, gpart_a1Zhz) = Genome.Split.split gpart_a1Zhy
                            p_a1Zfs
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zfr
                            (g_a1Zfr, gpart_a1Zhy) = Genome.Split.split gpart_a1Zhx
                            p_a1Zfq = double g_a1Zfp
                            (g_a1Zfp, gpart_a1Zhx) = Genome.Split.split gpart_a1Zhw
                            p_a1Zfo = double g_a1Zfn
                            (g_a1Zfn, gpart_a1Zhw) = Genome.Split.split gpart_a1Zhv
                            p_a1Zfm = double g_a1Zfl
                            (g_a1Zfl, gpart_a1Zhv) = Genome.Split.split gpart_a1Zhu
                            p_a1Zfk = double g_a1Zfj
                            (g_a1Zfj, gpart_a1Zhu) = Genome.Split.split gpart_a1Zht
                            p_a1Zfi = double g_a1Zfh
                            (g_a1Zfh, gpart_a1Zht) = Genome.Split.split genome_a1Zgv
                          in
                            \ desc_a1Zgw
                              -> case desc_a1Zgw of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfi)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfk)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfm)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfo)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfq)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfs)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfu)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfw)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zfy)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfA)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfC)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfE)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfG)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfI)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfK)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfM)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfO)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfQ)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfS)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfU)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfW)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZfY)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg0)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg2)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg4)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg6)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zg8)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zga)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgc)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zge)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgg)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgi)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgk)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgm)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgo)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgq)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgs)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zgu)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a1Zks
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zl5
                      p_a1Zkr = double g_a1Zkq
                      (g_a1Zkq, gpart_a1Zl5) = Genome.Split.split gpart_a1Zl4
                      p_a1Zkp = double g_a1Zko
                      (g_a1Zko, gpart_a1Zl4) = Genome.Split.split gpart_a1Zl3
                      p_a1Zkn = double g_a1Zkm
                      (g_a1Zkm, gpart_a1Zl3) = Genome.Split.split gpart_a1Zl2
                      p_a1Zkl = double g_a1Zkk
                      (g_a1Zkk, gpart_a1Zl2) = Genome.Split.split gpart_a1Zl1
                      p_a1Zkj = double g_a1Zki
                      (g_a1Zki, gpart_a1Zl1) = Genome.Split.split gpart_a1Zl0
                      p_a1Zkh = Functions.belowten' g_a1Zkg
                      (g_a1Zkg, gpart_a1Zl0) = Genome.Split.split gpart_a1ZkZ
                      p_a1Zkf = double g_a1Zke
                      (g_a1Zke, gpart_a1ZkZ) = Genome.Split.split gpart_a1ZkY
                      p_a1Zkd = double g_a1Zkc
                      (g_a1Zkc, gpart_a1ZkY) = Genome.Split.split gpart_a1ZkX
                      p_a1Zkb = double g_a1Zka
                      (g_a1Zka, gpart_a1ZkX) = Genome.Split.split gpart_a1ZkW
                      p_a1Zk9 = Functions.belowten' g_a1Zk8
                      (g_a1Zk8, gpart_a1ZkW) = Genome.Split.split gpart_a1ZkV
                      p_a1Zk7 = double g_a1Zk6
                      (g_a1Zk6, gpart_a1ZkV) = Genome.Split.split gpart_a1ZkU
                      p_a1Zk5 = Functions.belowten' g_a1Zk4
                      (g_a1Zk4, gpart_a1ZkU) = Genome.Split.split gpart_a1ZkT
                      p_a1Zk3 = double g_a1Zk2
                      (g_a1Zk2, gpart_a1ZkT) = Genome.Split.split gpart_a1ZkS
                      p_a1Zk1
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zk0
                      (g_a1Zk0, gpart_a1ZkS) = Genome.Split.split gpart_a1ZkR
                      p_a1ZjZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjY
                      (g_a1ZjY, gpart_a1ZkR) = Genome.Split.split gpart_a1ZkQ
                      p_a1ZjX = Functions.belowten' g_a1ZjW
                      (g_a1ZjW, gpart_a1ZkQ) = Genome.Split.split gpart_a1ZkP
                      p_a1ZjV = double g_a1ZjU
                      (g_a1ZjU, gpart_a1ZkP) = Genome.Split.split gpart_a1ZkO
                      p_a1ZjT = double g_a1ZjS
                      (g_a1ZjS, gpart_a1ZkO) = Genome.Split.split gpart_a1ZkN
                      p_a1ZjR = double g_a1ZjQ
                      (g_a1ZjQ, gpart_a1ZkN) = Genome.Split.split gpart_a1ZkM
                      p_a1ZjP = Functions.belowten' g_a1ZjO
                      (g_a1ZjO, gpart_a1ZkM) = Genome.Split.split gpart_a1ZkL
                      p_a1ZjN = double g_a1ZjM
                      (g_a1ZjM, gpart_a1ZkL) = Genome.Split.split gpart_a1ZkK
                      p_a1ZjL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjK
                      (g_a1ZjK, gpart_a1ZkK) = Genome.Split.split gpart_a1ZkJ
                      p_a1ZjJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjI
                      (g_a1ZjI, gpart_a1ZkJ) = Genome.Split.split gpart_a1ZkI
                      p_a1ZjH = double g_a1ZjG
                      (g_a1ZjG, gpart_a1ZkI) = Genome.Split.split gpart_a1ZkH
                      p_a1ZjF = Functions.belowten' g_a1ZjE
                      (g_a1ZjE, gpart_a1ZkH) = Genome.Split.split gpart_a1ZkG
                      p_a1ZjD = double g_a1ZjC
                      (g_a1ZjC, gpart_a1ZkG) = Genome.Split.split gpart_a1ZkF
                      p_a1ZjB = Functions.belowten' g_a1ZjA
                      (g_a1ZjA, gpart_a1ZkF) = Genome.Split.split gpart_a1ZkE
                      p_a1Zjz = double g_a1Zjy
                      (g_a1Zjy, gpart_a1ZkE) = Genome.Split.split gpart_a1ZkD
                      p_a1Zjx = double g_a1Zjw
                      (g_a1Zjw, gpart_a1ZkD) = Genome.Split.split gpart_a1ZkC
                      p_a1Zjv = Functions.belowten' g_a1Zju
                      (g_a1Zju, gpart_a1ZkC) = Genome.Split.split gpart_a1ZkB
                      p_a1Zjt = double g_a1Zjs
                      (g_a1Zjs, gpart_a1ZkB) = Genome.Split.split gpart_a1ZkA
                      p_a1Zjr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zjq
                      (g_a1Zjq, gpart_a1ZkA) = Genome.Split.split gpart_a1Zkz
                      p_a1Zjp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zjo
                      (g_a1Zjo, gpart_a1Zkz) = Genome.Split.split gpart_a1Zky
                      p_a1Zjn = double g_a1Zjm
                      (g_a1Zjm, gpart_a1Zky) = Genome.Split.split gpart_a1Zkx
                      p_a1Zjl = double g_a1Zjk
                      (g_a1Zjk, gpart_a1Zkx) = Genome.Split.split gpart_a1Zkw
                      p_a1Zjj = double g_a1Zji
                      (g_a1Zji, gpart_a1Zkw) = Genome.Split.split gpart_a1Zkv
                      p_a1Zjh = double g_a1Zjg
                      (g_a1Zjg, gpart_a1Zkv) = Genome.Split.split gpart_a1Zku
                      p_a1Zjf = double g_a1Zje
                      (g_a1Zje, gpart_a1Zku) = Genome.Split.split genome_a1Zks
                    in  \ x_a1Zl6
                          -> let
                               c_PTB_a1Zl9
                                 = ((Data.Fixed.Vector.toVector x_a1Zl6) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Zl7
                                 = ((Data.Fixed.Vector.toVector x_a1Zl6) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zld
                                 = ((Data.Fixed.Vector.toVector x_a1Zl6) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zle
                                 = ((Data.Fixed.Vector.toVector x_a1Zl6) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zlp
                                 = ((Data.Fixed.Vector.toVector x_a1Zl6) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zjn / (1 + ((c_MiRs_a1Zl7 / p_a1Zjt) ** p_a1Zjv)))
                                    + (negate (p_a1Zkj * c_PTB_a1Zl9))),
                                   ((p_a1Zjx
                                     / (1
                                        + (((c_MiRs_a1Zl7 / p_a1Zjz) ** p_a1ZjB)
                                           + ((c_PTB_a1Zl9 / p_a1ZjD) ** p_a1ZjF))))
                                    + (negate (p_a1Zkl * c_NPTB_a1Zld))),
                                   ((p_a1ZjH
                                     * (p_a1ZjR
                                        / ((1 + p_a1ZjR) + ((c_RESTc_a1Zle / p_a1ZjN) ** p_a1ZjP))))
                                    + (negate (p_a1Zkn * c_MiRs_a1Zl7))),
                                   ((p_a1ZjT
                                     * ((p_a1Zkb + ((c_PTB_a1Zl9 / p_a1ZjV) ** p_a1ZjX))
                                        / (((1 + p_a1Zkb) + ((c_PTB_a1Zl9 / p_a1ZjV) ** p_a1ZjX))
                                           + ((((p_a1Zjf / p_a1ZjZ) ** p_a1Zk1)
                                               + ((c_NPTB_a1Zld / p_a1Zk3) ** p_a1Zk5))
                                              + ((c_MiRs_a1Zl7 / p_a1Zk7) ** p_a1Zk9)))))
                                    + (negate (p_a1Zkp * c_RESTc_a1Zle))),
                                   ((p_a1Zkd / (1 + ((c_RESTc_a1Zle / p_a1Zkf) ** p_a1Zkh)))
                                    + (negate (p_a1Zkr * c_EndoNeuroTFs_a1Zlp)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483796",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483797",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483798",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483799",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483800",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483801",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483802",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483803",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483804",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483805",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483806",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483807",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483808",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483809",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483810",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483811",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483827",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483829",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483843",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483845",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483849",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483851",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483865",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483867",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679483870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679483871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zks
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zm1
                            p_a1Zkr = double g_a1Zkq
                            (g_a1Zkq, gpart_a1Zm1) = Genome.Split.split gpart_a1Zm0
                            p_a1Zkp = double g_a1Zko
                            (g_a1Zko, gpart_a1Zm0) = Genome.Split.split gpart_a1ZlZ
                            p_a1Zkn = double g_a1Zkm
                            (g_a1Zkm, gpart_a1ZlZ) = Genome.Split.split gpart_a1ZlY
                            p_a1Zkl = double g_a1Zkk
                            (g_a1Zkk, gpart_a1ZlY) = Genome.Split.split gpart_a1ZlX
                            p_a1Zkj = double g_a1Zki
                            (g_a1Zki, gpart_a1ZlX) = Genome.Split.split gpart_a1ZlW
                            p_a1Zkh = Functions.belowten' g_a1Zkg
                            (g_a1Zkg, gpart_a1ZlW) = Genome.Split.split gpart_a1ZlV
                            p_a1Zkf = double g_a1Zke
                            (g_a1Zke, gpart_a1ZlV) = Genome.Split.split gpart_a1ZlU
                            p_a1Zkd = double g_a1Zkc
                            (g_a1Zkc, gpart_a1ZlU) = Genome.Split.split gpart_a1ZlT
                            p_a1Zkb = double g_a1Zka
                            (g_a1Zka, gpart_a1ZlT) = Genome.Split.split gpart_a1ZlS
                            p_a1Zk9 = Functions.belowten' g_a1Zk8
                            (g_a1Zk8, gpart_a1ZlS) = Genome.Split.split gpart_a1ZlR
                            p_a1Zk7 = double g_a1Zk6
                            (g_a1Zk6, gpart_a1ZlR) = Genome.Split.split gpart_a1ZlQ
                            p_a1Zk5 = Functions.belowten' g_a1Zk4
                            (g_a1Zk4, gpart_a1ZlQ) = Genome.Split.split gpart_a1ZlP
                            p_a1Zk3 = double g_a1Zk2
                            (g_a1Zk2, gpart_a1ZlP) = Genome.Split.split gpart_a1ZlO
                            p_a1Zk1
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zk0
                            (g_a1Zk0, gpart_a1ZlO) = Genome.Split.split gpart_a1ZlN
                            p_a1ZjZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjY
                            (g_a1ZjY, gpart_a1ZlN) = Genome.Split.split gpart_a1ZlM
                            p_a1ZjX = Functions.belowten' g_a1ZjW
                            (g_a1ZjW, gpart_a1ZlM) = Genome.Split.split gpart_a1ZlL
                            p_a1ZjV = double g_a1ZjU
                            (g_a1ZjU, gpart_a1ZlL) = Genome.Split.split gpart_a1ZlK
                            p_a1ZjT = double g_a1ZjS
                            (g_a1ZjS, gpart_a1ZlK) = Genome.Split.split gpart_a1ZlJ
                            p_a1ZjR = double g_a1ZjQ
                            (g_a1ZjQ, gpart_a1ZlJ) = Genome.Split.split gpart_a1ZlI
                            p_a1ZjP = Functions.belowten' g_a1ZjO
                            (g_a1ZjO, gpart_a1ZlI) = Genome.Split.split gpart_a1ZlH
                            p_a1ZjN = double g_a1ZjM
                            (g_a1ZjM, gpart_a1ZlH) = Genome.Split.split gpart_a1ZlG
                            p_a1ZjL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjK
                            (g_a1ZjK, gpart_a1ZlG) = Genome.Split.split gpart_a1ZlF
                            p_a1ZjJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZjI
                            (g_a1ZjI, gpart_a1ZlF) = Genome.Split.split gpart_a1ZlE
                            p_a1ZjH = double g_a1ZjG
                            (g_a1ZjG, gpart_a1ZlE) = Genome.Split.split gpart_a1ZlD
                            p_a1ZjF = Functions.belowten' g_a1ZjE
                            (g_a1ZjE, gpart_a1ZlD) = Genome.Split.split gpart_a1ZlC
                            p_a1ZjD = double g_a1ZjC
                            (g_a1ZjC, gpart_a1ZlC) = Genome.Split.split gpart_a1ZlB
                            p_a1ZjB = Functions.belowten' g_a1ZjA
                            (g_a1ZjA, gpart_a1ZlB) = Genome.Split.split gpart_a1ZlA
                            p_a1Zjz = double g_a1Zjy
                            (g_a1Zjy, gpart_a1ZlA) = Genome.Split.split gpart_a1Zlz
                            p_a1Zjx = double g_a1Zjw
                            (g_a1Zjw, gpart_a1Zlz) = Genome.Split.split gpart_a1Zly
                            p_a1Zjv = Functions.belowten' g_a1Zju
                            (g_a1Zju, gpart_a1Zly) = Genome.Split.split gpart_a1Zlx
                            p_a1Zjt = double g_a1Zjs
                            (g_a1Zjs, gpart_a1Zlx) = Genome.Split.split gpart_a1Zlw
                            p_a1Zjr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zjq
                            (g_a1Zjq, gpart_a1Zlw) = Genome.Split.split gpart_a1Zlv
                            p_a1Zjp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zjo
                            (g_a1Zjo, gpart_a1Zlv) = Genome.Split.split gpart_a1Zlu
                            p_a1Zjn = double g_a1Zjm
                            (g_a1Zjm, gpart_a1Zlu) = Genome.Split.split gpart_a1Zlt
                            p_a1Zjl = double g_a1Zjk
                            (g_a1Zjk, gpart_a1Zlt) = Genome.Split.split gpart_a1Zls
                            p_a1Zjj = double g_a1Zji
                            (g_a1Zji, gpart_a1Zls) = Genome.Split.split gpart_a1Zlr
                            p_a1Zjh = double g_a1Zjg
                            (g_a1Zjg, gpart_a1Zlr) = Genome.Split.split gpart_a1Zlq
                            p_a1Zjf = double g_a1Zje
                            (g_a1Zje, gpart_a1Zlq) = Genome.Split.split genome_a1Zks
                          in
                            \ desc_a1Zkt
                              -> case desc_a1Zkt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjf)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjh)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjj)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjl)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjn)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjp)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjr)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjt)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjv)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjx)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zjz)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjB)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjD)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjF)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjH)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjJ)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjL)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjN)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjP)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjR)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjT)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjV)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjX)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZjZ)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk1)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk3)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk5)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk7)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zk9)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkb)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkd)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkf)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zkr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a1Zop
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1Zp2
                      p_a1Zoo = double g_a1Zon
                      (g_a1Zon, gpart_a1Zp2) = Genome.Split.split gpart_a1Zp1
                      p_a1Zom = double g_a1Zol
                      (g_a1Zol, gpart_a1Zp1) = Genome.Split.split gpart_a1Zp0
                      p_a1Zok = double g_a1Zoj
                      (g_a1Zoj, gpart_a1Zp0) = Genome.Split.split gpart_a1ZoZ
                      p_a1Zoi = double g_a1Zoh
                      (g_a1Zoh, gpart_a1ZoZ) = Genome.Split.split gpart_a1ZoY
                      p_a1Zog = double g_a1Zof
                      (g_a1Zof, gpart_a1ZoY) = Genome.Split.split gpart_a1ZoX
                      p_a1Zoe = Functions.belowten' g_a1Zod
                      (g_a1Zod, gpart_a1ZoX) = Genome.Split.split gpart_a1ZoW
                      p_a1Zoc = double g_a1Zob
                      (g_a1Zob, gpart_a1ZoW) = Genome.Split.split gpart_a1ZoV
                      p_a1Zoa = double g_a1Zo9
                      (g_a1Zo9, gpart_a1ZoV) = Genome.Split.split gpart_a1ZoU
                      p_a1Zo8 = double g_a1Zo7
                      (g_a1Zo7, gpart_a1ZoU) = Genome.Split.split gpart_a1ZoT
                      p_a1Zo6 = Functions.belowten' g_a1Zo5
                      (g_a1Zo5, gpart_a1ZoT) = Genome.Split.split gpart_a1ZoS
                      p_a1Zo4 = double g_a1Zo3
                      (g_a1Zo3, gpart_a1ZoS) = Genome.Split.split gpart_a1ZoR
                      p_a1Zo2 = Functions.belowten' g_a1Zo1
                      (g_a1Zo1, gpart_a1ZoR) = Genome.Split.split gpart_a1ZoQ
                      p_a1Zo0 = double g_a1ZnZ
                      (g_a1ZnZ, gpart_a1ZoQ) = Genome.Split.split gpart_a1ZoP
                      p_a1ZnY
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnX
                      (g_a1ZnX, gpart_a1ZoP) = Genome.Split.split gpart_a1ZoO
                      p_a1ZnW
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnV
                      (g_a1ZnV, gpart_a1ZoO) = Genome.Split.split gpart_a1ZoN
                      p_a1ZnU = Functions.belowten' g_a1ZnT
                      (g_a1ZnT, gpart_a1ZoN) = Genome.Split.split gpart_a1ZoM
                      p_a1ZnS = double g_a1ZnR
                      (g_a1ZnR, gpart_a1ZoM) = Genome.Split.split gpart_a1ZoL
                      p_a1ZnQ = double g_a1ZnP
                      (g_a1ZnP, gpart_a1ZoL) = Genome.Split.split gpart_a1ZoK
                      p_a1ZnO = double g_a1ZnN
                      (g_a1ZnN, gpart_a1ZoK) = Genome.Split.split gpart_a1ZoJ
                      p_a1ZnM = Functions.belowten' g_a1ZnL
                      (g_a1ZnL, gpart_a1ZoJ) = Genome.Split.split gpart_a1ZoI
                      p_a1ZnK = double g_a1ZnJ
                      (g_a1ZnJ, gpart_a1ZoI) = Genome.Split.split gpart_a1ZoH
                      p_a1ZnI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnH
                      (g_a1ZnH, gpart_a1ZoH) = Genome.Split.split gpart_a1ZoG
                      p_a1ZnG
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnF
                      (g_a1ZnF, gpart_a1ZoG) = Genome.Split.split gpart_a1ZoF
                      p_a1ZnE = double g_a1ZnD
                      (g_a1ZnD, gpart_a1ZoF) = Genome.Split.split gpart_a1ZoE
                      p_a1ZnC = Functions.belowten' g_a1ZnB
                      (g_a1ZnB, gpart_a1ZoE) = Genome.Split.split gpart_a1ZoD
                      p_a1ZnA = double g_a1Znz
                      (g_a1Znz, gpart_a1ZoD) = Genome.Split.split gpart_a1ZoC
                      p_a1Zny = Functions.belowten' g_a1Znx
                      (g_a1Znx, gpart_a1ZoC) = Genome.Split.split gpart_a1ZoB
                      p_a1Znw = double g_a1Znv
                      (g_a1Znv, gpart_a1ZoB) = Genome.Split.split gpart_a1ZoA
                      p_a1Znu = double g_a1Znt
                      (g_a1Znt, gpart_a1ZoA) = Genome.Split.split gpart_a1Zoz
                      p_a1Zns = Functions.belowten' g_a1Znr
                      (g_a1Znr, gpart_a1Zoz) = Genome.Split.split gpart_a1Zoy
                      p_a1Znq = double g_a1Znp
                      (g_a1Znp, gpart_a1Zoy) = Genome.Split.split gpart_a1Zox
                      p_a1Zno
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Znn
                      (g_a1Znn, gpart_a1Zox) = Genome.Split.split gpart_a1Zow
                      p_a1Znm
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Znl
                      (g_a1Znl, gpart_a1Zow) = Genome.Split.split gpart_a1Zov
                      p_a1Znk = double g_a1Znj
                      (g_a1Znj, gpart_a1Zov) = Genome.Split.split gpart_a1Zou
                      p_a1Zni = double g_a1Znh
                      (g_a1Znh, gpart_a1Zou) = Genome.Split.split gpart_a1Zot
                      p_a1Zng = double g_a1Znf
                      (g_a1Znf, gpart_a1Zot) = Genome.Split.split gpart_a1Zos
                      p_a1Zne = double g_a1Znd
                      (g_a1Znd, gpart_a1Zos) = Genome.Split.split gpart_a1Zor
                      p_a1Znc = double g_a1Znb
                      (g_a1Znb, gpart_a1Zor) = Genome.Split.split genome_a1Zop
                    in  \ x_a1Zp3
                          -> let
                               c_PTB_a1Zp6
                                 = ((Data.Fixed.Vector.toVector x_a1Zp3) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Zp4
                                 = ((Data.Fixed.Vector.toVector x_a1Zp3) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zpa
                                 = ((Data.Fixed.Vector.toVector x_a1Zp3) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zpb
                                 = ((Data.Fixed.Vector.toVector x_a1Zp3) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Zpm
                                 = ((Data.Fixed.Vector.toVector x_a1Zp3) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Znk / (1 + ((c_MiRs_a1Zp4 / p_a1Znq) ** p_a1Zns)))
                                    + (negate (p_a1Zog * c_PTB_a1Zp6))),
                                   ((p_a1Znu
                                     / (1
                                        + (((c_MiRs_a1Zp4 / p_a1Znw) ** p_a1Zny)
                                           + ((c_PTB_a1Zp6 / p_a1ZnA) ** p_a1ZnC))))
                                    + (negate (p_a1Zoi * c_NPTB_a1Zpa))),
                                   ((p_a1ZnE
                                     * (p_a1ZnO
                                        / ((1 + p_a1ZnO) + ((c_RESTc_a1Zpb / p_a1ZnK) ** p_a1ZnM))))
                                    + (negate (p_a1Zok * c_MiRs_a1Zp4))),
                                   ((p_a1ZnQ
                                     * ((p_a1Zo8 + ((c_PTB_a1Zp6 / p_a1ZnS) ** p_a1ZnU))
                                        / (((1 + p_a1Zo8) + ((c_PTB_a1Zp6 / p_a1ZnS) ** p_a1ZnU))
                                           + (((c_NPTB_a1Zpa / p_a1Zo0) ** p_a1Zo2)
                                              + ((c_MiRs_a1Zp4 / p_a1Zo4) ** p_a1Zo6)))))
                                    + (negate (p_a1Zom * c_RESTc_a1Zpb))),
                                   ((p_a1Zoa / (1 + ((c_RESTc_a1Zpb / p_a1Zoc) ** p_a1Zoe)))
                                    + (negate (p_a1Zoo * c_EndoNeuroTFs_a1Zpm)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484041",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484042",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484043",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484044",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484045",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484046",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484047",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484048",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484049",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484050",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484051",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484052",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484053",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484054",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484055",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484056",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484057",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484058",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484059",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484060",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484061",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484062",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484063",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484064",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484065",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484066",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484067",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484068",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484069",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484070",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484071",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484072",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484073",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484074",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484075",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484076",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484077",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484078",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484079",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484080",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484081",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484082",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484083",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484084",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484085",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484086",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484087",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484088",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484089",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484090",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484091",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484092",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484093",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484094",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484095",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484096",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484097",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484098",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484099",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484100",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484101",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484102",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484103",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484104",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484105",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484106",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484107",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484108",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484109",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484110",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484111",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484112",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484113",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484114",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zop
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZpY
                            p_a1Zoo = double g_a1Zon
                            (g_a1Zon, gpart_a1ZpY) = Genome.Split.split gpart_a1ZpX
                            p_a1Zom = double g_a1Zol
                            (g_a1Zol, gpart_a1ZpX) = Genome.Split.split gpart_a1ZpW
                            p_a1Zok = double g_a1Zoj
                            (g_a1Zoj, gpart_a1ZpW) = Genome.Split.split gpart_a1ZpV
                            p_a1Zoi = double g_a1Zoh
                            (g_a1Zoh, gpart_a1ZpV) = Genome.Split.split gpart_a1ZpU
                            p_a1Zog = double g_a1Zof
                            (g_a1Zof, gpart_a1ZpU) = Genome.Split.split gpart_a1ZpT
                            p_a1Zoe = Functions.belowten' g_a1Zod
                            (g_a1Zod, gpart_a1ZpT) = Genome.Split.split gpart_a1ZpS
                            p_a1Zoc = double g_a1Zob
                            (g_a1Zob, gpart_a1ZpS) = Genome.Split.split gpart_a1ZpR
                            p_a1Zoa = double g_a1Zo9
                            (g_a1Zo9, gpart_a1ZpR) = Genome.Split.split gpart_a1ZpQ
                            p_a1Zo8 = double g_a1Zo7
                            (g_a1Zo7, gpart_a1ZpQ) = Genome.Split.split gpart_a1ZpP
                            p_a1Zo6 = Functions.belowten' g_a1Zo5
                            (g_a1Zo5, gpart_a1ZpP) = Genome.Split.split gpart_a1ZpO
                            p_a1Zo4 = double g_a1Zo3
                            (g_a1Zo3, gpart_a1ZpO) = Genome.Split.split gpart_a1ZpN
                            p_a1Zo2 = Functions.belowten' g_a1Zo1
                            (g_a1Zo1, gpart_a1ZpN) = Genome.Split.split gpart_a1ZpM
                            p_a1Zo0 = double g_a1ZnZ
                            (g_a1ZnZ, gpart_a1ZpM) = Genome.Split.split gpart_a1ZpL
                            p_a1ZnY
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnX
                            (g_a1ZnX, gpart_a1ZpL) = Genome.Split.split gpart_a1ZpK
                            p_a1ZnW
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnV
                            (g_a1ZnV, gpart_a1ZpK) = Genome.Split.split gpart_a1ZpJ
                            p_a1ZnU = Functions.belowten' g_a1ZnT
                            (g_a1ZnT, gpart_a1ZpJ) = Genome.Split.split gpart_a1ZpI
                            p_a1ZnS = double g_a1ZnR
                            (g_a1ZnR, gpart_a1ZpI) = Genome.Split.split gpart_a1ZpH
                            p_a1ZnQ = double g_a1ZnP
                            (g_a1ZnP, gpart_a1ZpH) = Genome.Split.split gpart_a1ZpG
                            p_a1ZnO = double g_a1ZnN
                            (g_a1ZnN, gpart_a1ZpG) = Genome.Split.split gpart_a1ZpF
                            p_a1ZnM = Functions.belowten' g_a1ZnL
                            (g_a1ZnL, gpart_a1ZpF) = Genome.Split.split gpart_a1ZpE
                            p_a1ZnK = double g_a1ZnJ
                            (g_a1ZnJ, gpart_a1ZpE) = Genome.Split.split gpart_a1ZpD
                            p_a1ZnI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnH
                            (g_a1ZnH, gpart_a1ZpD) = Genome.Split.split gpart_a1ZpC
                            p_a1ZnG
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZnF
                            (g_a1ZnF, gpart_a1ZpC) = Genome.Split.split gpart_a1ZpB
                            p_a1ZnE = double g_a1ZnD
                            (g_a1ZnD, gpart_a1ZpB) = Genome.Split.split gpart_a1ZpA
                            p_a1ZnC = Functions.belowten' g_a1ZnB
                            (g_a1ZnB, gpart_a1ZpA) = Genome.Split.split gpart_a1Zpz
                            p_a1ZnA = double g_a1Znz
                            (g_a1Znz, gpart_a1Zpz) = Genome.Split.split gpart_a1Zpy
                            p_a1Zny = Functions.belowten' g_a1Znx
                            (g_a1Znx, gpart_a1Zpy) = Genome.Split.split gpart_a1Zpx
                            p_a1Znw = double g_a1Znv
                            (g_a1Znv, gpart_a1Zpx) = Genome.Split.split gpart_a1Zpw
                            p_a1Znu = double g_a1Znt
                            (g_a1Znt, gpart_a1Zpw) = Genome.Split.split gpart_a1Zpv
                            p_a1Zns = Functions.belowten' g_a1Znr
                            (g_a1Znr, gpart_a1Zpv) = Genome.Split.split gpart_a1Zpu
                            p_a1Znq = double g_a1Znp
                            (g_a1Znp, gpart_a1Zpu) = Genome.Split.split gpart_a1Zpt
                            p_a1Zno
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Znn
                            (g_a1Znn, gpart_a1Zpt) = Genome.Split.split gpart_a1Zps
                            p_a1Znm
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Znl
                            (g_a1Znl, gpart_a1Zps) = Genome.Split.split gpart_a1Zpr
                            p_a1Znk = double g_a1Znj
                            (g_a1Znj, gpart_a1Zpr) = Genome.Split.split gpart_a1Zpq
                            p_a1Zni = double g_a1Znh
                            (g_a1Znh, gpart_a1Zpq) = Genome.Split.split gpart_a1Zpp
                            p_a1Zng = double g_a1Znf
                            (g_a1Znf, gpart_a1Zpp) = Genome.Split.split gpart_a1Zpo
                            p_a1Zne = double g_a1Znd
                            (g_a1Znd, gpart_a1Zpo) = Genome.Split.split gpart_a1Zpn
                            p_a1Znc = double g_a1Znb
                            (g_a1Znb, gpart_a1Zpn) = Genome.Split.split genome_a1Zop
                          in
                            \ desc_a1Zoq
                              -> case desc_a1Zoq of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znc)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zne)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zng)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zni)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znk)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znm)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zno)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znq)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zns)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znu)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Znw)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zny)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnA)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnC)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnE)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnG)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnI)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnK)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnM)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnO)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnQ)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnS)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnU)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnW)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZnY)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo0)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo2)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo4)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo6)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zo8)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoa)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoc)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoe)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zog)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoi)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zok)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zom)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zoo)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a1Zsm
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZsZ
                      p_a1Zsl = double g_a1Zsk
                      (g_a1Zsk, gpart_a1ZsZ) = Genome.Split.split gpart_a1ZsY
                      p_a1Zsj = double g_a1Zsi
                      (g_a1Zsi, gpart_a1ZsY) = Genome.Split.split gpart_a1ZsX
                      p_a1Zsh = double g_a1Zsg
                      (g_a1Zsg, gpart_a1ZsX) = Genome.Split.split gpart_a1ZsW
                      p_a1Zsf = double g_a1Zse
                      (g_a1Zse, gpart_a1ZsW) = Genome.Split.split gpart_a1ZsV
                      p_a1Zsd = double g_a1Zsc
                      (g_a1Zsc, gpart_a1ZsV) = Genome.Split.split gpart_a1ZsU
                      p_a1Zsb = Functions.belowten' g_a1Zsa
                      (g_a1Zsa, gpart_a1ZsU) = Genome.Split.split gpart_a1ZsT
                      p_a1Zs9 = double g_a1Zs8
                      (g_a1Zs8, gpart_a1ZsT) = Genome.Split.split gpart_a1ZsS
                      p_a1Zs7 = double g_a1Zs6
                      (g_a1Zs6, gpart_a1ZsS) = Genome.Split.split gpart_a1ZsR
                      p_a1Zs5 = double g_a1Zs4
                      (g_a1Zs4, gpart_a1ZsR) = Genome.Split.split gpart_a1ZsQ
                      p_a1Zs3 = Functions.belowten' g_a1Zs2
                      (g_a1Zs2, gpart_a1ZsQ) = Genome.Split.split gpart_a1ZsP
                      p_a1Zs1 = double g_a1Zs0
                      (g_a1Zs0, gpart_a1ZsP) = Genome.Split.split gpart_a1ZsO
                      p_a1ZrZ = Functions.belowten' g_a1ZrY
                      (g_a1ZrY, gpart_a1ZsO) = Genome.Split.split gpart_a1ZsN
                      p_a1ZrX = double g_a1ZrW
                      (g_a1ZrW, gpart_a1ZsN) = Genome.Split.split gpart_a1ZsM
                      p_a1ZrV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrU
                      (g_a1ZrU, gpart_a1ZsM) = Genome.Split.split gpart_a1ZsL
                      p_a1ZrT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrS
                      (g_a1ZrS, gpart_a1ZsL) = Genome.Split.split gpart_a1ZsK
                      p_a1ZrR = Functions.belowten' g_a1ZrQ
                      (g_a1ZrQ, gpart_a1ZsK) = Genome.Split.split gpart_a1ZsJ
                      p_a1ZrP = double g_a1ZrO
                      (g_a1ZrO, gpart_a1ZsJ) = Genome.Split.split gpart_a1ZsI
                      p_a1ZrN = double g_a1ZrM
                      (g_a1ZrM, gpart_a1ZsI) = Genome.Split.split gpart_a1ZsH
                      p_a1ZrL = double g_a1ZrK
                      (g_a1ZrK, gpart_a1ZsH) = Genome.Split.split gpart_a1ZsG
                      p_a1ZrJ = Functions.belowten' g_a1ZrI
                      (g_a1ZrI, gpart_a1ZsG) = Genome.Split.split gpart_a1ZsF
                      p_a1ZrH = double g_a1ZrG
                      (g_a1ZrG, gpart_a1ZsF) = Genome.Split.split gpart_a1ZsE
                      p_a1ZrF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrE
                      (g_a1ZrE, gpart_a1ZsE) = Genome.Split.split gpart_a1ZsD
                      p_a1ZrD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrC
                      (g_a1ZrC, gpart_a1ZsD) = Genome.Split.split gpart_a1ZsC
                      p_a1ZrB = double g_a1ZrA
                      (g_a1ZrA, gpart_a1ZsC) = Genome.Split.split gpart_a1ZsB
                      p_a1Zrz = Functions.belowten' g_a1Zry
                      (g_a1Zry, gpart_a1ZsB) = Genome.Split.split gpart_a1ZsA
                      p_a1Zrx = double g_a1Zrw
                      (g_a1Zrw, gpart_a1ZsA) = Genome.Split.split gpart_a1Zsz
                      p_a1Zrv = Functions.belowten' g_a1Zru
                      (g_a1Zru, gpart_a1Zsz) = Genome.Split.split gpart_a1Zsy
                      p_a1Zrt = double g_a1Zrs
                      (g_a1Zrs, gpart_a1Zsy) = Genome.Split.split gpart_a1Zsx
                      p_a1Zrr = double g_a1Zrq
                      (g_a1Zrq, gpart_a1Zsx) = Genome.Split.split gpart_a1Zsw
                      p_a1Zrp = Functions.belowten' g_a1Zro
                      (g_a1Zro, gpart_a1Zsw) = Genome.Split.split gpart_a1Zsv
                      p_a1Zrn = double g_a1Zrm
                      (g_a1Zrm, gpart_a1Zsv) = Genome.Split.split gpart_a1Zsu
                      p_a1Zrl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zrk
                      (g_a1Zrk, gpart_a1Zsu) = Genome.Split.split gpart_a1Zst
                      p_a1Zrj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zri
                      (g_a1Zri, gpart_a1Zst) = Genome.Split.split gpart_a1Zss
                      p_a1Zrh = double g_a1Zrg
                      (g_a1Zrg, gpart_a1Zss) = Genome.Split.split gpart_a1Zsr
                      p_a1Zrf = double g_a1Zre
                      (g_a1Zre, gpart_a1Zsr) = Genome.Split.split gpart_a1Zsq
                      p_a1Zrd = double g_a1Zrc
                      (g_a1Zrc, gpart_a1Zsq) = Genome.Split.split gpart_a1Zsp
                      p_a1Zrb = double g_a1Zra
                      (g_a1Zra, gpart_a1Zsp) = Genome.Split.split gpart_a1Zso
                      p_a1Zr9 = double g_a1Zr8
                      (g_a1Zr8, gpart_a1Zso) = Genome.Split.split genome_a1Zsm
                    in  \ x_a1Zt0
                          -> let
                               c_PTB_a1Zt3
                                 = ((Data.Fixed.Vector.toVector x_a1Zt0) Data.Vector.Unboxed.! 0)
                               c_MiRs_a1Zt1
                                 = ((Data.Fixed.Vector.toVector x_a1Zt0) Data.Vector.Unboxed.! 2)
                               c_NPTB_a1Zt7
                                 = ((Data.Fixed.Vector.toVector x_a1Zt0) Data.Vector.Unboxed.! 1)
                               c_RESTc_a1Zt8
                                 = ((Data.Fixed.Vector.toVector x_a1Zt0) Data.Vector.Unboxed.! 3)
                               c_EndoNeuroTFs_a1Ztj
                                 = ((Data.Fixed.Vector.toVector x_a1Zt0) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a1Zrh
                                     / (1
                                        + (((p_a1Zr9 / p_a1Zrj) ** p_a1Zrl)
                                           + ((c_MiRs_a1Zt1 / p_a1Zrn) ** p_a1Zrp))))
                                    + (negate (p_a1Zsd * c_PTB_a1Zt3))),
                                   ((p_a1Zrr
                                     / (1
                                        + (((c_MiRs_a1Zt1 / p_a1Zrt) ** p_a1Zrv)
                                           + ((c_PTB_a1Zt3 / p_a1Zrx) ** p_a1Zrz))))
                                    + (negate (p_a1Zsf * c_NPTB_a1Zt7))),
                                   ((p_a1ZrB
                                     * (p_a1ZrL
                                        / ((1 + p_a1ZrL) + ((c_RESTc_a1Zt8 / p_a1ZrH) ** p_a1ZrJ))))
                                    + (negate (p_a1Zsh * c_MiRs_a1Zt1))),
                                   ((p_a1ZrN
                                     * ((p_a1Zs5 + ((c_PTB_a1Zt3 / p_a1ZrP) ** p_a1ZrR))
                                        / (((1 + p_a1Zs5) + ((c_PTB_a1Zt3 / p_a1ZrP) ** p_a1ZrR))
                                           + (((c_NPTB_a1Zt7 / p_a1ZrX) ** p_a1ZrZ)
                                              + ((c_MiRs_a1Zt1 / p_a1Zs1) ** p_a1Zs3)))))
                                    + (negate (p_a1Zsj * c_RESTc_a1Zt8))),
                                   ((p_a1Zs7 / (1 + ((c_RESTc_a1Zt8 / p_a1Zs9) ** p_a1Zsb)))
                                    + (negate (p_a1Zsl * c_EndoNeuroTFs_a1Ztj)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484286",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484287",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484288",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484289",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484290",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484291",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484292",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484293",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484294",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484295",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484296",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484297",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484298",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484299",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484300",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484301",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484302",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484303",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484304",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484305",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484306",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484307",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484308",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484309",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484310",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484311",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484312",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484313",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484314",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484315",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484316",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484317",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484318",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484319",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484320",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484321",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484322",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484323",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484324",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484325",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484326",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484327",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484328",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484329",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484330",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484331",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484332",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484333",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484334",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484335",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484336",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484337",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484338",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484339",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484355",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484357",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679484360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679484361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a1Zsm
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a1ZtV
                            p_a1Zsl = double g_a1Zsk
                            (g_a1Zsk, gpart_a1ZtV) = Genome.Split.split gpart_a1ZtU
                            p_a1Zsj = double g_a1Zsi
                            (g_a1Zsi, gpart_a1ZtU) = Genome.Split.split gpart_a1ZtT
                            p_a1Zsh = double g_a1Zsg
                            (g_a1Zsg, gpart_a1ZtT) = Genome.Split.split gpart_a1ZtS
                            p_a1Zsf = double g_a1Zse
                            (g_a1Zse, gpart_a1ZtS) = Genome.Split.split gpart_a1ZtR
                            p_a1Zsd = double g_a1Zsc
                            (g_a1Zsc, gpart_a1ZtR) = Genome.Split.split gpart_a1ZtQ
                            p_a1Zsb = Functions.belowten' g_a1Zsa
                            (g_a1Zsa, gpart_a1ZtQ) = Genome.Split.split gpart_a1ZtP
                            p_a1Zs9 = double g_a1Zs8
                            (g_a1Zs8, gpart_a1ZtP) = Genome.Split.split gpart_a1ZtO
                            p_a1Zs7 = double g_a1Zs6
                            (g_a1Zs6, gpart_a1ZtO) = Genome.Split.split gpart_a1ZtN
                            p_a1Zs5 = double g_a1Zs4
                            (g_a1Zs4, gpart_a1ZtN) = Genome.Split.split gpart_a1ZtM
                            p_a1Zs3 = Functions.belowten' g_a1Zs2
                            (g_a1Zs2, gpart_a1ZtM) = Genome.Split.split gpart_a1ZtL
                            p_a1Zs1 = double g_a1Zs0
                            (g_a1Zs0, gpart_a1ZtL) = Genome.Split.split gpart_a1ZtK
                            p_a1ZrZ = Functions.belowten' g_a1ZrY
                            (g_a1ZrY, gpart_a1ZtK) = Genome.Split.split gpart_a1ZtJ
                            p_a1ZrX = double g_a1ZrW
                            (g_a1ZrW, gpart_a1ZtJ) = Genome.Split.split gpart_a1ZtI
                            p_a1ZrV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrU
                            (g_a1ZrU, gpart_a1ZtI) = Genome.Split.split gpart_a1ZtH
                            p_a1ZrT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrS
                            (g_a1ZrS, gpart_a1ZtH) = Genome.Split.split gpart_a1ZtG
                            p_a1ZrR = Functions.belowten' g_a1ZrQ
                            (g_a1ZrQ, gpart_a1ZtG) = Genome.Split.split gpart_a1ZtF
                            p_a1ZrP = double g_a1ZrO
                            (g_a1ZrO, gpart_a1ZtF) = Genome.Split.split gpart_a1ZtE
                            p_a1ZrN = double g_a1ZrM
                            (g_a1ZrM, gpart_a1ZtE) = Genome.Split.split gpart_a1ZtD
                            p_a1ZrL = double g_a1ZrK
                            (g_a1ZrK, gpart_a1ZtD) = Genome.Split.split gpart_a1ZtC
                            p_a1ZrJ = Functions.belowten' g_a1ZrI
                            (g_a1ZrI, gpart_a1ZtC) = Genome.Split.split gpart_a1ZtB
                            p_a1ZrH = double g_a1ZrG
                            (g_a1ZrG, gpart_a1ZtB) = Genome.Split.split gpart_a1ZtA
                            p_a1ZrF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrE
                            (g_a1ZrE, gpart_a1ZtA) = Genome.Split.split gpart_a1Ztz
                            p_a1ZrD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1ZrC
                            (g_a1ZrC, gpart_a1Ztz) = Genome.Split.split gpart_a1Zty
                            p_a1ZrB = double g_a1ZrA
                            (g_a1ZrA, gpart_a1Zty) = Genome.Split.split gpart_a1Ztx
                            p_a1Zrz = Functions.belowten' g_a1Zry
                            (g_a1Zry, gpart_a1Ztx) = Genome.Split.split gpart_a1Ztw
                            p_a1Zrx = double g_a1Zrw
                            (g_a1Zrw, gpart_a1Ztw) = Genome.Split.split gpart_a1Ztv
                            p_a1Zrv = Functions.belowten' g_a1Zru
                            (g_a1Zru, gpart_a1Ztv) = Genome.Split.split gpart_a1Ztu
                            p_a1Zrt = double g_a1Zrs
                            (g_a1Zrs, gpart_a1Ztu) = Genome.Split.split gpart_a1Ztt
                            p_a1Zrr = double g_a1Zrq
                            (g_a1Zrq, gpart_a1Ztt) = Genome.Split.split gpart_a1Zts
                            p_a1Zrp = Functions.belowten' g_a1Zro
                            (g_a1Zro, gpart_a1Zts) = Genome.Split.split gpart_a1Ztr
                            p_a1Zrn = double g_a1Zrm
                            (g_a1Zrm, gpart_a1Ztr) = Genome.Split.split gpart_a1Ztq
                            p_a1Zrl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zrk
                            (g_a1Zrk, gpart_a1Ztq) = Genome.Split.split gpart_a1Ztp
                            p_a1Zrj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a1Zri
                            (g_a1Zri, gpart_a1Ztp) = Genome.Split.split gpart_a1Zto
                            p_a1Zrh = double g_a1Zrg
                            (g_a1Zrg, gpart_a1Zto) = Genome.Split.split gpart_a1Ztn
                            p_a1Zrf = double g_a1Zre
                            (g_a1Zre, gpart_a1Ztn) = Genome.Split.split gpart_a1Ztm
                            p_a1Zrd = double g_a1Zrc
                            (g_a1Zrc, gpart_a1Ztm) = Genome.Split.split gpart_a1Ztl
                            p_a1Zrb = double g_a1Zra
                            (g_a1Zra, gpart_a1Ztl) = Genome.Split.split gpart_a1Ztk
                            p_a1Zr9 = double g_a1Zr8
                            (g_a1Zr8, gpart_a1Ztk) = Genome.Split.split genome_a1Zsm
                          in
                            \ desc_a1Zsn
                              -> case desc_a1Zsn of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zr9)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrb)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrd)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrf)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrh)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrj)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrl)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrn)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrt)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zrz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrR)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrT)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrV)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrX)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1ZrZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zs9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsb)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsd)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsf)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsh)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsj)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a1Zsl)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asV8
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asVL
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                      (g_asV2, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                      (g_asUY, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUX = Functions.belowten' g_asUW
                      (g_asUW, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                      (g_asUU, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUP = Functions.belowten' g_asUO
                      (g_asUO, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                      (g_asUM, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUL = Functions.belowten' g_asUK
                      (g_asUK, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                      (g_asUI, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                      (g_asUG, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                      (g_asUE, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUD = Functions.belowten' g_asUC
                      (g_asUC, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                      (g_asUA, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                      (g_asUy, gpart_asVu) = Genome.Split.split gpart_asVt
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVt) = Genome.Split.split gpart_asVs
                      p_asUv = Functions.belowten' g_asUu
                      (g_asUu, gpart_asVs) = Genome.Split.split gpart_asVr
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVr) = Genome.Split.split gpart_asVq
                      p_asUr
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUq
                      (g_asUq, gpart_asVq) = Genome.Split.split gpart_asVp
                      p_asUp
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                      (g_asUo, gpart_asVp) = Genome.Split.split gpart_asVo
                      p_asUn = code-0.1.0.0:Genome.FixedList.Functions.double g_asUm
                      (g_asUm, gpart_asVo) = Genome.Split.split gpart_asVn
                      p_asUl = Functions.belowten' g_asUk
                      (g_asUk, gpart_asVn) = Genome.Split.split gpart_asVm
                      p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                      (g_asUi, gpart_asVm) = Genome.Split.split gpart_asVl
                      p_asUh = Functions.belowten' g_asUg
                      (g_asUg, gpart_asVl) = Genome.Split.split gpart_asVk
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asVk) = Genome.Split.split gpart_asVj
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVj) = Genome.Split.split gpart_asVi
                      p_asUb = Functions.belowten' g_asUa
                      (g_asUa, gpart_asVi) = Genome.Split.split gpart_asVh
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asVh) = Genome.Split.split gpart_asVg
                      p_asU7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU6
                      (g_asU6, gpart_asVg) = Genome.Split.split gpart_asVf
                      p_asU5
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                      (g_asU4, gpart_asVf) = Genome.Split.split gpart_asVe
                      p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                      (g_asU2, gpart_asVe) = Genome.Split.split gpart_asVd
                      p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                      (g_asU0, gpart_asVd) = Genome.Split.split gpart_asVc
                      p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                      (g_asTY, gpart_asVc) = Genome.Split.split gpart_asVb
                      p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                      (g_asTW, gpart_asVb) = Genome.Split.split gpart_asVa
                      p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                      (g_asTU, gpart_asVa) = Genome.Split.split genome_asV8
                    in
                      [Reaction
                         (\ x_asVM
                            -> let c_MiRs_asVN = ((toVector x_asVM) Data.Vector.Unboxed.! 2)
                               in (p_asU3 / (1 + ((c_MiRs_asVN / p_asU9) ** p_asUb))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asVO
                            -> let
                                 c_MiRs_asVP = ((toVector x_asVO) Data.Vector.Unboxed.! 2)
                                 c_PTB_asVQ = ((toVector x_asVO) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUd
                                  / (1
                                     + (((c_MiRs_asVP / p_asUf) ** p_asUh)
                                        + ((c_PTB_asVQ / p_asUj) ** p_asUl)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asVR
                            -> let c_RESTc_asVS = ((toVector x_asVR) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUn
                                  * ((p_asUx + ((p_asTZ / p_asUp) ** p_asUr))
                                     / (((1 + p_asUx) + ((p_asTZ / p_asUp) ** p_asUr))
                                        + ((c_RESTc_asVS / p_asUt) ** p_asUv)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asVT
                            -> let
                                 c_MiRs_asVX = ((toVector x_asVT) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asVW = ((toVector x_asVT) Data.Vector.Unboxed.! 1)
                                 c_PTB_asVU = ((toVector x_asVT) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUz
                                  * ((p_asUR + ((c_PTB_asVU / p_asUB) ** p_asUD))
                                     / (((1 + p_asUR) + ((c_PTB_asVU / p_asUB) ** p_asUD))
                                        + ((((p_asTV / p_asUF) ** p_asUH)
                                            + ((c_NPTB_asVW / p_asUJ) ** p_asUL))
                                           + ((c_MiRs_asVX / p_asUN) ** p_asUP))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asVY
                            -> let c_RESTc_asVZ = ((toVector x_asVY) Data.Vector.Unboxed.! 3)
                               in (p_asUT / (1 + ((c_RESTc_asVZ / p_asUV) ** p_asUX))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asW0
                            -> let c_PTB_asW1 = ((toVector x_asW0) Data.Vector.Unboxed.! 0)
                               in (p_asUZ * c_PTB_asW1))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asW2
                            -> let c_NPTB_asW3 = ((toVector x_asW2) Data.Vector.Unboxed.! 1)
                               in (p_asV1 * c_NPTB_asW3))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asW4
                            -> let c_MiRs_asW5 = ((toVector x_asW4) Data.Vector.Unboxed.! 2)
                               in (p_asV3 * c_MiRs_asW5))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asW6
                            -> let c_RESTc_asW7 = ((toVector x_asW6) Data.Vector.Unboxed.! 3)
                               in (p_asV5 * c_RESTc_asW7))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asW8
                            -> let
                                 c_EndoNeuroTFs_asW9 = ((toVector x_asW8) Data.Vector.Unboxed.! 4)
                               in (p_asV7 * c_EndoNeuroTFs_asW9))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120896",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120897",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120898",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120899",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120900",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120901",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asV8
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asWQ
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asV3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV2
                            (g_asV2, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUY
                            (g_asUY, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUX = Functions.belowten' g_asUW
                            (g_asUW, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUV = code-0.1.0.0:Genome.FixedList.Functions.double g_asUU
                            (g_asUU, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asUP = Functions.belowten' g_asUO
                            (g_asUO, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asUN = code-0.1.0.0:Genome.FixedList.Functions.double g_asUM
                            (g_asUM, gpart_asWG) = Genome.Split.split gpart_asWF
                            p_asUL = Functions.belowten' g_asUK
                            (g_asUK, gpart_asWF) = Genome.Split.split gpart_asWE
                            p_asUJ = code-0.1.0.0:Genome.FixedList.Functions.double g_asUI
                            (g_asUI, gpart_asWE) = Genome.Split.split gpart_asWD
                            p_asUH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                            (g_asUG, gpart_asWD) = Genome.Split.split gpart_asWC
                            p_asUF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUE
                            (g_asUE, gpart_asWC) = Genome.Split.split gpart_asWB
                            p_asUD = Functions.belowten' g_asUC
                            (g_asUC, gpart_asWB) = Genome.Split.split gpart_asWA
                            p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                            (g_asUA, gpart_asWA) = Genome.Split.split gpart_asWz
                            p_asUz = code-0.1.0.0:Genome.FixedList.Functions.double g_asUy
                            (g_asUy, gpart_asWz) = Genome.Split.split gpart_asWy
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWy) = Genome.Split.split gpart_asWx
                            p_asUv = Functions.belowten' g_asUu
                            (g_asUu, gpart_asWx) = Genome.Split.split gpart_asWw
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWw) = Genome.Split.split gpart_asWv
                            p_asUr
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUq
                            (g_asUq, gpart_asWv) = Genome.Split.split gpart_asWu
                            p_asUp
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUo
                            (g_asUo, gpart_asWu) = Genome.Split.split gpart_asWt
                            p_asUn = code-0.1.0.0:Genome.FixedList.Functions.double g_asUm
                            (g_asUm, gpart_asWt) = Genome.Split.split gpart_asWs
                            p_asUl = Functions.belowten' g_asUk
                            (g_asUk, gpart_asWs) = Genome.Split.split gpart_asWr
                            p_asUj = code-0.1.0.0:Genome.FixedList.Functions.double g_asUi
                            (g_asUi, gpart_asWr) = Genome.Split.split gpart_asWq
                            p_asUh = Functions.belowten' g_asUg
                            (g_asUg, gpart_asWq) = Genome.Split.split gpart_asWp
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asWp) = Genome.Split.split gpart_asWo
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWo) = Genome.Split.split gpart_asWn
                            p_asUb = Functions.belowten' g_asUa
                            (g_asUa, gpart_asWn) = Genome.Split.split gpart_asWm
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWm) = Genome.Split.split gpart_asWl
                            p_asU7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU6
                            (g_asU6, gpart_asWl) = Genome.Split.split gpart_asWk
                            p_asU5
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asU4
                            (g_asU4, gpart_asWk) = Genome.Split.split gpart_asWj
                            p_asU3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU2
                            (g_asU2, gpart_asWj) = Genome.Split.split gpart_asWi
                            p_asU1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU0
                            (g_asU0, gpart_asWi) = Genome.Split.split gpart_asWh
                            p_asTZ = code-0.1.0.0:Genome.FixedList.Functions.double g_asTY
                            (g_asTY, gpart_asWh) = Genome.Split.split gpart_asWg
                            p_asTX = code-0.1.0.0:Genome.FixedList.Functions.double g_asTW
                            (g_asTW, gpart_asWg) = Genome.Split.split gpart_asWf
                            p_asTV = code-0.1.0.0:Genome.FixedList.Functions.double g_asTU
                            (g_asTU, gpart_asWf) = Genome.Split.split genome_asV8
                          in
                            \ desc_asV9
                              -> case desc_asV9 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTV)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTX)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asTZ)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU1)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU3)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU5)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asYL
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asZo
                      p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                      (g_asYJ, gpart_asZo) = Genome.Split.split gpart_asZn
                      p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                      (g_asYH, gpart_asZn) = Genome.Split.split gpart_asZm
                      p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                      (g_asYF, gpart_asZm) = Genome.Split.split gpart_asZl
                      p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                      (g_asYD, gpart_asZl) = Genome.Split.split gpart_asZk
                      p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                      (g_asYB, gpart_asZk) = Genome.Split.split gpart_asZj
                      p_asYA = Functions.belowten' g_asYz
                      (g_asYz, gpart_asZj) = Genome.Split.split gpart_asZi
                      p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                      (g_asYx, gpart_asZi) = Genome.Split.split gpart_asZh
                      p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                      (g_asYv, gpart_asZh) = Genome.Split.split gpart_asZg
                      p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                      (g_asYt, gpart_asZg) = Genome.Split.split gpart_asZf
                      p_asYs = Functions.belowten' g_asYr
                      (g_asYr, gpart_asZf) = Genome.Split.split gpart_asZe
                      p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                      (g_asYp, gpart_asZe) = Genome.Split.split gpart_asZd
                      p_asYo = Functions.belowten' g_asYn
                      (g_asYn, gpart_asZd) = Genome.Split.split gpart_asZc
                      p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                      (g_asYl, gpart_asZc) = Genome.Split.split gpart_asZb
                      p_asYk
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                      (g_asYj, gpart_asZb) = Genome.Split.split gpart_asZa
                      p_asYi
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYh
                      (g_asYh, gpart_asZa) = Genome.Split.split gpart_asZ9
                      p_asYg = Functions.belowten' g_asYf
                      (g_asYf, gpart_asZ9) = Genome.Split.split gpart_asZ8
                      p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                      (g_asYd, gpart_asZ8) = Genome.Split.split gpart_asZ7
                      p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                      (g_asYb, gpart_asZ7) = Genome.Split.split gpart_asZ6
                      p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                      (g_asY9, gpart_asZ6) = Genome.Split.split gpart_asZ5
                      p_asY8 = Functions.belowten' g_asY7
                      (g_asY7, gpart_asZ5) = Genome.Split.split gpart_asZ4
                      p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                      (g_asY5, gpart_asZ4) = Genome.Split.split gpart_asZ3
                      p_asY4
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                      (g_asY3, gpart_asZ3) = Genome.Split.split gpart_asZ2
                      p_asY2
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY1
                      (g_asY1, gpart_asZ2) = Genome.Split.split gpart_asZ1
                      p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                      (g_asXZ, gpart_asZ1) = Genome.Split.split gpart_asZ0
                      p_asXY = Functions.belowten' g_asXX
                      (g_asXX, gpart_asZ0) = Genome.Split.split gpart_asYZ
                      p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                      (g_asXV, gpart_asYZ) = Genome.Split.split gpart_asYY
                      p_asXU = Functions.belowten' g_asXT
                      (g_asXT, gpart_asYY) = Genome.Split.split gpart_asYX
                      p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                      (g_asXR, gpart_asYX) = Genome.Split.split gpart_asYW
                      p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                      (g_asXP, gpart_asYW) = Genome.Split.split gpart_asYV
                      p_asXO = Functions.belowten' g_asXN
                      (g_asXN, gpart_asYV) = Genome.Split.split gpart_asYU
                      p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                      (g_asXL, gpart_asYU) = Genome.Split.split gpart_asYT
                      p_asXK
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXJ
                      (g_asXJ, gpart_asYT) = Genome.Split.split gpart_asYS
                      p_asXI
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                      (g_asXH, gpart_asYS) = Genome.Split.split gpart_asYR
                      p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                      (g_asXF, gpart_asYR) = Genome.Split.split gpart_asYQ
                      p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                      (g_asXD, gpart_asYQ) = Genome.Split.split gpart_asYP
                      p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                      (g_asXB, gpart_asYP) = Genome.Split.split gpart_asYO
                      p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                      (g_asXz, gpart_asYO) = Genome.Split.split gpart_asYN
                      p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                      (g_asXx, gpart_asYN) = Genome.Split.split genome_asYL
                    in
                      [Reaction
                         (\ x_asZp
                            -> let c_MiRs_asZq = ((toVector x_asZp) Data.Vector.Unboxed.! 2)
                               in (p_asXG / (1 + ((c_MiRs_asZq / p_asXM) ** p_asXO))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZr
                            -> let
                                 c_MiRs_asZs = ((toVector x_asZr) Data.Vector.Unboxed.! 2)
                                 c_PTB_asZt = ((toVector x_asZr) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asXQ
                                  / (1
                                     + (((c_MiRs_asZs / p_asXS) ** p_asXU)
                                        + ((c_PTB_asZt / p_asXW) ** p_asXY)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asZu
                            -> let c_RESTc_asZv = ((toVector x_asZu) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asY0
                                  * (p_asYa
                                     / ((1 + p_asYa) + ((c_RESTc_asZv / p_asY6) ** p_asY8)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asZw
                            -> let
                                 c_MiRs_asZA = ((toVector x_asZw) Data.Vector.Unboxed.! 2)
                                 c_NPTB_asZz = ((toVector x_asZw) Data.Vector.Unboxed.! 1)
                                 c_PTB_asZx = ((toVector x_asZw) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYc
                                  * ((p_asYu + ((c_PTB_asZx / p_asYe) ** p_asYg))
                                     / (((1 + p_asYu) + ((c_PTB_asZx / p_asYe) ** p_asYg))
                                        + ((((p_asXy / p_asYi) ** p_asYk)
                                            + ((c_NPTB_asZz / p_asYm) ** p_asYo))
                                           + ((c_MiRs_asZA / p_asYq) ** p_asYs))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asZB
                            -> let c_RESTc_asZC = ((toVector x_asZB) Data.Vector.Unboxed.! 3)
                               in (p_asYw / (1 + ((c_RESTc_asZC / p_asYy) ** p_asYA))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asZD
                            -> let c_PTB_asZE = ((toVector x_asZD) Data.Vector.Unboxed.! 0)
                               in (p_asYC * c_PTB_asZE))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asZF
                            -> let c_NPTB_asZG = ((toVector x_asZF) Data.Vector.Unboxed.! 1)
                               in (p_asYE * c_NPTB_asZG))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asZH
                            -> let c_MiRs_asZI = ((toVector x_asZH) Data.Vector.Unboxed.! 2)
                               in (p_asYG * c_MiRs_asZI))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asZJ
                            -> let c_RESTc_asZK = ((toVector x_asZJ) Data.Vector.Unboxed.! 3)
                               in (p_asYI * c_RESTc_asZK))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asZL
                            -> let
                                 c_EndoNeuroTFs_asZM = ((toVector x_asZL) Data.Vector.Unboxed.! 4)
                               in (p_asYK * c_EndoNeuroTFs_asZM))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121115",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121116",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121117",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121118",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121119",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121120",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121121",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121122",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121123",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121124",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121125",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121126",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121127",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121128",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121129",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121130",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121131",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121132",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121133",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121134",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121135",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121136",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121137",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121138",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121139",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121140",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121141",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121142",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121143",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121144",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121145",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121146",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121147",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121148",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121149",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121150",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121151",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121152",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121153",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121154",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121155",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121156",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121157",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121158",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121159",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121160",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121161",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121162",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121163",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121164",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121165",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121166",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121167",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121168",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121169",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121170",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121171",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121172",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121173",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121174",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121175",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121176",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121177",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121178",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121179",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121180",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121181",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121182",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121183",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121184",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121185",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121186",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121187",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121188",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121189",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121190",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asYL
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at0o
                            p_asYK = code-0.1.0.0:Genome.FixedList.Functions.double g_asYJ
                            (g_asYJ, gpart_at0o) = Genome.Split.split gpart_at0n
                            p_asYI = code-0.1.0.0:Genome.FixedList.Functions.double g_asYH
                            (g_asYH, gpart_at0n) = Genome.Split.split gpart_at0m
                            p_asYG = code-0.1.0.0:Genome.FixedList.Functions.double g_asYF
                            (g_asYF, gpart_at0m) = Genome.Split.split gpart_at0l
                            p_asYE = code-0.1.0.0:Genome.FixedList.Functions.double g_asYD
                            (g_asYD, gpart_at0l) = Genome.Split.split gpart_at0k
                            p_asYC = code-0.1.0.0:Genome.FixedList.Functions.double g_asYB
                            (g_asYB, gpart_at0k) = Genome.Split.split gpart_at0j
                            p_asYA = Functions.belowten' g_asYz
                            (g_asYz, gpart_at0j) = Genome.Split.split gpart_at0i
                            p_asYy = code-0.1.0.0:Genome.FixedList.Functions.double g_asYx
                            (g_asYx, gpart_at0i) = Genome.Split.split gpart_at0h
                            p_asYw = code-0.1.0.0:Genome.FixedList.Functions.double g_asYv
                            (g_asYv, gpart_at0h) = Genome.Split.split gpart_at0g
                            p_asYu = code-0.1.0.0:Genome.FixedList.Functions.double g_asYt
                            (g_asYt, gpart_at0g) = Genome.Split.split gpart_at0f
                            p_asYs = Functions.belowten' g_asYr
                            (g_asYr, gpart_at0f) = Genome.Split.split gpart_at0e
                            p_asYq = code-0.1.0.0:Genome.FixedList.Functions.double g_asYp
                            (g_asYp, gpart_at0e) = Genome.Split.split gpart_at0d
                            p_asYo = Functions.belowten' g_asYn
                            (g_asYn, gpart_at0d) = Genome.Split.split gpart_at0c
                            p_asYm = code-0.1.0.0:Genome.FixedList.Functions.double g_asYl
                            (g_asYl, gpart_at0c) = Genome.Split.split gpart_at0b
                            p_asYk
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYj
                            (g_asYj, gpart_at0b) = Genome.Split.split gpart_at0a
                            p_asYi
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYh
                            (g_asYh, gpart_at0a) = Genome.Split.split gpart_at09
                            p_asYg = Functions.belowten' g_asYf
                            (g_asYf, gpart_at09) = Genome.Split.split gpart_at08
                            p_asYe = code-0.1.0.0:Genome.FixedList.Functions.double g_asYd
                            (g_asYd, gpart_at08) = Genome.Split.split gpart_at07
                            p_asYc = code-0.1.0.0:Genome.FixedList.Functions.double g_asYb
                            (g_asYb, gpart_at07) = Genome.Split.split gpart_at06
                            p_asYa = code-0.1.0.0:Genome.FixedList.Functions.double g_asY9
                            (g_asY9, gpart_at06) = Genome.Split.split gpart_at05
                            p_asY8 = Functions.belowten' g_asY7
                            (g_asY7, gpart_at05) = Genome.Split.split gpart_at04
                            p_asY6 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY5
                            (g_asY5, gpart_at04) = Genome.Split.split gpart_at03
                            p_asY4
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY3
                            (g_asY3, gpart_at03) = Genome.Split.split gpart_at02
                            p_asY2
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asY1
                            (g_asY1, gpart_at02) = Genome.Split.split gpart_at01
                            p_asY0 = code-0.1.0.0:Genome.FixedList.Functions.double g_asXZ
                            (g_asXZ, gpart_at01) = Genome.Split.split gpart_at00
                            p_asXY = Functions.belowten' g_asXX
                            (g_asXX, gpart_at00) = Genome.Split.split gpart_asZZ
                            p_asXW = code-0.1.0.0:Genome.FixedList.Functions.double g_asXV
                            (g_asXV, gpart_asZZ) = Genome.Split.split gpart_asZY
                            p_asXU = Functions.belowten' g_asXT
                            (g_asXT, gpart_asZY) = Genome.Split.split gpart_asZX
                            p_asXS = code-0.1.0.0:Genome.FixedList.Functions.double g_asXR
                            (g_asXR, gpart_asZX) = Genome.Split.split gpart_asZW
                            p_asXQ = code-0.1.0.0:Genome.FixedList.Functions.double g_asXP
                            (g_asXP, gpart_asZW) = Genome.Split.split gpart_asZV
                            p_asXO = Functions.belowten' g_asXN
                            (g_asXN, gpart_asZV) = Genome.Split.split gpart_asZU
                            p_asXM = code-0.1.0.0:Genome.FixedList.Functions.double g_asXL
                            (g_asXL, gpart_asZU) = Genome.Split.split gpart_asZT
                            p_asXK
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXJ
                            (g_asXJ, gpart_asZT) = Genome.Split.split gpart_asZS
                            p_asXI
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asXH
                            (g_asXH, gpart_asZS) = Genome.Split.split gpart_asZR
                            p_asXG = code-0.1.0.0:Genome.FixedList.Functions.double g_asXF
                            (g_asXF, gpart_asZR) = Genome.Split.split gpart_asZQ
                            p_asXE = code-0.1.0.0:Genome.FixedList.Functions.double g_asXD
                            (g_asXD, gpart_asZQ) = Genome.Split.split gpart_asZP
                            p_asXC = code-0.1.0.0:Genome.FixedList.Functions.double g_asXB
                            (g_asXB, gpart_asZP) = Genome.Split.split gpart_asZO
                            p_asXA = code-0.1.0.0:Genome.FixedList.Functions.double g_asXz
                            (g_asXz, gpart_asZO) = Genome.Split.split gpart_asZN
                            p_asXy = code-0.1.0.0:Genome.FixedList.Functions.double g_asXx
                            (g_asXx, gpart_asZN) = Genome.Split.split genome_asYL
                          in
                            \ desc_asYM
                              -> case desc_asYM of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXy)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXA)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXC)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXE)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXG)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXI)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXK)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXM)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXO)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXQ)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXS)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXU)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXW)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asXY)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY0)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY2)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY4)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY6)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY8)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYa)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYc)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYe)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYg)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYi)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYk)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYm)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYo)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYq)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYs)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYu)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYw)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYy)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYA)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYC)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYE)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYG)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYI)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYK)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at2j
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at2W
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at2W) = Genome.Split.split gpart_at2V
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at2V) = Genome.Split.split gpart_at2U
                      p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                      (g_at2d, gpart_at2U) = Genome.Split.split gpart_at2T
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at2T) = Genome.Split.split gpart_at2S
                      p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                      (g_at29, gpart_at2S) = Genome.Split.split gpart_at2R
                      p_at28 = Functions.belowten' g_at27
                      (g_at27, gpart_at2R) = Genome.Split.split gpart_at2Q
                      p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                      (g_at25, gpart_at2Q) = Genome.Split.split gpart_at2P
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at2P) = Genome.Split.split gpart_at2O
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at2O) = Genome.Split.split gpart_at2N
                      p_at20 = Functions.belowten' g_at1Z
                      (g_at1Z, gpart_at2N) = Genome.Split.split gpart_at2M
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at2M) = Genome.Split.split gpart_at2L
                      p_at1W = Functions.belowten' g_at1V
                      (g_at1V, gpart_at2L) = Genome.Split.split gpart_at2K
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at2K) = Genome.Split.split gpart_at2J
                      p_at1S
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                      (g_at1R, gpart_at2J) = Genome.Split.split gpart_at2I
                      p_at1Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1P
                      (g_at1P, gpart_at2I) = Genome.Split.split gpart_at2H
                      p_at1O = Functions.belowten' g_at1N
                      (g_at1N, gpart_at2H) = Genome.Split.split gpart_at2G
                      p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                      (g_at1L, gpart_at2G) = Genome.Split.split gpart_at2F
                      p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                      (g_at1J, gpart_at2F) = Genome.Split.split gpart_at2E
                      p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                      (g_at1H, gpart_at2E) = Genome.Split.split gpart_at2D
                      p_at1G = Functions.belowten' g_at1F
                      (g_at1F, gpart_at2D) = Genome.Split.split gpart_at2C
                      p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                      (g_at1D, gpart_at2C) = Genome.Split.split gpart_at2B
                      p_at1C
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1B
                      (g_at1B, gpart_at2B) = Genome.Split.split gpart_at2A
                      p_at1A
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                      (g_at1z, gpart_at2A) = Genome.Split.split gpart_at2z
                      p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                      (g_at1x, gpart_at2z) = Genome.Split.split gpart_at2y
                      p_at1w = Functions.belowten' g_at1v
                      (g_at1v, gpart_at2y) = Genome.Split.split gpart_at2x
                      p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                      (g_at1t, gpart_at2x) = Genome.Split.split gpart_at2w
                      p_at1s = Functions.belowten' g_at1r
                      (g_at1r, gpart_at2w) = Genome.Split.split gpart_at2v
                      p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                      (g_at1p, gpart_at2v) = Genome.Split.split gpart_at2u
                      p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                      (g_at1n, gpart_at2u) = Genome.Split.split gpart_at2t
                      p_at1m = Functions.belowten' g_at1l
                      (g_at1l, gpart_at2t) = Genome.Split.split gpart_at2s
                      p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                      (g_at1j, gpart_at2s) = Genome.Split.split gpart_at2r
                      p_at1i
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                      (g_at1h, gpart_at2r) = Genome.Split.split gpart_at2q
                      p_at1g
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1f
                      (g_at1f, gpart_at2q) = Genome.Split.split gpart_at2p
                      p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                      (g_at1d, gpart_at2p) = Genome.Split.split gpart_at2o
                      p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                      (g_at1b, gpart_at2o) = Genome.Split.split gpart_at2n
                      p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                      (g_at19, gpart_at2n) = Genome.Split.split gpart_at2m
                      p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                      (g_at17, gpart_at2m) = Genome.Split.split gpart_at2l
                      p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                      (g_at15, gpart_at2l) = Genome.Split.split genome_at2j
                    in
                      [Reaction
                         (\ x_at2X
                            -> let c_MiRs_at2Y = ((toVector x_at2X) Data.Vector.Unboxed.! 2)
                               in (p_at1e / (1 + ((c_MiRs_at2Y / p_at1k) ** p_at1m))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at2Z
                            -> let
                                 c_MiRs_at30 = ((toVector x_at2Z) Data.Vector.Unboxed.! 2)
                                 c_PTB_at31 = ((toVector x_at2Z) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1o
                                  / (1
                                     + (((c_MiRs_at30 / p_at1q) ** p_at1s)
                                        + ((c_PTB_at31 / p_at1u) ** p_at1w)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at32
                            -> let c_RESTc_at33 = ((toVector x_at32) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at1y
                                  * (p_at1I
                                     / ((1 + p_at1I) + ((c_RESTc_at33 / p_at1E) ** p_at1G)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at34
                            -> let
                                 c_MiRs_at38 = ((toVector x_at34) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at37 = ((toVector x_at34) Data.Vector.Unboxed.! 1)
                                 c_PTB_at35 = ((toVector x_at34) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at1K
                                  * ((p_at22 + ((c_PTB_at35 / p_at1M) ** p_at1O))
                                     / (((1 + p_at22) + ((c_PTB_at35 / p_at1M) ** p_at1O))
                                        + (((c_NPTB_at37 / p_at1U) ** p_at1W)
                                           + ((c_MiRs_at38 / p_at1Y) ** p_at20))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at39
                            -> let c_RESTc_at3a = ((toVector x_at39) Data.Vector.Unboxed.! 3)
                               in (p_at24 / (1 + ((c_RESTc_at3a / p_at26) ** p_at28))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at3b
                            -> let c_PTB_at3c = ((toVector x_at3b) Data.Vector.Unboxed.! 0)
                               in (p_at2a * c_PTB_at3c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at3d
                            -> let c_NPTB_at3e = ((toVector x_at3d) Data.Vector.Unboxed.! 1)
                               in (p_at2c * c_NPTB_at3e))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at3f
                            -> let c_MiRs_at3g = ((toVector x_at3f) Data.Vector.Unboxed.! 2)
                               in (p_at2e * c_MiRs_at3g))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at3h
                            -> let c_RESTc_at3i = ((toVector x_at3h) Data.Vector.Unboxed.! 3)
                               in (p_at2g * c_RESTc_at3i))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at3j
                            -> let
                                 c_EndoNeuroTFs_at3k = ((toVector x_at3j) Data.Vector.Unboxed.! 4)
                               in (p_at2i * c_EndoNeuroTFs_at3k))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121335",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121336",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121337",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121338",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121339",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121340",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121341",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121342",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121343",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121344",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121345",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121346",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121347",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121348",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121349",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121350",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121351",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121352",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121353",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121354",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121355",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121356",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121357",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121358",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121359",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121360",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121361",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121362",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121363",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121364",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121365",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121366",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121367",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121368",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121369",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121370",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121371",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121372",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121373",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121374",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121375",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121376",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121377",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121378",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121379",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121380",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121381",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121382",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121383",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121384",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at2j
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3W
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at3W) = Genome.Split.split gpart_at3V
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at3V) = Genome.Split.split gpart_at3U
                            p_at2e = code-0.1.0.0:Genome.FixedList.Functions.double g_at2d
                            (g_at2d, gpart_at3U) = Genome.Split.split gpart_at3T
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at3T) = Genome.Split.split gpart_at3S
                            p_at2a = code-0.1.0.0:Genome.FixedList.Functions.double g_at29
                            (g_at29, gpart_at3S) = Genome.Split.split gpart_at3R
                            p_at28 = Functions.belowten' g_at27
                            (g_at27, gpart_at3R) = Genome.Split.split gpart_at3Q
                            p_at26 = code-0.1.0.0:Genome.FixedList.Functions.double g_at25
                            (g_at25, gpart_at3Q) = Genome.Split.split gpart_at3P
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at3P) = Genome.Split.split gpart_at3O
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at3O) = Genome.Split.split gpart_at3N
                            p_at20 = Functions.belowten' g_at1Z
                            (g_at1Z, gpart_at3N) = Genome.Split.split gpart_at3M
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at3M) = Genome.Split.split gpart_at3L
                            p_at1W = Functions.belowten' g_at1V
                            (g_at1V, gpart_at3L) = Genome.Split.split gpart_at3K
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at3K) = Genome.Split.split gpart_at3J
                            p_at1S
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1R
                            (g_at1R, gpart_at3J) = Genome.Split.split gpart_at3I
                            p_at1Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1P
                            (g_at1P, gpart_at3I) = Genome.Split.split gpart_at3H
                            p_at1O = Functions.belowten' g_at1N
                            (g_at1N, gpart_at3H) = Genome.Split.split gpart_at3G
                            p_at1M = code-0.1.0.0:Genome.FixedList.Functions.double g_at1L
                            (g_at1L, gpart_at3G) = Genome.Split.split gpart_at3F
                            p_at1K = code-0.1.0.0:Genome.FixedList.Functions.double g_at1J
                            (g_at1J, gpart_at3F) = Genome.Split.split gpart_at3E
                            p_at1I = code-0.1.0.0:Genome.FixedList.Functions.double g_at1H
                            (g_at1H, gpart_at3E) = Genome.Split.split gpart_at3D
                            p_at1G = Functions.belowten' g_at1F
                            (g_at1F, gpart_at3D) = Genome.Split.split gpart_at3C
                            p_at1E = code-0.1.0.0:Genome.FixedList.Functions.double g_at1D
                            (g_at1D, gpart_at3C) = Genome.Split.split gpart_at3B
                            p_at1C
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1B
                            (g_at1B, gpart_at3B) = Genome.Split.split gpart_at3A
                            p_at1A
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1z
                            (g_at1z, gpart_at3A) = Genome.Split.split gpart_at3z
                            p_at1y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1x
                            (g_at1x, gpart_at3z) = Genome.Split.split gpart_at3y
                            p_at1w = Functions.belowten' g_at1v
                            (g_at1v, gpart_at3y) = Genome.Split.split gpart_at3x
                            p_at1u = code-0.1.0.0:Genome.FixedList.Functions.double g_at1t
                            (g_at1t, gpart_at3x) = Genome.Split.split gpart_at3w
                            p_at1s = Functions.belowten' g_at1r
                            (g_at1r, gpart_at3w) = Genome.Split.split gpart_at3v
                            p_at1q = code-0.1.0.0:Genome.FixedList.Functions.double g_at1p
                            (g_at1p, gpart_at3v) = Genome.Split.split gpart_at3u
                            p_at1o = code-0.1.0.0:Genome.FixedList.Functions.double g_at1n
                            (g_at1n, gpart_at3u) = Genome.Split.split gpart_at3t
                            p_at1m = Functions.belowten' g_at1l
                            (g_at1l, gpart_at3t) = Genome.Split.split gpart_at3s
                            p_at1k = code-0.1.0.0:Genome.FixedList.Functions.double g_at1j
                            (g_at1j, gpart_at3s) = Genome.Split.split gpart_at3r
                            p_at1i
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1h
                            (g_at1h, gpart_at3r) = Genome.Split.split gpart_at3q
                            p_at1g
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at1f
                            (g_at1f, gpart_at3q) = Genome.Split.split gpart_at3p
                            p_at1e = code-0.1.0.0:Genome.FixedList.Functions.double g_at1d
                            (g_at1d, gpart_at3p) = Genome.Split.split gpart_at3o
                            p_at1c = code-0.1.0.0:Genome.FixedList.Functions.double g_at1b
                            (g_at1b, gpart_at3o) = Genome.Split.split gpart_at3n
                            p_at1a = code-0.1.0.0:Genome.FixedList.Functions.double g_at19
                            (g_at19, gpart_at3n) = Genome.Split.split gpart_at3m
                            p_at18 = code-0.1.0.0:Genome.FixedList.Functions.double g_at17
                            (g_at17, gpart_at3m) = Genome.Split.split gpart_at3l
                            p_at16 = code-0.1.0.0:Genome.FixedList.Functions.double g_at15
                            (g_at15, gpart_at3l) = Genome.Split.split genome_at2j
                          in
                            \ desc_at2k
                              -> case desc_at2k of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at16)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at18)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1a)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1c)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1e)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1g)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1i)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1k)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1m)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1o)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1q)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1s)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1u)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1w)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1y)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1A)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1C)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1E)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1G)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1I)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1K)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1M)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1O)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Q)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1S)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at5R
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at6u
                      p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                      (g_at5P, gpart_at6u) = Genome.Split.split gpart_at6t
                      p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                      (g_at5N, gpart_at6t) = Genome.Split.split gpart_at6s
                      p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                      (g_at5L, gpart_at6s) = Genome.Split.split gpart_at6r
                      p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                      (g_at5J, gpart_at6r) = Genome.Split.split gpart_at6q
                      p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                      (g_at5H, gpart_at6q) = Genome.Split.split gpart_at6p
                      p_at5G = Functions.belowten' g_at5F
                      (g_at5F, gpart_at6p) = Genome.Split.split gpart_at6o
                      p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                      (g_at5D, gpart_at6o) = Genome.Split.split gpart_at6n
                      p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                      (g_at5B, gpart_at6n) = Genome.Split.split gpart_at6m
                      p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                      (g_at5z, gpart_at6m) = Genome.Split.split gpart_at6l
                      p_at5y = Functions.belowten' g_at5x
                      (g_at5x, gpart_at6l) = Genome.Split.split gpart_at6k
                      p_at5w = code-0.1.0.0:Genome.FixedList.Functions.double g_at5v
                      (g_at5v, gpart_at6k) = Genome.Split.split gpart_at6j
                      p_at5u = Functions.belowten' g_at5t
                      (g_at5t, gpart_at6j) = Genome.Split.split gpart_at6i
                      p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                      (g_at5r, gpart_at6i) = Genome.Split.split gpart_at6h
                      p_at5q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5p
                      (g_at5p, gpart_at6h) = Genome.Split.split gpart_at6g
                      p_at5o
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5n
                      (g_at5n, gpart_at6g) = Genome.Split.split gpart_at6f
                      p_at5m = Functions.belowten' g_at5l
                      (g_at5l, gpart_at6f) = Genome.Split.split gpart_at6e
                      p_at5k = code-0.1.0.0:Genome.FixedList.Functions.double g_at5j
                      (g_at5j, gpart_at6e) = Genome.Split.split gpart_at6d
                      p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                      (g_at5h, gpart_at6d) = Genome.Split.split gpart_at6c
                      p_at5g = code-0.1.0.0:Genome.FixedList.Functions.double g_at5f
                      (g_at5f, gpart_at6c) = Genome.Split.split gpart_at6b
                      p_at5e = Functions.belowten' g_at5d
                      (g_at5d, gpart_at6b) = Genome.Split.split gpart_at6a
                      p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                      (g_at5b, gpart_at6a) = Genome.Split.split gpart_at69
                      p_at5a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at59
                      (g_at59, gpart_at69) = Genome.Split.split gpart_at68
                      p_at58
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at57
                      (g_at57, gpart_at68) = Genome.Split.split gpart_at67
                      p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                      (g_at55, gpart_at67) = Genome.Split.split gpart_at66
                      p_at54 = Functions.belowten' g_at53
                      (g_at53, gpart_at66) = Genome.Split.split gpart_at65
                      p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                      (g_at51, gpart_at65) = Genome.Split.split gpart_at64
                      p_at50 = Functions.belowten' g_at4Z
                      (g_at4Z, gpart_at64) = Genome.Split.split gpart_at63
                      p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                      (g_at4X, gpart_at63) = Genome.Split.split gpart_at62
                      p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                      (g_at4V, gpart_at62) = Genome.Split.split gpart_at61
                      p_at4U = Functions.belowten' g_at4T
                      (g_at4T, gpart_at61) = Genome.Split.split gpart_at60
                      p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                      (g_at4R, gpart_at60) = Genome.Split.split gpart_at5Z
                      p_at4Q
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4P
                      (g_at4P, gpart_at5Z) = Genome.Split.split gpart_at5Y
                      p_at4O
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4N
                      (g_at4N, gpart_at5Y) = Genome.Split.split gpart_at5X
                      p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                      (g_at4L, gpart_at5X) = Genome.Split.split gpart_at5W
                      p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                      (g_at4J, gpart_at5W) = Genome.Split.split gpart_at5V
                      p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                      (g_at4H, gpart_at5V) = Genome.Split.split gpart_at5U
                      p_at4G = code-0.1.0.0:Genome.FixedList.Functions.double g_at4F
                      (g_at4F, gpart_at5U) = Genome.Split.split gpart_at5T
                      p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                      (g_at4D, gpart_at5T) = Genome.Split.split genome_at5R
                    in
                      [Reaction
                         (\ x_at6v
                            -> let c_MiRs_at6w = ((toVector x_at6v) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at4M
                                  / (1
                                     + (((p_at4E / p_at4O) ** p_at4Q)
                                        + ((c_MiRs_at6w / p_at4S) ** p_at4U)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6x
                            -> let
                                 c_MiRs_at6y = ((toVector x_at6x) Data.Vector.Unboxed.! 2)
                                 c_PTB_at6z = ((toVector x_at6x) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at4W
                                  / (1
                                     + (((c_MiRs_at6y / p_at4Y) ** p_at50)
                                        + ((c_PTB_at6z / p_at52) ** p_at54)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at6A
                            -> let c_RESTc_at6B = ((toVector x_at6A) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at56
                                  * (p_at5g
                                     / ((1 + p_at5g) + ((c_RESTc_at6B / p_at5c) ** p_at5e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at6C
                            -> let
                                 c_MiRs_at6G = ((toVector x_at6C) Data.Vector.Unboxed.! 2)
                                 c_NPTB_at6F = ((toVector x_at6C) Data.Vector.Unboxed.! 1)
                                 c_PTB_at6D = ((toVector x_at6C) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at5i
                                  * ((p_at5A + ((c_PTB_at6D / p_at5k) ** p_at5m))
                                     / (((1 + p_at5A) + ((c_PTB_at6D / p_at5k) ** p_at5m))
                                        + (((c_NPTB_at6F / p_at5s) ** p_at5u)
                                           + ((c_MiRs_at6G / p_at5w) ** p_at5y))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at6H
                            -> let c_RESTc_at6I = ((toVector x_at6H) Data.Vector.Unboxed.! 3)
                               in (p_at5C / (1 + ((c_RESTc_at6I / p_at5E) ** p_at5G))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at6J
                            -> let c_PTB_at6K = ((toVector x_at6J) Data.Vector.Unboxed.! 0)
                               in (p_at5I * c_PTB_at6K))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at6L
                            -> let c_NPTB_at6M = ((toVector x_at6L) Data.Vector.Unboxed.! 1)
                               in (p_at5K * c_NPTB_at6M))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at6N
                            -> let c_MiRs_at6O = ((toVector x_at6N) Data.Vector.Unboxed.! 2)
                               in (p_at5M * c_MiRs_at6O))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at6P
                            -> let c_RESTc_at6Q = ((toVector x_at6P) Data.Vector.Unboxed.! 3)
                               in (p_at5O * c_RESTc_at6Q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at6R
                            -> let
                                 c_EndoNeuroTFs_at6S = ((toVector x_at6R) Data.Vector.Unboxed.! 4)
                               in (p_at5Q * c_EndoNeuroTFs_at6S))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121555",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121556",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121557",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121558",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121559",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121560",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121561",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121562",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121563",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121564",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121565",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121566",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121567",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121568",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121569",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121570",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121571",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121572",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121573",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121574",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121575",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121576",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121577",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121578",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121579",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121580",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121581",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121582",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121583",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121584",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121585",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121586",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121587",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121588",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121589",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121590",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121591",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121592",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121593",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121594",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121595",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121596",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121597",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121598",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121599",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121600",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121601",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121602",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121603",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121604",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121605",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121606",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [NPTB] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121607",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121608",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121609",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121610",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121611",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121612",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121613",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121614",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121615",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121616",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121617",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121618",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121619",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121620",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121621",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121622",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121623",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121624",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121625",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121626",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121627",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121628",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121629",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121630",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at5R
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7u
                            p_at5Q = code-0.1.0.0:Genome.FixedList.Functions.double g_at5P
                            (g_at5P, gpart_at7u) = Genome.Split.split gpart_at7t
                            p_at5O = code-0.1.0.0:Genome.FixedList.Functions.double g_at5N
                            (g_at5N, gpart_at7t) = Genome.Split.split gpart_at7s
                            p_at5M = code-0.1.0.0:Genome.FixedList.Functions.double g_at5L
                            (g_at5L, gpart_at7s) = Genome.Split.split gpart_at7r
                            p_at5K = code-0.1.0.0:Genome.FixedList.Functions.double g_at5J
                            (g_at5J, gpart_at7r) = Genome.Split.split gpart_at7q
                            p_at5I = code-0.1.0.0:Genome.FixedList.Functions.double g_at5H
                            (g_at5H, gpart_at7q) = Genome.Split.split gpart_at7p
                            p_at5G = Functions.belowten' g_at5F
                            (g_at5F, gpart_at7p) = Genome.Split.split gpart_at7o
                            p_at5E = code-0.1.0.0:Genome.FixedList.Functions.double g_at5D
                            (g_at5D, gpart_at7o) = Genome.Split.split gpart_at7n
                            p_at5C = code-0.1.0.0:Genome.FixedList.Functions.double g_at5B
                            (g_at5B, gpart_at7n) = Genome.Split.split gpart_at7m
                            p_at5A = code-0.1.0.0:Genome.FixedList.Functions.double g_at5z
                            (g_at5z, gpart_at7m) = Genome.Split.split gpart_at7l
                            p_at5y = Functions.belowten' g_at5x
                            (g_at5x, gpart_at7l) = Genome.Split.split gpart_at7k
                            p_at5w = code-0.1.0.0:Genome.FixedList.Functions.double g_at5v
                            (g_at5v, gpart_at7k) = Genome.Split.split gpart_at7j
                            p_at5u = Functions.belowten' g_at5t
                            (g_at5t, gpart_at7j) = Genome.Split.split gpart_at7i
                            p_at5s = code-0.1.0.0:Genome.FixedList.Functions.double g_at5r
                            (g_at5r, gpart_at7i) = Genome.Split.split gpart_at7h
                            p_at5q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5p
                            (g_at5p, gpart_at7h) = Genome.Split.split gpart_at7g
                            p_at5o
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5n
                            (g_at5n, gpart_at7g) = Genome.Split.split gpart_at7f
                            p_at5m = Functions.belowten' g_at5l
                            (g_at5l, gpart_at7f) = Genome.Split.split gpart_at7e
                            p_at5k = code-0.1.0.0:Genome.FixedList.Functions.double g_at5j
                            (g_at5j, gpart_at7e) = Genome.Split.split gpart_at7d
                            p_at5i = code-0.1.0.0:Genome.FixedList.Functions.double g_at5h
                            (g_at5h, gpart_at7d) = Genome.Split.split gpart_at7c
                            p_at5g = code-0.1.0.0:Genome.FixedList.Functions.double g_at5f
                            (g_at5f, gpart_at7c) = Genome.Split.split gpart_at7b
                            p_at5e = Functions.belowten' g_at5d
                            (g_at5d, gpart_at7b) = Genome.Split.split gpart_at7a
                            p_at5c = code-0.1.0.0:Genome.FixedList.Functions.double g_at5b
                            (g_at5b, gpart_at7a) = Genome.Split.split gpart_at79
                            p_at5a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at59
                            (g_at59, gpart_at79) = Genome.Split.split gpart_at78
                            p_at58
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at57
                            (g_at57, gpart_at78) = Genome.Split.split gpart_at77
                            p_at56 = code-0.1.0.0:Genome.FixedList.Functions.double g_at55
                            (g_at55, gpart_at77) = Genome.Split.split gpart_at76
                            p_at54 = Functions.belowten' g_at53
                            (g_at53, gpart_at76) = Genome.Split.split gpart_at75
                            p_at52 = code-0.1.0.0:Genome.FixedList.Functions.double g_at51
                            (g_at51, gpart_at75) = Genome.Split.split gpart_at74
                            p_at50 = Functions.belowten' g_at4Z
                            (g_at4Z, gpart_at74) = Genome.Split.split gpart_at73
                            p_at4Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at4X
                            (g_at4X, gpart_at73) = Genome.Split.split gpart_at72
                            p_at4W = code-0.1.0.0:Genome.FixedList.Functions.double g_at4V
                            (g_at4V, gpart_at72) = Genome.Split.split gpart_at71
                            p_at4U = Functions.belowten' g_at4T
                            (g_at4T, gpart_at71) = Genome.Split.split gpart_at70
                            p_at4S = code-0.1.0.0:Genome.FixedList.Functions.double g_at4R
                            (g_at4R, gpart_at70) = Genome.Split.split gpart_at6Z
                            p_at4Q
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4P
                            (g_at4P, gpart_at6Z) = Genome.Split.split gpart_at6Y
                            p_at4O
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at4N
                            (g_at4N, gpart_at6Y) = Genome.Split.split gpart_at6X
                            p_at4M = code-0.1.0.0:Genome.FixedList.Functions.double g_at4L
                            (g_at4L, gpart_at6X) = Genome.Split.split gpart_at6W
                            p_at4K = code-0.1.0.0:Genome.FixedList.Functions.double g_at4J
                            (g_at4J, gpart_at6W) = Genome.Split.split gpart_at6V
                            p_at4I = code-0.1.0.0:Genome.FixedList.Functions.double g_at4H
                            (g_at4H, gpart_at6V) = Genome.Split.split gpart_at6U
                            p_at4G = code-0.1.0.0:Genome.FixedList.Functions.double g_at4F
                            (g_at4F, gpart_at6U) = Genome.Split.split gpart_at6T
                            p_at4E = code-0.1.0.0:Genome.FixedList.Functions.double g_at4D
                            (g_at4D, gpart_at6T) = Genome.Split.split genome_at5R
                          in
                            \ desc_at5S
                              -> case desc_at5S of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4E)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4G)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4I)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4K)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4M)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4O)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Q)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4S)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4U)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4W)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at4Y)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at50)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at52)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at54)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at56)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at58)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5a)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5c)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5e)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5g)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5i)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5k)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5m)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5o)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5q)
                                   "Inhibition coef [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5s)
                                   "Inhibition hill [NPTB] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5u)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5w)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5y)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5A)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5C)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5E)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5G)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5I)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5K)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5M)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5O)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Q)
                                   _ -> Nothing }}
