src/ineurons/Settings.hs:22:31-138: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_a26Cs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26D9
                      p_a26Cr = double g_a26Cq
                      (g_a26Cq, gpart_a26D9) = Genome.Split.split gpart_a26D8
                      p_a26Cp = double g_a26Co
                      (g_a26Co, gpart_a26D8) = Genome.Split.split gpart_a26D7
                      p_a26Cn = double g_a26Cm
                      (g_a26Cm, gpart_a26D7) = Genome.Split.split gpart_a26D6
                      p_a26Cl = double g_a26Ck
                      (g_a26Ck, gpart_a26D6) = Genome.Split.split gpart_a26D5
                      p_a26Cj = double g_a26Ci
                      (g_a26Ci, gpart_a26D5) = Genome.Split.split gpart_a26D4
                      p_a26Ch = double g_a26Cg
                      (g_a26Cg, gpart_a26D4) = Genome.Split.split gpart_a26D3
                      p_a26Cf = Functions.belowten' g_a26Ce
                      (g_a26Ce, gpart_a26D3) = Genome.Split.split gpart_a26D2
                      p_a26Cd = double g_a26Cc
                      (g_a26Cc, gpart_a26D2) = Genome.Split.split gpart_a26D1
                      p_a26Cb = Functions.belowten' g_a26Ca
                      (g_a26Ca, gpart_a26D1) = Genome.Split.split gpart_a26D0
                      p_a26C9 = double g_a26C8
                      (g_a26C8, gpart_a26D0) = Genome.Split.split gpart_a26CZ
                      p_a26C7 = double g_a26C6
                      (g_a26C6, gpart_a26CZ) = Genome.Split.split gpart_a26CY
                      p_a26C5 = double g_a26C4
                      (g_a26C4, gpart_a26CY) = Genome.Split.split gpart_a26CX
                      p_a26C3 = Functions.belowten' g_a26C2
                      (g_a26C2, gpart_a26CX) = Genome.Split.split gpart_a26CW
                      p_a26C1 = double g_a26C0
                      (g_a26C0, gpart_a26CW) = Genome.Split.split gpart_a26CV
                      p_a26BZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BY
                      (g_a26BY, gpart_a26CV) = Genome.Split.split gpart_a26CU
                      p_a26BX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BW
                      (g_a26BW, gpart_a26CU) = Genome.Split.split gpart_a26CT
                      p_a26BV = Functions.belowten' g_a26BU
                      (g_a26BU, gpart_a26CT) = Genome.Split.split gpart_a26CS
                      p_a26BT = double g_a26BS
                      (g_a26BS, gpart_a26CS) = Genome.Split.split gpart_a26CR
                      p_a26BR = double g_a26BQ
                      (g_a26BQ, gpart_a26CR) = Genome.Split.split gpart_a26CQ
                      p_a26BP = double g_a26BO
                      (g_a26BO, gpart_a26CQ) = Genome.Split.split gpart_a26CP
                      p_a26BN = Functions.belowten' g_a26BM
                      (g_a26BM, gpart_a26CP) = Genome.Split.split gpart_a26CO
                      p_a26BL = double g_a26BK
                      (g_a26BK, gpart_a26CO) = Genome.Split.split gpart_a26CN
                      p_a26BJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BI
                      (g_a26BI, gpart_a26CN) = Genome.Split.split gpart_a26CM
                      p_a26BH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BG
                      (g_a26BG, gpart_a26CM) = Genome.Split.split gpart_a26CL
                      p_a26BF = double g_a26BE
                      (g_a26BE, gpart_a26CL) = Genome.Split.split gpart_a26CK
                      p_a26BD = Functions.belowten' g_a26BC
                      (g_a26BC, gpart_a26CK) = Genome.Split.split gpart_a26CJ
                      p_a26BB = double g_a26BA
                      (g_a26BA, gpart_a26CJ) = Genome.Split.split gpart_a26CI
                      p_a26Bz = Functions.belowten' g_a26By
                      (g_a26By, gpart_a26CI) = Genome.Split.split gpart_a26CH
                      p_a26Bx = double g_a26Bw
                      (g_a26Bw, gpart_a26CH) = Genome.Split.split gpart_a26CG
                      p_a26Bv = double g_a26Bu
                      (g_a26Bu, gpart_a26CG) = Genome.Split.split gpart_a26CF
                      p_a26Bt = double g_a26Bs
                      (g_a26Bs, gpart_a26CF) = Genome.Split.split gpart_a26CE
                      p_a26Br = Functions.belowten' g_a26Bq
                      (g_a26Bq, gpart_a26CE) = Genome.Split.split gpart_a26CD
                      p_a26Bp = double g_a26Bo
                      (g_a26Bo, gpart_a26CD) = Genome.Split.split gpart_a26CC
                      p_a26Bn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bm
                      (g_a26Bm, gpart_a26CC) = Genome.Split.split gpart_a26CB
                      p_a26Bl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bk
                      (g_a26Bk, gpart_a26CB) = Genome.Split.split gpart_a26CA
                      p_a26Bj = Functions.belowten' g_a26Bi
                      (g_a26Bi, gpart_a26CA) = Genome.Split.split gpart_a26Cz
                      p_a26Bh = double g_a26Bg
                      (g_a26Bg, gpart_a26Cz) = Genome.Split.split gpart_a26Cy
                      p_a26Bf = double g_a26Be
                      (g_a26Be, gpart_a26Cy) = Genome.Split.split gpart_a26Cx
                      p_a26Bd = double g_a26Bc
                      (g_a26Bc, gpart_a26Cx) = Genome.Split.split gpart_a26Cw
                      p_a26Bb = double g_a26Ba
                      (g_a26Ba, gpart_a26Cw) = Genome.Split.split gpart_a26Cv
                      p_a26B9 = double g_a26B8
                      (g_a26B8, gpart_a26Cv) = Genome.Split.split gpart_a26Cu
                      p_a26B7 = double g_a26B6
                      (g_a26B6, gpart_a26Cu) = Genome.Split.split genome_a26Cs
                    in  \ x_a26Da
                          -> let
                               c_PTB_a26Df
                                 = ((Data.Fixed.Vector.toVector x_a26Da) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26Dd
                                 = ((Data.Fixed.Vector.toVector x_a26Da) Data.Vector.Unboxed.! 2)
                               c_RESTc_a26Db
                                 = ((Data.Fixed.Vector.toVector x_a26Da) Data.Vector.Unboxed.! 3)
                               c_NPTB_a26Dj
                                 = ((Data.Fixed.Vector.toVector x_a26Da) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a26Dw
                                 = ((Data.Fixed.Vector.toVector x_a26Da) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Bf
                                     * ((p_a26Bt + ((c_RESTc_a26Db / p_a26Bh) ** p_a26Bj))
                                        / (((1 + p_a26Bt) + ((c_RESTc_a26Db / p_a26Bh) ** p_a26Bj))
                                           + ((c_MiRs_a26Dd / p_a26Bp) ** p_a26Br))))
                                    + (negate (p_a26Cj * c_PTB_a26Df))),
                                   ((p_a26Bv
                                     / (1
                                        + (((c_MiRs_a26Dd / p_a26Bx) ** p_a26Bz)
                                           + ((c_PTB_a26Df / p_a26BB) ** p_a26BD))))
                                    + (negate (p_a26Cl * c_NPTB_a26Dj))),
                                   ((p_a26BF
                                     * ((p_a26BP + ((p_a26Bb / p_a26BH) ** p_a26BJ))
                                        / (((1 + p_a26BP) + ((p_a26Bb / p_a26BH) ** p_a26BJ))
                                           + ((c_RESTc_a26Db / p_a26BL) ** p_a26BN))))
                                    + (negate (p_a26Cn * c_MiRs_a26Dd))),
                                   ((p_a26BR
                                     * ((p_a26C5 + ((c_PTB_a26Df / p_a26BT) ** p_a26BV))
                                        / (((1 + p_a26C5) + ((c_PTB_a26Df / p_a26BT) ** p_a26BV))
                                           + (((p_a26B7 / p_a26BX) ** p_a26BZ)
                                              + ((c_MiRs_a26Dd / p_a26C1) ** p_a26C3)))))
                                    + (negate (p_a26Cp * c_RESTc_a26Db))),
                                   ((p_a26C7
                                     * ((p_a26Ch + ((c_MiRs_a26Dd / p_a26C9) ** p_a26Cb))
                                        / (((1 + p_a26Ch) + ((c_MiRs_a26Dd / p_a26C9) ** p_a26Cb))
                                           + ((c_RESTc_a26Db / p_a26Cd) ** p_a26Cf))))
                                    + (negate (p_a26Cr * c_EndoNeuroTFs_a26Dw)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511812",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511813",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511814",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511815",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511816",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511817",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511818",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511819",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511820",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511821",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511822",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511823",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511824",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511825",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511826",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511827",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511828",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511829",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511830",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511831",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511832",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511833",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511834",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511835",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511836",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511837",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511838",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511839",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511840",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511841",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511842",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511843",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511844",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511845",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511846",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511847",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511848",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511849",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511850",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511851",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511852",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511853",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511854",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511855",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511856",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511857",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511858",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511859",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511860",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511861",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511862",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511863",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511864",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511865",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511866",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511867",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511868",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511869",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511870",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511871",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511872",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511873",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511874",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511875",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511876",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511877",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511878",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511879",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511880",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511881",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511882",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511883",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511884",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511885",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511886",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511887",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511888",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511889",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511890",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511891",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511892",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511893",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679511894",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679511895",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Cs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Ec
                            p_a26Cr = double g_a26Cq
                            (g_a26Cq, gpart_a26Ec) = Genome.Split.split gpart_a26Eb
                            p_a26Cp = double g_a26Co
                            (g_a26Co, gpart_a26Eb) = Genome.Split.split gpart_a26Ea
                            p_a26Cn = double g_a26Cm
                            (g_a26Cm, gpart_a26Ea) = Genome.Split.split gpart_a26E9
                            p_a26Cl = double g_a26Ck
                            (g_a26Ck, gpart_a26E9) = Genome.Split.split gpart_a26E8
                            p_a26Cj = double g_a26Ci
                            (g_a26Ci, gpart_a26E8) = Genome.Split.split gpart_a26E7
                            p_a26Ch = double g_a26Cg
                            (g_a26Cg, gpart_a26E7) = Genome.Split.split gpart_a26E6
                            p_a26Cf = Functions.belowten' g_a26Ce
                            (g_a26Ce, gpart_a26E6) = Genome.Split.split gpart_a26E5
                            p_a26Cd = double g_a26Cc
                            (g_a26Cc, gpart_a26E5) = Genome.Split.split gpart_a26E4
                            p_a26Cb = Functions.belowten' g_a26Ca
                            (g_a26Ca, gpart_a26E4) = Genome.Split.split gpart_a26E3
                            p_a26C9 = double g_a26C8
                            (g_a26C8, gpart_a26E3) = Genome.Split.split gpart_a26E2
                            p_a26C7 = double g_a26C6
                            (g_a26C6, gpart_a26E2) = Genome.Split.split gpart_a26E1
                            p_a26C5 = double g_a26C4
                            (g_a26C4, gpart_a26E1) = Genome.Split.split gpart_a26E0
                            p_a26C3 = Functions.belowten' g_a26C2
                            (g_a26C2, gpart_a26E0) = Genome.Split.split gpart_a26DZ
                            p_a26C1 = double g_a26C0
                            (g_a26C0, gpart_a26DZ) = Genome.Split.split gpart_a26DY
                            p_a26BZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BY
                            (g_a26BY, gpart_a26DY) = Genome.Split.split gpart_a26DX
                            p_a26BX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BW
                            (g_a26BW, gpart_a26DX) = Genome.Split.split gpart_a26DW
                            p_a26BV = Functions.belowten' g_a26BU
                            (g_a26BU, gpart_a26DW) = Genome.Split.split gpart_a26DV
                            p_a26BT = double g_a26BS
                            (g_a26BS, gpart_a26DV) = Genome.Split.split gpart_a26DU
                            p_a26BR = double g_a26BQ
                            (g_a26BQ, gpart_a26DU) = Genome.Split.split gpart_a26DT
                            p_a26BP = double g_a26BO
                            (g_a26BO, gpart_a26DT) = Genome.Split.split gpart_a26DS
                            p_a26BN = Functions.belowten' g_a26BM
                            (g_a26BM, gpart_a26DS) = Genome.Split.split gpart_a26DR
                            p_a26BL = double g_a26BK
                            (g_a26BK, gpart_a26DR) = Genome.Split.split gpart_a26DQ
                            p_a26BJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BI
                            (g_a26BI, gpart_a26DQ) = Genome.Split.split gpart_a26DP
                            p_a26BH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26BG
                            (g_a26BG, gpart_a26DP) = Genome.Split.split gpart_a26DO
                            p_a26BF = double g_a26BE
                            (g_a26BE, gpart_a26DO) = Genome.Split.split gpart_a26DN
                            p_a26BD = Functions.belowten' g_a26BC
                            (g_a26BC, gpart_a26DN) = Genome.Split.split gpart_a26DM
                            p_a26BB = double g_a26BA
                            (g_a26BA, gpart_a26DM) = Genome.Split.split gpart_a26DL
                            p_a26Bz = Functions.belowten' g_a26By
                            (g_a26By, gpart_a26DL) = Genome.Split.split gpart_a26DK
                            p_a26Bx = double g_a26Bw
                            (g_a26Bw, gpart_a26DK) = Genome.Split.split gpart_a26DJ
                            p_a26Bv = double g_a26Bu
                            (g_a26Bu, gpart_a26DJ) = Genome.Split.split gpart_a26DI
                            p_a26Bt = double g_a26Bs
                            (g_a26Bs, gpart_a26DI) = Genome.Split.split gpart_a26DH
                            p_a26Br = Functions.belowten' g_a26Bq
                            (g_a26Bq, gpart_a26DH) = Genome.Split.split gpart_a26DG
                            p_a26Bp = double g_a26Bo
                            (g_a26Bo, gpart_a26DG) = Genome.Split.split gpart_a26DF
                            p_a26Bn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bm
                            (g_a26Bm, gpart_a26DF) = Genome.Split.split gpart_a26DE
                            p_a26Bl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Bk
                            (g_a26Bk, gpart_a26DE) = Genome.Split.split gpart_a26DD
                            p_a26Bj = Functions.belowten' g_a26Bi
                            (g_a26Bi, gpart_a26DD) = Genome.Split.split gpart_a26DC
                            p_a26Bh = double g_a26Bg
                            (g_a26Bg, gpart_a26DC) = Genome.Split.split gpart_a26DB
                            p_a26Bf = double g_a26Be
                            (g_a26Be, gpart_a26DB) = Genome.Split.split gpart_a26DA
                            p_a26Bd = double g_a26Bc
                            (g_a26Bc, gpart_a26DA) = Genome.Split.split gpart_a26Dz
                            p_a26Bb = double g_a26Ba
                            (g_a26Ba, gpart_a26Dz) = Genome.Split.split gpart_a26Dy
                            p_a26B9 = double g_a26B8
                            (g_a26B8, gpart_a26Dy) = Genome.Split.split gpart_a26Dx
                            p_a26B7 = double g_a26B6
                            (g_a26B6, gpart_a26Dx) = Genome.Split.split genome_a26Cs
                          in
                            \ desc_a26Ct
                              -> case desc_a26Ct of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B7)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26B9)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bb)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bd)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bf)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bh)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bj)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bl)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bn)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bp)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Br)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bt)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bv)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bx)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Bz)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BB)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BD)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BF)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BH)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26BZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26C1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26C3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26C5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26C7)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26C9)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cb)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cd)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cf)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ch)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Cr)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:23:31-133: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_a26GI
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Hp
                      p_a26GH = double g_a26GG
                      (g_a26GG, gpart_a26Hp) = Genome.Split.split gpart_a26Ho
                      p_a26GF = double g_a26GE
                      (g_a26GE, gpart_a26Ho) = Genome.Split.split gpart_a26Hn
                      p_a26GD = double g_a26GC
                      (g_a26GC, gpart_a26Hn) = Genome.Split.split gpart_a26Hm
                      p_a26GB = double g_a26GA
                      (g_a26GA, gpart_a26Hm) = Genome.Split.split gpart_a26Hl
                      p_a26Gz = double g_a26Gy
                      (g_a26Gy, gpart_a26Hl) = Genome.Split.split gpart_a26Hk
                      p_a26Gx = double g_a26Gw
                      (g_a26Gw, gpart_a26Hk) = Genome.Split.split gpart_a26Hj
                      p_a26Gv = Functions.belowten' g_a26Gu
                      (g_a26Gu, gpart_a26Hj) = Genome.Split.split gpart_a26Hi
                      p_a26Gt = double g_a26Gs
                      (g_a26Gs, gpart_a26Hi) = Genome.Split.split gpart_a26Hh
                      p_a26Gr = Functions.belowten' g_a26Gq
                      (g_a26Gq, gpart_a26Hh) = Genome.Split.split gpart_a26Hg
                      p_a26Gp = double g_a26Go
                      (g_a26Go, gpart_a26Hg) = Genome.Split.split gpart_a26Hf
                      p_a26Gn = double g_a26Gm
                      (g_a26Gm, gpart_a26Hf) = Genome.Split.split gpart_a26He
                      p_a26Gl = double g_a26Gk
                      (g_a26Gk, gpart_a26He) = Genome.Split.split gpart_a26Hd
                      p_a26Gj = Functions.belowten' g_a26Gi
                      (g_a26Gi, gpart_a26Hd) = Genome.Split.split gpart_a26Hc
                      p_a26Gh = double g_a26Gg
                      (g_a26Gg, gpart_a26Hc) = Genome.Split.split gpart_a26Hb
                      p_a26Gf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ge
                      (g_a26Ge, gpart_a26Hb) = Genome.Split.split gpart_a26Ha
                      p_a26Gd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Gc
                      (g_a26Gc, gpart_a26Ha) = Genome.Split.split gpart_a26H9
                      p_a26Gb = Functions.belowten' g_a26Ga
                      (g_a26Ga, gpart_a26H9) = Genome.Split.split gpart_a26H8
                      p_a26G9 = double g_a26G8
                      (g_a26G8, gpart_a26H8) = Genome.Split.split gpart_a26H7
                      p_a26G7 = double g_a26G6
                      (g_a26G6, gpart_a26H7) = Genome.Split.split gpart_a26H6
                      p_a26G5 = double g_a26G4
                      (g_a26G4, gpart_a26H6) = Genome.Split.split gpart_a26H5
                      p_a26G3 = Functions.belowten' g_a26G2
                      (g_a26G2, gpart_a26H5) = Genome.Split.split gpart_a26H4
                      p_a26G1 = double g_a26G0
                      (g_a26G0, gpart_a26H4) = Genome.Split.split gpart_a26H3
                      p_a26FZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FY
                      (g_a26FY, gpart_a26H3) = Genome.Split.split gpart_a26H2
                      p_a26FX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FW
                      (g_a26FW, gpart_a26H2) = Genome.Split.split gpart_a26H1
                      p_a26FV = double g_a26FU
                      (g_a26FU, gpart_a26H1) = Genome.Split.split gpart_a26H0
                      p_a26FT = Functions.belowten' g_a26FS
                      (g_a26FS, gpart_a26H0) = Genome.Split.split gpart_a26GZ
                      p_a26FR = double g_a26FQ
                      (g_a26FQ, gpart_a26GZ) = Genome.Split.split gpart_a26GY
                      p_a26FP = Functions.belowten' g_a26FO
                      (g_a26FO, gpart_a26GY) = Genome.Split.split gpart_a26GX
                      p_a26FN = double g_a26FM
                      (g_a26FM, gpart_a26GX) = Genome.Split.split gpart_a26GW
                      p_a26FL = double g_a26FK
                      (g_a26FK, gpart_a26GW) = Genome.Split.split gpart_a26GV
                      p_a26FJ = double g_a26FI
                      (g_a26FI, gpart_a26GV) = Genome.Split.split gpart_a26GU
                      p_a26FH = Functions.belowten' g_a26FG
                      (g_a26FG, gpart_a26GU) = Genome.Split.split gpart_a26GT
                      p_a26FF = double g_a26FE
                      (g_a26FE, gpart_a26GT) = Genome.Split.split gpart_a26GS
                      p_a26FD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FC
                      (g_a26FC, gpart_a26GS) = Genome.Split.split gpart_a26GR
                      p_a26FB
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FA
                      (g_a26FA, gpart_a26GR) = Genome.Split.split gpart_a26GQ
                      p_a26Fz = Functions.belowten' g_a26Fy
                      (g_a26Fy, gpart_a26GQ) = Genome.Split.split gpart_a26GP
                      p_a26Fx = double g_a26Fw
                      (g_a26Fw, gpart_a26GP) = Genome.Split.split gpart_a26GO
                      p_a26Fv = double g_a26Fu
                      (g_a26Fu, gpart_a26GO) = Genome.Split.split gpart_a26GN
                      p_a26Ft = double g_a26Fs
                      (g_a26Fs, gpart_a26GN) = Genome.Split.split gpart_a26GM
                      p_a26Fr = double g_a26Fq
                      (g_a26Fq, gpart_a26GM) = Genome.Split.split gpart_a26GL
                      p_a26Fp = double g_a26Fo
                      (g_a26Fo, gpart_a26GL) = Genome.Split.split gpart_a26GK
                      p_a26Fn = double g_a26Fm
                      (g_a26Fm, gpart_a26GK) = Genome.Split.split genome_a26GI
                    in  \ x_a26Hq
                          -> let
                               c_PTB_a26Hv
                                 = ((Data.Fixed.Vector.toVector x_a26Hq) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26Ht
                                 = ((Data.Fixed.Vector.toVector x_a26Hq) Data.Vector.Unboxed.! 2)
                               c_RESTc_a26Hr
                                 = ((Data.Fixed.Vector.toVector x_a26Hq) Data.Vector.Unboxed.! 3)
                               c_NPTB_a26Hz
                                 = ((Data.Fixed.Vector.toVector x_a26Hq) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a26HM
                                 = ((Data.Fixed.Vector.toVector x_a26Hq) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26Fv
                                     * ((p_a26FJ + ((c_RESTc_a26Hr / p_a26Fx) ** p_a26Fz))
                                        / (((1 + p_a26FJ) + ((c_RESTc_a26Hr / p_a26Fx) ** p_a26Fz))
                                           + ((c_MiRs_a26Ht / p_a26FF) ** p_a26FH))))
                                    + (negate (p_a26Gz * c_PTB_a26Hv))),
                                   ((p_a26FL
                                     / (1
                                        + (((c_MiRs_a26Ht / p_a26FN) ** p_a26FP)
                                           + ((c_PTB_a26Hv / p_a26FR) ** p_a26FT))))
                                    + (negate (p_a26GB * c_NPTB_a26Hz))),
                                   ((p_a26FV
                                     * (p_a26G5
                                        / ((1 + p_a26G5) + ((c_RESTc_a26Hr / p_a26G1) ** p_a26G3))))
                                    + (negate (p_a26GD * c_MiRs_a26Ht))),
                                   ((p_a26G7
                                     * ((p_a26Gl + ((c_PTB_a26Hv / p_a26G9) ** p_a26Gb))
                                        / (((1 + p_a26Gl) + ((c_PTB_a26Hv / p_a26G9) ** p_a26Gb))
                                           + (((p_a26Fn / p_a26Gd) ** p_a26Gf)
                                              + ((c_MiRs_a26Ht / p_a26Gh) ** p_a26Gj)))))
                                    + (negate (p_a26GF * c_RESTc_a26Hr))),
                                   ((p_a26Gn
                                     * ((p_a26Gx + ((c_MiRs_a26Ht / p_a26Gp) ** p_a26Gr))
                                        / (((1 + p_a26Gx) + ((c_MiRs_a26Ht / p_a26Gp) ** p_a26Gr))
                                           + ((c_RESTc_a26Hr / p_a26Gt) ** p_a26Gv))))
                                    + (negate (p_a26GH * c_EndoNeuroTFs_a26HM)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512076",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512077",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512078",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512079",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512080",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512081",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512082",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512083",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512084",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512085",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512086",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512087",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512088",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512089",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512090",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512091",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512092",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512093",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512094",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512095",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512096",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512097",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512098",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512099",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512100",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512101",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512102",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512103",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512104",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512105",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512106",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512107",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512108",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512109",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512110",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512111",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512112",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512113",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512114",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512115",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512116",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512117",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512118",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512119",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512120",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512121",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512122",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512123",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512124",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512125",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512126",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512127",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512128",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512129",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512130",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512131",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512132",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512133",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512134",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512135",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512136",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512137",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512138",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512139",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512140",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512141",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512142",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512143",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512144",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512145",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26GI
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26Is
                            p_a26GH = double g_a26GG
                            (g_a26GG, gpart_a26Is) = Genome.Split.split gpart_a26Ir
                            p_a26GF = double g_a26GE
                            (g_a26GE, gpart_a26Ir) = Genome.Split.split gpart_a26Iq
                            p_a26GD = double g_a26GC
                            (g_a26GC, gpart_a26Iq) = Genome.Split.split gpart_a26Ip
                            p_a26GB = double g_a26GA
                            (g_a26GA, gpart_a26Ip) = Genome.Split.split gpart_a26Io
                            p_a26Gz = double g_a26Gy
                            (g_a26Gy, gpart_a26Io) = Genome.Split.split gpart_a26In
                            p_a26Gx = double g_a26Gw
                            (g_a26Gw, gpart_a26In) = Genome.Split.split gpart_a26Im
                            p_a26Gv = Functions.belowten' g_a26Gu
                            (g_a26Gu, gpart_a26Im) = Genome.Split.split gpart_a26Il
                            p_a26Gt = double g_a26Gs
                            (g_a26Gs, gpart_a26Il) = Genome.Split.split gpart_a26Ik
                            p_a26Gr = Functions.belowten' g_a26Gq
                            (g_a26Gq, gpart_a26Ik) = Genome.Split.split gpart_a26Ij
                            p_a26Gp = double g_a26Go
                            (g_a26Go, gpart_a26Ij) = Genome.Split.split gpart_a26Ii
                            p_a26Gn = double g_a26Gm
                            (g_a26Gm, gpart_a26Ii) = Genome.Split.split gpart_a26Ih
                            p_a26Gl = double g_a26Gk
                            (g_a26Gk, gpart_a26Ih) = Genome.Split.split gpart_a26Ig
                            p_a26Gj = Functions.belowten' g_a26Gi
                            (g_a26Gi, gpart_a26Ig) = Genome.Split.split gpart_a26If
                            p_a26Gh = double g_a26Gg
                            (g_a26Gg, gpart_a26If) = Genome.Split.split gpart_a26Ie
                            p_a26Gf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ge
                            (g_a26Ge, gpart_a26Ie) = Genome.Split.split gpart_a26Id
                            p_a26Gd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Gc
                            (g_a26Gc, gpart_a26Id) = Genome.Split.split gpart_a26Ic
                            p_a26Gb = Functions.belowten' g_a26Ga
                            (g_a26Ga, gpart_a26Ic) = Genome.Split.split gpart_a26Ib
                            p_a26G9 = double g_a26G8
                            (g_a26G8, gpart_a26Ib) = Genome.Split.split gpart_a26Ia
                            p_a26G7 = double g_a26G6
                            (g_a26G6, gpart_a26Ia) = Genome.Split.split gpart_a26I9
                            p_a26G5 = double g_a26G4
                            (g_a26G4, gpart_a26I9) = Genome.Split.split gpart_a26I8
                            p_a26G3 = Functions.belowten' g_a26G2
                            (g_a26G2, gpart_a26I8) = Genome.Split.split gpart_a26I7
                            p_a26G1 = double g_a26G0
                            (g_a26G0, gpart_a26I7) = Genome.Split.split gpart_a26I6
                            p_a26FZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FY
                            (g_a26FY, gpart_a26I6) = Genome.Split.split gpart_a26I5
                            p_a26FX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FW
                            (g_a26FW, gpart_a26I5) = Genome.Split.split gpart_a26I4
                            p_a26FV = double g_a26FU
                            (g_a26FU, gpart_a26I4) = Genome.Split.split gpart_a26I3
                            p_a26FT = Functions.belowten' g_a26FS
                            (g_a26FS, gpart_a26I3) = Genome.Split.split gpart_a26I2
                            p_a26FR = double g_a26FQ
                            (g_a26FQ, gpart_a26I2) = Genome.Split.split gpart_a26I1
                            p_a26FP = Functions.belowten' g_a26FO
                            (g_a26FO, gpart_a26I1) = Genome.Split.split gpart_a26I0
                            p_a26FN = double g_a26FM
                            (g_a26FM, gpart_a26I0) = Genome.Split.split gpart_a26HZ
                            p_a26FL = double g_a26FK
                            (g_a26FK, gpart_a26HZ) = Genome.Split.split gpart_a26HY
                            p_a26FJ = double g_a26FI
                            (g_a26FI, gpart_a26HY) = Genome.Split.split gpart_a26HX
                            p_a26FH = Functions.belowten' g_a26FG
                            (g_a26FG, gpart_a26HX) = Genome.Split.split gpart_a26HW
                            p_a26FF = double g_a26FE
                            (g_a26FE, gpart_a26HW) = Genome.Split.split gpart_a26HV
                            p_a26FD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FC
                            (g_a26FC, gpart_a26HV) = Genome.Split.split gpart_a26HU
                            p_a26FB
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26FA
                            (g_a26FA, gpart_a26HU) = Genome.Split.split gpart_a26HT
                            p_a26Fz = Functions.belowten' g_a26Fy
                            (g_a26Fy, gpart_a26HT) = Genome.Split.split gpart_a26HS
                            p_a26Fx = double g_a26Fw
                            (g_a26Fw, gpart_a26HS) = Genome.Split.split gpart_a26HR
                            p_a26Fv = double g_a26Fu
                            (g_a26Fu, gpart_a26HR) = Genome.Split.split gpart_a26HQ
                            p_a26Ft = double g_a26Fs
                            (g_a26Fs, gpart_a26HQ) = Genome.Split.split gpart_a26HP
                            p_a26Fr = double g_a26Fq
                            (g_a26Fq, gpart_a26HP) = Genome.Split.split gpart_a26HO
                            p_a26Fp = double g_a26Fo
                            (g_a26Fo, gpart_a26HO) = Genome.Split.split gpart_a26HN
                            p_a26Fn = double g_a26Fm
                            (g_a26Fm, gpart_a26HN) = Genome.Split.split genome_a26GI
                          in
                            \ desc_a26GJ
                              -> case desc_a26GJ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fn)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fp)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fr)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ft)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fv)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fx)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Fz)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FB)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FD)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FF)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FH)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FJ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FL)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FN)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FP)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FR)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FT)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FV)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FX)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26FZ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G1)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G3)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G5)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G7)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26G9)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gb)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gd)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gf)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gh)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gj)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gl)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gn)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gp)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gr)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gt)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gv)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gx)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Gz)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26GB)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26GD)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26GF)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26GH)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:24:31-136: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_a26KY
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26LF
                      p_a26KX = double g_a26KW
                      (g_a26KW, gpart_a26LF) = Genome.Split.split gpart_a26LE
                      p_a26KV = double g_a26KU
                      (g_a26KU, gpart_a26LE) = Genome.Split.split gpart_a26LD
                      p_a26KT = double g_a26KS
                      (g_a26KS, gpart_a26LD) = Genome.Split.split gpart_a26LC
                      p_a26KR = double g_a26KQ
                      (g_a26KQ, gpart_a26LC) = Genome.Split.split gpart_a26LB
                      p_a26KP = double g_a26KO
                      (g_a26KO, gpart_a26LB) = Genome.Split.split gpart_a26LA
                      p_a26KN = double g_a26KM
                      (g_a26KM, gpart_a26LA) = Genome.Split.split gpart_a26Lz
                      p_a26KL = Functions.belowten' g_a26KK
                      (g_a26KK, gpart_a26Lz) = Genome.Split.split gpart_a26Ly
                      p_a26KJ = double g_a26KI
                      (g_a26KI, gpart_a26Ly) = Genome.Split.split gpart_a26Lx
                      p_a26KH = Functions.belowten' g_a26KG
                      (g_a26KG, gpart_a26Lx) = Genome.Split.split gpart_a26Lw
                      p_a26KF = double g_a26KE
                      (g_a26KE, gpart_a26Lw) = Genome.Split.split gpart_a26Lv
                      p_a26KD = double g_a26KC
                      (g_a26KC, gpart_a26Lv) = Genome.Split.split gpart_a26Lu
                      p_a26KB = double g_a26KA
                      (g_a26KA, gpart_a26Lu) = Genome.Split.split gpart_a26Lt
                      p_a26Kz = Functions.belowten' g_a26Ky
                      (g_a26Ky, gpart_a26Lt) = Genome.Split.split gpart_a26Ls
                      p_a26Kx = double g_a26Kw
                      (g_a26Kw, gpart_a26Ls) = Genome.Split.split gpart_a26Lr
                      p_a26Kv
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ku
                      (g_a26Ku, gpart_a26Lr) = Genome.Split.split gpart_a26Lq
                      p_a26Kt
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ks
                      (g_a26Ks, gpart_a26Lq) = Genome.Split.split gpart_a26Lp
                      p_a26Kr = Functions.belowten' g_a26Kq
                      (g_a26Kq, gpart_a26Lp) = Genome.Split.split gpart_a26Lo
                      p_a26Kp = double g_a26Ko
                      (g_a26Ko, gpart_a26Lo) = Genome.Split.split gpart_a26Ln
                      p_a26Kn = double g_a26Km
                      (g_a26Km, gpart_a26Ln) = Genome.Split.split gpart_a26Lm
                      p_a26Kl = double g_a26Kk
                      (g_a26Kk, gpart_a26Lm) = Genome.Split.split gpart_a26Ll
                      p_a26Kj = Functions.belowten' g_a26Ki
                      (g_a26Ki, gpart_a26Ll) = Genome.Split.split gpart_a26Lk
                      p_a26Kh = double g_a26Kg
                      (g_a26Kg, gpart_a26Lk) = Genome.Split.split gpart_a26Lj
                      p_a26Kf
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ke
                      (g_a26Ke, gpart_a26Lj) = Genome.Split.split gpart_a26Li
                      p_a26Kd
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Kc
                      (g_a26Kc, gpart_a26Li) = Genome.Split.split gpart_a26Lh
                      p_a26Kb = double g_a26Ka
                      (g_a26Ka, gpart_a26Lh) = Genome.Split.split gpart_a26Lg
                      p_a26K9 = Functions.belowten' g_a26K8
                      (g_a26K8, gpart_a26Lg) = Genome.Split.split gpart_a26Lf
                      p_a26K7 = double g_a26K6
                      (g_a26K6, gpart_a26Lf) = Genome.Split.split gpart_a26Le
                      p_a26K5 = Functions.belowten' g_a26K4
                      (g_a26K4, gpart_a26Le) = Genome.Split.split gpart_a26Ld
                      p_a26K3 = double g_a26K2
                      (g_a26K2, gpart_a26Ld) = Genome.Split.split gpart_a26Lc
                      p_a26K1 = double g_a26K0
                      (g_a26K0, gpart_a26Lc) = Genome.Split.split gpart_a26Lb
                      p_a26JZ = double g_a26JY
                      (g_a26JY, gpart_a26Lb) = Genome.Split.split gpart_a26La
                      p_a26JX = Functions.belowten' g_a26JW
                      (g_a26JW, gpart_a26La) = Genome.Split.split gpart_a26L9
                      p_a26JV = double g_a26JU
                      (g_a26JU, gpart_a26L9) = Genome.Split.split gpart_a26L8
                      p_a26JT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26JS
                      (g_a26JS, gpart_a26L8) = Genome.Split.split gpart_a26L7
                      p_a26JR
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26JQ
                      (g_a26JQ, gpart_a26L7) = Genome.Split.split gpart_a26L6
                      p_a26JP = Functions.belowten' g_a26JO
                      (g_a26JO, gpart_a26L6) = Genome.Split.split gpart_a26L5
                      p_a26JN = double g_a26JM
                      (g_a26JM, gpart_a26L5) = Genome.Split.split gpart_a26L4
                      p_a26JL = double g_a26JK
                      (g_a26JK, gpart_a26L4) = Genome.Split.split gpart_a26L3
                      p_a26JJ = double g_a26JI
                      (g_a26JI, gpart_a26L3) = Genome.Split.split gpart_a26L2
                      p_a26JH = double g_a26JG
                      (g_a26JG, gpart_a26L2) = Genome.Split.split gpart_a26L1
                      p_a26JF = double g_a26JE
                      (g_a26JE, gpart_a26L1) = Genome.Split.split gpart_a26L0
                      p_a26JD = double g_a26JC
                      (g_a26JC, gpart_a26L0) = Genome.Split.split genome_a26KY
                    in  \ x_a26LG
                          -> let
                               c_PTB_a26LL
                                 = ((Data.Fixed.Vector.toVector x_a26LG) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26LJ
                                 = ((Data.Fixed.Vector.toVector x_a26LG) Data.Vector.Unboxed.! 2)
                               c_RESTc_a26LH
                                 = ((Data.Fixed.Vector.toVector x_a26LG) Data.Vector.Unboxed.! 3)
                               c_NPTB_a26LP
                                 = ((Data.Fixed.Vector.toVector x_a26LG) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a26M2
                                 = ((Data.Fixed.Vector.toVector x_a26LG) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26JL
                                     * ((p_a26JZ + ((c_RESTc_a26LH / p_a26JN) ** p_a26JP))
                                        / (((1 + p_a26JZ) + ((c_RESTc_a26LH / p_a26JN) ** p_a26JP))
                                           + ((c_MiRs_a26LJ / p_a26JV) ** p_a26JX))))
                                    + (negate (p_a26KP * c_PTB_a26LL))),
                                   ((p_a26K1
                                     / (1
                                        + (((c_MiRs_a26LJ / p_a26K3) ** p_a26K5)
                                           + ((c_PTB_a26LL / p_a26K7) ** p_a26K9))))
                                    + (negate (p_a26KR * c_NPTB_a26LP))),
                                   ((p_a26Kb
                                     * (p_a26Kl
                                        / ((1 + p_a26Kl) + ((c_RESTc_a26LH / p_a26Kh) ** p_a26Kj))))
                                    + (negate (p_a26KT * c_MiRs_a26LJ))),
                                   ((p_a26Kn
                                     * ((p_a26KB + ((c_PTB_a26LL / p_a26Kp) ** p_a26Kr))
                                        / (((1 + p_a26KB) + ((c_PTB_a26LL / p_a26Kp) ** p_a26Kr))
                                           + ((c_MiRs_a26LJ / p_a26Kx) ** p_a26Kz))))
                                    + (negate (p_a26KV * c_RESTc_a26LH))),
                                   ((p_a26KD
                                     * ((p_a26KN + ((c_MiRs_a26LJ / p_a26KF) ** p_a26KH))
                                        / (((1 + p_a26KN) + ((c_MiRs_a26LJ / p_a26KF) ** p_a26KH))
                                           + ((c_RESTc_a26LH / p_a26KJ) ** p_a26KL))))
                                    + (negate (p_a26KX * c_EndoNeuroTFs_a26M2)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512340",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512341",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512342",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512343",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512344",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512345",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512346",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512347",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512348",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512349",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512350",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512351",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512352",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512353",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512354",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512355",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512356",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512357",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512358",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512359",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512360",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512361",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512362",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512363",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512364",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512365",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512366",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512367",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512368",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512369",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512370",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512371",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512372",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512373",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512374",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512375",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512376",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512377",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512378",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512379",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512380",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512381",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512382",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512383",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512384",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512385",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512386",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512387",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512388",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512389",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512390",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512391",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512392",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512393",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512394",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512395",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512396",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512397",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512398",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512399",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512400",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512401",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512402",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512403",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512404",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512405",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512406",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512407",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512408",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512409",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512410",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512411",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512412",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512413",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512414",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512415",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512416",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512417",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512418",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512419",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512420",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512421",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512422",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512423",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26KY
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26MI
                            p_a26KX = double g_a26KW
                            (g_a26KW, gpart_a26MI) = Genome.Split.split gpart_a26MH
                            p_a26KV = double g_a26KU
                            (g_a26KU, gpart_a26MH) = Genome.Split.split gpart_a26MG
                            p_a26KT = double g_a26KS
                            (g_a26KS, gpart_a26MG) = Genome.Split.split gpart_a26MF
                            p_a26KR = double g_a26KQ
                            (g_a26KQ, gpart_a26MF) = Genome.Split.split gpart_a26ME
                            p_a26KP = double g_a26KO
                            (g_a26KO, gpart_a26ME) = Genome.Split.split gpart_a26MD
                            p_a26KN = double g_a26KM
                            (g_a26KM, gpart_a26MD) = Genome.Split.split gpart_a26MC
                            p_a26KL = Functions.belowten' g_a26KK
                            (g_a26KK, gpart_a26MC) = Genome.Split.split gpart_a26MB
                            p_a26KJ = double g_a26KI
                            (g_a26KI, gpart_a26MB) = Genome.Split.split gpart_a26MA
                            p_a26KH = Functions.belowten' g_a26KG
                            (g_a26KG, gpart_a26MA) = Genome.Split.split gpart_a26Mz
                            p_a26KF = double g_a26KE
                            (g_a26KE, gpart_a26Mz) = Genome.Split.split gpart_a26My
                            p_a26KD = double g_a26KC
                            (g_a26KC, gpart_a26My) = Genome.Split.split gpart_a26Mx
                            p_a26KB = double g_a26KA
                            (g_a26KA, gpart_a26Mx) = Genome.Split.split gpart_a26Mw
                            p_a26Kz = Functions.belowten' g_a26Ky
                            (g_a26Ky, gpart_a26Mw) = Genome.Split.split gpart_a26Mv
                            p_a26Kx = double g_a26Kw
                            (g_a26Kw, gpart_a26Mv) = Genome.Split.split gpart_a26Mu
                            p_a26Kv
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ku
                            (g_a26Ku, gpart_a26Mu) = Genome.Split.split gpart_a26Mt
                            p_a26Kt
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ks
                            (g_a26Ks, gpart_a26Mt) = Genome.Split.split gpart_a26Ms
                            p_a26Kr = Functions.belowten' g_a26Kq
                            (g_a26Kq, gpart_a26Ms) = Genome.Split.split gpart_a26Mr
                            p_a26Kp = double g_a26Ko
                            (g_a26Ko, gpart_a26Mr) = Genome.Split.split gpart_a26Mq
                            p_a26Kn = double g_a26Km
                            (g_a26Km, gpart_a26Mq) = Genome.Split.split gpart_a26Mp
                            p_a26Kl = double g_a26Kk
                            (g_a26Kk, gpart_a26Mp) = Genome.Split.split gpart_a26Mo
                            p_a26Kj = Functions.belowten' g_a26Ki
                            (g_a26Ki, gpart_a26Mo) = Genome.Split.split gpart_a26Mn
                            p_a26Kh = double g_a26Kg
                            (g_a26Kg, gpart_a26Mn) = Genome.Split.split gpart_a26Mm
                            p_a26Kf
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ke
                            (g_a26Ke, gpart_a26Mm) = Genome.Split.split gpart_a26Ml
                            p_a26Kd
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Kc
                            (g_a26Kc, gpart_a26Ml) = Genome.Split.split gpart_a26Mk
                            p_a26Kb = double g_a26Ka
                            (g_a26Ka, gpart_a26Mk) = Genome.Split.split gpart_a26Mj
                            p_a26K9 = Functions.belowten' g_a26K8
                            (g_a26K8, gpart_a26Mj) = Genome.Split.split gpart_a26Mi
                            p_a26K7 = double g_a26K6
                            (g_a26K6, gpart_a26Mi) = Genome.Split.split gpart_a26Mh
                            p_a26K5 = Functions.belowten' g_a26K4
                            (g_a26K4, gpart_a26Mh) = Genome.Split.split gpart_a26Mg
                            p_a26K3 = double g_a26K2
                            (g_a26K2, gpart_a26Mg) = Genome.Split.split gpart_a26Mf
                            p_a26K1 = double g_a26K0
                            (g_a26K0, gpart_a26Mf) = Genome.Split.split gpart_a26Me
                            p_a26JZ = double g_a26JY
                            (g_a26JY, gpart_a26Me) = Genome.Split.split gpart_a26Md
                            p_a26JX = Functions.belowten' g_a26JW
                            (g_a26JW, gpart_a26Md) = Genome.Split.split gpart_a26Mc
                            p_a26JV = double g_a26JU
                            (g_a26JU, gpart_a26Mc) = Genome.Split.split gpart_a26Mb
                            p_a26JT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26JS
                            (g_a26JS, gpart_a26Mb) = Genome.Split.split gpart_a26Ma
                            p_a26JR
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26JQ
                            (g_a26JQ, gpart_a26Ma) = Genome.Split.split gpart_a26M9
                            p_a26JP = Functions.belowten' g_a26JO
                            (g_a26JO, gpart_a26M9) = Genome.Split.split gpart_a26M8
                            p_a26JN = double g_a26JM
                            (g_a26JM, gpart_a26M8) = Genome.Split.split gpart_a26M7
                            p_a26JL = double g_a26JK
                            (g_a26JK, gpart_a26M7) = Genome.Split.split gpart_a26M6
                            p_a26JJ = double g_a26JI
                            (g_a26JI, gpart_a26M6) = Genome.Split.split gpart_a26M5
                            p_a26JH = double g_a26JG
                            (g_a26JG, gpart_a26M5) = Genome.Split.split gpart_a26M4
                            p_a26JF = double g_a26JE
                            (g_a26JE, gpart_a26M4) = Genome.Split.split gpart_a26M3
                            p_a26JD = double g_a26JC
                            (g_a26JC, gpart_a26M3) = Genome.Split.split genome_a26KY
                          in
                            \ desc_a26KZ
                              -> case desc_a26KZ of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JD)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JF)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JH)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JJ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JL)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JN)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JP)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JR)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JT)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JV)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JX)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26JZ)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26K1)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26K3)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26K5)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26K7)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26K9)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kb)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kd)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kf)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kh)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kj)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kl)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kn)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kp)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kr)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kt)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kv)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kx)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Kz)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KB)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KD)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KF)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KH)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KJ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KL)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KN)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KP)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KR)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KT)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KV)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26KX)
                                   _ -> Nothing }}
src/ineurons/Settings.hs:25:31-140: Splicing expression
    describe . buildPheno
    $ flip typed [t| ReactionGradient Factor |] <$> gradient
      <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_a26Pe
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26PV
                      p_a26Pd = double g_a26Pc
                      (g_a26Pc, gpart_a26PV) = Genome.Split.split gpart_a26PU
                      p_a26Pb = double g_a26Pa
                      (g_a26Pa, gpart_a26PU) = Genome.Split.split gpart_a26PT
                      p_a26P9 = double g_a26P8
                      (g_a26P8, gpart_a26PT) = Genome.Split.split gpart_a26PS
                      p_a26P7 = double g_a26P6
                      (g_a26P6, gpart_a26PS) = Genome.Split.split gpart_a26PR
                      p_a26P5 = double g_a26P4
                      (g_a26P4, gpart_a26PR) = Genome.Split.split gpart_a26PQ
                      p_a26P3 = double g_a26P2
                      (g_a26P2, gpart_a26PQ) = Genome.Split.split gpart_a26PP
                      p_a26P1 = Functions.belowten' g_a26P0
                      (g_a26P0, gpart_a26PP) = Genome.Split.split gpart_a26PO
                      p_a26OZ = double g_a26OY
                      (g_a26OY, gpart_a26PO) = Genome.Split.split gpart_a26PN
                      p_a26OX = Functions.belowten' g_a26OW
                      (g_a26OW, gpart_a26PN) = Genome.Split.split gpart_a26PM
                      p_a26OV = double g_a26OU
                      (g_a26OU, gpart_a26PM) = Genome.Split.split gpart_a26PL
                      p_a26OT = double g_a26OS
                      (g_a26OS, gpart_a26PL) = Genome.Split.split gpart_a26PK
                      p_a26OR = double g_a26OQ
                      (g_a26OQ, gpart_a26PK) = Genome.Split.split gpart_a26PJ
                      p_a26OP = Functions.belowten' g_a26OO
                      (g_a26OO, gpart_a26PJ) = Genome.Split.split gpart_a26PI
                      p_a26ON = double g_a26OM
                      (g_a26OM, gpart_a26PI) = Genome.Split.split gpart_a26PH
                      p_a26OL
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26OK
                      (g_a26OK, gpart_a26PH) = Genome.Split.split gpart_a26PG
                      p_a26OJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26OI
                      (g_a26OI, gpart_a26PG) = Genome.Split.split gpart_a26PF
                      p_a26OH = Functions.belowten' g_a26OG
                      (g_a26OG, gpart_a26PF) = Genome.Split.split gpart_a26PE
                      p_a26OF = double g_a26OE
                      (g_a26OE, gpart_a26PE) = Genome.Split.split gpart_a26PD
                      p_a26OD = double g_a26OC
                      (g_a26OC, gpart_a26PD) = Genome.Split.split gpart_a26PC
                      p_a26OB = double g_a26OA
                      (g_a26OA, gpart_a26PC) = Genome.Split.split gpart_a26PB
                      p_a26Oz = Functions.belowten' g_a26Oy
                      (g_a26Oy, gpart_a26PB) = Genome.Split.split gpart_a26PA
                      p_a26Ox = double g_a26Ow
                      (g_a26Ow, gpart_a26PA) = Genome.Split.split gpart_a26Pz
                      p_a26Ov
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ou
                      (g_a26Ou, gpart_a26Pz) = Genome.Split.split gpart_a26Py
                      p_a26Ot
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Os
                      (g_a26Os, gpart_a26Py) = Genome.Split.split gpart_a26Px
                      p_a26Or = double g_a26Oq
                      (g_a26Oq, gpart_a26Px) = Genome.Split.split gpart_a26Pw
                      p_a26Op = Functions.belowten' g_a26Oo
                      (g_a26Oo, gpart_a26Pw) = Genome.Split.split gpart_a26Pv
                      p_a26On = double g_a26Om
                      (g_a26Om, gpart_a26Pv) = Genome.Split.split gpart_a26Pu
                      p_a26Ol = Functions.belowten' g_a26Ok
                      (g_a26Ok, gpart_a26Pu) = Genome.Split.split gpart_a26Pt
                      p_a26Oj = double g_a26Oi
                      (g_a26Oi, gpart_a26Pt) = Genome.Split.split gpart_a26Ps
                      p_a26Oh = double g_a26Og
                      (g_a26Og, gpart_a26Ps) = Genome.Split.split gpart_a26Pr
                      p_a26Of = double g_a26Oe
                      (g_a26Oe, gpart_a26Pr) = Genome.Split.split gpart_a26Pq
                      p_a26Od = Functions.belowten' g_a26Oc
                      (g_a26Oc, gpart_a26Pq) = Genome.Split.split gpart_a26Pp
                      p_a26Ob = double g_a26Oa
                      (g_a26Oa, gpart_a26Pp) = Genome.Split.split gpart_a26Po
                      p_a26O9
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26O8
                      (g_a26O8, gpart_a26Po) = Genome.Split.split gpart_a26Pn
                      p_a26O7
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26O6
                      (g_a26O6, gpart_a26Pn) = Genome.Split.split gpart_a26Pm
                      p_a26O5 = Functions.belowten' g_a26O4
                      (g_a26O4, gpart_a26Pm) = Genome.Split.split gpart_a26Pl
                      p_a26O3 = double g_a26O2
                      (g_a26O2, gpart_a26Pl) = Genome.Split.split gpart_a26Pk
                      p_a26O1 = double g_a26O0
                      (g_a26O0, gpart_a26Pk) = Genome.Split.split gpart_a26Pj
                      p_a26NZ = double g_a26NY
                      (g_a26NY, gpart_a26Pj) = Genome.Split.split gpart_a26Pi
                      p_a26NX = double g_a26NW
                      (g_a26NW, gpart_a26Pi) = Genome.Split.split gpart_a26Ph
                      p_a26NV = double g_a26NU
                      (g_a26NU, gpart_a26Ph) = Genome.Split.split gpart_a26Pg
                      p_a26NT = double g_a26NS
                      (g_a26NS, gpart_a26Pg) = Genome.Split.split genome_a26Pe
                    in  \ x_a26PW
                          -> let
                               c_PTB_a26Q1
                                 = ((Data.Fixed.Vector.toVector x_a26PW) Data.Vector.Unboxed.! 0)
                               c_MiRs_a26PZ
                                 = ((Data.Fixed.Vector.toVector x_a26PW) Data.Vector.Unboxed.! 2)
                               c_RESTc_a26PX
                                 = ((Data.Fixed.Vector.toVector x_a26PW) Data.Vector.Unboxed.! 3)
                               c_NPTB_a26Q5
                                 = ((Data.Fixed.Vector.toVector x_a26PW) Data.Vector.Unboxed.! 1)
                               c_EndoNeuroTFs_a26Qi
                                 = ((Data.Fixed.Vector.toVector x_a26PW) Data.Vector.Unboxed.! 4)
                             in
                               ((Data.Fixed.Vector.indexed . Data.Vector.Unboxed.fromList)
                                $ [((p_a26O1
                                     * ((p_a26Of + ((c_RESTc_a26PX / p_a26O3) ** p_a26O5))
                                        / (((1 + p_a26Of) + ((c_RESTc_a26PX / p_a26O3) ** p_a26O5))
                                           + (((p_a26NT / p_a26O7) ** p_a26O9)
                                              + ((c_MiRs_a26PZ / p_a26Ob) ** p_a26Od)))))
                                    + (negate (p_a26P5 * c_PTB_a26Q1))),
                                   ((p_a26Oh
                                     / (1
                                        + (((c_MiRs_a26PZ / p_a26Oj) ** p_a26Ol)
                                           + ((c_PTB_a26Q1 / p_a26On) ** p_a26Op))))
                                    + (negate (p_a26P7 * c_NPTB_a26Q5))),
                                   ((p_a26Or
                                     * (p_a26OB
                                        / ((1 + p_a26OB) + ((c_RESTc_a26PX / p_a26Ox) ** p_a26Oz))))
                                    + (negate (p_a26P9 * c_MiRs_a26PZ))),
                                   ((p_a26OD
                                     * ((p_a26OR + ((c_PTB_a26Q1 / p_a26OF) ** p_a26OH))
                                        / (((1 + p_a26OR) + ((c_PTB_a26Q1 / p_a26OF) ** p_a26OH))
                                           + ((c_MiRs_a26PZ / p_a26ON) ** p_a26OP))))
                                    + (negate (p_a26Pb * c_RESTc_a26PX))),
                                   ((p_a26OT
                                     * ((p_a26P3 + ((c_MiRs_a26PZ / p_a26OV) ** p_a26OX))
                                        / (((1 + p_a26P3) + ((c_MiRs_a26PZ / p_a26OV) ** p_a26OX))
                                           + ((c_RESTc_a26PX / p_a26OZ) ** p_a26P1))))
                                    + (negate (p_a26Pd * c_EndoNeuroTFs_a26Qi)))]) ::
                          ReactionGradient Factor,
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512604",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512605",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512606",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512607",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512608",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512609",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512610",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512611",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512612",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512613",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512614",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512615",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512616",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512617",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512618",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512619",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512620",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512621",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512622",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512623",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512639",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512641",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512643",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512657",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512659",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512661",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512663",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512677",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512679",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679512686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679512687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = double}],
       lookupParam = \ genome_a26Pe
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_a26QY
                            p_a26Pd = double g_a26Pc
                            (g_a26Pc, gpart_a26QY) = Genome.Split.split gpart_a26QX
                            p_a26Pb = double g_a26Pa
                            (g_a26Pa, gpart_a26QX) = Genome.Split.split gpart_a26QW
                            p_a26P9 = double g_a26P8
                            (g_a26P8, gpart_a26QW) = Genome.Split.split gpart_a26QV
                            p_a26P7 = double g_a26P6
                            (g_a26P6, gpart_a26QV) = Genome.Split.split gpart_a26QU
                            p_a26P5 = double g_a26P4
                            (g_a26P4, gpart_a26QU) = Genome.Split.split gpart_a26QT
                            p_a26P3 = double g_a26P2
                            (g_a26P2, gpart_a26QT) = Genome.Split.split gpart_a26QS
                            p_a26P1 = Functions.belowten' g_a26P0
                            (g_a26P0, gpart_a26QS) = Genome.Split.split gpart_a26QR
                            p_a26OZ = double g_a26OY
                            (g_a26OY, gpart_a26QR) = Genome.Split.split gpart_a26QQ
                            p_a26OX = Functions.belowten' g_a26OW
                            (g_a26OW, gpart_a26QQ) = Genome.Split.split gpart_a26QP
                            p_a26OV = double g_a26OU
                            (g_a26OU, gpart_a26QP) = Genome.Split.split gpart_a26QO
                            p_a26OT = double g_a26OS
                            (g_a26OS, gpart_a26QO) = Genome.Split.split gpart_a26QN
                            p_a26OR = double g_a26OQ
                            (g_a26OQ, gpart_a26QN) = Genome.Split.split gpart_a26QM
                            p_a26OP = Functions.belowten' g_a26OO
                            (g_a26OO, gpart_a26QM) = Genome.Split.split gpart_a26QL
                            p_a26ON = double g_a26OM
                            (g_a26OM, gpart_a26QL) = Genome.Split.split gpart_a26QK
                            p_a26OL
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26OK
                            (g_a26OK, gpart_a26QK) = Genome.Split.split gpart_a26QJ
                            p_a26OJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26OI
                            (g_a26OI, gpart_a26QJ) = Genome.Split.split gpart_a26QI
                            p_a26OH = Functions.belowten' g_a26OG
                            (g_a26OG, gpart_a26QI) = Genome.Split.split gpart_a26QH
                            p_a26OF = double g_a26OE
                            (g_a26OE, gpart_a26QH) = Genome.Split.split gpart_a26QG
                            p_a26OD = double g_a26OC
                            (g_a26OC, gpart_a26QG) = Genome.Split.split gpart_a26QF
                            p_a26OB = double g_a26OA
                            (g_a26OA, gpart_a26QF) = Genome.Split.split gpart_a26QE
                            p_a26Oz = Functions.belowten' g_a26Oy
                            (g_a26Oy, gpart_a26QE) = Genome.Split.split gpart_a26QD
                            p_a26Ox = double g_a26Ow
                            (g_a26Ow, gpart_a26QD) = Genome.Split.split gpart_a26QC
                            p_a26Ov
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Ou
                            (g_a26Ou, gpart_a26QC) = Genome.Split.split gpart_a26QB
                            p_a26Ot
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26Os
                            (g_a26Os, gpart_a26QB) = Genome.Split.split gpart_a26QA
                            p_a26Or = double g_a26Oq
                            (g_a26Oq, gpart_a26QA) = Genome.Split.split gpart_a26Qz
                            p_a26Op = Functions.belowten' g_a26Oo
                            (g_a26Oo, gpart_a26Qz) = Genome.Split.split gpart_a26Qy
                            p_a26On = double g_a26Om
                            (g_a26Om, gpart_a26Qy) = Genome.Split.split gpart_a26Qx
                            p_a26Ol = Functions.belowten' g_a26Ok
                            (g_a26Ok, gpart_a26Qx) = Genome.Split.split gpart_a26Qw
                            p_a26Oj = double g_a26Oi
                            (g_a26Oi, gpart_a26Qw) = Genome.Split.split gpart_a26Qv
                            p_a26Oh = double g_a26Og
                            (g_a26Og, gpart_a26Qv) = Genome.Split.split gpart_a26Qu
                            p_a26Of = double g_a26Oe
                            (g_a26Oe, gpart_a26Qu) = Genome.Split.split gpart_a26Qt
                            p_a26Od = Functions.belowten' g_a26Oc
                            (g_a26Oc, gpart_a26Qt) = Genome.Split.split gpart_a26Qs
                            p_a26Ob = double g_a26Oa
                            (g_a26Oa, gpart_a26Qs) = Genome.Split.split gpart_a26Qr
                            p_a26O9
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26O8
                            (g_a26O8, gpart_a26Qr) = Genome.Split.split gpart_a26Qq
                            p_a26O7
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_a26O6
                            (g_a26O6, gpart_a26Qq) = Genome.Split.split gpart_a26Qp
                            p_a26O5 = Functions.belowten' g_a26O4
                            (g_a26O4, gpart_a26Qp) = Genome.Split.split gpart_a26Qo
                            p_a26O3 = double g_a26O2
                            (g_a26O2, gpart_a26Qo) = Genome.Split.split gpart_a26Qn
                            p_a26O1 = double g_a26O0
                            (g_a26O0, gpart_a26Qn) = Genome.Split.split gpart_a26Qm
                            p_a26NZ = double g_a26NY
                            (g_a26NY, gpart_a26Qm) = Genome.Split.split gpart_a26Ql
                            p_a26NX = double g_a26NW
                            (g_a26NW, gpart_a26Ql) = Genome.Split.split gpart_a26Qk
                            p_a26NV = double g_a26NU
                            (g_a26NU, gpart_a26Qk) = Genome.Split.split gpart_a26Qj
                            p_a26NT = double g_a26NS
                            (g_a26NS, gpart_a26Qj) = Genome.Split.split genome_a26Pe
                          in
                            \ desc_a26Pf
                              -> case desc_a26Pf of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NT)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NV)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NX)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26NZ)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26O1)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26O3)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26O5)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26O7)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26O9)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ob)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Od)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Of)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Oh)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Oj)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ol)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26On)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Op)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Or)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ot)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ov)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Ox)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Oz)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OB)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OD)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OF)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OH)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OJ)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OL)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26ON)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OP)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OR)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OT)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OV)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OX)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26OZ)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26P1)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26P3)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26P5)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26P7)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26P9)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Pb)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_a26Pd)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:19:26-94: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions Cocktail10
  ======>
    GPMap
      {gpmap = \ genome_asVs
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asW9
                      p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                      (g_asVq, gpart_asW9) = Genome.Split.split gpart_asW8
                      p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                      (g_asVo, gpart_asW8) = Genome.Split.split gpart_asW7
                      p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                      (g_asVm, gpart_asW7) = Genome.Split.split gpart_asW6
                      p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                      (g_asVk, gpart_asW6) = Genome.Split.split gpart_asW5
                      p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                      (g_asVi, gpart_asW5) = Genome.Split.split gpart_asW4
                      p_asVh = code-0.1.0.0:Genome.FixedList.Functions.double g_asVg
                      (g_asVg, gpart_asW4) = Genome.Split.split gpart_asW3
                      p_asVf = Functions.belowten' g_asVe
                      (g_asVe, gpart_asW3) = Genome.Split.split gpart_asW2
                      p_asVd = code-0.1.0.0:Genome.FixedList.Functions.double g_asVc
                      (g_asVc, gpart_asW2) = Genome.Split.split gpart_asW1
                      p_asVb = Functions.belowten' g_asVa
                      (g_asVa, gpart_asW1) = Genome.Split.split gpart_asW0
                      p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                      (g_asV8, gpart_asW0) = Genome.Split.split gpart_asVZ
                      p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                      (g_asV6, gpart_asVZ) = Genome.Split.split gpart_asVY
                      p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                      (g_asV4, gpart_asVY) = Genome.Split.split gpart_asVX
                      p_asV3 = Functions.belowten' g_asV2
                      (g_asV2, gpart_asVX) = Genome.Split.split gpart_asVW
                      p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                      (g_asV0, gpart_asVW) = Genome.Split.split gpart_asVV
                      p_asUZ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                      (g_asUY, gpart_asVV) = Genome.Split.split gpart_asVU
                      p_asUX
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUW
                      (g_asUW, gpart_asVU) = Genome.Split.split gpart_asVT
                      p_asUV = Functions.belowten' g_asUU
                      (g_asUU, gpart_asVT) = Genome.Split.split gpart_asVS
                      p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                      (g_asUS, gpart_asVS) = Genome.Split.split gpart_asVR
                      p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                      (g_asUQ, gpart_asVR) = Genome.Split.split gpart_asVQ
                      p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                      (g_asUO, gpart_asVQ) = Genome.Split.split gpart_asVP
                      p_asUN = Functions.belowten' g_asUM
                      (g_asUM, gpart_asVP) = Genome.Split.split gpart_asVO
                      p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                      (g_asUK, gpart_asVO) = Genome.Split.split gpart_asVN
                      p_asUJ
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                      (g_asUI, gpart_asVN) = Genome.Split.split gpart_asVM
                      p_asUH
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                      (g_asUG, gpart_asVM) = Genome.Split.split gpart_asVL
                      p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                      (g_asUE, gpart_asVL) = Genome.Split.split gpart_asVK
                      p_asUD = Functions.belowten' g_asUC
                      (g_asUC, gpart_asVK) = Genome.Split.split gpart_asVJ
                      p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                      (g_asUA, gpart_asVJ) = Genome.Split.split gpart_asVI
                      p_asUz = Functions.belowten' g_asUy
                      (g_asUy, gpart_asVI) = Genome.Split.split gpart_asVH
                      p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                      (g_asUw, gpart_asVH) = Genome.Split.split gpart_asVG
                      p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                      (g_asUu, gpart_asVG) = Genome.Split.split gpart_asVF
                      p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                      (g_asUs, gpart_asVF) = Genome.Split.split gpart_asVE
                      p_asUr = Functions.belowten' g_asUq
                      (g_asUq, gpart_asVE) = Genome.Split.split gpart_asVD
                      p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                      (g_asUo, gpart_asVD) = Genome.Split.split gpart_asVC
                      p_asUn
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                      (g_asUm, gpart_asVC) = Genome.Split.split gpart_asVB
                      p_asUl
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                      (g_asUk, gpart_asVB) = Genome.Split.split gpart_asVA
                      p_asUj = Functions.belowten' g_asUi
                      (g_asUi, gpart_asVA) = Genome.Split.split gpart_asVz
                      p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                      (g_asUg, gpart_asVz) = Genome.Split.split gpart_asVy
                      p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                      (g_asUe, gpart_asVy) = Genome.Split.split gpart_asVx
                      p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                      (g_asUc, gpart_asVx) = Genome.Split.split gpart_asVw
                      p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                      (g_asUa, gpart_asVw) = Genome.Split.split gpart_asVv
                      p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                      (g_asU8, gpart_asVv) = Genome.Split.split gpart_asVu
                      p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                      (g_asU6, gpart_asVu) = Genome.Split.split genome_asVs
                    in
                      [Reaction
                         (\ x_asWa
                            -> let
                                 c_MiRs_asWd = ((toVector x_asWa) Data.Vector.Unboxed.! 2)
                                 c_RESTc_asWb = ((toVector x_asWa) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUf
                                  * ((p_asUt + ((c_RESTc_asWb / p_asUh) ** p_asUj))
                                     / (((1 + p_asUt) + ((c_RESTc_asWb / p_asUh) ** p_asUj))
                                        + ((c_MiRs_asWd / p_asUp) ** p_asUr)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWe
                            -> let
                                 c_MiRs_asWf = ((toVector x_asWe) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWg = ((toVector x_asWe) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUv
                                  / (1
                                     + (((c_MiRs_asWf / p_asUx) ** p_asUz)
                                        + ((c_PTB_asWg / p_asUB) ** p_asUD)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_asWh
                            -> let c_RESTc_asWi = ((toVector x_asWh) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asUF
                                  * ((p_asUP + ((p_asUb / p_asUH) ** p_asUJ))
                                     / (((1 + p_asUP) + ((p_asUb / p_asUH) ** p_asUJ))
                                        + ((c_RESTc_asWi / p_asUL) ** p_asUN)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_asWj
                            -> let
                                 c_MiRs_asWm = ((toVector x_asWj) Data.Vector.Unboxed.! 2)
                                 c_PTB_asWk = ((toVector x_asWj) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asUR
                                  * ((p_asV5 + ((c_PTB_asWk / p_asUT) ** p_asUV))
                                     / (((1 + p_asV5) + ((c_PTB_asWk / p_asUT) ** p_asUV))
                                        + (((p_asU7 / p_asUX) ** p_asUZ)
                                           + ((c_MiRs_asWm / p_asV1) ** p_asV3))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_asWn
                            -> let
                                 c_RESTc_asWq = ((toVector x_asWn) Data.Vector.Unboxed.! 3)
                                 c_MiRs_asWo = ((toVector x_asWn) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asV7
                                  * ((p_asVh + ((c_MiRs_asWo / p_asV9) ** p_asVb))
                                     / (((1 + p_asVh) + ((c_MiRs_asWo / p_asV9) ** p_asVb))
                                        + ((c_RESTc_asWq / p_asVd) ** p_asVf)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_asWr
                            -> let c_PTB_asWs = ((toVector x_asWr) Data.Vector.Unboxed.! 0)
                               in (p_asVj * c_PTB_asWs))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_asWt
                            -> let c_NPTB_asWu = ((toVector x_asWt) Data.Vector.Unboxed.! 1)
                               in (p_asVl * c_NPTB_asWu))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_asWv
                            -> let c_MiRs_asWw = ((toVector x_asWv) Data.Vector.Unboxed.! 2)
                               in (p_asVn * c_MiRs_asWw))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_asWx
                            -> let c_RESTc_asWy = ((toVector x_asWx) Data.Vector.Unboxed.! 3)
                               in (p_asVp * c_RESTc_asWy))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_asWz
                            -> let
                                 c_EndoNeuroTFs_asWA = ((toVector x_asWz) Data.Vector.Unboxed.! 4)
                               in (p_asVr * c_EndoNeuroTFs_asWA))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120902",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120903",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120904",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120905",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120906",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120907",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120908",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120909",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120910",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120911",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120912",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120913",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120914",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120915",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120916",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120917",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120918",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120919",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120920",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120921",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120922",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120923",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120924",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120925",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120926",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120927",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120928",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120929",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120930",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120931",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120932",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120933",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120934",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120935",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120936",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120937",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120938",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120939",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill [~] --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120940",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120941",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120942",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120943",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120944",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120945",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120946",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120947",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120948",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120949",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120950",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120951",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120952",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120953",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120954",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120955",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120956",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120957",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120958",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120959",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120960",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120961",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120962",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120963",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120964",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120965",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120966",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120967",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120968",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120969",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120970",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120971",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120972",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120973",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120974",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120975",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120976",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120977",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120978",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120979",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120980",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120981",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120982",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120983",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679120984",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679120985",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asVs
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_asXl
                            p_asVr = code-0.1.0.0:Genome.FixedList.Functions.double g_asVq
                            (g_asVq, gpart_asXl) = Genome.Split.split gpart_asXk
                            p_asVp = code-0.1.0.0:Genome.FixedList.Functions.double g_asVo
                            (g_asVo, gpart_asXk) = Genome.Split.split gpart_asXj
                            p_asVn = code-0.1.0.0:Genome.FixedList.Functions.double g_asVm
                            (g_asVm, gpart_asXj) = Genome.Split.split gpart_asXi
                            p_asVl = code-0.1.0.0:Genome.FixedList.Functions.double g_asVk
                            (g_asVk, gpart_asXi) = Genome.Split.split gpart_asXh
                            p_asVj = code-0.1.0.0:Genome.FixedList.Functions.double g_asVi
                            (g_asVi, gpart_asXh) = Genome.Split.split gpart_asXg
                            p_asVh = code-0.1.0.0:Genome.FixedList.Functions.double g_asVg
                            (g_asVg, gpart_asXg) = Genome.Split.split gpart_asXf
                            p_asVf = Functions.belowten' g_asVe
                            (g_asVe, gpart_asXf) = Genome.Split.split gpart_asXe
                            p_asVd = code-0.1.0.0:Genome.FixedList.Functions.double g_asVc
                            (g_asVc, gpart_asXe) = Genome.Split.split gpart_asXd
                            p_asVb = Functions.belowten' g_asVa
                            (g_asVa, gpart_asXd) = Genome.Split.split gpart_asXc
                            p_asV9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV8
                            (g_asV8, gpart_asXc) = Genome.Split.split gpart_asXb
                            p_asV7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV6
                            (g_asV6, gpart_asXb) = Genome.Split.split gpart_asXa
                            p_asV5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV4
                            (g_asV4, gpart_asXa) = Genome.Split.split gpart_asX9
                            p_asV3 = Functions.belowten' g_asV2
                            (g_asV2, gpart_asX9) = Genome.Split.split gpart_asX8
                            p_asV1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asV0
                            (g_asV0, gpart_asX8) = Genome.Split.split gpart_asX7
                            p_asUZ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUY
                            (g_asUY, gpart_asX7) = Genome.Split.split gpart_asX6
                            p_asUX
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUW
                            (g_asUW, gpart_asX6) = Genome.Split.split gpart_asX5
                            p_asUV = Functions.belowten' g_asUU
                            (g_asUU, gpart_asX5) = Genome.Split.split gpart_asX4
                            p_asUT = code-0.1.0.0:Genome.FixedList.Functions.double g_asUS
                            (g_asUS, gpart_asX4) = Genome.Split.split gpart_asX3
                            p_asUR = code-0.1.0.0:Genome.FixedList.Functions.double g_asUQ
                            (g_asUQ, gpart_asX3) = Genome.Split.split gpart_asX2
                            p_asUP = code-0.1.0.0:Genome.FixedList.Functions.double g_asUO
                            (g_asUO, gpart_asX2) = Genome.Split.split gpart_asX1
                            p_asUN = Functions.belowten' g_asUM
                            (g_asUM, gpart_asX1) = Genome.Split.split gpart_asX0
                            p_asUL = code-0.1.0.0:Genome.FixedList.Functions.double g_asUK
                            (g_asUK, gpart_asX0) = Genome.Split.split gpart_asWZ
                            p_asUJ
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUI
                            (g_asUI, gpart_asWZ) = Genome.Split.split gpart_asWY
                            p_asUH
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUG
                            (g_asUG, gpart_asWY) = Genome.Split.split gpart_asWX
                            p_asUF = code-0.1.0.0:Genome.FixedList.Functions.double g_asUE
                            (g_asUE, gpart_asWX) = Genome.Split.split gpart_asWW
                            p_asUD = Functions.belowten' g_asUC
                            (g_asUC, gpart_asWW) = Genome.Split.split gpart_asWV
                            p_asUB = code-0.1.0.0:Genome.FixedList.Functions.double g_asUA
                            (g_asUA, gpart_asWV) = Genome.Split.split gpart_asWU
                            p_asUz = Functions.belowten' g_asUy
                            (g_asUy, gpart_asWU) = Genome.Split.split gpart_asWT
                            p_asUx = code-0.1.0.0:Genome.FixedList.Functions.double g_asUw
                            (g_asUw, gpart_asWT) = Genome.Split.split gpart_asWS
                            p_asUv = code-0.1.0.0:Genome.FixedList.Functions.double g_asUu
                            (g_asUu, gpart_asWS) = Genome.Split.split gpart_asWR
                            p_asUt = code-0.1.0.0:Genome.FixedList.Functions.double g_asUs
                            (g_asUs, gpart_asWR) = Genome.Split.split gpart_asWQ
                            p_asUr = Functions.belowten' g_asUq
                            (g_asUq, gpart_asWQ) = Genome.Split.split gpart_asWP
                            p_asUp = code-0.1.0.0:Genome.FixedList.Functions.double g_asUo
                            (g_asUo, gpart_asWP) = Genome.Split.split gpart_asWO
                            p_asUn
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUm
                            (g_asUm, gpart_asWO) = Genome.Split.split gpart_asWN
                            p_asUl
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asUk
                            (g_asUk, gpart_asWN) = Genome.Split.split gpart_asWM
                            p_asUj = Functions.belowten' g_asUi
                            (g_asUi, gpart_asWM) = Genome.Split.split gpart_asWL
                            p_asUh = code-0.1.0.0:Genome.FixedList.Functions.double g_asUg
                            (g_asUg, gpart_asWL) = Genome.Split.split gpart_asWK
                            p_asUf = code-0.1.0.0:Genome.FixedList.Functions.double g_asUe
                            (g_asUe, gpart_asWK) = Genome.Split.split gpart_asWJ
                            p_asUd = code-0.1.0.0:Genome.FixedList.Functions.double g_asUc
                            (g_asUc, gpart_asWJ) = Genome.Split.split gpart_asWI
                            p_asUb = code-0.1.0.0:Genome.FixedList.Functions.double g_asUa
                            (g_asUa, gpart_asWI) = Genome.Split.split gpart_asWH
                            p_asU9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU8
                            (g_asU8, gpart_asWH) = Genome.Split.split gpart_asWG
                            p_asU7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asU6
                            (g_asU6, gpart_asWG) = Genome.Split.split genome_asVs
                          in
                            \ desc_asVt
                              -> case desc_asVt of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU7)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asU9)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUb)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUd)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUf)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUh)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUj)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUl)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUn)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUp)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUr)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUt)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUv)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUx)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUz)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUB)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUD)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUF)
                                   "Activation coef [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUH)
                                   "Activation hill [~] --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUJ)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUL)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUN)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUP)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUR)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUT)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUV)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUX)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asUZ)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV1)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV3)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV5)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV7)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asV9)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVb)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVd)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVf)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVh)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVj)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVl)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVn)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVp)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asVr)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:20:26-89: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions RESTi
  ======>
    GPMap
      {gpmap = \ genome_asZo
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at05
                      p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                      (g_asZm, gpart_at05) = Genome.Split.split gpart_at04
                      p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                      (g_asZk, gpart_at04) = Genome.Split.split gpart_at03
                      p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                      (g_asZi, gpart_at03) = Genome.Split.split gpart_at02
                      p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                      (g_asZg, gpart_at02) = Genome.Split.split gpart_at01
                      p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                      (g_asZe, gpart_at01) = Genome.Split.split gpart_at00
                      p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                      (g_asZc, gpart_at00) = Genome.Split.split gpart_asZZ
                      p_asZb = Functions.belowten' g_asZa
                      (g_asZa, gpart_asZZ) = Genome.Split.split gpart_asZY
                      p_asZ9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ8
                      (g_asZ8, gpart_asZY) = Genome.Split.split gpart_asZX
                      p_asZ7 = Functions.belowten' g_asZ6
                      (g_asZ6, gpart_asZX) = Genome.Split.split gpart_asZW
                      p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                      (g_asZ4, gpart_asZW) = Genome.Split.split gpart_asZV
                      p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                      (g_asZ2, gpart_asZV) = Genome.Split.split gpart_asZU
                      p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                      (g_asZ0, gpart_asZU) = Genome.Split.split gpart_asZT
                      p_asYZ = Functions.belowten' g_asYY
                      (g_asYY, gpart_asZT) = Genome.Split.split gpart_asZS
                      p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                      (g_asYW, gpart_asZS) = Genome.Split.split gpart_asZR
                      p_asYV
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYU
                      (g_asYU, gpart_asZR) = Genome.Split.split gpart_asZQ
                      p_asYT
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                      (g_asYS, gpart_asZQ) = Genome.Split.split gpart_asZP
                      p_asYR = Functions.belowten' g_asYQ
                      (g_asYQ, gpart_asZP) = Genome.Split.split gpart_asZO
                      p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                      (g_asYO, gpart_asZO) = Genome.Split.split gpart_asZN
                      p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                      (g_asYM, gpart_asZN) = Genome.Split.split gpart_asZM
                      p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                      (g_asYK, gpart_asZM) = Genome.Split.split gpart_asZL
                      p_asYJ = Functions.belowten' g_asYI
                      (g_asYI, gpart_asZL) = Genome.Split.split gpart_asZK
                      p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                      (g_asYG, gpart_asZK) = Genome.Split.split gpart_asZJ
                      p_asYF
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYE
                      (g_asYE, gpart_asZJ) = Genome.Split.split gpart_asZI
                      p_asYD
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYC
                      (g_asYC, gpart_asZI) = Genome.Split.split gpart_asZH
                      p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                      (g_asYA, gpart_asZH) = Genome.Split.split gpart_asZG
                      p_asYz = Functions.belowten' g_asYy
                      (g_asYy, gpart_asZG) = Genome.Split.split gpart_asZF
                      p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                      (g_asYw, gpart_asZF) = Genome.Split.split gpart_asZE
                      p_asYv = Functions.belowten' g_asYu
                      (g_asYu, gpart_asZE) = Genome.Split.split gpart_asZD
                      p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                      (g_asYs, gpart_asZD) = Genome.Split.split gpart_asZC
                      p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                      (g_asYq, gpart_asZC) = Genome.Split.split gpart_asZB
                      p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                      (g_asYo, gpart_asZB) = Genome.Split.split gpart_asZA
                      p_asYn = Functions.belowten' g_asYm
                      (g_asYm, gpart_asZA) = Genome.Split.split gpart_asZz
                      p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                      (g_asYk, gpart_asZz) = Genome.Split.split gpart_asZy
                      p_asYj
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYi
                      (g_asYi, gpart_asZy) = Genome.Split.split gpart_asZx
                      p_asYh
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                      (g_asYg, gpart_asZx) = Genome.Split.split gpart_asZw
                      p_asYf = Functions.belowten' g_asYe
                      (g_asYe, gpart_asZw) = Genome.Split.split gpart_asZv
                      p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                      (g_asYc, gpart_asZv) = Genome.Split.split gpart_asZu
                      p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                      (g_asYa, gpart_asZu) = Genome.Split.split gpart_asZt
                      p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                      (g_asY8, gpart_asZt) = Genome.Split.split gpart_asZs
                      p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                      (g_asY6, gpart_asZs) = Genome.Split.split gpart_asZr
                      p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                      (g_asY4, gpart_asZr) = Genome.Split.split gpart_asZq
                      p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                      (g_asY2, gpart_asZq) = Genome.Split.split genome_asZo
                    in
                      [Reaction
                         (\ x_at06
                            -> let
                                 c_MiRs_at09 = ((toVector x_at06) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at07 = ((toVector x_at06) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYb
                                  * ((p_asYp + ((c_RESTc_at07 / p_asYd) ** p_asYf))
                                     / (((1 + p_asYp) + ((c_RESTc_at07 / p_asYd) ** p_asYf))
                                        + ((c_MiRs_at09 / p_asYl) ** p_asYn)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0a
                            -> let
                                 c_MiRs_at0b = ((toVector x_at0a) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0c = ((toVector x_at0a) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYr
                                  / (1
                                     + (((c_MiRs_at0b / p_asYt) ** p_asYv)
                                        + ((c_PTB_at0c / p_asYx) ** p_asYz)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at0d
                            -> let c_RESTc_at0e = ((toVector x_at0d) Data.Vector.Unboxed.! 3)
                               in
                                 (p_asYB
                                  * (p_asYL
                                     / ((1 + p_asYL) + ((c_RESTc_at0e / p_asYH) ** p_asYJ)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at0f
                            -> let
                                 c_MiRs_at0i = ((toVector x_at0f) Data.Vector.Unboxed.! 2)
                                 c_PTB_at0g = ((toVector x_at0f) Data.Vector.Unboxed.! 0)
                               in
                                 (p_asYN
                                  * ((p_asZ1 + ((c_PTB_at0g / p_asYP) ** p_asYR))
                                     / (((1 + p_asZ1) + ((c_PTB_at0g / p_asYP) ** p_asYR))
                                        + (((p_asY3 / p_asYT) ** p_asYV)
                                           + ((c_MiRs_at0i / p_asYX) ** p_asYZ))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at0j
                            -> let
                                 c_RESTc_at0m = ((toVector x_at0j) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at0k = ((toVector x_at0j) Data.Vector.Unboxed.! 2)
                               in
                                 (p_asZ3
                                  * ((p_asZd + ((c_MiRs_at0k / p_asZ5) ** p_asZ7))
                                     / (((1 + p_asZd) + ((c_MiRs_at0k / p_asZ5) ** p_asZ7))
                                        + ((c_RESTc_at0m / p_asZ9) ** p_asZb)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at0n
                            -> let c_PTB_at0o = ((toVector x_at0n) Data.Vector.Unboxed.! 0)
                               in (p_asZf * c_PTB_at0o))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at0p
                            -> let c_NPTB_at0q = ((toVector x_at0p) Data.Vector.Unboxed.! 1)
                               in (p_asZh * c_NPTB_at0q))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at0r
                            -> let c_MiRs_at0s = ((toVector x_at0r) Data.Vector.Unboxed.! 2)
                               in (p_asZj * c_MiRs_at0s))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at0t
                            -> let c_RESTc_at0u = ((toVector x_at0t) Data.Vector.Unboxed.! 3)
                               in (p_asZl * c_RESTc_at0u))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at0v
                            -> let
                                 c_EndoNeuroTFs_at0w = ((toVector x_at0v) Data.Vector.Unboxed.! 4)
                               in (p_asZn * c_EndoNeuroTFs_at0w))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121146",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121147",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121148",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121149",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121150",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121151",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121152",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121153",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121154",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121155",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121156",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121157",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121158",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121159",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121160",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121161",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121162",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121163",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121164",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121165",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121166",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121167",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121168",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121169",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121170",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121171",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121172",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121173",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121174",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121175",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121176",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121177",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121178",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121179",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121180",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121181",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121182",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121183",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121184",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121185",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121186",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121187",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121188",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121189",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121190",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121191",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121192",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121193",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121194",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121195",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121196",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121197",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121198",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121199",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121200",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121201",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121202",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121203",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121204",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121205",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121206",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121207",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121208",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121209",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121210",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121211",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121212",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121213",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121214",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121215",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121216",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121217",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121218",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121219",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121220",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121221",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121222",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121223",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121224",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121225",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121226",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121227",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121228",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121229",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_asZo
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at1c
                            p_asZn = code-0.1.0.0:Genome.FixedList.Functions.double g_asZm
                            (g_asZm, gpart_at1c) = Genome.Split.split gpart_at1b
                            p_asZl = code-0.1.0.0:Genome.FixedList.Functions.double g_asZk
                            (g_asZk, gpart_at1b) = Genome.Split.split gpart_at1a
                            p_asZj = code-0.1.0.0:Genome.FixedList.Functions.double g_asZi
                            (g_asZi, gpart_at1a) = Genome.Split.split gpart_at19
                            p_asZh = code-0.1.0.0:Genome.FixedList.Functions.double g_asZg
                            (g_asZg, gpart_at19) = Genome.Split.split gpart_at18
                            p_asZf = code-0.1.0.0:Genome.FixedList.Functions.double g_asZe
                            (g_asZe, gpart_at18) = Genome.Split.split gpart_at17
                            p_asZd = code-0.1.0.0:Genome.FixedList.Functions.double g_asZc
                            (g_asZc, gpart_at17) = Genome.Split.split gpart_at16
                            p_asZb = Functions.belowten' g_asZa
                            (g_asZa, gpart_at16) = Genome.Split.split gpart_at15
                            p_asZ9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ8
                            (g_asZ8, gpart_at15) = Genome.Split.split gpart_at14
                            p_asZ7 = Functions.belowten' g_asZ6
                            (g_asZ6, gpart_at14) = Genome.Split.split gpart_at13
                            p_asZ5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ4
                            (g_asZ4, gpart_at13) = Genome.Split.split gpart_at12
                            p_asZ3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ2
                            (g_asZ2, gpart_at12) = Genome.Split.split gpart_at11
                            p_asZ1 = code-0.1.0.0:Genome.FixedList.Functions.double g_asZ0
                            (g_asZ0, gpart_at11) = Genome.Split.split gpart_at10
                            p_asYZ = Functions.belowten' g_asYY
                            (g_asYY, gpart_at10) = Genome.Split.split gpart_at0Z
                            p_asYX = code-0.1.0.0:Genome.FixedList.Functions.double g_asYW
                            (g_asYW, gpart_at0Z) = Genome.Split.split gpart_at0Y
                            p_asYV
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYU
                            (g_asYU, gpart_at0Y) = Genome.Split.split gpart_at0X
                            p_asYT
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYS
                            (g_asYS, gpart_at0X) = Genome.Split.split gpart_at0W
                            p_asYR = Functions.belowten' g_asYQ
                            (g_asYQ, gpart_at0W) = Genome.Split.split gpart_at0V
                            p_asYP = code-0.1.0.0:Genome.FixedList.Functions.double g_asYO
                            (g_asYO, gpart_at0V) = Genome.Split.split gpart_at0U
                            p_asYN = code-0.1.0.0:Genome.FixedList.Functions.double g_asYM
                            (g_asYM, gpart_at0U) = Genome.Split.split gpart_at0T
                            p_asYL = code-0.1.0.0:Genome.FixedList.Functions.double g_asYK
                            (g_asYK, gpart_at0T) = Genome.Split.split gpart_at0S
                            p_asYJ = Functions.belowten' g_asYI
                            (g_asYI, gpart_at0S) = Genome.Split.split gpart_at0R
                            p_asYH = code-0.1.0.0:Genome.FixedList.Functions.double g_asYG
                            (g_asYG, gpart_at0R) = Genome.Split.split gpart_at0Q
                            p_asYF
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYE
                            (g_asYE, gpart_at0Q) = Genome.Split.split gpart_at0P
                            p_asYD
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYC
                            (g_asYC, gpart_at0P) = Genome.Split.split gpart_at0O
                            p_asYB = code-0.1.0.0:Genome.FixedList.Functions.double g_asYA
                            (g_asYA, gpart_at0O) = Genome.Split.split gpart_at0N
                            p_asYz = Functions.belowten' g_asYy
                            (g_asYy, gpart_at0N) = Genome.Split.split gpart_at0M
                            p_asYx = code-0.1.0.0:Genome.FixedList.Functions.double g_asYw
                            (g_asYw, gpart_at0M) = Genome.Split.split gpart_at0L
                            p_asYv = Functions.belowten' g_asYu
                            (g_asYu, gpart_at0L) = Genome.Split.split gpart_at0K
                            p_asYt = code-0.1.0.0:Genome.FixedList.Functions.double g_asYs
                            (g_asYs, gpart_at0K) = Genome.Split.split gpart_at0J
                            p_asYr = code-0.1.0.0:Genome.FixedList.Functions.double g_asYq
                            (g_asYq, gpart_at0J) = Genome.Split.split gpart_at0I
                            p_asYp = code-0.1.0.0:Genome.FixedList.Functions.double g_asYo
                            (g_asYo, gpart_at0I) = Genome.Split.split gpart_at0H
                            p_asYn = Functions.belowten' g_asYm
                            (g_asYm, gpart_at0H) = Genome.Split.split gpart_at0G
                            p_asYl = code-0.1.0.0:Genome.FixedList.Functions.double g_asYk
                            (g_asYk, gpart_at0G) = Genome.Split.split gpart_at0F
                            p_asYj
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYi
                            (g_asYi, gpart_at0F) = Genome.Split.split gpart_at0E
                            p_asYh
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_asYg
                            (g_asYg, gpart_at0E) = Genome.Split.split gpart_at0D
                            p_asYf = Functions.belowten' g_asYe
                            (g_asYe, gpart_at0D) = Genome.Split.split gpart_at0C
                            p_asYd = code-0.1.0.0:Genome.FixedList.Functions.double g_asYc
                            (g_asYc, gpart_at0C) = Genome.Split.split gpart_at0B
                            p_asYb = code-0.1.0.0:Genome.FixedList.Functions.double g_asYa
                            (g_asYa, gpart_at0B) = Genome.Split.split gpart_at0A
                            p_asY9 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY8
                            (g_asY8, gpart_at0A) = Genome.Split.split gpart_at0z
                            p_asY7 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY6
                            (g_asY6, gpart_at0z) = Genome.Split.split gpart_at0y
                            p_asY5 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY4
                            (g_asY4, gpart_at0y) = Genome.Split.split gpart_at0x
                            p_asY3 = code-0.1.0.0:Genome.FixedList.Functions.double g_asY2
                            (g_asY2, gpart_at0x) = Genome.Split.split genome_asZo
                          in
                            \ desc_asZp
                              -> case desc_asZp of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY3)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY5)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY7)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asY9)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYb)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYd)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYf)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYh)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYj)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYl)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYn)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYp)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYr)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYt)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYv)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYx)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYz)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYB)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYD)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYF)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYH)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYJ)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYL)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYN)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYP)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYR)
                                   "Inhibition coef [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYT)
                                   "Inhibition hill [~] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYV)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYX)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asYZ)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ1)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ3)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ5)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ7)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZ9)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZb)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZd)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZf)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZh)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZj)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZl)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_asZn)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:21:26-92: Splicing expression
    describe . buildPheno $ reactionNetwork <$> neuroreactions WildType
  ======>
    GPMap
      {gpmap = \ genome_at3f
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at3W
                      p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                      (g_at3d, gpart_at3W) = Genome.Split.split gpart_at3V
                      p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                      (g_at3b, gpart_at3V) = Genome.Split.split gpart_at3U
                      p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                      (g_at39, gpart_at3U) = Genome.Split.split gpart_at3T
                      p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                      (g_at37, gpart_at3T) = Genome.Split.split gpart_at3S
                      p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                      (g_at35, gpart_at3S) = Genome.Split.split gpart_at3R
                      p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                      (g_at33, gpart_at3R) = Genome.Split.split gpart_at3Q
                      p_at32 = Functions.belowten' g_at31
                      (g_at31, gpart_at3Q) = Genome.Split.split gpart_at3P
                      p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                      (g_at2Z, gpart_at3P) = Genome.Split.split gpart_at3O
                      p_at2Y = Functions.belowten' g_at2X
                      (g_at2X, gpart_at3O) = Genome.Split.split gpart_at3N
                      p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                      (g_at2V, gpart_at3N) = Genome.Split.split gpart_at3M
                      p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                      (g_at2T, gpart_at3M) = Genome.Split.split gpart_at3L
                      p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                      (g_at2R, gpart_at3L) = Genome.Split.split gpart_at3K
                      p_at2Q = Functions.belowten' g_at2P
                      (g_at2P, gpart_at3K) = Genome.Split.split gpart_at3J
                      p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                      (g_at2N, gpart_at3J) = Genome.Split.split gpart_at3I
                      p_at2M
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2L
                      (g_at2L, gpart_at3I) = Genome.Split.split gpart_at3H
                      p_at2K
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2J
                      (g_at2J, gpart_at3H) = Genome.Split.split gpart_at3G
                      p_at2I = Functions.belowten' g_at2H
                      (g_at2H, gpart_at3G) = Genome.Split.split gpart_at3F
                      p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                      (g_at2F, gpart_at3F) = Genome.Split.split gpart_at3E
                      p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                      (g_at2D, gpart_at3E) = Genome.Split.split gpart_at3D
                      p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                      (g_at2B, gpart_at3D) = Genome.Split.split gpart_at3C
                      p_at2A = Functions.belowten' g_at2z
                      (g_at2z, gpart_at3C) = Genome.Split.split gpart_at3B
                      p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                      (g_at2x, gpart_at3B) = Genome.Split.split gpart_at3A
                      p_at2w
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                      (g_at2v, gpart_at3A) = Genome.Split.split gpart_at3z
                      p_at2u
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                      (g_at2t, gpart_at3z) = Genome.Split.split gpart_at3y
                      p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                      (g_at2r, gpart_at3y) = Genome.Split.split gpart_at3x
                      p_at2q = Functions.belowten' g_at2p
                      (g_at2p, gpart_at3x) = Genome.Split.split gpart_at3w
                      p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                      (g_at2n, gpart_at3w) = Genome.Split.split gpart_at3v
                      p_at2m = Functions.belowten' g_at2l
                      (g_at2l, gpart_at3v) = Genome.Split.split gpart_at3u
                      p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                      (g_at2j, gpart_at3u) = Genome.Split.split gpart_at3t
                      p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                      (g_at2h, gpart_at3t) = Genome.Split.split gpart_at3s
                      p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                      (g_at2f, gpart_at3s) = Genome.Split.split gpart_at3r
                      p_at2e = Functions.belowten' g_at2d
                      (g_at2d, gpart_at3r) = Genome.Split.split gpart_at3q
                      p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                      (g_at2b, gpart_at3q) = Genome.Split.split gpart_at3p
                      p_at2a
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at29
                      (g_at29, gpart_at3p) = Genome.Split.split gpart_at3o
                      p_at28
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at27
                      (g_at27, gpart_at3o) = Genome.Split.split gpart_at3n
                      p_at26 = Functions.belowten' g_at25
                      (g_at25, gpart_at3n) = Genome.Split.split gpart_at3m
                      p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                      (g_at23, gpart_at3m) = Genome.Split.split gpart_at3l
                      p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                      (g_at21, gpart_at3l) = Genome.Split.split gpart_at3k
                      p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                      (g_at1Z, gpart_at3k) = Genome.Split.split gpart_at3j
                      p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                      (g_at1X, gpart_at3j) = Genome.Split.split gpart_at3i
                      p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                      (g_at1V, gpart_at3i) = Genome.Split.split gpart_at3h
                      p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                      (g_at1T, gpart_at3h) = Genome.Split.split genome_at3f
                    in
                      [Reaction
                         (\ x_at3X
                            -> let
                                 c_MiRs_at40 = ((toVector x_at3X) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at3Y = ((toVector x_at3X) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at22
                                  * ((p_at2g + ((c_RESTc_at3Y / p_at24) ** p_at26))
                                     / (((1 + p_at2g) + ((c_RESTc_at3Y / p_at24) ** p_at26))
                                        + ((c_MiRs_at40 / p_at2c) ** p_at2e)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at41
                            -> let
                                 c_MiRs_at42 = ((toVector x_at41) Data.Vector.Unboxed.! 2)
                                 c_PTB_at43 = ((toVector x_at41) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2i
                                  / (1
                                     + (((c_MiRs_at42 / p_at2k) ** p_at2m)
                                        + ((c_PTB_at43 / p_at2o) ** p_at2q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at44
                            -> let c_RESTc_at45 = ((toVector x_at44) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at2s
                                  * (p_at2C
                                     / ((1 + p_at2C) + ((c_RESTc_at45 / p_at2y) ** p_at2A)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at46
                            -> let
                                 c_MiRs_at49 = ((toVector x_at46) Data.Vector.Unboxed.! 2)
                                 c_PTB_at47 = ((toVector x_at46) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at2E
                                  * ((p_at2S + ((c_PTB_at47 / p_at2G) ** p_at2I))
                                     / (((1 + p_at2S) + ((c_PTB_at47 / p_at2G) ** p_at2I))
                                        + ((c_MiRs_at49 / p_at2O) ** p_at2Q)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at4a
                            -> let
                                 c_RESTc_at4d = ((toVector x_at4a) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at4b = ((toVector x_at4a) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at2U
                                  * ((p_at34 + ((c_MiRs_at4b / p_at2W) ** p_at2Y))
                                     / (((1 + p_at34) + ((c_MiRs_at4b / p_at2W) ** p_at2Y))
                                        + ((c_RESTc_at4d / p_at30) ** p_at32)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at4e
                            -> let c_PTB_at4f = ((toVector x_at4e) Data.Vector.Unboxed.! 0)
                               in (p_at36 * c_PTB_at4f))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at4g
                            -> let c_NPTB_at4h = ((toVector x_at4g) Data.Vector.Unboxed.! 1)
                               in (p_at38 * c_NPTB_at4h))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at4i
                            -> let c_MiRs_at4j = ((toVector x_at4i) Data.Vector.Unboxed.! 2)
                               in (p_at3a * c_MiRs_at4j))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at4k
                            -> let c_RESTc_at4l = ((toVector x_at4k) Data.Vector.Unboxed.! 3)
                               in (p_at3c * c_RESTc_at4l))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at4m
                            -> let
                                 c_EndoNeuroTFs_at4n = ((toVector x_at4m) Data.Vector.Unboxed.! 4)
                               in (p_at3e * c_EndoNeuroTFs_at4n))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121385",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121386",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121387",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121388",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121389",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121390",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121391",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121392",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121393",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121394",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121395",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121396",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121397",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121398",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121399",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121400",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121401",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121402",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121403",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121404",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121405",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121406",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121407",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121408",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121409",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121410",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121411",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121412",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121413",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121414",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121415",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121416",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121417",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121418",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121419",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121420",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121421",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121422",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121423",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121424",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121425",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121426",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121427",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121428",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121429",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121430",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121431",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121432",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121433",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121434",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121435",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121436",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121437",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121438",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121439",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121440",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121441",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121442",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121443",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121444",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121445",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121446",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121447",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121448",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121449",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121450",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121451",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121452",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121453",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121454",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121455",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121456",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121457",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121458",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121459",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121460",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121461",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121462",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121463",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121464",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121465",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121466",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121467",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121468",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at3f
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at53
                            p_at3e = code-0.1.0.0:Genome.FixedList.Functions.double g_at3d
                            (g_at3d, gpart_at53) = Genome.Split.split gpart_at52
                            p_at3c = code-0.1.0.0:Genome.FixedList.Functions.double g_at3b
                            (g_at3b, gpart_at52) = Genome.Split.split gpart_at51
                            p_at3a = code-0.1.0.0:Genome.FixedList.Functions.double g_at39
                            (g_at39, gpart_at51) = Genome.Split.split gpart_at50
                            p_at38 = code-0.1.0.0:Genome.FixedList.Functions.double g_at37
                            (g_at37, gpart_at50) = Genome.Split.split gpart_at4Z
                            p_at36 = code-0.1.0.0:Genome.FixedList.Functions.double g_at35
                            (g_at35, gpart_at4Z) = Genome.Split.split gpart_at4Y
                            p_at34 = code-0.1.0.0:Genome.FixedList.Functions.double g_at33
                            (g_at33, gpart_at4Y) = Genome.Split.split gpart_at4X
                            p_at32 = Functions.belowten' g_at31
                            (g_at31, gpart_at4X) = Genome.Split.split gpart_at4W
                            p_at30 = code-0.1.0.0:Genome.FixedList.Functions.double g_at2Z
                            (g_at2Z, gpart_at4W) = Genome.Split.split gpart_at4V
                            p_at2Y = Functions.belowten' g_at2X
                            (g_at2X, gpart_at4V) = Genome.Split.split gpart_at4U
                            p_at2W = code-0.1.0.0:Genome.FixedList.Functions.double g_at2V
                            (g_at2V, gpart_at4U) = Genome.Split.split gpart_at4T
                            p_at2U = code-0.1.0.0:Genome.FixedList.Functions.double g_at2T
                            (g_at2T, gpart_at4T) = Genome.Split.split gpart_at4S
                            p_at2S = code-0.1.0.0:Genome.FixedList.Functions.double g_at2R
                            (g_at2R, gpart_at4S) = Genome.Split.split gpart_at4R
                            p_at2Q = Functions.belowten' g_at2P
                            (g_at2P, gpart_at4R) = Genome.Split.split gpart_at4Q
                            p_at2O = code-0.1.0.0:Genome.FixedList.Functions.double g_at2N
                            (g_at2N, gpart_at4Q) = Genome.Split.split gpart_at4P
                            p_at2M
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2L
                            (g_at2L, gpart_at4P) = Genome.Split.split gpart_at4O
                            p_at2K
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2J
                            (g_at2J, gpart_at4O) = Genome.Split.split gpart_at4N
                            p_at2I = Functions.belowten' g_at2H
                            (g_at2H, gpart_at4N) = Genome.Split.split gpart_at4M
                            p_at2G = code-0.1.0.0:Genome.FixedList.Functions.double g_at2F
                            (g_at2F, gpart_at4M) = Genome.Split.split gpart_at4L
                            p_at2E = code-0.1.0.0:Genome.FixedList.Functions.double g_at2D
                            (g_at2D, gpart_at4L) = Genome.Split.split gpart_at4K
                            p_at2C = code-0.1.0.0:Genome.FixedList.Functions.double g_at2B
                            (g_at2B, gpart_at4K) = Genome.Split.split gpart_at4J
                            p_at2A = Functions.belowten' g_at2z
                            (g_at2z, gpart_at4J) = Genome.Split.split gpart_at4I
                            p_at2y = code-0.1.0.0:Genome.FixedList.Functions.double g_at2x
                            (g_at2x, gpart_at4I) = Genome.Split.split gpart_at4H
                            p_at2w
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2v
                            (g_at2v, gpart_at4H) = Genome.Split.split gpart_at4G
                            p_at2u
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at2t
                            (g_at2t, gpart_at4G) = Genome.Split.split gpart_at4F
                            p_at2s = code-0.1.0.0:Genome.FixedList.Functions.double g_at2r
                            (g_at2r, gpart_at4F) = Genome.Split.split gpart_at4E
                            p_at2q = Functions.belowten' g_at2p
                            (g_at2p, gpart_at4E) = Genome.Split.split gpart_at4D
                            p_at2o = code-0.1.0.0:Genome.FixedList.Functions.double g_at2n
                            (g_at2n, gpart_at4D) = Genome.Split.split gpart_at4C
                            p_at2m = Functions.belowten' g_at2l
                            (g_at2l, gpart_at4C) = Genome.Split.split gpart_at4B
                            p_at2k = code-0.1.0.0:Genome.FixedList.Functions.double g_at2j
                            (g_at2j, gpart_at4B) = Genome.Split.split gpart_at4A
                            p_at2i = code-0.1.0.0:Genome.FixedList.Functions.double g_at2h
                            (g_at2h, gpart_at4A) = Genome.Split.split gpart_at4z
                            p_at2g = code-0.1.0.0:Genome.FixedList.Functions.double g_at2f
                            (g_at2f, gpart_at4z) = Genome.Split.split gpart_at4y
                            p_at2e = Functions.belowten' g_at2d
                            (g_at2d, gpart_at4y) = Genome.Split.split gpart_at4x
                            p_at2c = code-0.1.0.0:Genome.FixedList.Functions.double g_at2b
                            (g_at2b, gpart_at4x) = Genome.Split.split gpart_at4w
                            p_at2a
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at29
                            (g_at29, gpart_at4w) = Genome.Split.split gpart_at4v
                            p_at28
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at27
                            (g_at27, gpart_at4v) = Genome.Split.split gpart_at4u
                            p_at26 = Functions.belowten' g_at25
                            (g_at25, gpart_at4u) = Genome.Split.split gpart_at4t
                            p_at24 = code-0.1.0.0:Genome.FixedList.Functions.double g_at23
                            (g_at23, gpart_at4t) = Genome.Split.split gpart_at4s
                            p_at22 = code-0.1.0.0:Genome.FixedList.Functions.double g_at21
                            (g_at21, gpart_at4s) = Genome.Split.split gpart_at4r
                            p_at20 = code-0.1.0.0:Genome.FixedList.Functions.double g_at1Z
                            (g_at1Z, gpart_at4r) = Genome.Split.split gpart_at4q
                            p_at1Y = code-0.1.0.0:Genome.FixedList.Functions.double g_at1X
                            (g_at1X, gpart_at4q) = Genome.Split.split gpart_at4p
                            p_at1W = code-0.1.0.0:Genome.FixedList.Functions.double g_at1V
                            (g_at1V, gpart_at4p) = Genome.Split.split gpart_at4o
                            p_at1U = code-0.1.0.0:Genome.FixedList.Functions.double g_at1T
                            (g_at1T, gpart_at4o) = Genome.Split.split genome_at3f
                          in
                            \ desc_at3g
                              -> case desc_at3g of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1U)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1W)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at1Y)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at20)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at22)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at24)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at26)
                                   "Inhibition coef 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at28)
                                   "Inhibition hill 0 --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2a)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2c)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2e)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2g)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2i)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2k)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2m)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2o)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2q)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2s)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2u)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2w)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2y)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2A)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2C)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2E)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2G)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2I)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2K)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2M)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2O)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Q)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2S)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2U)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2W)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at2Y)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at30)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at32)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at34)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at36)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at38)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3a)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3c)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at3e)
                                   _ -> Nothing }}
src/ineurons/Gillespie.hs:22:26-96: Splicing expression
    describe . buildPheno
    $ reactionNetwork <$> neuroreactions PTBdepletion
  ======>
    GPMap
      {gpmap = \ genome_at76
                 -> let
                      ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at7N
                      p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                      (g_at74, gpart_at7N) = Genome.Split.split gpart_at7M
                      p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                      (g_at72, gpart_at7M) = Genome.Split.split gpart_at7L
                      p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                      (g_at70, gpart_at7L) = Genome.Split.split gpart_at7K
                      p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                      (g_at6Y, gpart_at7K) = Genome.Split.split gpart_at7J
                      p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                      (g_at6W, gpart_at7J) = Genome.Split.split gpart_at7I
                      p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                      (g_at6U, gpart_at7I) = Genome.Split.split gpart_at7H
                      p_at6T = Functions.belowten' g_at6S
                      (g_at6S, gpart_at7H) = Genome.Split.split gpart_at7G
                      p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                      (g_at6Q, gpart_at7G) = Genome.Split.split gpart_at7F
                      p_at6P = Functions.belowten' g_at6O
                      (g_at6O, gpart_at7F) = Genome.Split.split gpart_at7E
                      p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                      (g_at6M, gpart_at7E) = Genome.Split.split gpart_at7D
                      p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                      (g_at6K, gpart_at7D) = Genome.Split.split gpart_at7C
                      p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                      (g_at6I, gpart_at7C) = Genome.Split.split gpart_at7B
                      p_at6H = Functions.belowten' g_at6G
                      (g_at6G, gpart_at7B) = Genome.Split.split gpart_at7A
                      p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                      (g_at6E, gpart_at7A) = Genome.Split.split gpart_at7z
                      p_at6D
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6C
                      (g_at6C, gpart_at7z) = Genome.Split.split gpart_at7y
                      p_at6B
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6A
                      (g_at6A, gpart_at7y) = Genome.Split.split gpart_at7x
                      p_at6z = Functions.belowten' g_at6y
                      (g_at6y, gpart_at7x) = Genome.Split.split gpart_at7w
                      p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                      (g_at6w, gpart_at7w) = Genome.Split.split gpart_at7v
                      p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                      (g_at6u, gpart_at7v) = Genome.Split.split gpart_at7u
                      p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                      (g_at6s, gpart_at7u) = Genome.Split.split gpart_at7t
                      p_at6r = Functions.belowten' g_at6q
                      (g_at6q, gpart_at7t) = Genome.Split.split gpart_at7s
                      p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                      (g_at6o, gpart_at7s) = Genome.Split.split gpart_at7r
                      p_at6n
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6m
                      (g_at6m, gpart_at7r) = Genome.Split.split gpart_at7q
                      p_at6l
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6k
                      (g_at6k, gpart_at7q) = Genome.Split.split gpart_at7p
                      p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                      (g_at6i, gpart_at7p) = Genome.Split.split gpart_at7o
                      p_at6h = Functions.belowten' g_at6g
                      (g_at6g, gpart_at7o) = Genome.Split.split gpart_at7n
                      p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                      (g_at6e, gpart_at7n) = Genome.Split.split gpart_at7m
                      p_at6d = Functions.belowten' g_at6c
                      (g_at6c, gpart_at7m) = Genome.Split.split gpart_at7l
                      p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                      (g_at6a, gpart_at7l) = Genome.Split.split gpart_at7k
                      p_at69 = code-0.1.0.0:Genome.FixedList.Functions.double g_at68
                      (g_at68, gpart_at7k) = Genome.Split.split gpart_at7j
                      p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                      (g_at66, gpart_at7j) = Genome.Split.split gpart_at7i
                      p_at65 = Functions.belowten' g_at64
                      (g_at64, gpart_at7i) = Genome.Split.split gpart_at7h
                      p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                      (g_at62, gpart_at7h) = Genome.Split.split gpart_at7g
                      p_at61
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at60
                      (g_at60, gpart_at7g) = Genome.Split.split gpart_at7f
                      p_at5Z
                        = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Y
                      (g_at5Y, gpart_at7f) = Genome.Split.split gpart_at7e
                      p_at5X = Functions.belowten' g_at5W
                      (g_at5W, gpart_at7e) = Genome.Split.split gpart_at7d
                      p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                      (g_at5U, gpart_at7d) = Genome.Split.split gpart_at7c
                      p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                      (g_at5S, gpart_at7c) = Genome.Split.split gpart_at7b
                      p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                      (g_at5Q, gpart_at7b) = Genome.Split.split gpart_at7a
                      p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                      (g_at5O, gpart_at7a) = Genome.Split.split gpart_at79
                      p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                      (g_at5M, gpart_at79) = Genome.Split.split gpart_at78
                      p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                      (g_at5K, gpart_at78) = Genome.Split.split genome_at76
                    in
                      [Reaction
                         (\ x_at7O
                            -> let
                                 c_MiRs_at7R = ((toVector x_at7O) Data.Vector.Unboxed.! 2)
                                 c_RESTc_at7P = ((toVector x_at7O) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at5T
                                  * ((p_at67 + ((c_RESTc_at7P / p_at5V) ** p_at5X))
                                     / (((1 + p_at67) + ((c_RESTc_at7P / p_at5V) ** p_at5X))
                                        + (((p_at5L / p_at5Z) ** p_at61)
                                           + ((c_MiRs_at7R / p_at63) ** p_at65))))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at7S
                            -> let
                                 c_MiRs_at7T = ((toVector x_at7S) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7U = ((toVector x_at7S) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at69
                                  / (1
                                     + (((c_MiRs_at7T / p_at6b) ** p_at6d)
                                        + ((c_PTB_at7U / p_at6f) ** p_at6h)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 1, 0, 0, 0]),
                       Reaction
                         (\ x_at7V
                            -> let c_RESTc_at7W = ((toVector x_at7V) Data.Vector.Unboxed.! 3)
                               in
                                 (p_at6j
                                  * (p_at6t
                                     / ((1 + p_at6t) + ((c_RESTc_at7W / p_at6p) ** p_at6r)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 1, 0, 0]),
                       Reaction
                         (\ x_at7X
                            -> let
                                 c_MiRs_at80 = ((toVector x_at7X) Data.Vector.Unboxed.! 2)
                                 c_PTB_at7Y = ((toVector x_at7X) Data.Vector.Unboxed.! 0)
                               in
                                 (p_at6v
                                  * ((p_at6J + ((c_PTB_at7Y / p_at6x) ** p_at6z))
                                     / (((1 + p_at6J) + ((c_PTB_at7Y / p_at6x) ** p_at6z))
                                        + ((c_MiRs_at80 / p_at6F) ** p_at6H)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 1, 0]),
                       Reaction
                         (\ x_at81
                            -> let
                                 c_RESTc_at84 = ((toVector x_at81) Data.Vector.Unboxed.! 3)
                                 c_MiRs_at82 = ((toVector x_at81) Data.Vector.Unboxed.! 2)
                               in
                                 (p_at6L
                                  * ((p_at6V + ((c_MiRs_at82 / p_at6N) ** p_at6P))
                                     / (((1 + p_at6V) + ((c_MiRs_at82 / p_at6N) ** p_at6P))
                                        + ((c_RESTc_at84 / p_at6R) ** p_at6T)))))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, 1]),
                       Reaction
                         (\ x_at85
                            -> let c_PTB_at86 = ((toVector x_at85) Data.Vector.Unboxed.! 0)
                               in (p_at6X * c_PTB_at86))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [-1, 0, 0, 0, 0]),
                       Reaction
                         (\ x_at87
                            -> let c_NPTB_at88 = ((toVector x_at87) Data.Vector.Unboxed.! 1)
                               in (p_at6Z * c_NPTB_at88))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, -1, 0, 0, 0]),
                       Reaction
                         (\ x_at89
                            -> let c_MiRs_at8a = ((toVector x_at89) Data.Vector.Unboxed.! 2)
                               in (p_at71 * c_MiRs_at8a))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, -1, 0, 0]),
                       Reaction
                         (\ x_at8b
                            -> let c_RESTc_at8c = ((toVector x_at8b) Data.Vector.Unboxed.! 3)
                               in (p_at73 * c_RESTc_at8c))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, -1, 0]),
                       Reaction
                         (\ x_at8d
                            -> let
                                 c_EndoNeuroTFs_at8e = ((toVector x_at8d) Data.Vector.Unboxed.! 4)
                               in (p_at75 * c_EndoNeuroTFs_at8e))
                         ((indexed . Data.Vector.Unboxed.fromList) $ [0, 0, 0, 0, -1])],
       parameters = [Parameter
                       {param_info = "External inhibition parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121624",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121625",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External inhibition parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121626",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121627",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 1",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121628",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121629",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "External activation parameter 2",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121630",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121631",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121632",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121633",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121634",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121635",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [RESTc] --> PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121636",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121637",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121638",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121639",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill [~] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121640",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121641",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121642",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121643",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121644",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121645",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121646",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121647",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121648",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121649",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121650",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121651",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121652",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121653",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121654",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121655",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [PTB] --| NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121656",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121657",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Vmax transcription of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121658",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121659",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121660",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121661",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Activation hill 0 --> MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121662",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121663",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121664",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121665",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121666",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121667",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121668",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121669",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121670",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121671",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121672",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121673",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [PTB] --> RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121674",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121675",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121676",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121677",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition hill 0 --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121678",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121679",
                        param_gtype = Data.Typeable.Internal.typeRep ([] :: [()]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 ::
                                       () -> Double},
                     Parameter
                       {param_info = "Inhibition coef [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121680",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121681",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [MiRs] --| RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121682",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121683",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121684",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121685",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Vmax transcription of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121686",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121687",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation coef [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121688",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121689",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Activation hill [MiRs] --> EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121690",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121691",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Inhibition coef [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121692",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121693",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Inhibition hill [RESTc] --| EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121694",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121695",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = Functions.belowten'},
                     Parameter
                       {param_info = "Background transcription EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121696",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121697",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of PTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121698",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121699",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of NPTB",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121700",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121701",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of MiRs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121702",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121703",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of RESTc",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121704",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121705",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double},
                     Parameter
                       {param_info = "Decay rate of EndoNeuroTFs",
                        param_gname = Language.Haskell.TH.Syntax.mkName
                                        "g_6989586621679121706",
                        param_pname = Language.Haskell.TH.Syntax.mkName
                                        "p_6989586621679121707",
                        param_gtype = Data.Typeable.Internal.typeRep
                                        ([] :: [Data.Fixed.List.FixedList 1 Double]),
                        param_ptype = Data.Typeable.Internal.typeRep ([] :: [Double]),
                        param_func = code-0.1.0.0:Genome.FixedList.Functions.double}],
       lookupParam = \ genome_at76
                       -> let
                            ghc-prim-0.5.0.0:GHC.Tuple.() = gpart_at8U
                            p_at75 = code-0.1.0.0:Genome.FixedList.Functions.double g_at74
                            (g_at74, gpart_at8U) = Genome.Split.split gpart_at8T
                            p_at73 = code-0.1.0.0:Genome.FixedList.Functions.double g_at72
                            (g_at72, gpart_at8T) = Genome.Split.split gpart_at8S
                            p_at71 = code-0.1.0.0:Genome.FixedList.Functions.double g_at70
                            (g_at70, gpart_at8S) = Genome.Split.split gpart_at8R
                            p_at6Z = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Y
                            (g_at6Y, gpart_at8R) = Genome.Split.split gpart_at8Q
                            p_at6X = code-0.1.0.0:Genome.FixedList.Functions.double g_at6W
                            (g_at6W, gpart_at8Q) = Genome.Split.split gpart_at8P
                            p_at6V = code-0.1.0.0:Genome.FixedList.Functions.double g_at6U
                            (g_at6U, gpart_at8P) = Genome.Split.split gpart_at8O
                            p_at6T = Functions.belowten' g_at6S
                            (g_at6S, gpart_at8O) = Genome.Split.split gpart_at8N
                            p_at6R = code-0.1.0.0:Genome.FixedList.Functions.double g_at6Q
                            (g_at6Q, gpart_at8N) = Genome.Split.split gpart_at8M
                            p_at6P = Functions.belowten' g_at6O
                            (g_at6O, gpart_at8M) = Genome.Split.split gpart_at8L
                            p_at6N = code-0.1.0.0:Genome.FixedList.Functions.double g_at6M
                            (g_at6M, gpart_at8L) = Genome.Split.split gpart_at8K
                            p_at6L = code-0.1.0.0:Genome.FixedList.Functions.double g_at6K
                            (g_at6K, gpart_at8K) = Genome.Split.split gpart_at8J
                            p_at6J = code-0.1.0.0:Genome.FixedList.Functions.double g_at6I
                            (g_at6I, gpart_at8J) = Genome.Split.split gpart_at8I
                            p_at6H = Functions.belowten' g_at6G
                            (g_at6G, gpart_at8I) = Genome.Split.split gpart_at8H
                            p_at6F = code-0.1.0.0:Genome.FixedList.Functions.double g_at6E
                            (g_at6E, gpart_at8H) = Genome.Split.split gpart_at8G
                            p_at6D
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6C
                            (g_at6C, gpart_at8G) = Genome.Split.split gpart_at8F
                            p_at6B
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6A
                            (g_at6A, gpart_at8F) = Genome.Split.split gpart_at8E
                            p_at6z = Functions.belowten' g_at6y
                            (g_at6y, gpart_at8E) = Genome.Split.split gpart_at8D
                            p_at6x = code-0.1.0.0:Genome.FixedList.Functions.double g_at6w
                            (g_at6w, gpart_at8D) = Genome.Split.split gpart_at8C
                            p_at6v = code-0.1.0.0:Genome.FixedList.Functions.double g_at6u
                            (g_at6u, gpart_at8C) = Genome.Split.split gpart_at8B
                            p_at6t = code-0.1.0.0:Genome.FixedList.Functions.double g_at6s
                            (g_at6s, gpart_at8B) = Genome.Split.split gpart_at8A
                            p_at6r = Functions.belowten' g_at6q
                            (g_at6q, gpart_at8A) = Genome.Split.split gpart_at8z
                            p_at6p = code-0.1.0.0:Genome.FixedList.Functions.double g_at6o
                            (g_at6o, gpart_at8z) = Genome.Split.split gpart_at8y
                            p_at6n
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6m
                            (g_at6m, gpart_at8y) = Genome.Split.split gpart_at8x
                            p_at6l
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at6k
                            (g_at6k, gpart_at8x) = Genome.Split.split gpart_at8w
                            p_at6j = code-0.1.0.0:Genome.FixedList.Functions.double g_at6i
                            (g_at6i, gpart_at8w) = Genome.Split.split gpart_at8v
                            p_at6h = Functions.belowten' g_at6g
                            (g_at6g, gpart_at8v) = Genome.Split.split gpart_at8u
                            p_at6f = code-0.1.0.0:Genome.FixedList.Functions.double g_at6e
                            (g_at6e, gpart_at8u) = Genome.Split.split gpart_at8t
                            p_at6d = Functions.belowten' g_at6c
                            (g_at6c, gpart_at8t) = Genome.Split.split gpart_at8s
                            p_at6b = code-0.1.0.0:Genome.FixedList.Functions.double g_at6a
                            (g_at6a, gpart_at8s) = Genome.Split.split gpart_at8r
                            p_at69 = code-0.1.0.0:Genome.FixedList.Functions.double g_at68
                            (g_at68, gpart_at8r) = Genome.Split.split gpart_at8q
                            p_at67 = code-0.1.0.0:Genome.FixedList.Functions.double g_at66
                            (g_at66, gpart_at8q) = Genome.Split.split gpart_at8p
                            p_at65 = Functions.belowten' g_at64
                            (g_at64, gpart_at8p) = Genome.Split.split gpart_at8o
                            p_at63 = code-0.1.0.0:Genome.FixedList.Functions.double g_at62
                            (g_at62, gpart_at8o) = Genome.Split.split gpart_at8n
                            p_at61
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at60
                            (g_at60, gpart_at8n) = Genome.Split.split gpart_at8m
                            p_at5Z
                              = \ ghc-prim-0.5.0.0:GHC.Tuple.() -> 1.0 :: () -> Double g_at5Y
                            (g_at5Y, gpart_at8m) = Genome.Split.split gpart_at8l
                            p_at5X = Functions.belowten' g_at5W
                            (g_at5W, gpart_at8l) = Genome.Split.split gpart_at8k
                            p_at5V = code-0.1.0.0:Genome.FixedList.Functions.double g_at5U
                            (g_at5U, gpart_at8k) = Genome.Split.split gpart_at8j
                            p_at5T = code-0.1.0.0:Genome.FixedList.Functions.double g_at5S
                            (g_at5S, gpart_at8j) = Genome.Split.split gpart_at8i
                            p_at5R = code-0.1.0.0:Genome.FixedList.Functions.double g_at5Q
                            (g_at5Q, gpart_at8i) = Genome.Split.split gpart_at8h
                            p_at5P = code-0.1.0.0:Genome.FixedList.Functions.double g_at5O
                            (g_at5O, gpart_at8h) = Genome.Split.split gpart_at8g
                            p_at5N = code-0.1.0.0:Genome.FixedList.Functions.double g_at5M
                            (g_at5M, gpart_at8g) = Genome.Split.split gpart_at8f
                            p_at5L = code-0.1.0.0:Genome.FixedList.Functions.double g_at5K
                            (g_at5K, gpart_at8f) = Genome.Split.split genome_at76
                          in
                            \ desc_at77
                              -> case desc_at77 of {
                                   "External inhibition parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5L)
                                   "External inhibition parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5N)
                                   "External activation parameter 1"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5P)
                                   "External activation parameter 2"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5R)
                                   "Vmax transcription of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5T)
                                   "Activation coef [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5V)
                                   "Activation hill [RESTc] --> PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5X)
                                   "Inhibition coef [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at5Z)
                                   "Inhibition hill [~] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at61)
                                   "Inhibition coef [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at63)
                                   "Inhibition hill [MiRs] --| PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at65)
                                   "Background transcription PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at67)
                                   "Vmax transcription of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at69)
                                   "Inhibition coef [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6b)
                                   "Inhibition hill [MiRs] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6d)
                                   "Inhibition coef [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6f)
                                   "Inhibition hill [PTB] --| NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6h)
                                   "Vmax transcription of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6j)
                                   "Activation coef 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6l)
                                   "Activation hill 0 --> MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6n)
                                   "Inhibition coef [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6p)
                                   "Inhibition hill [RESTc] --| MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6r)
                                   "Background transcription MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6t)
                                   "Vmax transcription of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6v)
                                   "Activation coef [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6x)
                                   "Activation hill [PTB] --> RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6z)
                                   "Inhibition coef 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6B)
                                   "Inhibition hill 0 --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6D)
                                   "Inhibition coef [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6F)
                                   "Inhibition hill [MiRs] --| RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6H)
                                   "Background transcription RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6J)
                                   "Vmax transcription of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6L)
                                   "Activation coef [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6N)
                                   "Activation hill [MiRs] --> EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6P)
                                   "Inhibition coef [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6R)
                                   "Inhibition hill [RESTc] --| EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6T)
                                   "Background transcription EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6V)
                                   "Decay rate of PTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6X)
                                   "Decay rate of NPTB"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at6Z)
                                   "Decay rate of MiRs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at71)
                                   "Decay rate of RESTc"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at73)
                                   "Decay rate of EndoNeuroTFs"
                                     -> Data.Dynamic.fromDynamic (Data.Dynamic.toDyn p_at75)
                                   _ -> Nothing }}
